import SubmodularMatching.LowerBoundGlobalVerifiedTheorem
import Lean.Util.CollectAxioms

/-!
# Supplementary verification of the AJX blueprint code

Run `lake env lean verification/AuditVendorDeclarations.lean` from the
project root after `lake build`. The imported environment determines each
declaration's defining module, including private and generated declarations.
-/

open Lean Elab Command

#check AJXUpstream.PaperWalkEncoding.GamblerWalk.position_congr_until
#check AJXUpstream.PaperParameterSelection.SelectedParameters.failure_error_absorption
#check AJXUpstream.PaperParameterSelection.SelectedParameters.centralDelayFactor_eq
#check AJXUpstream.PaperParameterSelection.SelectedParameters.paperLowerBound_le_central_estimate

set_option maxHeartbeats 0 in
run_cmd do
  let env ← getEnv
  let modulePrefix := "SubmodularMatching.AJXUpstream."
  let vendorDecls := env.constants.toList.filterMap fun (name, _) => do
    let idx ← env.getModuleIdxFor? name
    let mod := env.header.modules[idx.toNat]!.module.toString
    if mod.startsWith modulePrefix then some name else none
  if vendorDecls.isEmpty then
    throwError "No vendored declarations found"
  let (_, audit) := ((vendorDecls.forM Lean.CollectAxioms.collect).run env).run {}
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  let unexpected := audit.axioms.filter (fun n => !allowed.contains n)
  unless unexpected.isEmpty do
    throwError "Unexpected vendor axioms {unexpected}"
  let privateDecls := vendorDecls.filter Lean.isPrivateName
  logInfo m!"Audited {vendorDecls.length} vendored declarations including {privateDecls.length} private declarations"
  logInfo m!"All vendored axiom dependencies {audit.axioms}"
