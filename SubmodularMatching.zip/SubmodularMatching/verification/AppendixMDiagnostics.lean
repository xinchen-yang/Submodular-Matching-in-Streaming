import SubmodularMatching.AppendixMDiagnosticCertificate
import SubmodularMatching.AppendixMArxivConstants

open SubmodularMatching.AppendixM.Diagnostics

example : slackMicro false false = 1325 ∧ slackMicro false true = 1741 ∧
    slackMicro true false = 2261 ∧ slackMicro true true = 22477 := by decide

#print axioms SubmodularMatching.AppendixM.Diagnostics.equation26_diagnostic
#print axioms SubmodularMatching.AppendixM.arxiv_priority_certificate
