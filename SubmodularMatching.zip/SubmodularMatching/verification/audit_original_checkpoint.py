#!/usr/bin/env python3
"""Check unchanged original modules and audit their inherited theorem list after the numerical replay."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
FAMILY = "SubmodularMatching.ReplayUncoveredMiddle."
RESULT = FAMILY + "Result"
BUILD = ROOT / ".lake/build/lib/lean"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}


def module_path(name, suffix):
    return Path(*name.split(".")).with_suffix(suffix)


def original_modules(summary):
    local = {}
    for source, sign in summary["source_sha256"].items():
        path = ROOT / source
        data = path.read_bytes()
        if sha256(data).hexdigest() != sign:
            raise ValueError(f"Original source differs from the checkpoint: {path}")
        module = ".".join(Path(source).with_suffix("").parts)
        if not module.startswith(FAMILY):
            local[module] = re.findall(r"^import\s+(SubmodularMatching(?:\.[\w.]+)?)\s*$",
                                       data.decode(), re.MULTILINE)
    return local


def audit_names(output, names, compiler):
    # The visitor is the same one used by Lean's built-in #print axioms command.
    code = """import SubmodularMatching
import Lean.Util.CollectAxioms
open Lean Elab Command
elab "#checkpoint_roots" roots:ident+ : command => do
  let env ← getEnv
  let kernel := env.checked.get
  let names := roots.map (·.getId)
  for name in names do
    unless (kernel.find? name).isSome do
      throwError m!"Missing kernel declaration {name}"
  let (_, checked) := ((names.forM Lean.CollectAxioms.collect).run env).run {}
  logInfo m!"Audited {names.size} original declarations"
  logInfo m!"Axiom union: {checked.axioms.qsort Name.lt |>.toList}"
#checkpoint_roots
"""
    src = output / "OriginalUnion.lean"
    src.write_text(code + "".join("  " + name + "\n" for name in names))
    with (output / "original-union.log").open("w") as log:
        subprocess.run(compiler + [str(src)], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    log = (output / "original-union.log").read_text()
    match = re.search(r"Axiom union:\s*\[([^\]]*)\]", log)
    if f"Audited {len(names)} original declarations" not in log or not match:
        raise RuntimeError("Incomplete original axiom audit")
    if set(re.findall(r"[A-Za-z.]+", match.group(1))) - ALLOWED:
        raise RuntimeError("Unexpected original axiom: " + match.group(1))
    print(log, end="")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--worker-budget", type=Path, help="Optional plain-text active worker limit between 1 and --jobs")
    parser.add_argument("--runner", help="Optional shared concurrency limiter for each compiler process")
    parser.add_argument("--wait-for-result", action="store_true",
                        help="Wait if the separate Appendix L replay has not yet installed its final checked object")
    args = parser.parse_args()
    if args.jobs < 1 or not os.environ.get("LEAN_PATH") or not shutil.which("lean"):
        parser.error("Use lake env python3 and at least one worker")
    out = args.output.resolve()
    logs = out / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    summary = json.loads((ROOT / "verification/summary.json").read_text())
    dependencies = original_modules(summary)
    done = {n for n in dependencies if (BUILD / module_path(n, ".olean")).is_file()}
    pending = sorted(set(dependencies) - done)
    compiler = ([args.runner] if args.runner else []) + [
        shutil.which("lean"), "--root=" + str(ROOT), "-DrelaxedAutoImplicit=false", "-DmaxSynthPendingDepth=3"]
    original_reused = len(done)
    checked = []
    def compile_module(name):
        dest = BUILD / module_path(name, ".olean")
        dest.parent.mkdir(parents=True, exist_ok=True)
        with (logs / (name + ".log")).open("w") as log:
            result = subprocess.run(compiler + ["-o", str(dest), str(ROOT / module_path(name, ".lean"))],
                                    cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f"Lean rejected {name}; see {logs / (name + '.log')}")
        return name
    with ThreadPoolExecutor(max_workers=args.jobs) as pool, (out / "progress.log").open("a", buffering=1) as log:
        active = {}
        while pending or active:
            if (BUILD / module_path(RESULT, ".olean")).is_file():
                done.add(RESULT)
            limit = args.jobs
            if args.worker_budget:
                limit = min(limit, max(1, int(args.worker_budget.read_text().strip())))
            while len(active) < limit:
                n = next((n for n in pending if all(d in done for d in dependencies[n])), None)
                if n is None:
                    break
                pending.remove(n)
                active[pool.submit(compile_module, n)] = n
            if not active:
                if args.wait_for_result and RESULT not in done:
                    time.sleep(5)
                    continue
                raise RuntimeError("Missing original imports. Complete the numerical replay with --install.")
            finished, _ = wait(active, return_when=FIRST_COMPLETED)
            for job in finished:
                n = job.result()
                del active[job]
                done.add(n)
                checked.append(n)
                print(n, f"{len(done.intersection(dependencies))}/{len(dependencies)}", file=log)
    audit_names(out, summary["audited_declarations"], compiler)
    receipt = {"source_files_checked": len(summary["source_sha256"]), "outside_large_numerical_family": len(dependencies),
               "existing_objects": original_reused, "new_objects": checked,
               "audited_theorems": len(summary["audited_declarations"]),
               "original_source_summary_sha256": sha256((ROOT / "verification/summary.json").read_bytes()).hexdigest()}
    (out / "original-audit-result.json").write_text(json.dumps(receipt, indent=2) + "\n")


if __name__ == "__main__":
    main()
