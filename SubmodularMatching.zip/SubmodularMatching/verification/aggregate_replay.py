"""Check the Appendix L shards in batches, retaining their original declarations verbatim."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
PREFIX = "SubmodularMatching.ReplayUncoveredMiddle."
SHARDS = ROOT / "SubmodularMatching" / "ReplayUncoveredMiddle"
DECLARATION = re.compile(rb"^(?:private )?(?:theorem|def) (\w+)", re.MULTILINE)


def digest(data):
    return sha256(data).hexdigest()


def source_path(root, module, suffix):
    return root.joinpath(*module.split(".")).with_suffix(suffix)


def read_original(path, trusted):
    data = path.read_bytes()
    key = path.relative_to(ROOT).as_posix()
    if digest(data) != trusted[key]:
        raise ValueError(f"Source hash differs from the verified checkpoint: {key}")
    lines = data.splitlines(keepends=True)
    stop = next(i for i, line in enumerate(lines) if not line.startswith(b"import "))
    imports = [line.decode().split()[1] for line in lines[:stop]]
    body = b"".join(lines[stop:])
    if not imports or re.search(rb"^import ", body, re.MULTILINE):
        raise ValueError(f"Unexpected import layout: {key}")
    return data, imports, body


def generate(output, batch_size):
    src = output / "src"
    src.mkdir(parents=True, exist_ok=True)
    trusted = json.loads((ROOT / "verification/summary.json").read_text())["source_sha256"]
    groups = []
    assignment = {}
    for family in ("Rates", "Cones", "Part"):
        files = sorted(SHARDS.glob(family + "*.lean"))
        for i in range(0, len(files), batch_size):
            module = f"SubmodularMatchingReplayBatch.{family}{i // batch_size:04}"
            members = files[i:i + batch_size]
            groups.append((module, members))
            for f in members:
                assignment[PREFIX + f.stem] = module

    records = {}
    seen = set()
    public_names = set()
    body_count = 0
    for module, members in groups:
        imports = set()
        bodies = []
        proofs = []
        for f in members:
            data, required, body = read_original(f, trusted)
            key = PREFIX + f.stem
            for dep in required:
                if dep.startswith(PREFIX) and dep not in seen:
                    raise ValueError(f"Original import is out of order: {key} imports {dep}")
                target = assignment.get(dep, dep)
                if target != module:
                    imports.add(target)
            declarations = DECLARATION.findall(body)
            if not declarations or public_names.intersection(declarations) or len(set(declarations)) != len(declarations):
                raise ValueError(f"Unexpected duplicate or empty declaration set in {key}")
            public_names.update(declarations)
            body_count += len(declarations)
            seen.add(key)
            proofs.append({"source": f.relative_to(ROOT).as_posix(), "source_sha256": digest(data),
                           "body_sha256": digest(body), "bytes": len(body), "declarations": len(declarations),
                           "original_imports": required})
            bodies.append(body)

        head = "".join(f"import {dep}\n" for dep in sorted(imports)).encode()
        path = source_path(src, module, ".lean")
        path.parent.mkdir(parents=True, exist_ok=True)
        aggregate = head + b"".join(bodies)
        path.write_bytes(aggregate)
        on_disk = path.read_bytes()
        offset = len(head)
        for proof, original in zip(proofs, bodies):
            proof["offset"] = offset
            if on_disk[offset:offset+len(original)] != original:
                raise ValueError(f"Body changed in {module}")
            offset += len(original)
        if offset != len(on_disk):
            raise ValueError(f"Unaccounted bytes in {module}")
        records[module] = {"imports": sorted(imports), "shards": proofs, "sha256": digest(on_disk)}

    original_files = set(SHARDS.glob("*.lean"))
    if original_files != {f for _, members in groups for f in members} | {SHARDS / "Result.lean"}:
        raise ValueError("The batch list omits original files")
    result_file = SHARDS / "Result.lean"
    data, result_imports, _ = read_original(result_file, trusted)
    for dep in result_imports:
        if dep not in assignment:
            raise ValueError(f"Unexpected final import {dep}")
        # The original final theorem imports this module by name. It sees the same checked
        # declarations through the aggregate, with no additional declaration or assumption.
        body = f"import {assignment[dep]}\n".encode()
        forward = source_path(src, dep, ".lean")
        forward.parent.mkdir(parents=True, exist_ok=True)
        forward.write_bytes(body)
        records[dep] = {"imports": [assignment[dep]], "sha256": digest(body), "forwarding": True}
    result = PREFIX + "Result"
    source_path(src, result, ".lean").write_bytes(data)
    records[result] = {"imports": result_imports, "sha256": digest(data), "verbatim_result": True}
    manifest = {"batch_size": batch_size, "original_shards": len(seen), "declarations": body_count, "modules": records}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return records


def expose_project_helpers(lib, search_path):
    """Lean selects a package directory before looking for a specific module.

    The forwarder shares the original package name. Expose the checkpoint's
    ordinary objects in that namespace while keeping the numerical objects
    produced by this replay in its own generated subdirectory.
    """
    roots = [Path(p) for p in search_path.split(os.pathsep) if p]
    package = next((r / "SubmodularMatching" for r in roots
                    if r.resolve() != lib.resolve() and (r / "SubmodularMatching").is_dir()), None)
    if package is None:
        raise ValueError("Missing original project build objects; run with --prepare")
    target = lib / "SubmodularMatching"
    for src in package.rglob("*.olean*"):
        relative = src.relative_to(package)
        if relative.parts[0] == "ReplayUncoveredMiddle" or not src.is_file():
            continue
        dest = target / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists() and os.path.samefile(src, dest):
            continue
        with tempfile.TemporaryDirectory(dir=dest.parent) as tmp:
            staged = Path(tmp) / dest.name
            try:
                staged.symlink_to(src.resolve())
            except OSError:
                try:
                    os.link(src, staged)
                except OSError:
                    shutil.copy2(src, staged)
            os.replace(staged, dest)


def compile_modules(output, records, jobs, runner):
    lib = output / "lib"
    logdir = output / "logs"
    logdir.mkdir(parents=True, exist_ok=True)
    src = output / "src"
    env = os.environ.copy()
    if not env.get("LEAN_PATH"):
        raise SystemExit("Run the checker with lake env so the original project and its dependencies are visible")
    expose_project_helpers(lib, env["LEAN_PATH"])
    env["LEAN_PATH"] = str(lib) + os.pathsep + env["LEAN_PATH"]
    lean = shutil.which("lean", path=env.get("PATH"))
    if not lean:
        raise SystemExit("Pinned Lean executable is missing from PATH")

    def compile_one(name):
        target = source_path(lib, name, ".olean")
        target.parent.mkdir(parents=True, exist_ok=True)
        cmd = ([runner] if runner else []) + [lean, "--root=" + str(src), "-DrelaxedAutoImplicit=false",
               "-DmaxSynthPendingDepth=3", "-o", str(target), str(source_path(src, name, ".lean"))]
        started = time.monotonic()
        with (logdir / (name + ".log")).open("w") as log:
            result = subprocess.run(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f"Lean rejected {name}; inspect {logdir / (name + '.log')}")
        return name, round(time.monotonic() - started, 2)

    # Inputs already checked in this run may resume after an interruption. The fingerprint
    # includes the exact transitive batch contents and the installed compiler identity.
    identity = subprocess.check_output([lean, "--version"], env=env)
    external = sorted({d for r in records.values() for d in r["imports"] if d not in records})
    search = [Path(x) for x in env["LEAN_PATH"].split(os.pathsep) if x]
    direct_hashes = {}
    for dep in external:
        path = next((source_path(base, dep, ".olean") for base in search
                     if source_path(base, dep, ".olean").is_file()), None)
        if path is None:
            raise ValueError(f"Missing compiled prerequisite {dep}; run with --prepare")
        direct_hashes[dep] = digest(path.read_bytes())
    pins = digest((ROOT / "lake-manifest.json").read_bytes()) + digest((ROOT / "lean-toolchain").read_bytes())
    signatures = dict(direct_hashes)
    for n, r in records.items():
        deps = [signatures[i] for i in r["imports"]]
        signatures[n] = digest(identity + (pins + r["sha256"] + "".join(deps)).encode())
    stampdir = output / "checked"
    stampdir.mkdir(exist_ok=True)
    done = {n for n in records if (stampdir / n).is_file() and (stampdir / n).read_text() == signatures[n]
            and source_path(lib, n, ".olean").is_file()}
    # An early parameter check can release a long chain of dependent geometry
    # batches. Prioritize the longest still-unchecked dependency paths.
    children = {n: [] for n in records if n not in done}
    for n in children:
        for dep in records[n]["imports"]:
            if dep in children:
                children[dep].append(n)
    height = {}
    for n in reversed(children):
        height[n] = 1 + max((height[child] for child in children[n]), default=0)
    pending = sorted(children, key=lambda n: (-height[n], n))
    active = {}
    with ThreadPoolExecutor(max_workers=jobs) as pool, (output / "progress.log").open("a", buffering=1) as log:
        while pending or active:
            while len(active) < jobs:
                n = next((n for n in pending if all(d not in records or d in done for d in records[n]["imports"])), None)
                if n is None:
                    break
                pending.remove(n)
                active[pool.submit(compile_one, n)] = n
            if not active:
                raise RuntimeError("Dependency cycle")
            finished, _ = wait(active, return_when=FIRST_COMPLETED)
            for future in finished:
                n, seconds = future.result()
                del active[future]
                done.add(n)
                (stampdir / n).write_text(signatures[n])
                print(n, seconds, f"{len(done)}/{len(records)}", file=log)


def install_checked(output, records):
    """Install checked batches plus a forwarding import without modifying any original source."""
    dest = ROOT / ".lake/build/lib/lean"
    result = PREFIX + "Result"
    receipt = dest / "SubmodularMatchingReplayBatch" / "installed-result.json"
    if source_path(dest, result, ".olean").is_file() and not receipt.exists():
        print("Original compiled result already exists; leaving the project's installed objects in place.")
        return
    if not (output / "checked" / result).is_file():
        raise ValueError("The closed final result has not completed its kernel check")
    for n in records:
        path = source_path(output / "lib", n, ".olean")
        target = source_path(dest, n, ".olean")
        target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=target.parent) as tmp:
            staged = Path(tmp) / target.name
            try:
                os.link(path, staged)
            except OSError:
                shutil.copyfile(path, staged)
            os.replace(staged, target)
    receipt.write_text(json.dumps({"verbatim_result_source": records[result]["sha256"],
                                   "checked_stamp": (output / "checked" / result).read_text()}) + "\n")

MONOTONE_MODULES = ["SubmodularMatching.UpperBoundFixedK1Program",
                    "SubmodularMatching.CapacityMonotoneTheorem"]


def monotone_prerequisites():
    """Lake can prepare these imports without requesting the final numerical fragment."""
    modules = set()
    for name in MONOTONE_MODULES:
        path = source_path(ROOT, name, ".lean")
        imports = {line.split()[1] for line in path.read_text().splitlines() if line.startswith("import ")}
        modules.update(imports)
    return modules - set(MONOTONE_MODULES) - {PREFIX + "Result"}


def check_monotone(output):
    """Check the original theorem, its direct capacity corollary, and both axiom closures."""
    lean = shutil.which("lean")
    build = ROOT / ".lake/build/lib/lean"
    flags = [lean, "--root=" + str(ROOT), "-DrelaxedAutoImplicit=false", "-DmaxSynthPendingDepth=3"]
    for name in MONOTONE_MODULES:
        src = source_path(ROOT, name, ".lean")
        dest = source_path(build, name, ".olean")
        dest.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(flags + ["-o", str(dest), str(src)], cwd=ROOT, check=True)
    names = ["SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream.theorem1_1_real_verified",
             "SubmodularMatching.Capacity.theorem5_1_monotone",
             "SubmodularMatching.Capacity.theorem5_1_monotone_confidence"]
    with tempfile.TemporaryDirectory() as temp:
        audit = Path(temp) / "CapacityAudit.lean"
        audit.write_text("import " + MONOTONE_MODULES[-1] + "\n" +
                         "".join("#print axioms " + name + "\n" for name in names))
        out = subprocess.check_output(flags + [str(audit)], cwd=ROOT, text=True)
    reports = re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", out)
    if [entry[0] for entry in reports] != names or any(
        set(re.findall(r"[a-zA-Z.]+", axioms)) - {"propext", "Classical.choice", "Quot.sound"}
        for _, axioms in reports
    ):
        raise RuntimeError("Unexpected monotone axiom report: " + out)
    (output / "monotone-transfer-axioms.log").write_text(out)
    print(out, end="")



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--runner", help="Optional compiler process wrapper")
    parser.add_argument("--generate-only", action="store_true")
    parser.add_argument("--prepare", action="store_true", help="Build local external import prerequisites with Lake")
    parser.add_argument("--install", action="store_true", help="Install checked aggregates into the local project build")
    parser.add_argument("--check-monotone", action="store_true",
                        help="After the replay, install its checked result and verify the direct Theorem 1.1 to Theorem 5.1 transfer")
    args = parser.parse_args()
    if min(args.batch_size, args.jobs) < 1:
        parser.error("batch size and jobs must be positive")
    output = args.output.resolve()
    records = generate(output, args.batch_size)
    if not args.generate_only:
        if args.prepare:
            external = {d for r in records.values() for d in r["imports"] if d not in records}
            if args.check_monotone:
                external.update(monotone_prerequisites())
            external = sorted(external)
            subprocess.run(["lake", "build", *external], cwd=ROOT, check=True)
        compile_modules(output, records, args.jobs, args.runner)
        if args.install or args.check_monotone:
            install_checked(output, records)
        if args.check_monotone:
            check_monotone(output)
