#!/usr/bin/env python3
"""Fetch the Mathlib cache needed by this project's actual imports."""

import argparse
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--lake", default="lake")
args = parser.parse_args()
imports = set()
for path in (root / "SubmodularMatching").rglob("*.lean"):
    imports.update(re.findall(r"^import\s+(Mathlib(?:\.[\w]+)+)\s*$", path.read_text(), re.M))
print(f"Fetching cached dependencies for {len(imports)} Mathlib imports.", flush=True)
subprocess.run([args.lake, "exe", "cache", "get", *sorted(imports)], cwd=root, check=True)
