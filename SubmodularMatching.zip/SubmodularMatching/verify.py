#!/usr/bin/env python3
"""Rebuild local proofs and audit their transitive Lean axiom dependencies.

Run from this project: python3 verify.py
Optional: python3 verify.py --lake /absolute/path/to/lake
The source scan is a supplementary check; the Lean build and axiom output
are the actual verification evidence. External numerical checkers are separate.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
STANDARD_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}


def without_comments_and_strings(text: str) -> str:
    """Preserve lines while removing nested Lean block comments and strings."""
    out = []
    i, depth = 0, 0
    in_string = False
    while i < len(text):
        pair = text[i:i + 2]
        ch = text[i]
        if depth:
            if pair == "/-":
                depth += 1
                out.extend("  ")
                i += 2
            elif pair == "-/":
                depth -= 1
                out.extend("  ")
                i += 2
            else:
                out.append("\n" if ch == "\n" else " ")
                i += 1
        elif in_string:
            if ch == "\\" and i + 1 < len(text):
                out.extend("  ")
                i += 2
            else:
                if ch == '"':
                    in_string = False
                out.append("\n" if ch == "\n" else " ")
                i += 1
        elif pair == "/-":
            depth = 1
            out.extend("  ")
            i += 2
        elif pair == "--":
            end = text.find("\n", i)
            if end == -1:
                end = len(text)
            out.append(" " * (end - i))
            i = end
        elif ch == '"':
            in_string = True
            out.append(" ")
            i += 1
        else:
            out.append(ch)
            i += 1
    if depth or in_string:
        raise RuntimeError("Unterminated comment or string in source scan")
    return "".join(out)


def theorem_names(clean: str) -> list[str]:
    scopes: list[tuple[str, str]] = []
    names = []
    for line in clean.splitlines():
        s = line.strip()
        m = re.match(r"namespace\s+([\w.]+)\s*$", s)
        if m:
            scopes.append(("namespace", m.group(1)))
            continue
        if re.match(r"(?:noncomputable\s+)?section(?:\s+\w+)?\s*$", s):
            scopes.append(("section", ""))
            continue
        if re.match(r"end(?:\s+[\w.]+)?\s*$", s):
            if scopes:
                scopes.pop()
            continue
        m = re.match(r"(?:@\[[^\]]+\]\s*)?(?:protected\s+)?(?:theorem|lemma)\s+([\w'.]+)", s)
        if m:
            prefix = [name for kind, name in scopes if kind == "namespace"]
            names.append(".".join(prefix + [m.group(1)]))
    return names


def run(command: list[str], log: Path) -> str:
    print("Running:", " ".join(command), flush=True)
    proc = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT)
    log.write_text(proc.stdout)
    if proc.returncode:
        print(proc.stdout)
        raise RuntimeError(f"Command failed ({proc.returncode}); see {log.relative_to(ROOT)}")
    print(proc.stdout[-2500:] if len(proc.stdout) > 2500 else proc.stdout, end="", flush=True)
    return proc.stdout


def audit_declarations(lake: str, names: list[str], jobs: int, log: Path) -> str:
    """Use Lean's axiom command for every declaration, with optional parallel batches."""
    if jobs == 1:
        return run([lake, "env", "lean", "Audit.lean"], log)

    with tempfile.TemporaryDirectory(prefix="submodular-axioms-") as temporary:
        paths = []
        for index in range(min(jobs, len(names))):
            path = Path(temporary) / f"Audit{index}.lean"
            commands = "\n".join(f"#print axioms {name}" for name in names[index::jobs])
            path.write_text(f"import SubmodularMatching\n\n{commands}\n")
            paths.append(path)

        def check(path: Path) -> subprocess.CompletedProcess:
            return subprocess.run([lake, "env", "lean", str(path)], cwd=ROOT, text=True,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                  env={**os.environ, "LEAN_NUM_THREADS": "1"})

        print(f"Checking axioms in {len(paths)} parallel Lean processes.", flush=True)
        with ThreadPoolExecutor(max_workers=jobs) as pool:
            results = list(pool.map(check, paths))
    output = "".join(result.stdout for result in results)
    log.write_text(output)
    errors = [result.returncode for result in results if result.returncode]
    if errors:
        raise RuntimeError(f"Lean axiom checks failed with {errors}; see {log.relative_to(ROOT)}")
    print(output[-2500:], end="", flush=True)
    return output


def audit_axiom_union(lake: str, names: list[str], log: Path) -> str:
    """Use the same kernel dependency visitor as #print axioms, with one visited set."""
    header = """import SubmodularMatching
import Lean.Util.CollectAxioms

open Lean Elab Command

elab "#print_axiom_union" roots:ident+ : command => do
  let env ← getEnv
  let kernel := env.checked.get
  let names := roots.map (·.getId)
  for name in names do
    unless (kernel.find? name).isSome do
      throwError m!"Missing kernel declaration {name}"
  let (_, checked) := ((names.forM Lean.CollectAxioms.collect).run env).run {}
  logInfo m!"Audited {names.size} declarations"
  logInfo m!"'all declarations' depends on axioms: {checked.axioms.qsort Name.lt |>.toList}"

#print_axiom_union
"""
    with tempfile.TemporaryDirectory(prefix="submodular-axioms-") as temporary:
        path = Path(temporary) / "AuditUnion.lean"
        path.write_text(header + "".join(f"  {name}\n" for name in names))
        return run([lake, "env", "lean", str(path)], log)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lake", default="lake")
    parser.add_argument("--source-only", action="store_true")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--audit-jobs", type=int, default=1,
                      help="parallel Lean checks recording a list for each theorem (default: 1)")
    mode.add_argument("--batch-axioms", action="store_true",
                      help="check every theorem in one pass and report the union of dependencies")
    args = parser.parse_args()
    if args.audit_jobs < 1:
        parser.error("--audit-jobs must be positive")
    logs = ROOT / "verification"
    logs.mkdir(exist_ok=True)
    local = sorted((ROOT / "SubmodularMatching").rglob("*.lean"))
    files = [ROOT / "SubmodularMatching.lean", *local]
    graph, names, hashes = {}, [], {}
    forbidden = re.compile(r"\b(sorry|admit|axiom|native_decide|unsafe|implemented_by|extern)\b")
    for path in files:
        text = path.read_text()
        clean = without_comments_and_strings(text)
        bad = forbidden.search(clean)
        if bad:
            line = clean[:bad.start()].count("\n") + 1
            raise RuntimeError(f"Forbidden token {bad.group(1)} in {path.relative_to(ROOT)}:{line}")
        module = ".".join(path.relative_to(ROOT).with_suffix("").parts)
        graph[module] = re.findall(r"^import\s+(SubmodularMatching(?:\.[\w]+)*)\s*$", clean, re.M)
        names.extend(theorem_names(clean))
        hashes[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    reachable, todo = set(), ["SubmodularMatching"]
    while todo:
        name = todo.pop()
        if name in reachable:
            continue
        if name not in graph:
            raise RuntimeError(f"Missing local import: {name}")
        reachable.add(name)
        todo.extend(graph[name])
    missing = set(graph) - reachable
    if missing:
        raise RuntimeError(f"Local modules not imported by root: {sorted(missing)}")
    if len(names) != len(set(names)):
        raise RuntimeError("Duplicate parsed theorem names")
    names = sorted(names)
    print(f"Source scan: {len(local)} library modules, {len(names)} theorem/lemma declarations; no forbidden tokens.")
    if args.source_only:
        print("SOURCE SCAN ONLY: no compilation or proof verification claimed.")
        return 0
    run([args.lake, "build"], logs / "build.log")
    version = run([args.lake, "env", "lean", "--version"], logs / "toolchain.log").strip()
    expected = (ROOT / "lean-toolchain").read_text().strip().split(":")[-1].lstrip("v")
    if not version.startswith("Lean (version " + expected + ","):
        raise RuntimeError(f"Unexpected compiler: {version}")
    audit = "import SubmodularMatching\n\n" + "\n".join(f"#print axioms {name}" for name in names) + "\n"
    (ROOT / "Audit.lean").write_text(audit)
    axioms = {}
    pattern = r"'([^']+)'\s+depends on axioms:\s*\[([^\]]*)\]"
    if args.batch_axioms:
        output = audit_axiom_union(args.lake, names, logs / "axioms.log")
        union_match = re.search(pattern, output)
        if (not union_match or union_match[1] != "all declarations"
                or f"Audited {len(names)} declarations" not in output):
            raise RuntimeError("No complete axiom-union audit result parsed")
        union = {part.strip() for part in union_match[2].split(",") if part.strip()}
        if extra := union - STANDARD_AXIOMS:
            raise RuntimeError(f"Nonstandard axiom dependencies: {sorted(extra)}")
    else:
        output = audit_declarations(args.lake, names, args.audit_jobs, logs / "axioms.log")
        for name, deps in re.findall(pattern, output):
            axioms[name] = [part.strip() for part in deps.split(",") if part.strip()]
        for name in re.findall(r"'([^']+)'\s+does not depend on any axioms", output):
            axioms[name] = []
        for name in names:
            if name not in axioms:
                raise RuntimeError(f"No audit result parsed for {name}")
            if extra := set(axioms[name]) - STANDARD_AXIOMS:
                raise RuntimeError(f"Nonstandard axiom dependencies for {name}: {sorted(extra)}")
        union = {axiom for dependencies in axioms.values() for axiom in dependencies}
    for relative, expected_hash in hashes.items():
        if hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() != expected_hash:
            raise RuntimeError(f"Source changed during verification: {relative}; rerun after editing stops")
    manifest = json.loads((ROOT / "lake-manifest.json").read_text())
    dependency_revisions = {}
    for pkg in manifest["packages"]:
        directory = ROOT / ".lake" / "packages" / pkg["name"]
        proc = subprocess.run(["git", "-C", str(directory), "rev-parse", "HEAD"],
                              text=True, capture_output=True)
        actual = proc.stdout.strip()
        if proc.returncode or actual != pkg["rev"]:
            raise RuntimeError(f"Dependency revision mismatch: {pkg['name']}")
        dependency_revisions[pkg["name"]] = actual
    result = {
        "checked_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "result": "PASS", "compiler": version,
        "local_library_modules": len(local), "audited_theorems": len(names),
        "allowed_axioms": sorted(STANDARD_AXIOMS),
        "axiom_audit_mode": "union" if args.batch_axioms else "per_declaration",
        "axioms_union": sorted(union),
        "dependency_revisions": dependency_revisions, "source_sha256": hashes,
        "scope": (
            "Default kernel library. The upper bound instantiates the sparse real value-oracle program "
            "using the complete Appendix L price certificate. "
            "The lower bound includes blueprint existence. Appendix K includes the generic finite "
            "implementation and resource proofs."
        ),
    }
    if args.batch_axioms:
        result["audited_declarations"] = names
    else:
        result["axioms_by_theorem"] = axioms
    (logs / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"PASS: all {len(names)} theorem/lemma declarations compiled and axiom-audited.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (RuntimeError, OSError) as error:
        print(f"VERIFICATION FAILED: {error}", file=sys.stderr)
        sys.exit(1)
