"""Exact general-graph finite-factor and amplification arithmetic.

The source parameter file must separately pass check_joint_source_exact.py.
This script verifies the operational horizon, rounding parameters, basic or
archive-portfolio coefficient, and a positive high-probability grid margin.
No graph instances or floating-point decisions are used.
"""

import argparse
from fractions import Fraction as Q
import hashlib
import json
from math import factorial
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('parameters', type=Path)
    parser.add_argument('--target', required=True)
    parser.add_argument('--hp-factor')
    parser.add_argument('--rounding-r', default='0.51')
    parser.add_argument('--rounding-error', default='1e-6')
    parser.add_argument('--finite-error', default='1e-8')
    parser.add_argument('--b')
    parser.add_argument('--portfolio', action='store_true')
    parser.add_argument('--archive-k', type=int, default=1000)
    parser.add_argument('--archive-error', default='1e-6')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    raw = args.parameters.read_bytes()
    data = json.loads(raw)
    sigma, horizon = Q(data['sigma']), Q(data['source_horizon'])
    p = Q(data.get('p', '1e-36'))
    A, B = list(map(Q, data['A'])), list(map(Q, data['B']))
    r, epsilon_R = Q(args.rounding_r), Q(args.rounding_error)
    epsilon_0 = Q(args.finite_error)
    require(Q(1, 2) < r < 1, 'the finite Shearer sampler needs 1/2<r<1')
    D = r * (1 - r)
    require(0 < D <= horizon <= Q(1, 4), 'operational/source horizons disagree')
    require(0 < epsilon_R < 1 and 0 < epsilon_0 < Q(1, 4),
            'invalid error parameters')
    require((2 / epsilon_0).denominator == 1,
            'the best singleton must be a final comparison-grid point')
    cap = (epsilon_R / 2) ** 5 / 5120
    require(0 < p <= min(Q(1), cap), 'coordinate cap is too large')
    growth = min(min(A), 2 * min(B))
    require(0 < growth * p <= 1, 'source incidence-growth condition fails')
    exp_lower = sum(((-1) ** (j + 1) * D ** j / factorial(j)
                     for j in range(1, 25)), Q(0))
    b = Q(args.b) if args.b else Q((exp_lower * 10 ** 12).__floor__(), 10 ** 12)
    require(0 < b < exp_lower, 'b must be strictly below the exponential lower bound')
    theta = 1 - epsilon_R
    epsilon_A = epsilon_R / 4
    general_mean_excess = p * D ** 2 / (1 - D)
    general_variance_bound = p * D * (2 - D) * (1 + general_mean_excess) / (1 - D)
    require(epsilon_A > general_mean_excess, 'row tolerance must exceed the general-graph mean excess')
    general_loss = 2 * general_variance_bound / ((1 - 2 * D) * (epsilon_A - general_mean_excess) ** 2)
    kappa_A = (1 - general_loss) / (1 + epsilon_A)
    theta_G = 1 - epsilon_R / 2
    require(theta_G * kappa_A >= theta, 'total rounding coefficient is too small')
    gamma = None
    if args.portfolio:
        epsilon_b = Q(args.archive_error)
        require(args.archive_k >= 1 and 0 < epsilon_b < 1, 'invalid archive parameters')
        require(sigma > b, 'the stronger-source portfolio requires sigma>b')
        gamma = 1 / (2 + Q(1, args.archive_k) + epsilon_b / 4)
        coefficient = gamma * theta * sigma / (gamma + theta * (sigma - b))
        additive = 200 * epsilon_0
    else:
        coefficient = theta * min(sigma, b)
        additive = 100 * epsilon_0
    require(1 / coefficient <= 10, 'wrapper inverse-coefficient assumption fails')
    conditional_factor = 1 / coefficient + additive
    expected_factor = conditional_factor / (1 - epsilon_0)
    target = Q(args.target)
    hp_factor = Q(args.hp_factor) if args.hp_factor else (expected_factor + target) / 2
    require(1 < expected_factor < hp_factor < target,
            'expected, intermediate and target factors are not strictly ordered')
    success = (hp_factor - expected_factor) / (expected_factor * (hp_factor - 1))
    repetitions = (1 / success).__ceil__()
    margin = 1 / hp_factor - epsilon_0 / 2 - 1 / target
    require(margin > 0, 'final comparison-grid margin is not positive')
    report = {
        'status': 'PASS', 'parameter_sha256': hashlib.sha256(raw).hexdigest(),
        'source_sigma': str(sigma), 'source_horizon': str(horizon),
        'operational_r': str(r), 'operational_D': str(D),
        'b': str(b), 'b_taylor_margin': str(exp_lower - b),
        'p': str(p), 'coordinate_cap_margin': str(cap - p),
        'source_growth_product': str(growth * p),
        'rounding_error': str(epsilon_R), 'finite_error': str(epsilon_0),
        'theta': str(theta), 'actual_rounding_margin': str(theta_G * kappa_A - theta),
        'general_mean_excess': str(general_mean_excess),
        'general_variance_bound': str(general_variance_bound),
        'general_completion_coefficient': str(kappa_A),
        'portfolio': args.portfolio, 'archive_gamma': str(gamma) if gamma else None,
        'conditional_coefficient': str(coefficient),
        'conditional_factor': str(conditional_factor),
        'expected_factor': str(expected_factor),
        'expected_factor_display_only': float(expected_factor),
        'hp_factor': str(hp_factor), 'target_factor': str(target),
        'trial_success_lower_bound': str(success),
        'repetitions_per_log_confidence': repetitions,
        'final_grid_margin': str(margin),
        'scope': 'Exact finite-factor arithmetic; source inequalities require their separate certificate.'}
    if args.output:
        args.output.write_text(json.dumps(report, indent=2) + '\n')
    summary = {key: report[key] for key in (
        'status', 'parameter_sha256', 'portfolio', 'expected_factor',
        'expected_factor_display_only', 'hp_factor', 'target_factor',
        'repetitions_per_log_confidence', 'final_grid_margin')}
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
