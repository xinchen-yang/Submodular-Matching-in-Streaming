# Numerical certificate provenance and verification boundary

The eight original payloads in this directory were recovered from the supplied
`submodular_matching.tex`. Every recovered payload was checked against the SHA-256
digest in its `BEGIN_FILE` marker. The names, digests, and byte counts are in
`payload_manifest.json`.

The paper source used for extraction has SHA-256
`58e39a3c84996550342f25847b78718fef4216165c55a9e6fcd1a890dc05a1fb`.
The parameter JSON has SHA-256
`338f62f4ba1c0fcb0edb8841e56d2e2cb3e0da4e137c8e8ed70ad787551c7970`.

## Lean proofs

`SubmodularMatching/NumericalCertificate.lean` proves exact scalar parameter
bounds, the degree identity, the coordinate cap, the general-graph rounding
coefficient arithmetic, the finite factor below 4.524656, and the probability
and final-grid margins. It also proves `beta < 1 - exp(-degree)` using a
13-term positive Taylor lower bound on `exp(degree)` from Mathlib. The proofs
use exact arithmetic and ordinary Lean proof terms.

The current project additionally proves the abstract source analysis in
`SourceLocal`, `SourcePotential`, `SourceSegments`, `SourcePath`, and `SourceRun`.
In particular, `SourceCertificate.main_run_bound_ideal` applies the source inequality
to the actual sorted, rounded streaming updates and the stored comparator LP.
`SourceDataActual` constructs the source functions and configurations from
the concrete arrays. The kernel checks all 27,648 fixed-point rate rows and
both improper integrals over the full 1,136-knot table. `NumericalReplayIntegral`
certifies those integrals with rational upper bounds
`999999952548740/1000000000000000` and
`996493758737123/1000000000000000`. These use a separate conservative
logarithm enclosure from the original GMP checker.

`NumericalReplayLastRows` checks all four coverage classes at the terminal
ratio-one grid, including the archived exact minimum-slack witness.
`NumericalReplayLastEndpoint` extends those checks to the local inequalities
for every pair of nonnegative real prices.
The default project proves the complete price-box inequalities for the
three classes with a covered endpoint. It also proves both tails and the
first 324 and last 216 modes of the two-uncovered class. The checked wrapper
`appendixSourceObligation_of_nextBand` leaves modes 324 through
27,431 of that class as its single price-box hypothesis.

## External exact checks

`finite_constants_rechecked.json` records a fresh run of the supplied
`check_general_finite_constants.py`. This is distinct from the original saved
`finite_constants.json`.

`array_structure_rechecked.json` records a fresh exact rational check of rate
positivity, rate ordering, all source-direction conditions, and boundary
ordering. Reproduce it with:

```sh
python3 certificate/check_array_structure.py
```

The full GMP checker can be reproduced from this directory with:

```sh
python3 run_exact_source.py source_parameters.json --prefix rechecked --workers 4
```

`rechecked_certificate.json` records a fresh complete run, completed successfully
in 537.84 seconds. Its four disjoint interval ranges cover all 27,648 modes.
The run checked 368,163,240 separation points, covered 46,483,643,836 grid pairs,
and checked 110,592 zero-price cases. It also recomputed both integral upper
bounds. The numerical fields, minimum-slack witness, and input digests all agree
with the embedded `source_certificate.json`; see `recheck_comparison.json`.

The complete execution of these GMP checks is an independent arithmetic
verification. Lean also proves the price-box checker sound and verifies the
analytic reduction from accepted boxes to the source inequalities.

The C++ checker requires a C++17 compiler and GMP development libraries. Its
generated binary and exported temporary input are not needed in the source
archive; they are recreated by the runner.

## Lean executable check of selected modes

After building the project, run the following from its root.

```sh
lake env lean --run certificate/CheckSourceSlice.lean 0 27647
```

The mode indices are zero-based. Each selected mode exercises all eight
combinations of its two ratio endpoints and four endpoint-capacity classes.
Mode 27647 includes the archived minimum-slack witness and ratio one. Every
run also computes both integral upper bounds from the full 1,136-knot table.
The observed upper bounds were
`999999950956391491/1000000000000000000` and
`990582544907118101/1000000000000000000`, matching the saved GMP results.

This command evaluates the certified arithmetic functions on the JSON at
runtime. The kernel proofs described above check the concrete parameters
and integrals through separate Lean declarations.

## Exact price-box replay

`price_partition.bin` covers both endpoints of every source rate interval for
all four covered/uncovered classes. The boxes divide the endpoint indices
and the two price axes. A leaf selects a nonnegative multiplier bounded by
the coefficient of the positive-part term. The indicated two support cones
give lower bounds for the resulting separate, affine-price objectives. The
source functions have constant tails beyond the last knot.

From the project root, run either of the complete checks.

```sh
python3 certificate/check_price_partition.py
lake env lean --run certificate/CheckPricePartition.lean
```

The Python checker reads the source JSON and independently recomputes the
rate extrema, both supports, the integer inequality on every leaf, and
the two tail bounds. The Lean program uses the exact same box predicate
as the individually kernel-checked partition proofs. It checks the embedded
cone table against the project literals and runs all four partitions.
The SHA-256 of the packed witness is `2f361f26d4c9849af603a9e482bd9fc745ba8e20ec22ad7a89c6359ffc734d74`.
Successful execution of this program is separate from a Lean theorem about
the complete partition.

| Coverage class | Endpoint indices | Accepted leaves |
| --- | ---: | ---: |
| Both uncovered | 55,296 | 354,153 |
| First uncovered, second covered | 55,296 | 97 |
| First covered, second uncovered | 55,296 | 62 |
| Both covered | 55,296 | 8 |

Both replays passed all 354,320 leaves and all 3,302 cones in this checkpoint.
The binary starts with `SMBOX1`, a little-endian 16-bit cone count, and its
cone entries. Each entry contains one coverage byte followed by five
little-endian 16-bit knot indices for its interval, contact knot and two
neighbors. Four trees follow in the order shown above. In preorder, one
byte marks a mode split (0), first-price split (1), second-price split (2),
or leaf (3). A leaf carries eight little-endian bytes with its first and
second cone identifiers in the lowest two 12-bit fields, and its multiplier
numerator in the upper 40 bits.

## Formal theorem using Lean's compiler

Run the following from the built project root.

```sh
lake env lean certificate/NativePricePartition.lean
```

The theorem `SubmodularMatching.OptionalPriceCertificate.completePricePartition`
covers all four coverage classes, both endpoints of all 27,648 source intervals,
and every pair of real prices in the root box. Its `sourceConditions` corollary
includes all nonnegative prices and both integral budgets. The `native_decide`
tactic evaluates the 354,153-leaf two-uncovered class. The three other classes,
all cone-support proofs, the exact source rows, and the checker soundness are
proved in the default library. The optional theorem's axiom report contains
`propext`, `Classical.choice`, `Quot.sound`, `Lean.ofReduceBool`, and
`Lean.trustCompiler`. The same file checks
`theorem1_1_verified`, `theorem1_1_confidence_verified`, and
`approximationFamily_corollary_verified` with that source theorem.

## Standard-kernel replay

The default build imports the generated middle-range proof in
`SubmodularMatching/ReplayUncoveredMiddle/`. The 348,985 checked rectangles
cover endpoint indices 648 through 54,863. Every leaf uses natural-number
comparisons of exact scaled inequalities. The shared source-row and cone
proofs justify the parameters used by those inequalities. Ordinary Lean
proofs join the leaves into `Replay.UncoveredMiddle.checked`, then combine
that box with the certified margins and the other three coverage classes.

The generated sources are included. From the project root, check them with
the following command.

```sh
lake build SubmodularMatching.ReplayUncoveredMiddle.Result
```

To regenerate the middle-range modules from the pinned input, choose a
fresh destination and run the following command.

```sh
python3 certificate/generate_kernel_partition.py \
  --endpoints 648 54863 --proof-limit 28 --module-limit 512 \
  --memoize --shared-rows --nat-memo \
  --module-root SubmodularMatching.ReplayUncoveredMiddle \
  --namespace SubmodularMatching.SourceCertificate.Replay.UncoveredMiddle \
  --out /tmp/submodular-matching-price
```

This emits 1,735 modules. Their source matches the corresponding directory
in the project. The shared row proofs in `SubmodularMatching/ReplayMemoRows/`
are available to both the shipped replay and the generator.
