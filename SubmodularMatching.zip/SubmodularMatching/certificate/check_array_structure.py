"""Exact structural checks on the embedded rate arrays (external to Lean)."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

base = Path(__file__).resolve().parent
source = base / "source_parameters.json"
data = json.loads(source.read_text())
A = list(map(F, data["A"]))
B = list(map(F, data["B"]))
c = list(map(F, data["boundaries"]))
assert len(A) == len(B) == 27648
assert len(c) == len(A) + 1
assert A[0] == B[0]
assert all(b > 0 and a >= b for a, b in zip(A, B))
assert all(A[j] < c[j] * (A[j] + B[j]) for j in range(1, len(A)))
assert all(x < y for x, y in zip(c, c[1:]))
assert c[0] == F(1, 2) and c[-1] == 1
report = {
    "rate_count": len(A),
    "boundary_count": len(c),
    "positive_rates": True,
    "initial_equal": True,
    "SP0_all_intervals": True,
    "increasing_boundaries": True,
    "first_boundary": str(c[0]),
    "last_boundary": str(c[-1]),
    "rate_sum_max": str(max(a + b for a, b in zip(A, B))),
    "parameter_sha256": sha256(source.read_bytes()).hexdigest(),
    "scope": "External Python exact Fraction checks; not Lean proofs of the full array or local/integral inequalities.",
}
(base / "array_structure_rechecked.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
