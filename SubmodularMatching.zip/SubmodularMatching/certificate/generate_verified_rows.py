#!/usr/bin/env python3
"""Generate cacheable Lean proofs of each literal source rate lookup."""
from __future__ import annotations

import argparse
import re
from pathlib import Path

NAMESPACE = "SubmodularMatching.SourceCertificate.Replay"
ROWS_PER_BLOCK = 512
ROWS_PER_WORD = 16
ROW_FIELD_WIDTH = 42
ROW_WIDTH = ROW_FIELD_WIDTH * 3
TABLE_ROWS = 27648
END_BOUNDARY = 10**12


def source_rows(project: Path) -> list[tuple[int, int, int]]:
    rows = []
    for index in range(3):
        data = (project / "SubmodularMatching" / f"SourceDataRateLiteral{index}.lean").read_text()
        rows.extend(tuple(map(int, m)) for m in re.findall(r"⟨(\d+), (\d+), (\d+)⟩", data))
    if len(rows) != TABLE_ROWS:
        raise ValueError(f"Expected {TABLE_ROWS:,} rows, found {len(rows):,}")
    rows.append((0, 0, END_BOUNDARY))
    return rows


def packed_word(rows: list[tuple[int, int, int]]) -> int:
    word = 0
    for index, (high, low, boundary) in enumerate(rows):
        packed_row = high | (low << ROW_FIELD_WIDTH) | (boundary << (2 * ROW_FIELD_WIDTH))
        word |= packed_row << (ROW_WIDTH * index)
    return word


def block_name(row_index: int) -> str:
    return f"Block{row_index // ROWS_PER_BLOCK:02d}"


def row_name(row_index: int) -> str:
    return f"rawRow{row_index:05d}"


def render_block(rows: list[tuple[int, int, int]], start: int) -> str:
    lines = ["import SubmodularMatching.ReplayMemoRawRow", "", f"namespace {NAMESPACE}", "",
             "set_option maxRecDepth 5000", "set_option maxHeartbeats 10000000", ""]
    for first in range(start, min(start + ROWS_PER_BLOCK, len(rows)), ROWS_PER_WORD):
        part = rows[first:first+ROWS_PER_WORD]
        word_index = first // ROWS_PER_WORD
        word_name = f"rateWordData{word_index:04d}"
        lookup_name = f"rateWordLookup{word_index:04d}"
        lines.append(f"private def {word_name} : Nat := {packed_word(part):#x}")
        lines.append(f"private theorem {lookup_name} : rateWord {word_index} = {word_name} := rfl")
        lines.append("")
        for offset, (a, b, c) in enumerate(part):
            index = first + offset
            lines.append(f"def {row_name(index)} : VerifiedRawRow {index} :=")
            lines.append(f"  VerifiedRawRow.ofWord {index} {word_name} ⟨{a}, {b}, {c}⟩ {lookup_name} rfl")
        lines.append("")
    return "\n".join(lines + [f"end {NAMESPACE}", ""])


def generate(project: Path, output: Path) -> list[Path]:
    rows = source_rows(project)
    output.mkdir(parents=True, exist_ok=True)
    files = []
    for index in range(0, len(rows), ROWS_PER_BLOCK):
        p = output / f"{block_name(index)}.lean"
        contents = render_block(rows, index)
        if not p.exists() or p.read_text() != contents:
            p.write_text(contents)
        files.append(p)
    return files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    files = generate(args.project, args.out)
    print(f"Generated {len(files)} Lean modules for {TABLE_ROWS+1:,} source rows")


if __name__ == "__main__":
    main()
