"""Run disjoint exact mode checks and certify their complete range coverage."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import argparse, json, subprocess, sys, time

HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('parameters',type=Path)
p.add_argument('--prefix',required=True)
p.add_argument('--workers',type=int,default=4)
args=p.parse_args()
source=json.loads(args.parameters.read_text());k=len(source['A'])
data=HERE/f'{args.prefix}_input.txt'
subprocess.run([sys.executable,str(HERE/'export_exact_source.py'),
                str(args.parameters),str(data)],check=True)
boundaries=[k*j//args.workers for j in range(args.workers+1)]
started=time.monotonic()
checker_source=HERE/'exact_source_checker.cpp'
checker_hash=sha256(checker_source.read_bytes()).hexdigest()
binary=HERE/f'{args.prefix}_checker.bin'
compile_command=['g++','-O3','-std=c++17',str(checker_source),'-lgmpxx','-lgmp','-o',str(binary)]
subprocess.run(compile_command,check=True)
assert sha256(checker_source.read_bytes()).hexdigest()==checker_hash
compiler_version=subprocess.check_output(['g++','--version'],text=True).splitlines()[0]
def check(part):
    output=HERE/f'{args.prefix}_part{part}.json'
    with (HERE/f'{args.prefix}_part{part}.log').open('w') as log:
        subprocess.run([str(binary),str(data),str(output),
                        str(boundaries[part]),str(boundaries[part+1])],
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    value=json.loads(output.read_text())
    assert value['mode_range']==boundaries[part:part+2]
    print(json.dumps({'part':part,'status':value['status'],
                      'range':value['mode_range']}),flush=True)
    return part,value
with ThreadPoolExecutor(max_workers=args.workers) as pool:
    results=dict(f.result() for f in as_completed([pool.submit(check,j) for j in range(args.workers)]))
parts=[results[j] for j in range(args.workers)]
assert boundaries[0]==0 and boundaries[-1]==k
assert all(a<b for a,b in zip(boundaries,boundaries[1:]))
assert all(v['sigma']==source['sigma'] and v['source_horizon']==source['source_horizon'] for v in parts)
assert all(v['integral_uppers']==parts[0]['integral_uppers'] for v in parts)
result=dict(parts[0]);result['mode_range']=[0,k]
result['status']='PASS: complete exact rational four-class source certificate'
result['parameter_sha256']=sha256(args.parameters.read_bytes()).hexdigest()
result['source_reciprocal']=source['source_reciprocal']
result['checker_sha256']=checker_hash
result['checker_binary_sha256']=sha256(binary.read_bytes()).hexdigest()
result['compiler_version']=compiler_version
result['compile_command']=compile_command
result['exported_input_sha256']=sha256(data.read_bytes()).hexdigest()
for key in ('evaluated_separation_points','interior_grid_pairs_covered','zero_price_checks'):
    result[key]=sum(v[key] for v in parts)
least=min(parts,key=lambda v:Fraction(v['minimum_slack']))
result['minimum_slack']=least['minimum_slack']
result['minimum_slack_witness']=least['minimum_slack_witness']
result['integral_upper']=str(max(map(Fraction,result['integral_uppers'])))
result['partition_certificates']=[{
    'file':f'{args.prefix}_part{j}.json',
    'sha256':sha256((HERE/f'{args.prefix}_part{j}.json').read_bytes()).hexdigest(),
    'mode_range':v['mode_range']} for j,v in enumerate(parts)]
result['elapsed_seconds']=time.monotonic()-started
result['scope']='Universal affine-cell and kink-boundary verification; no finite graph search is used.'
(HERE/f'{args.prefix}_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
