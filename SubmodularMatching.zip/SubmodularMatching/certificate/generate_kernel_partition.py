"""Generate ordinary Lean kernel checks of the complete two-uncovered price certificate.

Use `lake env python3 certificate/generate_kernel_partition.py --out DIR --build`
from a built project. Use --endpoints FIRST LAST to check just that inclusive
interval of endpoint indices, or --sample to build one subtree as a smoke test.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
from struct import unpack_from
from time import monotonic

BINARY = Path(__file__).with_name("price_partition.bin")
SHA256 = "2f361f26d4c9849af603a9e482bd9fc745ba8e20ec22ad7a89c6359ffc734d74"
ROOT = (0, 55295, 0, 1135, 0, 1135)
NAMESPACE = "SubmodularMatching.SourceCertificate.Replay.GeneratedKernelPrice"
MODULE_ROOT = "GeneratedPrice"
PROOF_LIMIT = 28
MODULE_LIMIT = 160
GROUP_SIZE = 16
LITERAL_MODULE_SIZE = 192
MEMO_IMPORT = "SubmodularMatching.ReplayMemo"
NAT_MEMO_IMPORT = "SubmodularMatching.ReplayMemoNat"
RATE_IMPORT = "SubmodularMatching.ReplayRateLookup"
CONE_IMPORT = "SubmodularMatching.CertificateHullConeData"
RUN_IMPORT = "SubmodularMatching.ReplayMemoRun"
ROW_MODULE = "SubmodularMatching.ReplayMemoRows.Block"
RATE_RUN_ENDS = (0, 118, 128, 7700, 11261, 11266, 27104, 27166, 27188, 27483, 27487, 27647)


@dataclass(slots=True)
class Node:
    op: int
    count: int
    box: tuple[int, ...]
    word: int = 0
    left: Node | None = None
    right: Node | None = None
    middle: int | None = None
    midpoint_subtree: bool = True


def join_node(op, box, middle, left, right):
    axis = 2 * op
    midpoint_subtree = (middle == (box[axis] + box[axis + 1]) // 2
                        and left.midpoint_subtree and right.midpoint_subtree)
    return Node(op, left.count + right.count, box, left=left, right=right,
                middle=middle, midpoint_subtree=midpoint_subtree)


def read_hard_class():
    data = BINARY.read_bytes()
    if hashlib.sha256(data).hexdigest() != SHA256 or data[:6] != b"SMBOX1":
        raise ValueError("Unexpected price partition witness")
    position = 8 + 11 * unpack_from("<H", data, 6)[0]

    def read(box):
        nonlocal position
        op = data[position]
        position += 1
        if op == 3:
            word = unpack_from("<Q", data, position)[0]
            position += 8
            region = box[0] + 65536 * box[1]
            return Node(op, 1, box, word | region << 64)
        if op > 2:
            raise ValueError(f"Invalid split at byte {position - 1}")
        axis = 2 * op
        middle = (box[axis] + box[axis + 1]) // 2
        lhs, rhs = list(box), list(box)
        lhs[axis + 1] = middle
        rhs[axis] = middle + (op == 0)
        left, right = read(tuple(lhs)), read(tuple(rhs))
        return join_node(op, box, middle, left, right)

    root = read(ROOT)
    if root.count != 354153:
        raise ValueError("Unexpected number of uncovered-class leaves")
    return root


def restrict_endpoints(node, first, last):
    lo, hi, *prices = node.box
    if hi < first or last < lo:
        return None
    if first <= lo and hi <= last:
        return node

    box = (max(first, lo), min(last, hi), *prices)
    if node.op == 3:
        # The packed word keeps the original wider interval for rate bounds.
        return Node(node.op, 1, box, word=node.word)
    left = restrict_endpoints(node.left, first, last)
    right = restrict_endpoints(node.right, first, last)
    if left is None:
        return right
    if right is None:
        return left
    return join_node(node.op, box, node.middle, left, right)


def leaf_fields(word):
    return word >> 64, word & 4095, (word >> 12) & 4095, (word >> 24) & ((1 << 40) - 1)


def tree_term(node, memoize=False):
    if node.op == 3:
        if memoize:
            region, x, y, multiplier = leaf_fields(node.word)
            return f"(.leaf ⟨region{region}, cone{x}, cone{y}, {multiplier}⟩)"
        return f"(.leaf {node.word:#x})"
    term = (".m", ".x", ".y")[node.op]
    return f"({term} {tree_term(node.left, memoize)} {tree_term(node.right, memoize)})"


def box_term(node):
    return "⟨" + ", ".join(map(str, node.box)) + "⟩"


def leaves(node):
    if node.op == 3:
        yield node
    else:
        yield from leaves(node.left)
        yield from leaves(node.right)


def literal_ids(chunks):
    regions, cones = set(), set()
    for chunk in chunks:
        for leaf in leaves(chunk):
            region, x, y, _ = leaf_fields(leaf.word)
            regions.add(region)
            cones.update((x, y))
    return regions, cones


def single_run_conditions(identifier):
    lo, hi = identifier % 65536, min(ROOT[1], identifier // 65536)
    runs = zip(RATE_RUN_ENDS, RATE_RUN_ENDS[1:])
    for index, (first, last) in enumerate(runs):
        if first <= lo // 2 <= hi // 2 <= last:
            return lo, hi, index, (lo // 2, hi // 2, (lo + 1) // 2, (hi + 1) // 2)
    return None


class LiteralData:
    """Reconstruct data that Lean individually identifies with the source tables."""

    def __init__(self):
        source = json.loads(BINARY.with_name("source_parameters.json").read_text())

        def scaled(key):
            values = [Fraction(x) * 10**12 for x in source[key]]
            if any(x.denominator != 1 for x in values):
                raise ValueError(f"Nonintegral source value after scaling in {key}")
            return [x.numerator for x in values]

        self.high, self.low, self.boundary = map(scaled, ("A", "B", "boundaries"))
        knots = scaled("grid")
        heights = [scaled("H_uncovered"), scaled("H_covered")]
        data = BINARY.read_bytes()
        count, = unpack_from("<H", data, 6)
        self.cones = []
        for index in range(count):
            covered, lo, hi, knot, prev, after = unpack_from("<B5H", data, 8 + 11 * index)
            height = heights[covered]
            coords = (knots[knot] - knots[prev], height[knot] - height[prev],
                      knots[after] - knots[knot], height[after] - height[knot],
                      knots[knot], height[knot])
            bounds = ", ".join(map(str, (lo, hi, knot, prev, after)))
            data_args = ", ".join(map(str, coords))
            self.cones.append(f"⟨{str(bool(covered)).lower()}, ⟨{bounds}⟩, ⟨{data_args}⟩⟩")

    @lru_cache(None)
    def region(self, identifier):
        lo, hi = identifier % 65536, min(ROOT[1], identifier // 65536)
        high = self.high[lo // 2:hi // 2 + 1]
        low = self.low[lo // 2:hi // 2 + 1]
        coefficients = (min(high), max(high), min(low), max(low),
                        self.boundary[(lo + 1) // 2], self.boundary[(hi + 1) // 2])
        return f"⟨{lo}, {hi}, ⟨{', '.join(map(str, coefficients))}⟩⟩"

    def region_declarations(self, regions, use_shared_rows):
        for identifier in regions:
            header = f"def region{identifier} : VerifiedRegion :=\n"
            single = single_run_conditions(identifier) if use_shared_rows else None
            if single is None:
                yield (header + f"  VerifiedRegion.ofLiteral {identifier} {self.region(identifier)}\n"
                       "    (fun z _ => runRegion_valid quickRow quickRow_eq quickRow_boundary z) (by decide) (by rfl)\n")
            else:
                lo, hi, run, rows = single
                row_refs = " ".join(f"rawRow{k:05d}" for k in rows)
                yield (header + f"  VerifiedRegion.ofRunRowsLiteral {lo} {hi} {run} {self.region(identifier)}\n"
                       f"    (by decide) (by decide) (by decide) {row_refs} (by rfl)\n")

    def cone_declarations(self, cones):
        return (
            f"def cone{i} : VerifiedCone :=\n"
            f"  VerifiedCone.ofLiteral {i} {self.cones[i]} appendixFastConeAt_sufficient (by decide) (by rfl)\n"
            for i in cones
        )


def write_if_changed(path, contents):
    if not path.exists() or path.read_text() != contents:
        path.write_text(contents)


class Generator:
    def __init__(self, out, module_root, namespace, proof_limit, module_limit, memoize,
                 use_shared_rows, use_nat_checks):
        self.out = out
        self.module_root = module_root
        self.namespace = namespace
        self.proof_limit = proof_limit
        self.module_limit = module_limit
        self.literals = LiteralData() if memoize else None
        self.use_shared_rows = use_shared_rows
        self.use_nat_checks = use_nat_checks
        self.rate_modules = {}
        self.cone_modules = {}
        self.files = []
        self.counter = 0

    def write_module(self, name, deps, imports, body):
        head = "".join(f"import {module}\n" for module in imports)
        head += "".join(f"import {self.module_root}.{module}\n" for module in deps)
        header = (f"\nnamespace {self.namespace}\n\nset_option maxRecDepth 5000\n"
                  "set_option maxHeartbeats 10000000\n\n")
        write_if_changed(self.out / f"{name}.lean", head + header + body + f"\nend {self.namespace}\n")
        self.files.append((name, deps))

    def write_literal_modules(self, root):
        regions, cones = literal_ids([root])
        region_ids = sorted(regions)
        for start in range(0, len(region_ids), LITERAL_MODULE_SIZE):
            ids = region_ids[start:start + LITERAL_MODULE_SIZE]
            name = f"Rates{start // LITERAL_MODULE_SIZE:04}"
            imports = [MEMO_IMPORT, RATE_IMPORT]
            if self.use_shared_rows:
                row_blocks = set()
                for identifier in ids:
                    result = single_run_conditions(identifier)
                    if result is not None:
                        row_blocks.update(k // 512 for k in result[3])
                imports += [RUN_IMPORT, *(f"{ROW_MODULE}{k:02d}" for k in sorted(row_blocks))]
            self.rate_modules.update((i, name) for i in ids)
            self.write_module(name, [], imports,
                              "\n".join(self.literals.region_declarations(ids, self.use_shared_rows)))

        cone_ids = sorted(cones)
        for start in range(0, len(cone_ids), LITERAL_MODULE_SIZE):
            ids = cone_ids[start:start + LITERAL_MODULE_SIZE]
            name = f"Cones{start // LITERAL_MODULE_SIZE:04}"
            self.cone_modules.update((i, name) for i in ids)
            self.write_module(name, [], [MEMO_IMPORT, CONE_IMPORT],
                              "\n".join(self.literals.cone_declarations(ids)))

    def module(self, root, level):
        deps, body, chunks = [], [], []
        memoize = self.literals is not None
        goal = "AppendixBoxGoal false false" if memoize else "ProjectedGoal"
        lower = self.module_limit * GROUP_SIZE ** (level - 1) if level else 0

        def theorem(node):
            if level and node.count <= lower:
                name = self.module(node, level - 1)
                deps.append(name)
                return name
            if node.count <= self.proof_limit and node.midpoint_subtree:
                if memoize:
                    chunks.append(node)
                check = "projectedGoal_chunk"
                if memoize:
                    check = "memoNatGoal_chunk" if self.use_nat_checks else "memoGoal_chunk"
                proof = f"{check} _ {tree_term(node, memoize)} (by decide +kernel)"
            else:
                left, right = theorem(node.left), theorem(node.right)
                split = ("splitMode", "splitX", "splitY")[node.op]
                proof = f"AppendixBoxGoal.{split} _ {node.middle} (by decide) (by decide)"
                if memoize:
                    proof += f" {left} {right}"
                else:
                    proof = f"by\n  intro rates cones\n  exact {proof} ({left} rates cones) ({right} rates cones)"
            self.counter += 1
            name = f"step{self.counter}"
            body.append(f"private theorem {name} : {goal} {box_term(node)} :=\n  {proof}\n")
            return name

        result = theorem(root)
        name = f"Part{len(self.files):05}"
        body.append(f"theorem {name} : {goal} {box_term(root)} := {result}\n")
        imports = ["SubmodularMatching.ReplaySubinterval"]
        if memoize:
            imports = [NAT_MEMO_IMPORT if self.use_nat_checks else MEMO_IMPORT]
            if chunks:
                regions, cones = literal_ids(chunks)
                deps.extend(sorted({self.rate_modules[i] for i in regions} |
                                   {self.cone_modules[i] for i in cones}))
        self.write_module(name, deps, imports, "\n".join(body))
        return name

    def finish(self, node):
        if self.literals is not None:
            self.write_literal_modules(node)
        level = 0
        while node.count > self.module_limit * GROUP_SIZE ** level:
            level += 1
        name = self.module(node, level)
        imports = [RATE_IMPORT, CONE_IMPORT]
        goal = "appendixPriceRoot" if node.box == ROOT else box_term(node)
        proof = name
        if self.literals is not None:
            imports = []
        else:
            proof += (" (fun z _ => runRegion_valid quickRow quickRow_eq quickRow_boundary z)\n"
                      "    appendixFastConeAt_sufficient")
        text = (f"theorem checked : AppendixBoxGoal false false {goal} :=\n"
                f"  {proof}\n\n#print axioms checked\n")
        self.write_module("Result", [name], imports, text)


def build(directory, module_dir, files, jobs):
    env = os.environ.copy()
    env["LEAN_PATH"] = os.pathsep.join(filter(None, [str(directory), env.get("LEAN_PATH")]))
    depths = {}
    levels = []
    for name, deps in files:
        depth = max((depths[d] + 1 for d in deps), default=0)
        depths[name] = depth
        if depth == len(levels):
            levels.append([])
        levels[depth].append((name, deps))

    def compile_module(item):
        name, deps = item
        src = module_dir / f"{name}.lean"
        obj = module_dir / f"{name}.olean"
        prereqs = [src] + [module_dir / f"{dep}.olean" for dep in deps]
        if obj.exists() and obj.stat().st_mtime_ns >= max(p.stat().st_mtime_ns for p in prereqs):
            return
        tmp = obj.with_suffix(".pending.olean")
        subprocess.run(["lean", "-j", "1", "-R", str(directory), "-o", str(tmp), str(src)], env=env, check=True)
        tmp.replace(obj)

    completed = 0
    started = monotonic()
    with ThreadPoolExecutor(max_workers=jobs) as pool:
        for index, tasks in enumerate(levels):
            print(f"Checking layer {index + 1}/{len(levels)} ({len(tasks)} modules)", flush=True)
            pending = [pool.submit(compile_module, item) for item in tasks]
            try:
                for done in as_completed(pending):
                    done.result()
                    completed += 1
                    if completed % 25 == 0 or completed == len(files):
                        elapsed = monotonic() - started
                        print(f"Checked {completed}/{len(files)} modules in {elapsed:.1f}s", flush=True)
            except BaseException:
                for job in pending:
                    job.cancel()
                raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path, help="dedicated output directory")
    parser.add_argument("--sample", action="store_true", help="check only the first small subtree")
    parser.add_argument("--endpoints", type=int, nargs=2, metavar=("FIRST", "LAST"),
                        help="restrict the proof to this inclusive interval of endpoint indices")
    parser.add_argument("--build", action="store_true", help="compile generated sources in the current Lean environment")
    parser.add_argument("--jobs", type=int, default=1, help="parallel Lean processes (default 1)")
    parser.add_argument("--proof-limit", type=int, default=PROOF_LIMIT,
                        help=f"maximum leaves per decidable check (default {PROOF_LIMIT})")
    parser.add_argument("--module-limit", type=int, default=MODULE_LIMIT,
                        help=f"maximum leaves per leaf module (default {MODULE_LIMIT})")
    parser.add_argument("--module-root", default=MODULE_ROOT,
                        help=f"Lean import prefix for generated modules (default {MODULE_ROOT})")
    parser.add_argument("--namespace", default=NAMESPACE,
                        help=f"Lean declaration namespace (default {NAMESPACE})")
    parser.add_argument("--memoize", action="store_true",
                        help="share checked region and cone records across the generated modules")
    parser.add_argument("--shared-rows", action="store_true",
                        help="also reuse checked source rows inside memoized region records")
    parser.add_argument("--nat-memo", action="store_true",
                        help="use natural-number arithmetic for the memoized leaf comparisons")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    if not 1 <= args.proof_limit <= args.module_limit:
        parser.error("expected 1 <= --proof-limit <= --module-limit")
    if (args.shared_rows or args.nat_memo) and not args.memoize:
        parser.error("--shared-rows and --nat-memo require --memoize")
    for name in (args.module_root, args.namespace):
        if not all(part.isidentifier() for part in name.split(".")):
            parser.error("--module-root and --namespace require dotted Lean identifiers")
    root = read_hard_class()
    if args.endpoints is not None:
        first, last = args.endpoints
        if not ROOT[0] <= first <= last <= ROOT[1]:
            parser.error(f"--endpoints must lie between {ROOT[0]} and {ROOT[1]}")
        root = restrict_endpoints(root, first, last)
        if root is None:
            raise ValueError("Could not construct a certificate for the requested interval")
    if args.sample:
        while root.count > args.proof_limit:
            root = root.left
    out = args.out.resolve()
    module_dir = out.joinpath(*args.module_root.split("."))
    module_dir.mkdir(exist_ok=True, parents=True)
    generator = Generator(module_dir, args.module_root, args.namespace,
                          args.proof_limit, args.module_limit, args.memoize, args.shared_rows, args.nat_memo)
    generator.finish(root)
    print(f"Generated {len(generator.files)} modules for {root.count:,} leaves, box {root.box}", flush=True)
    if args.build:
        build(out, module_dir, generator.files, args.jobs)


if __name__ == "__main__":
    main()
