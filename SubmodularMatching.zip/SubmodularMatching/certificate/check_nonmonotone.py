from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
import json
import re
import subprocess
import tempfile

SCALE = 10**8
DEGREE = Q(13, 40)
VERTEX_TANGENT = DEGREE / 5
EDGE_TANGENT = Q(13, 20) * DEGREE
FACTOR = Q(4727, 1000)
SLACK_LOWER_NUMERATORS = (1325, 1741, 2261, 22477)

root = Path(__file__).resolve().parent
original = json.loads((root / "source_parameters.json").read_text())
profile = json.loads((root / "nonmonotone_profiles.json").read_text())

def fractions(data, key):
    return list(map(Q, data[key]))

A = fractions(original, "A")
B = fractions(original, "B")
ratios = fractions(original, "boundaries")
knots = fractions(profile, "grid")
heights = [fractions(profile, key) for key in ("H_uncovered", "H_covered")]
scales = fractions(profile, "scales")
assert len(A) == len(B) and len(ratios) == len(A) + 1
assert len(scales) == 64 and min(scales) > 0
assert all(a <= b for a, b in zip(ratios, ratios[1:]))
assert ratios[0] == Q(1, 2) and ratios[-1] == 1
assert len(knots) == len(heights[0]) == len(heights[1])
assert all(a < b for a, b in zip(knots, knots[1:]))
assert knots[0] == 0
rates = [scales[j * len(scales) // len(A)] for j in range(len(A))]
A = [rate * x for rate, x in zip(rates, A)]
B = [rate * x for rate, x in zip(rates, B)]
d0 = Q(original["source_horizon"])
s = DEGREE - d0
assert 0 < d0 < Q(1, 4) and 0 < s < Q(1, 4)
gamma_grid = 10**12
discriminant = 1 - 4*s
root_floor = isqrt((discriminant.numerator * gamma_grid**2) // discriminant.denominator)
lower_sqrt = Q(root_floor, gamma_grid)
loss = Q(1, 2) + s - lower_sqrt / 2
area = s/2 + s*s/2 - (1 - discriminant * (lower_sqrt + Q(1,gamma_grid)))/12
gamma = 1 - (2*area + (d0-s)*loss)/DEGREE
beta_upper = gamma * DEGREE / (1 + DEGREE/2)**2
alpha_upper = beta_upper * (1 + DEGREE/4)
factor_upper = 1 / beta_upper
assert factor_upper < FACTOR

def floor(x):
    return (x * SCALE).__floor__()

def ceil(x):
    return (x * SCALE).__ceil__()

def log_series_upper(z):
    assert 1 <= z <= 2
    x = (z - 1) / (z + 1)
    terms = 24
    return (
        2 * sum(x**(2*k + 1) / (2*k + 1) for k in range(terms))
        + 2 * x**(2*terms + 1) / ((2*terms + 1) * (1 - x*x))
    )

def log_upper(z):
    shift = 0
    while z > 2:
        shift += 1
        z /= 2
    return log_series_upper(z) + shift * log_series_upper(Q(2))

for h in heights:
    assert h[0] == h[1] == 0
    assert all(a <= b for a, b in zip(h, h[1:]))
    integral_upper = h[-1] / knots[-1]
    for a, b, y, z in zip(knots[1:], knots[2:], h[1:], h[2:]):
        slope = (z - y) / (b - a)
        intercept = y - slope * a
        segment = slope * log_upper(b / a) + intercept * (1/a - 1/b)
        integral_upper += Q((10**20 * segment).__ceil__(), 10**20)
    assert integral_upper <= Q("0.999990001")
    print("Integral upper bound:", float(integral_upper))

retained_knots = [x for x in knots if x <= 1000]
rounded_knots = [ceil(x) for x in retained_knots]
assert all(a < b for a, b in zip(rounded_knots, rounded_knots[1:]))
theta = d0 / DEGREE
interaction = theta * (1 - theta)

def cap(load, tangent):
    return 1 - interaction * tangent**2 - (1 - 2 * interaction * tangent) * load

vertex_caps = [floor(cap(i * DEGREE, VERTEX_TANGENT)) for i in range(2)]
edge_caps = [floor(cap(i * DEGREE, EDGE_TANGENT)) for i in range(3)]
assert min(vertex_caps + edge_caps) > 0
lines = [(
    SCALE, floor(DEGREE), ceil(alpha_upper), ceil(beta_upper),
    len(rounded_knots), len(A), *vertex_caps, *edge_caps,
)]
lines.extend(
    (knot, floor(h0), floor(h1))
    for knot, h0, h1 in zip(rounded_knots, *heights)
)
lines.extend(
    (floor(a), floor(b), ceil(a), ceil(b), floor(lo), ceil(hi))
    for a, b, lo, hi in zip(A, B, ratios, ratios[1:])
)
with tempfile.TemporaryDirectory() as tmp:
    checker = Path(tmp) / "checker"
    subprocess.run(
        ["g++", "-O3", "-std=c++17", str(root / "check_nonmonotone.cpp"), "-o", str(checker)],
        check=True,
    )
    result = subprocess.run(
        [str(checker)],
        input="".join(" ".join(map(str, row)) + "\n" for row in lines),
        text=True,
        stdout=subprocess.PIPE,
        check=True,
    )
slacks = re.search(r"Numerators over (\d+): ([\d ]+)", result.stdout)
assert slacks and int(slacks[1]) == SCALE**3
slack_numerators = list(map(int, slacks[2].split()))
assert len(slack_numerators) == len(SLACK_LOWER_NUMERATORS)
assert all(
    observed >= stated * SCALE**3 // 10**6
    for observed, stated in zip(slack_numerators, SLACK_LOWER_NUMERATORS)
)
print(result.stdout, end="")
print("Limiting factor is below", float(factor_upper), "and the stated factor is", float(FACTOR))
