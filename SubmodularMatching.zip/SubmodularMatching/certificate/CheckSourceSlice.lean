import Lean.Data.Json.Parser
import Lean.Data.Json.FromToJson.Basic
import SubmodularMatching.CertificateInterpolation
import SubmodularMatching.CertificateRationalLog

/-!
# Run the checked arithmetic functions on selected source modes

From the project root, after building the library:
`lake env lean --run certificate/CheckSourceSlice.lean 0 27647`

The integer arguments select source modes. With no arguments the first and
last modes are checked. The weighted integral budget is evaluated on the
entire knot table. This executable checks the JSON at runtime.
-/

open Lean SubmodularMatching.SourceCertificate

namespace SourceSlice

def parseOption (result : Option α) (message : String) : Except String α :=
  match result with
  | some a => .ok a
  | none => .error message

def parseOrThrow (result : Except String α) : IO α :=
  match result with
  | .ok a => pure a
  | .error message => throw (IO.userError message)

def parseRational (input : String) : Except String ℚ := do
  match input.splitOn "/" with
  | [s] =>
    let n ← parseOption s.toInt? s!"Invalid integer: {input}"
    return (n : ℚ)
  | [s,t] =>
    let n ← parseOption s.toInt? s!"Invalid numerator: {input}"
    let d ← parseOption t.toInt? s!"Invalid denominator: {input}"
    if d > 0 then return (n : ℚ) / (d : ℚ)
    else throw s!"Nonpositive denominator: {input}"
  | _ => throw s!"Invalid rational: {input}"

def readVector (json : Json) (key : String) : Except String (Array ℚ) := do
  let entries ← json.getObjValAs? (Array String) key
  entries.mapM parseRational

def readScalar (json : Json) (key : String) : Except String ℚ := do
  parseRational (← json.getObjValAs? String key)

def endpoint (grid h0 h1 : Array ℚ) (sigma degree A B c : ℚ) (i j : Bool) : Bool :=
  let heights (covered : Bool) := if covered then h1 else h0
  let value (covered : Bool) := rationalInterpolate (grid.size - 1)
      (fun k => grid[k]!) (fun k => (heights covered)[k]!)
  let U (a : ℚ) := (1 - if i then degree else 0) * A * value i a
  let V (d : ℚ) := (1 - if j then degree else 0) * B * value j d
  let k := 1 - (if i then degree else 0) - (if j then degree else 0)
  let target := sigma * (1 + (if i then 0 else A) + (if j then 0 else B))
  let ax := ((grid.toList.filter (· < 1 / c)) ++ [1 / c]).reverse
  let dy := if c = 1 then [0] else (grid.toList.filter (· < 1 / (1 - c))) ++ [1 / (1 - c)]
  checkRationalEndpoint U V ax dy k c target

def integralBudget (grid heights : Array ℚ) : ℚ := Id.run do
  let scale : ℚ := 1000000000000000000
  let mut sum : Int := 0
  for i in [0:grid.size - 1] do
    let h := heights[i+1]! - heights[i]!
    if h ≠ 0 then
      let a := grid[i]!
      let b := grid[i+1]!
      let slope := h / (b - a)
      let upper := rationalDyadicLogUpper (b / a) 36 128
      sum := sum + (scale * slope * upper).ceil
  return (sum : ℚ) / scale

def run (json : Json) (requested : List String) : IO Unit := do
  let grid ← parseOrThrow (readVector json "grid")
  let h0 ← parseOrThrow (readVector json "H_uncovered")
  let h1 ← parseOrThrow (readVector json "H_covered")
  let high ← parseOrThrow (readVector json "A")
  let low ← parseOrThrow (readVector json "B")
  let boundary ← parseOrThrow (readVector json "boundaries")
  let sigma ← parseOrThrow (readScalar json "sigma")
  let degree ← parseOrThrow (readScalar json "source_horizon")
  let p ← parseOrThrow (readScalar json "p")
  let modes ← if requested.isEmpty then pure [0, high.size - 1] else
    parseOrThrow (requested.mapM fun x => parseOption x.toNat? s!"Invalid mode index: {x}")
  unless grid.size ≥ 2 && h0.size == grid.size && h1.size == grid.size &&
      high.size > 0 && low.size == high.size && boundary.size == high.size + 1 do
    throw <| IO.userError "Inconsistent source parameter dimensions."
  for idx in modes do
    unless idx < high.size do
      throw <| IO.userError s!"Mode {idx} is outside the parameter table."
    let A := high[idx]!
    let B := low[idx]!
    let start ← IO.monoMsNow
    for side in [idx, idx+1] do
      for i in [false,true] do
        for j in [false,true] do
          unless endpoint grid h0 h1 sigma degree A B boundary[side]! i j do
            throw <| IO.userError s!"Negative slack in mode {idx}, boundary {side}, classes {i},{j}"
    let finish ← IO.monoMsNow
    IO.println s!"PASS mode {idx}, all 8 endpoint/class combinations, {finish-start} ms"
  let cmax := ((high.zip low).map (fun ab => ab.1 + ab.2)).foldl max 0
  let start ← IO.monoMsNow
  let integral0 := integralBudget grid h0
  let integral1 := integralBudget grid h1
  let bound := 1 / (1 + p * cmax)
  unless integral0 < bound && integral1 < bound do
    throw <| IO.userError "Weighted integral budget exceeded."
  let finish ← IO.monoMsNow
  IO.println s!"PASS full knot-table integral budgets {integral0} and {integral1}, {finish-start} ms"

end SourceSlice

def main (args : List String) : IO Unit := do
  let input ← IO.FS.readFile "certificate/source_parameters.json"
  let json ← SourceSlice.parseOrThrow (Json.parse input)
  SourceSlice.run json args
