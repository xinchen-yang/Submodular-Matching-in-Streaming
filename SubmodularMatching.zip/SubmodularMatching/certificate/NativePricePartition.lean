import SubmodularMatching.UpperBoundParametricCorollary
import SubmodularMatching.UpperBoundGraphConfidence
import SubmodularMatching.UpperBoundParametricGraph
import Lean.Elab.Term
import SubmodularMatching.ReplayPartitionCodec
import SubmodularMatching.ReplayRateLookup
import SubmodularMatching.CertificateRateRunRegion
import SubmodularMatching.CertificateHullConeData
import SubmodularMatching.CertificateEasyCones
import SubmodularMatching.ReplayPacked01
import SubmodularMatching.ReplayPacked10
import SubmodularMatching.ReplayPacked11

/-!
# Optional compiler-trusted theorem for the complete Appendix L certificate

Run from the project root with `lake env lean certificate/NativePricePartition.lean`.
The term elaborator embeds the binary witness into this module. The uncovered/uncovered
partition is evaluated by `native_decide`. The other three complete classes,
all cone support proofs, and the input-table identity use the default project proofs.
The mathematical soundness of the checker is supplied by the ordinary
project modules. The final commands print the transitive axiom dependencies.
This file is outside the default library target.
-/

open SubmodularMatching.SourceCertificate SubmodularMatching.SourceCertificate.Replay

namespace SubmodularMatching.OptionalPriceCertificate

open Lean Elab Term in
elab "readPricePartitionHex" : term => do
  let data ← IO.FS.readBinFile "certificate/price_partition.bin"
  let digits := "0123456789abcdef".toUTF8
  let mut result := ByteArray.emptyWithCapacity (2*data.size)
  for x in data do
    result := result.push digits[x.toNat/16]!
    result := result.push digits[x.toNat%16]!
  return mkStrLit (String.fromUTF8! result)

private def witness : String := readPricePartitionHex

private def nibble (v : UInt8) : ℕ :=
  if v.toNat < 58 then v.toNat-48 else v.toNat-87

private def octet (src : ByteArray) (pos : ℕ) : ℕ :=
  16*nibble src[2*pos]! + nibble src[2*pos+1]!

private def readWord (src : ByteArray) (pos size : ℕ) : ℕ := Id.run do
  let mut acc := 0
  for i in [0:size] do
    acc := acc + (octet src (pos+i) <<< (8*i))
  return acc

private def readTree (src : ByteArray) : ℕ → ℕ → Option (MidpointPartition ℕ × ℕ)
  | 0, _ => none
  | depth+1, pos => do
    if 2*pos+1 ≥ src.size then none else
      let op := octet src pos
      if op = 3 then
        if 2*(pos+9) > src.size then none else
          some (.leaf (readWord src (pos+1) 8),pos+9)
      else if op < 3 then
        let (l,p) ← readTree src depth (pos+1)
        let (r,h) ← readTree src depth p
        let tree := if op = 0 then MidpointPartition.m l r else if op = 1 then
          MidpointPartition.x l r else MidpointPartition.y l r
        some (tree,h)
      else none

private def trees : Array (MidpointPartition ℕ) := Id.run do
  let bytes := witness.toUTF8
  let mut p := 8+11*readWord bytes 6 2
  let mut result := #[]
  for _ in [0:4] do
    match readTree bytes 64 p with
    | none => return #[]
    | some (tree,next) =>
      result := result.push tree
      p := next
  if 2*p = bytes.size then return result else return #[]

private def candidate (i j : Bool) : MidpointPartition ℕ :=
  (trees[2*(if i then 1 else 0)+(if j then 1 else 0)]?).getD (.leaf 0)

/-- The two-uncovered class is the only remaining native comparison. -/
private theorem acceptedHard :
    (candidate false false).check (compiledCheck (runRegion quickRow) appendixFastConeAt
      appendixConeCount false false) appendixPriceRoot = true := by native_decide

private theorem ratesValid (z : ℕ) (_ : z < 2^32) : (runRegion quickRow z).Valid :=
  runRegion_valid quickRow quickRow_eq quickRow_boundary z

theorem uncoveredPricePartition : AppendixBoxGoal false false appendixPriceRoot := by
  apply AppendixBoxGoal.chunk false false appendixPriceRoot
    (compiledCheck (runRegion quickRow) appendixFastConeAt appendixConeCount false false)
    _ (candidate false false) acceptedHard
  intro box word hv check
  exact appendixFastLeaf_sound_of_support _ _ _ _ ratesValid appendixFastConeAt_sufficient false false
    box (packedWitness box word) hv check

theorem completePricePartition (i j : Bool) : AppendixBoxGoal i j appendixPriceRoot := by
  cases i <;> cases j
  · exact uncoveredPricePartition
  · exact Packed01.checked ratesValid appendixFastConeAt_easy
  · exact Packed10.checked ratesValid appendixFastConeAt_easy
  · exact Packed11.checked ratesValid appendixFastConeAt_easy

/-- The actual price-potential source conditions, including every endpoint,
every pair of nonnegative real prices, and both integral budgets. -/
theorem sourceConditions (tau theta gap grid : ℝ)
    (hθ : 0 < theta) (hθτ : theta ≤ tau) (hd : 0 ≤ gap) (hg : 0 < grid)
    (hgτ : grid ≤ NumericalCertificate.coordinateCap * tau) :
    RunSourceConditions appendixPotentialTable.sourceFunction
      (appendixPotentialConfig tau theta gap grid hθ hθτ hd hg hgτ)
      NumericalCertificate.degree NumericalCertificate.sigma (SourceRateTable.appendixCmax : ℝ) :=
  actualSourceConditions_of_cover tau theta gap grid hθ hθτ hd hg hgτ completePricePartition

#print axioms completePricePartition
#print axioms sourceConditions

end SubmodularMatching.OptionalPriceCertificate

/-! # Upper-bound specialization using the compiler-checked partition -/

namespace SubmodularMatching.OptionalPriceCertificate

open SourceCertificate UpperBoundAssembly GibbsSampler NumericalCertificate

noncomputable section

theorem completeSourceObligation (n : ℕ) (hn : 2 ≤ n) : AppendixSourceObligation n hn := by
  intro tau _
  unfold appendixGuessConfig
  apply actualSourceConditions_of_cover
  exact completePricePartition

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- The fixed approximation factor with the complete numerical premise
resolved by the optional compiler-trusted replay above. -/
theorem theorem1_1_verified (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, f M ≤ f O)
    (delta : ℝ) (hδ : 0 < delta) :
    let p := S.expectedOutput f hf hm
    let q := S.amplifiedOutput f hf hm delta
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / targetFactor ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤ delta :=
  S.theorem1_1_value f hf hm h0 (completeSourceObligation (Fintype.card V)) O hO hopt delta hδ

/-- The manuscript's inverse-polynomial confidence guarantee. -/
theorem theorem1_1_confidence_verified (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, f M ≤ f O)
    (hn : 1 ≤ Fintype.card V) (c : ℝ) :
    let n := Fintype.card V
    let delta := (((n : ℝ) ^ ⌈c⌉₊)⁻¹)
    let q := S.amplifiedOutput f hf hm delta
    q.outcomes ⊆ S.matchings ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤
        (n : ℝ) ^ (-c) :=
  S.theorem1_1_confidence f hf hm h0 (completeSourceObligation (Fintype.card V)) O hO hopt hn c

/-- The optional numerical proof also supplies the paper's full
fixed-accuracy family. -/
theorem approximationFamily_verified (S : SimpleEdgeStream E V) {slack : ℝ}
    (a : FamilyParameters slack) (hslack : 0 < slack) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, f M ≤ f O)
    (delta : ℝ) (hδ : 0 < delta) :
    let p := S.familyExpectedOutput a f hf hm
    let q := S.familyAmplifiedOutput a f hf hm delta
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / a.target ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / a.target ≤ f M then 0 else 1) ≤ delta :=
  S.approximationFamily_value a hslack f hf hm h0 (completeSourceObligation (Fintype.card V))
    O hO hopt delta hδ

/-- The complete approximation-family result chooses one set of fixed
parameters for each ratio and works uniformly on all input streams. -/
theorem approximationFamily_corollary_verified (ratio : ℝ) (hr : (45246551 : ℝ) / 10000000 < ratio)
    :
    ∃ a : FamilyParameters (ratio - 45246551 / 10000000),
      ∀ (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
        (hf : IsSubmodular f) (hmono : IsMonotone f) (_h0 : 0 ≤ f ∅)
        (O : Finset E) (_hO : O ∈ S.matchings)
        (_hopt : ∀ M ∈ S.matchings, f M ≤ f O) (δ : ℝ) (_hδ : 0 < δ),
        let p := S.familyExpectedOutput a f hf hmono
        let q := S.familyAmplifiedOutput a f hf hmono δ
        p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
          f O / ratio ≤ expected p.outcomes p.mass f ∧
          expected q.outcomes q.mass (fun M => if f O / ratio ≤ f M then 0 else 1) ≤ δ :=
  UpperBoundAssembly.approximationFamily_corollary ratio hr (completeSourceObligation (Fintype.card V))


end

end SubmodularMatching.OptionalPriceCertificate

#print axioms SubmodularMatching.OptionalPriceCertificate.theorem1_1_verified
#print axioms SubmodularMatching.OptionalPriceCertificate.theorem1_1_confidence_verified
#print axioms SubmodularMatching.OptionalPriceCertificate.approximationFamily_verified
#print axioms SubmodularMatching.OptionalPriceCertificate.approximationFamily_corollary_verified
