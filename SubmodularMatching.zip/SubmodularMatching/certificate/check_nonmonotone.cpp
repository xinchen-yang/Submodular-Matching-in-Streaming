#include <algorithm>
#include <array>
#include <cassert>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

using i64 = long long;
using i128 = __int128_t;

std::string digits(i128 number) {
  assert(number >= 0);
  if (!number) return "0";
  std::string result;
  while (number) {
    result += char('0' + number % 10);
    number /= 10;
  }
  std::reverse(result.begin(), result.end());
  return result;
}

int main() {
  i64 Q, D, alpha, beta;
  size_t n, groups;
  std::array<i64,2> caps;
  std::array<i64,3> edge_caps;
  std::cin >> Q >> D >> alpha >> beta >> n >> groups >> caps[0] >> caps[1]
           >> edge_caps[0] >> edge_caps[1] >> edge_caps[2];
  std::vector<i64> a(n);
  std::array<std::vector<i64>, 2> H{std::vector<i64>(n), std::vector<i64>(n)};
  for (size_t l=0; l<n; ++l)
    std::cin >> a[l] >> H[0][l] >> H[1][l];
  const i128 Q2=i128(Q)*Q, Q3=Q2*Q;
  std::array<i128,4> minimum{Q3,Q3,Q3,Q3};
  std::vector<i128> V(n);
  auto check = [&](int flag, i128 slack){
    minimum[flag]=std::min(minimum[flag],slack);
    if (slack < 0) {
      std::cerr << "Negative slack in case " << flag << ": "
                << (long double)slack/(long double)Q3 << "\n";
      std::exit(1);
    }
  };
  auto interpolate = [&](int type, i128 n_x, i64 d_x, size_t k){
    assert(d_x > 0 && i128(d_x)*a[k] <= n_x);
    if (k+1 == n) return H[type][k];
    assert(n_x < i128(d_x)*a[k+1]);
    i128 increment=i128(H[type][k+1]-H[type][k])*(n_x-i128(d_x)*a[k]);
    return H[type][k]+i64(increment/(i128(a[k+1]-a[k])*d_x));
  };
  for(size_t group=0; group<groups; ++group) {
    i64 A, B, Aupper, Bupper, Cmin, Cmax;
    std::cin>>A>>B>>Aupper>>Bupper>>Cmin>>Cmax;
    for(int i=0; i<2; ++i) for(int j=0; j<2; ++j) {
      int flag=2*i+j;
      i64 q=edge_caps[i+j];
      i128 u=i128(caps[i])*A, v=i128(caps[j])*B;
      i128 rhs=(i128(alpha)*Q+i128(beta)*((1-i)*Aupper+(1-j)*Bupper))*Q;
      check(flag,u*H[i].back()-rhs);
      check(flag,v*H[j].back()-rhs);
      for(i64 c : {Cmin,Cmax}) {
        i64 r = Q-c;
        for(size_t l=0; l<n; ++l) {
          V[l]=v*H[j][l]-i128(q)*r*a[l];
          if (l) V[l]=std::min(V[l],V[l-1]);
        }
        size_t k=n-1;
        for(size_t l=0; l<n; ++l) {
          i128 numerator=Q2-i128(c)*a[l];
          if (numerator < 0) break;
          if (r) {
            while (i128(r)*a[k] > numerator) --k;
            check(flag,u*H[i][l]+V[k]+i128(q)*numerator-rhs);
            if (i128(r)*a.back() >= numerator)
              check(flag,u*H[i][l]+v*interpolate(j,numerator,r,k)-rhs);
          } else {
            check(flag,u*H[i][l]+i128(q)*numerator-rhs);
          }
        }
        k=n-1;
        for(size_t l=0; l<n; ++l) {
          i128 numerator=Q2-i128(r)*a[l];
          if (numerator < 0) break;
          while (i128(c)*a[k] > numerator) --k;
          if (i128(c)*a.back() >= numerator)
            check(flag,u*interpolate(i,numerator,c,k)+v*H[j][l]-rhs);
        }
      }
    }
  }
  std::cout<<std::setprecision(15)<<"Minimum rigorous lower slacks by flag:";
  for(i128 slack:minimum)
    std::cout<<" "<<(long double)slack/(long double)Q3;
  std::cout<<"\nNumerators over "<<digits(Q3)<<":";
  for(i128 slack:minimum)
    std::cout<<" "<<digits(slack);
  std::cout<<"\n";
}
