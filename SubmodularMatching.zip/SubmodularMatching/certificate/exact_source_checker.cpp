// Independent exact checker for the complete four-class source inequalities.
// Every arithmetic operation uses GMP rationals. No floating point tolerance.
// On each piecewise-affine cell, a minimum lies at a grid vertex or at an
// intersection with c*a+(1-c)*d=1. Prefix minima cover all grid vertices.
#include <gmpxx.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using Q = mpq_class;
using Z = mpz_class;
void require(bool yes, const std::string& message) {
  if (!yes) throw std::runtime_error(message);
}
Q readq(std::istream& in) {
  std::string s; require(bool(in >> s), "Truncated input");
  Q q(s); q.canonicalize(); return q;
}
std::vector<Q> readv(std::istream& in, std::size_t n) {
  std::vector<Q> out; out.reserve(n);
  for (std::size_t i=0;i<n;++i) out.push_back(readq(in));
  return out;
}
Q small_log_upper(const Q& z) {
  require(z>=1 && z<=2, "Log range");
  const Q u=(z-1)/(z+1), u2=u*u;
  Q power=u, sum=0;
  for (int j=0;j<36;++j) { sum+=2*power/(2*j+1); power*=u2; }
  return sum+2*power/(73*(1-u2));
}
Q log_upper(Q z) {
  require(z>=1, "Negative log range"); int exponent=0;
  while (z>2) { z/=2; ++exponent; }
  return exponent*small_log_upper(Q(2))+small_log_upper(z);
}

int main(int argc,char** argv) {
 try {
  require(argc==3 || argc==5,
          "Usage: exact_source_checker input.txt output.json [mode_start mode_end]");
  std::ifstream input(argv[1]); require(bool(input), "Cannot open input");
  std::string magic; input>>magic; require(magic=="SOURCE4_V1", "Bad format");
  std::size_t k,n; input>>k>>n; require(k>0 && n>=2, "Bad dimensions");
  Q sigma=readq(input), D=readq(input), p=readq(input);
  const auto A=readv(input,k), B=readv(input,k), C=readv(input,k+1);
  const auto grid=readv(input,n);
  const std::array<std::vector<Q>,2> height={readv(input,n),readv(input,n)};
  std::string trailing; require(!(input>>trailing), "Unexpected input data");
  require(sigma>0 && sigma<1 && D>0 && D<=Q(1,4) && p>0 && p<=1,
          "Invalid scalar parameters");
  require(C.front()==Q(1,2) && C.back()==1 && grid.front()==0,
          "Invalid domains");
  require(A.front()==B.front(), "First mode is not balanced");
  Q Cmax=0;
  for (std::size_t j=0;j<k;++j) {
    require(A[j]>=B[j] && B[j]>0, "Invalid rates");
    require(C[j]<C[j+1], "Unordered modes");
    require(sigma*(1+A[j]+B[j])<1, "Acceptance coefficient not below one");
    if (A[j]+B[j]>Cmax) Cmax=A[j]+B[j];
    require(grid.back()>=1/(1-C[j]), "Potential tail too short");
  }
  for (int status=0;status<2;++status) {
    require(height[status][0]==0 && height[status][1]==0,
            "Potential not zero near zero");
    for (std::size_t i=1;i<n;++i) {
      require(grid[i]>grid[i-1], "Unordered potential grid");
      require(height[status][i]>=height[status][i-1], "Nonmonotone potential");
    }
  }
  auto H=[&](int status,const Q& x)->Q {
    require(x>=0, "Negative argument");
    if (x>=grid.back()) return height[status].back();
    auto it=std::upper_bound(grid.begin(),grid.end(),x);
    require(it!=grid.begin(), "Interpolation underflow");
    std::size_t j=std::size_t(it-grid.begin()-1);
    return height[status][j]+(height[status][j+1]-height[status][j])*
      (x-grid[j])/(grid[j+1]-grid[j]);
  };
  std::size_t start=0,end=k;
  if (argc==5) { start=std::stoull(argv[3]);end=std::stoull(argv[4]); }
  require(start<end && end<=k,"Bad mode partition");
  std::uint64_t checked=0, represented=0, tails=0;
  bool has_min=false; Q minimum;
  std::size_t witness_mode=0; int witness_i=0,witness_j=0;
  Q witness_c,witness_a,witness_d;
  auto check=[&](std::size_t mode,int i,int j,const Q& c,
                 const Q& a,const Q& d,const Q& gap) {
    if (gap<0) {
      std::ostringstream msg;
      msg<<"Negative exact slack: mode="<<mode<<" status="<<i<<j
         <<" c="<<c<<" a="<<a<<" d="<<d<<" gap="<<gap;
      throw std::runtime_error(msg.str());
    }
    ++checked;
    if (!has_min || gap<minimum) {
      has_min=true; minimum=gap; witness_mode=mode; witness_i=i; witness_j=j;
      witness_c=c;witness_a=a;witness_d=d;
    }
  };
  for (std::size_t mode=start;mode<end;++mode) {
    for (int i=0;i<2;++i) for (int j=0;j<2;++j) {
      const Q u=(1-D*i)*A[mode],v=(1-D*j)*B[mode],q=1-D*(i+j);
      const Q target=sigma*(1+(1-i)*A[mode]+(1-j)*B[mode]);
      require(u*height[i].back()>=target && v*height[j].back()>=target,
              "Zero-price tail inequality failed"); ++tails;
      for (int side=0;side<2;++side) {
        const Q c=C[mode+side];
        if (c==1) {
          for (std::size_t a=0;a<n && grid[a]<=1;++a)
            check(mode,i,j,c,grid[a],Q(0),u*height[i][a]+q*(1-grid[a])-target);
          check(mode,i,j,c,Q(1),Q(0),u*H(i,Q(1))-target);
          continue;
        }
        const Q xmax=1/c,ymax=1/(1-c);
        std::vector<Q> ax,dy,ha,hd;
        for (std::size_t a=0;a<n && grid[a]<=xmax;++a) {
          ax.push_back(grid[a]);ha.push_back(height[i][a]);
        }
        if (ax.back()!=xmax) { ax.push_back(xmax);ha.push_back(H(i,xmax)); }
        for (std::size_t d=0;d<n && grid[d]<=ymax;++d) {
          dy.push_back(grid[d]);hd.push_back(height[j][d]);
        }
        if (dy.back()!=ymax) { dy.push_back(ymax);hd.push_back(H(j,ymax)); }
        std::vector<Q> best; std::vector<std::size_t> best_arg;
        Q current;std::size_t arg=0;
        for (std::size_t d=0;d<dy.size();++d) {
          Q term=v*hd[d]-q*(1-c)*dy[d];
          if (d==0 || term<current) { current=term;arg=d; }
          best.push_back(current);best_arg.push_back(arg);
        }
        for (std::size_t a=0;a<ax.size();++a) {
          const Q top=(1-c*ax[a])/(1-c);
          auto it=std::upper_bound(dy.begin(),dy.end(),top);
          require(it!=dy.begin(), "Prefix search underflow");
          std::size_t last=std::size_t(it-dy.begin()-1);
          const Q gap=u*ha[a]-q*c*ax[a]+best[last]+q-target;
          check(mode,i,j,c,ax[a],dy[best_arg[last]],gap);
          represented+=last+1;
          check(mode,i,j,c,ax[a],top,u*ha[a]+v*H(j,top)-target);
        }
        for (std::size_t d=0;d<dy.size();++d) {
          const Q left=(1-(1-c)*dy[d])/c;
          check(mode,i,j,c,left,dy[d],u*H(i,left)+v*hd[d]-target);
        }
      }
    }
    if ((mode+1)%64==0)
      std::cerr<<"Verified mode "<<mode+1<<" / "<<end<<", exact checks "<<checked<<"\n";
  }
  const Z denominator("1000000000000000000");
  std::array<Q,2> integrals;
  for (int status=0;status<2;++status) {
    Z sum=0;
    for (std::size_t j=0;j+1<n;++j) {
      const Q slope=(height[status][j+1]-height[status][j])/(grid[j+1]-grid[j]);
      if (slope==0) continue;
      require(grid[j]>0,"Nonzero slope at zero");
      const Q term=slope*log_upper(grid[j+1]/grid[j])*denominator;
      Z ceiling; mpz_cdiv_q(ceiling.get_mpz_t(),term.get_num_mpz_t(),term.get_den_mpz_t());
      sum+=ceiling;
    }
    integrals[status]=Q(sum,denominator);integrals[status].canonicalize();
    require(integrals[status]<1/(1+p*Cmax),"Potential integral exceeds budget");
  }
  std::ofstream out(argv[2]);require(bool(out),"Cannot create output");
  out<<"{\n  \"status\": \"PASS: exact GMP rational four-class source inequalities\",\n"
     <<"  \"mode_range\": ["<<start<<", "<<end<<"],\n"
     <<"  \"modes\": "<<k<<", \"potential_knots\": "<<n<<",\n"
     <<"  \"sigma\": \""<<sigma<<"\", \"source_horizon\": \""<<D<<"\",\n"
     <<"  \"evaluated_separation_points\": "<<checked<<",\n"
     <<"  \"interior_grid_pairs_covered\": "<<represented<<",\n"
     <<"  \"zero_price_checks\": "<<tails<<",\n"
     <<"  \"minimum_slack\": \""<<minimum<<"\",\n"
     <<"  \"minimum_slack_witness\": ["<<witness_mode<<", "<<witness_i<<", "<<witness_j
     <<", \""<<witness_c<<"\", \""<<witness_a<<"\", \""<<witness_d<<"\"],\n"
     <<"  \"integral_uppers\": [\""<<integrals[0]<<"\", \""<<integrals[1]<<"\"],\n"
     <<"  \"Cmax\": \""<<Cmax<<"\",\n"
     <<"  \"arithmetic\": \"GMP arbitrary precision rationals; exact log-series upper bounds\"\n}\n";
  std::cout<<"PASS modes ["<<start<<","<<end<<"), checks="<<checked<<"\n";
  return 0;
 } catch (const std::exception& e) {
  std::cerr<<"FAIL: "<<e.what()<<"\n"; return 1;
 }
}
