import SubmodularMatching.ReplayPartitionCodec
import SubmodularMatching.ReplayQuickRate
import SubmodularMatching.CertificateRateRunRegion
import SubmodularMatching.CertificateConeLiterals

/-!
# Run the complete compressed Appendix L price certificate

Run from the project root with `lake env lean --run certificate/CheckPricePartition.lean`.
All box and tilt comparisons use the same integer functions as the kernel-checked
subtrees. This program also checks the support certificate of each referenced
cone. Its success is a runtime result.
-/

open SubmodularMatching.SourceCertificate SubmodularMatching.SourceCertificate.Replay

namespace PricePartitionDriver

def unsigned (bs : ByteArray) (pos size : ℕ) : ℕ := Id.run do
  let mut value := 0
  for i in [0:size] do
    value := value + (bs[pos+i]!.toNat <<< (8*i))
  return value

partial def traverse (bs : ByteArray) (i j : Bool) (box : PriceBox) (pos : ℕ) :
    Except String (ℕ × ℕ) := do
  if pos ≥ bs.size then throw "Truncated tree"
  let opcode := bs[pos]!.toNat
  if opcode = 3 then
    if pos+9 > bs.size then throw "Truncated leaf"
    let w := unsigned bs (pos+1) 8
    if !compiledCheck (runRegion quickRow) appendixFastConeAt appendixConeCount i j box w then
      throw s!"Leaf failed at byte {pos}, endpoint range {box.modeLo}..{box.modeHi}"
    return (pos+9,1)
  let (left,right) ← match opcode with
    | 0 =>
      if box.modeLo ≥ box.modeHi then throw "Invalid discrete split" else
        let mid := (box.modeLo+box.modeHi)/2
        pure ({box with modeHi := mid}, {box with modeLo := mid+1})
    | 1 =>
      if box.xLo+1 ≥ box.xHi then throw "Invalid horizontal split" else
        let mid := (box.xLo+box.xHi)/2
        pure ({box with xHi := mid}, {box with xLo := mid})
    | 2 =>
      if box.yLo+1 ≥ box.yHi then throw "Invalid vertical split" else
        let mid := (box.yLo+box.yHi)/2
        pure ({box with yHi := mid}, {box with yLo := mid})
    | _ => throw "Unknown opcode"
  let (p,n) ← traverse bs i j left (pos+1)
  let (p',n') ← traverse bs i j right p
  return (p',n+n')

end PricePartitionDriver

def main : IO Unit := do
  let data ← IO.FS.readBinFile "certificate/price_partition.bin"
  let expect (p : Bool) (m : String) : IO Unit :=
    if p then pure () else throw (IO.userError m)
  expect (data.size ≥ 8 && data.extract 0 6 == "SMBOX1".toUTF8) "Unexpected file header"
  let n := PricePartitionDriver.unsigned data 6 2
  expect (n ≤ appendixConeCount && 8+11*n ≤ data.size) "Bad cone-table size"
  for k in [0:n] do
    let pos := 8+11*k
    let entry := appendixFastConeAt k
    let attr (j : ℕ) := PricePartitionDriver.unsigned data (pos+1+2*j) 2
    expect ((data[pos]!.toNat == (if entry.covered then 1 else 0)) &&
      entry.cone.lo == attr 0 && entry.cone.hi == attr 1 && entry.cone.ix == attr 2 &&
      entry.cone.prev == attr 3 && entry.cone.next == attr 4 && entry.check)
      s!"Cone mismatch at {k}"
  IO.println s!"Checked {n} support cones."
  let mut pos := 8+11*n
  for i in [false,true] do
    for j in [false,true] do
      match PricePartitionDriver.traverse data i j appendixPriceRoot pos with
      | .error msg => throw (IO.userError msg)
      | .ok (next,count) =>
        pos := next
        IO.println s!"Class {i},{j}: {count} accepted leaves on all 55,296 endpoints."
  expect (pos == data.size) "Trailing certificate data"
