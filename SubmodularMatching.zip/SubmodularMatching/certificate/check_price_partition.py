"""Replay the complete four-class price-box proof using mathematical integers.

The soundness lemmas for the rectangle relaxation live in the Lean project.
This standalone checker evaluates the actual recorded tree and source JSON.
"""
import functools
from fractions import Fraction
import json
from pathlib import Path
import struct
import time

BASE = Path(__file__).resolve().parent
SCALE = 10**12
DD = 62500000000000000000000
DN = 15609923359958673284671
SN = 10000000
SD = 45246551


def require(condition, message):
    if not condition:
        raise ValueError(message)


class Reader:
    def __init__(self, path):
        self.data = path.read_bytes()
        self.position = 0

    def take(self, count):
        data = self.data[self.position:self.position + count]
        require(len(data) == count, "Truncated certificate")
        self.position += count
        return data

    def read(self, fmt):
        return struct.unpack(fmt, self.take(struct.calcsize(fmt)))


def main():
    started = time.monotonic()
    source = json.loads((BASE / "source_parameters.json").read_text())

    def fixed(key):
        values = [Fraction(x) * SCALE for x in source[key]]
        require(all(x.denominator == 1 for x in values), "Invalid fixed-point value")
        return [x.numerator for x in values]

    require(Fraction(source["source_horizon"]) == Fraction(DN, DD), "Degree mismatch")
    require(Fraction(source["sigma"]) == Fraction(SN, SD), "Target mismatch")
    x = fixed("grid")
    heights = [fixed("H_uncovered"), fixed("H_covered")]
    a, b, c = map(fixed, ("A", "B", "boundaries"))
    require(len(x) == 1136 and all(len(h) == len(x) for h in heights), "Bad height dimensions")
    require(len(a) == len(b) == 27648 and len(c) == len(a) + 1, "Bad rate dimensions")
    require(x[0] == 0 and all(u < v for u, v in zip(x, x[1:])), "Knots out of order")
    require(all(u <= v for h in heights for u, v in zip(h, h[1:])), "Heights out of order")
    require(all(u <= v for u, v in zip(c, c[1:])), "Unordered rate boundaries")
    require(c[0] == SCALE // 2 and c[-1] == SCALE, "Rate domain mismatch")
    require(all(min(h) >= 0 for h in heights) and min(a) > 0 and min(b) > 0,
            "Sign conditions failed")
    rd = Reader(BASE / "price_partition.bin")
    require(rd.take(6) == b"SMBOX1", "Unknown certificate format")
    count, = rd.read("<H")
    cones = []
    for _ in range(count):
        side, lo, hi, idx, prev, nxt = rd.read("<B5H")
        require(side < 2 and 0 <= lo <= prev <= idx <= nxt <= hi < len(x), "Bad cone indices")
        require((prev < idx or idx == lo) and (idx < nxt or idx == hi), "Degenerate cone")
        h = heights[side]
        dx0, dh0 = x[idx]-x[prev], h[idx]-h[prev]
        dx1, dh1 = x[nxt]-x[idx], h[nxt]-h[idx]
        for k in range(lo, idx):
            require((h[idx]-h[k])*dx0 <= dh0*(x[idx]-x[k]), "Invalid left secant")
        for k in range(idx+1, hi+1):
            require(dh1*(x[k]-x[idx]) <= (h[k]-h[idx])*dx1, "Invalid right secant")
        cones.append((side, lo, hi, dx0, dh0, dx1, dh1, x[idx], h[idx]))

    @functools.lru_cache(None)
    def bounds(lo, hi):
        aa = a[lo//2:hi//2+1]
        bb = b[lo//2:hi//2+1]
        return min(aa), max(aa), min(bb), max(bb), c[(lo+1)//2], c[(hi+1)//2]

    def axis(cone, side, lo, hi, wgt, penalty):
        s, l, r, dx0, dh0, dx1, dh1, xx, hh = cones[cone]
        require((s, l, r) == (side, lo, hi), "Cone attached to wrong interval")
        require(wgt*dh0 <= penalty*dx0 and penalty*dx1 <= wgt*dh1, "Invalid tilt")
        return wgt*hh - penalty*xx

    for i in (0, 1):
        for j in (0, 1):
            root = (0, 55295, 0, 1135, 0, 1135)
            boxes = [root]
            leaves = 0
            while boxes:
                region = boxes.pop()
                lo, hi, xl, xr, yl, yr = region
                op, = rd.read("<B")
                if op < 3:
                    k = 2*op
                    require(region[k] < region[k+1], "Split of atomic interval")
                    mid = (region[k]+region[k+1])//2
                    left, right = list(region), list(region)
                    left[k+1] = mid
                    right[k] = mid + int(op == 0)
                    boxes.extend((right, left))
                    continue
                require(op == 3, "Invalid split tag")
                word, = rd.read("<Q")
                cx, cy, t = word & 4095, (word >> 12) & 4095, word >> 24
                require(max(cx, cy) < len(cones), "Cone reference out of range")
                amin, amax, bmin, bmax, clo, chi = bounds(lo, hi)
                require(t*DD <= (DD-DN*(i+j))*SCALE, "Invalid multiplier")
                lx = axis(cx, i, xl, xr, (DD-DN*i)*amin*SCALE, t*chi*DD)
                ly = axis(cy, j, yl, yr, (DD-DN*j)*bmin*SCALE, t*(SCALE-clo)*DD)
                target = SN*(SCALE+(1-i)*amax+(1-j)*bmax)
                require(target*DD*SCALE**2 <= (lx+ly+t*DD*SCALE**2)*SD, "Box gap negative")
                leaves += 1
            amin, amax, bmin, bmax, _, _ = bounds(0, 55295)
            target = SN*(SCALE+(1-i)*amax+(1-j)*bmax)
            require(target*DD*SCALE <= SD*(DD-DN*i)*amin*heights[i][-1], "Horizontal tail failed")
            require(target*DD*SCALE <= SD*(DD-DN*j)*bmin*heights[j][-1], "Vertical tail failed")
            print(f"Class {i}{j} passed on all 55,296 endpoints and {leaves:,} rectangles.")
    require(rd.position == len(rd.data), "Trailing bytes")
    print(f"{len(cones):,} cones. Exact replay completed in {time.monotonic()-started:.2f} seconds.")


if __name__ == "__main__":
    main()
