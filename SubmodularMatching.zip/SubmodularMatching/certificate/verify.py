"""Reproduce the exact source certificate and finite approximation margins.

Run after extracting the commented payloads from submodular_matching.tex.
Dependencies: Python 3; g++ with C++17; GMP headers and libraries.
"""
from pathlib import Path
import argparse
import subprocess
import sys

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--finite-only', action='store_true')
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    if not args.finite_only:
        subprocess.run([sys.executable, str(here / 'run_exact_source.py'),
                        str(here / 'source_parameters.json'), '--prefix', 'verified',
                        '--workers', str(args.workers)], check=True, cwd=here)
    subprocess.run([
        sys.executable, str(here / 'check_general_finite_constants.py'),
        str(here / 'source_parameters.json'),
        '--target', '4.524656', '--hp-factor', '4.5246552',
        '--rounding-r', '128882864927/250000000000',
        '--rounding-error', '1e-8', '--finite-error', '1e-10',
        '--b', '110505663541/500000000000',
        '--output', str(here / 'verified_finite_constants.json')],
        check=True, cwd=here)

if __name__ == '__main__':
    main()
