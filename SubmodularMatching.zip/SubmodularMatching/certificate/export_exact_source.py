"""Export an already rational source parameter file for the GMP checker."""
from fractions import Fraction
from pathlib import Path
import argparse, json

p=argparse.ArgumentParser()
p.add_argument('parameters',type=Path)
p.add_argument('output',type=Path)
args=p.parse_args()
x=json.loads(args.parameters.read_text())
k,n=len(x['A']),len(x['grid'])
lines=['SOURCE4_V1',f'{k} {n}']
for key in ('sigma','source_horizon','p'):
    lines.append(str(Fraction(x[key])))
for key in ('A','B','boundaries','grid','H_uncovered','H_covered'):
    lines.extend(str(Fraction(v)) for v in x[key])
args.output.write_text('\n'.join(lines)+'\n')
print(json.dumps({'modes':k,'knots':n,'output':str(args.output)}))
