import SubmodularMatching.NumericalReplayRows
import SubmodularMatching.SourceDataFixedPoint

/-! # Exact knot checks at the final boundary of the source rate table -/

namespace SubmodularMatching.SourceCertificate.Replay

open SourceRateTable

def lastHigh : ℚ := 1162930155947 / 1000000000000
def lastLow : ℚ := 22628882943 / 40000000000

/-- Exact minimum in the external checker, used here as the proposed lower
bound on every relevant one-dimensional knot slack. -/
def lastSlack : ℚ := 6998679384616972300555973 / 565581887500000000000000000000000

def finalTarget (i j : Bool) : ℚ :=
  appendixSigma * (1+(1-bitQ i)*lastHigh+(1-bitQ j)*lastLow)

def finalHigh (i : Bool) : ℚ := (1-appendixDegree*bitQ i)*lastHigh
def finalCapacity (i j : Bool) : ℚ := 1-appendixDegree*(bitQ i+bitQ j)

def finalValue (i j : Bool) (k : ℕ) : ℚ :=
  finalHigh i * height i k + finalCapacity i j * (1-knot k)

def finalRow (k : ℕ) : Bool :=
  [false, true].all fun i => [false, true].all fun j =>
    decide (finalTarget i j + lastSlack ≤ finalValue i j k)

set_option maxHeartbeats 5000000
set_option maxRecDepth 16000

private theorem finalRowsChecked : allRows finalRow 0 231 = true := by decide +kernel

theorem final_knot_bound (i j : Bool) (k : ℕ) (hk : k ≤ 230) :
    finalTarget i j + lastSlack ≤ finalValue i j k := by
  have h := allRows_sound finalRowsChecked (Nat.zero_le k) (by omega)
  simp only [finalRow, List.all_eq_true, List.mem_cons, List.mem_nil_iff, or_false,
    decide_eq_true_eq] at h
  exact h i (by cases i <;> simp) j (by cases j <;> simp)

theorem final_knot_230 : knot 230 = 1 := by decide +kernel

theorem minimum_witness :
    knot 134 = 11/25 ∧ finalValue false true 134 - finalTarget false true = lastSlack := by
  decide +kernel

end SubmodularMatching.SourceCertificate.Replay
