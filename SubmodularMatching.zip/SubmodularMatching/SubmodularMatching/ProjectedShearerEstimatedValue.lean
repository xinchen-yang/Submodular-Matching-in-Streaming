import SubmodularMatching.ProjectedShearerFirstStage
import SubmodularMatching.ProjectedShearerNoisyCoupling

/-! # Expected value with finite-accuracy score decisions -/

namespace SubmodularMatching.Shearer
open GibbsMatching AppendixM
open scoped BigOperators

variable {E V L : Type*} [DecidableEq E] [DecidableEq V] [DecidableEq L]

/-- The estimated-sign output on the actual two uniformly time-marked
samples incurs the explicit oracle and finite-grid collision losses. -/
theorem finite_estimated_priority_output [LinearOrder E] (ends : E → Finset V) (label : E → L)
    (h : Finset L → ℝ) (S : Finset E) (Y : E → ℝ) (hf : IsSubmodular h) (H ε : ℝ)
    (hlo : ∀ U, 0 ≤ h U) (hhi : ∀ U, h U ≤ H) (hε : 0 ≤ ε)
    (h0 : ∀ a ∈ S, 0 ≤ Y a) (hends : ∀ a ∈ S, (ends a).card = 2)
    (hY : ∀ w, ∑ a ∈ incident ends S w, Y a ≤ degree)
    (Q m n : ℕ) (hQ : 0 < Q) (hn : 0 < n) (hm : (m:ℝ)/Q = layerOne) (hw : (n:ℝ)/Q = layerTwo)
    (els : ℕ → L) (k : ℕ) (hcover : S.image label ⊆ replacementPrefix els k)
    (hdistinct : ∀ i < k, ∀ j < k, els i = els j → i = j)
    (estimate : Finset (E×ℕ) → (E×ℕ) → ℝ)
    (acc : ∀ A e, (∀ a ∈ A, Disjoint ((binEnds ends) a) ((binEnds ends) e)) →
      |estimate A e - marginal h (binLabel label e) (A.image (binLabel label))| ≤ ε) :
    let avg := binLaw ends S Y Q m n
    let val := bernoulliExpectation els (fun i => unalteredMarginal ends S Y label Q m n (els i)) h k
    gamma*(val-h ∅) - (gamma+2*S.card)*H*avg collision - 2*S.card*ε ≤
      avg (fun A B => h ((estimatedOutput ends label h estimate A B).image (binLabel label))-h ∅) := by
  intro avg val
  let s := scoreAt (binEnds ends) (binLabel label) h Prod.snd
  let g := survivingAt (binEnds ends) (binLabel label) h Prod.snd
  let input := fun A B : Finset (E×ℕ) => h ((A∪B).image (binLabel label))
  let output := fun A B : Finset (E×ℕ) => h ((estimatedOutput ends label h estimate A B).image (binLabel label))-h ∅
  have io := bin_interior ends S Y h0 hends hY Q m (hm.trans_lt layerDegrees.2.1)
  have ip := bin_interior ends S Y h0 hends hY Q n (hw.trans_lt (layerDegrees.2.2.2.trans layerDegrees.2.1))
  have lo := binLaw_mono ends S Y Q m n io ip (fun A hA B hB =>
    (realized_score_accounting ends label h S hf H hlo hhi hends m n A B hA hB).1)
  have hi := binLaw_mono ends S Y Q m n io ip (fun A hA B hB =>
    (estimatedOutput_accounting ends label h S hf H ε hlo hhi hε hends m n estimate acc A B hA hB).2)
  have left : avg input-h ∅ ≤ avg (sampleTotal s)+H*avg collision := by
    have eqin := binLaw_linear ends S Y Q m n input collision 0 (h ∅)
    have eqs := binLaw_linear ends S Y Q m n (sampleTotal s) collision H 0
    simp only [zero_mul,add_zero,sub_zero] at eqin eqs
    simpa only [input,avg,s,←eqin,←eqs] using lo
  have right : avg (sampleTotal g) ≤ avg output + (2*S.card*H)*avg collision + 2*S.card*ε := by
    have eqout := binLaw_linear ends S Y Q m n output collision (2*S.card*H) (-(2*S.card*ε))
    simp only [sub_neg_eq_add] at eqout
    simpa only [output,avg,g,←eqout] using hi
  have raw : val ≤ avg input := binLaw_lemmaM2 ends S Y label Q m n io ip els k hcover hdistinct h hf
  have retain := finite_joint_score_retention ends label h S Y hf h0 hends hY Q m n hQ hn hm hw
  change gamma * avg (sampleTotal s) ≤ avg (sampleTotal g) at retain
  have gam : 0 ≤ gamma := by norm_num [gamma,retention,priorityArea,priorityLoss,rootHi,rootLo,degree,layerOne,layerTwo,discriminant]
  have cmp := mul_le_mul_of_nonneg_left ((sub_le_sub_right raw (h ∅)).trans left) gam
  change _ ≤ avg output
  linarith only [cmp,right,retain]

end SubmodularMatching.Shearer
