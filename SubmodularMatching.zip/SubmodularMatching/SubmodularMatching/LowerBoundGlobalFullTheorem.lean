import SubmodularMatching.LowerBoundGlobalAJXFamily
import SubmodularMatching.LowerBoundGlobalCoverage

/-! # The manuscript's Theorem 1.2 with its cited existence inputs -/

namespace SubmodularMatching.LowerBoundGlobal

open Filter LowerBoundAssembly MeasureTheory

universe u v

noncomputable section

/-- The hard family is fixed by the approximation ratio and word exponent.
The state type, randomness space and family of streaming programs are
chosen after that family is fixed. -/
theorem theorem1_2_of_ajx {R a : ℝ} (hR : 1 ≤ R) (hR3 : R < 3) (ha : 0 ≤ a)
    (ers : AJX.ERSFamilies) (bp : AJX.ProperBlueprintsNearTwoThirds) :
    ∃ (params : Parameters R) (family : BlueprintFamily params.densityLoss) (A : ℕ),
      a + 1 < (A : ℝ) ∧
      Tendsto (fun i => (BlueprintVertexCount params family (A : ℝ) i : ℝ)) atTop atTop ∧
      ∀ {State : ℕ → Type u} {Seed : ℕ → Type v}
        [∀ i, Fintype (State i)] [∀ i, Nonempty (State i)] [∀ i, MeasurableSpace (Seed i)]
        (μ : ∀ i, Measure (Seed i)) [∀ i, IsProbabilityMeasure (μ i)]
        (alg : ∀ i, BlueprintRandomProgram params family (A : ℝ) i (State i) (Seed i) (μ i))
        (space : WordSpace (BlueprintVertexCount params family (A : ℝ)) a),
        (∀ i, Fintype.card (State i) ≤ 2 ^ space.bits i) →
        ∀ prob > (0 : ℝ), ∀ᶠ i : ℕ in atTop,
          HasHardCounterexamples params family i (alg i) prob := by
  obtain ⟨params, ⟨family⟩⟩ := exists_blueprint_for_factor hR hR3 (AJX.blueprintFamilies_of_AJX ers bp)
  obtain ⟨A, hA⟩ := exists_nat_gt (a + 1)
  refine ⟨params, family, A, hA, blueprintVertexCount_tendsto_atTop params family, ?_⟩
  intro State Seed _ _ _ μ _ alg space hstates prob hprob
  exact factor_three_for_random_blueprint hR params family ha hA μ alg space hstates hprob

end

end SubmodularMatching.LowerBoundGlobal
