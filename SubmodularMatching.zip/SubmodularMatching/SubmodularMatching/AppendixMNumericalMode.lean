import SubmodularMatching.AppendixMNumericalEnvelope
import SubmodularMatching.AppendixMRescaledRates

namespace SubmodularMatching.AppendixM
open SourceCertificate

/-- Equation (26) for every real price pair and every ratio in each one of the
27,648 original mode intervals, with a uniform strict slack of one millionth. -/
theorem equation26_of_envelope (m : ℕ) (i j : Bool) (p : AppendixBoxParameters)
    (env : Envelope p (scaleDen m) i j)
    (valid : ∀ side, p.Bounds m side) (c : ℝ)
    (hcL : (rescaledRateTable.boundary m : ℝ) ≤ c)
    (hcH : c ≤ (rescaledRateTable.boundary (m+1) : ℝ))
    (a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d) :
    localTarget i j (rescaledRateTable.high m) (rescaledRateTable.low m) ≤
      localValue i j (rescaledRateTable.high m) (rescaledRateTable.low m) c a d := by
  obtain ⟨aLo, aHi, bLo, bHi, cLo, _⟩ := valid false
  obtain ⟨_, _, _, _, _, cHi⟩ := valid true
  have cLe (z w : ℕ) (h : z ≤ w) : (z : ℝ)/10^12 ≤ (w : ℝ)/10^12 :=
    div_le_div_of_nonneg_right (by exact_mod_cast h) (by norm_num)
  have rLe (z w : ℕ) (h : z ≤ w) : (z : ℝ)/scaleDen m ≤ (w : ℝ)/scaleDen m :=
    div_le_div_of_nonneg_right (by exact_mod_cast h) (Nat.cast_nonneg _)
  have hlo : ((appendixRawRatio m false : ℕ) : ℝ)/10^12 ≤ c := by
    calc
      _ = appendixRatio m false := by rw [appendixRawRatio_real]; norm_num [sourceScale]
      _ ≤ c := by simpa [appendixRatio, rescaledRateTable_boundary] using hcL
  have hhi : c ≤ ((appendixRawRatio m true : ℕ) : ℝ)/10^12 := by
    calc
      c ≤ appendixRatio m true := by simpa [appendixRatio, rescaledRateTable_boundary] using hcH
      _ = _ := by rw [appendixRawRatio_real]; norm_num [sourceScale]
  rw [rescaledRateTable_high_real, rescaledRateTable_low_real]
  exact env _ _ _ (rLe _ _ aLo) (rLe _ _ aHi) (rLe _ _ bLo) (rLe _ _ bHi)
    ((cLe _ _ cLo).trans hlo) (hhi.trans (cLe _ _ cHi)) _ _ ha hd

end SubmodularMatching.AppendixM
