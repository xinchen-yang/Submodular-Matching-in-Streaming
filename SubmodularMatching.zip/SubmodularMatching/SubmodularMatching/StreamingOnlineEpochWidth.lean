import SubmodularMatching.StreamingOnlineEpoch
import SubmodularMatching.StreamingOnlineFraction

/-!
# Width of dyadic guesses with bounded oracle words

A positive rational oracle value with numerator and denominator bounded by
`2^a` lies between `2^{-a}` and `2^a`. The online epoch keeps an actual
maximum and a previously seen anchor, so its dyadic exponents and scales
have bounded bit width under the same input encoding convention.
-/

namespace SubmodularMatching.Streaming

theorem fractionBound_abs_le (q : ℚ) (B : ℕ) (hb : FractionBound q B) :
    |q| ≤ (B : ℚ) := by
  have hd : (1 : ℚ) ≤ (q.den : ℚ) := by exact_mod_cast (Nat.one_le_iff_ne_zero.2 q.den_ne_zero)
  have hn : |(q.num : ℚ)| ≤ (B : ℚ) := by
    rw [← Int.cast_abs, ← Nat.cast_natAbs]
    exact_mod_cast hb.1
  have hden : 0 ≤ (q.den : ℚ) := Nat.cast_nonneg _
  rw [← Rat.num_div_den q, abs_div, abs_of_nonneg hden]
  apply (div_le_iff₀ (by exact_mod_cast q.den_pos)).2
  exact hn.trans (le_mul_of_one_le_right (by positivity) hd)

theorem fractionBound_recip_le (q : ℚ) (B : ℕ) (hb : FractionBound q B) (hq : 0 < q) :
    1 / (B : ℚ) ≤ q := by
  have h := fractionBound_abs_le q⁻¹ B hb.inv
  rw [abs_of_nonneg (inv_nonneg.2 hq.le)] at h
  have hB : (0 : ℚ) < B := by exact_mod_cast q.den_pos.trans_le hb.2
  rw [one_div]
  exact (inv_le_comm₀ hB hq).2 h

private theorem fractionBound_max {x y : ℚ} {B : ℕ}
    (hx : FractionBound x B) (hy : FractionBound y B) : FractionBound (max x y) B := by
  rw [max_def]
  split_ifs
  · exact hy
  · exact hx

/-- Both saved absolute values remain within the original oracle-word bound. -/
theorem runOnlineEpoch_values_bounded (W : ℚ) (span : ℕ) (value : ℕ → ℚ) (n B : ℕ)
    (hB : 0 < B) (hv : ∀ i < n, FractionBound (value i) B) :
    FractionBound (runOnlineEpoch W span value n).best B ∧
      FractionBound (runOnlineEpoch W span value n).anchor B := by
  induction n with
  | zero => exact ⟨FractionBound.zero hB, FractionBound.zero hB⟩
  | succ n ih =>
    obtain ⟨hb, ha⟩ := ih (fun i hi => hv i (Nat.lt_succ_of_lt hi))
    have hnew := fractionBound_max hb (hv n (Nat.lt_succ_self _))
    rw [runOnlineEpoch]
    unfold OnlineEpoch.step
    dsimp only
    split_ifs
    · exact ⟨hnew, hnew⟩
    · exact ⟨hnew, ha⟩

/-- Exponents fit in twice the oracle width plus the active window width. -/
theorem OnlineEpoch.active_exponent_word_bound (st : OnlineEpoch) (hs : st.Valid)
    (j a span : ℕ) (W : ℚ)
    (hb : FractionBound st.best (2 ^ a)) (ha : FractionBound st.anchor (2 ^ a))
    (h : j ∈ st.active W span) :
    j ≤ 2 * a + span := by
  have hbest : 0 < st.best := by
    by_contra! hp
    simp [OnlineEpoch.active, hp.not_gt] at h
  have hcap : st.best ≤ (↑(2 ^ a : ℕ) : ℚ) :=
    (le_abs_self _).trans (fractionBound_abs_le _ _ hb)
  have has : 1 / (↑(2 ^ a : ℕ) : ℚ) ≤ st.anchor :=
    fractionBound_recip_le _ _ ha (hs.positive hbest)
  have hscale : st.best ≤ st.scale (2 * a) := by
    unfold OnlineEpoch.scale
    push_cast at hcap has
    rw [mul_comm 2 a, pow_mul, pow_two]
    refine hcap.trans ?_
    calc
      _ = (1 / (2 : ℚ) ^ a) * ((2 : ℚ) ^ a * (2 : ℚ) ^ a) := by field_simp
      _ ≤ _ := mul_le_mul_of_nonneg_right has (by positivity)
  have hleast : st.least ≤ 2 * a := by
    by_contra! hlt
    exact (hs.minimal _ hlt).not_ge hscale
  have hj : j ≤ st.least + span := by
    unfold OnlineEpoch.active at h
    rw [if_pos hbest, List.mem_filter, List.mem_map] at h
    obtain ⟨⟨i, hi, rfl⟩, -⟩ := h
    rw [List.mem_range] at hi
    omega
  omega

/-- The actual rational scale uses a numerator and denominator bounded
by the original oracle width, the lower index, and the window. -/
theorem OnlineEpoch.active_scale_word_bound (st : OnlineEpoch) (hs : st.Valid)
    (j a span : ℕ) (W : ℚ)
    (hb : FractionBound st.best (2 ^ a)) (ha : FractionBound st.anchor (2 ^ a))
    (h : j ∈ st.active W span) :
    FractionBound (st.scale j) (2 ^ (3 * a + span)) := by
  have hj := st.active_exponent_word_bound hs j a span W hb ha h
  have hp : FractionBound ((2 : ℚ) ^ j) (2 ^ j) := by
    change FractionBound ((↑(2 : ℕ) : ℚ) ^ j) (2 ^ j)
    rw [← Nat.cast_pow]
    simp [FractionBound, Nat.one_le_pow]
  refine (ha.mul hp).mono ?_
  rw [← pow_add]
  exact Nat.pow_le_pow_right (by decide : 0 < 2) (by omega)

end SubmodularMatching.Streaming
