import SubmodularMatching.ProjectedShearerJointScan
import SubmodularMatching.ShearerTimeCloneLaw

/-! # First-stage projected value of the finite priority matching -/

namespace SubmodularMatching.Shearer
open GibbsMatching AppendixM
open scoped BigOperators

variable {E V L : Type*} [DecidableEq E] [DecidableEq V] [DecidableEq L]
variable (ends : E → Finset V) (S : Finset E) (Y : E → ℝ) (label : E → L)

noncomputable def binLaw (Q m n : ℕ) :=
  markedPair (binEnds ends) (binSupport S m) (binSupport S n) (binMass Y Q) (binMass Y Q)

noncomputable def unalteredMarginal (Q m n : ℕ) (l : L) :=
  binLaw ends S Y Q m n (fun A B => if l ∈ (A∪B).image (binLabel label) then 1 else 0)

theorem binLaw_mono (Q m n : ℕ)
    (io : InteriorLaw (binEnds ends) (binSupport S m) (binMass Y Q))
    (ip : InteriorLaw (binEnds ends) (binSupport S n) (binMass Y Q))
    {F G : Finset (E×ℕ) → Finset (E×ℕ) → ℝ}
    (hFG : ∀ A ∈ matchings (binEnds ends) (binSupport S m), ∀ B ∈ matchings (binEnds ends) (binSupport S n), F A B ≤ G A B) :
    binLaw ends S Y Q m n F ≤ binLaw ends S Y Q m n G := by
  unfold binLaw markedPair expectation
  exact Finset.sum_le_sum (fun A hA => mul_le_mul_of_nonneg_left (Finset.sum_le_sum (fun B hB =>
    mul_le_mul_of_nonneg_left (hFG A hA B hB) (ip.nonneg B hB))) (io.nonneg A hA))

theorem binLaw_linear (Q m n : ℕ) (F G : Finset (E×ℕ) → Finset (E×ℕ) → ℝ) (c d : ℝ) :
    binLaw ends S Y Q m n (fun A B => F A B + c*G A B - d) =
    binLaw ends S Y Q m n F + c * binLaw ends S Y Q m n G - d := by
  unfold binLaw markedPair
  simp_rw [expectation_sub,expectation_add,expectation_const_mul,expectation_const]

/-- Erasing the independent uniform marks recovers the two original
Shearer samples, so the marginal used by M.2 is the original calibrated
union marginal, also for multiple disjoint copies of a label. -/
theorem unalteredMarginal_original (Q m n : ℕ) (hm : 0 < m) (hn : 0 < n)
    (hends : ∀ e ∈ S, (ends e).card = 2) (l : L) :
    let base (k : ℕ) (a : E) := (k:ℝ)/Q/degree*Y a
    unalteredMarginal ends S Y label Q m n l = markedPair ends S S (base m) (base n)
      (fun A B => if l ∈ (A ∪ B).image label then 1 else 0) := by
  intro base
  have hend (e : E) (he : e ∈ S) : (ends e).Nonempty := Finset.card_pos.mp (by rw [hends _ he]; norm_num)
  have agree (k : ℕ) (hk : 0 < k) : binMass Y Q = fun c : E×ℕ => base k c.1/k := by
    funext c
    have hk' : (k:ℝ) ≠ 0 := by exact_mod_cast hk.ne'
    dsimp [binMass,base]
    field_simp
    <;> ring
  have pull (k : ℕ) (hk : 0 < k) (f : Finset E → ℝ) :
      expectation (binEnds ends) (binSupport S k) (binMass Y Q) (fun A => f (A.image Prod.fst)) =
      expectation ends S (base k) f := by
    rw [agree k hk]
    exact timeClone_projected_expectation ends S (base k) k hk hend f
  let f (A B : Finset E) : ℝ := if l ∈ (A∪B).image label then 1 else 0
  unfold unalteredMarginal binLaw markedPair
  have heq (A B : Finset (E×ℕ)) : (if l ∈ (A∪B).image (binLabel label) then (1:ℝ) else 0) =
      f (A.image Prod.fst) (B.image Prod.fst) := by simp only [f,←Finset.image_union,Finset.image_image,Function.comp_def]; rfl
  simp_rw [heq]
  simp_rw [pull n hn]
  exact pull m hm (fun A => expectation ends S (base n) (f A))

theorem binLaw_lemmaM2 (Q m n : ℕ)
    (io : InteriorLaw (binEnds ends) (binSupport S m) (binMass Y Q))
    (ip : InteriorLaw (binEnds ends) (binSupport S n) (binMass Y Q))
    (els : ℕ → L) (k : ℕ) (hcover : S.image label ⊆ replacementPrefix els k)
    (hdistinct : ∀ i < k, ∀ j < k, els i = els j → i = j) (h : Finset L → ℝ) (hf : IsSubmodular h) :
    bernoulliExpectation els (fun i => unalteredMarginal ends S Y label Q m n (els i)) h k ≤
      binLaw ends S Y Q m n (fun A B => h ((A∪B).image (binLabel label))) := by
  let a : LabelLayer (E×ℕ) V L := ⟨binEnds ends,binSupport S m,binMass Y Q,binLabel label,io⟩
  let b : LabelLayer (E×ℕ) V L := ⟨binEnds ends,binSupport S n,binMass Y Q,binLabel label,ip⟩
  have hc (j : ℕ) : (binSupport S j).image (binLabel label) ⊆ replacementPrefix els k := by
    intro l hl
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hl
    exact hcover (Finset.mem_image_of_mem label (Finset.mem_product.mp hi).1)
  have layers : ∀ t ∈ [a,b], t.support.image t.label ⊆ replacementPrefix els k := by
    intro t ht
    simp only [List.mem_cons,List.not_mem_nil,or_false] at ht
    rcases ht with rfl | rfl
    · exact hc _
    · exact hc _
  have ident (f : Finset L → ℝ) : LabelLayer.unionAvg [a,b] f = binLaw ends S Y Q m n (fun A B => f ((A∪B).image (binLabel label))) := by
    simp only [LabelLayer.unionAvg,LabelLayer.average,a,b,Finset.union_empty,binLaw,markedPair,Finset.image_union]
  have marg (i : ℕ) : LabelLayer.unionMarginal [a,b] (els i) = unalteredMarginal ends S Y label Q m n (els i) :=
    (LabelLayer.unionMarginal_correct [a,b] (els i)).symm.trans (ident _)
  have hm2 := LabelLayer.lemmaM2_independent_layers [a,b] els k layers hdistinct h hf
  simpa only [marg,ident] using hm2

/-- On one joint law the finite first-stage output is a slot matching and
its expected gain dominates the calibrated multilinear gain with the
explicit finite-time collision allowance. -/
theorem finite_priority_output [LinearOrder E] (h : Finset L → ℝ) (hf : IsSubmodular h) (H : ℝ)
    (hlo : ∀ U, 0 ≤ h U) (hhi : ∀ U, h U ≤ H) (h0 : ∀ e ∈ S, 0 ≤ Y e)
    (hends : ∀ a ∈ S, (ends a).card = 2) (hY : ∀ w, ∑ a ∈ incident ends S w, Y a ≤ degree)
    (Q m n : ℕ) (hQ : 0 < Q) (hn : 0 < n) (hm : (m:ℝ)/Q = layerOne) (hw : (n:ℝ)/Q = layerTwo)
    (els : ℕ → L) (k : ℕ) (hcover : S.image label ⊆ replacementPrefix els k)
    (hdistinct : ∀ i < k, ∀ j < k, els i = els j → i = j) :
    let avg := binLaw ends S Y Q m n
    let val := bernoulliExpectation els (fun i => unalteredMarginal ends S Y label Q m n (els i)) h k
    (∀ A B, Streaming.IsMatchingOn (binEnds ends) (markedOutput ends label h A B)) ∧
    gamma * (val - h ∅) - ((gamma+2*S.card)*H) * avg collision ≤
      avg (fun A B => h ((markedOutput ends label h A B).image (binLabel label))-h ∅) := by
  intro avg val
  refine ⟨markedOutput_matching ends label h hf, ?_⟩
  let s := scoreAt (binEnds ends) (binLabel label) h Prod.snd
  let g := survivingAt (binEnds ends) (binLabel label) h Prod.snd
  let input := fun A B : Finset (E×ℕ) => h ((A∪B).image (binLabel label))
  let output := fun A B : Finset (E×ℕ) => h ((markedOutput ends label h A B).image (binLabel label))-h ∅
  have io := bin_interior ends S Y h0 hends hY Q m (hm.trans_lt layerDegrees.2.1)
  have ip := bin_interior ends S Y h0 hends hY Q n (hw.trans_lt (layerDegrees.2.2.2.trans layerDegrees.2.1))
  have ha (A : Finset (E×ℕ)) (hA : A ∈ matchings (binEnds ends) (binSupport S m)) (B : Finset (E×ℕ))
      (hB : B ∈ matchings (binEnds ends) (binSupport S n)) := realized_score_accounting ends label h S hf H hlo hhi hends m n A B hA hB
  have lo := binLaw_mono ends S Y Q m n io ip (fun A hA B hB => (ha A hA B hB).1)
  have hi := binLaw_mono ends S Y Q m n io ip (fun A hA B hB => (ha A hA B hB).2)
  have left : avg input - h ∅ ≤ avg (sampleTotal s) + H * avg collision := by
    have eqin := binLaw_linear ends S Y Q m n input collision 0 (h ∅)
    have eqs := binLaw_linear ends S Y Q m n (sampleTotal s) collision H 0
    simp only [zero_mul,add_zero,sub_zero] at eqin eqs
    simpa only [input,avg,s,← eqin,← eqs] using lo
  have right : avg (sampleTotal g) ≤ avg output + (2*S.card*H)*avg collision := by
    have eqg := binLaw_linear ends S Y Q m n output collision (2*S.card*H) 0
    simp only [sub_zero] at eqg
    simpa only [output,avg,g,← eqg] using hi
  have raw : val ≤ avg input := binLaw_lemmaM2 ends S Y label Q m n io ip els k hcover hdistinct h hf
  have retain := finite_joint_score_retention ends label h S Y hf h0 hends hY Q m n hQ hn hm hw
  change gamma * avg (sampleTotal s) ≤ avg (sampleTotal g) at retain
  have gam : 0 ≤ gamma := by norm_num [gamma,retention,priorityArea,priorityLoss,rootHi,rootLo,degree,layerOne,layerTwo,discriminant]
  have cmp := mul_le_mul_of_nonneg_left ((sub_le_sub_right raw (h ∅)).trans left) gam
  change _ ≤ avg output
  linarith only [cmp,retain,right]

end SubmodularMatching.Shearer
