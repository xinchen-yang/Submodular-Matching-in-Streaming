import SubmodularMatching.NumericalReplayLastRows
import SubmodularMatching.SourceDataActual

/-! # The four local classes at the final rate boundary -/

namespace SubmodularMatching.SourceCertificate.Replay

open SourceRateTable


private theorem rational_height_at_knot (T : SourcePotentialTable) (b : Bool) (k : ℕ)
    (hk : k ≤ T.count) :
    rationalInterpolate T.count T.knot (T.height b) (T.knot k) = T.height b k := by
  apply Rat.cast_injective (α := ℝ)
  rw [← T.evaluate]
  change T.value b (T.realKnot k) = T.realHeight b k
  rcases hk.eq_or_lt with rfl | hk
  · exact T.value_tail _ _ le_rfl
  · rw [T.value_affine b k hk _ le_rfl (T.ordered k hk).le]
    ring

/-- Full Boolean checks of the last endpoint at all four combinations of
covered and uncovered endpoints. This is the endpoint that attains the
published minimum slack. -/
theorem last_endpoint_checked (i j : Bool) :
    appendixPotentialTable.checkTableEndpoint (finalHigh i) ((1-appendixDegree*bitQ j)*lastLow)
      (finalCapacity i j) 1 (finalTarget i j) i j = true := by
  let T := appendixPotentialTable
  have h1 : T.knot 230 = 1 := final_knot_230
  have he (b : Bool) (k : ℕ) (hk : k ≤ 1135) :
      rationalInterpolate T.count T.knot (T.height b) (T.knot k) = height b k :=
    rational_height_at_knot T b k hk
  have h0 : rationalInterpolate T.count T.knot (T.height j) 0 = 0 := by
    have h := he j 0 (by decide)
    rw [T.first_knot, (height_initial j).1] at h
    exact h
  have lone : finalTarget i j ≤ finalHigh i * height i 230 := by
    have hh := final_knot_bound i j 230 le_rfl
    rw [finalValue, final_knot_230, sub_self, mul_zero, add_zero] at hh
    exact (le_add_of_nonneg_right (by decide +kernel : 0 ≤ lastSlack)).trans hh
  have hatOne : rationalInterpolate T.count T.knot (T.height i) 1 = height i 230 := by
    have hh := he i 230 (by decide)
    rwa [h1] at hh
  unfold SourcePotentialTable.checkTableEndpoint checkRationalEndpoint
  simp only [if_true, Bool.and_eq_true, decide_eq_true_eq, List.all_eq_true, one_div_one]
  change (finalTarget i j ≤ finalHigh i * rationalInterpolate T.count T.knot (T.height i) 1 +
    _ * rationalInterpolate T.count T.knot (T.height j) 0) ∧
    ∀ x ∈ (T.axisKnots 1).reverse, x ≤ 1 → finalTarget i j ≤
      finalHigh i * rationalInterpolate T.count T.knot (T.height i) x +
      _ * rationalInterpolate T.count T.knot (T.height j) 0 + finalCapacity i j*(1-x)
  rw [h0, mul_zero, add_zero, hatOne]
  refine ⟨lone, ?_⟩
  intro x hx hx1
  rw [add_zero]
  rcases (T.in_axisKnots 1 x).mp (List.mem_reverse.mp hx) with rfl | ⟨hlt, k, hk, rfl⟩
  · rwa [sub_self, mul_zero, add_zero, hatOne]
  · have hk230 : k ≤ 230 := by
      by_contra! hn
      have hr := T.ordered.lt hn hk
      unfold SourcePotentialTable.realKnot at hr
      have hr' : T.knot 230 < T.knot k := by exact_mod_cast hr
      rw [h1] at hr'
      exact (not_lt_of_ge hr'.le) hlt
    rw [he i k hk]
    exact (le_add_of_nonneg_right (by decide +kernel : 0 ≤ lastSlack)).trans
      (final_knot_bound i j k hk230)

/-- At the last endpoint, every pair of nonnegative real prices satisfies
the source inequality with the actual two rate constants. -/
theorem last_endpoint_real (i j : Bool) (a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d) :
    (finalTarget i j : ℝ) ≤ gridValue
      (fun x => (finalHigh i : ℝ) * appendixPotentialTable.value i x)
      (fun y => (((1-appendixDegree*bitQ j)*lastLow : ℚ) : ℝ) * appendixPotentialTable.value j y)
      (finalCapacity i j : ℝ) 1 a d := by
  simpa only [Rat.cast_one] using
    appendixPotentialTable.checkTableEndpoint_sound (finalHigh i) ((1-appendixDegree*bitQ j)*lastLow)
      (finalCapacity i j) 1 (finalTarget i j) i j (by decide +kernel) le_rfl
      (by cases i <;> decide +kernel) (by cases j <;> decide +kernel)
      (last_endpoint_checked i j) a d ha hd

end SubmodularMatching.SourceCertificate.Replay
