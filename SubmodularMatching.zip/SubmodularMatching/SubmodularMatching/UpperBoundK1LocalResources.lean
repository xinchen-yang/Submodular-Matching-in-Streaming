import SubmodularMatching.StreamingK1Space
import SubmodularMatching.UpperBoundK1Schedule
import SubmodularMatching.UpperBoundVertexPairScan
import SubmodularMatching.TwoStageSeparateTape

/-! # Local loop sizes for the generic finite optimizer and rounding -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint GibbsSampler ShearerSampler TwoStage
open scoped BigOperators

noncomputable section

variable {m : ℕ} {V : Type*} [DecidableEq V]

/-- Euler stages are quadratic uniformly over the permitted degree cap. -/
theorem k1Optimizer_stages_le (D : ℝ) (hD : 0 ≤ D) (hD1 : D ≤ 1)
    (k : ℕ) (hk : 8 < k) (m : ℕ) :
    FiniteGreedy.stages D m (k1Epsilon k) ≤ (k + 1) * (m + 1) ^ 2 := by
  have h := stages_polynomial D (k1Epsilon k) m hD hD1 (k1Epsilon_bounds k hk).1
  have hcast : (FiniteGreedy.stages D m (k1Epsilon k) : ℝ) ≤ k * (m : ℝ) ^ 2 + 1 := by
    convert h using 1
    unfold k1Epsilon
    rw [div_div_eq_mul_div]
    ring
  have hNat : FiniteGreedy.stages D m (k1Epsilon k) ≤ k * m ^ 2 + 1 := by
    exact_mod_cast hcast
  calc
    _ ≤ k * m ^ 2 + 1 := hNat
    _ ≤ k * (m + 1) ^ 2 + (m + 1) ^ 2 :=
      Nat.add_le_add (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (Nat.le_succ m) _))
        (one_le_pow₀ (by omega))
    _ = _ := by ring

/-- The common denominator and projected iterations have polynomial
sizes at every fixed reciprocal direction tolerance. -/
theorem packing_loop_bounds_of_reciprocal (b : ℕ) (hb : 0 < b) (hm : 0 < m)
    (ends : Fin m → V × V) :
    let v := Fintype.card (IncidentVertex ends)
    let M := v + (v + m)
    let N := m + m
    Nat.ceil (4 * (N : ℝ) ^ 2 / (1 / (b : ℝ))) ≤ (20 * b) * (m + 1) ^ 2 ∧
      LinearPacking.iterationCount M N (1 / (b : ℝ)) ≤ (160000 * b ^ 4 + 1) * (m + 1) ^ 8 ∧
      LinearPacking.rationalOutputDenominator M N 1 b ≤
        ((160000 * b ^ 4 + 1) * (5 * b)) * (m + 1) ^ 9 := by
  intro v M N
  have hv : v ≤ 2 * m := incidentVertex_card_le ends
  have hM : 0 < M := by dsimp [M]; omega
  have hM' : M ≤ 5 * (m + 1) := by dsimp [M]; omega
  have hN : 0 < N := by dsimp [N]; omega
  have hN' : N ≤ 2 * (m + 1) := by dsimp [N]; omega
  have h := LinearPacking.rational_iteration_resources M N 1 b hM hN (by decide) hb (by omega)
  simp only [Nat.cast_one] at h
  have hJ : 100 * M ^ 2 * N ^ 6 * b ^ 4 + 1 ≤ (160000 * b ^ 4 + 1) * (m + 1) ^ 8 := by
    calc
      _ ≤ 100 * (5 * (m + 1)) ^ 2 * (2 * (m + 1)) ^ 6 * b ^ 4 + (m + 1) ^ 8 :=
        Nat.add_le_add (Nat.mul_le_mul_right _ (Nat.mul_le_mul
          (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM' _)) (Nat.pow_le_pow_left hN' _)))
          (one_le_pow₀ (by omega))
      _ = _ := by ring
  refine ⟨h.1.trans ?_, h.2.1.trans hJ, h.2.2.trans ?_⟩
  · calc
      _ ≤ 5 * (2 * (m + 1)) ^ 2 * b := by gcongr
      _ = _ := by ring
  · have hN0 : 2 * N * b + b ≤ (5 * b) * (m + 1) := by
      calc
        _ ≤ 2 * (2 * (m + 1)) * b + b * (m + 1) :=
          Nat.add_le_add (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ hN'))
            (Nat.le_mul_of_pos_right _ (by omega))
        _ = _ := by ring
    calc
      _ ≤ ((160000 * b ^ 4 + 1) * (m + 1) ^ 8) * ((5 * b) * (m + 1)) :=
        Nat.mul_le_mul hJ hN0
      _ = _ := by ring

theorem k1DirectionTolerance (k : ℕ) : k1Epsilon k / 8 = 1 / ((4 * k : ℕ) : ℝ) := by
  unfold k1Epsilon
  push_cast
  by_cases h : k = 0
  · simp [h]
  · have h' : (k : ℝ) ≠ 0 := by exact_mod_cast h
    field_simp [h'] <;> ring

/-- The exact compact direction loop gives `O(m^11)` visits per guess,
including the scalar recurrence on the common discount grid. -/
theorem k1Packing_visits_all_stages (D : ℝ) (hD : 0 ≤ D) (hD1 : D ≤ 1)
    (k : ℕ) (hk : 8 < k) (hm : 0 < m) (ends : Fin m → V × V) :
    let v := Fintype.card (IncidentVertex ends)
    let K := FiniteGreedy.stages D m (k1Epsilon k)
    let J := LinearPacking.iterationCount (v + (v + m)) (m + m) (k1Epsilon k / 8)
    K * J * compactDirectionScalarVisits v m + K ^ 2 ≤
      ((k + 1) * (160000 * (4 * k) ^ 4 + 1) * 19 + (k + 1) ^ 2) * (m + 1) ^ 11 := by
  intro v K J
  let C := (k + 1) * (160000 * (4 * k) ^ 4 + 1) * 19
  have hK := k1Optimizer_stages_le D hD hD1 k hk m
  have hJ : J ≤ (160000 * (4 * k) ^ 4 + 1) * (m + 1) ^ 8 := by
    dsimp only [J]
    rw [k1DirectionTolerance]
    exact (packing_loop_bounds_of_reciprocal (4 * k) (by omega) hm ends).2.1
  have hscalar : compactDirectionScalarVisits v m ≤ 19 * (m + 1) :=
    (compactDirectionScalarVisits_le ends).trans (Nat.mul_le_mul_left _ (Nat.le_succ _))
  have hpack : K * J * compactDirectionScalarVisits v m ≤ C * (m + 1) ^ 11 := by
    calc
      _ ≤ ((k + 1) * (m + 1) ^ 2) * ((160000 * (4 * k) ^ 4 + 1) * (m + 1) ^ 8) *
          (19 * (m + 1)) := Nat.mul_le_mul (Nat.mul_le_mul hK hJ) hscalar
      _ = _ := by dsimp only [C]; ring
  have hdisc : K ^ 2 ≤ (k + 1) ^ 2 * (m + 1) ^ 11 := by
    calc
      _ ≤ ((k + 1) * (m + 1) ^ 2) ^ 2 := Nat.pow_le_pow_left hK _
      _ = (k + 1) ^ 2 * (m + 1) ^ 4 := by ring
      _ ≤ _ := Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) (by decide))
  exact (Nat.add_le_add hpack hdisc).trans_eq (by dsimp only [C]; ring)

theorem k1Accuracy_inv_le (D : ℝ) (hD : 0 < D) (hD1 : D ≤ 1)
    (k : ℕ) (hk : 8 < k) (hm : 0 < m) :
    (FiniteGreedy.accuracy D m (k1Epsilon k))⁻¹ ≤ (16 * (k : ℝ)) * (m + 1 : ℕ) := by
  have hm' : (0 : ℝ) < m := by exact_mod_cast hm
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast (show 1 ≤ k by omega)
  have hb : (0 : ℝ) < (16 * (k : ℝ)) * (m + 1 : ℕ) := by positivity
  have he := (k1Epsilon_bounds k hk).1
  have hξ : 0 < FiniteGreedy.accuracy D m (k1Epsilon k) := by
    unfold FiniteGreedy.accuracy
    exact lt_min (by norm_num) (by positivity)
  rw [← one_div, div_le_iff₀ hξ]
  rw [mul_comm (16 * (k : ℝ) * (m + 1 : ℕ)) (FiniteGreedy.accuracy D m (k1Epsilon k))]
  apply (div_le_iff₀ hb).1
  unfold FiniteGreedy.accuracy
  apply le_min
  · rw [div_le_iff₀ hb]
    push_cast
    have hM : (1 : ℝ) ≤ (m : ℝ) + 1 := by linarith [show (0 : ℝ) ≤ m from Nat.cast_nonneg m]
    nlinarith only [hk1, hM, mul_le_mul hk1 hM (by norm_num) (by positivity)]
  · have hden : 0 < 16 * D * (m : ℝ) := by positivity
    rw [div_le_div_iff₀ hb hden]
    have hDm := mul_le_mul_of_nonneg_right hD1 hm'.le
    have hcoeff : k1Epsilon k * (16 * (k : ℝ)) = 32 := by
      unfold k1Epsilon
      have hk0 : (k : ℝ) ≠ 0 := by exact_mod_cast (show k ≠ 0 by omega)
      field_simp [hk0] <;> norm_num
    push_cast
    rw [← mul_assoc (k1Epsilon k) (16 * (k : ℝ)), hcoeff]
    nlinarith only [hDm, hm'.le]

private theorem ceilLog_le_of_polynomial {x C d m : ℕ} (h : x ≤ C * (m + 1) ^ d) :
    Nat.clog 2 x ≤ (d + C.log2 + 1) * ((m + 1).log2 + 1) :=
  Nat.clog_le_of_le_pow (polynomial_index_word_bound h).le

def k1ShearerFuelConstant (denominator k : ℕ) : ℕ :=
  denominator ^ 2 * (2 + (32 * k).log2 + 1)

def k1ShearerAttemptsConstant (denominator k : ℕ) : ℕ :=
  3 + (16 * k * (16 * (k1ShearerFuelConstant denominator k) + 1)).log2 + 1

/-- For fixed rational input parameters, both rejection and recursion
counters of the actual first word sampler use logarithmically many bits. -/
theorem k1Shearer_budget {E : Type*} (c : RationalShearerInput E) (k vertices m : ℕ)
    (hv : vertices ≤ 2 * m) :
    let D := 4 * vertices * k
    let L := separateTapeFuel c m D
    let B := separateTapeAttempts m L D
    let w := (m + 1).log2 + 1
    L ≤ k1ShearerFuelConstant c.b k * w ∧ B ≤ k1ShearerAttemptsConstant c.b k * w := by
  intro D L B w
  have hD : D ≤ (8 * k) * (m + 1) := by
    calc
      D ≤ 4 * (2 * (m + 1)) * k := by
        dsimp only [D]
        exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (hv.trans (Nat.mul_le_mul_left _ (Nat.le_succ _))))
      _ = _ := by ring
  have hfuel : L ≤ k1ShearerFuelConstant c.b k * w := by
    dsimp only [L, separateTapeFuel, k1ShearerFuelConstant]
    rw [Nat.mul_assoc (c.b ^ 2) (2 + (32 * k).log2 + 1) w]
    apply Nat.mul_le_mul_left
    apply ceilLog_le_of_polynomial
    calc
      _ ≤ 4 * (m + 1) * ((8 * k) * (m + 1)) := Nat.mul_le_mul_left _ hD
      _ = _ := by ring
  refine ⟨hfuel, ?_⟩
  let F := k1ShearerFuelConstant c.b k
  have hw : w ≤ 2 * (m + 1) := by
    have hh := Nat.log2_le_self (m + 1)
    dsimp [w]
    omega
  have hL : 8 * L + 1 ≤ (16 * F + 1) * (m + 1) := by
    calc
      _ ≤ 8 * (F * (2 * (m + 1))) + (m + 1) :=
        Nat.add_le_add (Nat.mul_le_mul_left _ (hfuel.trans (Nat.mul_le_mul_left _ hw))) (by omega)
      _ = _ := by ring
  dsimp only [B, separateTapeAttempts, k1ShearerAttemptsConstant]
  apply ceilLog_le_of_polynomial
  calc
    _ ≤ 2 * (m + 1) * ((16 * F + 1) * (m + 1)) * ((8 * k) * (m + 1)) :=
      Nat.mul_le_mul (Nat.mul_le_mul_left _ hL) hD
    _ = _ := by dsimp only [F]; ring

/-- Work in the integer samplers, adjusted for stored-vertex scans, the
maximum number of primitive words per first-stage trial, and the exact
activity calculation before running the second sampler. -/
def k1RoundVisitBudget {E : Type*} (c : RationalShearerInput E) (k vertices stored active : ℕ) : ℕ :=
  let D := 4 * vertices * k
  let L := separateTapeFuel c stored D
  let B := separateTapeAttempts stored L D
  let T := lowActivitySteps vertices active (lowActivityPrecision D)
  stored * (8 * L + 1) * B * (stored + 1) + T * active + 6 * (stored + 1) ^ 3

def k1RoundVisitConstant (denominator k : ℕ) : ℕ :=
  (16 * (k1ShearerFuelConstant denominator k) + 1) * (2 * (k1ShearerAttemptsConstant denominator k)) +
    40 * (1 + 2 * (8 * k + 1)) + 6

theorem k1RoundVisitBudget_le {E : Type*} (c : RationalShearerInput E) (k vertices m active : ℕ)
    (hv : vertices ≤ 2 * m) (ha : active ≤ m) :
    k1RoundVisitBudget c k vertices m active ≤ k1RoundVisitConstant c.b k * (m + 1) ^ 8 := by
  let D := 4 * vertices * k
  let L := separateTapeFuel c m D
  let B := separateTapeAttempts m L D
  let F := k1ShearerFuelConstant c.b k
  let A := k1ShearerAttemptsConstant c.b k
  let w := (m + 1).log2 + 1
  let T := lowActivitySteps vertices active (lowActivityPrecision D)
  have hw : w ≤ 2 * (m + 1) := by
    have h := Nat.log2_le_self (m + 1)
    dsimp [w]
    omega
  obtain ⟨hL, hB⟩ := k1Shearer_budget c k vertices m hv
  have hL' : 8 * L + 1 ≤ (16 * F + 1) * (m + 1) := by
    calc
      _ ≤ 8 * (F * (2 * (m + 1))) + (m + 1) :=
        Nat.add_le_add (Nat.mul_le_mul_left _ (hL.trans (Nat.mul_le_mul_left _ hw))) (by omega)
      _ = _ := by ring
  have hB' : B ≤ (2 * A) * (m + 1) := by
    exact hB.trans ((Nat.mul_le_mul_left A hw).trans_eq (by ring))
  have hS : m * (8 * L + 1) * B * (m + 1) ≤ ((16 * F + 1) * (2 * A)) * (m + 1) ^ 8 := by
    calc
      _ ≤ (m + 1) * ((16 * F + 1) * (m + 1)) * ((2 * A) * (m + 1)) * (m + 1) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul (Nat.mul_le_mul (Nat.le_succ _) hL') hB')
      _ = ((16 * F + 1) * (2 * A)) * (m + 1) ^ 4 := by ring
      _ ≤ _ := Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) (by decide))
  have hG : T * active ≤ (40 * (1 + 2 * (8 * k + 1))) * (m + 1) ^ 8 := by
    have hT := (parametricGibbs_budget k vertices m active hv ha).1
    calc
      _ ≤ (40 * (1 + 2 * (8 * k + 1)) * (m + 1) ^ 7) * (m + 1) :=
        Nat.mul_le_mul hT (ha.trans (Nat.le_succ _))
      _ = _ := by ring
  have hR : 6 * (m + 1) ^ 3 ≤ 6 * (m + 1) ^ 8 :=
    Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) (by decide))
  calc
    _ ≤ ((16 * F + 1) * (2 * A)) * (m + 1) ^ 8 +
        (40 * (1 + 2 * (8 * k + 1))) * (m + 1) ^ 8 + 6 * (m + 1) ^ 8 :=
      Nat.add_le_add (Nat.add_le_add hS hG) hR
    _ = _ := by dsimp only [F, A, k1RoundVisitConstant]; ring

end

end SubmodularMatching.UpperBoundAssembly
