import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardLast

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000
theorem chunk73 : ProjectedGoal ⟨55242,55295,0,70,1081,1099⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.m (.leaf 0xd7cbd7ca00000bd2cccd7207) (.leaf 0xd7cdd7cc01d1a94a20cd7662)) (.leaf 0xd7d0d7ce1d1a94a200cd7c5f)) (.leaf 0xd7d7d7d1e8d4a51000cd7049)) (.leaf 0xd7e4d7d8e8d4a51000cd7049)) (.leaf 0xd7ffd7e5e8d4a51000cd7049)) (by decide +kernel)
theorem chunk77 : ProjectedGoal ⟨55080,55106,0,70,1099,1135⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.leaf 0xd729d7280000000000cd8191) (.leaf 0xd72bd72a0000000000cd8191)) (.m (.leaf 0xd72dd72c0000000000cd8191) (.leaf 0xd72ed72e0000000000cd8191))) (.m (.m (.m (.leaf 0xd72fd72f0000000000cd8191) (.leaf 0xd730d7300000000000cd8191)) (.m (.leaf 0xd731d7310000000000cd8191) (.leaf 0xd732d7320000000000cd8191))) (.x (.x (.m (.m (.leaf 0xd733d7330000000000cd8500) (.leaf 0xd734d7340000000000cd8500)) (.leaf 0xd735d7350000000000cd8500)) (.leaf 0xd735d7330000000000cd81c9)) (.leaf 0xd735d7330000000000cd817f)))) (.m (.m (.m (.leaf 0xd737d7360000000000cd8191) (.leaf 0xd739d7380000000000cd8191)) (.m (.leaf 0xd73bd73a0000000000cd8191) (.leaf 0xd73cd73c0000000000cd8191))) (.m (.x (.x (.m (.m (.leaf 0xd73dd73d0000000000cd8500) (.leaf 0xd73ed73e0000000000cd8500)) (.leaf 0xd73fd73f0000000000cd8500)) (.leaf 0xd73fd73d0000000000cd81c9)) (.leaf 0xd73fd73d0000000000cd817f)) (.m (.leaf 0xd741d7400000000000cd8191) (.leaf 0xd742d7420000000000cd8191))))) (by decide +kernel)
theorem chunk78 : ProjectedGoal ⟨55107,55120,0,70,1099,1135⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.leaf 0xd743d7430000000000cd8191) (.leaf 0xd744d7440000000000cd8191)) (.m (.leaf 0xd745d7450000000000cd8191) (.leaf 0xd746d7460000000000cd8191))) (.x (.x (.m (.m (.leaf 0xd747d7470000000000cd8500) (.leaf 0xd748d7480000000000cd8500)) (.leaf 0xd749d7490000000000cd8500)) (.leaf 0xd749d7470000000000cd81c9)) (.leaf 0xd749d7470000000000cd817f))) (.m (.m (.leaf 0xd74bd74a0000000000cd8191) (.leaf 0xd74dd74c0000000000cd8191)) (.m (.leaf 0xd74fd74e0000000000cd8191) (.leaf 0xd750d7500000000000cd8191)))) (by decide +kernel)
theorem chunk79 : ProjectedGoal ⟨55121,55133,0,70,1099,1135⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.leaf 0xd751d7510000000000cd8191) (.leaf 0xd752d7520000000000cd8191)) (.m (.leaf 0xd753d7530000000000cd8191) (.leaf 0xd754d7540000000000cd8191))) (.x (.x (.m (.m (.leaf 0xd755d7550000000000cd8500) (.leaf 0xd756d7560000000000cd8500)) (.leaf 0xd757d7570000000000cd8500)) (.leaf 0xd757d7550000000000cd81c9)) (.leaf 0xd757d7550000000000cd817f))) (.m (.m (.leaf 0xd759d7580000000000cd8191) (.leaf 0xd75ad75a0000000000cd8191)) (.x (.x (.m (.m (.leaf 0xd75bd75b0000000000cd8500) (.leaf 0xd75cd75c0000000000cd8500)) (.leaf 0xd75dd75d0000000000cd8500)) (.leaf 0xd75dd75b0000000000cd81c9)) (.leaf 0xd75dd75b0000000000cd817f)))) (by decide +kernel)
end SubmodularMatching.SourceCertificate.Replay.HardLast
