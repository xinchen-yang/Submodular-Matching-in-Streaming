import SubmodularMatching.ReplayQuickChecks0
import SubmodularMatching.ReplayQuickChecks1
import SubmodularMatching.ReplayQuickChecks2
import SubmodularMatching.ReplayQuickChecks3
import SubmodularMatching.ReplayQuickChecks4
import SubmodularMatching.ReplayQuickChecks5
import SubmodularMatching.ReplayQuickChecks6
import SubmodularMatching.ReplayQuickChecks7
import SubmodularMatching.ReplayQuickChecks8

namespace SubmodularMatching.SourceCertificate.Replay
set_option maxRecDepth 16000
set_option maxHeartbeats 5000000
set_option linter.unusedSimpArgs false

private theorem quickLength0 : sourceRates00000.length = 1024 := by rfl
private theorem quickLength1024 : sourceRates01024.length = 1024 := by rfl
private theorem quickLength2048 : sourceRates02048.length = 1024 := by rfl
private theorem quickLength3072 : sourceRates03072.length = 1024 := by rfl
private theorem quickLength4096 : sourceRates04096.length = 1024 := by rfl
private theorem quickLength5120 : sourceRates05120.length = 1024 := by rfl
private theorem quickLength6144 : sourceRates06144.length = 1024 := by rfl
private theorem quickLength7168 : sourceRates07168.length = 1024 := by rfl
private theorem quickLength8192 : sourceRates08192.length = 1024 := by rfl
private theorem quickLength9216 : sourceRates09216.length = 1024 := by rfl
private theorem quickLength10240 : sourceRates10240.length = 1024 := by rfl
private theorem quickLength11264 : sourceRates11264.length = 1024 := by rfl
private theorem quickLength12288 : sourceRates12288.length = 1024 := by rfl
private theorem quickLength13312 : sourceRates13312.length = 1024 := by rfl
private theorem quickLength14336 : sourceRates14336.length = 1024 := by rfl
private theorem quickLength15360 : sourceRates15360.length = 1024 := by rfl
private theorem quickLength16384 : sourceRates16384.length = 1024 := by rfl
private theorem quickLength17408 : sourceRates17408.length = 1024 := by rfl
private theorem quickLength18432 : sourceRates18432.length = 1024 := by rfl
private theorem quickLength19456 : sourceRates19456.length = 1024 := by rfl
private theorem quickLength20480 : sourceRates20480.length = 1024 := by rfl
private theorem quickLength21504 : sourceRates21504.length = 1024 := by rfl
private theorem quickLength22528 : sourceRates22528.length = 1024 := by rfl
private theorem quickLength23552 : sourceRates23552.length = 1024 := by rfl
private theorem quickLength24576 : sourceRates24576.length = 1024 := by rfl
private theorem quickLength25600 : sourceRates25600.length = 1024 := by rfl
private theorem quickLength26624 : sourceRates26624.length = 1024 := by rfl

private theorem checked_lookup :
    checkRegionChunks compareQuick 0 27648 0 ratePieces = true := by
  unfold ratePieces ratePieces0 ratePieces1 ratePieces2
  simp only [List.cons_append, List.nil_append]
  simp only [checkRegionChunks, quickLength0, quickLength1024, quickLength2048, quickLength3072, quickLength4096, quickLength5120, quickLength6144, quickLength7168, quickLength8192, quickLength9216, quickLength10240, quickLength11264, quickLength12288, quickLength13312, quickLength14336, quickLength15360, quickLength16384, quickLength17408, quickLength18432, quickLength19456, quickLength20480, quickLength21504, quickLength22528, quickLength23552, quickLength24576, quickLength25600, quickLength26624, List.length_cons, List.length_nil, Nat.reduceAdd, Nat.reduceLT,
    Nat.reduceLeDiff, or_self, false_or, or_false, not_false_eq_true, if_false, if_true, quick0, quick1024, quick2048, quick3072, quick4096, quick5120, quick6144, quick7168, quick8192, quick9216, quick10240, quick11264, quick12288, quick13312, quick14336, quick15360, quick16384, quick17408, quick18432, quick19456, quick20480, quick21504, quick22528, quick23552, quick24576, quick25600, quick26624, Bool.true_and]
  decide +kernel

private theorem raw_eq (u v : RawSourceMode)
    (h : u.high = v.high ∧ u.low = v.low ∧ u.boundary = v.boundary) : u = v := by
  cases u; cases v
  obtain ⟨rfl,rfl,rfl⟩ := h
  rfl

private theorem compareQuick_sound (k : ℕ) (row : RawSourceMode) (h : compareQuick k row = true) :
    quickRow k = row := raw_eq _ _ (of_decide_eq_true h)

theorem quickRow_eq (k : ℕ) (hk : k < 27648) : quickRow k = appendixRawMode k := by
  let raw := sourceEndRow sourceScale
  have hlen : ratePieces.flatten.length = 27649 := by
    rw [ratePieces_flat, List.length_append, appendixRateRows_length]
    decide
  have h := checkRegionChunks_at _ _ _ _ _ checked_lookup k (by rw [hlen]; omega) (by omega) (by omega) raw
  rw [Nat.zero_add, ratePieces_flat, List.getD_append _ _ _ _ (by rwa [appendixRateRows_length])] at h
  exact compareQuick_sound k _ h

theorem quickRow_boundary (k : ℕ) (hk : k ≤ 27648) : (quickRow k).boundary = appendixRawBoundary k := by
  rcases hk.eq_or_lt with rfl | hlt
  · change (quickRow 27648).boundary = sourceScale
    decide +kernel
  · rw [quickRow_eq k hlt, appendixRawBoundary, if_pos hlt]

end SubmodularMatching.SourceCertificate.Replay
