import SubmodularMatching.NonmonotonePhysicalBudget
import SubmodularMatching.ProjectedShearerFirstStage

namespace SubmodularMatching.AppendixM
noncomputable section

/-- Concrete arithmetic for the sparse-layer rounding and the two floors in
the compensated Gibbs coordinates. All grid sizes are polynomial in K. -/
theorem physical_grid_precisions (K p : ℝ) (n m w q d : ℕ)
    (hK : 1≤K) (hn : (n:ℝ)≤K) (hm : (m:ℝ)≤K) (hp : 0≤p) (hp1 : p≤1)
    (hw : 16*K^3 ≤ (w:ℝ)) (hq : 16*K^2 ≤ (q:ℝ)) (hd : 4*K^3 ≤ (d:ℝ)) :
    3*p*(2*((n:ℝ)/w)) + 2/q ≤ 1/K^2 ∧
      (m:ℝ)/d+1/(4*K^2)+1/(4*K^2) ≤ 1/K^2 := by
  have hKp : 0<K := by linarith only [hK]
  have hnw : (n:ℝ)/w ≤ K/(16*K^3) :=
    div_le_div₀ (by positivity) hn (by positivity) hw
  have hqq : 2/(q:ℝ) ≤ 2/(16*K^2) := div_le_div₀ (by norm_num) le_rfl (by positivity) hq
  have hmden : (m:ℝ)/d ≤ K/(4*K^3) := div_le_div₀ (by positivity) hm (by positivity) hd
  have hc : 3*p*(2*((n:ℝ)/w)) ≤ 3*(2*(K/(16*K^3))) := by gcongr <;> linarith only [hp1]
  refine ⟨(add_le_add hc hqq).trans ?_, ((add_le_add_left (add_le_add_left hmden _) _)).trans ?_⟩
  all_goals field_simp <;> nlinarith only [sq_nonneg K]

/-- The rational two-layer width constraints hold with a fifth-order
time denominator; the chosen refinement remains polynomial in K. -/
theorem physical_time_grid (K : ℕ) :
    let c := 62500000000000000000000
    let Q := c*(K^5+1)
    let a : ℕ := 15609923359958673284671*(K^5+1)
    let b : ℕ := 4702576640041326715329*(K^5+1)
    K^5 ≤ Q ∧ Q ≤ c*(K^5+1) ∧ 0<Q ∧ 0<a ∧ 0<b ∧ (a:ℝ)/Q=layerOne ∧ (b:ℝ)/Q=layerTwo := by
  intro c Q a b
  refine ⟨by dsimp [Q,c]; omega,le_rfl,by dsimp [Q,c]; positivity,by dsimp [a]; positivity,
    by dsimp [b]; positivity,?_,?_⟩
  all_goals dsimp only [Q,a,b,c,layerTwo,degree,layerOne]
  all_goals push_cast; field_simp <;> ring

end
end SubmodularMatching.AppendixM
