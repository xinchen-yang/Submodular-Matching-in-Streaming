import SubmodularMatching.FiniteShearerRationalGrid
import SubmodularMatching.PackingResources
import SubmodularMatching.TwoStageSeparateAlteration
import SubmodularMatching.UpperBoundVertexIndex

/-! # Rational parameters and integer coordinates for Appendix K rounding -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint TwoStage GibbsMatching ShearerSampler

noncomputable section

/-- The two accuracies in Appendix K are independent. The integer
reciprocal condition on the streaming accuracy gives `ε₀ = 2 / K`.
The probability of stopping the Shearer recursion is `rNum / rDen`. -/
structure K1RoundingSettings where
  K : ℕ
  rNum : ℕ
  rDen : ℕ
  errNum : ℕ
  errDen : ℕ
  K_pos : 0 < K
  rNum_pos : 0 < rNum
  rNum_lt : rNum < rDen
  r_stop : rDen < 2 * rNum
  errNum_pos : 0 < errNum
  err_lt : errNum < errDen

namespace K1RoundingSettings

def epsilon (R : K1RoundingSettings) : ℝ := 2 / (R.K : ℝ)

def stop (R : K1RoundingSettings) : ℝ := (R.rNum : ℝ) / R.rDen

def degree (R : K1RoundingSettings) : ℝ := R.stop * (1 - R.stop)

def error (R : K1RoundingSettings) : ℝ := (R.errNum : ℝ) / R.errDen

def compensation (R : K1RoundingSettings) (m : ℕ) : ℕ := 4 * m * R.K

def alterationTop (R : K1RoundingSettings) : ℕ := 4 * R.errDen + R.errNum

def alterationBottom (R : K1RoundingSettings) : ℕ := 4 * R.errDen

def gibbsNumerator (R : K1RoundingSettings) : ℕ := 8 * R.errDen - R.errNum

def gibbsDenominator (R : K1RoundingSettings) : ℕ := 8 * R.errDen

def samplerDenominator (R : K1RoundingSettings) (vertices : ℕ) : ℕ :=
  4 * vertices * R.K

theorem error_bounds (R : K1RoundingSettings) : 0 < R.error ∧ R.error < 1 := by
  have hd : (0 : ℝ) < R.errDen := by exact_mod_cast R.errNum_pos.trans R.err_lt
  have hn : (0 : ℝ) < R.errNum := by exact_mod_cast R.errNum_pos
  have hlt : (R.errNum : ℝ) < R.errDen := by exact_mod_cast R.err_lt
  exact ⟨div_pos hn hd, (div_lt_one hd).mpr hlt⟩

theorem stop_bounds (R : K1RoundingSettings) : 1 / 2 < R.stop ∧ R.stop < 1 := by
  have hd : (0 : ℝ) < R.rDen := by exact_mod_cast R.rNum_pos.trans R.rNum_lt
  have hlt : (R.rNum : ℝ) < R.rDen := by exact_mod_cast R.rNum_lt
  have hs : (R.rDen : ℝ) < 2 * (R.rNum : ℝ) := by exact_mod_cast R.r_stop
  exact ⟨(lt_div_iff₀ hd).mpr (by linarith), (div_lt_one hd).mpr hlt⟩

theorem degree_bounds (R : K1RoundingSettings) : 0 < R.degree ∧ R.degree < 1 / 4 := by
  have hs := R.stop_bounds
  have hr0 : 0 < R.stop := by linarith only [hs.1]
  refine ⟨mul_pos hr0 (sub_pos.mpr hs.2), ?_⟩
  unfold degree
  nlinarith only [sq_pos_of_pos (sub_pos.mpr hs.1)]

theorem compensation_pos (R : K1RoundingSettings) {m : ℕ} (hm : 0 < m) :
    0 < R.compensation m := Nat.mul_pos (Nat.mul_pos (by decide) hm) R.K_pos

theorem compensation_mesh (R : K1RoundingSettings) {m : ℕ} (hm : 0 < m) :
    1 / (R.compensation m : ℝ) = R.epsilon / (8 * (m : ℝ)) := by
  have hk : (R.K : ℝ) ≠ 0 := by exact_mod_cast R.K_pos.ne'
  have hm' : (m : ℝ) ≠ 0 := by exact_mod_cast hm.ne'
  unfold compensation epsilon
  push_cast
  field_simp
  ring

theorem alterationTop_pos (R : K1RoundingSettings) : 0 < R.alterationTop :=
  Nat.add_pos_right _ R.errNum_pos

theorem alterationBottom_pos (R : K1RoundingSettings) : 0 < R.alterationBottom :=
  Nat.mul_pos (by decide) (R.errNum_pos.trans R.err_lt)

theorem alteration_scale (R : K1RoundingSettings) :
    1 + R.error / 4 = (R.alterationTop : ℝ) / R.alterationBottom := by
  have hd : (R.errDen : ℝ) ≠ 0 := by exact_mod_cast (R.errNum_pos.trans R.err_lt).ne'
  unfold alterationTop alterationBottom error
  push_cast
  field_simp

theorem gibbsNumerator_lt (R : K1RoundingSettings) :
    R.gibbsNumerator < R.gibbsDenominator := by
  have hd : 0 < R.errDen := R.errNum_pos.trans R.err_lt
  have he := R.errNum_pos
  unfold gibbsNumerator gibbsDenominator
  omega

theorem gibbs_scale (R : K1RoundingSettings) :
    1 - (R.error / 2) / 4 = (R.gibbsNumerator : ℝ) / R.gibbsDenominator := by
  have hge : R.errNum ≤ 8 * R.errDen := by have := R.err_lt; omega
  have hd : (R.errDen : ℝ) ≠ 0 := by exact_mod_cast (R.errNum_pos.trans R.err_lt).ne'
  unfold gibbsNumerator gibbsDenominator error
  rw [Nat.cast_sub hge]
  push_cast
  field_simp
  ring

theorem samplerDenominator_pos (R : K1RoundingSettings) {n : ℕ} (hn : 0 < n) :
    0 < R.samplerDenominator n := Nat.mul_pos (Nat.mul_pos (by decide) hn) R.K_pos

theorem sampler_error_budget (R : K1RoundingSettings) {n : ℕ} (hn : 0 < n) (B : ℝ)
    (hB : 0 ≤ B) :
    (1 / (R.samplerDenominator n : ℝ) + 1 / (R.samplerDenominator n : ℝ)) *
      ((n : ℝ) / 2 * B) ≤ R.epsilon * B / 4 := by
  have hk : (0 : ℝ) < R.K := by exact_mod_cast R.K_pos
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have heq : (1 / (R.samplerDenominator n : ℝ) + 1 / (R.samplerDenominator n : ℝ)) *
      ((n : ℝ) / 2 * B) = R.epsilon * B / 8 := by
    unfold samplerDenominator epsilon
    push_cast
    field_simp
    ring
  rw [heq]
  have hprod : 0 ≤ R.epsilon * B := mul_nonneg (by unfold epsilon; positivity) hB
  linarith only [hprod]

end K1RoundingSettings

/-- Read a coordinate already on the common grid as an integer index. -/
def k1RoundingGridIndex (q : ℕ) (z : ℝ) : ℕ := Int.toNat ⌊(q : ℝ) * z⌋

theorem k1RoundingGridIndex_decode {q : ℕ} {z : ℝ} (hq : 0 < q)
    (hz : 0 ≤ z) (hgrid : LinearPacking.OnGrid q z) :
    (k1RoundingGridIndex q z : ℝ) / q = z := by
  have hq' : (0 : ℝ) < q := by exact_mod_cast hq
  obtain ⟨i, hi⟩ := hgrid
  have hi0 : 0 ≤ i := by
    have : 0 ≤ (i : ℝ) := hi ▸ mul_nonneg hq'.le hz
    exact_mod_cast this
  unfold k1RoundingGridIndex
  rw [hi, Int.floor_intCast, ← Int.cast_natCast (R := ℝ), Int.toNat_of_nonneg hi0, ← hi]
  rw [mul_comm, mul_div_cancel_right₀ _ hq'.ne']

theorem k1RoundingGridIndex_of_div {q : ℕ} (hq : 0 < q) (word : ℕ) :
    k1RoundingGridIndex q ((word : ℝ) / q) = word := by
  have hq' : (q : ℝ) ≠ 0 := by exact_mod_cast hq.ne'
  unfold k1RoundingGridIndex
  rw [← mul_div_assoc, mul_comm (q : ℝ), mul_div_cancel_right₀ _ hq',
    Int.floor_natCast, Int.toNat_natCast]

variable {m : ℕ} {V : Type*} [DecidableEq V]

def k1RoundingShearerInputWords (R : K1RoundingSettings) (num : Fin m → ℕ)
    (q : ℕ) (hq : 0 < q) : RationalShearerInput (Fin m) where
  a := R.rNum
  b := R.rDen
  Q := q
  numerator := num
  a_pos := R.rNum_pos
  a_lt_b := R.rNum_lt
  Q_pos := hq

/-- The rational first-stage sampler receives the physical y coordinates. -/
def k1RoundingShearerInput (R : K1RoundingSettings) (y : Fin m → ℝ)
    (q : ℕ) (hq : 0 < q) : RationalShearerInput (Fin m) :=
  k1RoundingShearerInputWords R (fun i => k1RoundingGridIndex q (y i)) q hq

theorem k1RoundingShearerInput_decode (R : K1RoundingSettings) (y : Fin m → ℝ)
    (q : ℕ) (hq : 0 < q) (hy : ∀ i, 0 ≤ y i) (hgrid : ∀ i, LinearPacking.OnGrid q (y i)) :
    (k1RoundingShearerInput R y q hq).x = y := by
  funext i
  exact k1RoundingGridIndex_decode hq (hy i) (hgrid i)

theorem numberedVertexLoad_eq (ends : Fin m → V × V) (z : Fin m → ℝ)
    (v : IncidentVertex ends) :
    vertexLoad (pairEnds (numberedEnds ends)) Finset.univ z (incidentVertexNumbering ends v) =
      Joint.degree ends z v := by
  have hInc : incident (pairEnds (numberedEnds ends)) Finset.univ (incidentVertexNumbering ends v) =
      incident (pairEnds (restrictEnds ends)) Finset.univ v := by
    ext e
    rw [incident, incident, Finset.mem_filter, Finset.mem_filter, ← numberedEnds_pairEnds_map]
    simp only [← Equiv.coe_toEmbedding, Finset.mem_map']
  unfold vertexLoad
  rw [hInc]
  change Shearer.vertexDegree (pairEnds (restrictEnds ends)) Finset.univ z v = _
  rw [vertexDegree_pairEnds, restrictEnds_degree]

/-- Compact numbering preserves the joint packing constraints for the
identical first-stage and stored supports of Appendix K. -/
theorem k1NumberedFeasible {p D : ℝ} (ends : Fin m → V × V)
    (x y : Fin m → ℝ) (h : Joint.Feasible p D ends ends x y) :
    SeparateFeasible (numberedEnds ends) Finset.univ Finset.univ x y p D := by
  refine ⟨fun e _ => h.x_nonneg e, fun e _ => h.y_nonneg e, ?_, ?_, ?_⟩
  · intro v
    obtain ⟨u, rfl⟩ := (incidentVertexNumbering ends).surjective v
    rw [numberedVertexLoad_eq]
    exact h.y_degree u
  · intro v
    obtain ⟨u, rfl⟩ := (incidentVertexNumbering ends).surjective v
    rw [numberedVertexLoad_eq, numberedVertexLoad_eq]
    exact h.shared_degree u
  · intro e _
    change x e ≤ p * (1 - vertexLoad (pairEnds (numberedEnds ends)) Finset.univ y
      (incidentVertexNumbering ends (restrictEnds ends e).1) -
      vertexLoad (pairEnds (numberedEnds ends)) Finset.univ y
        (incidentVertexNumbering ends (restrictEnds ends e).2))
    rw [numberedVertexLoad_eq, numberedVertexLoad_eq, restrictEnds_first, restrictEnds_second]
    have hb := h.edge_bound e
    linarith only [hb]

end

end SubmodularMatching.UpperBoundAssembly
