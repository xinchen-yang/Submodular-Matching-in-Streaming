import SubmodularMatching.UpperBoundLiveFamily
import SubmodularMatching.UpperBoundK1OptimizerOnline

/-! # Retaining only the completed optimizer points of live guesses -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler Streaming

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable {Ns Ng : ℕ}
variable (cfg : K1OptimizerSettings)
variable (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
variable (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)

/-- Assign a completed point to each guess that is in the actual schedule. -/
def k1FinalLiveOptimizerChoice (Ng : ℕ) (j : ℕ) :
    CandidateLaw (CurrentOptimizerPoint (finalGuessCount P batches j)) := by
  classical
  let m := finalGuessCount P batches j
  let emb := finalGuessEmbedding P batches hunique j
  exact if j ∈ finalGuessIndices P then
    if hm : 0 < m then
      k1LiveOptimizerLaw cfg Ng hm (restrictEnds (P.ends ∘ emb)) (finalGuessConfig P j).tau
        (finalGuessFrozen P batches j ∘ emb) (reindexedObjective emb P.objective)
        (k1GradientDiscountGrid cfg.degree cfg.error m) (k1GradientCoordinateBits cfg.degree cfg.error m)
    else CandidateLaw.pure (fun _ => 0)
  else CandidateLaw.pure (fun _ => 0)

def k1FinalLiveOptimizerLaw (Ng : ℕ) : CandidateLaw (FinalPointFamily P batches) :=
  CandidateLaw.assign (k1FinalLiveOptimizerChoice cfg P batches hunique Ng)
    ((finalGuessIndices P).sort (· ≤ ·)) (fun _ _ => 0)

def k1ProjectFinalPoint (j : ℕ) (t : OptimizerTape (finalGuessCount P batches j) Ng) :
    CurrentOptimizerPoint (finalGuessCount P batches j) := by
  classical
  let m := finalGuessCount P batches j
  let emb := finalGuessEmbedding P batches hunique j
  exact if j ∈ finalGuessIndices P then
    if 0 < m then k1OptimizerPoint cfg (restrictEnds (P.ends ∘ emb)) (finalGuessConfig P j).tau
      (finalGuessFrozen P batches j ∘ emb) (reindexedObjective emb P.objective)
      (k1GradientDiscountGrid cfg.degree cfg.error m) t (FiniteGreedy.stages cfg.degree m cfg.error)
    else fun _ => 0
  else fun _ => 0

/-- The whole family of completed points is distributed exactly like the
transcript proof's projection. All slots start empty in the actual schedule. -/
theorem k1FinalLiveOptimizerLaw_value (test : FinalPointFamily P batches → ℝ) :
    let a := k1FinalLiveOptimizerLaw cfg P batches hunique Ng
    let b := k1FinalOptimizerWordLaw (Ng := Ng) cfg P batches hunique
    expected a.outcomes a.mass test = expected b.outcomes b.mass
      (fun t => test (fun j => k1ProjectFinalPoint cfg P batches hunique j (t j))) := by
  classical
  dsimp only
  unfold k1FinalLiveOptimizerLaw k1FinalOptimizerWordLaw
  let is := (finalGuessIndices P).sort (· ≤ ·)
  let p := k1FinalOptimizerWordChoice (Ng := Ng) cfg P batches hunique
  let q := k1FinalLiveOptimizerChoice cfg P batches hunique Ng
  let proj := k1ProjectFinalPoint (Ng := Ng) cfg P batches hunique
  let initial := fun j => OptimizerTape.empty (finalGuessCount P batches j) Ng
  have hchoice (j : ℕ) (obs : CurrentOptimizerPoint (finalGuessCount P batches j) → ℝ) :
      expected (p j).outcomes (p j).mass (obs ∘ proj j) =
        expected (q j).outcomes (q j).mass obs := by
    by_cases hj : j ∈ finalGuessIndices P
    · by_cases hm : 0 < finalGuessCount P batches j
      · let e := finalGuessEmbedding P batches hunique j
        have same := (k1LiveOptimizerLaw_value (N := Ng) cfg hm (restrictEnds (P.ends ∘ e))
          (finalGuessConfig P j).tau (finalGuessFrozen P batches j ∘ e)
          (reindexedObjective e P.objective) (k1GradientDiscountGrid cfg.degree cfg.error (finalGuessCount P batches j))
          (k1GradientCoordinateBits cfg.degree cfg.error (finalGuessCount P batches j)) obs).symm
        simpa only [p, q, proj, k1FinalOptimizerWordChoice, k1FinalLiveOptimizerChoice,
          k1ProjectFinalPoint, dif_pos hm, if_pos hj, if_pos hm, Function.comp_def] using same
      · simp [p, q, proj, k1FinalOptimizerWordChoice, k1FinalLiveOptimizerChoice, k1ProjectFinalPoint,
          hj, hm]
    · simp only [q, proj, k1FinalLiveOptimizerChoice, k1ProjectFinalPoint, Function.comp_def,
        if_neg hj, CandidateLaw.pure_expected]
      change expected (p j).outcomes (p j).mass (fun _ => obs (fun _ => 0)) = _
      simp only [expected, ← Finset.sum_mul, (p j).probability.total, one_mul]
  rw [CandidateLaw.assign_project_expected p q proj hchoice is initial test]
  have hi := CandidateLaw.assign_initial_eq q is (fun j => proj j (initial j)) (fun _ _ => 0)
    (by
      intro j hj
      have hj' : j ∉ finalGuessIndices P := mt (Finset.mem_sort (· ≤ ·)).2 hj
      simp only [proj, k1ProjectFinalPoint, if_neg hj'])
  rw [hi]

end

end SubmodularMatching.UpperBoundAssembly
