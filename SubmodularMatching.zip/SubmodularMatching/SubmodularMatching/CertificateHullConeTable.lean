import SubmodularMatching.CertificateHullCone

/-!
# Supporting-knot entries backed by shared verified envelopes
-/

namespace SubmodularMatching.SourceCertificate

structure AppendixHull where
  covered : Bool
  lo : ℕ
  hi : ℕ
  count : ℕ
  packedVertices : ℕ

def AppendixHull.vertex (A : AppendixHull) (k : ℕ) : ℕ := (A.packedVertices >>> (11 * k)) % 2048

def AppendixHull.Valid (A : AppendixHull) : Prop :=
  A.hi ≤ 1135 ∧ ConvexAxisEnvelope appendixGridX (appendixGridHeight A.covered)
    A.lo A.hi A.count A.vertex

def AppendixHull.check (A : AppendixHull) : Bool :=
  decide (A.hi ≤ 1135) &&
    checkConvexAxisEnvelope appendixGridX (appendixGridHeight A.covered) A.lo A.hi A.count A.vertex

theorem AppendixHull.check_sound (A : AppendixHull) (h : A.check = true) : A.Valid := by
  rw [check, Bool.and_eq_true] at h
  exact ⟨of_decide_eq_true h.1, checkConvexAxisEnvelope_sound _ _ _ _ _ _ h.2⟩

def CheckedAppendixHull := { H : AppendixHull // H.Valid }

def checkedAppendixHull (H : AppendixHull) (h : H.check = true) : CheckedAppendixHull :=
  ⟨H, H.check_sound h⟩

def AppendixFastCone.hullCheck (C : AppendixFastCone) (A : AppendixHull) (m : ℕ) : Bool :=
  decide (C.covered = A.covered ∧ C.cone.lo = A.lo ∧ C.cone.hi = A.hi ∧ m ≤ A.count ∧
    C.cone.ix = A.vertex m ∧ C.cone.prev = A.vertex (m - 1) ∧
    C.cone.next = A.vertex (min (m + 1) A.count) ∧
    C.coordinates = C.cone.appendixCoordinates C.covered)

theorem AppendixFastCone.hullCheck_sound (C : AppendixFastCone) (A : AppendixHull) (m : ℕ)
    (h : C.hullCheck A m = true) (hv : A.Valid) : C.Sufficient := by
  have hc : C.covered = A.covered ∧ C.cone.lo = A.lo ∧ C.cone.hi = A.hi ∧ m ≤ A.count ∧
      C.cone.ix = A.vertex m ∧ C.cone.prev = A.vertex (m - 1) ∧
      C.cone.next = A.vertex (min (m + 1) A.count) ∧
      C.coordinates = C.cone.appendixCoordinates C.covered := of_decide_eq_true h
  obtain ⟨flag, hl, hh, hm, ix, prev, next, coords⟩ := hc
  refine C.sufficient_of_hull A.vertex A.count m ?_ ?_ ⟨hm, ix, prev, next⟩ coords
  · rw [flag, hl, hh]
    exact hv.2
  · intro i j hij hj
    exact appendixGridX_monotone i j hij (hj.trans (hh ▸ hv.1))

def SupportedAppendixCone := { entry : AppendixFastCone // entry.Sufficient }

def supportedAppendixCone (entry : AppendixFastCone) (H : CheckedAppendixHull) (m : ℕ)
    (h : entry.hullCheck H.val m = true) : SupportedAppendixCone :=
  ⟨entry, entry.hullCheck_sound H.val m h H.property⟩

end SubmodularMatching.SourceCertificate
