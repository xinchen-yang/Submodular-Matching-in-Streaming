import SubmodularMatching.LowerBoundGlobalCyclicBuckets
import SubmodularMatching.LowerBoundGlobalWordPacking

/-! # Finite cyclic ERS hosts from low-agreement words -/

namespace SubmodularMatching.LowerBoundGlobal.AJX

open scoped BigOperators

noncomputable section

variable {m L C B W t : ℕ} [NeZero (C * (B + W))]

abbrev Coordinates (m L : ℕ) := Fin m × Fin L
abbrev CyclicVertex (m L C B W : ℕ) := Coordinates m L → BufferedRing C B W

/-- The displacements match arbitrary color pairs within a group and
are smaller than the color buffer when observed across different groups. -/
structure CyclicDesign (m L C B W t : ℕ) where
  word : Fin t → Fin m → Fin L
  word_injective : Function.Injective word
  shift : Fin C → Fin C → ℕ
  shift_pos : ∀ a b, 0 < shift a b
  shift_lt : ∀ a b, shift a b < C * (B + W)
  aligned : ∀ a b,
    (a.val * (B + W) + m * shift a b) % (C * (B + W)) = b.val * (B + W)
  small_overlap : ∀ i j : Fin t, i ≠ j → ∀ a b, agreement (word i) (word j) * shift a b < W

def cyclicWeight (word : Fin m → Fin L) (u : CyclicVertex m L C B W) : BufferedRing C B W :=
  ∑ k : Fin m, u (k, word k)

private def translate (word : Fin m → Fin L) (d : ℕ) (u : CyclicVertex m L C B W) :
    CyclicVertex m L C B W :=
  fun coord => u coord + if coord.2 = word coord.1 then (d : BufferedRing C B W) else 0

omit [NeZero (C * (B + W))] in
private theorem translate_injective (word : Fin m → Fin L) (d : ℕ) :
    Function.Injective (translate (C := C) (B := B) (W := W) word d) := by
  intro u v huv
  funext coord
  exact add_right_cancel (congrFun huv coord)

omit [NeZero (C * (B + W))] in
theorem cyclicWeight_translate (x y : Fin m → Fin L) (d : ℕ) (u : CyclicVertex m L C B W) :
    cyclicWeight x (translate y d u) =
      cyclicWeight x u + ((agreement x y * d : ℕ) : BufferedRing C B W) := by
  unfold cyclicWeight translate
  rw [Finset.sum_add_distrib]
  congr 1
  rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, Nat.cast_mul]
  rfl

def cyclicBucket (word : Fin m → Fin L) (a : Fin C) : Finset (CyclicVertex m L C B W) :=
  Finset.univ.filter (fun u => bufferedColor (cyclicWeight word u) = some a)

private def cyclicPairEmbedding (D : CyclicDesign m L C B W t) (i : Fin t) (a b : Fin C) :
    CyclicVertex m L C B W ↪ CyclicVertex m L C B W × CyclicVertex m L C B W where
  toFun u := (u, translate (D.word i) (D.shift a b) u)
  inj' _ _ h := congrArg Prod.fst h

def cyclicBlock (D : CyclicDesign m L C B W t) (i : Fin t) (a b : Fin C) :
    Finset (CyclicVertex m L C B W × CyclicVertex m L C B W) :=
  (cyclicBucket (B := B) (W := W) (D.word i) a).map (cyclicPairEmbedding D i a b)

theorem mem_cyclicBlock {D : CyclicDesign m L C B W t} {i : Fin t} {a b : Fin C}
    {e : CyclicVertex m L C B W × CyclicVertex m L C B W} :
    e ∈ cyclicBlock D i a b ↔
      bufferedColor (cyclicWeight (D.word i) e.1) = some a ∧
      e.2 = translate (D.word i) (D.shift a b) e.1 := by
  constructor
  · intro h
    obtain ⟨u, hu, rfl⟩ := Finset.mem_map.mp h
    exact ⟨(Finset.mem_filter.mp hu).2, rfl⟩
  · rintro ⟨hcol, htran⟩
    exact Finset.mem_map.mpr ⟨e.1, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hcol⟩,
      Prod.ext rfl htran.symm⟩

theorem cyclicBlock_matching (D : CyclicDesign m L C B W t) (i : Fin t) (a b : Fin C) :
    CloneLift.IsMatching (cyclicBlock D i a b) := by
  constructor
  · intro e he f hf heq
    have hl : e.1 = f.1 := heq
    refine Prod.ext hl ?_
    rw [(mem_cyclicBlock.mp he).2, (mem_cyclicBlock.mp hf).2, hl]
  · intro e he f hf heq
    have hr := (mem_cyclicBlock.mp he).2.symm.trans (heq.trans (mem_cyclicBlock.mp hf).2)
    exact Prod.ext (translate_injective (D.word i) (D.shift a b) hr) heq

theorem cyclicBlock_colors {D : CyclicDesign m L C B W t} {i : Fin t} {a b : Fin C}
    {e : CyclicVertex m L C B W × CyclicVertex m L C B W} (he : e ∈ cyclicBlock D i a b) :
    bufferedColor (cyclicWeight (D.word i) e.1) = some a ∧
      bufferedColor (cyclicWeight (D.word i) e.2) = some b := by
  obtain ⟨hc, ht⟩ := mem_cyclicBlock.mp he
  refine ⟨hc, ?_⟩
  rw [ht, cyclicWeight_translate, agreement_self]
  exact bufferedColor_shift_to _ hc (D.aligned a b)

theorem cyclicBlock_same_group {D : CyclicDesign m L C B W t} {i j : Fin t}
    {a b c d : Fin C} {e : CyclicVertex m L C B W × CyclicVertex m L C B W}
    (he : e ∈ cyclicBlock D i a b) (hf : e ∈ cyclicBlock D j c d) : i = j := by
  by_contra hne
  have hw : D.word i ≠ D.word j := fun h => hne (D.word_injective h)
  obtain ⟨k, hk⟩ := Function.ne_iff.mp hw
  have ht := congrFun ((mem_cyclicBlock.mp he).2.symm.trans (mem_cyclicBlock.mp hf).2)
    (k, D.word i k)
  simp only [translate, if_true, if_neg hk, add_zero, add_eq_left] at ht
  have hz := congrArg ZMod.val ht
  rw [ZMod.val_natCast_of_lt (D.shift_lt a b), ZMod.val_zero] at hz
  exact (D.shift_pos a b).ne' hz

theorem cyclicBlock_induced {D : CyclicDesign m L C B W t} {i j : Fin t}
    {a b c d : Fin C} {e : CyclicVertex m L C B W × CyclicVertex m L C B W}
    (he : e ∈ cyclicBlock D i a b) (hij : i ≠ j)
    (hc : bufferedColor (cyclicWeight (D.word j) e.1) = some c)
    (hd : bufferedColor (cyclicWeight (D.word j) e.2) = some d) : c = d := by
  rw [(mem_cyclicBlock.mp he).2, cyclicWeight_translate] at hd
  exact bufferedColor_small_shift _ hc hd (D.small_overlap j i hij.symm a b)

private def cyclicVertexIndex :
    CyclicVertex m L C B W ≃ Fin ((C * (B + W)) ^ (m * L)) :=
  Fintype.equivFinOfCardEq (by
    rw [Fintype.card_fun, ZMod.card, Fintype.card_prod, Fintype.card_fin, Fintype.card_fin])

private def cyclicEdgeIndex :
    (CyclicVertex m L C B W × CyclicVertex m L C B W) ↪
      (Fin ((C * (B + W)) ^ (m * L)) × Fin ((C * (B + W)) ^ (m * L))) :=
  (Equiv.prodCongr cyclicVertexIndex cyclicVertexIndex).toEmbedding

/-- Reindex the cyclic grid by the finite type used by the ERS interface. -/
def CyclicDesign.toERS (D : CyclicDesign m L C B W t) (r : ℕ)
    (hcount : ∀ (i : Fin t) (a : Fin C), (cyclicBucket (C := C) (B := B) (W := W) (D.word i) a).card = r) :
    ERS ((C * (B + W)) ^ (m * L)) C r t where
  block i a b := (cyclicBlock D i a b).map cyclicEdgeIndex
  leftBucket i x := bufferedColor (cyclicWeight (D.word i)
    ((cyclicVertexIndex (C := C) (B := B) (W := W)).symm x))
  rightBucket i x := bufferedColor (cyclicWeight (D.word i)
    ((cyclicVertexIndex (C := C) (B := B) (W := W)).symm x))
  block_card i a b := by rw [Finset.card_map, cyclicBlock, Finset.card_map, hcount]
  block_matching i a b := by
    have hm := cyclicBlock_matching D i a b
    constructor <;> intro x hx y hy heq
    · obtain ⟨u, hu, rfl⟩ := Finset.mem_map.mp hx
      obtain ⟨v, hv, rfl⟩ := Finset.mem_map.mp hy
      exact congrArg cyclicEdgeIndex (hm.1 hu hv (cyclicVertexIndex.injective heq))
    · obtain ⟨u, hu, rfl⟩ := Finset.mem_map.mp hx
      obtain ⟨v, hv, rfl⟩ := Finset.mem_map.mp hy
      exact congrArg cyclicEdgeIndex (hm.2 hu hv (cyclicVertexIndex.injective heq))
  bucket_of_mem h := by
    obtain ⟨u, hu, rfl⟩ := Finset.mem_map.mp h
    simpa only [cyclicEdgeIndex, Equiv.toEmbedding_apply, Equiv.prodCongr_apply,
      Equiv.symm_apply_apply, Prod.map] using cyclicBlock_colors hu
  same_group h h' := by
    obtain ⟨u, hu, rfl⟩ := Finset.mem_map.mp h
    obtain ⟨v, hv, he⟩ := Finset.mem_map.mp h'
    have heq := cyclicEdgeIndex.injective he
    subst v
    exact cyclicBlock_same_group hu hv
  induced h hne hc hd := by
    obtain ⟨u, hu, rfl⟩ := Finset.mem_map.mp h
    apply cyclicBlock_induced hu hne
    · simpa only [cyclicEdgeIndex, Equiv.toEmbedding_apply, Equiv.prodCongr_apply,
        Equiv.symm_apply_apply, Prod.map] using hc
    · simpa only [cyclicEdgeIndex, Equiv.toEmbedding_apply, Equiv.prodCongr_apply,
        Equiv.symm_apply_apply, Prod.map] using hd

end

end SubmodularMatching.LowerBoundGlobal.AJX
