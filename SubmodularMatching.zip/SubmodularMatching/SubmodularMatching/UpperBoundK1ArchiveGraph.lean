import SubmodularMatching.UpperBoundK1ArchiveProgram
import SubmodularMatching.UpperBoundK1OracleIndices

/-! # General Appendix K.1 for any simple stream, with the physical archive -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler Streaming
open scoped BigOperators

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

namespace K1ProgramInput

variable {a : K1Parameters} (I : K1ProgramInput a E V)

omit [Fintype E] in
theorem feasible_value_bound (M : Finset E) (hM : M ∈ I.feasible) :
    0 ≤ I.P.objective M ∧ I.P.objective M ≤ (I.P.vertices : ℝ) * I.B := by
  have h0 := I.P.monotone ∅ M (Finset.empty_subset M)
  rw [I.P.normalized] at h0
  refine ⟨h0, ?_⟩
  have hsize : 2 * M.card ≤ I.P.vertices := by
    rw [I.vertices]
    exact arrived_matching_card I.P.ends I.P.edges I.P.arrivals (fun e _ => I.loopless e) M hM
  have hcard : (M.card : ℝ) ≤ I.P.vertices := by
    exact_mod_cast (show M.card ≤ I.P.vertices by omega)
  have hsingle (e : E) : I.P.objective {e} ≤ I.B := by
    obtain ⟨i, hi, he⟩ := Finset.mem_image.mp (I.allArrived e)
    rw [← he]
    exact singleton_le_maximum I.P.value (Finset.mem_range.mp hi)
  have hsub := submodular_union_le_sum_singletons I.P.objective I.P.submodular I.P.monotone
    I.P.normalized ∅ M
  rw [Finset.empty_union, I.P.normalized, zero_add] at hsub
  calc
    _ ≤ M.sum (fun _ => I.B) := hsub.trans (Finset.sum_le_sum fun e _ => hsingle e)
    _ = (M.card : ℝ) * I.B := by simp
    _ ≤ _ := mul_le_mul_of_nonneg_right hcard I.positiveBest.le

omit [Fintype E] in
/-- A fixed denominator bounds the integer index and gives an exact
binary-search implementation of the comparison for either grid. -/
theorem finalComparison_index (g : ℕ) (hg : 0 < g) (M : Finset E) (hM : M ∈ I.feasible) :
    let step := I.B / (g : ℝ)
    let bits := (g * I.P.vertices).log2 + 1
    compareGridIndex (fun i : ℤ => decide ((i : ℝ) * step ≤ I.P.objective M)) 0 bits =
      (comparisonIndex I.P.objective step M, bits) ∧
    bits ≤ (g.log2 + 2) * ((I.P.vertices + 1).log2 + 1) := by
  dsimp only
  refine ⟨?_, ?_⟩
  · have h := k1Objective_grid_comparisons 1 g I.P.vertices (by decide) hg I.B (I.P.objective M)
      I.positiveBest (I.feasible_value_bound M hM)
    simpa only [Nat.cast_one, one_div_mul_eq_div, comparisonIndex] using h
  · have h := (k1GridComparisonBits_le a.k g I.P.vertices 0 (Nat.zero_le _)).2.2
    simpa only [show 1 + g.log2 + 1 = g.log2 + 2 by omega] using h

omit [Fintype E] in
/-- The integer comparator preserves the exact tie rule of both final scans. -/
theorem finalComparison_selection (g : ℕ) (hg : 0 < g) (M N : Finset E)
    (hM : M ∈ I.feasible) (hN : N ∈ I.feasible) :
    let step := I.B / (g : ℝ)
    let bits := (g * I.P.vertices).log2 + 1
    let index (A : Finset E) := (compareGridIndex
      (fun i : ℤ => decide ((i : ℝ) * step ≤ I.P.objective A)) 0 bits).1
    (if index M ≤ index N then N else M) = keepBetter I.P.objective step M N := by
  dsimp only
  rw [(I.finalComparison_index g hg M hM).1, (I.finalComparison_index g hg N hN).1] <;> rfl

omit [Fintype E] in
theorem finalComparison_steps (C : K1Confidence a) :
    a.error * I.B / 2 = I.B / (a.k : ℝ) ∧
      C.comparisonMesh * I.B = I.B / (C.comparisonDenominator : ℝ) := by
  constructor
  · unfold K1Parameters.error k1Epsilon
    ring
  · unfold K1Confidence.comparisonMesh
    ring

end K1ProgramInput

namespace SimpleEdgeStream

variable (S : SimpleEdgeStream E V) (a : K1Parameters)

def k1ArchivedExpectedOutput (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f) :
    CandidateLaw (Finset E) := by
  classical
  let g := normalizeObjective f
  have hg := normalizeObjective_properties f hf hmono
  exact if hB : ∃ e, 0 < g {e} then
    (S.k1PositiveProgram a g hg.1 hg.2.1 hg.2.2 hB).withRetainedBest.archivedExpectedLaw else CandidateLaw.pure ∅

def k1ArchivedAmplifiedOutput (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (C : K1Confidence a) (δ : ℝ) : CandidateLaw (Finset E) := by
  classical
  let g := normalizeObjective f
  have hg := normalizeObjective_properties f hf hmono
  exact if hB : ∃ e, 0 < g {e} then
    (S.k1PositiveProgram a g hg.1 hg.2.1 hg.2.2 hB).withRetainedBest.archivedAmplifiedLaw C δ else CandidateLaw.pure ∅

set_option maxHeartbeats 1000000 in
/-- Theorem K.1's expectation and confidence requirements on the original
objective, for arbitrary admissible rational rate and accuracy parameters. -/
theorem theoremK1_verified (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (h0 : 0 ≤ f ∅) (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (C : K1Confidence a) (δ : ℝ) (hδ : 0 < δ) :
    let p := S.k1ArchivedExpectedOutput a f hf hmono
    let q := S.k1ArchivedAmplifiedOutput a f hf hmono C δ
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      ((1 - a.error) * a.theta * a.eta / (1 + 5 * a.error)) * f O ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / C.target ≤ f M then 0 else 1) ≤ δ := by
  classical
  dsimp only
  rw [← a.expectedFactor_eq (f O)]
  let g := normalizeObjective f
  let hg := normalizeObjective_properties f hf hmono
  have hR : 1 ≤ a.expectedFactor := a.one_lt_expectedFactor.le
  have hC : 1 ≤ C.target := C.one_lt_target.le
  by_cases hpos : ∃ e, 0 < normalizeObjective f {e}
  · let p := S.k1PositiveProgram a g hg.1 hg.2.1 hg.2.2 hpos
    have hset := S.k1PositiveProgram_feasible a g hg.1 hg.2.1 hg.2.2 hpos
    have hO' : O ∈ p.feasible := by rw [hset]; exact hO
    have ho' (M : Finset E) (h : M ∈ p.feasible) : p.P.objective M ≤ p.P.objective O := by
      rw [hset] at h
      exact sub_le_sub_right (hopt M h) _
    let J := p.withRetainedBest
    have h := p.archived_guarantees C O hO' ho' δ hδ
    have hl := h.1
    have hq := h.2.1
    rw [hset] at hl hq
    have he : g O / a.expectedFactor ≤ expected J.archivedExpectedLaw.outcomes
        J.archivedExpectedLaw.mass g := by
      rw [a.expectedFactor_eq]
      exact h.2.2.1
    have hp := h.2.2.2
    simp only [k1ArchivedExpectedOutput, k1ArchivedAmplifiedOutput, dif_pos hpos]
    refine ⟨hl, hq, normalizeObjective_expected_transfer f O _ hR h0 _ _
      J.archivedExpectedLaw.probability he, ?_⟩
    refine ((J.archivedAmplifiedLaw C δ).expected_le _ _ ?_).trans hp
    intro M _
    change (if f O / C.target ≤ f M then (0 : ℝ) else 1) ≤
      (if g O / C.target ≤ g M then 0 else 1)
    by_cases h : g O / C.target ≤ g M
    · have h' := normalizeObjective_transfer f M O _ hC h0 h
      rw [if_pos h, if_pos h']
    · rw [if_neg h]
      split_ifs <;> norm_num
  · have hz := objective_zero_of_empty_singletons g hg.1 hg.2.1 hg.2.2 hpos O
    have hfO : f O = f ∅ := sub_eq_zero.mp hz
    have hcase : f O / a.expectedFactor ≤ f ∅ := by rw [hfO]; exact div_le_self h0 hR
    have hconfidence : f O / C.target ≤ f ∅ := by rw [hfO]; exact div_le_self h0 hC
    have hempty : ∅ ∈ S.matchings := GibbsMatching.empty_mem_matchings _ _
    simp only [k1ArchivedExpectedOutput, k1ArchivedAmplifiedOutput, dif_neg hpos, CandidateLaw.pure_expected]
    exact ⟨Finset.singleton_subset_iff.2 hempty, Finset.singleton_subset_iff.2 hempty, hcase,
      by simpa only [if_pos hconfidence] using hδ.le⟩

theorem theoremK1_archived_expectation (f : Finset E → ℝ) (hf : IsSubmodular f)
    (hmono : IsMonotone f) (h0 : 0 ≤ f ∅) (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) :
    let p := S.k1ArchivedExpectedOutput a f hf hmono
    p.outcomes ⊆ S.matchings ∧
      ((1 - a.error) * a.theta * a.eta / (1 + 5 * a.error)) * f O ≤ expected p.outcomes p.mass f := by
  let C : K1Confidence a := ⟨a.trialFactor + 1, lt_add_of_pos_right _ one_pos⟩
  have h := S.theoremK1_verified a f hf hmono h0 O hO hopt C 1 one_pos
  exact ⟨h.1, h.2.2.1⟩

theorem theoremK1_archived_confidence (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (h0 : 0 ≤ f ∅) (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (C : K1Confidence a) (c : ℝ) :
    let n := max 2 (Fintype.card V)
    let δ := (((n : ℝ) ^ ⌈c⌉₊)⁻¹)
    let q := S.k1ArchivedAmplifiedOutput a f hf hmono C δ
    q.outcomes ⊆ S.matchings ∧
      expected q.outcomes q.mass (fun M => if f O / C.target ≤ f M then 0 else 1) ≤
        (n : ℝ) ^ (-c) := by
  classical
  dsimp only
  let n := max 2 (Fintype.card V)
  have hn : 1 ≤ n := le_trans (by norm_num) (le_max_left _ _)
  have hn' : (0 : ℝ) < n := by exact_mod_cast (Nat.zero_lt_one.trans_le hn)
  let δ := (((n : ℝ) ^ ⌈c⌉₊)⁻¹)
  have hδ : 0 < δ := inv_pos.mpr (pow_pos hn' _)
  have h := S.theoremK1_verified a f hf hmono h0 O hO hopt C δ hδ
  exact ⟨h.2.1, h.2.2.2.trans (confidence_integer_le _ hn c)⟩

end SimpleEdgeStream

end

end SubmodularMatching.UpperBoundAssembly
