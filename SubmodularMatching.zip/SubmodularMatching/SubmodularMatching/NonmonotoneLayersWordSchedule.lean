import SubmodularMatching.NonmonotoneLayersDecodedLaw
import SubmodularMatching.NonmonotoneOptimizerSchedule

/-! Finite precision and word bounds for decoding a column on the physical
slot-pair graph. The exponent depends logarithmically on the vertex capacity. -/

namespace SubmodularMatching.NonmonotoneLayers

open NonmonotoneOptimizer

def decoderSteps (k : ℕ) := 3*k+1
def decoderBits (k q : ℕ) := 3*k+2*q+2

theorem decoder_precision (a b k q : ℕ) (hcap : min a b ≤ 2^q) (d w : ℝ)
    (hd : 0 ≤ d) (hd1 : d ≤ 1) (hw1 : w ≤ 1) :
    d*w/(2:ℝ)^(decoderSteps k)+2*((min a b:ℕ):ℝ)^2*(slotMesh (decoderBits k q):ℝ)
      ≤ 1/(scale k:ℝ)^3 := by
  have hm : ((min a b:ℕ):ℝ) ≤ (2:ℝ)^q := by exact_mod_cast hcap
  have hh := mul_le_mul_of_nonneg_left (sq_le_sq' (by linarith [Nat.cast_nonneg (α:=ℝ) (min a b)]) hm)
    (show 0 ≤ 2*(slotMesh (decoderBits k q):ℝ) by dsimp [slotMesh]; positivity)
  have hw := (mul_le_of_le_one_right hd hw1).trans hd1
  have hl := div_le_div_of_nonneg_right hw (show (0:ℝ) ≤ 2^decoderSteps k by positivity)
  calc
    _ ≤ 1/(2:ℝ)^decoderSteps k + 2*((2:ℝ)^q)^2*(slotMesh (decoderBits k q):ℝ) := by linarith only [hh,hl]
    _ = _ := by
      simp only [decoderSteps,decoderBits,slotMesh,scale,Rat.cast_div,Rat.cast_one,
        Nat.cast_pow,Nat.cast_ofNat,pow_add,show 3*k=k*3 by omega,show 2*q=q*2 by omega,pow_mul]
      field_simp
      push_cast
      ring

/-- Every bisection point uses at most the original endpoint denominator times
a power of two. The returned interpolation numerator fits in the step count. -/
theorem ratBisect_grid (estimate : ℚ → ℚ) (target l r : ℚ) (k : ℕ) :
    ∃ i : ℕ, i ≤ 2^k ∧ ratBisect estimate target l r k = l+(r-l)*(i:ℚ)/(2:ℚ)^k := by
  induction k generalizing l r with
  | zero => exact ⟨0,by norm_num,by simp [ratBisect]⟩
  | succ k ih =>
    let mid := (l+r)/2
    by_cases h : estimate mid ≤ target
    · obtain ⟨i,hi,hout⟩ := ih mid r
      refine ⟨2^k+i,by rw [pow_succ]; omega,?_⟩
      rw [ratBisect,if_pos h,hout]
      simp only [mid,Nat.cast_add,Nat.cast_pow,Nat.cast_ofNat,pow_succ]
      field_simp
      ring
    · obtain ⟨i,hi,hout⟩ := ih l mid
      refine ⟨i,by rw [pow_succ]; omega,?_⟩
      rw [ratBisect,if_neg h,hout]
      simp only [mid,pow_succ]
      field_simp
      ring

/-- In particular, decoding multiplies the input rational mass by just one
bounded dyadic fraction. -/
theorem decodedMass_grid (a b bits steps : ℕ) (θ₁ θ₂ d w : ℚ) :
    ∃ i : ℕ, i ≤ 2^steps ∧ decodedMass a b bits steps θ₁ θ₂ d w = d*w*i/(2:ℚ)^steps := by
  simpa only [decodedMass,sub_zero,zero_add] using
    ratBisect_grid (estimateUnion a b bits θ₁ θ₂) (w/(1/d+w)) 0 (d*w) steps

end SubmodularMatching.NonmonotoneLayers
