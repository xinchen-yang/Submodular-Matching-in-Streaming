import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull014_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 682, 684, 2, 0xab155aaa⟩ (by decide +kernel)

private def hull014_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 684, 686, 1, 0x1572ac⟩ (by decide +kernel)

private def hull014_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 686, 691, 1, 0x159aae⟩ (by decide +kernel)

private def hull014_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 21, 4, 0x1502804c09011⟩ (by decide +kernel)

private def hull014_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 567, 851, 49, 0x1a9b4d698d2195b2a61ec3185af95f0b9d72ae45c6b716dada5b2b5d6b2d55a8b4d622c2582afd5f2ab554a9d53295528a4948a895109fd3f27b4f49cd392624c29812fa37⟩ (by decide +kernel)

private def hull014_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 673, 691, 5, 0x159aab554a9d532a1⟩ (by decide +kernel)

private def hull014_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 682, 686, 2, 0xab955aaa⟩ (by decide +kernel)

private def hull014_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 26, 9, 0xd01903005c0b01502804c09011⟩ (by decide +kernel)

private def hull014_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 684, 685, 1, 0x156aac⟩ (by decide +kernel)

private def hull014_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 685, 686, 1, 0x1572ad⟩ (by decide +kernel)

private def hull014_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 686, 688, 1, 0x1582ae⟩ (by decide +kernel)

private def hull014_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 19, 2, 0x4c09011⟩ (by decide +kernel)

private def hull014_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 19, 21, 2, 0x540a013⟩ (by decide +kernel)

private def hull014_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 688, 691, 1, 0x159ab0⟩ (by decide +kernel)

private def hull014_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 686, 687, 1, 0x157aae⟩ (by decide +kernel)

private def hull014_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 687, 688, 1, 0x1582af⟩ (by decide +kernel)

private def hull014_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 688, 689, 1, 0x158ab0⟩ (by decide +kernel)

private def hull014_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 689, 691, 1, 0x159ab1⟩ (by decide +kernel)

private def hull014_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 35, 18, 0x8c1102104007c0f01d03806c0d01903005c0b01502804c09011⟩ (by decide +kernel)

private def hull014_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 691, 692, 1, 0x15a2b3⟩ (by decide +kernel)

private def hull014_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 692, 693, 1, 0x15aab4⟩ (by decide +kernel)

private def hull014_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 693, 695, 1, 0x15bab5⟩ (by decide +kernel)

private def hull014_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 695, 700, 1, 0x15e2b7⟩ (by decide +kernel)

private def hull014_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 700, 709, 7, 0x58ab11612c157eaf95eabc⟩ (by decide +kernel)

private def hull014_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 691, 700, 1, 0x15e2b3⟩ (by decide +kernel)

private def hull014_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 691, 693, 1, 0x15aab3⟩ (by decide +kernel)

private def hull014_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 691, 695, 1, 0x15bab3⟩ (by decide +kernel)

private def hull014_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 1135, 1, 0x237b53⟩ (by decide +kernel)

private def hull014_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 693, 694, 1, 0x15b2b5⟩ (by decide +kernel)

private def hull014_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 694, 695, 1, 0x15bab6⟩ (by decide +kernel)

private def hull014_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 695, 697, 1, 0x15cab7⟩ (by decide +kernel)

private def hull014_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 697, 700, 1, 0x15e2b9⟩ (by decide +kernel)

private def hull014_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 695, 696, 1, 0x15c2b7⟩ (by decide +kernel)

private def hull014_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 696, 697, 1, 0x15cab8⟩ (by decide +kernel)

private def hull014_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 697, 698, 1, 0x15d2b9⟩ (by decide +kernel)

private def hull014_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 698, 700, 1, 0x15e2ba⟩ (by decide +kernel)

private def hull014_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 698, 699, 1, 0x15daba⟩ (by decide +kernel)

private def hull014_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 699, 700, 1, 0x15e2bb⟩ (by decide +kernel)

private def hull014_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 691, 709, 6, 0xb15622c2582afd5f2b3⟩ (by decide +kernel)

private def hull014_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 700, 702, 2, 0xaf95eabc⟩ (by decide +kernel)

private def hull014_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 702, 704, 2, 0xb015fabe⟩ (by decide +kernel)

private def hull014_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 704, 709, 4, 0x2c5588b0960ac0⟩ (by decide +kernel)

private def hull014_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 700, 704, 4, 0x2c057eaf95eabc⟩ (by decide +kernel)

private def hull014_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 702, 703, 1, 0x15fabe⟩ (by decide +kernel)

private def hull014_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 703, 704, 1, 0x1602bf⟩ (by decide +kernel)

private def hull014_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 567, 709, 26, 0xb15622c2582afd5f2ab554a9d53295528a4948a895109fd3f27b4f49cd392624c29812fa37⟩ (by decide +kernel)

private def hull014_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 704, 706, 2, 0xb0960ac0⟩ (by decide +kernel)

private def hull014_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 706, 707, 1, 0x161ac2⟩ (by decide +kernel)

private def hull014_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 707, 709, 2, 0xb15622c3⟩ (by decide +kernel)

private def hull014_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 706, 709, 2, 0xb15622c2⟩ (by decide +kernel)

private def hull014_050 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 717, 1, 0x166ac5⟩ (by decide +kernel)

private def hull014_051 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 717, 726, 8, 0x2d65aab5169ad25a0b3d672cd⟩ (by decide +kernel)

private def hull014_052 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 726, 744, 10, 0xba173ae55c8b8d6e2db5b4b656bad6⟩ (by decide +kernel)

private def hull014_053 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 744, 780, 4, 0x30c616be57c2e8⟩ (by decide +kernel)

private def hull014_054 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 780, 851, 7, 0x6a6d35a6348656ca987b0c⟩ (by decide +kernel)

private def hull014_055 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 713, 1, 0x164ac5⟩ (by decide +kernel)

private def hull014_056 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 713, 717, 1, 0x166ac9⟩ (by decide +kernel)

private def hull014_057 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 711, 1, 0x163ac5⟩ (by decide +kernel)

private def hull014_058 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 711, 713, 1, 0x164ac7⟩ (by decide +kernel)

private def hull014_059 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 851, 24, 0x35369ad31a432b654c3d8630b5f2be173ae55c8b8d6e2db5b4b656bad65aab5169ac5⟩ (by decide +kernel)

private def hull014_060 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 710, 1, 0x1632c5⟩ (by decide +kernel)

private def hull014_061 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 710, 711, 1, 0x163ac6⟩ (by decide +kernel)

private def hull014_062 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 35, 26, 0x8c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def supportedCone1792 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨682, 684, 684, 683, 684⟩, ⟨5000000000, 49261168, 0, 0, 2065000000000, 669435060057⟩⟩
    hull014_000 2 (by decide +kernel)

private def supportedCone1793 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨682, 684, 682, 682, 683⟩, ⟨0, 0, 5000000000, 47091912, 2055000000000, 669338706977⟩⟩
    hull014_000 0 (by decide +kernel)

private def supportedCone1794 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨682, 684, 683, 682, 684⟩, ⟨5000000000, 47091912, 5000000000, 49261168, 2060000000000, 669385798889⟩⟩
    hull014_000 1 (by decide +kernel)

private def supportedCone1795 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨684, 686, 684, 684, 686⟩, ⟨0, 0, 7501365694, 73333727, 2065000000000, 669435060057⟩⟩
    hull014_001 0 (by decide +kernel)

private def supportedCone1796 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨686, 691, 686, 686, 691⟩, ⟨0, 0, 17498634306, 169014025, 2072501365694, 669508393784⟩⟩
    hull014_002 0 (by decide +kernel)

private def supportedCone1797 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 21, 17, 17, 18⟩, ⟨0, 0, 1385503170, 16446452, 237415209672, 37965431⟩⟩
    hull014_003 0 (by decide +kernel)

private def supportedCone1798 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 702, 683, 703⟩, ⟨75000000000, 712929474, 5000000000, 51840326, 2135000000000, 670098728363⟩⟩
    hull014_004 21 (by decide +kernel)

private def supportedCone1799 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨673, 691, 683, 682, 691⟩, ⟨5000000000, 47091912, 30000000000, 291608920, 2060000000000, 669385798889⟩⟩
    hull014_005 4 (by decide +kernel)

private def supportedCone1800 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨682, 686, 683, 682, 686⟩, ⟨5000000000, 47091912, 12501365694, 122594895, 2060000000000, 669385798889⟩⟩
    hull014_006 1 (by decide +kernel)

private def supportedCone1801 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨682, 686, 682, 682, 683⟩, ⟨0, 0, 5000000000, 47091912, 2055000000000, 669338706977⟩⟩
    hull014_006 0 (by decide +kernel)

private def supportedCone1802 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 26, 19, 18, 20⟩, ⟨1199287158, 15058052, 655849173, 8806333, 240000000000, 69469935⟩⟩
    hull014_007 2 (by decide +kernel)

private def supportedCone1803 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨682, 686, 686, 683, 686⟩, ⟨12501365694, 122594895, 0, 0, 2072501365694, 669508393784⟩⟩
    hull014_006 2 (by decide +kernel)

private def supportedCone1804 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨684, 686, 686, 684, 686⟩, ⟨7501365694, 73333727, 0, 0, 2072501365694, 669508393784⟩⟩
    hull014_001 1 (by decide +kernel)

private def supportedCone1805 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨684, 685, 684, 684, 685⟩, ⟨0, 0, 5000000000, 48945355, 2065000000000, 669435060057⟩⟩
    hull014_008 0 (by decide +kernel)

private def supportedCone1806 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨685, 686, 685, 685, 686⟩, ⟨0, 0, 2501365694, 24388372, 2070000000000, 669484005412⟩⟩
    hull014_009 0 (by decide +kernel)

private def supportedCone1807 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨684, 685, 685, 684, 685⟩, ⟨5000000000, 48945355, 0, 0, 2070000000000, 669484005412⟩⟩
    hull014_008 1 (by decide +kernel)

private def supportedCone1808 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨685, 686, 686, 685, 686⟩, ⟨2501365694, 24388372, 0, 0, 2072501365694, 669508393784⟩⟩
    hull014_009 1 (by decide +kernel)

private def supportedCone1809 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨673, 691, 691, 683, 691⟩, ⟨30000000000, 291608920, 0, 0, 2090000000000, 669677407809⟩⟩
    hull014_005 5 (by decide +kernel)

private def supportedCone1810 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨686, 688, 688, 686, 688⟩, ⟨7498634306, 72829717, 0, 0, 2080000000000, 669581223501⟩⟩
    hull014_010 1 (by decide +kernel)

private def supportedCone1811 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 19, 17, 17, 18⟩, ⟨0, 0, 1385503170, 16446452, 237415209672, 37965431⟩⟩
    hull014_011 0 (by decide +kernel)

private def supportedCone1812 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨686, 688, 686, 686, 688⟩, ⟨0, 0, 7498634306, 72829717, 2072501365694, 669508393784⟩⟩
    hull014_010 0 (by decide +kernel)

private def supportedCone1813 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨19, 21, 19, 19, 20⟩, ⟨0, 0, 655849173, 8806333, 240000000000, 69469935⟩⟩
    hull014_012 0 (by decide +kernel)

private def supportedCone1814 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨688, 691, 688, 688, 691⟩, ⟨0, 0, 10000000000, 96184308, 2080000000000, 669581223501⟩⟩
    hull014_013 0 (by decide +kernel)

private def supportedCone1815 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨686, 687, 686, 686, 687⟩, ⟨0, 0, 2498634306, 24337152, 2072501365694, 669508393784⟩⟩
    hull014_014 0 (by decide +kernel)

private def supportedCone1816 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨686, 687, 687, 686, 687⟩, ⟨2498634306, 24337152, 0, 0, 2075000000000, 669532730936⟩⟩
    hull014_014 1 (by decide +kernel)

private def supportedCone1817 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨687, 688, 687, 687, 688⟩, ⟨0, 0, 5000000000, 48492565, 2075000000000, 669532730936⟩⟩
    hull014_015 0 (by decide +kernel)

private def supportedCone1818 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨687, 688, 688, 687, 688⟩, ⟨5000000000, 48492565, 0, 0, 2080000000000, 669581223501⟩⟩
    hull014_015 1 (by decide +kernel)

private def supportedCone1819 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨686, 691, 691, 686, 691⟩, ⟨17498634306, 169014025, 0, 0, 2090000000000, 669677407809⟩⟩
    hull014_002 1 (by decide +kernel)

private def supportedCone1820 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨688, 689, 688, 688, 689⟩, ⟨0, 0, 5000000000, 48201343, 2080000000000, 669581223501⟩⟩
    hull014_016 0 (by decide +kernel)

private def supportedCone1821 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨689, 691, 689, 689, 691⟩, ⟨0, 0, 5000000000, 47982965, 2085000000000, 669629424844⟩⟩
    hull014_017 0 (by decide +kernel)

private def supportedCone1822 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨688, 689, 689, 688, 689⟩, ⟨5000000000, 48201343, 0, 0, 2085000000000, 669629424844⟩⟩
    hull014_016 1 (by decide +kernel)

private def supportedCone1823 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 35, 34, 35⟩, ⟨1503327172, 68709630, 0, 0, 260000000000, 651686301⟩⟩
    hull014_018 18 (by decide +kernel)

def appendixHullConeBlock0056 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1792,
    supportedCone1793,
    supportedCone1794,
    supportedCone1795,
    supportedCone1796,
    supportedCone1797,
    supportedCone1798,
    supportedCone1799,
    supportedCone1800,
    supportedCone1801,
    supportedCone1802,
    supportedCone1803,
    supportedCone1804,
    supportedCone1805,
    supportedCone1806,
    supportedCone1807,
    supportedCone1808,
    supportedCone1809,
    supportedCone1810,
    supportedCone1811,
    supportedCone1812,
    supportedCone1813,
    supportedCone1814,
    supportedCone1815,
    supportedCone1816,
    supportedCone1817,
    supportedCone1818,
    supportedCone1819,
    supportedCone1820,
    supportedCone1821,
    supportedCone1822,
    supportedCone1823,
  ], rfl⟩

private def supportedCone1824 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 32, 31, 33⟩, ⟨1405628119, 52888125, 1263823080, 49116029, 256405628119, 499191035⟩⟩
    hull014_018 15 (by decide +kernel)

private def supportedCone1825 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨688, 691, 691, 688, 691⟩, ⟨10000000000, 96184308, 0, 0, 2090000000000, 669677407809⟩⟩
    hull014_013 1 (by decide +kernel)

private def supportedCone1826 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨689, 691, 691, 689, 691⟩, ⟨5000000000, 47982965, 0, 0, 2090000000000, 669677407809⟩⟩
    hull014_017 1 (by decide +kernel)

private def supportedCone1827 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨691, 692, 692, 691, 692⟩, ⟨5000000000, 47734946, 0, 0, 2095000000000, 669725142755⟩⟩
    hull014_019 1 (by decide +kernel)

private def supportedCone1828 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨691, 692, 691, 691, 692⟩, ⟨0, 0, 5000000000, 47734946, 2090000000000, 669677407809⟩⟩
    hull014_019 0 (by decide +kernel)

private def supportedCone1829 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨692, 693, 692, 692, 693⟩, ⟨0, 0, 5000000000, 47480791, 2095000000000, 669725142755⟩⟩
    hull014_020 0 (by decide +kernel)

private def supportedCone1830 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨693, 695, 693, 693, 695⟩, ⟨0, 0, 8000000000, 75450430, 2100000000000, 669772623546⟩⟩
    hull014_021 0 (by decide +kernel)

private def supportedCone1831 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨695, 700, 695, 695, 700⟩, ⟨0, 0, 22000000000, 204473518, 2108000000000, 669848073976⟩⟩
    hull014_022 0 (by decide +kernel)

private def supportedCone1832 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 709, 700, 700, 701⟩, ⟨0, 0, 2000000000, 18322581, 2130000000000, 670052547494⟩⟩
    hull014_023 0 (by decide +kernel)

private def supportedCone1833 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨691, 700, 691, 691, 700⟩, ⟨0, 0, 40000000000, 375139685, 2090000000000, 669677407809⟩⟩
    hull014_024 0 (by decide +kernel)

private def supportedCone1834 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨691, 693, 691, 691, 693⟩, ⟨0, 0, 10000000000, 95215737, 2090000000000, 669677407809⟩⟩
    hull014_025 0 (by decide +kernel)

private def supportedCone1835 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨691, 693, 693, 691, 693⟩, ⟨10000000000, 95215737, 0, 0, 2100000000000, 669772623546⟩⟩
    hull014_025 1 (by decide +kernel)

private def supportedCone1836 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 20, 19, 21⟩, ⟨655849173, 8806333, 1970044404, 29103683, 240655849173, 78276268⟩⟩
    hull014_018 3 (by decide +kernel)

private def supportedCone1837 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨691, 695, 691, 691, 695⟩, ⟨0, 0, 18000000000, 170666167, 2090000000000, 669677407809⟩⟩
    hull014_026 0 (by decide +kernel)

private def supportedCone1838 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨692, 693, 693, 692, 693⟩, ⟨5000000000, 47480791, 0, 0, 2100000000000, 669772623546⟩⟩
    hull014_020 1 (by decide +kernel)

private def supportedCone1839 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨691, 695, 695, 691, 695⟩, ⟨18000000000, 170666167, 0, 0, 2108000000000, 669848073976⟩⟩
    hull014_026 1 (by decide +kernel)

private def supportedCone1840 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 1135, 851, 851, 1135⟩, ⟨0, 0, 1999999999997160000000000, 49319724385368, 2840000000000, 680275614632⟩⟩
    hull014_027 0 (by decide +kernel)

private def supportedCone1841 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨693, 694, 693, 693, 694⟩, ⟨0, 0, 5000000000, 47251198, 2100000000000, 669772623546⟩⟩
    hull014_028 0 (by decide +kernel)

private def supportedCone1842 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨694, 695, 694, 694, 695⟩, ⟨0, 0, 3000000000, 28199232, 2105000000000, 669819874744⟩⟩
    hull014_029 0 (by decide +kernel)

private def supportedCone1843 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨693, 695, 695, 693, 695⟩, ⟨8000000000, 75450430, 0, 0, 2108000000000, 669848073976⟩⟩
    hull014_021 1 (by decide +kernel)

private def supportedCone1844 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨693, 694, 694, 693, 694⟩, ⟨5000000000, 47251198, 0, 0, 2105000000000, 669819874744⟩⟩
    hull014_028 1 (by decide +kernel)

private def supportedCone1845 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨694, 695, 695, 694, 695⟩, ⟨3000000000, 28199232, 0, 0, 2108000000000, 669848073976⟩⟩
    hull014_029 1 (by decide +kernel)

private def supportedCone1846 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨695, 697, 695, 695, 697⟩, ⟨0, 0, 7000000000, 65589328, 2108000000000, 669848073976⟩⟩
    hull014_030 0 (by decide +kernel)

private def supportedCone1847 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨697, 700, 697, 697, 700⟩, ⟨0, 0, 15000000000, 138884190, 2115000000000, 669913663304⟩⟩
    hull014_031 0 (by decide +kernel)

private def supportedCone1848 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨695, 697, 697, 695, 697⟩, ⟨7000000000, 65589328, 0, 0, 2115000000000, 669913663304⟩⟩
    hull014_030 1 (by decide +kernel)

private def supportedCone1849 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨695, 696, 695, 695, 696⟩, ⟨0, 0, 2000000000, 18789162, 2108000000000, 669848073976⟩⟩
    hull014_032 0 (by decide +kernel)

private def supportedCone1850 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨696, 697, 696, 696, 697⟩, ⟨0, 0, 5000000000, 46800166, 2110000000000, 669866863138⟩⟩
    hull014_033 0 (by decide +kernel)

private def supportedCone1851 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨695, 696, 696, 695, 696⟩, ⟨2000000000, 18789162, 0, 0, 2110000000000, 669866863138⟩⟩
    hull014_032 1 (by decide +kernel)

private def supportedCone1852 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨695, 700, 700, 695, 700⟩, ⟨22000000000, 204473518, 0, 0, 2130000000000, 670052547494⟩⟩
    hull014_022 1 (by decide +kernel)

private def supportedCone1853 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨696, 697, 697, 696, 697⟩, ⟨5000000000, 46800166, 0, 0, 2115000000000, 669913663304⟩⟩
    hull014_033 1 (by decide +kernel)

private def supportedCone1854 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 26, 18, 17, 19⟩, ⟨1385503170, 16446452, 1199287158, 15058052, 238800712842, 54411883⟩⟩
    hull014_007 1 (by decide +kernel)

private def supportedCone1855 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨697, 698, 698, 697, 698⟩, ⟨5000000000, 46539189, 0, 0, 2120000000000, 669960202493⟩⟩
    hull014_034 1 (by decide +kernel)

def appendixHullConeBlock0057 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1824,
    supportedCone1825,
    supportedCone1826,
    supportedCone1827,
    supportedCone1828,
    supportedCone1829,
    supportedCone1830,
    supportedCone1831,
    supportedCone1832,
    supportedCone1833,
    supportedCone1834,
    supportedCone1835,
    supportedCone1836,
    supportedCone1837,
    supportedCone1838,
    supportedCone1839,
    supportedCone1840,
    supportedCone1841,
    supportedCone1842,
    supportedCone1843,
    supportedCone1844,
    supportedCone1845,
    supportedCone1846,
    supportedCone1847,
    supportedCone1848,
    supportedCone1849,
    supportedCone1850,
    supportedCone1851,
    supportedCone1852,
    supportedCone1853,
    supportedCone1854,
    supportedCone1855,
  ], rfl⟩

private def supportedCone1856 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨697, 698, 697, 697, 698⟩, ⟨0, 0, 5000000000, 46539189, 2115000000000, 669913663304⟩⟩
    hull014_034 0 (by decide +kernel)

private def supportedCone1857 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨698, 700, 698, 698, 700⟩, ⟨0, 0, 10000000000, 92345001, 2120000000000, 669960202493⟩⟩
    hull014_035 0 (by decide +kernel)

private def supportedCone1858 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨697, 700, 700, 697, 700⟩, ⟨15000000000, 138884190, 0, 0, 2130000000000, 670052547494⟩⟩
    hull014_031 1 (by decide +kernel)

private def supportedCone1859 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨698, 699, 698, 698, 699⟩, ⟨0, 0, 5000000000, 46262552, 2120000000000, 669960202493⟩⟩
    hull014_036 0 (by decide +kernel)

private def supportedCone1860 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨699, 700, 699, 699, 700⟩, ⟨0, 0, 5000000000, 46082449, 2125000000000, 670006465045⟩⟩
    hull014_037 0 (by decide +kernel)

private def supportedCone1861 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨698, 699, 699, 698, 699⟩, ⟨5000000000, 46262552, 0, 0, 2125000000000, 670006465045⟩⟩
    hull014_036 1 (by decide +kernel)

private def supportedCone1862 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨698, 700, 700, 698, 700⟩, ⟨10000000000, 92345001, 0, 0, 2130000000000, 670052547494⟩⟩
    hull014_035 1 (by decide +kernel)

private def supportedCone1863 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨691, 700, 700, 691, 700⟩, ⟨40000000000, 375139685, 0, 0, 2130000000000, 670052547494⟩⟩
    hull014_024 1 (by decide +kernel)

private def supportedCone1864 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨691, 709, 702, 691, 703⟩, ⟨45000000000, 421320554, 5000000000, 51840326, 2135000000000, 670098728363⟩⟩
    hull014_038 1 (by decide +kernel)

private def supportedCone1865 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨699, 700, 700, 699, 700⟩, ⟨5000000000, 46082449, 0, 0, 2130000000000, 670052547494⟩⟩
    hull014_037 1 (by decide +kernel)

private def supportedCone1866 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 709, 701, 700, 702⟩, ⟨2000000000, 18322581, 3000000000, 27858288, 2132000000000, 670070870075⟩⟩
    hull014_023 1 (by decide +kernel)

private def supportedCone1867 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 702, 701, 700, 702⟩, ⟨2000000000, 18322581, 3000000000, 27858288, 2132000000000, 670070870075⟩⟩
    hull014_039 1 (by decide +kernel)

private def supportedCone1868 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 702, 700, 700, 701⟩, ⟨0, 0, 2000000000, 18322581, 2130000000000, 670052547494⟩⟩
    hull014_039 0 (by decide +kernel)

private def supportedCone1869 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨702, 704, 702, 702, 703⟩, ⟨0, 0, 5000000000, 51840326, 2135000000000, 670098728363⟩⟩
    hull014_040 0 (by decide +kernel)

private def supportedCone1870 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨704, 709, 704, 704, 705⟩, ⟨0, 0, 1000000000, 10367938, 2144000000000, 670192310249⟩⟩
    hull014_041 0 (by decide +kernel)

private def supportedCone1871 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 702, 702, 701, 702⟩, ⟨3000000000, 27858288, 0, 0, 2135000000000, 670098728363⟩⟩
    hull014_039 2 (by decide +kernel)

private def supportedCone1872 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 704, 702, 701, 703⟩, ⟨3000000000, 27858288, 5000000000, 51840326, 2135000000000, 670098728363⟩⟩
    hull014_042 2 (by decide +kernel)

private def supportedCone1873 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 704, 701, 700, 702⟩, ⟨2000000000, 18322581, 3000000000, 27858288, 2132000000000, 670070870075⟩⟩
    hull014_042 1 (by decide +kernel)

private def supportedCone1874 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 709, 702, 701, 703⟩, ⟨3000000000, 27858288, 5000000000, 51840326, 2135000000000, 670098728363⟩⟩
    hull014_023 2 (by decide +kernel)

private def supportedCone1875 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 727, 726, 729⟩, ⟨5000000000, 64268160, 10000000000, 128994694, 2255000000000, 671439498852⟩⟩
    hull014_004 30 (by decide +kernel)

private def supportedCone1876 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨702, 703, 702, 702, 703⟩, ⟨0, 0, 5000000000, 51840326, 2135000000000, 670098728363⟩⟩
    hull014_043 0 (by decide +kernel)

private def supportedCone1877 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨703, 704, 703, 703, 704⟩, ⟨0, 0, 4000000000, 41741560, 2140000000000, 670150568689⟩⟩
    hull014_044 0 (by decide +kernel)

private def supportedCone1878 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 705, 703, 706⟩, ⟨5000000000, 52109498, 5000000000, 53174514, 2145000000000, 670202678187⟩⟩
    hull014_004 23 (by decide +kernel)

private def supportedCone1879 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 703, 702, 705⟩, ⟨5000000000, 51840326, 5000000000, 52109498, 2140000000000, 670150568689⟩⟩
    hull014_004 22 (by decide +kernel)

private def supportedCone1880 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 704, 703, 702, 704⟩, ⟨5000000000, 51840326, 4000000000, 41741560, 2140000000000, 670150568689⟩⟩
    hull014_042 3 (by decide +kernel)

private def supportedCone1881 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 726, 725, 727⟩, ⟨5000000000, 62542085, 5000000000, 64268160, 2250000000000, 671375230692⟩⟩
    hull014_004 29 (by decide +kernel)

private def supportedCone1882 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨700, 704, 704, 703, 704⟩, ⟨4000000000, 41741560, 0, 0, 2144000000000, 670192310249⟩⟩
    hull014_042 4 (by decide +kernel)

private def supportedCone1883 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 709, 708, 706, 709⟩, ⟨10000000000, 110466541, 5000000000, 60630849, 2160000000000, 670366319242⟩⟩
    hull014_045 25 (by decide +kernel)

private def supportedCone1884 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 709, 702, 683, 703⟩, ⟨75000000000, 712929474, 5000000000, 51840326, 2135000000000, 670098728363⟩⟩
    hull014_045 21 (by decide +kernel)

private def supportedCone1885 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨704, 709, 705, 704, 706⟩, ⟨1000000000, 10367938, 5000000000, 53174514, 2145000000000, 670202678187⟩⟩
    hull014_041 1 (by decide +kernel)

private def supportedCone1886 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 723, 708, 724⟩, ⟨75000000000, 829267247, 5000000000, 56992018, 2235000000000, 671195586489⟩⟩
    hull014_004 26 (by decide +kernel)

private def supportedCone1887 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 706, 705, 708⟩, ⟨5000000000, 53174514, 10000000000, 110466541, 2150000000000, 670255852701⟩⟩
    hull014_004 24 (by decide +kernel)

def appendixHullConeBlock0058 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1856,
    supportedCone1857,
    supportedCone1858,
    supportedCone1859,
    supportedCone1860,
    supportedCone1861,
    supportedCone1862,
    supportedCone1863,
    supportedCone1864,
    supportedCone1865,
    supportedCone1866,
    supportedCone1867,
    supportedCone1868,
    supportedCone1869,
    supportedCone1870,
    supportedCone1871,
    supportedCone1872,
    supportedCone1873,
    supportedCone1874,
    supportedCone1875,
    supportedCone1876,
    supportedCone1877,
    supportedCone1878,
    supportedCone1879,
    supportedCone1880,
    supportedCone1881,
    supportedCone1882,
    supportedCone1883,
    supportedCone1884,
    supportedCone1885,
    supportedCone1886,
    supportedCone1887,
  ], rfl⟩

private def supportedCone1888 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨704, 709, 706, 705, 708⟩, ⟨5000000000, 53174514, 10000000000, 110466541, 2150000000000, 670255852701⟩⟩
    hull014_041 2 (by decide +kernel)

private def supportedCone1889 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨704, 709, 708, 706, 709⟩, ⟨10000000000, 110466541, 5000000000, 60630849, 2160000000000, 670366319242⟩⟩
    hull014_041 3 (by decide +kernel)

private def supportedCone1890 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨704, 706, 706, 705, 706⟩, ⟨5000000000, 53174514, 0, 0, 2150000000000, 670255852701⟩⟩
    hull014_046 2 (by decide +kernel)

private def supportedCone1891 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨706, 707, 707, 706, 707⟩, ⟨5000000000, 55237347, 0, 0, 2155000000000, 670311090048⟩⟩
    hull014_047 1 (by decide +kernel)

private def supportedCone1892 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨707, 709, 707, 707, 708⟩, ⟨0, 0, 5000000000, 55229194, 2155000000000, 670311090048⟩⟩
    hull014_048 0 (by decide +kernel)

private def supportedCone1893 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨706, 709, 708, 706, 709⟩, ⟨10000000000, 110466541, 5000000000, 60630849, 2160000000000, 670366319242⟩⟩
    hull014_049 1 (by decide +kernel)

private def supportedCone1894 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 708, 706, 723⟩, ⟨10000000000, 110466541, 75000000000, 829267247, 2160000000000, 670366319242⟩⟩
    hull014_004 25 (by decide +kernel)

private def supportedCone1895 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 709, 706, 705, 708⟩, ⟨5000000000, 53174514, 10000000000, 110466541, 2150000000000, 670255852701⟩⟩
    hull014_045 24 (by decide +kernel)

private def supportedCone1896 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 709, 709, 708, 709⟩, ⟨5000000000, 60630849, 0, 0, 2165000000000, 670426950091⟩⟩
    hull014_045 26 (by decide +kernel)

private def supportedCone1897 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨707, 709, 708, 707, 709⟩, ⟨5000000000, 55229194, 5000000000, 60630849, 2160000000000, 670366319242⟩⟩
    hull014_048 1 (by decide +kernel)

private def supportedCone1898 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 709, 567, 567, 607⟩, ⟨0, 0, 110051856392, 0, 1667569655535, 667919698423⟩⟩
    hull014_045 0 (by decide +kernel)

private def supportedCone1899 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨707, 709, 709, 708, 709⟩, ⟨5000000000, 60630849, 0, 0, 2165000000000, 670426950091⟩⟩
    hull014_048 2 (by decide +kernel)

private def supportedCone1900 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 717, 709, 709, 717⟩, ⟨0, 0, 40000000000, 448102357, 2165000000000, 670426950091⟩⟩
    hull014_050 0 (by decide +kernel)

private def supportedCone1901 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 726, 717, 717, 718⟩, ⟨0, 0, 5000000000, 52372338, 2205000000000, 670875052448⟩⟩
    hull014_051 0 (by decide +kernel)

private def supportedCone1902 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨726, 744, 726, 726, 727⟩, ⟨0, 0, 5000000000, 64268160, 2250000000000, 671375230692⟩⟩
    hull014_052 0 (by decide +kernel)

private def supportedCone1903 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨744, 780, 744, 744, 760⟩, ⟨0, 0, 80000000000, 1187625524, 2335000000000, 672565691996⟩⟩
    hull014_053 0 (by decide +kernel)

private def supportedCone1904 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨780, 851, 780, 780, 783⟩, ⟨0, 0, 15000000000, 226745522, 2505000000000, 675094483365⟩⟩
    hull014_054 0 (by decide +kernel)

private def supportedCone1905 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 713, 709, 709, 713⟩, ⟨0, 0, 20000000000, 236045683, 2165000000000, 670426950091⟩⟩
    hull014_055 0 (by decide +kernel)

private def supportedCone1906 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨713, 717, 713, 713, 717⟩, ⟨0, 0, 20000000000, 212056674, 2185000000000, 670662995774⟩⟩
    hull014_056 0 (by decide +kernel)

private def supportedCone1907 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 711, 709, 709, 711⟩, ⟨0, 0, 10000000000, 128672484, 2165000000000, 670426950091⟩⟩
    hull014_057 0 (by decide +kernel)

private def supportedCone1908 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨711, 713, 711, 711, 713⟩, ⟨0, 0, 10000000000, 107373199, 2175000000000, 670555622575⟩⟩
    hull014_058 0 (by decide +kernel)

private def supportedCone1909 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 851, 723, 709, 724⟩, ⟨70000000000, 768636398, 5000000000, 56992018, 2235000000000, 671195586489⟩⟩
    hull014_059 1 (by decide +kernel)

private def supportedCone1910 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 710, 709, 709, 710⟩, ⟨0, 0, 5000000000, 69017373, 2165000000000, 670426950091⟩⟩
    hull014_060 0 (by decide +kernel)

private def supportedCone1911 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨710, 711, 711, 710, 711⟩, ⟨5000000000, 59655111, 0, 0, 2175000000000, 670555622575⟩⟩
    hull014_061 1 (by decide +kernel)

private def supportedCone1912 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 26, 23, 22, 24⟩, ⟨929323095, 19209070, 1407888149, 33953019, 245000000000, 153223181⟩⟩
    hull014_007 6 (by decide +kernel)

private def supportedCone1913 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨710, 711, 710, 710, 711⟩, ⟨0, 0, 5000000000, 59655111, 2170000000000, 670495967464⟩⟩
    hull014_061 0 (by decide +kernel)

private def supportedCone1914 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 24, 23, 25⟩, ⟨1407888149, 33953019, 1142765542, 29098135, 246407888149, 187176200⟩⟩
    hull014_062 15 (by decide +kernel)

private def supportedCone1915 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 710, 710, 709, 710⟩, ⟨5000000000, 69017373, 0, 0, 2170000000000, 670495967464⟩⟩
    hull014_060 1 (by decide +kernel)

private def supportedCone1916 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 25, 24, 26⟩, ⟨1142765542, 29098135, 1603882869, 43246842, 247550653691, 216274335⟩⟩
    hull014_062 16 (by decide +kernel)

private def supportedCone1917 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 27, 26, 28⟩, ⟨845463440, 24459535, 1383292683, 42240405, 250000000000, 283980712⟩⟩
    hull014_062 18 (by decide +kernel)

private def supportedCone1918 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨711, 713, 713, 711, 713⟩, ⟨10000000000, 107373199, 0, 0, 2185000000000, 670662995774⟩⟩
    hull014_058 1 (by decide +kernel)

private def supportedCone1919 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 711, 711, 709, 711⟩, ⟨10000000000, 128672484, 0, 0, 2175000000000, 670555622575⟩⟩
    hull014_057 1 (by decide +kernel)

def appendixHullConeBlock0059 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1888,
    supportedCone1889,
    supportedCone1890,
    supportedCone1891,
    supportedCone1892,
    supportedCone1893,
    supportedCone1894,
    supportedCone1895,
    supportedCone1896,
    supportedCone1897,
    supportedCone1898,
    supportedCone1899,
    supportedCone1900,
    supportedCone1901,
    supportedCone1902,
    supportedCone1903,
    supportedCone1904,
    supportedCone1905,
    supportedCone1906,
    supportedCone1907,
    supportedCone1908,
    supportedCone1909,
    supportedCone1910,
    supportedCone1911,
    supportedCone1912,
    supportedCone1913,
    supportedCone1914,
    supportedCone1915,
    supportedCone1916,
    supportedCone1917,
    supportedCone1918,
    supportedCone1919,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
