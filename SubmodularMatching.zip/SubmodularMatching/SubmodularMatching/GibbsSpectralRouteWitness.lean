import SubmodularMatching.GibbsSpectralRoute

/-!
# Finite routes and their lengths

Every transition decreases the number of differing edges by exactly one.
Thus the oriented transitions form a finite set with a telescoping sum.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [LinearOrder E] [DecidableEq V]

omit [DecidableEq V] in
theorem ForwardChange.edge_singleton {I F M N : Finset E} {e : E}
    (h : ForwardChange I F M N e) : diffEdges M N = {e} := by
  ext d
  rcases h with ⟨_,he,rfl⟩ | ⟨_,he,rfl⟩
  · simp only [mem_diffEdges, Finset.mem_erase, Finset.mem_singleton]
    constructor
    · tauto
    · rintro rfl
      tauto
  · simp only [mem_diffEdges, Finset.mem_insert, Finset.mem_singleton]
    constructor
    · tauto
    · rintro rfl
      tauto

omit [DecidableEq V] in
theorem ForwardChange.diff_erase {I F M N : Finset E} {e : E}
    (h : ForwardChange I F M N e) : e ∈ diffEdges M F ∧
      diffEdges N F = (diffEdges M F).erase e := by
  rcases h with ⟨heIF,heM,rfl⟩ | ⟨heFI,heM,rfl⟩
  · have hNF := (Finset.mem_sdiff.mp heIF).2
    refine ⟨mem_diffEdges.mpr (Or.inl ⟨heM,hNF⟩),?_⟩
    ext d
    by_cases hd : d = e
    · subst d
      simp [hNF]
    · simp [hd]
  · have hF := (Finset.mem_sdiff.mp heFI).1
    refine ⟨mem_diffEdges.mpr (Or.inr ⟨hF,heM⟩),?_⟩
    ext d
    by_cases hd : d = e
    · subst d
      simp [hF]
    · simp [hd]

/-- The route as a set of directed transitions, with exact length and
the identities needed to bound its contribution to the Dirichlet form. -/
structure MatchingRouteWitness (ends : E → Finset V) (edges I F N : Finset E) where
  moves : Finset (Finset E × Finset E)
  valid : ∀ z ∈ moves, OrderedMatchingMove ends edges I F z.1 z.2
  measure_le : ∀ z ∈ moves, (diffEdges N F).card ≤ (diffEdges z.2 F).card
  length : moves.card + (diffEdges N F).card = (diffEdges I F).card
  telescopes : ∀ f : Finset E → ℝ, (∑ z ∈ moves, (f z.1 - f z.2)) = f I - f N

private theorem routeWitness_exists (ends : E → Finset V) (edges I F N : Finset E)
    (h : Relation.ReflTransGen (OrderedMatchingMove ends edges I F) I N) :
    Nonempty (MatchingRouteWitness ends edges I F N) := by
  induction h with
  | refl => exact ⟨⟨∅,by simp,by simp,by simp,by simp⟩⟩
  | @tail M N hPrev hStep ih =>
    obtain ⟨route⟩ := ih
    obtain ⟨e,he,-⟩ := hStep.route_step
    obtain ⟨heIn,hErase⟩ := he.diff_erase
    have hCard : (diffEdges N F).card+1 = (diffEdges M F).card := by
      rw [hErase]
      exact Finset.card_erase_add_one heIn
    have hNew : (M,N) ∉ route.moves := by
      intro hIn
      have hMeasure := route.measure_le (M,N) hIn
      simp only at hMeasure
      omega
    refine ⟨⟨insert (M,N) route.moves,?_,?_,?_,?_⟩⟩
    · intro z hz
      rcases Finset.mem_insert.mp hz with rfl | hz
      · exact hStep
      · exact route.valid z hz
    · intro z hz
      rcases Finset.mem_insert.mp hz with rfl | hz
      · exact le_rfl
      · have hMeasure := route.measure_le z hz
        omega
    · have hLength := route.length
      rw [Finset.card_insert_of_notMem hNew]
      omega
    · intro f
      rw [Finset.sum_insert hNew, route.telescopes f]
      simp only
      ring

theorem matchingRouteWitness (ends : E → Finset V) (edges I F : Finset E)
    (hi : I ∈ matchings ends edges) (hf : F ∈ matchings ends edges)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) :
    Nonempty (MatchingRouteWitness ends edges I F F) :=
  routeWitness_exists ends edges I F F (ordered_route_exists ends edges I F hi hf hEnds)

/-- A fixed choice of directed route for each pair of valid matchings. -/
noncomputable def matchingRoute (ends : E → Finset V) (edges : Finset E)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) (I F : Finset E) : Finset (Finset E × Finset E) := by
  classical
  exact if h : I ∈ matchings ends edges ∧ F ∈ matchings ends edges then
    (matchingRouteWitness ends edges I F h.1 h.2 hEnds).some.moves else ∅

private theorem matchingRoute_eq (ends : E → Finset V) (edges : Finset E)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) (I F : Finset E)
    (hi : I ∈ matchings ends edges) (hf : F ∈ matchings ends edges) :
    matchingRoute ends edges hEnds I F =
      (matchingRouteWitness ends edges I F hi hf hEnds).some.moves := by
  classical
  exact dif_pos ⟨hi,hf⟩

theorem matchingRoute_valid (ends : E → Finset V) (edges : Finset E)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) (I F : Finset E)
    (hi : I ∈ matchings ends edges) (hf : F ∈ matchings ends edges)
    (z : Finset E × Finset E) (hz : z ∈ matchingRoute ends edges hEnds I F) :
    OrderedMatchingMove ends edges I F z.1 z.2 := by
  rw [matchingRoute_eq ends edges hEnds I F hi hf] at hz
  exact (matchingRouteWitness ends edges I F hi hf hEnds).some.valid z hz

theorem matchingRoute_card_le (ends : E → Finset V) (edges : Finset E)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) (I F : Finset E)
    (hi : I ∈ matchings ends edges) (hf : F ∈ matchings ends edges) :
    (matchingRoute ends edges hEnds I F).card ≤ edges.card := by
  rw [matchingRoute_eq ends edges hEnds I F hi hf]
  have hLength := (matchingRouteWitness ends edges I F hi hf hEnds).some.length
  have hEmpty : diffEdges F F = ∅ := by ext e; simp
  simp only [hEmpty,Finset.card_empty,add_zero] at hLength
  rw [hLength]
  apply Finset.card_le_card
  intro e he
  rcases mem_diffEdges.mp he with he | he
  · exact ((mem_matchings ..).mp hi).1 he.1
  · exact ((mem_matchings ..).mp hf).1 he.1

theorem matchingRoute_telescopes (ends : E → Finset V) (edges : Finset E)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) (I F : Finset E)
    (hi : I ∈ matchings ends edges) (hf : F ∈ matchings ends edges) (f : Finset E → ℝ) :
    (∑ z ∈ matchingRoute ends edges hEnds I F, (f z.1-f z.2)) = f I-f F := by
  rw [matchingRoute_eq ends edges hEnds I F hi hf]
  exact (matchingRouteWitness ends edges I F hi hf hEnds).some.telescopes f

end SubmodularMatching.GibbsSampler
