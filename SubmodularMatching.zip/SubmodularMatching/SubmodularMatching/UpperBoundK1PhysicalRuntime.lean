import SubmodularMatching.UpperBoundK1ActualRuntime
import SubmodularMatching.UpperBoundK1ArchiveProgram
import SubmodularMatching.StreamingK1FreshResources

/-! # Query and visit counts using the real archive and sampler inputs -/

namespace SubmodularMatching.UpperBoundAssembly.K1ProgramInput

open Streaming Joint ShearerSampler GibbsSampler TwoStage

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]
variable {a : K1Parameters} (I : K1ProgramInput a E V)

def archivedNonemptyKeys (st : RealSource.OnlineStreamState E V) : Finset ℕ :=
  (st.instances.map Prod.fst).toFinset.filter (fun j => 0 < (archivedRows st j).length)

abbrev ArchivedActive (st : RealSource.OnlineStreamState E V) := {j // j ∈ archivedNonemptyKeys st}

def archivedSize {st : RealSource.OnlineStreamState E V} (j : ArchivedActive st) : ℕ :=
  (archivedRows st j).length

def archivedEnds {st : RealSource.OnlineStreamState E V} (j : ArchivedActive st) :
    Fin (archivedSize j) → V × V :=
  fun e => I.P.ends ((archivedRows st j).get e).1

theorem archivedSize_pos {st : RealSource.OnlineStreamState E V} (j : ArchivedActive st) :
    0 < archivedSize j := (Finset.mem_filter.mp j.property).2

/-- The array sizes in the actual sparse archive agree with the bounds
for the proved stream schedule on every replayed state. -/
theorem archivedSchedule_sizes (ω : ℝ) (batches : ℕ → Fin (I.Ns ω) → ℝ) :
    let st := I.replayState ω batches
    Fintype.card (ArchivedActive st) ≤ I.L ∧
      ∀ j : ArchivedActive st, 0 < archivedSize j ∧ archivedSize j ≤ I.P.vertices ^ 2 := by
  intro st
  have hkeys : st.instances.map Prod.fst = (finalGuessIndices I.P).sort (· ≤ ·) :=
    I.replayGuessOrder_eq ω batches
  have hsize : (archivedNonemptyKeys st).card ≤ I.L := by
    unfold archivedNonemptyKeys
    apply (Finset.card_filter_le _ _).trans
    rw [hkeys, Finset.sort_toFinset]
    exact activeGuessIndices_card_le I.P.width I.P.value I.P.span I.P.arrivals
      I.P.width_bound I.positiveBest
  refine ⟨by simpa only [Fintype.card_coe] using hsize, ?_⟩
  intro j
  have hj : (j : ℕ) ∈ st.instances.map Prod.fst :=
    List.mem_toFinset.mp (Finset.mem_filter.mp j.property).1
  have hactive : finalGuessActive I.P j.val :=
    (mem_activeGuessIndices _ _ _ _ _ (guessAnchor_pos _ _ _ I.positiveBest)
      (guessAnchor_le _ _ _) I.P.width_bound).1 ((Finset.mem_sort _).1 (hkeys ▸ hj))
  obtain ⟨hlen, _, _⟩ := I.replayGuess_handoff ω batches j.val hactive
  refine ⟨archivedSize_pos j, ?_⟩
  change (archivedRows st j).length ≤ _
  rw [show (archivedRows st j).length = finalGuessCount I.P batches j.val from hlen]
  exact (finalGuessCount_le_arrivals I.P batches I.noRepeat _).trans I.P.arrivals_bound

def archivedRoundingInput (t : I.ArchivedPreparation) (j : ArchivedActive t.state) :
    RationalShearerInput (Fin (archivedSize j)) :=
  let ends := I.archivedEnds j
  let vertices := Fintype.card (IncidentVertex ends)
  let d := a.eulerDenominator (archivedSize j) vertices
  let hd := a.eulerDenominator_pos (archivedSize_pos j) vertices
  k1RoundingShearerInput a.roundingSettings (k1PhysicalOfNormalizedPoint a.optimizerSettings
    (t.points j.val)).2 d hd

/-- The active list passed to the Gibbs walk after the actual first
sampler outcome and the integer alteration of the retained arrays. -/
def archivedGibbsSize (t : I.ArchivedPreparation) (j : ArchivedActive t.state)
    (T : Finset (Fin (archivedSize j))) : ℕ := by
  let R := a.roundingSettings
  let ep := numberedEnds (restrictEnds (I.archivedEnds j))
  let stored := List.finRange (archivedSize j)
  let c := I.archivedRoundingInput t j
  let x := (k1PhysicalOfNormalizedPoint a.optimizerSettings (t.points j.val)).1
  let xWord := fun e => k1RoundingGridIndex c.Q (x e)
  let mesh := R.compensation (archivedSize j)
  let compensated := separateWordTable stored
    (separateCompensatedWord ep stored.toFinset stored.toFinset xWord c.numerator c.Q c.Q mesh)
  let altered := separateWordTable stored
    (separateAlteredWord ep stored.toFinset (readSeparateWordTable stored compensated)
      mesh R.alterationTop R.alterationBottom T)
  let activity := activityWordsFromStoredGrid ep R.gibbsNumerator R.gibbsDenominator
    (mesh * R.alterationTop) (readSeparateWordTable stored altered) stored
  exact (positiveActivityList activity stored).length

theorem archivedGibbsSize_le (t : I.ArchivedPreparation) (j : ArchivedActive t.state)
    (T : Finset (Fin (archivedSize j))) : I.archivedGibbsSize t j T ≤ archivedSize j := by
  unfold archivedGibbsSize positiveActivityList
  exact (List.length_filter_le _ _).trans (by simp only [List.length_finRange, le_refl])

/-- Every physical archive passed to the optimizer is represented by a
supported reference execution, including outcomes with inaccurate estimates. -/
theorem archivedPreparation_replays (ω : ℝ) (t : I.ArchivedPreparation)
    (ht : t ∈ (I.archivedPreparation ω).outcomes) :
    ∃ b ∈ (I.source ω).outcomes, t.state = I.replayState ω b := by
  classical
  unfold archivedPreparation at ht
  obtain ⟨st, _, hpoint⟩ := (CandidateLaw.mem_bind _ _ _).mp ht
  unfold prepareArchivedState CandidateLaw.map at hpoint
  obtain ⟨_, _, rfl⟩ := Finset.mem_image.mp hpoint
  have hst := RealSource.samplewisePrefixLaw_support I.P I.onlineGrid (I.Ns ω) a.p
    I.P.arrivals st.property
  obtain ⟨b, hb, hs⟩ := RealSource.freshPrefixLaw_attained I.P I.onlineGrid
    I.width_one_le I.onlineGrid_matches (I.Ns ω) a.p I.P.arrivals le_rfl st.val hst
  exact ⟨b, hb, hs.symm⟩

/-- Runtime bounds on the actual stored edge lists, with the actual
rounded second-stage support for each trial. -/
theorem archivedRuntime_polynomial (C : K1Confidence a) (c : ℕ)
    (hspan : I.P.span = Nat.clog 2 ((I.P.vertices * a.k + 1) / 2))
    (t : I.ArchivedPreparation)
    (ht : t ∈ (I.archivedPreparation (min a.error ((((I.P.vertices : ℝ) ^ c)⁻¹) / 2))).outcomes)
    (firstSample : (j : ArchivedActive t.state) →
      Fin (C.trials (((I.P.vertices : ℝ) ^ c)⁻¹)) → Finset (Fin (archivedSize j))) :
    let n := I.P.vertices
    let w := (n + 1).log2 + 1
    let δ := ((n : ℝ) ^ c)⁻¹
    let ω := min a.error (δ / 2)
    let T := C.trials δ
    let stored : ArchivedActive t.state → ℕ := archivedSize
    let ends : (j : ArchivedActive t.state) → Fin (stored j) → V × V := I.archivedEnds
    let Q := k1ExactQueryCount a.degree a.k I.P.arrivals I.L (I.Ns ω) (I.Ng ω) T stored
    let A := k1DirectionVisitCount a.degree a.k stored ends +
      4 * (n + 1) ^ 2 * Q + k1RoundingVisitCount a.k T stored ends
        (I.archivedRoundingInput t) (fun j r => I.archivedGibbsSize t j (firstSample j r))
    Q ≤ k1QueryConstant a.k c C.trialMultiplier * (n + 1) ^ 10 * w ^ 2 ∧
      A ≤ k1VisitConstant a.k c C.trialMultiplier a.roundingSettings.rDen * (n + 1) ^ 22 * w := by
  let ω := min a.error ((((I.P.vertices : ℝ) ^ c)⁻¹) / 2)
  obtain ⟨batches, _, hs⟩ := I.archivedPreparation_replays ω t ht
  have hcard : Fintype.card (ArchivedActive t.state) ≤ I.L :=
    hs.symm ▸ (I.archivedSchedule_sizes ω batches).1
  have hstored : ∀ j : ArchivedActive t.state, 0 < archivedSize j ∧ archivedSize j ≤ I.P.vertices ^ 2 :=
    hs.symm ▸ (I.archivedSchedule_sizes ω batches).2
  exact I.resources_of_schedule C c hspan archivedSize I.archivedEnds hcard hstored
    a.roundingSettings.rDen (I.archivedRoundingInput t) (fun _ => rfl)
    (fun j r => I.archivedGibbsSize t j (firstSample j r))
    (fun j r => I.archivedGibbsSize_le t j (firstSample j r))

end

end SubmodularMatching.UpperBoundAssembly.K1ProgramInput
