import SubmodularMatching.UpperBoundK1ArchiveData
import SubmodularMatching.UpperBoundK1LiveProgram
import SubmodularMatching.UpperBoundK1IntegerArchive
import SubmodularMatching.UpperBoundOnlineCandidates

/-! # Post-stream optimization and rounding from the archived rows -/

namespace SubmodularMatching.UpperBoundAssembly.K1ProgramInput

open GibbsSampler Streaming

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]
variable {a : K1Parameters} (I : K1ProgramInput a E V)

def archivedRows (st : RealSource.OnlineStreamState E V) (j : ℕ) : List (E × ℕ) :=
  ((st.instanceAt j).getD OnlineInstance.empty).edges

abbrev ArchivedPoints (st : RealSource.OnlineStreamState E V) :=
  ∀ j, CurrentOptimizerPoint (archivedRows st j).length

private def optimizerFromArchive {m : ℕ} (p : K1OptimizerSettings) (ends : E → V × V)
    (objective : Finset E → ℝ) (edge : Fin m → E) (weight : Fin m → ℝ)
    (tau : ℝ) (Ng : ℕ) : CandidateLaw (CurrentOptimizerPoint m) :=
  if hm : 0 < m then
    k1LiveOptimizerLaw p Ng hm (restrictEnds (ends ∘ edge)) tau weight
      (fun S => objective (S.image edge)) (k1GradientDiscountGrid p.degree p.error m)
      (k1GradientCoordinateBits p.degree p.error m)
  else CandidateLaw.pure (fun _ => 0)

def archivedOptimizerChoice (Ng : ℕ) (st : RealSource.OnlineStreamState E V) (j : ℕ) :
    CandidateLaw (CurrentOptimizerPoint (archivedRows st j).length) := by
  classical
  let rows := archivedRows st j
  let gap := I.P.epsilon * st.epoch.scale j / (I.P.vertices : ℝ) ^ 2
  exact if j ∈ st.instances.map Prod.fst then
    optimizerFromArchive a.optimizerSettings I.P.ends I.P.objective
      (fun i => (rows.get i).1) (fun i => gap * (rows.get i).2) (st.epoch.scale j) Ng
  else CandidateLaw.pure (fun _ => 0)

def archivedOptimizerLaw (Ng : ℕ) (st : RealSource.OnlineStreamState E V) :
    CandidateLaw (ArchivedPoints st) :=
  CandidateLaw.assign (I.archivedOptimizerChoice Ng st) (st.instances.map Prod.fst) (fun _ _ => 0)

def compiledOptimizerChoice (Ng : ℕ) (st : RealSource.OnlineStreamState E V) (j : ℕ) :
    CandidateLaw (CurrentOptimizerPoint (archivedRows st j).length) := by
  classical
  exact if j ∈ st.instances.map Prod.fst then
    optimizerFromArchiveCompiled a I.P.ends I.P.objective (archivedRows st j) I.P.vertices
      (st.epoch.scale j) Ng
  else CandidateLaw.pure (fun _ => 0)

def compiledOptimizerLaw (Ng : ℕ) (st : RealSource.OnlineStreamState E V) :
    CandidateLaw (ArchivedPoints st) :=
  CandidateLaw.assign (I.compiledOptimizerChoice Ng st) (st.instances.map Prod.fst) (fun _ _ => 0)

/-- On every actual source run, compiling the archived optimizer into
integer coefficient, packing, and point operations preserves its law. -/
theorem compiledOptimizerLaw_value (ω : ℝ) (hω : 0 < ω)
    (batches : ℕ → Fin (I.Ns ω) → ℝ) (hb : batches ∈ (I.source ω).outcomes)
    (test : ArchivedPoints (I.replayState ω batches) → ℝ) :
    let st := I.replayState ω batches
    let p := I.compiledOptimizerLaw (I.Ng ω) st
    let q := I.archivedOptimizerLaw (I.Ng ω) st
    expected p.outcomes p.mass test = expected q.outcomes q.mass test := by
  classical
  intro st p q
  unfold p q compiledOptimizerLaw archivedOptimizerLaw
  apply CandidateLaw.assign_congr_expected
  intro j obs
  by_cases hj : j ∈ st.instances.map Prod.fst
  · have hkeys : st.instances.map Prod.fst = (finalGuessIndices I.P).sort (· ≤ ·) :=
      I.replayGuessOrder_eq ω batches
    have hi : j ∈ finalGuessIndices I.P := (Finset.mem_sort _).1 (hkeys ▸ hj)
    have ha : finalGuessActive I.P j := (mem_activeGuessIndices I.P.width _ _ _ j
      (guessAnchor_pos _ _ _ I.positiveBest) (guessAnchor_le _ _ _) I.P.width_bound).1 hi
    obtain ⟨hlen, htau, hrow⟩ := I.replayGuess_handoff ω batches j ha
    let τ := st.epoch.scale j
    let rows := archivedRows st j
    have ht : 0 < τ := by
      change 0 < (I.replayState ω batches).epoch.scale j
      rw [htau]
      exact (finalGuessConfig I.P j).theta_pos.trans_le (finalGuessConfig I.P j).theta_le_tau
    have hN : 0 < I.Ng ω := Nat.succ_pos _
    have hweight (i : Fin rows.length) : k1ArchivedWeight a I.P.vertices τ (rows.get i).2 ≤ τ := by
      unfold k1ArchivedWeight
      rw [← I.epsilon]
      let emb := finalGuessEmbedding I.P batches I.noRepeat j
      have hw : I.P.epsilon * τ / (I.P.vertices : ℝ) ^ 2 * (rows.get i).2 =
          finalGuessFrozen I.P batches j (emb (i.cast hlen)) := (hrow i).2
      have ht' : τ = (finalGuessConfig I.P j).tau := htau
      change I.P.epsilon * τ / (I.P.vertices : ℝ) ^ 2 * (rows.get i).2 ≤ τ
      rw [hw, ht']
      exact (I.replayGuess_frozen_bounds ω hω batches hb j ha
        (finalGuessEmbedding I.P batches I.noRepeat j (i.cast hlen))).2
    have h := optimizerFromArchiveCompiled_value a I.P.ends I.P.objective rows I.P.vertices
      I.P.vertices_pos τ ht (I.Ng ω) hN hweight obs
    simp only [compiledOptimizerChoice, archivedOptimizerChoice, if_pos hj, optimizerFromArchive, I.epsilon]
    exact h
  · simp only [compiledOptimizerChoice, archivedOptimizerChoice, if_neg hj]

def candidatesFromArchive (st : RealSource.OnlineStreamState E V) (points : ArchivedPoints st) :
    List (CandidateLaw (Finset E)) := by
  classical
  exact (st.instances.map Prod.fst).filterMap fun j =>
    let rows := archivedRows st j
    if hm : 0 < rows.length then
      if hn : (rows.map Prod.fst).Nodup then
        some (k1CompactGuessFromPoint a hm (archiveEmbedding rows hn)
          I.P.ends I.loopless I.simple (points j))
      else none
    else none

def pointOnArchive {N : ℕ} (st : RealSource.OnlineStreamState E V)
    (batches : ℕ → Fin N → ℝ) (j : ℕ) (point : CurrentOptimizerPoint (finalGuessCount I.P batches j)) :
    CurrentOptimizerPoint (archivedRows st j).length := by
  classical
  exact if h : (archivedRows st j).length = finalGuessCount I.P batches j then
    h.symm ▸ point else fun _ => 0

private theorem cast_zero {m n : ℕ} (h : m = n) :
    (h ▸ (fun _ => 0 : CurrentOptimizerPoint m) : CurrentOptimizerPoint n) = (fun _ => 0) := by
  subst n
  rfl

private theorem cast_expected {m n : ℕ} (h : m = n)
    (law : CandidateLaw (CurrentOptimizerPoint m)) (test : CurrentOptimizerPoint m → ℝ) :
    let transported : CandidateLaw (CurrentOptimizerPoint n) := h ▸ law
    expected transported.outcomes transported.mass (test ∘ (fun x => h.symm ▸ x)) =
      expected law.outcomes law.mass test := by
  subst n
  rfl

omit [Fintype V] in
private theorem optimizerFromArchive_transport (p : K1OptimizerSettings) (ends : E → V × V)
    (objective : Finset E → ℝ) (edge : ℕ → E) (weight : ℕ → ℝ) (tau : ℝ) (Ng m n : ℕ)
    (h : m = n) :
    (h ▸ optimizerFromArchive p ends objective (fun i : Fin m => edge i) (fun i => weight i) tau Ng :
      CandidateLaw (CurrentOptimizerPoint n)) =
    optimizerFromArchive p ends objective (fun i : Fin n => edge i) (fun i => weight i) tau Ng := by
  subst n
  rfl

private theorem candidateFromArchive_transport {m n : ℕ} (h : m = n) (hm : 0 < m) (hn : 0 < n)
    (e : Fin m ↪ E) (e' : Fin n ↪ E) (he : ∀ i : Fin m, e i = e' (i.cast h))
    (point : CurrentOptimizerPoint n) :
    k1CompactGuessFromPoint a hm e I.P.ends I.loopless I.simple (h.symm ▸ point) =
      k1CompactGuessFromPoint a hn e' I.P.ends I.loopless I.simple point := by
  subst n
  have heq : e = e' := Function.Embedding.ext he
  rw [heq]

private theorem archivedOptimizerChoice_eq (ω : ℝ) (batches : ℕ → Fin (I.Ns ω) → ℝ) (j : ℕ)
    (hj : j ∈ finalGuessIndices I.P)
    (hlen : (archivedRows (I.replayState ω batches) j).length = finalGuessCount I.P batches j) :
    (hlen ▸ I.archivedOptimizerChoice (I.Ng ω) (I.replayState ω batches) j :
      CandidateLaw (CurrentOptimizerPoint (finalGuessCount I.P batches j))) =
      k1FinalLiveOptimizerChoice a.optimizerSettings I.P batches I.noRepeat (I.Ng ω) j := by
  let st := I.replayState ω batches
  let rows := archivedRows st j
  let m := finalGuessCount I.P batches j
  let emb := finalGuessEmbedding I.P batches I.noRepeat j
  let gap := I.P.epsilon * st.epoch.scale j / (I.P.vertices : ℝ) ^ 2
  let d := (I.P.edges I.bestIndex, 0)
  let edge : ℕ → E := fun i => (rows.getD i d).1
  let weight : ℕ → ℝ := fun i => gap * (rows.getD i d).2
  have ha : finalGuessActive I.P j := (mem_activeGuessIndices I.P.width _ _ _ j
    (guessAnchor_pos _ _ _ I.positiveBest) (guessAnchor_le _ _ _) I.P.width_bound).1 hj
  obtain ⟨heq, hτ, hrows⟩ := I.replayGuess_handoff ω batches j ha
  have hmem : j ∈ st.instances.map Prod.fst := by rw [I.replayGuessOrder_eq]; exact (Finset.mem_sort _).2 hj
  have hget (i : Fin rows.length) : rows.get i = rows.getD i d := (List.getD_eq_get _ _ _).symm
  have he (i : Fin rows.length) : (rows.get i).1 = edge i := congrArg Prod.fst (hget i)
  have hw (i : Fin rows.length) : gap * (rows.get i).2 = weight i :=
    congrArg (fun q : E × ℕ => gap * q.2) (hget i)
  have he' : (fun i : Fin m => edge i) = ⇑emb := by
    funext i
    exact (he (i.cast hlen.symm)).symm.trans (hrows (i.cast hlen.symm)).1
  have hw' : (fun i : Fin m => weight i) = finalGuessFrozen I.P batches j ∘ emb := by
    funext i
    exact (hw (i.cast hlen.symm)).symm.trans (hrows (i.cast hlen.symm)).2
  have hF : (fun S : Finset (Fin m) => I.P.objective (S.image (⇑emb))) =
      reindexedObjective emb I.P.objective := by
    funext S
    unfold reindexedObjective
    rw [Finset.map_eq_image]
  have hdef : I.archivedOptimizerChoice (I.Ng ω) st j =
      optimizerFromArchive a.optimizerSettings I.P.ends I.P.objective
        (fun i : Fin rows.length => edge i) (fun i => weight i) (st.epoch.scale j) (I.Ng ω) := by
    simp only [archivedOptimizerChoice, if_pos hmem]
    rw [funext he, funext hw]
  rw [hdef, optimizerFromArchive_transport _ _ _ edge weight _ _ _ _ hlen]
  unfold optimizerFromArchive k1FinalLiveOptimizerChoice
  dsimp only [st, emb, m] at he' hw' hτ hF ⊢
  rw [if_pos hj]
  by_cases hm : 0 < finalGuessCount I.P batches j
  · rw [dif_pos hm, dif_pos hm, he', hw', hτ, hF]
  · rw [dif_neg hm, dif_neg hm]

omit [DecidableEq E] in
private theorem archiveRows_get_map (rows : List (E × ℕ))
    (i : Fin (rows.map Prod.fst).length) :
    (rows.map Prod.fst).get i =
      (rows.get (i.cast (show (rows.map Prod.fst).length = rows.length from List.length_map Prod.fst))).1 := by
  simp only [List.get_eq_getElem, List.getElem_map, Fin.val_cast]

theorem candidatesFromArchive_eq (ω : ℝ) (batches : ℕ → Fin (I.Ns ω) → ℝ)
    (points : FinalPointFamily I.P batches) :
    let st := I.replayState ω batches
    I.candidatesFromArchive st (fun j => I.pointOnArchive st batches j (points j)) =
      I.liveCandidates ω ⟨batches, points⟩ := by
  intro st
  have hk : st.instances.map Prod.fst = (finalGuessIndices I.P).sort (· ≤ ·) :=
    I.replayGuessOrder_eq ω batches
  unfold candidatesFromArchive liveCandidates
  simp only [hk]
  apply List.filterMap_congr
  intro j hj
  have hj' : j ∈ finalGuessIndices I.P := (Finset.mem_sort _).1 hj
  have ha : finalGuessActive I.P j := (mem_activeGuessIndices I.P.width _ _ _ j
    (guessAnchor_pos _ _ _ I.positiveBest) (guessAnchor_le _ _ _) I.P.width_bound).1 hj'
  let rows := archivedRows st j
  let m := finalGuessCount I.P batches j
  let emb := finalGuessEmbedding I.P batches I.noRepeat j
  obtain ⟨hlen, _, hrow⟩ := I.replayGuess_handoff ω batches j ha
  have hl : rows.length = m := hlen
  have he (i : Fin rows.length) : (rows.get i).1 = emb (i.cast hl) := (hrow i).1
  have hnd : (rows.map Prod.fst).Nodup := by
    apply List.nodup_iff_injective_get.mpr
    intro i k h
    simp only [archiveRows_get_map, he] at h
    exact Fin.ext (congrArg (fun k : Fin m => k.val) (emb.injective h))
  by_cases hm : 0 < m
  · have hr : 0 < rows.length := by rw [hl]; exact hm
    rw [dif_pos hr, dif_pos hm, dif_pos hnd]
    unfold pointOnArchive
    rw [dif_pos hl, Option.some.injEq]
    exact I.candidateFromArchive_transport hl hr hm _ emb he _
  · have hr : ¬0 < rows.length := by rw [hl]; exact hm
    rw [dif_neg hr, dif_neg hm]

theorem archiveOptimizerLaw_value (ω : ℝ) (batches : ℕ → Fin (I.Ns ω) → ℝ)
    (test : List (CandidateLaw (Finset E)) → ℝ) :
    let st := I.replayState ω batches
    let p := I.archivedOptimizerLaw (I.Ng ω) st
    let q := k1FinalLiveOptimizerLaw a.optimizerSettings I.P batches I.noRepeat (I.Ng ω)
    expected p.outcomes p.mass (test ∘ I.candidatesFromArchive st) =
      expected q.outcomes q.mass (fun points => test (I.liveCandidates ω ⟨batches, points⟩)) := by
  dsimp only
  let st := I.replayState ω batches
  let keys := st.instances.map Prod.fst
  let ref := k1FinalLiveOptimizerChoice a.optimizerSettings I.P batches I.noRepeat (I.Ng ω)
  let actual := I.archivedOptimizerChoice (I.Ng ω) st
  let project := I.pointOnArchive st batches
  let obs := test ∘ I.candidatesFromArchive st
  have hkeys : keys = (finalGuessIndices I.P).sort (· ≤ ·) := I.replayGuessOrder_eq ω batches
  have hp (j : ℕ) (test' : CurrentOptimizerPoint (archivedRows st j).length → ℝ) :
      expected (ref j).outcomes (ref j).mass (test' ∘ project j) =
        expected (actual j).outcomes (actual j).mass test' := by
    by_cases hj : j ∈ finalGuessIndices I.P
    · have ha : finalGuessActive I.P j := (mem_activeGuessIndices I.P.width _ _ _ j
        (guessAnchor_pos _ _ _ I.positiveBest) (guessAnchor_le _ _ _) I.P.width_bound).1 hj
      obtain ⟨hlen, _, _⟩ := I.replayGuess_handoff ω batches j ha
      have hl : (archivedRows st j).length = finalGuessCount I.P batches j := hlen
      have hcast : (hl ▸ actual j : CandidateLaw (CurrentOptimizerPoint (finalGuessCount I.P batches j))) =
          ref j := I.archivedOptimizerChoice_eq ω batches j hj hl
      have hproj : project j = (fun x => hl.symm ▸ x) := by
        funext x
        change I.pointOnArchive st batches j x = _
        rw [pointOnArchive, dif_pos hl]
      rw [← hcast, hproj]
      exact cast_expected hl (actual j) test'
    · have hnot : j ∉ st.instances.map Prod.fst := by
        change j ∉ keys
        rwa [hkeys, Finset.mem_sort]
      have hactual : actual j = CandidateLaw.pure (fun _ => 0) := by
        simp only [actual, archivedOptimizerChoice, if_neg hnot]
      have href : ref j = CandidateLaw.pure (fun _ => 0) := by
        simp only [ref, k1FinalLiveOptimizerChoice, if_neg hj]
      rw [hactual, href, CandidateLaw.pure_expected, CandidateLaw.pure_expected]
      apply congrArg test'
      unfold project pointOnArchive
      split
      · exact cast_zero _
      · rfl
  have hinit : (fun j => project j (fun _ => 0)) = (fun _ _ => 0) := by
    funext j
    unfold project pointOnArchive
    split
    · exact cast_zero _
    · rfl
  have hh := CandidateLaw.assign_project_expected ref actual project hp keys (fun _ _ => 0) obs
  rw [hinit] at hh
  refine hh.symm.trans ?_
  have hRef : CandidateLaw.assign ref keys (fun _ _ => 0) =
      k1FinalLiveOptimizerLaw a.optimizerSettings I.P batches I.noRepeat (I.Ng ω) := by
    unfold k1FinalLiveOptimizerLaw
    rw [hkeys]
  rw [hRef]
  apply congrArg (expected _ _)
  funext points
  change obs (fun j => project j (points j)) = test (I.liveCandidates ω ⟨batches, points⟩)
  exact congrArg test (I.candidatesFromArchive_eq ω batches points)

end

end SubmodularMatching.UpperBoundAssembly.K1ProgramInput
