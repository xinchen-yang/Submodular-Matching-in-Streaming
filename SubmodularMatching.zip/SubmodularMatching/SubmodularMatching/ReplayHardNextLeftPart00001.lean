import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextLeft

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step10 : ProjectedGoal ⟨270, 283, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.leaf 0x10e010ee8d4a51000048048) (.leaf 0x10f010fe8d4a51000048048)) (.m (.leaf 0x1100110e8d4a51000048048) (.leaf 0x1110111e8d4a51000048048))) (.x (.x (.leaf 0x1140112e8d4a51000048049) (.x (.leaf 0x1140112e8d4a5100004804a) (.x (.leaf 0x1140112e8d4a5100004804b) (.x (.y (.y (.leaf 0x1140112e8d4a5100004904c) (.y (.leaf 0x1140112e8d4a5100004a04c) (.y (.leaf 0x1140112e8d4a5100004b04c) (.y (.m (.m (.leaf 0x1120112e8d4a5100004c04c) (.leaf 0x1130113e8d4a5100004c04c)) (.leaf 0x1140114e8d4a5100004c04c)) (.leaf 0x1140112e8d4a5100004d04c))))) (.leaf 0x1140112e8d4a5100004e04c)) (.leaf 0x1140112e8d4a5100004804d))))) (.leaf 0x1140112e8d4a5100004804e))) (.m (.m (.leaf 0x1160115e8d4a51000048048) (.leaf 0x1180117e8d4a51000048048)) (.m (.leaf 0x11a0119e8d4a51000048048) (.leaf 0x11b011be8d4a51000048048)))) (by decide +kernel)

private theorem step11 : ProjectedGoal ⟨284, 290, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0x11c011ce8d4a51000048048) (.leaf 0x11d011de8d4a51000048048)) (.m (.leaf 0x11e011ee8d4a51000048048) (.leaf 0x11f011fe8d4a51000048048))) (.x (.x (.leaf 0x1220120e8d4a51000048049) (.x (.leaf 0x1220120e8d4a5100004804a) (.x (.leaf 0x1220120e8d4a5100004804b) (.x (.y (.y (.leaf 0x1220120e8d4a5100004904c) (.y (.leaf 0x1220120e8d4a5100004a04c) (.y (.leaf 0x1220120e8d4a5100004b04c) (.y (.m (.m (.leaf 0x1200120e8d4a5100004c04c) (.leaf 0x1210121e8d4a5100004c04c)) (.leaf 0x1220122e8d4a5100004c04c)) (.leaf 0x1220120e8d4a5100004d04c))))) (.leaf 0x1220120e8d4a5100004e04c)) (.leaf 0x1220120e8d4a5100004804d))))) (.leaf 0x1220120e8d4a5100004804e))) (by decide +kernel)

private theorem step12 : ProjectedGoal ⟨291, 296, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.leaf 0x1240123e8d4a51000048048) (.leaf 0x1250125e8d4a51000048048)) (.x (.x (.leaf 0x1280126e8d4a51000048049) (.x (.leaf 0x1280126e8d4a5100004804a) (.x (.leaf 0x1280126e8d4a5100004804b) (.x (.y (.y (.leaf 0x1280126e8d4a5100004904c) (.y (.leaf 0x1280126e8d4a5100004a04c) (.y (.leaf 0x1280126e8d4a5100004b04c) (.y (.m (.m (.leaf 0x1260126e8d4a5100004c04c) (.leaf 0x1270127e8d4a5100004c04c)) (.leaf 0x1280128e8d4a5100004c04c)) (.leaf 0x1280126e8d4a5100004d04c))))) (.leaf 0x1280126e8d4a5100004e04c)) (.leaf 0x1280126e8d4a5100004804d))))) (.leaf 0x1280126e8d4a5100004804e))) (by decide +kernel)

private theorem step13 : ProjectedGoal ⟨284, 296, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 290 (by decide) (by decide) (step11 rates cones) (step12 rates cones)

private theorem step14 : ProjectedGoal ⟨270, 296, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 283 (by decide) (by decide) (step10 rates cones) (step13 rates cones)

private theorem step15 : ProjectedGoal ⟨297, 310, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0x12a0129e8d4a51000048048) (.leaf 0x12c012be8d4a51000048048)) (.m (.leaf 0x12e012de8d4a51000048048) (.leaf 0x12f012fe8d4a51000048048))) (.m (.m (.m (.leaf 0x1300130e8d4a51000048048) (.leaf 0x1310131e8d4a51000048048)) (.m (.leaf 0x1320132e8d4a51000048048) (.leaf 0x1330133e8d4a51000048048))) (.x (.x (.leaf 0x1360134e8d4a51000048049) (.x (.leaf 0x1360134e8d4a5100004804a) (.x (.leaf 0x1360134e8d4a5100004804b) (.x (.y (.y (.leaf 0x1360134e8d4a5100004904c) (.y (.leaf 0x1360134e8d4a5100004a04c) (.y (.leaf 0x1360134e8d4a5100004b04c) (.y (.m (.m (.leaf 0x1340134e8d4a5100004c04c) (.leaf 0x1350135e8d4a5100004c04c)) (.leaf 0x1360136e8d4a5100004c04c)) (.leaf 0x1360134e8d4a5100004d04c))))) (.leaf 0x1360134e8d4a5100004e04c)) (.leaf 0x1360134e8d4a5100004804d))))) (.leaf 0x1360134e8d4a5100004804e)))) (by decide +kernel)

private theorem step16 : ProjectedGoal ⟨311, 323, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0x1380137e8d4a51000048048) (.leaf 0x13a0139e8d4a51000048048)) (.m (.leaf 0x13c013be8d4a51000048048) (.leaf 0x13d013de8d4a51000048048))) (.m (.x (.x (.leaf 0x140013ee8d4a51000048049) (.x (.leaf 0x140013ee8d4a5100004804a) (.x (.leaf 0x140013ee8d4a5100004804b) (.x (.y (.y (.leaf 0x140013ee8d4a5100004904c) (.y (.leaf 0x140013ee8d4a5100004a04c) (.y (.leaf 0x140013ee8d4a5100004b04c) (.y (.m (.m (.leaf 0x13e013ee8d4a5100004c04c) (.leaf 0x13f013fe8d4a5100004c04c)) (.leaf 0x1400140e8d4a5100004c04c)) (.leaf 0x140013ee8d4a5100004d04c))))) (.leaf 0x140013ee8d4a5100004e04c)) (.leaf 0x140013ee8d4a5100004804d))))) (.leaf 0x140013ee8d4a5100004804e)) (.m (.leaf 0x1420141e8d4a51000048048) (.leaf 0x1430143e8d4a51000048048)))) (by decide +kernel)

private theorem step17 : ProjectedGoal ⟨297, 323, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 310 (by decide) (by decide) (step15 rates cones) (step16 rates cones)

private theorem step18 : ProjectedGoal ⟨270, 323, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 296 (by decide) (by decide) (step14 rates cones) (step17 rates cones)

theorem Part00001 : ProjectedGoal ⟨270, 323, 0, 283, 0, 283⟩ := step18

end SubmodularMatching.SourceCertificate.Replay.HardNextLeft
