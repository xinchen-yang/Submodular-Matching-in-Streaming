import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step71 : ProjectedGoal ⟨54864, 55079, 141, 283, 283, 567⟩ :=
  projectedGoal_chunk _ (.leaf 0xd7ffd650e8d4a5100000f0db) (by decide +kernel)

theorem Part00005 : ProjectedGoal ⟨54864, 55079, 141, 283, 283, 567⟩ := step71

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
