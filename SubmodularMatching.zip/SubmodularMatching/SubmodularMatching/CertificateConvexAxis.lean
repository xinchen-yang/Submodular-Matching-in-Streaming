import SubmodularMatching.CertificateAxisEnvelope

/-!
# An exact minimum on a convex lower envelope

Ordered secants of a verified lower envelope imply that the sign of each
successive objective increment changes at most once. Two comparisons at the
selected support knot thus certify every ordinate of the original interval.
-/

namespace SubmodularMatching.SourceCertificate

/-- Coordinates viewed along the selected vertices of the lower envelope. -/
def hullDX (x vertex : ℕ → ℕ) (i : ℕ) : ℤ := (x (vertex (i + 1)) : ℤ) - x (vertex i)

def hullDH (height vertex : ℕ → ℕ) (i : ℕ) : ℤ :=
  (height (vertex (i + 1)) : ℤ) - height (vertex i)

def hullScore (x height : ℕ → ℕ) (weight penalty : ℤ) (k : ℕ) : ℤ :=
  weight * (height k : ℤ) - penalty * (x k : ℤ)

def hullStep (x height vertex : ℕ → ℕ) (weight penalty : ℤ) (i : ℕ) : ℤ :=
  weight * hullDH height vertex i - penalty * hullDX x vertex i

/-- The chord and secant facts need to be checked only once per source
height table and price interval. `count` is the number of chords. -/
structure ConvexAxisEnvelope (x height : ℕ → ℕ) (lo hi count : ℕ)
    (vertex : ℕ → ℕ) : Prop where
  first : vertex 0 = lo
  last : vertex count = hi
  indexStep : ∀ i < count, vertex i < vertex (i + 1)
  positiveWidth : ∀ i < count, 0 < hullDX x vertex i
  slopes : ∀ i, i + 1 < count →
    hullDH height vertex i * hullDX x vertex (i + 1) ≤
      hullDH height vertex (i + 1) * hullDX x vertex i
  chord : ∀ i < count, ∀ k, vertex i ≤ k → k ≤ vertex (i + 1) →
    integerChordCheck (x k) (height k) (x (vertex i)) (height (vertex i))
      (x (vertex (i + 1))) (height (vertex (i + 1))) = true

theorem hull_step_mul_le_of_slopes (x height vertex : ℕ → ℕ) (w p : ℤ) (i : ℕ)
    (hw : 0 ≤ w)
    (h : hullDH height vertex i * hullDX x vertex (i + 1) ≤
      hullDH height vertex (i + 1) * hullDX x vertex i) :
    hullStep x height vertex w p i * hullDX x vertex (i + 1) ≤
      hullStep x height vertex w p (i + 1) * hullDX x vertex i := by
  have h' := mul_le_mul_of_nonneg_left h hw
  unfold hullStep
  nlinarith only [h']

theorem hull_score_diff (x height vertex : ℕ → ℕ) (w p : ℤ) (i : ℕ) :
    hullScore x height w p (vertex (i + 1)) - hullScore x height w p (vertex i) =
      hullStep x height vertex w p i := by
  unfold hullScore hullStep hullDX hullDH
  ring

theorem hullStep_nonnegative_after (x height vertex : ℕ → ℕ)
    (lo hi count : ℕ) (hull : ConvexAxisEnvelope x height lo hi count vertex)
    (w p : ℤ) (hw : 0 ≤ w) (m : ℕ)
    (hbase : 0 ≤ hullStep x height vertex w p m) :
    ∀ j, m ≤ j → j < count → 0 ≤ hullStep x height vertex w p j := by
  intro j
  induction j with
  | zero =>
    intro h
    cases Nat.eq_zero_of_le_zero h
    exact fun _ => hbase
  | succ j ih =>
    intro hmin hj
    by_cases h : m = j + 1
    · rw [← h]
      exact hbase
    · have hmid : m ≤ j := by omega
      have hp := ih hmid (Nat.lt_of_succ_lt hj)
      have hscaled := hull_step_mul_le_of_slopes x height vertex w p j hw (hull.slopes j hj)
      exact nonneg_of_mul_nonneg_left
        ((mul_nonneg hp (hull.positiveWidth (j + 1) hj).le).trans hscaled)
        (hull.positiveWidth j (Nat.lt_of_succ_lt hj))

theorem hullStep_nonpositive_before (x height vertex : ℕ → ℕ)
    (lo hi count : ℕ) (hull : ConvexAxisEnvelope x height lo hi count vertex)
    (w p : ℤ) (hw : 0 ≤ w) (m : ℕ) (hm : m < count)
    (hbase : hullStep x height vertex w p m ≤ 0)
    (j : ℕ) (hj : j ≤ m) :
    hullStep x height vertex w p j ≤ 0 := by
  induction h : m - j generalizing j with
  | zero =>
    have he : j = m := by omega
    simpa only [he] using hbase
  | succ n ih =>
    have hn : m - (j + 1) = n := by omega
    have hj' : j + 1 ≤ m := by omega
    have hp := ih (j + 1) hj' hn
    have hjlt := lt_of_le_of_lt hj' hm
    have hd := hull.positiveWidth (j + 1) hjlt
    have hscaled := hull_step_mul_le_of_slopes x height vertex w p j hw (hull.slopes j hjlt)
    have hneg := hscaled.trans (mul_nonpos_of_nonpos_of_nonneg hp
      (hull.positiveWidth j (Nat.lt_of_succ_lt hjlt)).le)
    exact nonpos_of_mul_nonpos_left hneg hd

theorem hull_support_minimum (x height vertex : ℕ → ℕ)
    (lo hi count : ℕ) (hull : ConvexAxisEnvelope x height lo hi count vertex)
    (w p : ℤ) (hw : 0 ≤ w) (m : ℕ) (hm : m ≤ count)
    (hleft : 0 < m → hullStep x height vertex w p (m - 1) ≤ 0)
    (hright : m < count → 0 ≤ hullStep x height vertex w p m) :
    ∀ j ≤ count, hullScore x height w p (vertex m) ≤ hullScore x height w p (vertex j) := by
  intro j hj
  by_cases hdir : m ≤ j
  · induction j with
    | zero =>
      have he := Nat.eq_zero_of_le_zero hdir
      rw [he]
    | succ j ih =>
      by_cases he : m = j + 1
      · rw [he]
      · have hpre : m ≤ j := by omega
        have hjlt : j < count := by omega
        have hm' := lt_of_le_of_lt hpre hjlt
        have hpos := hullStep_nonnegative_after x height vertex lo hi count hull w p hw m
          (hright hm') j hpre hjlt
        rw [← hull_score_diff] at hpos
        exact (ih hjlt.le hpre).trans (sub_nonneg.mp hpos)
  · have hjm : j < m := lt_of_not_ge hdir
    have hm0 : 0 < m := Nat.zero_lt_of_lt hjm
    have hm' : m - 1 < count := by omega
    have hsign (k : ℕ) (hk : k < m) : hullStep x height vertex w p k ≤ 0 :=
      hullStep_nonpositive_before x height vertex lo hi count hull w p hw (m - 1) hm'
        (hleft hm0) k (by omega)
    have hmono (k : ℕ) (hk : k ≤ m) :
        hullScore x height w p (vertex m) ≤ hullScore x height w p (vertex k) := by
      induction hdist : m - k generalizing k with
      | zero =>
        have hke : k = m := by omega
        rw [hke]
      | succ n ih =>
        have hnext : m - (k + 1) = n := by omega
        have hcase := ih (k + 1) (by omega) hnext
        have hs := hsign k (by omega)
        rw [← hull_score_diff] at hs
        exact hcase.trans (sub_nonpos.mp hs)
    exact hmono j hjm.le

theorem hull_point_in_chord (vertex : ℕ → ℕ) (count k : ℕ)
    (hlo : vertex 0 ≤ k) (hhi : k ≤ vertex count) :
    k = vertex 0 ∨ ∃ i < count, vertex i ≤ k ∧ k ≤ vertex (i + 1) := by
  induction count with
  | zero => exact Or.inl (hhi.antisymm hlo)
  | succ n ih =>
    by_cases h : k ≤ vertex n
    · rcases ih h with he | ⟨i, hi, h₁, h₂⟩
      · exact Or.inl he
      · exact Or.inr ⟨i, hi.trans (Nat.lt_succ_self _), h₁, h₂⟩
    · exact Or.inr ⟨n, Nat.lt_succ_self _, (lt_of_not_ge h).le, hhi⟩

theorem ConvexAxisEnvelope.vertex_le_hi (x height vertex : ℕ → ℕ) (lo hi count : ℕ)
    (hull : ConvexAxisEnvelope x height lo hi count vertex) (i : ℕ) (hi' : i ≤ count) :
    vertex i ≤ hi := by
  have h : ∀ j ≤ count, i ≤ j → vertex i ≤ vertex j := by
    intro j hj hij
    induction j with
    | zero => cases Nat.eq_zero_of_le_zero hij; exact le_rfl
    | succ j ih =>
      by_cases h : i = j + 1
      · rw [h]
      · exact (ih (Nat.le_of_succ_le hj) (by omega)).trans
          (hull.indexStep j (Nat.lt_of_succ_le hj)).le
  simpa only [hull.last] using h count le_rfl hi'

/-- Two supporting secants certify the raw minimum on all original knots
of the interval, including the heights not used as hull vertices. -/
theorem integer_axis_minimum_of_hull (S : ℕ) (x height vertex : ℕ → ℕ)
    (lo hi count : ℕ) (hull : ConvexAxisEnvelope x height lo hi count vertex)
    (hcoordinate : ∀ i j, i ≤ j → j ≤ hi → x i ≤ x j)
    (w p : ℤ) (hw : 0 ≤ w) (m : ℕ) (hm : m ≤ count)
    (hleft : 0 < m → hullStep x height vertex w p (m - 1) ≤ 0)
    (hright : m < count → 0 ≤ hullStep x height vertex w p m)
    (k : ℕ) (hkl : lo ≤ k) (hkh : k ≤ hi) :
    integerAxisCheck S (x k) (height k) w p (hullScore x height w p (vertex m)) = true := by
  have hmin := hull_support_minimum x height vertex lo hi count hull w p hw m hm hleft hright
  have hcheck (j : ℕ) (hj : j ≤ count) :
      integerAxisCheck S (x (vertex j)) (height (vertex j)) w p
        (hullScore x height w p (vertex m)) = true :=
    decide_eq_true (hmin j hj)
  rcases hull_point_in_chord vertex count k (hull.first.symm ▸ hkl) (hull.last.symm ▸ hkh) with
      hk | ⟨i, hi', hiLo, hiHi⟩
  · rw [hk]
    exact hcheck 0 (Nat.zero_le _)
  · have horder : x (vertex i) < x (vertex (i + 1)) := by
      have h := sub_pos.mp (hull.positiveWidth i hi')
      exact_mod_cast h
    have hBound := hull.vertex_le_hi x height vertex lo hi count (i + 1) (Nat.succ_le_of_lt hi')
    exact integerAxisCheck_of_chord S _ _ _ _ _ _ _ _ _ hw
      (hcoordinate _ _ hiLo hkh) (hcoordinate _ _ hiHi hBound) horder
      (hcheck i hi'.le) (hcheck (i + 1) (Nat.succ_le_of_lt hi'))
      (hull.chord i hi' k hiLo hiHi)

end SubmodularMatching.SourceCertificate
