import SubmodularMatching.StreamingOnlineInstance
import SubmodularMatching.StoredEmbedding
import Mathlib.Data.Nat.Log

/-!
# Deterministic bounded record sizes

Each frozen weight is encoded in weight-grid units and each vertex
potential is encoded in potential-grid units. Their bounds apply to every
transcript of bounded marginal samples, regardless of estimator accuracy.
-/

namespace SubmodularMatching.Streaming

/-- The ratios required by the executable grid can be formed without
writing the guess's absolute scale into the potential state. -/
def GridUpdateParameters.paper (base : RationalStage) (stages : List RationalStage)
    (p epsilon : ℚ) (vertices : ℕ) : GridUpdateParameters :=
  ⟨base, stages, vertices, p * epsilon / (vertices : ℚ) ^ 2, (vertices : ℚ) ^ 2 / epsilon⟩

theorem GridUpdateParameters.paper_matches (base : RationalStage) (stages : List RationalStage)
    (p epsilon : ℚ) (vertices : ℕ) (C : PotentialConfig)
    (he : 0 < epsilon) (hv : 0 < vertices)
    (hbase : base.real = C.base) (hstages : stages.map RationalStage.real = C.stages)
    (hp : (p : ℝ) = C.p)
    (hθ : C.theta = (epsilon : ℝ) * C.tau / vertices)
    (hd : C.gap = (epsilon : ℝ) * C.tau / (vertices : ℝ) ^ 2)
    (hg : C.grid = C.p * (epsilon : ℝ) ^ 2 * C.tau / (vertices : ℝ) ^ 4) :
    (GridUpdateParameters.paper base stages p epsilon vertices).Matches C := by
  have he' : 0 < (epsilon : ℝ) := by exact_mod_cast he
  have hv' : 0 < (vertices : ℝ) := by exact_mod_cast hv
  refine ⟨hbase, hstages, ?_, ?_, ?_⟩
  · simp only [GridUpdateParameters.paper]
    push_cast
    rw [hd, hθ]
    field_simp
  · simp only [GridUpdateParameters.paper]
    push_cast
    rw [hp, hd, hg]
    field_simp
  · simp only [GridUpdateParameters.paper]
    push_cast
    rw [hd, hg]
    field_simp

/-- The exact snapped accumulator has a bounded nonnegative integer index. -/
theorem sourceAccumulator_interval {N : ℕ} (d tau : ℝ) (samples : Fin N → ℝ)
    (hd : 0 < d) (hs : ∀ i, 0 ≤ samples i ∧ samples i ≤ tau) :
    0 ≤ sourceIndex d samples ∧ (sourceIndex d samples : ℝ) ≤ (N : ℝ) * (4 * tau / d) := by
  unfold sourceIndex
  constructor
  · exact Finset.sum_nonneg (fun i _ => Int.floor_nonneg.2 (by
      exact div_nonneg (by linarith [(hs i).1]) hd.le))
  · push_cast
    calc
      _ ≤ ∑ _i : Fin N, 4 * tau / d := by
        apply Finset.sum_le_sum
        intro i _
        exact (Int.floor_le _).trans
          (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left (hs i).2 (by norm_num)) hd.le)
      _ = _ := by simp

/-- Any integer weight returned by the estimator fits in the stated
relative range. -/
theorem sourceWeightIndex_le {N : ℕ} (d tau : ℝ) (samples : Fin N → ℝ)
    (hd : 0 < d) (hN : 0 < N) (hs : ∀ i, 0 ≤ samples i ∧ samples i ≤ tau) :
    (sourceWeightIndex N (sourceIndex d samples) : ℝ) ≤ tau / d := by
  apply (le_div_iff₀ hd).2
  rw [mul_comm, ← sourceWeight_eq_index]
  exact (sourceWeight_bounds d tau samples hd hN hs).2

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Each sparse numerical record remains inside the checked potential cap. -/
theorem runOnlineInstance_index_le (R : GridUpdateParameters) (C : PotentialConfig)
    (hR : R.Matches C) (hd : 0 < C.gap) (ends : E → V × V) (input : ℕ → E × ℕ) (n : ℕ)
    (hweight : ∀ i < n, C.gap * (input i).2 ≤ C.tau) (v : V) :
    (indexAt (runOnlineInstance R ends input n).vertices v : ℝ) ≤ C.cap / C.grid := by
  apply (le_div_iff₀ C.grid_pos).2
  rw [mul_comm, (runOnlineInstance_represents R C hR hd ends input n).1.potential]
  exact (runPotential_invariant_prefix C ends _ n hweight v).2.1

/-- Stored edge records have the proven single-instance cardinality bound,
using distinct arrivals to identify the record sequence with its finite set. -/
theorem runOnlineInstance_edge_records_le (R : GridUpdateParameters) (C : PotentialConfig)
    (hR : R.Matches C) (hd : 0 < C.gap) (ends : E → V × V) (edges : ℕ → E)
    {N : ℕ} (hN : 0 < N) (samples : ℕ → Fin N → ℝ)
    (allEdges M : Finset E) (n : ℕ)
    (hs : ∀ i < n, ∀ j, 0 ≤ samples i j ∧ samples i j ≤ C.tau)
    (hin : ∀ i < n, edges i ∈ allEdges)
    (hloopless : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ K : Finset E, K ⊆ allEdges →
      IsMatchingOn (endpointSet ends) K → K.card ≤ M.card)
    (hunique : ∀ i < n, ∀ j < n, edges i = edges j → i = j) :
    (runOnlineInstance R ends (fun i => (edges i, sourceWeightIndex N
      (sourceIndex C.gap (samples i)))) n).edges.length ≤ 2 * M.card * C.incidenceLimit := by
  let input := fun i => (edges i, sourceWeightIndex N (sourceIndex C.gap (samples i)))
  let st := runOnlineInstance R ends input n
  have hr := runOnlineInstance_represents R C hR hd ends input n
  have hinput : (fun i => ((input i).1, C.gap * (input i).2)) =
      (fun i => (edges i, sourceWeight C.gap (samples i))) := by
    funext i
    simp [input, sourceWeight_eq_index]
  dsimp only at hr
  rw [hinput] at hr
  have hn := acceptedOrder_nodup C ends (fun i => (edges i, sourceWeight C.gap (samples i))) n hunique
  change st.edges.length ≤ _
  calc
    _ = (st.edges.map Prod.fst).toFinset.card := by
      have hno : (st.edges.map Prod.fst).Nodup := by rw [hr.2]; exact hn
      rw [List.toFinset_card_of_nodup hno, List.length_map]
    _ = _ := congrArg Finset.card hr.1.stored
    _ ≤ _ := sampled_runPotential_storage_bound C ends hN hd edges samples allEdges M n
      hs hin hloopless hMsub hM hmax

/-- A positive index bounded by a fixed-degree polynomial in the vertex
count has an explicit word-width bound. Zero needs no exponent bits here. -/
theorem polynomial_index_binary_width (index n A power a b : ℕ)
    (hindex : index ≤ A * n ^ power) (hA : A ≤ 2 ^ a) (hn : n ≤ 2 ^ b) :
    Nat.log 2 index ≤ a + b * power := by
  have hscale : index ≤ 2 ^ (a + b * power) := by
    calc
      _ ≤ A * n ^ power := hindex
      _ ≤ 2 ^ a * (2 ^ b) ^ power :=
        Nat.mul_le_mul hA (Nat.pow_le_pow_left hn _)
      _ = _ := by rw [pow_add, pow_mul]
  calc
    Nat.log 2 index ≤ Nat.log 2 (2 ^ (a + b * power)) := Nat.log_mono_right hscale
    _ = _ := Nat.log_pow (by decide) _

end SubmodularMatching.Streaming
