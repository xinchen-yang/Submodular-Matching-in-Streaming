import SubmodularMatching.ProjectedShearerBestPair
import SubmodularMatching.CapacitySignedSamplerResources
import SubmodularMatching.NonmonotoneLayersBestWords

/-! Bounded binary precision and size for both decoded Shearer samplers. -/
namespace SubmodularMatching.AppendixM
open Streaming LinearPacking Capacity NonmonotoneLayers NonmonotoneOptimizer UpperBoundAssembly Shearer ShearerCappedSampler
open GibbsSampler GibbsMatching TwoLayerDiffuse
open scoped BigOperators
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

theorem layerShare_pow (h : ℕ) : layerShare (2^h) = ((2:ℝ)^(2*h+2))⁻¹ := by
  simp only [layerShare,Nat.cast_pow,Nat.cast_ofNat,one_div,pow_add,show 2*h=h*2 by omega,pow_mul]
  congr 1
  ring

def originalLayerCap (E : Type*) [Fintype E] (h : ℕ) := 2*Fintype.card E+2*h+3

theorem layerCap_budget (E : Type*) [Fintype E] (h : ℕ) :
    (Fintype.card E:ℝ)+Real.log (1/layerShare (2^h)) ≤ (originalLayerCap E h:ℝ)*Real.log 2 := by
  have ht := physical_layer_threshold 1 (by norm_num) (le_refl 1) (fun _ : E => (1:ℝ)) (fun _ => le_refl 1) (2*h+2)
  rw [layerShare_pow]
  simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one,one_mul] at ht
  apply ht.trans
  apply mul_le_mul_of_nonneg_right _ (Real.log_nonneg (by norm_num))
  exact_mod_cast (show 2*Fintype.card E+(2*h+2) ≤ originalLayerCap E h from by unfold originalLayerCap; omega)

def decoded_best_pair_pow (S : SimpleEdgeStream E V) (b : V→ℕ) (hb : ∀ v, 0<b v) (rank : Slots b ↪ ℕ)
    (k q T : ℕ) (hT : 0<T) (w : E→ℚ) (u : E→ℕ) (hu : ∀ e, w e=(u e:ℚ)/T)
    (r : ℕ) (pair : E→ BSlot b × BSlot b) (x : E→ℝ) (p Av Bv Ae Be : ℝ) :
    let Y := fun e => (decodedCoordinate S b k q w e:ℝ)
    let law θ := DeliveredLayer pairVertices (layerSupport S b rank) (fun e => slotWeight b (labelTable S.ends Y) θ e.1 e.2)
      (layerShare (2^r)) (layerShare_range _ (by positivity)) (originalLayerCap E r) (1/((2^r:ℕ):ℝ)^2)
    PhysicalAction S.ends b pair p degree Av Bv Ae Be x Y → law firstProportion × law secondProportion :=
  decoded_best_pair S b hb rank k q T hT w u hu (2^r) (by positivity) (originalLayerCap E r) (layerCap_budget E r)
    pair x p Av Bv Ae Be

/-- Both physical samplers can be obtained from precisely the rational
best coordinates returned by the scheduled optimizer. -/
def returnedBestSamplers {n l rows s bits : ℕ} [NeZero n] (data : BlockData E n l)
    (G : PackingGrid rows l) (hist : ℕ→E) (prob : ℕ→ℝ) (a : ℕ) (hp : ∀ i<a,0≤prob i ∧ prob i≤1)
    (f : Finset E→ℝ) (τ : ℝ) (words : OptimizerWords a n l s bits) (hc : 0<data.c) (hβ : data.β=scoreBeta)
    (hw : ∀ i, |(data.frozen i:ℝ)|≤paperScale l)
    (S : SimpleEdgeStream E V) (b : V→ℕ) (hb : ∀ v, 0<b v) (rank : Slots b ↪ ℕ)
    (col : E → Fin l) (k q r : ℕ) (pair : E→ BSlot b × BSlot b) (x : E→ℝ) (p Av Bv Ae Be : ℝ) :
    let answers := data.paperAnswers hist prob a f τ hp words
    let run := data.candidateRun G (paperExponent l) answers
    let best := (run (ascentFuel (paperExponent l))).bestState
    let w := fun e => atRat best (col e)
    let Y := fun e => (decodedCoordinate S b k q w e:ℝ)
    let law θ := DeliveredLayer pairVertices (layerSupport S b rank) (fun e => slotWeight b (labelTable S.ends Y) θ e.1 e.2)
      (layerShare (2^r)) (layerShare_range _ (by positivity)) (originalLayerCap E r) (1/((2^r:ℕ):ℝ)^2)
    PhysicalAction S.ends b pair p degree Av Bv Ae Be x Y → law firstProportion × law secondProportion := by
  intro answers run best w Y law act
  have hh := data.returned_best_words G hist prob a hp f τ words hc hβ hw
  exact decoded_best_pair_pow S b hb rank k q (BlockData.bestDen l) (by dsimp [BlockData.bestDen]; positivity) w
    (fun e => BlockData.stateNumerator l best (col e)) (fun e => (hh (col e)).2) r pair x p Av Bv Ae Be act

end
end SubmodularMatching.AppendixM
