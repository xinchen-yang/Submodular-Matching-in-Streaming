import SubmodularMatching.CapacityRealWordStorage
import SubmodularMatching.CapacityBankSpace

/-! Simultaneous source storage for the finite-word one-pass capacity program. -/
namespace SubmodularMatching.Capacity.RealOracle
open Streaming AppendixM UpperBoundAssembly
variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

private theorem member_info {X : Type*} (st : GuessBank X) (fresh : X) (W : ℝ) (span : ℕ)
    (value : ℝ) (act : ℕ → ℝ → X → X) (item : ℕ × X)
    (h : item ∈ (st.advance fresh W span value act).states) :
    item.1 ∈ (st.epoch.step W span value).active W span ∧
      (st.advance fresh W span value act).lookup item.1 = some item.2 := by
  let ep := st.epoch.step W span value
  let F := fun j => act j (ep.scale j) (if st.epoch.resets W value then fresh
    else (st.lookup j).getD fresh)
  change item ∈ (ep.active W span).map (fun j => (j,F j)) at h
  obtain ⟨j,hj,rfl⟩ := List.mem_map.mp h
  refine ⟨hj,?_⟩
  change ((ep.active W span).map (fun j => (j,F j))).lookup j = _
  generalize ep.active W span = keys at hj ⊢
  induction keys with
  | nil => simp at hj
  | cons i is ih =>
    by_cases he : j=i
    · subst i; simp
    · have hf : (j == i) = false := beq_eq_false_iff_ne.mpr he
      simpa [List.lookup,hf] using ih (by simpa [he] using hj)

def bankCells {cap : V → ℕ} (s : GuessBank (SparseSlots E cap)) :=
  4 + (s.states.map (fun kv => payloadCells kv.2)).sum

private theorem list_sum_bound {X : Type*} (L : List X) (f : X → ℕ) (a : ℕ)
    (h : ∀ x ∈ L, f x ≤ a) : (L.map f).sum ≤ L.length * a := by
  induction L with
  | nil => simp
  | cons y ys ih =>
    simp only [List.map_cons,List.sum_cons,List.length_cons,Nat.succ_mul]
    rw [Nat.add_comm (ys.length*a)]
    exact Nat.add_le_add (h y List.mem_cons_self) (ih (fun x hx => h x (List.mem_cons_of_mem _ hx)))

/-- Record cells for every live guess, including the epoch header, sparse
slot counters, stored labels and their recorded slot endpoints. The bound holds
at every prefix and on every tape. -/
theorem forwardBank_space (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0<cap (ends e).1 ∧ 0<cap (ends e).2)
    (hnoloop : ∀ e, (ends e).1 ≠ (ends e).2) (n N bits : ℕ)
    (hv : 2≤n^2) (hN : 0<N) (oracle : Finset E → ℝ)
    (hf : IsSubmodular (fun A => (oracle A:ℝ))) (hn : ∀ A, 0 ≤ (oracle A:ℝ))
    (edges : ℕ → E) (draw : ℕ → ℕ → ℕ → ℕ → ℕ) (k : ℕ)
    (hinj : ∀ i<k, ∀ l<k, edges i = edges l → i=l)
    (Z : Finset E) (hz : feasible ends cap Z) (hm : ∀ t, feasible ends cap t → t.card≤Z.card) :
    bankCells (forwardBank ends cap hpos (n^2) N bits oracle edges draw k) ≤
      (4+9*signedGuessCountConstant*(14+26*incidenceConstant)) *
        (Z.card+1)*((n+1).log2+1)^2 := by
  let v := n^2
  let w := (v+1).log2+1
  let w0 := (n+1).log2+1
  have hw : 1 ≤ w := Nat.le_add_left _ _
  have hw0 : 1 ≤ w0 := Nat.le_add_left _ _
  let bank := forwardBank ends cap hpos v N bits oracle edges draw k
  let W := (guessWidth v:ℝ)
  let span := guessSpan v
  let val := edgeClock edges oracle
  let act := slotAction ends cap hpos v N bits oracle edges draw
  let old := GuessBank.run (sparseEmpty cap) W span val act k
  have heq : bank = old.advance (sparseEmpty cap) W span (val k) (act k) := rfl
  have ht := GuessBank.state_count old (sparseEmpty cap) W span (val k) (act k)
  change bank.states.length ≤ span+1 at ht
  have hblock : ∀ kv ∈ bank.states, payloadCells kv.2 ≤
      (14+26*incidenceConstant)*(Z.card+1)*w := by
    intro kv hkv
    have hi := member_info old (sparseEmpty cap) W span (val k) (act k) kv hkv
    have hep : old.epoch = RealSource.runOnlineEpoch W span val k := GuessBank.clock _ _ _ _ _ _
    have hak := hi.1
    rw [hep] at hak
    obtain ⟨st,hst,ha,hb,hc⟩ := active_payload_storage ends cap hpos hnoloop v N bits hv hN
      oracle hf hn edges draw k kv.1 hinj Z hz hm hak
    change bank.lookup kv.1 = some st at hst
    have hsame : kv.2 = st := Option.some.inj (hi.2.symm.trans hst)
    rw [hsame]
    unfold payloadCells
    rw [ha]
    change st.machine.edges.length ≤ (1+2*(incidenceConstant*w))*Z.card at hb
    nlinarith only [hc,hb,hw,Nat.mul_le_mul_left Z.card hw]
  have hsum := list_sum_bound bank.states (fun kv => payloadCells kv.2) _ hblock
  have hh := ht.trans (signedGuessCount_le v)
  have hsize := hsum.trans (Nat.mul_le_mul_right _ hh)
  have hlog : w ≤ 3*w0 := squared_log_width n
  have hprod := Nat.mul_le_mul_left (signedGuessCountConstant*(14+26*incidenceConstant)*(Z.card+1))
    (Nat.pow_le_pow_left hlog 2)
  have hunit : 1 ≤ (Z.card+1)*w0^2 := Nat.succ_le_of_lt (Nat.mul_pos (Nat.succ_pos _) (pow_pos (by omega) _))
  change (bank.states.map (fun kv => payloadCells kv.2)).sum ≤
    signedGuessCountConstant*w*((14+26*incidenceConstant)*(Z.card+1)*w) at hsize
  change 4+(bank.states.map (fun kv => payloadCells kv.2)).sum ≤
    (4+9*signedGuessCountConstant*(14+26*incidenceConstant))*(Z.card+1)*w0^2
  calc
    _ ≤ 4*((Z.card+1)*w0^2)+signedGuessCountConstant*w*((14+26*incidenceConstant)*(Z.card+1)*w) :=
      Nat.add_le_add (by simpa using Nat.mul_le_mul_left 4 hunit) hsize
    _ = 4*((Z.card+1)*w0^2)+signedGuessCountConstant*(14+26*incidenceConstant)*(Z.card+1)*w^2 := by ring
    _ ≤ _ := by
      have hh := Nat.add_le_add_left hprod (4*((Z.card+1)*w0^2))
      convert hh using 1 <;> ring

end SubmodularMatching.Capacity.RealOracle
