import SubmodularMatching.ReplayQuickRate

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 16000
set_option maxHeartbeats 5000000

theorem quick8192 : allIndexed compareQuick 8192 sourceRates08192 = true := by decide +kernel

end SubmodularMatching.SourceCertificate.Replay
