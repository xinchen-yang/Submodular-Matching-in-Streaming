import SubmodularMatching.NonmonotoneSlotSupport
import SubmodularMatching.NonmonotoneSlotAlteration
import SubmodularMatching.NonmonotoneSlotPairPrecision

open scoped BigOperators

namespace SubmodularMatching.TwoLayerDiffuse

open GibbsMatching VarianceBound TwoStage
noncomputable section

variable {V I : Type*} [Fintype V] [DecidableEq V] [Fintype I] [DecidableEq I]

private theorem stored_card_two (b : V → ℕ) (rank : Slots b ↪ ℕ) (R : Finset (V × V))
    (e : Slots b × Slots b) (he : e ∈ storedSlotPairs b rank R) : (pairVertices e).card = 2 :=
  orderedPairs_card_two rank e (Finset.mem_filter.mpr ⟨Finset.mem_univ _,(Finset.mem_filter.mp he).2⟩)

theorem retained_slot_degree (b : V → ℕ) (hb : ∀ v, 0 < b v) (rank : Slots b ↪ ℕ)
    (R : Finset (V × V)) (Y : V → V → ℝ) (symm : ∀ u v, Y u v = Y v u)
    (diag : ∀ v, Y v v = 0) (hR : ∀ u v, Y u v ≠ 0 → (u,v) ∈ R ∨ (v,u) ∈ R)
    (θ : ℝ) (i : Slots b) :
    Shearer.vertexDegree pairVertices (storedSlotPairs b rank R) (fun z => slotWeight b Y θ z.1 z.2) i =
      θ * slotLoad b Y i.1 := by
  have h := neighborActivity_row_sum pairVertices (storedSlotPairs b rank R) (fun z => slotWeight b Y θ z.1 z.2)
    (stored_card_two b rank R) i
  simp_rw [stored_neighbor_matrix b rank R Y symm diag hR] at h
  rw [slot_degree_scan b hb Y θ i] at h
  rw [← show _ = Shearer.vertexDegree _ _ _ i from h]
  dsimp [slotLoad]
  ring

def retainedSlotLayer (b : V → ℕ) (hb : ∀ v, 0 < b v) (rank : Slots b ↪ ℕ)
    (R : Finset (V × V)) (Y : V → V → ℝ) (symm : ∀ u v, Y u v = Y v u)
    (diag : ∀ v, Y v v = 0) (hR : ∀ u v, Y u v ≠ 0 → (u,v) ∈ R ∨ (v,u) ∈ R)
    (hn : ∀ u v, 0 ≤ Y u v) (θ d : ℝ) (hθ : 0 ≤ θ) (hθd : θ*d ≤ 1/4)
    (hload : ∀ v, slotLoad b Y v ≤ d) : Layer pairVertices (storedSlotPairs b rank R) where
  y z := slotWeight b Y θ z.1 z.2
  nonneg z _ := by unfold slotWeight; exact div_nonneg (mul_nonneg hθ (hn _ _)) (by positivity)
  small i := (retained_slot_degree b hb rank R Y symm diag hR θ i).trans_le
    ((mul_le_mul_of_nonneg_left (hload i.1) hθ).trans hθd)

/-- Both sampled layers take place on the actual slot pairs over retained labels;
the separately enumerated diffuse vector still has just its single assigned copy
per edge. -/
theorem retained_slot_alteration (b : V → ℕ) (hb : ∀ v, 0 < b v) (rank : Slots b ↪ ℕ)
    (R : Finset (V × V)) (Y : V → V → ℝ) (symm : ∀ u v, Y u v = Y v u)
    (diag : ∀ v, Y v v = 0) (hR : ∀ u v, Y u v ≠ 0 → (u,v) ∈ R ∨ (v,u) ∈ R)
    (hn : ∀ u v, 0 ≤ Y u v)
    (ends : I → Slots b × Slots b) (loopless : ∀ e, (ends e).1 ≠ (ends e).2)
    (simple : Function.Injective (pairEnds ends)) (x : I → ℝ) (hx : ∀ e, 0 ≤ x e)
    (d p ξ θ₁ θ₂ tv te : ℝ) (hd : 0 ≤ d) (hd' : d ≤ 1/3) (hξ : 0 < ξ) (hp : 0 < p)
    (hpc : p ≤ coordinateCap ξ) (hθ₁ : 0 ≤ θ₁) (hθ₂ : 0 ≤ θ₂) (hsum : θ₁+θ₂=1)
    (ht₁ : θ₁*d ≤ 1/4) (ht₂ : θ₂*d ≤ 1/4) (hload : ∀ u, slotLoad b Y u ≤ d)
    (hv : ∀ i : Slots b, Joint.degree ends x i + (1-2*θ₁*θ₂*tv)*slotLoad b Y i.1
      ≤ 1 - θ₁*θ₂*tv^2)
    (hedge : ∀ e, x e / p + (1-2*θ₁*θ₂*te)*(slotLoad b Y (ends e).1.1 + slotLoad b Y (ends e).2.1)
      ≤ 1 - θ₁*θ₂*te^2) :
    let A := retainedSlotLayer b hb rank R Y symm diag hR hn θ₁ d hθ₁ ht₁ hload
    let B := retainedSlotLayer b hb rank R Y symm diag hR hn θ₂ d hθ₂ ht₂ hload
    let z := alteredSparse pairVertices (storedSlotPairs b rank R) ends A B x ξ
    (∀ ω e, 0 ≤ z ω e ∧ z ω e ≤ p) ∧ (∀ ω i, Joint.degree ends (z ω) i ≤ 1) ∧
    (∀ ω e, z ω e ≠ 0 → vacant pairVertices (storedSlotPairs b rank R) (ends e).1 ω = 1 ∧
      vacant pairVertices (storedSlotPairs b rank R) (ends e).2 ω = 1) ∧
    ∀ e, (1-ξ)*x e ≤ finiteMean (joint A B) (fun ω => z ω e) := by
  intro A B z
  let ℓ := fun i : Slots b => slotLoad b Y i.1
  exact packed_sparse_alteration pairVertices (storedSlotPairs b rank R) (stored_card_two b rank R)
    ends loopless simple A B x hx d p ξ θ₁ θ₂ tv te hd hd' hξ hp hpc hθ₁ hθ₂ hsum ℓ
    (fun i => hload i.1) (retained_slot_degree b hb rank R Y symm diag hR θ₁)
    (retained_slot_degree b hb rank R Y symm diag hR θ₂) hv hedge

/-- The same original-label accumulator bounds the actual partial graph's
pair probability. Omitting the zero coordinates introduces no error. -/
theorem retained_scan_error (b : V → ℕ) (hb : ∀ v, 0 < b v) (rank : Slots b ↪ ℕ)
    (R : Finset (V × V)) (Y : V → V → ℝ) (hs : ∀ u v, Y u v = Y v u)
    (hz : ∀ u, Y u u = 0) (hR : ∀ u v, Y u v ≠ 0 → (u,v) ∈ R ∨ (v,u) ∈ R)
    (hn : ∀ u v, 0 ≤ Y u v) (θ d : ℝ) (hθ : 0 ≤ θ) (hsd : θ*d ≤ 1/4)
    (hload : ∀ u, slotLoad b Y u ≤ d) (m : ℕ) (hm : 0 < m) (i j : Slots b) (hne : i ≠ j) :
    let A := retainedSlotLayer b hb rank R Y hs hz hR hn θ d hθ hsd hload
    A.pair i j ≤ scanPairUpper b Y θ m i j ∧ scanPairUpper b Y θ m i j ≤ 1 ∧
      scanPairUpper b Y θ m i j ≤ A.pair i j + (Fintype.card V : ℝ)/m := by
  intro A
  have hstored := slot_pair_scan b hb Y θ pairVertices (storedSlotPairs b rank R)
    (fun p => slotWeight b Y θ p.1 p.2) (stored_card_two b rank R)
    (stored_neighbor_matrix b rank R Y hs hz hR θ) i j hne
  have hfull := implicit_pair_probability b hb rank Y hs hz θ i j hne
  have heq : A.pair i j = Shearer.unmatchedPair pairVertices (orderedPairs rank)
      (fun p => slotWeight b Y θ p.1 p.2) i j := hstored.trans hfull.symm
  have hle := ((A.pair_bounds (stored_card_two b rank R) i j).2).trans (A.free_bounds i).2
  rw [heq] at hle ⊢
  exact scanPairUpper_error b hb rank Y hs hz hn θ m hm i j hne hle

end
end SubmodularMatching.TwoLayerDiffuse
