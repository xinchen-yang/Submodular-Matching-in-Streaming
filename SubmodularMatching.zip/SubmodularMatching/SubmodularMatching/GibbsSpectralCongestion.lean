import SubmodularMatching.GibbsSpectralEncoding
import SubmodularMatching.GibbsSpectralPaths
import Mathlib.Data.Nat.Choose.Bounds

/-!
# Polynomial congestion for activities at most one

For a fixed oriented transition, each pair of matchings has a distinct
encoding into a matching and a subset of at most four edges. The missing
activity factors are at most one. The larger matching's stationary mass
controls the transition capacity in either direction by reversibility.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [LinearOrder E] [DecidableEq V]

omit [DecidableEq V] in
/-- The possible sets of at most four defects. -/
def defectSets (edges : Finset E) : Finset (Finset E) :=
  edges.powerset.filter (fun D => D.card ≤ 4)

omit [DecidableEq V] [LinearOrder E] in
@[simp] theorem mem_defectSets (edges D : Finset E) :
    D ∈ defectSets edges ↔ D ⊆ edges ∧ D.card ≤ 4 := by
  simp [defectSets]

omit [DecidableEq V] in
theorem defectSets_card_le (edges : Finset E) :
    (defectSets edges).card ≤ 5*(edges.card+1)^4 := by
  have hEq : defectSets edges = (Finset.range 5).biUnion (fun i => edges.powersetCard i) := by
    ext D
    simp only [mem_defectSets,Finset.mem_biUnion,Finset.mem_range,Finset.mem_powersetCard]
    constructor
    · rintro ⟨hD,hK⟩
      exact ⟨D.card,by omega,hD,rfl⟩
    · rintro ⟨i,hi,hD,rfl⟩
      exact ⟨hD,by omega⟩
  rw [hEq]
  apply Finset.card_biUnion_le_card_mul
  intro i hi
  rw [Finset.card_powersetCard]
  have hi' : i ≤ 4 := by
    have h := Finset.mem_range.mp hi
    omega
  calc
    edges.card.choose i ≤ edges.card^i := Nat.choose_le_pow _ _
    _ ≤ (edges.card+1)^i := Nat.pow_le_pow_left (Nat.le_succ _) _
    _ ≤ (edges.card+1)^4 := Nat.pow_le_pow_right (Nat.succ_pos _) hi'

private theorem deletion_capacity (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (hAct : ∀ e ∈ edges, 0 ≤ activity e ∧ activity e ≤ 1)
    (M : Finset E) (hM : M ∈ matchings ends edges) (e : E) (he : e ∈ M) :
    probability ends edges activity M ≤
      (4*(edges.card:ℝ)) * (probability ends edges activity M *
        transition ends edges activity M (M.erase e)) := by
  have heS := ((mem_matchings ..).mp hM).1 he
  have hm : 0 < (edges.card:ℝ) := by
    exact_mod_cast Finset.card_pos.mpr ⟨e,heS⟩
  have heAct := hAct e heS
  have hπ := probability_nonnegative ends edges activity (fun d hd => (hAct d hd).1) M
  have hInv : (1:ℝ) ≤ 2*(1/(1+activity e)) := by
    rw [← mul_div_assoc,mul_one,le_div_iff₀ (by linarith : 0 < 1+activity e),one_mul]
    linarith
  rw [deletion_transition ends edges activity M e he]
  calc
    _ ≤ probability ends edges activity M * (2*(1/(1+activity e))) := by
      simpa only [mul_one] using mul_le_mul_of_nonneg_left hInv hπ
    _ = _ := by field_simp; ring

theorem orderedMove_capacity (ends : E → Finset V) (edges I F M N : Finset E)
    (activity : E → ℝ) (hAct : ∀ e ∈ edges, 0 ≤ activity e ∧ activity e ≤ 1)
    (hMove : OrderedMatchingMove ends edges I F M N) :
    probability ends edges activity (M ∪ N) ≤
      (4*(edges.card:ℝ)) * (probability ends edges activity M * transition ends edges activity M N) := by
  obtain ⟨e,hChange,-⟩ := hMove.route_step
  rcases hChange with ⟨_,heM,hN⟩ | ⟨_,heM,hN⟩
  · have h := deletion_capacity ends edges activity hAct M hMove.left e heM
    rwa [hN, Finset.union_eq_left.mpr (Finset.erase_subset _ _)]
  · have heN : e ∈ N := hN.symm ▸ Finset.mem_insert_self e M
    have hErase : N.erase e = M := by rw [hN,Finset.erase_insert heM]
    have hK : M ∪ N = N := Finset.union_eq_right.mpr (hN.symm ▸ Finset.subset_insert e M)
    rw [hK,detailed_balance ends edges activity M N hMove.left hMove.right]
    simpa only [hErase] using deletion_capacity ends edges activity hAct N hMove.right e heN

private noncomputable def chosenDefect (ends : E → Finset V) (edges I F M N : Finset E) :
    Finset E := by
  classical
  exact if h : OrderedMatchingMove ends edges I F M N then h.defect.choose else ∅

private theorem chosenDefect_spec (ends : E → Finset V) (edges I F M N : Finset E)
    (hMove : OrderedMatchingMove ends edges I F M N) :
    let D := chosenDefect ends edges I F M N
    D.card ≤ 4 ∧ D ⊆ diffEdges I F \ (M ∪ N) ∧
      Streaming.IsMatchingOn ends ((diffEdges I F \ (M ∪ N)) \ D) := by
  classical
  simp only [chosenDefect,dif_pos hMove]
  exact hMove.defect.choose_spec

set_option maxHeartbeats 900000 in
/-- Actual canonical paths for the manuscript's lazy chain on a graph
with two endpoints per edge and all activities in `[0,1]`. -/
noncomputable def lowActivityPaths (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (hAct : ∀ e ∈ edges, 0 ≤ activity e ∧ activity e ≤ 1)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) :
    CanonicalPathCertificate (matchings ends edges) (probability ends edges activity)
      (transition ends edges activity) edges.card (4*(edges.card:ℝ)*(defectSets edges).card) := by
  classical
  let states := matchings ends edges
  let π := probability ends edges activity
  let P := transition ends edges activity
  let routes := matchingRoute ends edges hEnds
  have hNonneg (M : Finset E) : 0 ≤ π M :=
    probability_nonnegative ends edges activity (fun d hd => (hAct d hd).1) M
  refine ⟨routes,?_,?_,?_,?_⟩
  · intro I hi F hf z hz
    have hMove := matchingRoute_valid ends edges hEnds I F hi hf z hz
    exact Finset.mem_product.mpr ⟨hMove.left,hMove.right⟩
  · exact fun I hi F hf => matchingRoute_telescopes ends edges hEnds I F hi hf
  · exact fun I hi F hf => matchingRoute_card_le ends edges hEnds I F hi hf
  intro M hM N hN
  let cap := π M * P M N
  let pairs := (states ×ˢ states).filter (fun z => (M,N) ∈ routes z.1 z.2)
  have hLoad : (∑ I ∈ states, ∑ F ∈ states, if (M,N) ∈ routes I F then π I*π F else 0) =
      ∑ z ∈ pairs, π z.1*π z.2 := by
    rw [Finset.sum_filter,Finset.sum_product]
  change (∑ I ∈ states, ∑ F ∈ states, if (M,N) ∈ routes I F then π I*π F else 0) ≤
    4*(edges.card:ℝ)*(defectSets edges).card*cap
  rw [hLoad]
  let K := M ∪ N
  let defect := fun z : Finset E × Finset E => chosenDefect ends edges z.1 z.2 M N
  let code := fun z : Finset E × Finset E => (complementMatching z.1 z.2 K (defect z),defect z)
  let codes := states ×ˢ defectSets edges
  have hValid (z : Finset E × Finset E) (hz : z ∈ pairs) :
      z.1 ∈ states ∧ z.2 ∈ states ∧ OrderedMatchingMove ends edges z.1 z.2 M N := by
    obtain ⟨hz₀,hz₁⟩ := Finset.mem_filter.mp hz
    obtain ⟨hI,hF⟩ := Finset.mem_product.mp hz₀
    exact ⟨hI,hF,matchingRoute_valid ends edges hEnds _ _ hI hF (M,N) hz₁⟩
  have hSpec (z : Finset E × Finset E) (hz : z ∈ pairs) :
      (defect z).card ≤ 4 ∧ defect z ⊆ diffEdges z.1 z.2 \ K ∧
        Streaming.IsMatchingOn ends ((diffEdges z.1 z.2 \ K) \ defect z) :=
    chosenDefect_spec ends edges z.1 z.2 M N (hValid z hz).2.2
  have hImage : pairs.image code ⊆ codes := by
    intro z hz
    obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hz
    obtain ⟨hi,hf,-⟩ := hValid p hp
    obtain ⟨hCard,hSub,hMatch⟩ := hSpec p hp
    apply Finset.mem_product.mpr
    refine ⟨complementMatching_valid ends edges p.1 p.2 K (defect p) hi hf hMatch,?_⟩
    apply (mem_defectSets ..).mpr
    refine ⟨?_,hCard⟩
    intro d hd
    obtain he | he := mem_diffEdges.mp (Finset.mem_sdiff.mp (hSub hd)).1
    · exact ((mem_matchings ..).mp hi).1 he.1
    · exact ((mem_matchings ..).mp hf).1 he.1
  have hInj : Set.InjOn code (↑pairs : Set (Finset E × Finset E)) := by
    intro z hz p hp hCode
    obtain ⟨hi,hf,hMove⟩ := hValid z hz
    obtain ⟨hi',hf',hMove'⟩ := hValid p hp
    have hResult := complementMatching_injective ends edges z.1 z.2 p.1 p.2 M N (defect z) (defect p)
      hi hf hi' hf' hMove hMove' (hSpec z hz).2.1 (hSpec p hp).2.1
      (congrArg Prod.snd hCode) (congrArg Prod.fst hCode)
    exact Prod.ext hResult.1 hResult.2
  have hCap : 0 ≤ cap :=
    mul_nonneg (hNonneg M)
      (transition_nonnegative ends edges activity (fun e he => (hAct e he).1) M N hM hN)
  have hTotal : (∑ z ∈ codes, π z.1) = (defectSets edges).card := by
    rw [Finset.sum_product]
    simp only [Finset.sum_const,nsmul_eq_mul]
    rw [← Finset.mul_sum, probability_total ends edges activity (fun e he => (hAct e he).1)]
    simp
  calc
    _ ≤ ∑ z ∈ pairs, (4*(edges.card:ℝ)*cap)*π (code z).1 := by
      apply Finset.sum_le_sum
      intro z hz
      obtain ⟨hi,hf,hMove⟩ := hValid z hz
      obtain ⟨-,hSub,hMatch⟩ := hSpec z hz
      exact (encoding_weight_bound ends edges z.1 z.2 M N (defect z) activity hAct hi hf
        hMove hSub hMatch).trans
        (mul_le_mul_of_nonneg_right (orderedMove_capacity ends edges z.1 z.2 M N activity hAct hMove)
          (hNonneg (code z).1))
    _ = ∑ z ∈ pairs.image code, (4*(edges.card:ℝ)*cap)*π z.1 :=
      (Finset.sum_image (f := fun z : Finset E × Finset E => (4*(edges.card:ℝ)*cap)*π z.1) hInj).symm
    _ ≤ ∑ z ∈ codes, (4*(edges.card:ℝ)*cap)*π z.1 := by
      apply Finset.sum_le_sum_of_subset_of_nonneg hImage
      intro z _ _
      exact mul_nonneg (mul_nonneg (by positivity) hCap) (hNonneg z.1)
    _ = _ := by rw [← Finset.mul_sum,hTotal]; ring

end SubmodularMatching.GibbsSampler
