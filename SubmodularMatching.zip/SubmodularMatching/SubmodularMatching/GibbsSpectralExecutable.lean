import SubmodularMatching.GibbsSpectralScan
import SubmodularMatching.GibbsSpectralRationalCells
import SubmodularMatching.GibbsSpectralMateArray

/-!
# A dyadic Gibbs walk on the stored edges and mate table

The executable pass computes the current proposal and its cell count
from two mate reads. It carries a single residual word and performs the
selected constant-size update once.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching
open scoped BigOperators

variable {E : Type*} [DecidableEq E]

/-- A one-pass selector that returns its already evaluated local action. -/
def scanLocalActions (entry : E → LocalAction E × ℕ) : List E → ℕ → Option (LocalAction E)
  | [], _ => none
  | e :: tail, word =>
      let action := entry e
      if word < action.2 then some action.1 else scanLocalActions entry tail (word-action.2)

omit [DecidableEq E] in
theorem scanLocalActions_eq (entry : E → LocalAction E × ℕ) (stored : List E) (word : ℕ) :
    scanLocalActions entry stored word =
      (scanTicket (fun e => (entry e).2) stored word).map (fun e => (entry e).1) := by
  induction stored generalizing word with
  | nil => rfl
  | cons e tail ih =>
    simp only [scanLocalActions,scanTicket]
    split <;> simp [ih]

omit [DecidableEq E] in
private theorem scanTicket_congr (c d : E → ℕ) (stored : List E) (word : ℕ)
    (hc : ∀ e ∈ stored, c e = d e) :
    scanTicket c stored word = scanTicket d stored word := by
  induction stored generalizing word with
  | nil => rfl
  | cons e tail ih =>
    have he := hc e (by simp)
    simp only [scanTicket,he]
    split
    · rfl
    · apply ih
      intro x hx
      exact hc x (List.mem_cons_of_mem e hx)

omit [DecidableEq E] in
private theorem scanTicket_mem (cells : E → ℕ) (stored : List E) (word : ℕ) (e : E)
    (h : scanTicket cells stored word = some e) : e ∈ stored := by
  induction stored generalizing word with
  | nil => simp [scanTicket] at h
  | cons d tail ih =>
    simp only [scanTicket] at h
    split at h
    · simp [← Option.some.inj h]
    · exact List.mem_cons_of_mem d (ih _ h)

private def arrayActionEntry {n : ℕ} (ep : E → Fin n × Fin n)
    (activity : E → ActivityWords) (m wordSize : ℕ) (a : Array (Option E)) (e : E) : LocalAction E × ℕ :=
  let action := localActionFromMates ep (lookupMateArray a) e
  (action,action.cellsFromWordSize m wordSize activity)

/-- One chain step on compact vertex indices, with a supplied uniform
word. The stored edge list contains only positive activity edges. -/
def arrayGibbsStep {n : ℕ} (ep : E → Fin n × Fin n) (activity : E → ActivityWords)
    (stored : List E) (m b : ℕ) (a : Array (Option E)) (word : ℕ) : Array (Option E) :=
  let action := scanLocalActions (arrayActionEntry ep activity m (2^b) a) stored word
  action.elim a (fun move => move.updateArray ep a)

@[simp] theorem arrayGibbsStep_size {n : ℕ} (ep : E → Fin n × Fin n)
    (activity : E → ActivityWords) (stored : List E) (m b : ℕ) (a : Array (Option E)) (word : ℕ) :
    (arrayGibbsStep ep activity stored m b a word).size = a.size := by
  unfold arrayGibbsStep
  cases scanLocalActions (arrayActionEntry ep activity m (2^b) a) stored word
  · rfl
  · simp

theorem arrayGibbsStep_refines {n : ℕ} (ends : E → Finset (Fin n)) (ep : E → Fin n × Fin n)
    (hEnds : ∀ d, ends d = {(ep d).1,(ep d).2}) (edges M : Finset E)
    (hM : M ∈ matchings ends edges) (activity : E → ActivityWords)
    (ha : ∀ e ∈ edges, 0 < (activity e).numerator ∧ 0 < (activity e).denominator)
    (stored : List E) (hs : stored.toFinset = edges)
    (m : ℕ) (hm : m = edges.card) (b word : ℕ) (a : Array (Option E)) (hSize : a.size = n)
    (hMate : RepresentsMates ends M (lookupMateArray a)) :
    let target := scanGibbsTransition ends M
      (fun e => moveCells ends edges (fun d => (activity d).real) b M (proposal ends M e)) stored word
    target ∈ matchings ends edges ∧
      RepresentsMates ends target (lookupMateArray (arrayGibbsStep ep activity stored m b a word)) := by
  dsimp only
  let entry := arrayActionEntry ep activity m (2^b) a
  let mathematicalCells := fun e => moveCells ends edges (fun d => (activity d).real) b M (proposal ends M e)
  let ticket := scanTicket mathematicalCells stored word
  have hCells (e : E) (he : e ∈ stored) : (entry e).2 = mathematicalCells e := by
    have heE : e ∈ edges := hs ▸ List.mem_toFinset.mpr he
    have hLegal := localActionFromMates_legal ends ep hEnds M (lookupMateArray a) hMate e
    dsimp only [entry,arrayActionEntry,mathematicalCells]
    rw [hm]
    exact legalLocalAction_cells_eq ends edges activity ha b M hM e heE _ hLegal
  have hScan : scanLocalActions entry stored word = ticket.map (fun e => (entry e).1) := by
    rw [scanLocalActions_eq,scanTicket_congr _ mathematicalCells stored word hCells]
  unfold arrayGibbsStep scanGibbsTransition
  change ((ticket.elim M (proposal ends M)) ∈ matchings ends edges) ∧
    RepresentsMates ends (ticket.elim M (proposal ends M))
      (lookupMateArray ((scanLocalActions entry stored word).elim a (fun move => move.updateArray ep a)))
  rw [hScan]
  cases ht : ticket with
  | none => exact ⟨hM,hMate⟩
  | some e =>
    simp only [Option.elim_some,Option.map_some]
    have he := scanTicket_mem mathematicalCells stored word e ht
    have heE : e ∈ edges := hs ▸ List.mem_toFinset.mpr he
    have hLegal := localActionFromMates_legal ends ep hEnds M (lookupMateArray a) hMate e
    constructor
    · exact proposal_mem_matchings ends edges M hM e heE
    · rw [LocalAction.updateArray_lookup ep a hSize, ← hLegal.apply_eq_proposal _ _ _ _]
      exact hLegal.updateMate_represents ends ep hEnds M ((mem_matchings ..).mp hM).2
        (lookupMateArray a) hMate e _

/-- Evaluate the bounded-size row work and count only indexed mate reads
and writes. Each visited edge is checked once, with two mate reads. -/
def arrayGibbsWork {n : ℕ} (ep : E → Fin n × Fin n) (activity : E → ActivityWords)
    (stored : List E) (m b : ℕ) (a : Array (Option E)) (word : ℕ) : ℕ × ℕ :=
  let entry := arrayActionEntry ep activity m (2^b) a
  let visited := scanTicketVisits (fun e => (entry e).2) stored word
  let chosen := scanLocalActions entry stored word
  (2*visited, chosen.elim 0 LocalAction.mateWrites)

theorem arrayGibbsWork_bound {n : ℕ} (ep : E → Fin n × Fin n) (activity : E → ActivityWords)
    (stored : List E) (m b : ℕ) (a : Array (Option E)) (word : ℕ) :
    (arrayGibbsWork ep activity stored m b a word).1 ≤ 2*stored.length ∧
      (arrayGibbsWork ep activity stored m b a word).2 ≤ 4 := by
  unfold arrayGibbsWork
  constructor
  · exact Nat.mul_le_mul_left 2 (scanTicketVisits_le _ _ _)
  · change (scanLocalActions (arrayActionEntry ep activity m (2^b) a) stored word).elim
      0 LocalAction.mateWrites ≤ 4
    cases scanLocalActions (arrayActionEntry ep activity m (2^b) a) stored word with
    | none => simp
    | some action => exact action.mateWrites_le


/-- Materialize the matching for the objective query by scanning the mate
table. Repeated edge identifiers at both endpoints coalesce. -/
def matchingOfMateArray (a : Array (Option E)) : Finset E :=
  (a.toList.filterMap id).toFinset

theorem matchingOfMateArray_eq {n : ℕ} (ends : E → Finset (Fin n)) (ep : E → Fin n × Fin n)
    (hEnds : ∀ d, ends d = {(ep d).1,(ep d).2}) (M : Finset E)
    (a : Array (Option E)) (hs : a.size = n) (hMate : RepresentsMates ends M (lookupMateArray a)) :
    matchingOfMateArray a = M := by
  ext d
  have hMem : d ∈ matchingOfMateArray a ↔ some d ∈ a := by
    simp only [matchingOfMateArray,List.mem_toFinset,List.mem_filterMap,id_eq,Array.mem_toList_iff]
    constructor
    · rintro ⟨v,hv,rfl⟩
      exact hv
    · intro hd
      exact ⟨some d,hd,rfl⟩
  rw [hMem]
  constructor
  · intro hd
    obtain ⟨i,hi⟩ := Array.getElem?_of_mem hd
    have hi' : i < n := hs ▸ (getElem?_eq_some_iff.mp hi).1
    let v : Fin n := ⟨i,hi'⟩
    have h := (hMate v d).mp (Option.join_eq_some_iff.mpr hi)
    exact h.1
  · intro hd
    have h := (hMate (ep d).1 d).mpr ⟨hd,by simp [hEnds d]⟩
    exact Array.mem_of_getElem? (Option.join_eq_some_iff.mp h)

/-- After decoding the mate table for the value query, the distribution
under one uniform word is exactly the compensated dyadic transition row. -/
theorem arrayGibbsStep_law {n : ℕ} (ends : E → Finset (Fin n)) (ep : E → Fin n × Fin n)
    (hEnds : ∀ d, ends d = {(ep d).1,(ep d).2}) (edges M N : Finset E)
    (hM : M ∈ matchings ends edges) (hN : N ∈ matchings ends edges)
    (activity : E → ActivityWords)
    (ha : ∀ e ∈ edges, 0 < (activity e).numerator ∧ 0 < (activity e).denominator)
    (stored : List E) (hs : stored.toFinset = edges) (hd : stored.Nodup)
    (m : ℕ) (hm : m = edges.card) (b : ℕ) (a : Array (Option E)) (hSize : a.size = n)
    (hMate : RepresentsMates ends M (lookupMateArray a)) :
    (((∑ w ∈ Finset.range (2^b), if
        matchingOfMateArray (arrayGibbsStep ep activity stored m b a w) = N then (1:ℕ) else 0) : ℕ) : ℝ) /
      (2:ℝ)^b = roundedTransition ends edges (fun d => (activity d).real) b M N := by
  have hDecode (w : ℕ) : matchingOfMateArray (arrayGibbsStep ep activity stored m b a w) =
      scanGibbsTransition ends M
        (fun e => moveCells ends edges (fun d => (activity d).real) b M (proposal ends M e)) stored w := by
    have h := arrayGibbsStep_refines ends ep hEnds edges M hM activity ha stored hs m hm b w a hSize hMate
    exact matchingOfMateArray_eq ends ep hEnds _ _ (by simpa) h.2
  simp_rw [hDecode]
  exact scanGibbsTransition_law ends edges (fun d => (activity d).real)
    (fun e _ => div_nonneg (by positivity) (by positivity)) b M N hM hN stored hs hd

omit [DecidableEq E] in
@[simp] theorem vacantMates_size (n : ℕ) : (vacantMates (E := E) n).size = n := by
  simp [vacantMates]

omit [DecidableEq E] in
theorem vacantMates_represents {n : ℕ} (ends : E → Finset (Fin n)) :
    RepresentsMates ends ∅ (lookupMateArray (vacantMates n)) := by
  intro v d
  simp [vacantMates,lookupMateArray,v.isLt]

end SubmodularMatching.GibbsSampler
