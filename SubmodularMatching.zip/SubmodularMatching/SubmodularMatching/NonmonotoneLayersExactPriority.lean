import SubmodularMatching.NonmonotoneMarkedPriority
import SubmodularMatching.ProjectedShearerWordHround

/-! Priority of the exact decoded marginals. There is no second numerical
decoder error after the certified optimizer has valued its true marginals. -/

namespace SubmodularMatching.Shearer

open GibbsMatching AppendixM VarianceBound NonmonotoneCandidate
open scoped BigOperators

variable {C W I : Type*} [DecidableEq C] [DecidableEq W] [DecidableEq I]

theorem markedMarginal_bounds (ends : C → Finset W) (S : Finset C) (Y : C → ℝ) (lab : C → I)
    (h0 : ∀ e∈S, 0≤Y e) (hend : ∀ e∈S, (ends e).card=2) (hload : ∀ w, ∑ e∈incident ends S w, Y e ≤ degree)
    (Q a b : ℕ) (ha : (a:ℝ)/Q=layerOne) (hb : (b:ℝ)/Q=layerTwo) (i : I) :
    0 ≤ unalteredMarginal ends S Y lab Q a b i ∧ unalteredMarginal ends S Y lab Q a b i ≤ 1 := by
  have one := bin_interior ends S Y h0 hend hload Q a (ha.trans_lt layerDegrees.2.1)
  have two := bin_interior ends S Y h0 hend hload Q b (hb.trans_lt (layerDegrees.2.2.2.trans layerDegrees.2.1))
  have con (t : ℝ) : binLaw ends S Y Q a b (fun _ _ => t) = t := by
    unfold binLaw markedPair
    simp only [expectation_const]
  let hit := fun A B : Finset (C×ℕ) => if i∈(A∪B).image (binLabel lab) then (1:ℝ) else 0
  have lo := binLaw_mono ends S Y Q a b one two (F:=fun _ _ => 0) (G:=hit)
    (fun A _ B _ => by dsimp [hit]; split_ifs <;> norm_num)
  have hi := binLaw_mono ends S Y Q a b one two (F:=hit) (G:=fun _ _ => 1)
    (fun A _ B _ => by dsimp [hit]; split_ifs <;> norm_num)
  rw [con] at lo hi
  exact ⟨lo,hi⟩

section
variable {C : Type*} [LinearOrder C]

theorem exact_marked_priority (ends : C → Finset W) (S : Finset C) (Y : C → ℝ) (lab : C → I)
    (els hist : ℕ → I) (r s : ℕ) (p : ℝ) (hp : 0≤p) (hp1 : p≤1)
    (f : Finset I → ℝ) (hf : IsSubmodular f) (hn : ∀ A,0≤f A)
    (H ε : ℝ) (hH : ∀ A, shiftResidual hist p f s A ≤ H) (hε : 0≤ε)
    (h0 : ∀ e∈S,0≤Y e) (hend : ∀ e∈S,(ends e).card=2) (hload : ∀ w, ∑ e∈incident ends S w, Y e≤degree)
    (Q a b : ℕ) (hQ : 0<Q) (ha : 0<a) (hb : 0<b) (hA : (a:ℝ)/Q=layerOne) (hB : (b:ℝ)/Q=layerTwo)
    (x y : C → ℝ) (hx : ∀ e, x e=(a:ℝ)/Q/degree*Y e) (hy : ∀ e, y e=(b:ℝ)/Q/degree*Y e)
    (hc : S.image lab ⊆ replacementPrefix els r) (hi : ∀ i<r, ∀ j<r, els i=els j → i=j) :
    let h := shiftResidual hist p f s
    let F := bernoulliExpectation els (fun j => unalteredMarginal ends S Y lab Q a b (els j)) (residualValue hist p f s) r
    ∀ estimate : PriorityEstimate C, (∀ A e, |estimate A e - marginal h (binLabel lab e) (A.image (binLabel lab))|≤ε) →
      gamma*F - priorityLossBudget S.card r Q H ε 0 ≤ finiteMean (nativeMarkedPair ends S a b x y)
        (fun z => residualValue hist p f s (priorityLabels ends S a b lab h estimate z)) := by
  intro h F estimate acc
  exact finite_marked_hprio ends S Y lab els hist _ r s p hp hp1 f hf hn h (fun _ => rfl) H ε 0 hH hε
    h0 hend hload Q a b hQ ha hb hA hB x y hx hy hc hi
    (fun j _ => markedMarginal_bounds ends S Y lab h0 hend hload Q a b hA hB (els j))
    (fun _ _ => by simp) estimate (fun A e _ => acc A e)

end
end SubmodularMatching.Shearer
