import SubmodularMatching.SamplingConcentration
import SubmodularMatching.JointPolytope

/-!
# Explicit finite alteration in the two-stage rounding theorem

The alteration is defined outcome by outcome. Its support, coordinate cap,
and fractional degree bound are deterministic. Its retention guarantee is
derived from finite means and variances by Chebyshev and a two-event union
bound; no independence or conditional concentration is assumed.
-/

open scoped BigOperators

namespace SubmodularMatching.TwoStage

open VarianceBound Information

noncomputable section

variable {E V Ω : Type*} [Fintype E] [Fintype Ω] [DecidableEq V]

/-- The unmatched indicator at the other endpoint, zero off the edge. -/
def opposite (ends : E → V × V) (U : V → Ω → ℝ) (v : V) (e : E) (ω : Ω) : ℝ :=
  if v = (ends e).1 then U (ends e).2 ω
  else if v = (ends e).2 then U (ends e).1 ω else 0

/-- The unconditioned neighbor load `Z_v` from the paper. -/
def load (ends : E → V × V) (a : E → ℝ) (U : V → Ω → ℝ) (v : V) (ω : Ω) : ℝ :=
  ∑ e, a e * opposite ends U v e ω

/-- Formula GJ8: retain only unmatched endpoints of acceptable load and scale. -/
def altered (ends : E → V × V) (a : E → ℝ) (U : V → Ω → ℝ)
    (ε : ℝ) (ω : Ω) (e : E) : ℝ :=
  if U (ends e).1 ω = 1 ∧ U (ends e).2 ω = 1 ∧
      load ends a U (ends e).1 ω ≤ 1 + ε ∧ load ends a U (ends e).2 ω ≤ 1 + ε
  then a e / (1 + ε) else 0

omit [Fintype Ω] in
theorem altered_bounds (ends : E → V × V) (a : E → ℝ) (U : V → Ω → ℝ)
    (ε p : ℝ) (hε : 0 ≤ ε) (ha : ∀ e, 0 ≤ a e ∧ a e ≤ p) (ω : Ω) (e : E) :
    0 ≤ altered ends a U ε ω e ∧ altered ends a U ε ω e ≤ p := by
  have hd : 0 < 1 + ε := by linarith
  unfold altered
  split_ifs
  · refine ⟨div_nonneg (ha e).1 hd.le, ?_⟩
    apply le_trans _ (ha e).2
    apply (div_le_iff₀ hd).2
    nlinarith [mul_nonneg (ha e).1 hε]
  · exact ⟨le_rfl, (ha e).1.trans (ha e).2⟩

omit [Fintype Ω] in
theorem altered_support (ends : E → V × V) (a : E → ℝ) (U : V → Ω → ℝ)
    (ε : ℝ) (ω : Ω) (e : E) (he : altered ends a U ε ω e ≠ 0) :
    U (ends e).1 ω = 1 ∧ U (ends e).2 ω = 1 := by
  unfold altered at he
  split_ifs at he with h
  · exact ⟨h.1, h.2.1⟩
  · exact (he rfl).elim

omit [Fintype Ω] in
/-- Every outcome has fractional degree at most one. -/
theorem altered_degree (ends : E → V × V) (a : E → ℝ) (U : V → Ω → ℝ)
    (ε : ℝ) (hε : 0 ≤ ε) (ha : ∀ e, 0 ≤ a e)
    (hU : ∀ v ω, U v ω = 0 ∨ U v ω = 1) (ω : Ω) (v : V) :
    Joint.degree ends (altered ends a U ε ω) v ≤ 1 := by
  classical
  have hd : 0 < 1 + ε := by linarith
  by_cases hgood : U v ω = 1 ∧ load ends a U v ω ≤ 1 + ε
  · have hterm (e : E) : Joint.incidence ends v e * altered ends a U ε ω e ≤
        a e * opposite ends U v e ω / (1 + ε) := by
      have hU0 (w : V) : 0 ≤ U w ω := by
        rcases hU w ω with h | h <;> simp [h]
      by_cases hv1 : v = (ends e).1
      · have hop : opposite ends U v e ω = U (ends e).2 ω := by
          rw [opposite, if_pos hv1]
        have hi : Joint.incidence ends v e = 1 := by simp [Joint.incidence, hv1]
        rw [hi, one_mul, hop]
        unfold altered
        split_ifs with hg
        · rw [hg.2.1, mul_one]
        · exact div_nonneg (mul_nonneg (ha e) (hU0 _)) hd.le
      · by_cases hv2 : v = (ends e).2
        · have hop : opposite ends U v e ω = U (ends e).1 ω := by
            rw [opposite, if_neg hv1, if_pos hv2]
          have hi : Joint.incidence ends v e = 1 := by simp [Joint.incidence, hv2]
          rw [hi, one_mul, hop]
          unfold altered
          split_ifs with hg
          · rw [hg.1, mul_one]
          · exact div_nonneg (mul_nonneg (ha e) (hU0 _)) hd.le
        · simp [Joint.incidence, opposite, hv1, hv2]
    have hs := Finset.sum_le_sum (fun e (_ : e ∈ Finset.univ) => hterm e)
    have hdeg : Joint.degree ends (altered ends a U ε ω) v ≤
        load ends a U v ω / (1 + ε) := by
      simpa only [Joint.degree, load, Finset.sum_div] using hs
    exact hdeg.trans ((div_le_one hd).2 hgood.2)
  · have hz (e : E) : Joint.incidence ends v e * altered ends a U ε ω e = 0 := by
      by_cases he : v = (ends e).1 ∨ v = (ends e).2
      · have hnot : ¬(U (ends e).1 ω = 1 ∧ U (ends e).2 ω = 1 ∧
            load ends a U (ends e).1 ω ≤ 1 + ε ∧
            load ends a U (ends e).2 ω ≤ 1 + ε) := by
          intro hg
          apply hgood
          rcases he with he | he
          · simpa only [he] using And.intro hg.1 hg.2.2.1
          · simpa only [he] using And.intro hg.2.1 hg.2.2.2
        simp [altered, hnot]
      · simp [Joint.incidence, he]
    simp only [Joint.degree, hz, Finset.sum_const_zero]
    norm_num

omit [Fintype E] [DecidableEq V] in
/-- An upper-tail probability from a one-sided mean bound and actual variance. -/
theorem overload_probability (μ : Ω → ℝ) (Z : Ω → ℝ)
    (hμ : ∀ ω, 0 ≤ μ ω) (δ ε B : ℝ) (hgap : δ < ε)
    (hmean : finiteMean μ Z ≤ 1 + δ) (hvar : finiteVariance μ Z ≤ B) :
    (∑ ω, if 1 + ε < Z ω then μ ω else 0) ≤ B / (ε - δ) ^ 2 := by
  classical
  have hdev (ω : Ω) : (if 1 + ε < Z ω then μ ω else 0) ≤
      if ε - δ ≤ |Z ω - finiteMean μ Z| then μ ω else 0 := by
    by_cases hz : 1 + ε < Z ω
    · have hh : ε - δ ≤ |Z ω - finiteMean μ Z| := by
        have habs := le_abs_self (Z ω - finiteMean μ Z)
        linarith
      simp [hz, hh]
    · simp only [hz, ↓reduceIte]
      split_ifs
      · exact hμ ω
      · exact le_rfl
  exact (Finset.sum_le_sum (fun ω (_ : ω ∈ Finset.univ) => hdev ω)).trans
    ((finite_chebyshev μ Z hμ (ε - δ) (sub_pos.mpr hgap)).trans
      (div_le_div_of_nonneg_right hvar (sq_nonneg _)))

/-- Retention of each coordinate under the actual finite alteration. -/
theorem altered_expectation (ends : E → V × V) (a : E → ℝ) (U : V → Ω → ℝ)
    (μ : Ω → ℝ) (hμ : ∀ ω, 0 ≤ μ ω)
    (hU : ∀ v ω, U v ω = 0 ∨ U v ω = 1)
    (ε δ B qmin : ℝ) (hε : 0 ≤ ε) (hgap : δ < ε) (hB : 0 ≤ B)
    (hqmin : 0 < qmin) (ha : ∀ e, 0 ≤ a e)
    (hmean : ∀ v, finiteMean μ (load ends a U v) ≤ 1 + δ)
    (hvar : ∀ v, finiteVariance μ (load ends a U v) ≤ B)
    (e : E) (q x : ℝ)
    (hq : finiteMean μ (fun ω => U (ends e).1 ω * U (ends e).2 ω) = q)
    (hqlower : qmin ≤ q) (hx : a e * q = x) :
    ((1 - 2 * B / (qmin * (ε - δ) ^ 2)) / (1 + ε)) * x ≤
      finiteMean μ (fun ω => altered ends a U ε ω e) := by
  classical
  let C := B / (ε - δ) ^ 2
  have hC : 0 ≤ C := div_nonneg hB (sq_nonneg _)
  have hd : 0 < 1 + ε := by linarith
  have had : 0 ≤ a e / (1 + ε) := div_nonneg (ha e) hd.le
  let bad (v : V) (ω : Ω) : ℝ := if load ends a U v ω ≤ 1 + ε then 0 else 1
  have hbad (v : V) : finiteMean μ (bad v) ≤ C := by
    simpa only [finiteMean, bad, mul_ite, mul_one, mul_zero, ← not_le, ite_not] using
      overload_probability μ (load ends a U v) hμ δ ε B hgap (hmean v) (hvar v)
  have hpoint (ω : Ω) :
      a e / (1 + ε) * (U (ends e).1 ω * U (ends e).2 ω -
        bad (ends e).1 ω - bad (ends e).2 ω) ≤ altered ends a U ε ω e := by
    unfold altered
    rcases hU (ends e).1 ω with hu | hu <;>
      rcases hU (ends e).2 ω with hv | hv <;>
      by_cases h1 : load ends a U (ends e).1 ω ≤ 1 + ε <;>
      by_cases h2 : load ends a U (ends e).2 ω ≤ 1 + ε <;>
      simp [hu, hv, h1, h2, bad] <;>
      nlinarith
  have hs := Finset.sum_le_sum (fun ω (_ : ω ∈ Finset.univ) =>
    mul_le_mul_of_nonneg_left (hpoint ω) (hμ ω))
  change finiteMean μ (fun ω => a e / (1 + ε) *
    (U (ends e).1 ω * U (ends e).2 ω - bad (ends e).1 ω - bad (ends e).2 ω)) ≤ _ at hs
  rw [finiteMean_const_mul, finiteMean_sub, finiteMean_sub, hq] at hs
  have hbase : a e / (1 + ε) * (q - 2 * C) ≤
      finiteMean μ (fun ω => altered ends a U ε ω e) := by
    apply le_trans _ hs
    apply mul_le_mul_of_nonneg_left _ had
    linarith [hbad (ends e).1, hbad (ends e).2]
  have hratio : 2 * C ≤ q * (2 * C / qmin) := by
    calc
      2 * C = qmin * (2 * C / qmin) := by field_simp
      _ ≤ q * (2 * C / qmin) :=
        mul_le_mul_of_nonneg_right hqlower (div_nonneg (by linarith) hqmin.le)
  have hshape : q * (1 - 2 * C / qmin) ≤ q - 2 * C := by nlinarith
  have hscaled := mul_le_mul_of_nonneg_left hshape had
  apply le_trans _ (hscaled.trans hbase)
  apply le_of_eq
  rw [← hx]
  dsimp [C]
  field_simp

end

end SubmodularMatching.TwoStage
