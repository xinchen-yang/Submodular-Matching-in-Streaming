import SubmodularMatching.NonmonotoneActionScoreQueries

/-! # Objective value under finite-precision marginal decoding -/

namespace SubmodularMatching.NonmonotoneOptimizer
open Streaming
variable {E : Type*} [DecidableEq E]

/-- A signed perturbation of Bernoulli coordinates for a function bounded on
subsets of the actual labels. Each vector dominates its coordinatewise minimum. -/
theorem product_uniform_error (e : ℕ → E) (q r : ℕ → ℝ) (n : ℕ) (F : Finset E → ℝ)
    (H ε : ℝ) (hH : 0 ≤ H)
    (hq : ∀ j<n, 0 ≤ q j ∧ q j ≤ 1) (hr : ∀ j<n, 0 ≤ r j ∧ r j ≤ 1)
    (hed : ∀ j<n, |q j-r j| ≤ ε)
    (hf : ∀ A ⊆ (Finset.range n).image e, 0 ≤ F A ∧ F A ≤ H) :
    |bernoulliExpectation e q F n-bernoulliExpectation e r F n| ≤ 2*n*ε*H := by
  let G := (Finset.range n).image e
  let C := fun A => F (A∩G)
  let lo := fun j => min (q j) (r j)
  have hC : ∀ A, 0 ≤ C A ∧ C A ≤ H := fun A => hf _ Finset.inter_subset_right
  have heq (s : ℕ → ℝ) : bernoulliExpectation e s C n = bernoulliExpectation e s F n :=
    product_restrict_support _ _ _ _ (fun j hj => Finset.mem_image_of_mem _ (Finset.mem_range.mpr hj)) _
  have hlo (j : ℕ) (hj : j<n) : 0 ≤ lo j := le_min (hq j hj).1 (hr j hj).1
  have left := bernoulliExpectation_probability_gap e lo q C n H ε hH (fun j hj => by
    refine ⟨hlo j hj,min_le_left _ _,(hq j hj).2,?_⟩
    dsimp only [lo]
    rcases le_total (q j) (r j) with h | h
    · rw [min_eq_left h,sub_self]; exact (abs_nonneg _).trans (hed j hj)
    · rw [min_eq_right h]; exact (le_abs_self _).trans (hed j hj)) hC
  have right := bernoulliExpectation_probability_gap e lo r C n H ε hH (fun j hj => by
    refine ⟨hlo j hj,min_le_right _ _,(hr j hj).2,?_⟩
    dsimp only [lo]
    rcases le_total (q j) (r j) with h | h
    · rw [min_eq_left h]; exact (abs_le.mp (hed j hj)).1 |> fun v => by linarith only [v]
    · rw [min_eq_right h,sub_self]; exact (abs_nonneg _).trans (hed j hj)) hC
  rw [heq,heq] at left right
  rw [abs_sub_comm] at right
  have total := (abs_sub_le (bernoulliExpectation e q F n) (bernoulliExpectation e lo F n)
    (bernoulliExpectation e r F n)).trans (add_le_add left right)
  linarith only [total]

theorem decoded_history_error (h e : ℕ → E) (p q r : ℕ → ℝ) (m n : ℕ)
    (F : Finset E → ℝ) (τ ε : ℝ) (ht : 0 < τ) (hε : 0 ≤ ε)
    (hf : IsSubmodular F) (hn : ∀ A, 0 ≤ F A) (h0 : F ∅ ≤ τ)
    (hs : ∀ j<m, F {h j} ≤ τ) (he : ∀ j<n, F {e j} ≤ τ)
    (hp : ∀ j<m, 0 ≤ p j ∧ p j ≤ 1) (hq : ∀ j<n, 0 ≤ q j ∧ q j ≤ 1)
    (hr : ∀ j<n, 0 ≤ r j ∧ r j ≤ 1) (herr : ∀ j<n, |q j-r j| ≤ ε) :
    |bernoulliExpectation e q (historyMean h p m (normalized F τ)) n -
      bernoulliExpectation e r (historyMean h p m (normalized F τ)) n| ≤
      2*(m+n:ℕ)*ε*((m+n:ℕ)+1:ℝ) := by
  rw [← concat_expectation,← concat_expectation]
  apply product_uniform_error _ _ _ _ _ _ ε (by positivity)
  · exact (concatQuery h e p q m n F hp hq).unitProb
  · exact (concatQuery h e p r m n F hp hr).unitProb
  · intro j hj
    unfold concatCoordinates
    split_ifs with H
    · simpa using hε
    · exact herr _ (by omega)
  · apply normalized_value_range F hf hn _ _ τ ht h0
    intro j hj
    unfold concatCoordinates
    split_ifs with H
    · exact hs _ H
    · exact he _ (by omega)

def decodeSteps (N : ℕ) := 3 * paperExponent N + 1
def decodeBits (N cap : ℕ) := 3 * paperExponent N + 2 * Nat.clog 2 (cap+1) + 2

theorem decode_precision (N cap : ℕ) (mass : ℝ) (hm : mass ≤ 1) :
    mass/2^(decodeSteps N) + 2*(cap:ℝ)^2/2^(decodeBits N cap) ≤ 1/(paperScale N:ℝ)^3 := by
  let P : ℝ := paperScale N
  let c : ℝ := 2^(Nat.clog 2 (cap+1))
  have hp : 0 < P := by dsimp [P,paperScale,scale]; positivity
  have hc : 0 < c := by dsimp [c]; positivity
  have hcap : (cap:ℝ) ≤ c := by
    dsimp [c]; exact_mod_cast (Nat.le_succ cap).trans (Nat.le_pow_clog (by decide : 1 < 2) (cap+1))
  have hs : (2:ℝ)^decodeSteps N = P^3*2 := by
    simp [decodeSteps,P,paperScale,scale,pow_add,pow_mul,mul_comm]
    rw [← pow_mul, ← pow_mul, Nat.mul_comm 3]
  have hb : (2:ℝ)^decodeBits N cap = P^3*c^2*4 := by
    dsimp [decodeBits,P,paperScale,scale,c]
    push_cast; rw [pow_add,pow_add,Nat.mul_comm 3 _,pow_mul,Nat.mul_comm 2 _,pow_mul]; norm_num
  rw [hs,hb]
  change _ ≤ 1/P^3
  have h2 := pow_le_pow_left₀ (Nat.cast_nonneg cap : (0:ℝ) ≤ cap) hcap 2
  have hM := mul_le_mul_of_nonneg_right hm (sq_nonneg c)
  field_simp [hp.ne',hc.ne']
  nlinarith only [hM,h2]

theorem decoded_loss_size (m n N : ℕ) (hm : m ≤ n) (hN : N = n+n)
    (ε : ℝ) (he : ε ≤ 1/(paperScale N:ℝ)^3) :
    2*(m+n:ℕ)*ε*((m+n:ℕ)+1:ℝ) ≤ 2/(paperScale N:ℝ) := by
  let P : ℝ := paperScale N
  have hp : 0 < P := by dsimp [P,paperScale,scale]; positivity
  have hn : ((m+n:ℕ):ℝ)+1 ≤ P := by
    dsimp only [P]
    exact_mod_cast (show m+n+1 ≤ paperScale N from (show m+n+1 ≤ N+1 by omega).trans (paperScale_bounds N).2.1)
  have h0 : (0:ℝ) ≤ (m+n:ℕ) := by positivity
  have hmul : ((m+n:ℕ):ℝ)*(((m+n:ℕ):ℝ)+1) ≤ P^2 := by
    rw [pow_two]; exact mul_le_mul (by linarith only [hn]) hn (by positivity) hp.le
  change ε ≤ 1/P^3 at he
  have H := mul_le_mul_of_nonneg_right he (by positivity : (0:ℝ) ≤ ((m+n:ℕ):ℝ)*(((m+n:ℕ):ℝ)+1))
  have H' := mul_le_mul_of_nonneg_left hmul (by positivity : (0:ℝ) ≤ 1/P^3)
  change _ ≤ 2/P
  have H'' : (1/P^3)*P^2 = 1/P := by field_simp
  have hh := H.trans (H'.trans_eq H'')
  simp only [div_eq_mul_inv] at hh ⊢
  nlinarith only [hh]

end SubmodularMatching.NonmonotoneOptimizer
