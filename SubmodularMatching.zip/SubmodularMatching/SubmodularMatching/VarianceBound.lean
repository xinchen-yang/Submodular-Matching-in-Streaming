import SubmodularMatching.Definitions

/-!
# Algebraic variance estimate in (GM2)--(GM3)

The first theorem bounds a symmetric quadratic form by the absolute row sums
of its matrix. Specializing to the covariance row bound supplied by (GM1)
gives the scalar inequalities used in the paper. This module does not assume
the final variance inequality, and does not claim to prove the separate Gibbs
coupling that supplies the covariance row bound.
-/

namespace SubmodularMatching.VarianceBound

open scoped BigOperators

variable {V : Type*} [Fintype V]

/-- The finite quadratic form associated with a real matrix. -/
noncomputable def quadraticForm (C : V → V → ℝ) (c : V → ℝ) : ℝ :=
  ∑ u, ∑ v, c u * c v * C u v

theorem two_abs_mul_le_sq_add_sq (x y : ℝ) :
    2 * |x * y| ≤ x ^ 2 + y ^ 2 := by
  rw [abs_mul]
  nlinarith [sq_nonneg (|x| - |y|), sq_abs x, sq_abs y]

/-- Symmetry turns the two square terms in the pairwise estimate into one
sum over absolute matrix rows. The coefficient vector may have either sign. -/
theorem quadraticForm_le_absolute_rows
    (C : V → V → ℝ) (c : V → ℝ) (hsymm : ∀ u v, C u v = C v u) :
    quadraticForm C c ≤ ∑ u, c u ^ 2 * ∑ v, |C u v| := by
  have hpoint (u v : V) :
      2 * (c u * c v * C u v) ≤ (c u ^ 2 + c v ^ 2) * |C u v| := by
    have h1 := le_abs_self (c u * c v * C u v)
    rw [abs_mul] at h1
    have h2 := mul_le_mul_of_nonneg_right
      (two_abs_mul_le_sq_add_sq (c u) (c v)) (abs_nonneg (C u v))
    nlinarith
  have htranspose : (∑ u, ∑ v, c v ^ 2 * |C u v|) =
      ∑ u, ∑ v, c u ^ 2 * |C u v| := by
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro u _
    apply Finset.sum_congr rfl
    intro v _
    rw [hsymm v u]
  have hrows : (∑ u, ∑ v, c u ^ 2 * |C u v|) =
      ∑ u, c u ^ 2 * ∑ v, |C u v| := by
    simp_rw [← Finset.mul_sum]
  have hbound : 2 * quadraticForm C c ≤
      2 * (∑ u, c u ^ 2 * ∑ v, |C u v|) := by
    calc
      2 * quadraticForm C c = ∑ u, ∑ v, 2 * (c u * c v * C u v) := by
        simp only [quadraticForm, Finset.mul_sum]
      _ ≤ ∑ u, ∑ v, (c u ^ 2 + c v ^ 2) * |C u v| :=
        Finset.sum_le_sum fun u _ => Finset.sum_le_sum fun v _ => hpoint u v
      _ = 2 * (∑ u, c u ^ 2 * ∑ v, |C u v|) := by
        simp_rw [add_mul, Finset.sum_add_distrib]
        rw [htranspose, hrows]
        ring
  linarith

/-- A symmetric matrix's absolute-row bound controls its quadratic form. -/
theorem quadraticForm_le_row_bound
    (C : V → V → ℝ) (c rowBound : V → ℝ)
    (hsymm : ∀ u v, C u v = C v u)
    (hrow : ∀ u, (∑ v, |C u v|) ≤ rowBound u) :
    quadraticForm C c ≤ ∑ u, c u ^ 2 * rowBound u := by
  exact (quadraticForm_le_absolute_rows C c hsymm).trans
    (Finset.sum_le_sum fun u _ => mul_le_mul_of_nonneg_left (hrow u) (sq_nonneg (c u)))

/-- The quadratic-form implication (GM1) -> (GM2). For an actual covariance
matrix, the quadratic form is the variance of the weighted sum. -/
theorem covariance_row_bound
    (C : V → V → ℝ) (c a : V → ℝ)
    (hsymm : ∀ u v, C u v = C v u)
    (hrow : ∀ u, (∑ v, |C u v|) ≤ 2 * a u * (1 - a u)) :
    quadraticForm C c ≤ 2 * ∑ u, c u ^ 2 * a u * (1 - a u) := by
  calc
    quadraticForm C c ≤ ∑ u, c u ^ 2 * (2 * a u * (1 - a u)) :=
      quadraticForm_le_row_bound C c _ hsymm hrow
    _ = 2 * ∑ u, c u ^ 2 * a u * (1 - a u) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro u _
      ring

/-- Bounded nonnegative coefficients turn (GM2) into the first bound in (GM3). -/
theorem variance_le_twice_cap_mean
    (C : V → V → ℝ) (c a : V → ℝ) (h : ℝ)
    (hsymm : ∀ u v, C u v = C v u)
    (hrow : ∀ u, (∑ v, |C u v|) ≤ 2 * a u * (1 - a u))
    (hc : ∀ u, 0 ≤ c u ∧ c u ≤ h) (ha : ∀ u, 0 ≤ a u ∧ a u ≤ 1) :
    quadraticForm C c ≤ 2 * h * ∑ u, c u * a u := by
  have hpoint (u : V) : c u ^ 2 * a u * (1 - a u) ≤ h * (c u * a u) := by
    have hdrop := mul_le_mul_of_nonneg_left (sub_le_self (1 : ℝ) (ha u).1)
      (mul_nonneg (sq_nonneg (c u)) (ha u).1)
    have hsq := mul_le_mul_of_nonneg_right (hc u).2 (hc u).1
    have hscale := mul_le_mul_of_nonneg_right hsq (ha u).1
    nlinarith
  have hs := Finset.sum_le_sum fun u (_ : u ∈ Finset.univ) => hpoint u
  rw [← Finset.mul_sum] at hs
  have hvar := covariance_row_bound C c a hsymm hrow
  linarith

/-- The normalized variance inequality in the second half of (GM3). -/
theorem normalized_variance_le_half_cap
    (C : V → V → ℝ) (c a : V → ℝ) (h : ℝ) (hh : 0 ≤ h)
    (hsymm : ∀ u v, C u v = C v u)
    (hrow : ∀ u, (∑ v, |C u v|) ≤ 2 * a u * (1 - a u))
    (hc : ∀ u, 0 ≤ c u ∧ c u ≤ h) (ha : ∀ u, 0 ≤ a u ∧ a u ≤ 1) :
    quadraticForm C c / (1 + ∑ u, c u * a u) ^ 2 ≤ h / 2 := by
  have hmean : 0 ≤ ∑ u, c u * a u :=
    Finset.sum_nonneg fun u _ => mul_nonneg (hc u).1 (ha u).1
  have hd : 0 < (1 + ∑ u, c u * a u) ^ 2 := by positivity
  apply (div_le_iff₀ hd).mpr
  have hvar := variance_le_twice_cap_mean C c a h hsymm hrow hc ha
  have hsquare := mul_nonneg hh (sq_nonneg ((∑ u, c u * a u) - 1))
  nlinarith

section FiniteProbability

variable {Ω : Type*} [Fintype Ω]

/-- Expectation under an explicit finite law. -/
noncomputable def finiteMean (mass : Ω → ℝ) (X : Ω → ℝ) : ℝ :=
  ∑ ω, mass ω * X ω

/-- Variance of a finite real random variable. The probability-law hypotheses
are needed by applications; the expansion below is an algebraic identity. -/
noncomputable def finiteVariance (mass : Ω → ℝ) (X : Ω → ℝ) : ℝ :=
  finiteMean mass (fun ω => (X ω - finiteMean mass X) ^ 2)

/-- Covariance matrix of a finite family of real random variables. -/
noncomputable def finiteCovariance (mass : Ω → ℝ) (X : V → Ω → ℝ) (u v : V) : ℝ :=
  finiteMean mass (fun ω =>
    (X u ω - finiteMean mass (X u)) * (X v ω - finiteMean mass (X v)))

omit [Fintype V] in
theorem finiteCovariance_symmetric (mass : Ω → ℝ) (X : V → Ω → ℝ) :
    ∀ u v, finiteCovariance mass X u v = finiteCovariance mass X v u := by
  intro u v
  unfold finiteCovariance finiteMean
  apply Finset.sum_congr rfl
  intro ω _
  ring

theorem finiteMean_weighted_sum
    (mass : Ω → ℝ) (X : V → Ω → ℝ) (c : V → ℝ) :
    finiteMean mass (fun ω => ∑ v, c v * X v ω) =
      ∑ v, c v * finiteMean mass (X v) := by
  unfold finiteMean
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro v _
  apply Finset.sum_congr rfl
  intro ω _
  ring

/-- Variance of a finite linear combination is the covariance quadratic form.
This connects the matrix estimate above to the probabilistic quantity in GM2. -/
theorem finiteVariance_eq_quadraticForm
    (mass : Ω → ℝ) (X : V → Ω → ℝ) (c : V → ℝ) :
    finiteVariance mass (fun ω => ∑ v, c v * X v ω) =
      quadraticForm (finiteCovariance mass X) c := by
  have hcenter (ω : Ω) :
      (∑ v, c v * X v ω) - finiteMean mass (fun t => ∑ v, c v * X v t) =
        ∑ v, c v * (X v ω - finiteMean mass (X v)) := by
    rw [finiteMean_weighted_sum, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro v _
    ring
  change (∑ ω, mass ω * ((∑ v, c v * X v ω) -
    finiteMean mass (fun t => ∑ v, c v * X v t)) ^ 2) = _
  simp_rw [hcenter]
  calc
    (∑ ω, mass ω * (∑ v, c v * (X v ω - finiteMean mass (X v))) ^ 2) =
        ∑ ω, ∑ u, ∑ v, c u * c v *
          (mass ω * (X u ω - finiteMean mass (X u)) *
            (X v ω - finiteMean mass (X v))) := by
      simp_rw [pow_two, Finset.sum_mul, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro ω _
      apply Finset.sum_congr rfl
      intro u _
      apply Finset.sum_congr rfl
      intro v _
      ring
    _ = ∑ u, ∑ v, ∑ ω, c u * c v *
        (mass ω * (X u ω - finiteMean mass (X u)) *
          (X v ω - finiteMean mass (X v))) := by
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro u _
      rw [Finset.sum_comm]
    _ = quadraticForm (finiteCovariance mass X) c := by
      unfold quadraticForm finiteCovariance finiteMean
      simp_rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro u _
      apply Finset.sum_congr rfl
      intro v _
      apply Finset.sum_congr rfl
      intro ω _
      ring

/-- Actual finite variance bound, conditional only on the preceding covariance
row estimate. In the paper that row estimate is obtained from Gibbs coupling. -/
theorem finite_variance_bound
    (mass : Ω → ℝ) (X : V → Ω → ℝ) (c a : V → ℝ)
    (hrow : ∀ u, (∑ v, |finiteCovariance mass X u v|) ≤ 2 * a u * (1 - a u)) :
    finiteVariance mass (fun ω => ∑ v, c v * X v ω) ≤
      2 * ∑ u, c u ^ 2 * a u * (1 - a u) := by
  rw [finiteVariance_eq_quadraticForm]
  exact covariance_row_bound (finiteCovariance mass X) c a
    (finiteCovariance_symmetric mass X) hrow

end FiniteProbability

end SubmodularMatching.VarianceBound
