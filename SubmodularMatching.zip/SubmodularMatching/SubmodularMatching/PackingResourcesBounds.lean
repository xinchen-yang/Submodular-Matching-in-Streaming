import SubmodularMatching.PackingResourcesMachine

/-!
# Numerator widths of the finite packing machine

For positive integer rational accuracy parameters, the machine's working
arrays and output grid are bounded by explicit polynomials. Their binary
widths therefore grow logarithmically with the size bounds.
-/

namespace SubmodularMatching.LinearPacking

noncomputable section

/-- Explicit polynomial caps for the integral radius and iteration count. -/
theorem rational_iteration_resources (M N a b : ℕ)
    (hM : 0 < M) (hN : 0 < N) (ha : 0 < a) (hb : 0 < b) (hab : a ≤ b) :
    let epsilon := (a : ℝ) / b
    Nat.ceil (4 * (N : ℝ) ^ 2 / epsilon) ≤ 5 * N ^ 2 * b ∧
    iterationCount M N epsilon ≤ 100 * M ^ 2 * N ^ 6 * b ^ 4 + 1 ∧
    rationalOutputDenominator M N a b ≤
      (100 * M ^ 2 * N ^ 6 * b ^ 4 + 1) * (2 * N * b + b) := by
  intro epsilon
  have ha' : (0 : ℝ) < a := by exact_mod_cast ha
  have hb' : (0 : ℝ) < b := by exact_mod_cast hb
  have hN' : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hN2 : (1 : ℝ) ≤ (N : ℝ) ^ 2 := one_le_pow₀ hN'
  have ha1 : (1 : ℝ) ≤ a := by exact_mod_cast ha
  have hb1 : (1 : ℝ) ≤ b := by exact_mod_cast hb
  have he : 0 < epsilon := div_pos ha' hb'
  have he1 : epsilon ≤ 1 := (div_le_one hb').mpr (by exact_mod_cast hab)
  have hInv : 1 / epsilon ≤ b := by
    apply (div_le_iff₀ he).mpr
    change 1 ≤ (b : ℝ) * ((a : ℝ) / b)
    rw [mul_comm, div_mul_cancel₀ _ hb'.ne']
    exact ha1
  have hR : Nat.ceil (4 * (N : ℝ) ^ 2 / epsilon) ≤ 5 * N ^ 2 * b := by
    apply Nat.ceil_le.mpr
    push_cast
    have h := mul_le_mul_of_nonneg_left hInv (by positivity : 0 ≤ 4 * (N : ℝ) ^ 2)
    rw [mul_one_div] at h
    have hExtra : (1 : ℝ) ≤ (N : ℝ) ^ 2 * b := one_le_mul_of_one_le_of_one_le hN2 hb1
    linarith only [h, hExtra]
  have hJreal := iterationCount_polynomial M N epsilon hM hN he he1
  have hInv4 := pow_le_pow_left₀ (by positivity) hInv 4
  have hJreal' : (iterationCount M N epsilon : ℝ) ≤ 100 * (M : ℝ) ^ 2 * (N : ℝ) ^ 6 * (b : ℝ) ^ 4 + 1 := by
    have h := mul_le_mul_of_nonneg_left hInv4
      (by positivity : (0 : ℝ) ≤ 100 * (M : ℝ) ^ 2 * (N : ℝ) ^ 6)
    rw [div_pow, one_pow, mul_one_div] at h
    linarith
  have hJ : iterationCount M N epsilon ≤ 100 * M ^ 2 * N ^ 6 * b ^ 4 + 1 := by exact_mod_cast hJreal'
  refine ⟨hR, hJ, ?_⟩
  unfold rationalOutputDenominator
  exact Nat.mul_le_mul hJ (Nat.add_le_add_left hab _)

variable {Row Col : Type*} [Fintype Row] [Fintype Col]

/-- Width of both persistent arrays, measured in bits for the nonnegative
stored numerators. Only one value for each row and column is retained. -/
theorem integerRun_working_width (A : Row → Col → ℤ) (c : Col → ℤ)
    (P Q C R a j : ℕ) (hP : 0 < P) (hQ : 0 < Q) (hC : 0 < C) :
    let state := integerRun A c Q P C R a j
    (∀ h, 0 ≤ state.dual h ∧ (state.dual h).natAbs < 2 ^ ((P * R).log2 + 1)) ∧
    ∀ i, state.accumulator i < 2 ^ (j.log2 + 1) := by
  intro state
  let A' := fun h i => (A h i : ℝ) / Q
  let c' := fun i => (c i : ℝ) / C
  let η := (a : ℝ) * Q / P
  have h := integerRun_eq A c P Q C R a hP hQ hC j
  have hP' : (0 : ℝ) < P := by exact_mod_cast hP
  constructor
  · intro row
    have he : (state.dual row : ℝ) / P = dual A' c' R η j row := h.1 row
    have hb := dual_bounds A' c' (eta := η) (Nat.cast_nonneg R) j row
    rw [← he] at hb
    have hlo := (le_div_iff₀ hP').mp hb.1
    have hhi := (div_le_iff₀ hP').mp hb.2
    have hlo' : 0 ≤ state.dual row := by exact_mod_cast (show (0 : ℝ) ≤ (state.dual row : ℝ) by simpa using hlo)
    have hhi' : state.dual row ≤ (P * R : ℕ) := by
      exact_mod_cast (show (state.dual row : ℝ) ≤ (P : ℝ) * R by simpa only [mul_comm] using hhi)
    refine ⟨hlo', ?_⟩
    have hnat : (state.dual row).natAbs ≤ P * R := by
      have hh := Int.natAbs_of_nonneg hlo'
      exact_mod_cast (show ((state.dual row).natAbs : ℤ) ≤ (P * R : ℕ) from hh ▸ hhi')
    exact hnat.trans_lt Nat.lt_log2_self
  · intro i
    obtain ⟨b, hb, he⟩ := accumulated_action_numerator A' c' R η j i
    have hs : (state.accumulator i : ℝ) = b := (h.2 i).trans he
    have hs' : state.accumulator i = b := by exact_mod_cast hs
    rw [hs']
    exact hb.trans_lt Nat.lt_log2_self

end

end SubmodularMatching.LinearPacking
