import Mathlib.Algebra.Order.Field.Rat
import Mathlib.Data.List.Pairwise
import Mathlib.Tactic.Linarith

/-!
# An executable exact-rational row checker

The horizontal knots are processed in decreasing order. For each row, the
admissible vertical coordinates are a prefix of the ascending vertical
knots. A single scan maintains the smallest term in the prefix so far. Once
a vertical knot has been processed, it does not have to be scanned again.
-/

namespace SubmodularMatching.SourceCertificate

/-- Consume the affordable vertical knots of a sorted list, retaining the
smallest term encountered and the as yet unread suffix. -/
def consumeRowPrefix (term : ℚ → ℚ) (cut : ℚ) : ℚ → List ℚ → ℚ × List ℚ
  | carry, [] => (carry, [])
  | carry, d :: ds =>
    if d ≤ cut then consumeRowPrefix term cut (min carry (term d)) ds
    else (carry, d :: ds)

theorem consumeRowPrefix_carry_le (term : ℚ → ℚ) (cut carry : ℚ) (ds : List ℚ) :
    (consumeRowPrefix term cut carry ds).1 ≤ carry := by
  induction ds generalizing carry with
  | nil => exact le_rfl
  | cons d ds ih =>
    simp only [consumeRowPrefix]
    split
    · exact (ih _).trans (min_le_left _ _)
    · exact le_rfl

theorem consumeRowPrefix_suffix (term : ℚ → ℚ) (cut carry : ℚ) (ds : List ℚ) :
    List.Sublist (consumeRowPrefix term cut carry ds).2 ds := by
  induction ds generalizing carry with
  | nil => exact .slnil
  | cons d ds ih =>
    simp only [consumeRowPrefix]
    split
    · exact (ih _).cons _
    · exact List.Sublist.refl _

theorem consumeRowPrefix_processed (term : ℚ → ℚ) (cut carry : ℚ) (ds : List ℚ)
    (d : ℚ) (hd : d ∈ ds) :
    d ∈ (consumeRowPrefix term cut carry ds).2 ∨
      (consumeRowPrefix term cut carry ds).1 ≤ term d := by
  induction ds generalizing carry with
  | nil => simp at hd
  | cons x xs ih =>
    simp only [consumeRowPrefix]
    split
    · rcases List.mem_cons.mp hd with (rfl | hmem)
      · exact Or.inr ((consumeRowPrefix_carry_le _ _ _ _).trans (min_le_right _ _))
      · exact ih _ hmem
    · exact Or.inl hd

theorem consumeRowPrefix_outside (term : ℚ → ℚ) (cut carry : ℚ) (ds : List ℚ)
    (hs : ds.Pairwise (· ≤ ·)) (d : ℚ) (hd : d ∈ (consumeRowPrefix term cut carry ds).2) :
    cut < d := by
  induction ds generalizing carry with
  | nil => simp [consumeRowPrefix] at hd
  | cons x xs ih =>
    rw [consumeRowPrefix] at hd
    split at hd
    · exact ih _ (List.pairwise_cons.mp hs).2 hd
    · rcases List.mem_cons.mp hd with (rfl | hmem)
      · exact lt_of_not_ge (by assumption)
      · exact (lt_of_not_ge (by assumption : ¬x ≤ cut)).trans_le
          ((List.pairwise_cons.mp hs).1 d hmem)

/-- One check per horizontal knot suffices. When the horizontal knots
are decreasing and the vertical knots increasing, each admissible prefix
contains the prefix from the preceding row. -/
def checkRationalRows (rowValue columnTerm cut : ℚ → ℚ) (target : ℚ) :
    List ℚ → ℚ → List ℚ → Bool
  | [], _, _ => true
  | a :: as, carry, source =>
    let next := consumeRowPrefix columnTerm (cut a) carry source
    decide (target ≤ rowValue a + next.1) &&
      checkRationalRows rowValue columnTerm cut target as next.1 next.2

/-- Independent of the order of the rows, every successful row check
implies the desired inequality for all of its admissible columns.
The order above makes each prefix minimum exact as well as sound. -/
theorem checkRationalRows_sound (rowValue columnTerm cut : ℚ → ℚ) (target : ℚ)
    (as allColumns : List ℚ) (carry : ℚ) (columns : List ℚ)
    (hs : columns.Pairwise (· ≤ ·))
    (hseen : ∀ d ∈ allColumns, d ∈ columns ∨ carry ≤ columnTerm d)
    (hcheck : checkRationalRows rowValue columnTerm cut target as carry columns = true)
    (a d : ℚ) (ha : a ∈ as) (hd : d ∈ allColumns) (hcap : d ≤ cut a) :
    target ≤ rowValue a + columnTerm d := by
  induction as generalizing carry columns with
  | nil => simp at ha
  | cons x xs ih =>
    rw [checkRationalRows, Bool.and_eq_true, decide_eq_true_eq] at hcheck
    let next := consumeRowPrefix columnTerm (cut x) carry columns
    have hcarry := consumeRowPrefix_carry_le columnTerm (cut x) carry columns
    have hseen' (y : ℚ) (hy : y ∈ allColumns) : y ∈ next.2 ∨ next.1 ≤ columnTerm y := by
      rcases hseen y hy with h | h
      · exact consumeRowPrefix_processed _ _ _ _ _ h
      · exact Or.inr (hcarry.trans h)
    rcases List.mem_cons.mp ha with (rfl | hamem)
    · rcases hseen' d hd with hin | hin
      · exact False.elim ((not_lt_of_ge hcap)
          (consumeRowPrefix_outside _ _ _ _ hs d hin))
      · exact hcheck.1.trans (add_le_add le_rfl hin)
    · exact ih next.1 next.2
        (hs.sublist (consumeRowPrefix_suffix _ _ _ _)) hseen' hcheck.2 hamem

theorem rational_grid_row_checks (U V : ℚ → ℚ) (xs ys : List ℚ) (q c target : ℚ)
    (hc : c < 1) (hordered : ys.Pairwise (· ≤ ·))
    (hcheck : checkRationalRows (fun a => U a - q * c * a + q)
      (fun d => V d - q * (1 - c) * d) (fun a => (1 - c * a) / (1 - c))
      target xs (V 0) ys = true)
    (a d : ℚ) (ha : a ∈ xs) (hd : d ∈ ys) (hcap : c * a + (1 - c) * d ≤ 1) :
    target ≤ U a + V d + q * (1 - c * a - (1 - c) * d) := by
  have hbelow : d ≤ (1 - c * a) / (1 - c) := (le_div_iff₀ (sub_pos.mpr hc)).2 (by
    linarith only [hcap])
  have h := checkRationalRows_sound _ _ _ _ xs ys (V 0) ys hordered
    (fun _ h => Or.inl h) hcheck a d ha hd hbelow
  linarith only [h]

end SubmodularMatching.SourceCertificate
