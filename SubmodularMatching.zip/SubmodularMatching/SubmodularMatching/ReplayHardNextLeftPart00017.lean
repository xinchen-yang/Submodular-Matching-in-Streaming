import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextLeft

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step87 : ProjectedGoal ⟨216, 431, 283, 567, 567, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0xd7ff0000000000000002400f) (by decide +kernel)

theorem Part00017 : ProjectedGoal ⟨216, 431, 283, 567, 567, 1135⟩ := step87

end SubmodularMatching.SourceCertificate.Replay.HardNextLeft
