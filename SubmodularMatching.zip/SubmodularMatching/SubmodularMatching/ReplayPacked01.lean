import SubmodularMatching.ReplaySupportedPartition
import SubmodularMatching.ReplayQuickRate
import SubmodularMatching.CertificateRateRunRegion
import SubmodularMatching.CertificateConeLiterals

namespace SubmodularMatching.SourceCertificate.Replay.Packed01

set_option maxRecDepth 4000
set_option maxHeartbeats 8000000

def ClassGoal (box : PriceBox) : Prop :=
  (∀ z < 2^32, (runRegion quickRow z).Valid) →
  (∀ z < 72, (appendixFastConeAt z).Sufficient) → AppendixBoxGoal false true box

private theorem chunk0 : ClassGoal ⟨0, 27647, 0, 567, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 19 0x1c33c33ccf 0x300faeaddc9e0000000eaeaddc9e0000000daeaddc9e0000000caeaddc9e0000000baeaddc9e0000000aaeaddc9e00000009aeaddc9e00000008aeaddc9e00000007aeaddc9e00000006 (by decide +kernel)
private theorem chunk1 : ClassGoal ⟨27648, 41471, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 5 0x3f 0xaeaddc9e0000000daeaddc9e0000000daeaddc9e0000000e (by decide +kernel)
private theorem chunk2 : ClassGoal ⟨41472, 48383, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 5 0x3f 0xaeaddc9e00000010aeaddc9e00000010aeaddc9e0000000d (by decide +kernel)
private theorem chunk3 : ClassGoal ⟨48384, 51839, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 5 0x3f 0xaeaddc9e00000010aeaddc9e00000010aeaddc9e00000010 (by decide +kernel)
private theorem chunk4 : ClassGoal ⟨51840, 53567, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 9 0xfcf 0xaeaddc9e00000010aeaddc9e00000010aeaddc9e00000010aeaddc9e00000010aeaddc9e00000010 (by decide +kernel)
private theorem chunk5 : ClassGoal ⟨53568, 54431, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 21 0xcc3f0fc3f 0xaeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00013010aeaddc9e00012010aeaddc9e00011010aeaddc9e00000010aeaddc9e00000010aeaddc9e00000010 (by decide +kernel)
private theorem chunk6 : ClassGoal ⟨54432, 54539, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 7 0xff 0xaeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010 (by decide +kernel)
private theorem chunk7 : ClassGoal ⟨54540, 54593, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 15 0xf3c3cf 0xaeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010 (by decide +kernel)
private theorem chunk8 : ClassGoal ⟨54594, 54647, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 13 0x33c3cf 0xaeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010 (by decide +kernel)
private theorem chunk9 : ClassGoal ⟨54648, 54863, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 21 0xcf3c3c3cf 0xaeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010 (by decide +kernel)
private theorem chunk10 : ClassGoal ⟨54864, 55295, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 21 0x3fffccf 0xaeaddc9e00003010aeaddc9e00014010aeaddc9e00014010aeaddc9e00014010aeaddc9e0001400daeaddc9e0001400daeaddc9e0001400daeaddc9e0001400daeaddc9e0001400daeaddc9e0001400daeaddc9e0001400d (by decide +kernel)
private theorem chunk11 : ClassGoal ⟨27648, 55295, 283, 567, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 1 0x3 0x300f (by decide +kernel)
private theorem chunk12 : ClassGoal ⟨0, 27647, 0, 283, 567, 1135⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 11 0xacf3f 0x190150aeaddc9e00170180000000000017015aeaddc9e0001600eaeaddc9e0001600d0000000000004015 (by decide +kernel)
private theorem chunk13 : ClassGoal ⟨27648, 55295, 0, 283, 567, 1135⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 23 0x2b03ebf8bf3f 0x19015aeaddc9e0002300d369654f160023022000000000001f0155756ee4f00021020aeaddc9e0001b00d000000000001f01515d5bb93c001e01d000000000001c015aeaddc9e0001b00eaeaddc9e0001b00eaeaddc9e0001601a (by decide +kernel)
private theorem chunk14 : ClassGoal ⟨0, 55295, 283, 567, 567, 1135⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 1 0x3 0x400f (by decide +kernel)
private theorem chunk15 : ClassGoal ⟨0, 55295, 567, 1135, 0, 1135⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones false true _ 1 0x3 0x5024 (by decide +kernel)
private theorem branch0 : ClassGoal ⟨54540, 54647, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54593 (by decide) (by decide) (chunk7 rates cones) (chunk8 rates cones)
private theorem branch1 : ClassGoal ⟨54432, 54647, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54539 (by decide) (by decide) (chunk6 rates cones) (branch0 rates cones)
private theorem branch2 : ClassGoal ⟨54432, 54863, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54647 (by decide) (by decide) (branch1 rates cones) (chunk9 rates cones)
private theorem branch3 : ClassGoal ⟨54432, 55295, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54863 (by decide) (by decide) (branch2 rates cones) (chunk10 rates cones)
private theorem branch4 : ClassGoal ⟨53568, 55295, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54431 (by decide) (by decide) (chunk5 rates cones) (branch3 rates cones)
private theorem branch5 : ClassGoal ⟨51840, 55295, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 53567 (by decide) (by decide) (chunk4 rates cones) (branch4 rates cones)
private theorem branch6 : ClassGoal ⟨48384, 55295, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 51839 (by decide) (by decide) (chunk3 rates cones) (branch5 rates cones)
private theorem branch7 : ClassGoal ⟨41472, 55295, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 48383 (by decide) (by decide) (chunk2 rates cones) (branch6 rates cones)
private theorem branch8 : ClassGoal ⟨27648, 55295, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 41471 (by decide) (by decide) (chunk1 rates cones) (branch7 rates cones)
private theorem branch9 : ClassGoal ⟨27648, 55295, 0, 567, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 283 (by decide) (by decide) (branch8 rates cones) (chunk11 rates cones)
private theorem branch10 : ClassGoal ⟨0, 55295, 0, 567, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 27647 (by decide) (by decide) (chunk0 rates cones) (branch9 rates cones)
private theorem branch11 : ClassGoal ⟨0, 55295, 0, 283, 567, 1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 27647 (by decide) (by decide) (chunk12 rates cones) (chunk13 rates cones)
private theorem branch12 : ClassGoal ⟨0, 55295, 0, 567, 567, 1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 283 (by decide) (by decide) (branch11 rates cones) (chunk14 rates cones)
private theorem branch13 : ClassGoal ⟨0, 55295, 0, 567, 0, 1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 567 (by decide) (by decide) (branch10 rates cones) (branch12 rates cones)
private theorem branch14 : ClassGoal ⟨0, 55295, 0, 1135, 0, 1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 567 (by decide) (by decide) (branch13 rates cones) (chunk15 rates cones)

theorem checked : ClassGoal appendixPriceRoot := branch14

end SubmodularMatching.SourceCertificate.Replay.Packed01
