import SubmodularMatching.CapacityRationalMatrix

/-! # Decoding normalized packing states to the physical constraints (23) -/

namespace SubmodularMatching.Capacity
open Finset
open scoped BigOperators
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

theorem slotLoad_scale (ends : E → V × V) (cap : V → ℕ) (u : E → ℝ) (d : ℝ) (v : V) :
    slotLoad ends cap (fun e => d*u e) v = d*slotLoad ends cap u v := by
  unfold slotLoad
  rw [mul_sum]
  apply sum_congr rfl
  intro e _
  ring

structure PhysicalAction (ends : E → V × V) (cap : V → ℕ) (pair : E → BSlot cap × BSlot cap)
    (p d Av Bv Ae Be : ℝ) (x Y : E → ℝ) : Prop where
  x_nonnegative : ∀ e, 0 ≤ x e
  y_bounded : ∀ e, 0 ≤ Y e ∧ Y e ≤ d
  degree : ∀ v, slotLoad ends cap Y v ≤ d
  shared : ∀ i, Joint.degree pair x i + Bv*slotLoad ends cap Y i.1 ≤ Av
  edge : ∀ e, x e/p + Be*(slotLoad ends cap Y (ends e).1 + slotLoad ends cap Y (ends e).2) ≤ Ae

theorem physicalAction_of_rows (ends : E → V × V) (cap : V → ℕ) (pair : E → BSlot cap × BSlot cap)
    (p d Av Bv Ae Be : ℝ) (hp : 0 < p) (hd : 0 ≤ d) (hA : 0 < Av) (hE : 0 < Ae)
    (F u : E → ℝ) (hx : ∀ e, 0 ≤ F e) (hu : ∀ e, 0 ≤ u e ∧ u e ≤ 1)
    (hr : ∀ r, LinearPacking.load (capacityMatrix ends cap pair p d Av Bv Ae Be) (Sum.elim F u) r ≤ 1) :
    PhysicalAction ends cap pair p d Av Bv Ae Be (fun e => p*Ae*F e) (fun e => d*u e) := by
  have h := fun r => (capacityMatrix_load ends cap pair p d Av Bv Ae Be F u r).ge.trans (hr r)
  refine ⟨fun e => mul_nonneg (mul_nonneg hp.le hE.le) (hx e),
    fun e => ⟨mul_nonneg hd (hu e).1,mul_le_of_le_one_right hd (hu e).2⟩,?_,?_,?_⟩
  · intro v
    rw [slotLoad_scale]
    exact mul_le_of_le_one_right hd (h (.inl v))
  · intro i
    rw [slotLoad_scale,Joint.degree_scale]
    have hh : p*Ae/Av*Joint.degree pair F i + Bv*d/Av*slotLoad ends cap u i.1 ≤ 1 := h (.inr (.inl i))
    field_simp [hA.ne'] at hh
    linarith
  · intro e
    rw [slotLoad_scale,slotLoad_scale]
    have hh : F e + Be*d/Ae*(slotLoad ends cap u (ends e).1 + slotLoad ends cap u (ends e).2) ≤ 1 :=
      h (.inr (.inr e))
    have hx' : p*Ae*F e/p = Ae*F e := by field_simp
    rw [hx']
    field_simp [hE.ne'] at hh
    linarith

theorem physicalAction_decrease (ends : E → V × V) (cap : V → ℕ) (pair : E → BSlot cap × BSlot cap)
    (p d Av Bv Ae Be : ℝ) (x y z : E → ℝ) (h : PhysicalAction ends cap pair p d Av Bv Ae Be x y)
    (hz : ∀ e, 0 ≤ z e ∧ z e ≤ y e) (hv : 0 ≤ Bv) (he : 0 ≤ Be) :
    PhysicalAction ends cap pair p d Av Bv Ae Be x z := by
  have hs v : slotLoad ends cap z v ≤ slotLoad ends cap y v :=
    sum_le_sum (fun e _ => mul_le_mul_of_nonneg_left (hz e).2 (slotInc_bounds ends cap v e).1)
  exact ⟨h.x_nonnegative,fun e => ⟨(hz e).1,(hz e).2.trans (h.y_bounded e).2⟩,
    fun v => (hs v).trans (h.degree v),
    fun i => (add_le_add le_rfl (mul_le_mul_of_nonneg_left (hs i.1) hv)).trans (h.shared i),
    fun e => (add_le_add le_rfl (mul_le_mul_of_nonneg_left (add_le_add (hs _) (hs _)) he)).trans (h.edge e)⟩

end
end SubmodularMatching.Capacity
