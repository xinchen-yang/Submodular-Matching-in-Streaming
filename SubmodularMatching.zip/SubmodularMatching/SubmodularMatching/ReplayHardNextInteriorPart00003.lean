import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step33 : ProjectedGoal ⟨513, 516, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x2020201e8d4a51000048049) (.x (.leaf 0x2020201e8d4a5100004804a) (.x (.leaf 0x2020201e8d4a5100004804b) (.x (.x (.leaf 0x2020201e8d4a51000048050) (.x (.y (.y (.leaf 0x2020201e8d4a51000049051) (.y (.leaf 0x2020201e8d4a5100004a051) (.y (.leaf 0x2020201e8d4a5100004b051) (.y (.m (.leaf 0x2010201e8d4a5100004c051) (.leaf 0x2020202e8d4a5100004c051)) (.leaf 0x2020201e8d4a5100004d051))))) (.leaf 0x2020201e8d4a5100004e051)) (.leaf 0x2020201e8d4a51000048052))) (.leaf 0x2020201e8d4a5100004804d))))) (.leaf 0x2020201e8d4a5100004804e)) (.x (.x (.leaf 0x2040203e8d4a51000048049) (.x (.leaf 0x2040203e8d4a5100004804a) (.x (.leaf 0x2040203e8d4a5100004804b) (.x (.x (.leaf 0x2040203e8d4a51000048050) (.x (.y (.y (.leaf 0x2040203e8d4a51000049051) (.y (.leaf 0x2040203e8d4a5100004a051) (.y (.leaf 0x2040203e8d4a5100004b051) (.y (.m (.leaf 0x2030203e8d4a5100004c051) (.leaf 0x2040204e8d4a5100004c051)) (.leaf 0x2040203e8d4a5100004d051))))) (.leaf 0x2040203e8d4a5100004e051)) (.leaf 0x2040203e8d4a51000048052))) (.leaf 0x2040203e8d4a5100004804d))))) (.leaf 0x2040203e8d4a5100004804e))) (by decide +kernel)

private theorem step34 : ProjectedGoal ⟨517, 519, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x2060205e8d4a51000048049) (.x (.leaf 0x2060205e8d4a5100004804a) (.x (.leaf 0x2060205e8d4a5100004804b) (.x (.x (.leaf 0x2060205e8d4a51000048050) (.x (.y (.y (.leaf 0x2060205e8d4a51000049051) (.y (.leaf 0x2060205e8d4a5100004a051) (.y (.leaf 0x2060205e8d4a5100004b051) (.y (.m (.leaf 0x2050205e8d4a5100004c051) (.leaf 0x2060206e8d4a5100004c051)) (.leaf 0x2060205e8d4a5100004d051))))) (.leaf 0x2060205e8d4a5100004e051)) (.leaf 0x2060205e8d4a51000048052))) (.leaf 0x2060205e8d4a5100004804d))))) (.leaf 0x2060205e8d4a5100004804e)) (.leaf 0x2070207e8d4a5100004800a)) (by decide +kernel)

private theorem step35 : ProjectedGoal ⟨513, 519, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 516 (by decide) (by decide) (step33 rates cones) (step34 rates cones)

private theorem step36 : ProjectedGoal ⟨520, 526, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0x2080208e8d4a5100004800a) (.leaf 0x2090209e8d4a5100004800a)) (.m (.leaf 0x20a020ae8d4a5100004800a) (.leaf 0x20b020be8d4a5100004800a))) (.x (.x (.leaf 0x20e020ce8d4a51000048049) (.x (.leaf 0x20e020ce8d4a5100004804a) (.x (.leaf 0x20e020ce8d4a5100004804b) (.x (.x (.leaf 0x20e020ce8d4a51000048050) (.x (.y (.y (.leaf 0x20e020ce8d4a51000049051) (.y (.leaf 0x20e020ce8d4a5100004a051) (.y (.leaf 0x20e020ce8d4a5100004b051) (.y (.m (.m (.leaf 0x20c020ce8d4a5100004c051) (.leaf 0x20d020de8d4a5100004c051)) (.leaf 0x20e020ee8d4a5100004c051)) (.leaf 0x20e020ce8d4a5100004d051))))) (.leaf 0x20e020ce8d4a5100004e051)) (.leaf 0x20e020ce8d4a51000048052))) (.leaf 0x20e020ce8d4a5100004804d))))) (.leaf 0x20e020ce8d4a5100004804e))) (by decide +kernel)

private theorem step37 : ProjectedGoal ⟨513, 526, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 519 (by decide) (by decide) (step35 rates cones) (step36 rates cones)

private theorem step38 : ProjectedGoal ⟨527, 530, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x210020fe8d4a51000048049) (.x (.leaf 0x210020fe8d4a5100004804a) (.x (.leaf 0x210020fe8d4a5100004804b) (.x (.x (.leaf 0x210020fe8d4a51000048050) (.x (.y (.y (.leaf 0x210020fe8d4a51000049051) (.y (.leaf 0x210020fe8d4a5100004a051) (.y (.leaf 0x210020fe8d4a5100004b051) (.y (.m (.leaf 0x20f020fe8d4a5100004c051) (.leaf 0x2100210e8d4a5100004c051)) (.leaf 0x210020fe8d4a5100004d051))))) (.leaf 0x210020fe8d4a5100004e051)) (.leaf 0x210020fe8d4a51000048052))) (.leaf 0x210020fe8d4a5100004804d))))) (.leaf 0x210020fe8d4a5100004804e)) (.x (.x (.leaf 0x2120211e8d4a51000048049) (.x (.leaf 0x2120211e8d4a5100004804a) (.x (.leaf 0x2120211e8d4a5100004804b) (.x (.x (.leaf 0x2120211e8d4a51000048050) (.x (.y (.y (.leaf 0x2120211e8d4a51000049051) (.y (.leaf 0x2120211e8d4a5100004a051) (.y (.leaf 0x2120211e8d4a5100004b051) (.y (.m (.leaf 0x2110211e8d4a5100004c051) (.leaf 0x2120212e8d4a5100004c051)) (.leaf 0x2120211e8d4a5100004d051))))) (.leaf 0x2120211e8d4a5100004e051)) (.leaf 0x2120211e8d4a51000048052))) (.leaf 0x2120211e8d4a5100004804d))))) (.leaf 0x2120211e8d4a5100004804e))) (by decide +kernel)

private theorem step39 : ProjectedGoal ⟨531, 533, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x2140213e8d4a51000048049) (.x (.leaf 0x2140213e8d4a5100004804a) (.x (.leaf 0x2140213e8d4a5100004804b) (.x (.x (.leaf 0x2140213e8d4a51000048050) (.x (.y (.y (.leaf 0x2140213e8d4a51000049051) (.y (.leaf 0x2140213e8d4a5100004a051) (.y (.leaf 0x2140213e8d4a5100004b051) (.y (.m (.leaf 0x2130213e8d4a5100004c051) (.leaf 0x2140214e8d4a5100004c051)) (.leaf 0x2140213e8d4a5100004d051))))) (.leaf 0x2140213e8d4a5100004e051)) (.leaf 0x2140213e8d4a51000048052))) (.leaf 0x2140213e8d4a5100004804d))))) (.leaf 0x2140213e8d4a5100004804e)) (.leaf 0x2150215e8d4a5100004800a)) (by decide +kernel)

private theorem step40 : ProjectedGoal ⟨527, 533, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 530 (by decide) (by decide) (step38 rates cones) (step39 rates cones)

private theorem step41 : ProjectedGoal ⟨534, 536, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.x (.x (.leaf 0x2180216e8d4a51000048049) (.x (.leaf 0x2180216e8d4a5100004804a) (.x (.leaf 0x2180216e8d4a5100004804b) (.x (.x (.leaf 0x2180216e8d4a51000048050) (.x (.y (.y (.leaf 0x2180216e8d4a51000049051) (.y (.leaf 0x2180216e8d4a5100004a051) (.y (.leaf 0x2180216e8d4a5100004b051) (.y (.m (.m (.leaf 0x2160216e8d4a5100004c051) (.leaf 0x2170217e8d4a5100004c051)) (.leaf 0x2180218e8d4a5100004c051)) (.leaf 0x2180216e8d4a5100004d051))))) (.leaf 0x2180216e8d4a5100004e051)) (.leaf 0x2180216e8d4a51000048052))) (.leaf 0x2180216e8d4a5100004804d))))) (.leaf 0x2180216e8d4a5100004804e)) (by decide +kernel)

private theorem step42 : ProjectedGoal ⟨537, 539, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x21a0219e8d4a51000048049) (.x (.leaf 0x21a0219e8d4a5100004804a) (.x (.leaf 0x21a0219e8d4a5100004804b) (.x (.x (.leaf 0x21a0219e8d4a51000048050) (.x (.y (.y (.leaf 0x21a0219e8d4a51000049051) (.y (.leaf 0x21a0219e8d4a5100004a051) (.y (.leaf 0x21a0219e8d4a5100004b051) (.y (.m (.leaf 0x2190219e8d4a5100004c051) (.leaf 0x21a021ae8d4a5100004c051)) (.leaf 0x21a0219e8d4a5100004d051))))) (.leaf 0x21a0219e8d4a5100004e051)) (.leaf 0x21a0219e8d4a51000048052))) (.leaf 0x21a0219e8d4a5100004804d))))) (.leaf 0x21a0219e8d4a5100004804e)) (.leaf 0x21b021be8d4a5100004800a)) (by decide +kernel)

private theorem step43 : ProjectedGoal ⟨534, 539, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 536 (by decide) (by decide) (step41 rates cones) (step42 rates cones)

private theorem step44 : ProjectedGoal ⟨527, 539, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 533 (by decide) (by decide) (step40 rates cones) (step43 rates cones)

private theorem step45 : ProjectedGoal ⟨513, 539, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 526 (by decide) (by decide) (step37 rates cones) (step44 rates cones)

theorem Part00003 : ProjectedGoal ⟨513, 539, 0, 283, 0, 283⟩ := step45

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
