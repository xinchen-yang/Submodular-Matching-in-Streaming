import SubmodularMatching.StreamingSourceTapeSupport
import SubmodularMatching.UpperBoundVertexPeak

/-! # Source and working storage on every supported reference tape -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The simultaneous archive rows, one current postprocessing workspace,
and an incumbent obey the manuscript's quadratic logarithmic cell budget
on every source execution. The observation model allows real values. -/
theorem appendixSourceTape_workspace_le (edges : ℕ → E) (ends : E → V × V)
    (f : Finset E → ℝ) (n arrivals : ℕ) (hn : 2 ≤ n) (ha : arrivals ≤ n ^ 2)
    (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0)
    (k : ℕ) {N : ℕ} (hN : 0 < N) (batches : ℕ → Fin N → ℝ) (allEdges M : Finset E)
    (hin : ∀ i < k, edges i ∈ allEdges)
    (hloop : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet ends) A → A.card ≤ M.card)
    {m : ℕ} (storedEnds : Fin m → V × V) (current : ℕ) :
    let P := appendixScheduledSource edges ends f n arrivals hn ha hf hm hzero
    let hist := P.history batches P.calls.length
    let active := activeGuessIndices P.width (guessAnchor P.width P.value k)
      (singletonMaximum P.value k) P.span
    let len := fun j => (P.snapshot hist k j).stored.card
    batches ∈ (sourceTape P N).outcomes → current ∈ active → m = len current →
      sequentialWorkspace active len
        (sequentialGuessScratch (Fintype.card (IncidentVertex storedEnds)) m) M.card ≤
        (96 * appendixIncidenceConstant * appendixGuessCountConstant +
          8 * appendixGuessCountConstant + 50) * (M.card + 1) * ((n + 1).log2 + 1) ^ 2 := by
  intro P hist active len hb hcur hlen
  have hraw : ∀ i < k, ∀ j r, ∃ A, hist (i, j) r = marginal f (edges i) A := by
    intro i _ j r
    exact sourceTape_history_marginal P N batches hb P.calls.length le_rfl i j r
  exact appendixSourceWorkspace_le edges ends f n arrivals hn ha hf hm hzero k hN hist allEdges M
    hin hloop hMsub hM hmax hraw storedEnds current hcur hlen

end SubmodularMatching.UpperBoundAssembly
