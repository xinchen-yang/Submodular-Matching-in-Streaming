import SubmodularMatching.NonmonotoneChainQueries
import SubmodularMatching.ProjectedShearerLayers
import SubmodularMatching.UpperBoundWordVector

/-! Signed residual and gradient samples from physical random words and the
original value oracle. -/
namespace SubmodularMatching.Streaming.OracleQuery
open MeasureTheory ProbabilityTheory
open scoped BigOperators
noncomputable section
variable {E : Type*} [DecidableEq E]

def extendedProb (Q : OracleQuery E) (i : ℕ) : ℝ := if i<Q.size then Q.prob i else 0

theorem extendedProb_bounds (Q : OracleQuery E) (i : ℕ) :
    0 ≤ Q.extendedProb i ∧ Q.extendedProb i ≤ 1 := by
  unfold extendedProb
  split_ifs with h
  · exact Q.unitProb i h
  · norm_num

private theorem selector_subset (edges : ℕ → E) (words thresholds : ℕ → ℕ) (n : ℕ) :
    selectThresholdWords edges words thresholds n ⊆ (Finset.range n).image edges := by
  induction n with
  | zero => simp [selectThresholdWords]
  | succ n ih =>
    simp only [selectThresholdWords, Finset.range_succ, Finset.image_insert]
    split_ifs
    · exact Finset.insert_subset_insert _ ih
    · exact ih.trans (Finset.subset_insert _ _)

def wordValue (Q : OracleQuery E) (bits : ℕ) (w : Fin Q.size → Fin (2^bits)) : ℝ :=
  Q.evaluate (selectWordVector Q.edges Q.extendedProb Q.size bits w)

theorem word_bias (Q : OracleQuery E) (bits : ℕ) (lo hi : ℝ)
    (hrange : ∀ A ⊆ (Finset.range Q.size).image Q.edges, lo ≤ Q.evaluate A ∧ Q.evaluate A ≤ hi) :
    |Q.target - ∫ w, Q.wordValue bits w ∂wordLaw Q.size bits| ≤
      Q.size * (1/(2:ℝ)^bits) * (hi-lo) := by
  let G := (Finset.range Q.size).image Q.edges
  let H := fun A : Finset E => Q.evaluate (A∩G)-lo
  let bit := fun j => bitProbability (Q.extendedProb j) bits
  have hgap := bernoulliExpectation_probability_gap Q.edges bit Q.extendedProb H Q.size
    (hi-lo) (1/2^bits) (sub_nonneg.mpr ((hrange ∅ (Finset.empty_subset _)).1.trans
      (hrange ∅ (Finset.empty_subset _)).2)) (by
        intro i _
        have h := bitProbability_bounds (Q.extendedProb_bounds i).1 bits
        exact ⟨h.1,h.2.1,(Q.extendedProb_bounds i).2,h.2.2.le⟩) (by
        intro A
        obtain ⟨hl,hu⟩ := hrange (A∩G) Finset.inter_subset_right
        exact ⟨sub_nonneg.mpr hl,sub_le_sub_right hu _⟩)
  have he (p : ℕ → ℝ) : bernoulliExpectation Q.edges p H Q.size =
      bernoulliExpectation Q.edges p Q.evaluate Q.size - lo := by
    dsimp only [H]
    rw [bernoulliExpectation_sub,bernoulliExpectation_const,product_restrict_support]
    exact fun j hj => Finset.mem_image_of_mem _ (Finset.mem_range.mpr hj)
  rw [he,he,sub_sub_sub_cancel_right] at hgap
  unfold wordValue
  rw [selectWordVector_expectation _ _ _ _ Q.extendedProb_bounds]
  unfold target
  rw [NonmonotoneOptimizer.expectation_congr Q.edges Q.prob Q.extendedProb Q.evaluate Q.size
    (fun j hj => by simp [extendedProb,hj])]
  exact hgap

theorem word_batch_failure (Q : OracleQuery E) (N bits : ℕ) (lo hi d : ℝ)
    (hN : 0 < N) (hd : 0 < d)
    (hrange : ∀ A ⊆ (Finset.range Q.size).image Q.edges, lo ≤ Q.evaluate A ∧ Q.evaluate A ≤ hi)
    (hb : Q.size * (1/(2:ℝ)^bits)*(hi-lo) ≤ d/64) :
    (wordBatchLaw N Q.size bits).real {ω | ¬(Q.target-d ≤
      sourceAverage d (fun j => Q.wordValue bits (ω j)) ∧
      sourceAverage d (fun j => Q.wordValue bits (ω j)) ≤ Q.target+d)} ≤
        2 * Real.exp (-(2*N*(d/2)^2)/(hi-lo)^2) := by
  letI : IsProbabilityMeasure (wordLaw Q.size bits) := by unfold wordLaw; infer_instance
  have hmeas : Measurable (Q.wordValue bits) := measurable_of_finite _
  let μ := wordBatchLaw N Q.size bits
  let X := fun j (ω : WordBatch N Q.size bits) => Q.wordValue bits (ω j)
  have hind : iIndepFun X μ := iIndepFun_pi (fun _ => hmeas.aemeasurable)
  apply signed_estimate_failure hind (fun j => hmeas.comp (measurable_pi_apply j))
    lo hi d Q.target _ hd hN
  · intro j
    exact Filter.Eventually.of_forall (fun ω => hrange _ (selector_subset _ _ _ _))
  · intro j
    have hm := (measurePreserving_eval (fun _ : Fin N => wordLaw Q.size bits) j).map_eq
    change Measure.map (fun ω => ω j) μ = wordLaw Q.size bits at hm
    change (∫ ω, Q.wordValue bits (ω j) ∂μ) = _
    rw [← integral_map (measurable_pi_apply j).aemeasurable hmeas.aestronglyMeasurable,hm]
  · exact (Q.word_bias bits lo hi hrange).trans hb

/-- Direct oracle implementation of the residual objective: forming the union
of the residual sample and the iterate sample takes one coin per stored label. -/
def unionQuery (edges : ℕ → E) (n : ℕ) (q p : ℕ → ℝ) (F : Finset E → ℝ)
    (hq : ∀ j < n, 0 ≤ q j ∧ q j ≤ 1) (hp : ∀ j < n, 0 ≤ p j ∧ p j ≤ 1) :
    OracleQuery E where
  edges := edges
  size := n
  prob i := q i + (1-q i)*p i
  unitProb i hi := by
    obtain ⟨ha,hb⟩ := hq i hi
    obtain ⟨hc,hd⟩ := hp i hi
    exact ⟨add_nonneg ha (mul_nonneg (sub_nonneg.mpr hb) hc),
      by nlinarith only [mul_nonneg (sub_nonneg.mpr hb) (sub_nonneg.mpr hd)]⟩
  evaluate := F

theorem unionQuery_target (edges : ℕ → E) (n : ℕ) (q p : ℕ → ℝ) (F : Finset E → ℝ)
    (hq : ∀ j < n, 0 ≤ q j ∧ q j ≤ 1) (hp : ∀ j < n, 0 ≤ p j ∧ p j ≤ 1) :
    (unionQuery edges n q p F hq hp).target =
    bernoulliExpectation edges q (fun A => bernoulliExpectation edges p (fun B => F (A∪B)) n) n :=
  (Shearer.LabelLayer.independent_union edges q p F n).symm

/-- On a signed chain the query evaluates the same two original-oracle values
regardless of the sign of their difference. -/
theorem unionQuery_marginal (edges : ℕ → E) (n : ℕ) (q p : ℕ → ℝ) (f : Finset E → ℝ)
    (e : E) (hq : ∀ j < n, 0 ≤ q j ∧ q j ≤ 1) (hp : ∀ j < n, 0 ≤ p j ∧ p j ≤ 1) :
    (unionQuery edges n q p (marginal f e) hq hp).target = bernoulliExpectation edges q
      (marginal (fun A => bernoulliExpectation edges p (fun B => f (A ∪ B)) n) e) n := by
  rw [unionQuery_target]
  congr 1
  funext A
  unfold marginal
  rw [← bernoulliExpectation_sub]
  congr 1
  funext B
  rw [Finset.union_right_comm A]

end
end SubmodularMatching.Streaming.OracleQuery
