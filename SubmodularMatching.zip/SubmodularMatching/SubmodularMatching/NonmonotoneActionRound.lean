import SubmodularMatching.NonmonotoneActionScoreOutput
import SubmodularMatching.NonmonotonePreparationLaw

/-! Independent word batches for the two signed derivatives and score at one iterate. -/
namespace SubmodularMatching.NonmonotoneOptimizer
open Streaming MeasureTheory ProbabilityTheory UpperBoundAssembly
noncomputable section
variable {E : Type*} [DecidableEq E] {m n l s bits : ℕ} [NeZero n]

abbrev ActionKey (n : ℕ) := (Bool × Fin n) ⊕ Bool
def keySize (m n : ℕ) : ActionKey n → ℕ
  | .inr false => m
  | _ => m+n
abbrev ActionRound (m n s bits : ℕ) := (j : ActionKey n) → WordBatch s (keySize m n j) bits

def roundLaw (m n s bits : ℕ) : Measure (ActionRound m n s bits) :=
  Measure.pi fun j => wordBatchLaw s (keySize m n j) bits

instance (m n s bits : ℕ) : IsProbabilityMeasure (roundLaw m n s bits) := by
  unfold roundLaw; infer_instance

def roundWords (ω : ℕ → ActionRound m n s bits) : OptimizerWords m n l s bits where
  chain t _ flag i := ω t (.inl (flag,i))
  active t _ := ω t (.inr true)
  base t _ := ω t (.inr false)

namespace BlockData
variable (B : BlockData E n l) (r : Vec l) (h : ℕ → E) (p : ℕ → ℝ) (F : Finset E → ℝ)
variable (hp : ∀ i<m, 0 ≤ p i ∧ p i ≤ 1)

def keyQuery : ActionKey n → OracleQuery E
  | .inl (flag,i) => B.chainQuery r h p m F hp flag i
  | .inr false => baseQuery h p m F hp
  | .inr true => B.actionQuery r h p m F hp

theorem keyQuery_size (j : ActionKey n) : (B.keyQuery r h p F hp j).size = keySize m n j := by
  rcases j with ⟨flag,i⟩|v
  · rfl
  · cases v <;> rfl

def keyGood (d : ℚ) (j : ActionKey n) (w : WordBatch s (keySize m n j) bits) : Prop :=
  wordGood (B.keyQuery r h p F hp j) d ((B.keyQuery_size r h p F hp j).symm ▸ w)

theorem good_iff_keys (ω : ℕ → ActionRound m n s bits) (d : ℚ) (t : ℕ) :
    B.GoodStep r t h p F hp d (roundWords ω) ↔ ∀ j, B.keyGood r h p F hp d j (ω t j) := by
  constructor
  · rintro ⟨hc,ha,hb⟩ (⟨flag,i⟩|v)
    · exact hc flag i
    · cases v
      · exact hb
      · exact ha
  · intro H
    exact ⟨fun flag i => H (.inl (flag,i)),H (.inr true),H (.inr false)⟩

theorem keyRange (f : Finset E → ℝ) (τ : ℝ) (ht : 0<τ) (hf : IsSubmodular f)
    (hn : ∀ T, 0 ≤ f T) (h0 : f ∅ ≤ τ) (hh : ∀ i<m, f {h i} ≤ τ) (hs : ∀ i, f {B.label i} ≤ τ)
    (j : ActionKey n) :
    let Q := B.keyQuery r h p (normalized f τ) hp j
    ∀ A ⊆ (Finset.range Q.size).image Q.edges,
      -((m:ℝ)+n+1) ≤ Q.evaluate A ∧ Q.evaluate A ≤ (m:ℝ)+n+1 := by
  intro Q T hT
  rcases j with ⟨flag,i⟩|v
  · have hb := B.chainRange r h p f hp τ ht hf hn h0 hh hs flag i T hT
    exact ⟨hb.1,hb.2.trans (by linarith only [Nat.cast_nonneg (α:=ℝ) m,Nat.cast_nonneg (α:=ℝ) n])⟩
  · cases v
    · have hb := normalized_value_range f hf hn h m τ ht h0 hh T hT
      exact ⟨(by linarith only [Nat.cast_nonneg (α:=ℝ) m,Nat.cast_nonneg (α:=ℝ) n] : -((m:ℝ)+n+1)≤0).trans hb.1,
        hb.2.trans (by linarith only [Nat.cast_nonneg (α:=ℝ) n])⟩
    · have hsing (i : ℕ) (hi : i<m+n) : f {concatCoordinates h (B.orderedEdge r) m i} ≤ τ := by
        unfold concatCoordinates; split_ifs with H
        · exact hh _ H
        · exact hs _
      have hb := normalized_value_range f hf hn _ (m+n) τ ht h0 hsing T hT
      exact ⟨(by linarith only [Nat.cast_nonneg (α:=ℝ) m,Nat.cast_nonneg (α:=ℝ) n] : -((m:ℝ)+n+1)≤0).trans hb.1,
        by simpa only [Nat.cast_add] using hb.2⟩

end BlockData

theorem word_single_budget (Q : OracleQuery E) (d : ℚ) (K J : ℕ) (hK : 0<K) (hJ : 0<J)
    (lo hi : ℝ) (hd : 0<(d:ℝ)) (hwidth : 0<hi-lo) (hratio : hi-lo ≤ (K:ℝ)*d)
    (hsize : Q.size ≤ K) (hb : ∀ A ⊆ (Finset.range Q.size).image Q.edges, lo ≤ Q.evaluate A ∧ Q.evaluate A ≤ hi) :
    (wordBatchLaw (OracleQuery.batchCount K J) Q.size (OracleQuery.batchBits K)).real {ω | ¬wordGood Q d ω} ≤
      1/(J:ℝ) := by
  classical
  let μ := wordBatchLaw (OracleQuery.batchCount K J) Q.size (OracleQuery.batchBits K)
  let bad := {ω : WordBatch (OracleQuery.batchCount K J) Q.size (OracleQuery.batchBits K) | ¬wordGood Q d ω}
  have H := OracleQuery.adaptive_word_budget (fun _ (_ : Unit) => Q) K J 1 hK hJ hK lo hi d hd hwidth hratio
    (fun _ _ => hsize) (fun _ _ _ => ()) (fun _ _ => hb) ()
  change (∫ ω, (if wordGood Q d ω then (0:ℝ) else 1) ∂μ) ≤ _ at H
  have emp : (fun ω => if wordGood Q d ω then (0:ℝ) else 1) = bad.indicator (fun _ => (1:ℝ)) := by
    funext ω; by_cases ha : wordGood Q d ω <;> simp [bad,ha]
  rw [emp] at H
  change (∫ ω, bad.indicator (1 : WordBatch (OracleQuery.batchCount K J) Q.size (OracleQuery.batchBits K) → ℝ) ω ∂μ) ≤ _ at H
  rwa [integral_indicator_one (Set.toFinite bad).measurableSet] at H

end
end SubmodularMatching.NonmonotoneOptimizer
