import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step197 : ProjectedGoal ⟨432, 647, 0, 70, 851, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0x1aff00000000000000730191) (by decide +kernel)

theorem Part00015 : ProjectedGoal ⟨432, 647, 0, 70, 851, 1135⟩ := step197

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
