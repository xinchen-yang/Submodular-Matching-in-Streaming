import SubmodularMatching.UpperBoundVertexCandidate
import SubmodularMatching.UpperBoundSourceProgram

/-! # Final candidate scan driven by the actual surviving instances -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint Streaming TwoStage SourceCertificate GibbsSampler NumericalCertificate

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]
variable {Ns Ng : ℕ}

/-- The compact order is exactly the accepted-edge order of the final
instance, including its actual birth edge. -/
def finalGuessCount (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ) (j : ℕ) : ℕ :=
  (acceptedOrder (finalGuessConfig P j) P.ends (finalGuessInput P batches j)
    (finalGuessLength P j)).length

def finalGuessEmbedding (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (j : ℕ) : Fin (finalGuessCount P batches j) ↪ E :=
  storedEmbedding (finalGuessConfig P j) P.ends (finalGuessInput P batches j)
    (finalGuessLength P j) (finalGuessInput_distinct P batches j hunique)

def finalGuessFrozen (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ) (j : ℕ) : E → ℝ :=
  traceWeightIndex (finalGuessInput P batches j) (finalGuessLength P j)

def finalGuessIndices (P : ScheduledSource E V) : Finset ℕ :=
  activeGuessIndices P.width (guessAnchor P.width P.value P.arrivals)
    (singletonMaximum P.value P.arrivals) P.span

/-- The actual candidate for a nonempty final instance. -/
def finalGuessCandidate (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (hloop : ∀ e, (P.ends e).1 ≠ (P.ends e).2)
    (Q : ℕ → ℕ) (draw : ∀ j, AppendixDraw (finalGuessCount P batches j) Ng)
    (j : ℕ) (hm : 0 < finalGuessCount P batches j) : CandidateLaw (Finset E) :=
  compactAppendixGuessCandidate hm (finalGuessEmbedding P batches hunique j) P.ends hloop
    (finalGuessConfig P j).tau (finalGuessFrozen P batches j) P.objective (Q j) (draw j)

/-- Scan the nonempty final instances in index order. An empty instance
has no candidate beyond the empty matching already dominated by the singleton. -/
def finalGuessCandidates (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (hloop : ∀ e, (P.ends e).1 ≠ (P.ends e).2)
    (Q : ℕ → ℕ) (draw : ∀ j, AppendixDraw (finalGuessCount P batches j) Ng) :
    List (CandidateLaw (Finset E)) :=
  ((finalGuessIndices P).sort (· ≤ ·)).filterMap fun j =>
    if hm : 0 < finalGuessCount P batches j then
      some (finalGuessCandidate P batches hunique hloop Q draw j hm) else none

theorem finalGuessCandidate_in_scan (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (hloop : ∀ e, (P.ends e).1 ≠ (P.ends e).2)
    (Q : ℕ → ℕ) (draw : ∀ j, AppendixDraw (finalGuessCount P batches j) Ng)
    (j : ℕ) (hj : j ∈ finalGuessIndices P) (hm : 0 < finalGuessCount P batches j) :
    finalGuessCandidate P batches hunique hloop Q draw j hm ∈
      finalGuessCandidates P batches hunique hloop Q draw := by
  unfold finalGuessCandidates
  exact List.mem_filterMap.mpr ⟨j, (Finset.mem_sort (· ≤ ·)).2 hj, dif_pos hm⟩

theorem finalGuessCandidates_legal (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (hloop : ∀ e, (P.ends e).1 ≠ (P.ends e).2)
    (Q : ℕ → ℕ) (draw : ∀ j, AppendixDraw (finalGuessCount P batches j) Ng) :
    ∀ q ∈ finalGuessCandidates P batches hunique hloop Q draw,
      q.outcomes ⊆ arrivedMatchings P.ends P.edges P.arrivals := by
  intro q hq
  unfold finalGuessCandidates at hq
  obtain ⟨j, _, h⟩ := List.mem_filterMap.mp hq
  split_ifs at h with hm
  · obtain rfl := Option.some.inj h
    unfold finalGuessCandidate
    apply compactAppendixGuessCandidate_feasible
    unfold finalGuessEmbedding
    rw [storedEmbedding_image]
    exact finalGuessStored_arrived P batches j

omit [Fintype V] in
theorem finalGuessCount_le_arrivals (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (j : ℕ) : finalGuessCount P batches j ≤ P.arrivals := by
  let C := finalGuessConfig P j
  let input := finalGuessInput P batches j
  let n := finalGuessLength P j
  have hnd := acceptedOrder_nodup C P.ends input n (finalGuessInput_distinct P batches j hunique)
  have hcard := Finset.card_le_card (finalGuessStored_arrived P batches j)
  have hs : (arrivedEdges P.edges P.arrivals).card ≤ P.arrivals := by
    unfold arrivedEdges
    exact Finset.card_image_le.trans (Finset.card_range _).le
  have hcount : finalGuessCount P batches j = (runPotential C P.ends input n).stored.card := by
    change (acceptedOrder C P.ends input n).length = _
    rw [← acceptedOrder_toFinset, List.toFinset_card_of_nodup hnd]
  rw [hcount]
  exact hcard.trans hs

omit [Fintype V] in
/-- Positive stored size is needed only by the optimizer. An empty final
instance has zero stored value and zero ideal increments. -/
theorem zero_idealPotential_of_empty (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (n : ℕ) (hS : (runPotential C ends input n).stored = ∅) (v : V) :
    Streaming.idealPotential C ends input n v = 0 := by
  classical
  induction n with
  | zero => rfl
  | succ n ih =>
    have hsub := runPotential_stored_monotone C ends input (Nat.le_succ n)
    change (runPotential C ends input n).stored ⊆ (runPotential C ends input (n + 1)).stored at hsub
    rw [hS] at hsub
    have hs : (runPotential C ends input n).stored = ∅ := Finset.subset_empty.mp hsub
    have hrej := not_acceptedAt_of_not_stored C ends input (n + 1) n (Nat.lt_succ_self n)
      (by rw [hS]; exact Finset.notMem_empty _)
    rw [Streaming.idealPotential]
    change Streaming.idealPotential C ends input n v + (if acceptedAt C ends input n then _ else 0) = 0
    rw [if_neg hrej, ih hs, add_zero]

theorem empty_guess_charge (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (f : Finset E → ℝ) (n : ℕ) (M : Finset E) (e : ℝ)
    (hp : C.p ≤ 1) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (hS : (runPotential C ends input n).stored = ∅)
    (hcharge : f M ≤ traceRecordedValue C ends input n +
      traceResidual C ends input f n (M ∩ (runPotential C ends input n).stored) +
      (∑ v ∈ Finset.univ \ (M ∩ (runPotential C ends input n).stored).biUnion (endpointSet ends),
        idealPotential C ends input n v) + 6 * e * C.tau) :
    f M ≤ 6 * e * C.tau := by
  have hr : traceRecordedValue C ends input n = 0 := by
    unfold traceRecordedValue
    apply Finset.sum_eq_zero
    intro i hi
    have h := not_acceptedAt_of_not_stored C ends input n i (Finset.mem_range.mp hi)
      (by rw [hS]; exact Finset.notMem_empty _)
    simp [traceProbability, h]
  rw [hS, Finset.inter_empty, (traceResidual_properties C ends input f n hp hf hmono).1, hr]
    at hcharge
  simpa only [zero_idealPotential_of_empty C ends input n hS, Finset.sum_const_zero, zero_add] using hcharge

end

end SubmodularMatching.UpperBoundAssembly
