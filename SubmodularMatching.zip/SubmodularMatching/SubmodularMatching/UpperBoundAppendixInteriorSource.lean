import SubmodularMatching.CertificateHullConeData
import SubmodularMatching.ReplayHardFirst
import SubmodularMatching.ReplayHardLast
import SubmodularMatching.UpperBoundAppendixCheckedSource

/-!
# Only the middle uncovered-endpoint modes remain in the source obligation
-/

namespace SubmodularMatching.UpperBoundAssembly

open SourceCertificate

/-- The first and last 108 rate modes are checked in all four endpoint
classes. The hypothesis concerns the remaining modes with neither endpoint
covered and prices in the interpolation grid box. -/
theorem appendixSourceObligation_of_uncovered_middle (vertices : ℕ) (hn : 2 ≤ vertices)
    (middleModes : AppendixBoxGoal false false ⟨216, 55079, 0, 1135, 0, 1135⟩) :
    AppendixSourceObligation vertices hn := by
  have rates (z : ℕ) (_ : z < 2 ^ 32) : (Replay.runRegion Replay.quickRow z).Valid :=
    Replay.runRegion_valid Replay.quickRow Replay.quickRow_eq Replay.quickRow_boundary z
  apply appendixSourceObligation_of_uncovered_root vertices hn
  apply AppendixBoxGoal.splitMode appendixPriceRoot 215 (by decide) (by decide)
  · exact Replay.HardFirst.checked rates Replay.appendixFastConeAt_sufficient
  · exact AppendixBoxGoal.splitMode ⟨216, 55295, 0, 1135, 0, 1135⟩ 55079
      (by decide) (by decide) middleModes
      (Replay.HardLast.checked rates Replay.appendixFastConeAt_sufficient)

end SubmodularMatching.UpperBoundAssembly
