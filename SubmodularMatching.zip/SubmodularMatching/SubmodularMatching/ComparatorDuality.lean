import SubmodularMatching.CappedPacking
import SubmodularMatching.JointPolytope

/-!
# Dual-to-primal transfer for the matching comparator

This specializes the proved capped-packing normalization to the exact
capacities of `W_D(O)`. The indicator may be any vector in `[0,1]`, which in
particular includes the fixed covered-vertex indicator of a matching.
-/

open scoped BigOperators

namespace SubmodularMatching.Joint

noncomputable section

variable {E V : Type*} [Fintype E] [Fintype V] [DecidableEq V]

omit [Fintype E] in
theorem incidence_column (ends : E → V × V) (price : V → ℝ) (e : E)
    (he : (ends e).1 ≠ (ends e).2) :
    LinearPacking.column (fun v d => incidence ends v d) price e =
      price (ends e).1 + price (ends e).2 := by
  have hterm : ∀ v, incidence ends v e * price v =
      (if v = (ends e).1 then price (ends e).1 else 0) +
        (if v = (ends e).2 then price (ends e).2 else 0) := by
    intro v
    by_cases h1 : v = (ends e).1
    · simp [incidence, h1, he]
    · by_cases h2 : v = (ends e).2
      · simp [incidence, h2, Ne.symm he]
      · simp [incidence, h1, h2]
  unfold LinearPacking.column
  simp_rw [hterm]
  rw [Finset.sum_add_distrib]
  simp

/-- This is the final duality implication in Lemma 3.4 for the actual
matching-comparator LP. Taking `upper = W_D(O)` yields its stated conclusion
once the potential trace establishes the displayed all-dual lower bound. -/
theorem comparator_duality (ends : E → V × V) (I : V → ℝ) (w : E → ℝ)
    (p D tau lower upper : ℝ)
    (hM : 1 ≤ Fintype.card V) (hN : 1 ≤ Fintype.card E)
    (hends : ∀ e, (ends e).1 ≠ (ends e).2)
    (hI : ∀ v, 0 ≤ I v ∧ I v ≤ 1)
    (hp : 0 < p) (hD : 0 ≤ D) (hD2 : 2 * D < 1) (hpD : p ≤ 1 - D)
    (htau : 0 < tau) (hw : ∀ e, 0 ≤ w e ∧ w e ≤ tau)
    (hlower : ∀ price : V → ℝ, (∀ v, 0 ≤ price v) →
      lower ≤ (∑ v, (1 - D * I v) * price v) +
        p * ∑ e, (1 - D * (I (ends e).1 + I (ends e).2)) *
          max 0 (w e - price (ends e).1 - price (ends e).2))
    (hupper : ∀ z : E → ℝ,
      (∀ e, 0 ≤ z e ∧ z e ≤ p * (1 - D * (I (ends e).1 + I (ends e).2))) →
      (∀ v, degree ends z v ≤ 1 - D * I v) →
      (∑ e, w e * z e) ≤ upper) : lower ≤ upper := by
  let capacity : V → ℝ := fun v => 1 - D * I v
  let cap : E → ℝ := fun e => p * (1 - D * (I (ends e).1 + I (ends e).2))
  have hs : ∀ v, 0 < capacity v := by
    intro v
    have hiv := hI v
    dsimp [capacity]
    nlinarith [mul_le_mul_of_nonneg_left hiv.2 hD]
  have hcap : ∀ e, 0 ≤ cap e ∧ cap e ≤ p := by
    intro e
    have hu := hI (ends e).1
    have hv := hI (ends e).2
    have hk : 0 ≤ 1 - D * (I (ends e).1 + I (ends e).2) ∧
        1 - D * (I (ends e).1 + I (ends e).2) ≤ 1 := by
      constructor <;> nlinarith [mul_nonneg hD hu.1, mul_nonneg hD hv.1,
        mul_le_mul_of_nonneg_left (add_le_add hu.2 hv.2) hD]
    exact ⟨mul_nonneg hp.le hk.1, mul_le_of_le_one_right hp.le hk.2⟩
  have hp1 : p ≤ 1 := by linarith
  apply CappedPacking.dual_lower_le_primal_upper
    (fun v e => incidence ends v e) capacity cap w tau lower upper hM hN
    (fun v e => (incidence_bounds ends v e).1) hs (fun e => (hcap e).1)
    (fun e => (hw e).1) htau
  · intro v e
    have hinc := incidence_bounds ends v e
    have hi := hI v
    have hpc : p ≤ capacity v := by
      dsimp [capacity]
      nlinarith [mul_le_mul_of_nonneg_left hi.2 hD]
    exact (mul_le_of_le_one_left (hcap e).1 hinc.2).trans ((hcap e).2.trans hpc)
  · intro e
    exact (mul_le_of_le_one_right (hw e).1 ((hcap e).2.trans hp1)).trans (hw e).2
  · intro price hprice
    have hh := hlower price hprice
    have heq : CappedPacking.physicalDual (fun v e => incidence ends v e) capacity cap w price =
        (∑ v, (1 - D * I v) * price v) +
          p * ∑ e, (1 - D * (I (ends e).1 + I (ends e).2)) *
            max 0 (w e - price (ends e).1 - price (ends e).2) := by
      unfold CappedPacking.physicalDual
      simp only [capacity, cap, incidence_column ends price _ (hends _), Finset.mul_sum]
      congr 1
      apply Finset.sum_congr rfl
      intro e _
      rw [sub_add_eq_sub_sub]
      ring
    rw [heq]
    exact hh
  · intro z hz hload
    exact hupper z hz hload

end

end SubmodularMatching.Joint
