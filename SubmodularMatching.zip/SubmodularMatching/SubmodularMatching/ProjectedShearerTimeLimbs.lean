import SubmodularMatching.ProjectedShearerTimeCost

/-! A mixed-radix time word occupies at most one binary limb per selected copy. -/
namespace SubmodularMatching.Shearer
variable {E : Type*} [LinearOrder E]

private theorem limbValue_ofFn (B r : ℕ) (digits : Fin r → Fin B) :
    limbValue B (List.ofFn fun i => (digits i).val) = (finFunctionFinEquiv digits).val := by
  rw [finFunctionFinEquiv_apply]
  induction r with
  | zero => simp [limbValue]
  | succ r ih =>
    rw [List.ofFn_succ,limbValue,Fin.sum_univ_succ]
    have h := ih (fun i => digits i.succ)
    simp only [Fin.val_zero,pow_zero,mul_one,Fin.val_succ,pow_succ',h,Finset.mul_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro i _
    ring

/-- The actual accepted finite time word has a fixed count of binary limbs.
The same extraction supplies the original time assignment and exact
quadratic limb-visit count. Each intermediate carry fits in two limbs. -/
theorem time_word_limb_resources (M : Finset E) (k : ℕ) (hk : 0<k) (word : Fin (k^M.card)) :
    let B := 2^Nat.clog 2 k
    ∃ digits : List ℕ, digits.length=M.card ∧ (∀ x∈digits,x<B) ∧ limbValue B digits=word.val ∧
      (collectMarkDigits B k M.card digits [] 0).1 =
        List.ofFn (fun i : Fin M.card => (timeCodec M k word ((M.orderIsoOfFin rfl) i)).val) ∧
      (collectMarkDigits B k M.card digits [] 0).2 = M.card^2 ∧
      ∀ r x : ℕ, r<k → x<B → B*r+x<B^2 := by
  intro B
  have hB : k≤B := Nat.le_pow_clog (by decide : 1<2) _
  let full : Fin (B^M.card) := ⟨word.val,word.isLt.trans_le (Nat.pow_le_pow_left hB _)⟩
  let get : Fin M.card→Fin B := finFunctionFinEquiv.symm full
  let digits := List.ofFn fun i => (get i).val
  have he : limbValue B digits=word.val := (limbValue_ofFn B M.card get).trans
    (congrArg Fin.val (finFunctionFinEquiv.apply_symm_apply full))
  have hl : digits.length=M.card := List.length_ofFn
  have hd (x) (hx : x∈digits) : x<B := by
    obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hx
    exact (get i).isLt
  have hc := timeCodec_sequential M k hk word B digits hd he
  refine ⟨digits,hl,hd,he,hc.1,hc.2.trans (by rw [hl,sq]),?_⟩
  exact fun _ _ h g => division_step_width h hB g

/-- A bounded rejection attempt, including a rejected block, fits in the
same padded limb vector. At most t such blocks will be read from the stream. -/
theorem time_rejection_limbs (M : Finset E) (k t : ℕ) (hk : 0<k) :
    2^(timeGrid M k hk).bits ≤ (2^Nat.clog 2 k)^M.card ∧
    Fintype.card (Fin t × Fin M.card) = t*M.card := by
  constructor
  · rw [←Nat.pow_mul]
    apply Nat.pow_le_pow_right (by decide)
    simpa only [Nat.mul_comm] using time_word_width M k hk
  · simp

end SubmodularMatching.Shearer
