import SubmodularMatching.UpperBoundArchiveProgram

/-! # Choosing the reference incumbent from the physical singleton register -/

namespace SubmodularMatching.Streaming

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- A change in the cutoffs, trial counts or random words affects guess
archives only. It has no effect on the chosen best singleton, including
its deterministic tie resolution. -/
theorem runOnlineStream_bestEdge_independent (R : GridUpdateParameters) (ends : E → V × V)
    (W epsilon : ℚ) (span vertices : ℕ) (oracle : Finset E → ℚ)
    (threshold₁ N₁ threshold₂ N₂ : ℕ) (edges : ℕ → E)
    (coins₁ coins₂ : ℕ → ℕ → ℕ → ℕ → ℕ) (n : ℕ) :
    (runOnlineStream R ends W epsilon span vertices oracle threshold₁ N₁ edges coins₁ n).bestEdge =
      (runOnlineStream R ends W epsilon span vertices oracle threshold₂ N₂ edges coins₂ n).bestEdge := by
  induction n with
  | zero => rfl
  | succ n ih =>
    let a := runOnlineStream R ends W epsilon span vertices oracle threshold₁ N₁ edges coins₁ n
    let b := runOnlineStream R ends W epsilon span vertices oracle threshold₂ N₂ edges coins₂ n
    have ha : a.epoch = runOnlineEpoch W span (fun i => oracle {edges i}) n :=
      runOnlineStream_epoch _ _ _ _ _ _ _ _ _ _ _ _
    have hb : b.epoch = runOnlineEpoch W span (fun i => oracle {edges i}) n :=
      runOnlineStream_epoch _ _ _ _ _ _ _ _ _ _ _ _
    change (if a.epoch.best < oracle {edges n} then some (edges n) else a.bestEdge) =
      (if b.epoch.best < oracle {edges n} then some (edges n) else b.bestEdge)
    have h : a.bestEdge = b.bestEdge := ih
    rw [ha, hb, h]

end SubmodularMatching.Streaming

namespace SubmodularMatching.UpperBoundAssembly.AppendixProgramInput

open Streaming GibbsSampler NumericalCertificate

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]
variable (I : AppendixProgramInput E V)

/-- All runs have one common physical incumbent, with its actual input
position available as a proof witness. -/
theorem onlineSource_has_common_best (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ)) :
    ∃ i < I.P.arrivals, I.P.value i = I.B ∧
      ∀ ω coins, (I.onlineSourceState oracle ω coins I.P.arrivals).bestEdge = some (I.P.edges i) := by
  let R := appendixOnlineGrid I.P.vertices
  let zeroWords : ℕ → ℕ → ℕ → ℕ → ℕ := fun _ _ _ _ => 0
  let st := runOnlineStream R I.P.ends I.onlineWidth rationalEpsilon I.P.span I.P.vertices
    oracle 0 0 I.P.edges zeroWords I.P.arrivals
  let v := fun i => oracle {I.P.edges i}
  have hv : (fun i => (v i : ℝ)) = I.P.value := by
    funext i
    change (oracle {I.P.edges i} : ℝ) = I.P.objective {I.P.edges i}
    rw [hobj]
  have hmax : (st.epoch.best : ℝ) = I.B := by
    unfold st
    rw [runOnlineStream_epoch]
    have hs := (runOnlineEpoch_real I.onlineWidth I.P.span v I.P.arrivals).1
    rw [hv] at hs
    exact hs
  rcases runOnlineStream_bestEdge R I.P.ends I.onlineWidth rationalEpsilon I.P.span I.P.vertices
      oracle 0 0 I.P.edges zeroWords I.P.arrivals with hzero | ⟨i, hi, he, hval⟩
  · have hz : (st.epoch.best : ℝ) = 0 := by exact_mod_cast hzero.2
    exact (I.positiveBest.ne' (hmax.symm.trans hz)).elim
  · refine ⟨i, hi, ?_, ?_⟩
    · change I.P.objective {I.P.edges i} = I.B
      rw [hobj]
      exact (congrArg (Rat.cast : ℚ → ℝ) hval).trans hmax
    · intro ω coins
      unfold onlineSourceState
      rw [runOnlineStreamForward_eq]
      have hh := runOnlineStream_bestEdge_independent R I.P.ends I.onlineWidth rationalEpsilon
        I.P.span I.P.vertices oracle (dyadicThreshold rationalCoordinateCap I.P.bits)
        (I.Ns ω) 0 0 I.P.edges coins zeroWords I.P.arrivals
      exact hh.trans he

/-- Choose the analysis input's best-singleton witness with the tie rule
of the physical register. Its schedule and graph parameters are shared. -/
def withRetainedBest (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ)) : AppendixProgramInput E V :=
  let hi := Classical.choose_spec (I.onlineSource_has_common_best oracle hobj)
  { I with
    bestIndex := Classical.choose (I.onlineSource_has_common_best oracle hobj)
    bestIndex_arrived := hi.1
    bestIndex_value := hi.2.1 }

theorem withRetainedBest_physical (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ))
    (ω : ℝ) (coins : ℕ → ℕ → ℕ → ℕ → ℕ) :
    let J := I.withRetainedBest oracle hobj
    (J.onlineSourceState oracle ω coins J.P.arrivals).bestEdge = some (J.P.edges J.bestIndex) :=
  (Classical.choose_spec (I.onlineSource_has_common_best oracle hobj)).2.2 ω coins

variable [Fintype E]

/-- The archive-only law initializes its scan with the very edge kept by
the physical singleton register, under either confidence mode. -/
theorem archivedWord_physicalBest_guarantees (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ))
    (hcert : AppendixSourceObligation I.P.vertices I.atLeastTwo)
    (O : Finset E) (hO : O ∈ I.feasible)
    (hopt : ∀ M ∈ I.feasible, I.P.objective M ≤ I.P.objective O) (delta : ℝ) (hδ : 0 < delta) :
    let J := I.withRetainedBest oracle hobj
    let p := J.archivedExpectedLaw oracle
    let q := J.archivedAmplifiedLaw oracle delta
    p.outcomes ⊆ I.feasible ∧ q.outcomes ⊆ I.feasible ∧
      I.P.objective O / targetFactor ≤ expected p.outcomes p.mass I.P.objective ∧
      expected q.outcomes q.mass
        (fun M => if I.P.objective O / targetFactor ≤ I.P.objective M then 0 else 1) ≤ delta :=
  (I.withRetainedBest oracle hobj).archivedWord_guarantees oracle hobj hcert O hO hopt delta hδ

end

end SubmodularMatching.UpperBoundAssembly.AppendixProgramInput
