import SubmodularMatching.CertificateEasyConeData
import SubmodularMatching.CertificateConeLiteralProof

/-! # Checked cone prefix for the three covered endpoint classes -/

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000

private def appendixEasyConeBlocks : Array (AppendixConeBlock AppendixFastCone.Sufficient) := #[
  appendixHullConeBlock0000, appendixHullConeBlock0001, appendixHullConeBlock0002
]

private theorem appendixEasyConeRows (q : ℕ) (hq : q < appendixEasyConeBlocks.size) :
    appendixRawConeBlocks[q]? = (appendixEasyConeBlocks.map AppendixConeBlock.raw)[q]? := by
  change q < 3 at hq
  rw [Array.getElem?_map]
  interval_cases q
  · change some appendixRawConeBlock0000 =
      some (AppendixConeBlock.raw appendixHullConeBlock0000)
    apply congrArg some
    apply Array.toList_inj.mp
    rw [AppendixConeBlock.raw, Array.toList_map]
    rfl
  · change some appendixRawConeBlock0001 =
      some (AppendixConeBlock.raw appendixHullConeBlock0001)
    apply congrArg some
    apply Array.toList_inj.mp
    rw [AppendixConeBlock.raw, Array.toList_map]
    rfl
  · change some appendixRawConeBlock0002 =
      some (AppendixConeBlock.raw appendixHullConeBlock0002)
    apply congrArg some
    apply Array.toList_inj.mp
    rw [AppendixConeBlock.raw, Array.toList_map]
    rfl


theorem appendixFastConeAt_easy (id : ℕ) (hid : id < 72) :
    (appendixFastConeAt id).Sufficient :=
  appendixFastConeAt_prefix_proof appendixEasyConeBlocks appendixEasyConeRows id
    (show id < 96 from hid.trans_le (by decide))

end SubmodularMatching.SourceCertificate.Replay
