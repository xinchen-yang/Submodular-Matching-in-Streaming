import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step198 : ProjectedGoal ⟨54864, 55079, 567, 1135, 0, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0xd7ff6c000000000000047024) (by decide +kernel)

theorem Part00022 : ProjectedGoal ⟨54864, 55079, 567, 1135, 0, 1135⟩ := step198

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
