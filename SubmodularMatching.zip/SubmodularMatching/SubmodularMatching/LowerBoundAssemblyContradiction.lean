import SubmodularMatching.LowerBoundAssemblyLimit
import SubmodularMatching.LowerBoundSoundness

/-! # Combining completeness and finite soundness -/

namespace SubmodularMatching.LowerBoundAssembly

open Filter LowerBoundSoundness
open scoped BigOperators Topology

/-- The numerical profiles of the output and witness on a finite hard
distribution. The output bound is exactly the conclusion of
`LowerBoundSoundness.matching_objective_bound` after replacing the actual
outside-slot fraction by the chosen fixed cap. -/
structure FiniteExperiment (Ω : Type*) [Fintype Ω] (baseline target : ℝ) where
  law : Ω → ℝ
  output : Ω → ℝ
  witness : Ω → ℝ
  recovery : Ω → ℝ
  complete : Ω → Prop
  law_nonneg : ∀ ω, 0 ≤ law ω
  law_total : ∑ ω, law ω = 1
  witness_nonneg : ∀ ω, 0 ≤ witness ω
  recovery_nonneg : ∀ ω, 0 ≤ recovery ω
  witness_complete : ∀ ω, complete ω → target ≤ witness ω
  output_bound : ∀ ω, output ω ≤ baseline + recovery ω

namespace FiniteExperiment

variable {Ω : Type*} [Fintype Ω] {baseline target : ℝ}

noncomputable section

def failure (experiment : FiniteExperiment Ω baseline target) : ℝ :=
  eventMass experiment.law (fun ω => ¬experiment.complete ω)

def recoveryMean (experiment : FiniteExperiment Ω baseline target) : ℝ :=
  ∑ ω, experiment.law ω * experiment.recovery ω

def success (experiment : FiniteExperiment Ω baseline target) (R : ℝ) : ℝ :=
  eventMass experiment.law (fun ω => experiment.witness ω ≤ R * experiment.output ω)

theorem success_le (experiment : FiniteExperiment Ω baseline target) {R : ℝ}
    (hR : 0 < R) (hgap : baseline < target / R) :
    experiment.success R ≤ experiment.failure +
      experiment.recoveryMean / (target / R - baseline) := by
  apply event_le_exception_add_markov experiment.law experiment.recovery
    experiment.complete _ _ experiment.law_nonneg experiment.recovery_nonneg (sub_pos.mpr hgap)
  intro ω hc hs
  have ht := (div_le_iff₀ hR).2
    (show target ≤ experiment.output ω * R by
      rw [mul_comm]; exact (experiment.witness_complete ω hc).trans hs)
  linarith only [ht, experiment.output_bound ω]

theorem outputMean_le (experiment : FiniteExperiment Ω baseline target) :
    ∑ ω, experiment.law ω * experiment.output ω ≤ baseline + experiment.recoveryMean := by
  calc
    _ ≤ ∑ ω, experiment.law ω * (baseline + experiment.recovery ω) :=
      Finset.sum_le_sum (fun ω _ =>
        mul_le_mul_of_nonneg_left (experiment.output_bound ω) (experiment.law_nonneg ω))
    _ = _ := by
      rw [recoveryMean]
      simp only [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul, experiment.law_total, one_mul]

theorem witnessMean_ge (experiment : FiniteExperiment Ω baseline target) :
    target * (1 - experiment.failure) ≤ ∑ ω, experiment.law ω * experiment.witness ω := by
  classical
  calc
    _ = ∑ ω, if experiment.complete ω then experiment.law ω * target else 0 := by
      rw [failure, eventMass, ← experiment.law_total, ← Finset.sum_sub_distrib]
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro ω _
      by_cases hc : experiment.complete ω <;> simp [hc, mul_comm]
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro ω _
      split_ifs with hc
      · exact mul_le_mul_of_nonneg_left (experiment.witness_complete ω hc)
          (experiment.law_nonneg ω)
      · exact mul_nonneg (experiment.law_nonneg ω) (experiment.witness_nonneg ω)

end

/-- Assemble the actual recursive objective, matching-slot soundness,
and good-only completeness into the finite profile used by the limit. -/
noncomputable def ofMatching {L R C : Type*} [Fintype C]
    (μ : Ω → ℝ) (hμ : ∀ ω, 0 ≤ μ ω) (hμsum : ∑ ω, μ ω = 1)
    (unit cap ξ : ℝ) (hunit : 0 ≤ unit) (hc0 : 0 ≤ cap) (hc1 : cap ≤ 1)
    (stage : ((L × C) × (R × C)) → ℕ)
    (label : Ω → ((L × C) × (R × C)) → Bool)
    (special : Ω → ℕ → L × R → Prop) [∀ ω i, DecidablePred (special ω i)]
    (S W : Ω → Finset ((L × C) × (R × C))) (hS : ∀ ω, CloneLift.IsMatching (S ω))
    (count : ℕ) (coverL : Ω → ℕ → Finset L) (coverR : Ω → ℕ → Finset R)
    (hcapacity : ∀ ω i, i < count →
      (Fintype.card C : ℝ) * ((coverL ω i).card + (coverR ω i).card) * unit ≤ cap)
    (hcover : ∀ ω i, i < count → ∀ e ∈ S ω, stage e = i →
      ¬special ω i (CloneLift.basePair e) → e.1.1 ∈ coverL ω i ∨ e.2.1 ∈ coverR ω i)
    (complete : Ω → Prop)
    (hwbad : ∀ ω, complete ω → ∀ i < count,
      RecursiveObjective.stageMass unit stage (label ω) i false (W ω) = 0)
    (hwgood : ∀ ω, complete ω → ∀ i < count,
      1 - ξ ≤ RecursiveObjective.stageMass unit stage (label ω) i true (W ω) ∧
        RecursiveObjective.stageMass unit stage (label ω) i true (W ω) ≤ 1) :
    FiniteExperiment Ω (cap * (count + 1 : ℝ) / (1 + cap)) ((count : ℝ) * (1 - ξ)) where
  law := μ
  output := fun ω => RecursiveObjective.objective unit stage (label ω) 0 count (S ω)
  witness := fun ω => RecursiveObjective.objective unit stage (label ω) 0 count (W ω)
  recovery := fun ω => recoveryError unit stage (label ω) (special ω) (S ω) 0 count
  complete := complete
  law_nonneg := hμ
  law_total := hμsum
  witness_nonneg := fun ω => (RecursiveObjective.objective_bounds unit hunit stage (label ω) count 0 (W ω)).1
  recovery_nonneg := fun ω => recoveryError_nonnegative unit hunit stage (label ω) (special ω) (S ω) 0 count
  witness_complete := fun ω hc => RecursiveObjective.objective_good_only_lower_bound
    unit hunit stage (label ω) count 0 (W ω) ξ
    (fun i _ hi => hwbad ω hc i (by simpa using hi))
    (fun i _ hi => hwgood ω hc i (by simpa using hi))
  output_bound := fun ω =>
    matching_objective_bound unit cap hunit hc0 hc1 stage (label ω) (special ω) (S ω)
      (hS ω) 0 count (coverL ω) (coverR ω)
      (fun i _ hi => hcapacity ω i (by simpa using hi))
      (fun i _ hi => hcover ω i (by simpa using hi))

/-- A sequence of these distributions rules out a fixed every-input success
probability and an every-input expected approximation at the same ratio.
The proof applies after averaging over the algorithm's coins. -/
theorem eventually_failure_both_guarantees
    {ι : Type*} {l : Filter ι} {Ω : ι → Type*} [∀ i, Fintype (Ω i)]
    {baseline target R : ℝ} (hR : 0 < R) (hgap : baseline < target / R)
    (experiment : (i : ι) → FiniteExperiment (Ω i) baseline target)
    (hf : Tendsto (fun i => (experiment i).failure) l (𝓝 0))
    (he : Tendsto (fun i => (experiment i).recoveryMean) l (𝓝 0))
    {prob : ℝ} (hprob : 0 < prob) :
    ∀ᶠ i in l, (experiment i).success R < prob ∧
      R * (∑ ω, (experiment i).law ω * (experiment i).output ω) <
        ∑ ω, (experiment i).law ω * (experiment i).witness ω := by
  have hlim : Tendsto
      (fun i => (experiment i).failure + (experiment i).recoveryMean / (target / R - baseline))
      l (𝓝 0) := by simpa using hf.add (he.div_const (target / R - baseline))
  have hlimR : Tendsto (fun i => R * (baseline + (experiment i).recoveryMean)) l
      (𝓝 (R * baseline)) := by
    simpa using (tendsto_const_nhds.add he).const_mul R
  have hlimW : Tendsto (fun i => target * (1 - (experiment i).failure)) l (𝓝 target) := by
    simpa using ((tendsto_const_nhds (x := (1 : ℝ))).sub hf).const_mul target
  have hRbase : R * baseline < target := by
    simpa [mul_comm] using (lt_div_iff₀ hR).1 hgap
  obtain ⟨mid, hRmid, hmidW⟩ := exists_between hRbase
  filter_upwards [hlim.eventually_lt_const hprob, hlimR.eventually_lt_const hRmid,
    hlimW.eventually_const_lt hmidW] with i hi hRi hWi
  exact ⟨((experiment i).success_le hR hgap).trans_lt hi,
    (mul_le_mul_of_nonneg_left (experiment i).outputMean_le hR.le).trans_lt
      (hRi.trans (hWi.trans_le (experiment i).witnessMean_ge))⟩

end FiniteExperiment

end SubmodularMatching.LowerBoundAssembly
