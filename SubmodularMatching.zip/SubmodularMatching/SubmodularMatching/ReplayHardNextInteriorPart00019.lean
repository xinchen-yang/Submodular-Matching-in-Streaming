import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step206 : ProjectedGoal ⟨432, 445, 567, 1135, 0, 1135⟩ :=
  projectedGoal_chunk _ (.x (.y (.x (.x (.y (.y (.y (.y (.y (.m (.m (.m (.leaf 0x1b101b0000000000050059a) (.leaf 0x1b301b2000000000050059a)) (.m (.leaf 0x1b501b4000000000050059a) (.leaf 0x1b601b6000000000050059a))) (.m (.m (.m (.leaf 0x1b701b7000000000050059a) (.leaf 0x1b801b8000000000050059a)) (.m (.leaf 0x1b901b9000000000050059a) (.leaf 0x1ba01ba000000000050059a))) (.m (.m (.leaf 0x1bb01bb000000000050059a) (.leaf 0x1bc01bc000000000050059a)) (.leaf 0x1bd01bd000000000050059a)))) (.leaf 0x1bd01b000000000001c959a)) (.leaf 0x1bd01b0000000000017f59a)) (.leaf 0x1bd01b000000000000e859a)) (.leaf 0x1bd01b0000000000004e59a)) (.leaf 0x1bd01b0000000000000f59a)) (.leaf 0x1bd01b000000000000445b0)) (.leaf 0x1bd01b000000000000445b1)) (.leaf 0x1bd01b000000000000245b2)) (.leaf 0x1bd01b00000000000047730)) (by decide +kernel)

private theorem step207 : ProjectedGoal ⟨446, 458, 567, 1135, 0, 1135⟩ :=
  projectedGoal_chunk _ (.x (.y (.x (.x (.y (.y (.y (.y (.y (.m (.m (.m (.leaf 0x1bf01be000000000050059a) (.leaf 0x1c101c0000000000050059a)) (.m (.leaf 0x1c301c2000000000050059a) (.leaf 0x1c401c4000000000050059a))) (.m (.m (.m (.leaf 0x1c501c5000000000050059a) (.leaf 0x1c601c6000000000050059a)) (.leaf 0x1c701c7000000000050059a)) (.m (.leaf 0x1c901c8000000000050059a) (.leaf 0x1ca01ca000000000050059a)))) (.leaf 0x1ca01be00000000001c959a)) (.leaf 0x1ca01be000000000017f59a)) (.leaf 0x1ca01be00000000000e859a)) (.leaf 0x1ca01be000000000004e59a)) (.leaf 0x1ca01be000000000000f59a)) (.leaf 0x1ca01be00000000000445b0)) (.leaf 0x1ca01be00000000000445b1)) (.leaf 0x1ca01be00000000000245b2)) (.leaf 0x1ca01be0000000000047730)) (by decide +kernel)

private theorem step208 : ProjectedGoal ⟨432, 458, 567, 1135, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 445 (by decide) (by decide) (step206 rates cones) (step207 rates cones)

private theorem step209 : ProjectedGoal ⟨459, 485, 567, 638, 0, 567⟩ :=
  projectedGoal_chunk _ (.y (.y (.y (.y (.y (.m (.m (.m (.m (.m (.leaf 0x1cb01cb000000000050059a) (.leaf 0x1cc01cc000000000050059a)) (.m (.leaf 0x1cd01cd000000000050059a) (.leaf 0x1ce01ce000000000050059a))) (.m (.m (.leaf 0x1cf01cf000000000050059a) (.leaf 0x1d001d0000000000050059a)) (.leaf 0x1d101d1000000000050059a))) (.m (.m (.leaf 0x1d301d2000000000050059a) (.leaf 0x1d501d4000000000050059a)) (.m (.leaf 0x1d701d6000000000050059a) (.leaf 0x1d801d8000000000050059a)))) (.m (.m (.m (.m (.leaf 0x1d901d9000000000050059a) (.leaf 0x1da01da000000000050059a)) (.m (.leaf 0x1db01db000000000050059a) (.leaf 0x1dc01dc000000000050059a))) (.m (.m (.leaf 0x1dd01dd000000000050059a) (.leaf 0x1de01de000000000050059a)) (.leaf 0x1df01df000000000050059a))) (.m (.m (.leaf 0x1e101e0000000000050059a) (.leaf 0x1e201e2000000000050059a)) (.m (.m (.leaf 0x1e301e3000000000050059a) (.leaf 0x1e401e4000000000050059a)) (.leaf 0x1e501e5000000000050059a))))) (.leaf 0x1e501cb00000000001c959a)) (.leaf 0x1e501cb000000000017f59a)) (.leaf 0x1e501cb00000000000e859a)) (.leaf 0x1e501cb000000000004e59a)) (.leaf 0x1e501cb000000000000f59a)) (by decide +kernel)

private theorem step210 : ProjectedGoal ⟨459, 485, 638, 709, 0, 567⟩ :=
  projectedGoal_chunk _ (.leaf 0x1e501cb00000000000445b0) (by decide +kernel)

private theorem step211 : ProjectedGoal ⟨459, 485, 567, 709, 0, 567⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 638 (by decide) (by decide) (step209 rates cones) (step210 rates cones)

private theorem step212 : ProjectedGoal ⟨459, 485, 709, 851, 0, 567⟩ :=
  projectedGoal_chunk _ (.leaf 0x1e501cb00000000000445b1) (by decide +kernel)

private theorem step213 : ProjectedGoal ⟨459, 485, 567, 851, 0, 567⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 709 (by decide) (by decide) (step211 rates cones) (step212 rates cones)

private theorem step214 : ProjectedGoal ⟨459, 485, 567, 851, 567, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0x1e501cb00000000000245b2) (by decide +kernel)

private theorem step215 : ProjectedGoal ⟨459, 485, 567, 851, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 567 (by decide) (by decide) (step213 rates cones) (step214 rates cones)

private theorem step216 : ProjectedGoal ⟨459, 485, 851, 1135, 0, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0x1e501cb0000000000047730) (by decide +kernel)

private theorem step217 : ProjectedGoal ⟨459, 485, 567, 1135, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 851 (by decide) (by decide) (step215 rates cones) (step216 rates cones)

private theorem step218 : ProjectedGoal ⟨432, 485, 567, 1135, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 458 (by decide) (by decide) (step208 rates cones) (step217 rates cones)

private theorem step219 : ProjectedGoal ⟨486, 499, 567, 1135, 0, 1135⟩ :=
  projectedGoal_chunk _ (.x (.y (.x (.x (.y (.y (.y (.y (.y (.m (.m (.m (.leaf 0x1e701e6000000000050059a) (.leaf 0x1e901e8000000000050059a)) (.m (.leaf 0x1eb01ea000000000050059a) (.leaf 0x1ec01ec000000000050059a))) (.m (.m (.m (.leaf 0x1ed01ed000000000050059a) (.leaf 0x1ee01ee000000000050059a)) (.m (.leaf 0x1ef01ef000000000050059a) (.leaf 0x1f001f0000000000050059a))) (.m (.m (.leaf 0x1f101f1000000000050059a) (.leaf 0x1f201f2000000000050059a)) (.leaf 0x1f301f3000000000050059a)))) (.leaf 0x1f301e600000000001c959a)) (.leaf 0x1f301e6000000000017f59a)) (.leaf 0x1f301e600000000000e859a)) (.leaf 0x1f301e6000000000004e59a)) (.leaf 0x1f301e6000000000000f59a)) (.leaf 0x1f301e600000000000445b0)) (.leaf 0x1f301e600000000000445b1)) (.leaf 0x1f301e600000000000245b2)) (.leaf 0x1f301e60000000000047730)) (by decide +kernel)

private theorem step220 : ProjectedGoal ⟨500, 512, 567, 1135, 0, 1135⟩ :=
  projectedGoal_chunk _ (.x (.y (.x (.x (.y (.y (.y (.y (.y (.m (.m (.m (.leaf 0x1f501f4000000000050059a) (.leaf 0x1f701f6000000000050059a)) (.m (.leaf 0x1f901f8000000000050059a) (.leaf 0x1fa01fa000000000050059a))) (.m (.m (.m (.leaf 0x1fb01fb000000000050059a) (.leaf 0x1fc01fc000000000050059a)) (.leaf 0x1fd01fd000000000050059a)) (.m (.leaf 0x1ff01fe000000000050059a) (.leaf 0x2000200000000000050059a)))) (.leaf 0x20001f400000000001c959a)) (.leaf 0x20001f4000000000017f59a)) (.leaf 0x20001f400000000000e859a)) (.leaf 0x20001f4000000000004e59a)) (.leaf 0x20001f4000000000000f59a)) (.leaf 0x20001f400000000000445b0)) (.leaf 0x20001f400000000000445b1)) (.leaf 0x20001f400000000000245b2)) (.leaf 0x20001f40000000000047730)) (by decide +kernel)

private theorem step221 : ProjectedGoal ⟨486, 512, 567, 1135, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 499 (by decide) (by decide) (step219 rates cones) (step220 rates cones)

private theorem step222 : ProjectedGoal ⟨513, 539, 567, 638, 0, 567⟩ :=
  projectedGoal_chunk _ (.y (.y (.y (.y (.y (.m (.m (.m (.m (.m (.leaf 0x2010201000000000050059a) (.leaf 0x2020202000000000050059a)) (.m (.leaf 0x2030203000000000050059a) (.leaf 0x2040204000000000050059a))) (.m (.m (.leaf 0x2050205000000000050059a) (.leaf 0x2060206000000000050059a)) (.leaf 0x2070207000000000050059a))) (.m (.m (.leaf 0x2090208000000000050059a) (.leaf 0x20b020a000000000050059a)) (.m (.leaf 0x20d020c000000000050059a) (.leaf 0x20e020e000000000050059a)))) (.m (.m (.m (.m (.leaf 0x20f020f000000000050059a) (.leaf 0x2100210000000000050059a)) (.m (.leaf 0x2110211000000000050059a) (.leaf 0x2120212000000000050059a))) (.m (.m (.leaf 0x2130213000000000050059a) (.leaf 0x2140214000000000050059a)) (.leaf 0x2150215000000000050059a))) (.m (.m (.leaf 0x2170216000000000050059a) (.leaf 0x2180218000000000050059a)) (.m (.m (.leaf 0x2190219000000000050059a) (.leaf 0x21a021a000000000050059a)) (.leaf 0x21b021b000000000050059a))))) (.leaf 0x21b020100000000001c959a)) (.leaf 0x21b0201000000000017f59a)) (.leaf 0x21b020100000000000e859a)) (.leaf 0x21b0201000000000004e59a)) (.leaf 0x21b0201000000000000f59a)) (by decide +kernel)

private theorem step223 : ProjectedGoal ⟨513, 539, 567, 638, 567, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0x21b0201000000000002459a) (by decide +kernel)

private theorem step224 : ProjectedGoal ⟨513, 539, 567, 638, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 567 (by decide) (by decide) (step222 rates cones) (step223 rates cones)

private theorem step225 : ProjectedGoal ⟨513, 539, 638, 709, 0, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0x21b020100000000000475b0) (by decide +kernel)

private theorem step226 : ProjectedGoal ⟨513, 539, 567, 709, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 638 (by decide) (by decide) (step224 rates cones) (step225 rates cones)

private theorem step227 : ProjectedGoal ⟨513, 539, 709, 851, 0, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0x21b020100000000000475b1) (by decide +kernel)

private theorem step228 : ProjectedGoal ⟨513, 539, 567, 851, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 709 (by decide) (by decide) (step226 rates cones) (step227 rates cones)

private theorem step229 : ProjectedGoal ⟨513, 539, 851, 1135, 0, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0x21b02010000000000047730) (by decide +kernel)

private theorem step230 : ProjectedGoal ⟨513, 539, 567, 1135, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 851 (by decide) (by decide) (step228 rates cones) (step229 rates cones)

private theorem step231 : ProjectedGoal ⟨486, 539, 567, 1135, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 512 (by decide) (by decide) (step221 rates cones) (step230 rates cones)

private theorem step232 : ProjectedGoal ⟨432, 539, 567, 1135, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 485 (by decide) (by decide) (step218 rates cones) (step231 rates cones)

theorem Part00019 : ProjectedGoal ⟨432, 539, 567, 1135, 0, 1135⟩ := step232

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
