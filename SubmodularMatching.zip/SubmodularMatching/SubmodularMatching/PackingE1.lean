import SubmodularMatching.PackingResourcesBounds
import Mathlib.Data.Nat.Log
import Mathlib.Data.Rat.Floor

/-! # A dyadic, finite entry point for Lemma E.1 -/

namespace SubmodularMatching.LinearPacking

open scoped BigOperators

/-- The coarsest permitted reciprocal power of two. -/
noncomputable def packingAccuracyBits (epsilon : ℝ) : ℕ := Nat.clog 2 ⌈1 / epsilon⌉₊

/-- The same preparation for a supplied rational tolerance. -/
def rationalPackingAccuracyBits (epsilon : ℚ) : ℕ :=
  Nat.clog 2 ⌈(1 : ℚ) / epsilon⌉.toNat

theorem rationalPackingAccuracyBits_eq (epsilon : ℚ) :
    rationalPackingAccuracyBits epsilon = packingAccuracyBits (epsilon : ℝ) := by
  unfold rationalPackingAccuracyBits packingAccuracyBits
  rw [← Int.ceil_toNat]
  have hcast : (((1 : ℚ) / epsilon : ℚ) : ℝ) = 1 / (epsilon : ℝ) := by simp
  rw [← hcast, Rat.ceil_cast]

/-- The scale depends on the magnitude of the tolerance, including when
its original rational denominator is large. -/
theorem packingAccuracyBits_bounds (epsilon : ℝ) (he : 0 < epsilon) (he1 : epsilon ≤ 1) :
    let bits := packingAccuracyBits epsilon
    epsilon / 2 < 1 / (2 : ℝ) ^ bits ∧ 1 / (2 : ℝ) ^ bits ≤ epsilon := by
  intro bits
  have H : ⌈1 / epsilon⌉₊ ≤ 2 ^ bits := Nat.le_pow_clog (by decide) _
  have hp : (0 : ℝ) < 2 ^ bits := by positivity
  have hu : 1 / epsilon ≤ (2 : ℝ) ^ bits :=
    (Nat.ceil_le.mp H).trans_eq (by push_cast; rfl)
  refine ⟨?_, (div_le_iff₀ hp).mpr ?_⟩
  · cases hb : bits with
    | zero => simp only [pow_zero, div_one]; linarith only [he1]
    | succ j =>
      have hlt : j < Nat.clog 2 ⌈1 / epsilon⌉₊ := by
        change j < bits
        rw [hb]
        exact Nat.lt_succ_self _
      have hn : (2 : ℕ) ^ j < ⌈1 / epsilon⌉₊ := Nat.pow_lt_of_lt_clog hlt
      have hr : (2 : ℝ) ^ j < 1 / epsilon := by
        simpa only [Nat.cast_pow, Nat.cast_ofNat] using (Nat.lt_ceil.mp hn)
      have hr' := (lt_div_iff₀ he).mp hr
      rw [pow_succ]
      apply (lt_div_iff₀ (by positivity : (0 : ℝ) < 2 ^ j * 2)).mpr
      nlinarith only [hr']
  · simpa only [mul_comm epsilon] using (div_le_iff₀ he).mp hu

theorem packingAccuracyScale_bounds (epsilon : ℝ) (he : 0 < epsilon) (he1 : epsilon ≤ 1) :
    let bits := packingAccuracyBits epsilon
    (2 : ℝ) ^ bits < 2 / epsilon := by
  intro bits
  have h := (packingAccuracyBits_bounds epsilon he he1).1
  have h' := (lt_div_iff₀ (by positivity : (0 : ℝ) < 2 ^ bits)).mp h
  apply (lt_div_iff₀ he).mpr
  nlinarith only [h']

section

variable {Row Col : Type*} [Fintype Row] [Fintype Col]

/-- The response compares each objective coefficient at its own
denominator. No common coefficient grid is used. -/
def columnwiseAction (A : Row → Col → ℤ) (c : Col → ℚ)
    (dual : Row → ℤ) (P Q : ℕ) (i : Col) : ℕ :=
  integerAction A (fun j => (c j).num) dual P Q (c i).den i

def columnwiseStep (A : Row → Col → ℤ) (c : Col → ℚ) (Q P R : ℕ)
    (state : PackingArrays Row Col) : PackingArrays Row Col :=
  let take := columnwiseAction A c state.dual P Q
  ⟨fun h => min ((P : ℤ) * R) (max 0 (state.dual h +
      ((∑ i, A h i * (take i : ℤ)) - Q))),
    fun i => state.accumulator i + take i⟩

def columnwiseRun (A : Row → Col → ℤ) (c : Col → ℚ) (Q P R : ℕ) :
    ℕ → PackingArrays Row Col
  | 0 => ⟨fun _ => 0, fun _ => 0⟩
  | j + 1 => columnwiseStep A c Q P R (columnwiseRun A c Q P R j)

omit [Fintype Col] in
theorem columnwiseAction_le_one (A : Row → Col → ℤ) (c : Col → ℚ)
    (dual : Row → ℤ) (P Q : ℕ) (i : Col) : columnwiseAction A c dual P Q i ≤ 1 := by
  unfold columnwiseAction integerAction
  split_ifs <;> omega

omit [Fintype Col] in
theorem columnwiseAction_eq (A : Row → Col → ℤ) (c : Col → ℚ) (U : Row → ℤ)
    (P Q : ℕ) (hP : 0 < P) (hQ : 0 < Q) (i : Col) :
    (columnwiseAction A c U P Q i : ℝ) =
      action (fun h j => (A h j : ℝ) / Q) (fun j => (c j : ℝ)) (fun h => (U h : ℝ) / P) i := by
  unfold columnwiseAction
  have hi := integerAction_eq A (fun j => (c j).num) U P Q (c i).den hP hQ (c i).den_pos i
  simpa only [action, Rat.cast_def (c i)] using hi

theorem columnwiseStep_dual_eq (A : Row → Col → ℤ) (c : Col → ℚ)
    (P Q R : ℕ) (hP : 0 < P) (hQ : 0 < Q)
    (state : PackingArrays Row Col) (h : Row) :
    ((columnwiseStep A c Q P R state).dual h : ℝ) / P =
      dualStep (fun h i => (A h i : ℝ) / Q) (fun i => (c i : ℝ))
        R ((Q : ℝ) / P) (fun h => (state.dual h : ℝ) / P) h := by
  have hP' : (0 : ℝ) < P := by exact_mod_cast hP
  have hQ' : (0 : ℝ) < Q := by exact_mod_cast hQ
  simp only [columnwiseStep, Int.cast_min, Int.cast_max, Int.cast_zero, Int.cast_mul,
    Int.cast_natCast, Int.cast_add, Int.cast_sub, Int.cast_sum]
  simp_rw [columnwiseAction_eq A c state.dual P Q hP hQ]
  unfold dualStep clip load
  rw [← min_div_div_right hP'.le, ← max_div_div_right hP'.le, zero_div,
    mul_div_cancel_left₀ _ hP'.ne']
  simp_rw [div_mul_eq_mul_div]
  rw [← Finset.sum_div]
  apply congrArg (fun x : ℝ => min (R : ℝ) (max 0 x))
  field_simp

theorem columnwiseRun_eq (A : Row → Col → ℤ) (c : Col → ℚ)
    (P Q R : ℕ) (hP : 0 < P) (hQ : 0 < Q) (j : ℕ) :
    let A' := fun h i => (A h i : ℝ) / Q
    let c' := fun i => (c i : ℝ)
    let eta := (Q : ℝ) / P
    let state := columnwiseRun A c Q P R j
    (∀ h, (state.dual h : ℝ) / P = dual A' c' R eta j h) ∧
      ∀ i, (state.accumulator i : ℝ) = ∑ s ∈ Finset.range j, action A' c' (dual A' c' R eta s) i := by
  dsimp only
  induction j with
  | zero => simp [columnwiseRun, dual]
  | succ j ih =>
    let state := columnwiseRun A c Q P R j
    have hu : (fun h => (state.dual h : ℝ) / P) =
        dual (fun h i => (A h i : ℝ) / Q) (fun i => (c i : ℝ)) R ((Q : ℝ) / P) j :=
      funext ih.1
    constructor
    · intro h
      rw [columnwiseRun, columnwiseStep_dual_eq A c P Q R hP hQ state h, hu, dual]
    · intro i
      rw [columnwiseRun, columnwiseStep, Nat.cast_add, ih.2, Finset.sum_range_succ]
      rw [columnwiseAction_eq A c state.dual P Q hP hQ, hu]

/-- The persistent numerators have magnitudes at most `P·R` and the
number of completed iterations, including at intermediate steps. -/
theorem columnwiseRun_bounds (A : Row → Col → ℤ) (c : Col → ℚ)
    (P Q R : ℕ) (hP : 0 < P) (hQ : 0 < Q) (j : ℕ) :
    let state := columnwiseRun A c Q P R j
    (∀ h, 0 ≤ state.dual h ∧ (state.dual h).natAbs ≤ P * R) ∧
      (∀ i, state.accumulator i ≤ j) := by
  intro state
  let A' := fun h i => (A h i : ℝ) / Q
  let c' := fun i => (c i : ℝ)
  let eta := (Q : ℝ) / P
  have h := columnwiseRun_eq A c P Q R hP hQ j
  have hP' : (0 : ℝ) < P := by exact_mod_cast hP
  constructor
  · intro row
    have he : (state.dual row : ℝ) / P = dual A' c' R eta j row := h.1 row
    have hb := dual_bounds A' c' (eta := eta) (Nat.cast_nonneg R) j row
    rw [← he] at hb
    have hlo := (le_div_iff₀ hP').mp hb.1
    have hhi := (div_le_iff₀ hP').mp hb.2
    have hlo' : 0 ≤ state.dual row := by exact_mod_cast (show (0 : ℝ) ≤ (state.dual row : ℝ) by simpa using hlo)
    have hhi' : state.dual row ≤ (P * R : ℕ) := by
      exact_mod_cast (show (state.dual row : ℝ) ≤ (P : ℝ) * R by simpa only [mul_comm] using hhi)
    refine ⟨hlo', ?_⟩
    exact_mod_cast ((Int.natAbs_of_nonneg hlo').symm ▸ hhi')
  · intro i
    obtain ⟨b, hb, he⟩ := accumulated_action_numerator A' c' R eta j i
    have hi : (state.accumulator i : ℝ) = b := (h.2 i).trans he
    exact (show state.accumulator i = b by exact_mod_cast hi).le.trans hb

omit [Fintype Col] in
/-- Both exact comparison operands fit one fixed polynomial-size word
plus the bits of the current coefficient's denominator. -/
theorem columnwiseAction_operand_width (A : Row → Col → ℤ) (c : Col → ℚ)
    (U : Row → ℤ) (P Q R : ℕ)
    (hA : ∀ h i, 0 ≤ A h i ∧ A h i ≤ (Q : ℤ))
    (hU : ∀ h, 0 ≤ U h ∧ U h ≤ ((P * R : ℕ) : ℤ))
    (i : Col) (hc : 0 ≤ c i ∧ c i ≤ 1) :
    let d := (c i).den
    let B := (Fintype.card Row + 1) * Q * P * (R + 1)
    let W := (d.log2 + 1) + (B.log2 + 1)
    ((d : ℤ) * ∑ h, A h i * U h).natAbs < 2 ^ W ∧
      ((c i).num * (P : ℤ) * (Q : ℤ)).natAbs < 2 ^ W := by
  intro d B W
  let M := Fintype.card Row
  let X : ℤ := ∑ h, A h i * U h
  have hX0 : 0 ≤ X := Finset.sum_nonneg (fun h _ => mul_nonneg (hA h i).1 (hU h).1)
  have hX : X ≤ (M * Q * (P * R) : ℕ) := by
    calc
      _ ≤ ∑ _ : Row, (Q : ℤ) * ((P * R : ℕ) : ℤ) :=
        Finset.sum_le_sum (fun h _ => mul_le_mul (hA h i).2 (hU h).2 (hU h).1 (by positivity))
      _ = _ := by
        simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, M, Int.natCast_mul]
        ring
  have hX' : X.natAbs ≤ M * Q * (P * R) := by
    exact_mod_cast ((Int.natAbs_of_nonneg hX0).symm ▸ hX)
  have hB₁ : M * Q * (P * R) ≤ B := by
    calc
      _ = M * Q * P * R := by ring
      _ ≤ _ := Nat.mul_le_mul
        (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (Nat.le_succ _))) (Nat.le_succ _)
  have hB₂ : P * Q ≤ B := by
    calc
      _ = 1 * Q * P * 1 := by ring
      _ ≤ _ := Nat.mul_le_mul
        (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by omega : 1 ≤ M + 1))) (by omega)
  have hd : (0 : ℝ) < d := by exact_mod_cast (c i).den_pos
  have hNum0 := Rat.num_nonneg.mpr hc.1
  have hNum : (c i).num ≤ (d : ℤ) := by
    have hn : ((c i).num : ℝ) ≤ (d : ℝ) := by
      apply (div_le_one hd).mp
      change ((c i).num : ℝ) / ((c i).den : ℝ) ≤ 1
      rw [← Rat.cast_def]
      exact_mod_cast hc.2
    exact_mod_cast hn
  have hNum' : (c i).num.natAbs ≤ d := by
    exact_mod_cast ((Int.natAbs_of_nonneg hNum0).symm ▸ hNum)
  have hPow : d * B < 2 ^ W := by
    dsimp only [W]
    rw [pow_add]
    exact Nat.mul_lt_mul_of_lt_of_lt Nat.lt_log2_self Nat.lt_log2_self
  constructor
  · rw [Int.natAbs_mul, Int.natAbs_natCast]
    exact (Nat.mul_le_mul_left _ (hX'.trans hB₁)).trans_lt hPow
  · rw [Int.natAbs_mul, Int.natAbs_mul, Int.natAbs_natCast, Int.natAbs_natCast, Nat.mul_assoc]
    exact (Nat.mul_le_mul hNum' hB₂).trans_lt hPow

omit [Fintype Row] in
/-- The forward multiplication, signed residual, and pre-clipping dual
update also stay on the polynomial integer scale. -/
theorem columnwiseUpdate_operand_bounds (A : Row → Col → ℤ)
    (take : Col → ℕ) (U : Row → ℤ) (P Q R : ℕ) (h : Row)
    (hA : ∀ i, 0 ≤ A h i ∧ A h i ≤ (Q : ℤ)) (htake : ∀ i, take i ≤ 1)
    (hU : 0 ≤ U h ∧ U h ≤ ((P * R : ℕ) : ℤ)) :
    let N := Fintype.card Col
    let X : ℤ := ∑ i, A h i * (take i : ℤ)
    X.natAbs ≤ N * Q ∧ (X - (Q : ℤ)).natAbs ≤ (N + 1) * Q ∧
      (U h + (X - (Q : ℤ))).natAbs ≤ P * R + (N + 1) * Q := by
  intro N X
  have hX0 : 0 ≤ X := Finset.sum_nonneg (fun i _ => mul_nonneg (hA i).1 (by positivity))
  have hX : X ≤ (N * Q : ℕ) := by
    calc
      _ ≤ ∑ _ : Col, (Q : ℤ) := Finset.sum_le_sum (fun i _ => by
        have ht : (take i : ℤ) ≤ 1 := by exact_mod_cast htake i
        exact (mul_le_of_le_one_right (hA i).1 ht).trans (hA i).2)
      _ = _ := by simp [N]
  have hX' : X.natAbs ≤ N * Q := by
    exact_mod_cast ((Int.natAbs_of_nonneg hX0).symm ▸ hX)
  have hU' : (U h).natAbs ≤ P * R := by
    exact_mod_cast ((Int.natAbs_of_nonneg hU.1).symm ▸ hU.2)
  have hr : (X - (Q : ℤ)).natAbs ≤ (N + 1) * Q := by
    have hs := Int.natAbs_sub_le X (Q : ℤ)
    simp only [Int.natAbs_natCast] at hs
    exact hs.trans ((Nat.add_le_add_right hX' Q).trans_eq (by ring))
  exact ⟨hX', hr, (Int.natAbs_add_le _ _).trans (Nat.add_le_add hU' hr)⟩

/-- At reciprocal-integer accuracy, both ceilings in PK2 have rational
arguments that are already integers. -/
def packingRadiusNat (N scale : ℕ) : ℕ := 4 * N ^ 2 * scale

def packingIterationsNat (M N scale : ℕ) : ℕ := 64 * M ^ 2 * N ^ 6 * scale ^ 4

/-- Polynomial bounds for the clipped dual scale, the transpose scan
comparison base, and the rational output denominator. -/
theorem packingE1_word_caps (M N Q b : ℕ) (hM : 0 < M) (hN : 0 < N) (hb : 0 < b) :
    let P := 2 * b * M * N ^ 2 * Q
    let R := packingRadiusNat N b
    let J := packingIterationsNat M N b
    P * R = 8 * M * N ^ 4 * Q * b ^ 2 ∧
      (M + 1) * Q * P * (R + 1) ≤ 20 * M ^ 2 * N ^ 4 * Q ^ 2 * b ^ 2 ∧
      J * (2 * N * b + 1) ≤ 192 * M ^ 2 * N ^ 7 * b ^ 5 := by
  intro P R J
  have hNb : 1 ≤ N * b := Nat.mul_pos hN hb
  have hNb2 : 1 ≤ N ^ 2 * b := Nat.mul_pos (pow_pos hN 2) hb
  have hM' : M + 1 ≤ 2 * M := by omega
  have hR : R + 1 ≤ 5 * N ^ 2 * b := by
    unfold R packingRadiusNat
    calc
      _ ≤ 4 * N ^ 2 * b + N ^ 2 * b := Nat.add_le_add_left hNb2 _
      _ = _ := by ring
  have hEnd : 2 * N * b + 1 ≤ 3 * N * b := by
    calc
      _ ≤ 2 * N * b + N * b := Nat.add_le_add_left hNb _
      _ = _ := by ring
  refine ⟨by dsimp only [P, R, packingRadiusNat]; ring, ?_, ?_⟩
  · calc
      _ ≤ (2 * M) * Q * P * (5 * N ^ 2 * b) :=
        Nat.mul_le_mul (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ hM')) hR
      _ = _ := by dsimp only [P]; ring
  · calc
      _ ≤ J * (3 * N * b) := Nat.mul_le_mul_left _ hEnd
      _ = _ := by dsimp only [J, packingIterationsNat]; ring

theorem packingRadiusNat_eq (N scale : ℕ) :
    radius N (1 / (scale : ℝ)) = packingRadiusNat N scale := by
  unfold radius
  rw [div_div_eq_mul_div, div_one]
  have h : 4 * (N : ℝ) ^ 2 * scale = (packingRadiusNat N scale : ℝ) := by
    unfold packingRadiusNat
    push_cast
    rfl
  rw [h, Nat.ceil_natCast]

theorem packingIterationsNat_eq (M N scale : ℕ) (hM : 0 < M) (hN : 0 < N) (hs : 0 < scale) :
    iterationCount M N (1 / (scale : ℝ)) = packingIterationsNat M N scale := by
  have hMr : (M : ℝ) ≠ 0 := by exact_mod_cast hM.ne'
  have hNr : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  have hsr : (scale : ℝ) ≠ 0 := by exact_mod_cast hs.ne'
  unfold iterationCount
  rw [packingRadiusNat_eq N scale]
  have h : 2 * (packingRadiusNat N scale : ℝ) ^ 2 * M /
      (stepSize M N (1 / (scale : ℝ)) * (1 / (scale : ℝ))) =
        (packingIterationsNat M N scale : ℝ) := by
    unfold packingRadiusNat packingIterationsNat stepSize
    push_cast
    field_simp [hMr, hNr, hsr]
    ring
  rw [h, Nat.ceil_natCast]

/-- Executable rational packing with a matrix represented on the supplied
shared grid and with independently encoded rational coefficients. -/
def packingE1Solve (A : Row → Col → ℤ) (Q : ℕ) (c : Col → ℚ) (epsilon : ℚ) (i : Col) : ℚ :=
  let M := Fintype.card Row
  let N := Fintype.card Col
  let b := 2 ^ rationalPackingAccuracyBits epsilon
  let P := 2 * b * M * N ^ 2 * Q
  let R := packingRadiusNat N b
  let J := packingIterationsNat M N b
  let state := columnwiseRun A c Q P R J
  ((state.accumulator i * (2 * N * b) : ℕ) : ℚ) / ((J * (2 * N * b + 1) : ℕ) : ℚ)

noncomputable section

/-- The executable entry point denotes the exact mathematical packing
solution at the dyadic accuracy chosen by the preprocessor. -/
theorem packingE1Solve_eq (A : Row → Col → ℤ) (Q : ℕ) (hQ : 0 < Q)
    (c : Col → ℚ) (epsilon : ℚ) (hM : 0 < Fintype.card Row) (hN : 0 < Fintype.card Col)
    (i : Col) :
    (packingE1Solve A Q c epsilon i : ℝ) =
      solve (fun h j => (A h j : ℝ) / Q) (fun j => (c j : ℝ))
        (1 / (2 : ℝ) ^ packingAccuracyBits (epsilon : ℝ)) i := by
  let M := Fintype.card Row
  let N := Fintype.card Col
  let bits := rationalPackingAccuracyBits epsilon
  let b := (2 : ℕ) ^ bits
  let P := 2 * b * M * N ^ 2 * Q
  let R := packingRadiusNat N b
  let J := packingIterationsNat M N b
  let state := columnwiseRun A c Q P R J
  let A' := fun h j => (A h j : ℝ) / Q
  let c' := fun j => (c j : ℝ)
  let e := (1 : ℝ) / (b : ℝ)
  have hb : 0 < b := by dsimp [b]; positivity
  have hb' : (0 : ℝ) < b := by exact_mod_cast hb
  have hP : 0 < P := by dsimp only [P]; positivity
  have hMr : (0 : ℝ) < M := by exact_mod_cast hM
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have hQr : (0 : ℝ) < Q := by exact_mod_cast hQ
  have heq : 1 / (2 : ℝ) ^ bits = e := by dsimp only [e, b]; push_cast; rfl
  have hR : radius N e = (R : ℝ) := packingRadiusNat_eq N b
  have hJ : iterationCount M N e = J := packingIterationsNat_eq M N b hM hN hb
  have hJ' : (0 : ℝ) < J := by
    have : 0 < J := by dsimp only [J, packingIterationsNat]; positivity
    exact_mod_cast this
  have heta : (Q : ℝ) / P = stepSize M N e := by
    unfold stepSize
    dsimp only [P, e]
    push_cast
    field_simp
  have h := (columnwiseRun_eq A c P Q R hP hQ J).2 i
  change (state.accumulator i : ℝ) =
    ∑ j ∈ Finset.range J, action A' c' (dual A' c' R ((Q : ℝ) / P) j) i at h
  rw [heta] at h
  unfold packingE1Solve
  simp only [Rat.cast_div, Rat.cast_natCast, ← rationalPackingAccuracyBits_eq epsilon]
  change (((state.accumulator i * (2 * N * b) : ℕ) : ℝ)) / (J * (2 * N * b + 1) : ℕ) =
    solve A' c' (1 / (2 : ℝ) ^ bits) i
  rw [heq]
  change _ = (((∑ j ∈ Finset.range (iterationCount M N e),
    action A' c' (dual A' c' (radius N e) (stepSize M N e) j) i) /
      iterationCount M N e) / (1 + rescaling N e))
  rw [hJ, hR, ← h, rescaling]
  push_cast
  dsimp only [e]
  field_simp

/-- The real arithmetic solver at the preprocessed tolerance satisfies
the requested tolerance, with one matrix grid and one output grid. -/
theorem packingE1_entry (A : Row → Col → ℝ) (c : Col → ℝ)
    (epsilon : ℝ) (he : 0 < epsilon) (he1 : epsilon ≤ 1)
    (Q : ℕ) (hAgrid : ∀ h i, OnGrid Q (A h i))
    (hA : ∀ h i, 0 ≤ A h i ∧ A h i ≤ 1) (hc : ∀ i, 0 ≤ c i ∧ c i ≤ 1)
    (hM : 0 < Fintype.card Row) (hN : 0 < Fintype.card Col) :
    let M := Fintype.card Row
    let N := Fintype.card Col
    let bits := packingAccuracyBits epsilon
    let e := 1 / (2 : ℝ) ^ bits
    let J := iterationCount M N e
    let R := packingRadiusNat N (2 ^ bits)
    let P := dualDenominator M N Q bits
    let y := solve A c e
    epsilon / 2 < e ∧ e ≤ epsilon ∧
      (∀ i, 0 ≤ y i ∧ y i ≤ 1) ∧ (∀ h, load A y h ≤ 1) ∧
      (∀ t : Col → ℝ, (∀ i, 0 ≤ t i ∧ t i ≤ 1) → (∀ h, load A t h ≤ 1) →
        objective c t - epsilon ≤ objective c y) ∧
      (∀ i, OnGrid (outputDenominator M N bits) (y i)) ∧
      (∀ j h, ∃ u : ℕ, u ≤ P * R ∧
        (P : ℝ) * dual A c R (stepSize M N e) j h = u) ∧
      (J : ℝ) ≤ 1600 * (M : ℝ) ^ 2 * (N : ℝ) ^ 6 / epsilon ^ 4 + 1 := by
  intro M N bits e J R P y
  obtain ⟨heL, heU⟩ := packingAccuracyBits_bounds epsilon he he1
  change epsilon / 2 < e at heL
  change e ≤ epsilon at heU
  have he' : 0 < e := by dsimp [e]; positivity
  have hR : radius N e = (R : ℝ) := by
    have h := packingRadiusNat_eq N ((2 : ℕ) ^ bits)
    simpa only [Nat.cast_pow, Nat.cast_ofNat, e, R] using h
  obtain ⟨hy, hload, happ⟩ := solve_correct A c e hA hc hM hN he' (heU.trans he1)
  refine ⟨heL, heU, hy, hload, ?_, solve_output_grid A c bits hM hN, ?_, ?_⟩
  · intro t ht htA
    exact (sub_le_sub_left heU _).trans (happ t ht htA)
  · intro j h
    have hf := solve_dual_index_bound A c Q bits hM hN hAgrid j h
    change ∃ u : ℕ, u ≤ P * (⌈4 * (N : ℝ) ^ 2 / e⌉₊ : ℕ) ∧
      (P : ℝ) * dual A c (radius N e) (stepSize M N e) j h = u at hf
    have hNat : ⌈4 * (N : ℝ) ^ 2 / e⌉₊ = R := by
      change (↑⌈4 * (N : ℝ) ^ 2 / e⌉₊ : ℝ) = (R : ℝ) at hR
      exact_mod_cast hR
    rw [hNat, hR] at hf
    exact hf
  · calc
      (J : ℝ) ≤ 100 * (M : ℝ) ^ 2 * (N : ℝ) ^ 6 / e ^ 4 + 1 :=
        iterationCount_polynomial M N e hM hN he' (heU.trans he1)
      _ ≤ 100 * (M : ℝ) ^ 2 * (N : ℝ) ^ 6 / (epsilon / 2) ^ 4 + 1 := by
        exact add_le_add
          (div_le_div_of_nonneg_left (by positivity) (by positivity)
            (pow_le_pow_left₀ (by positivity : 0 ≤ epsilon / 2) heL.le 4)) le_rfl
      _ = _ := by ring

/-- Correctness of the rational implementation for the arbitrary supplied
accuracy, against every feasible packing. -/
theorem packingE1Solve_correct (A : Row → Col → ℤ) (Q : ℕ) (hQ : 0 < Q)
    (c : Col → ℚ) (epsilon : ℚ) (he : 0 < epsilon) (he1 : epsilon ≤ 1)
    (hM : 0 < Fintype.card Row) (hN : 0 < Fintype.card Col)
    (hA : ∀ h i, 0 ≤ A h i ∧ A h i ≤ (Q : ℤ))
    (hc : ∀ i, 0 ≤ c i ∧ c i ≤ 1) :
    let A' := fun h i => (A h i : ℝ) / Q
    let c' := fun i => (c i : ℝ)
    let y := fun i => (packingE1Solve A Q c epsilon i : ℝ)
    (∀ i, 0 ≤ y i ∧ y i ≤ 1) ∧ (∀ h, load A' y h ≤ 1) ∧
      ∀ t : Col → ℝ, (∀ i, 0 ≤ t i ∧ t i ≤ 1) → (∀ h, load A' t h ≤ 1) →
        objective c' t - (epsilon : ℝ) ≤ objective c' y := by
  intro A' c' y
  have hQ' : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hA' (h : Row) (i : Col) : 0 ≤ A' h i ∧ A' h i ≤ 1 := by
    exact ⟨div_nonneg (by exact_mod_cast (hA h i).1) hQ'.le,
      (div_le_one hQ').mpr (by exact_mod_cast (hA h i).2)⟩
  have hc' (i : Col) : 0 ≤ c' i ∧ c' i ≤ 1 := by
    dsimp only [c']
    exact ⟨by exact_mod_cast (hc i).1, by exact_mod_cast (hc i).2⟩
  have hgrid (h : Row) (i : Col) : OnGrid Q (A' h i) := by
    refine ⟨A h i, ?_⟩
    dsimp only [A']
    rw [← mul_div_assoc, mul_div_cancel_left₀ _ hQ'.ne']
  have h := packingE1_entry A' c' (epsilon : ℝ) (by exact_mod_cast he) (by exact_mod_cast he1)
    Q hgrid hA' hc' hM hN
  have hy : y = solve A' c' (1 / (2 : ℝ) ^ packingAccuracyBits (epsilon : ℝ)) :=
    funext (packingE1Solve_eq A Q hQ c epsilon hM hN)
  rw [hy]
  exact ⟨h.2.2.1, h.2.2.2.1, h.2.2.2.2.1⟩

end

end

section

variable {M N : ℕ}

/-- Materialized solver arrays on compact row and column identifiers. -/
structure PackingE1Vectors (M N : ℕ) where
  dual : Vector ℤ M
  accumulator : Vector ℕ N

def PackingE1Vectors.decode (state : PackingE1Vectors M N) : PackingArrays (Fin M) (Fin N) :=
  ⟨fun h => state.dual[h.val]'h.isLt, fun i => state.accumulator[i.val]'i.isLt⟩

def packingE1VectorZero (M N : ℕ) : PackingE1Vectors M N :=
  ⟨Vector.replicate M 0, Vector.replicate N 0⟩

def packingE1Decisions (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q P : ℕ)
    (state : PackingE1Vectors M N) : Vector ℕ N :=
  Vector.ofFn (columnwiseAction A c state.decode.dual P Q)

/-- Retain the binary decision vector once, then materialize the updated
arrays. The matrix remains an input lookup. -/
def packingE1VectorStep (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q P R : ℕ)
    (state : PackingE1Vectors M N) : PackingE1Vectors M N :=
  let decided := packingE1Decisions A c Q P state
  let take := fun (i : Fin N) => decided[i.val]'i.isLt
  ⟨Vector.ofFn (fun h => min ((P : ℤ) * R) (max 0 (state.decode.dual h +
      ((∑ i, A h i * (take i : ℤ)) - Q)))),
    Vector.ofFn (fun i => state.decode.accumulator i + take i)⟩

theorem packingE1VectorStep_decode (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q P R : ℕ)
    (state : PackingE1Vectors M N) :
    (packingE1VectorStep A c Q P R state).decode = columnwiseStep A c Q P R state.decode := by
  simp [packingE1VectorStep, packingE1Decisions, PackingE1Vectors.decode, columnwiseStep]

/-- The finite solver overwrites its state in a tail-recursive loop. -/
def packingE1VectorLoop (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q P R : ℕ) :
    ℕ → PackingE1Vectors M N → PackingE1Vectors M N
  | 0, state => state
  | j + 1, state => packingE1VectorLoop A c Q P R j (packingE1VectorStep A c Q P R state)

theorem packingE1VectorLoop_decode (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q P R j : ℕ)
    (state : PackingE1Vectors M N) :
    (packingE1VectorLoop A c Q P R j state).decode =
      (columnwiseStep A c Q P R)^[j] state.decode := by
  induction j generalizing state with
  | zero => rfl
  | succ j ih =>
    rw [packingE1VectorLoop, ih, packingE1VectorStep_decode, Function.iterate_succ_apply]

theorem packingE1VectorRun_decode (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q P R j : ℕ) :
    (packingE1VectorLoop A c Q P R j (packingE1VectorZero M N)).decode =
      columnwiseRun A c Q P R j := by
  rw [packingE1VectorLoop_decode]
  induction j with
  | zero => simp [packingE1VectorZero, PackingE1Vectors.decode, columnwiseRun]
  | succ j ih => rw [Function.iterate_succ_apply', ih, columnwiseRun]

/-- Even keeping both the old and new arrays during an update only
requires two row arrays and three column arrays, apart from scalar scratch. -/
theorem packingE1VectorStep_cells (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q P R : ℕ)
    (before : PackingE1Vectors M N) :
    let response := packingE1Decisions A c Q P before
    let after := packingE1VectorStep A c Q P R before
    before.dual.toArray.size + before.accumulator.toArray.size +
      response.toArray.size + after.dual.toArray.size + after.accumulator.toArray.size =
        2 * M + 3 * N := by
  simp only [Vector.size_toArray]
  omega

/-- Executable array output from a single packing run. -/
def packingE1VectorSolve (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q : ℕ)
    (epsilon : ℚ) : Vector ℚ N :=
  let b := 2 ^ rationalPackingAccuracyBits epsilon
  let P := 2 * b * M * N ^ 2 * Q
  let R := packingRadiusNat N b
  let J := packingIterationsNat M N b
  let state := packingE1VectorLoop A c Q P R J (packingE1VectorZero M N)
  Vector.ofFn (fun i => ((state.decode.accumulator i * (2 * N * b) : ℕ) : ℚ) /
    ((J * (2 * N * b + 1) : ℕ) : ℚ))

theorem packingE1VectorSolve_get (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q : ℕ)
    (epsilon : ℚ) (i : Fin N) :
    (packingE1VectorSolve A c Q epsilon)[i.val]'i.isLt = packingE1Solve A Q c epsilon i := by
  simp [packingE1VectorSolve, packingE1Solve, packingE1VectorRun_decode]

/-- At each materialized iteration the two arrays satisfy the same
integer bounds as the abstract projected updates. -/
theorem packingE1VectorLoop_bounds (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q P R j : ℕ)
    (hQ : 0 < Q) (hP : 0 < P) :
    let out := packingE1VectorLoop A c Q P R j (packingE1VectorZero M N)
    (∀ h, 0 ≤ out.decode.dual h ∧ (out.decode.dual h).natAbs ≤ P * R) ∧
      ∀ i, out.decode.accumulator i ≤ j := by
  intro out
  have h : out.decode = columnwiseRun A c Q P R j := packingE1VectorRun_decode A c Q P R j
  rw [h]
  exact columnwiseRun_bounds A c P Q R hP hQ j

/-- The materialized implementation of Lemma E.1, at any rational
requested tolerance in `(0, 1]`. -/
theorem packingE1VectorSolve_correct (A : Fin M → Fin N → ℤ) (c : Fin N → ℚ) (Q : ℕ)
    (epsilon : ℚ) (he : 0 < epsilon) (he1 : epsilon ≤ 1)
    (hQ : 0 < Q) (hM : 0 < M) (hN : 0 < N)
    (hA : ∀ h i, 0 ≤ A h i ∧ A h i ≤ (Q : ℤ))
    (hc : ∀ i, 0 ≤ c i ∧ c i ≤ 1) :
    let A' := fun h i => (A h i : ℝ) / Q
    let c' := fun i => (c i : ℝ)
    let y := fun (i : Fin N) => ((packingE1VectorSolve A c Q epsilon)[i.val]'i.isLt : ℝ)
    (∀ i, 0 ≤ y i ∧ y i ≤ 1) ∧ (∀ h, load A' y h ≤ 1) ∧
      ∀ t : Fin N → ℝ, (∀ i, 0 ≤ t i ∧ t i ≤ 1) → (∀ h, load A' t h ≤ 1) →
        objective c' t - (epsilon : ℝ) ≤ objective c' y := by
  intro A' c' y
  have h : y = fun i => (packingE1Solve A Q c epsilon i : ℝ) := by
    funext i
    exact congrArg (fun z : ℚ => (z : ℝ)) (packingE1VectorSolve_get A c Q epsilon i)
  rw [h]
  exact packingE1Solve_correct A Q hQ c epsilon he he1 (by simpa) (by simpa) hA hc

end

end SubmodularMatching.LinearPacking
