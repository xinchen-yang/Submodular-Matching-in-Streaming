import SubmodularMatching.LowerBoundWitnessProbability
import Mathlib.Data.Finset.Max

/-! # Every supported instance has a large matching -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

variable {p N P t H : ℕ} {C : Type*} [Fintype C] [DecidableEq C] [AddCommGroup C]

/-- The slots in one clone block with a particular public label.
Such a fiber is a matching between clone indices. -/
def slotsAtLabel (S : Finset (C × C)) (label : C) : Finset (C × C) :=
  S.filter (fun e => e.2 - e.1 = label)

/-- Every clone block has a label with at least its average number of
edges. This supplies a deterministic matching-size witness, independently
of the hidden labels in the submodular objective. -/
theorem exists_label_class_ge_average (S : Finset (C × C)) :
    ∃ label : C, S.card ≤ Fintype.card C * (slotsAtLabel S label).card := by
  obtain ⟨label, _, hmax⟩ := Finset.exists_max_image (Finset.univ : Finset C)
    (fun o => (slotsAtLabel S o).card) Finset.univ_nonempty
  refine ⟨label, ?_⟩
  calc
    _ = ∑ o : C, (slotsAtLabel S o).card := by
      exact Finset.card_eq_sum_card_fiberwise (f := fun e : C × C => e.2 - e.1)
        (t := Finset.univ) (fun _ _ => Finset.mem_univ _)
    _ ≤ ∑ _o : C, (slotsAtLabel S label).card :=
      Finset.sum_le_sum hmax
    _ = _ := by simp

def bestSlotLabel (S : Finset (C × C)) : C :=
  Classical.choose (exists_label_class_ge_average S)

theorem bestSlotLabel_ge_average (S : Finset (C × C)) :
    S.card ≤ Fintype.card C * (slotsAtLabel S (bestSlotLabel S)).card :=
  Classical.choose_spec (exists_label_class_ge_average S)

omit [AddCommGroup C] in
/-- The actual law keeps one prescribed clone count above every potential
base pair. This includes every private leaf, whether or not it occurs. -/
theorem stageDraw_slot_card_of_pos (q : ℝ)
    (draw : StageDraw (PaddedPair N) (C × C) C) [Nonempty C]
    (hmass : 0 < stageDrawMass (allCloneSlots N C) q draw) (z : PaddedPair N) :
    (draw.1 z).card = retainedSize q (Fintype.card C ^ 2) := by
  have hm := (stageDrawMass_pos_iff (allCloneSlots N C) q draw).mp hmass
  have hz := Finset.prod_ne_zero_iff.mp (ne_of_gt hm) z (Finset.mem_univ z)
  unfold uniformSubsetMass at hz
  split_ifs at hz with h
  · simpa [allCloneSlots, Fintype.card_prod, pow_two] using (Finset.mem_powersetCard.mp h).2
  · exact (hz rfl).elim

omit [Fintype C] [DecidableEq C] [AddCommGroup C] in
theorem privateLeaves_isMatching (Q : PhaseSample N) (hQ : CloneLift.IsMatching Q) :
    CloneLift.IsMatching (privateLeaves Q) := by
  simpa [baseWitness] using baseWitness_isMatching Q ∅ hQ

omit [Fintype C] [DecidableEq C] [AddCommGroup C] in
def stagePairSlot (z : Fin p × PaddedPair N) : (C × C) ↪ HardEdge p N C where
  toFun c := (z.1, z.2, c)
  inj' := by
    intro a b h
    exact congrArg (fun e : HardEdge p N C => e.2.2) h

/-- The stage-tagged private-leaf blocks in a full realization. -/
def hardLeafBlocks (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C) :
    Finset (Fin p × PaddedPair N) :=
  taggedSample (fun j => privateLeaves (b.canonical (draw.1 j).1))

theorem hardLeafBlocks_card (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C) :
    (hardLeafBlocks b draw).card = p * (2 * (N - H)) := by
  calc
    (hardLeafBlocks b draw).card =
        ∑ j : Fin p, ((hardLeafBlocks b draw).filter (fun z => z.1 = j)).card :=
      Finset.card_eq_sum_card_fiberwise (f := Prod.fst) (t := Finset.univ)
        (fun x _ => (Finset.mem_univ x.1 : x.1 ∈ (Finset.univ : Finset (Fin p))))
    _ = ∑ j : Fin p, (privateLeaves (b.canonical (draw.1 j).1)).card := by
      apply Finset.sum_congr rfl
      intro j _
      let emb : PaddedPair N ↪ Fin p × PaddedPair N :=
        ⟨fun e => (j, e), fun _ _ h => congrArg Prod.snd h⟩
      rw [← Finset.card_map emb]
      congr 1
      ext ⟨k, e⟩
      simp only [hardLeafBlocks, taggedSample, Finset.mem_filter, Finset.mem_univ, true_and,
        Finset.mem_map]
      constructor
      · rintro ⟨he, rfl⟩
        exact ⟨e, he, rfl⟩
      · rintro ⟨e', he', h⟩
        change (j, e') = (k, e) at h
        cases h
        exact ⟨he', rfl⟩
    _ = _ := by simp [privateLeaves_card _ (b.canonical_matching _), b.canonical_card]

/-- For each private leaf independently pick the best label for cardinality. -/
def hardLeafSlots (draw : HardDraw p N P t C) (z : Fin p × PaddedPair N) :
    Finset (C × C) :=
  let S := (draw.2 z.1).1 z.2
  slotsAtLabel S (bestSlotLabel S)

def hardLeafMatching (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C) :
    Finset (HardEdge p N C) :=
  (hardLeafBlocks b draw).biUnion (fun z => (hardLeafSlots draw z).map (stagePairSlot z))

theorem mem_hardLeafMatching (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C)
    (e : HardEdge p N C) :
    e ∈ hardLeafMatching b draw ↔
      (e.1, e.2.1) ∈ hardLeafBlocks b draw ∧ e.2.2 ∈ hardLeafSlots draw (e.1, e.2.1) := by
  constructor
  · intro he
    obtain ⟨z, hz, h⟩ := Finset.mem_biUnion.mp he
    obtain ⟨c, hc, rfl⟩ := Finset.mem_map.mp h
    exact ⟨hz, hc⟩
  · intro he
    exact Finset.mem_biUnion.mpr ⟨(e.1, e.2.1), he.1,
      Finset.mem_map.mpr ⟨e.2.2, he.2, rfl⟩⟩

theorem hardLeafMatching_arrived (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) {e : HardEdge p N C} (he : e ∈ hardLeafMatching b draw) :
    e ∈ hardStream b draw := by
  have hm := (mem_hardLeafMatching b draw e).mp he
  have hleaf := (Finset.mem_filter.mp hm.1).2
  have hslot := (Finset.mem_filter.mp hm.2).1
  apply List.mem_flatMap.mpr
  refine ⟨e.1, List.mem_finRange _, (mem_stageStream _ _ _ _).mpr ⟨rfl, ?_, hslot⟩⟩
  exact List.mem_append_right _ (Finset.mem_toList.mpr hleaf)

theorem hardLeafMatching_matching (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) : HardMatching (hardLeafMatching b draw) := by
  have hfacts (e : HardEdge p N C) (he : e ∈ hardLeafMatching b draw) :
      e.2.1 ∈ privateLeaves (b.canonical (draw.1 e.1).1) ∧
        e.2.2.2 - e.2.2.1 = bestSlotLabel ((draw.2 e.1).1 e.2.1) := by
    have hm := (mem_hardLeafMatching b draw e).mp he
    exact ⟨(Finset.mem_filter.mp hm.1).2, (Finset.mem_filter.mp hm.2).2⟩
  constructor
  · intro e he f hf h
    have hj : e.1 = f.1 := congrArg (fun x : Fin p × PaddedVertex N × C => x.1) h
    have hp := (privateLeaves_isMatching _ (b.canonical_matching (draw.1 e.1).1)).1
      (hfacts e he).1 (hj ▸ (hfacts f hf).1)
      (congrArg (fun x : Fin p × PaddedVertex N × C => x.2.1) h)
    have hc : e.2.2.1 = f.2.2.1 := congrArg (fun x : Fin p × PaddedVertex N × C => x.2.2) h
    have hlabel := (hfacts e he).2.trans (by rw [hj, hp, ← (hfacts f hf).2])
    rw [hc] at hlabel
    exact Prod.ext hj (Prod.ext hp (Prod.ext hc (sub_left_injective hlabel)))
  · intro e he f hf h
    have hj : e.1 = f.1 := congrArg (fun x : Fin p × PaddedVertex N × C => x.1) h
    have hp := (privateLeaves_isMatching _ (b.canonical_matching (draw.1 e.1).1)).2
      (hfacts e he).1 (hj ▸ (hfacts f hf).1)
      (congrArg (fun x : Fin p × PaddedVertex N × C => x.2.1) h)
    have hc : e.2.2.2 = f.2.2.2 := congrArg (fun x : Fin p × PaddedVertex N × C => x.2.2) h
    have hlabel := (hfacts e he).2.trans (by rw [hj, hp, ← (hfacts f hf).2])
    rw [hc] at hlabel
    exact Prod.ext hj (Prod.ext hp (Prod.ext (sub_right_injective hlabel) hc))

theorem hardLeafMatching_card (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C)
    (qb ql : ℝ) (hμ : 0 < hardDrawMass b qb ql draw) :
    p * (2 * (N - H)) * retainedSize ql (Fintype.card C ^ 2) ≤
      Fintype.card C * (hardLeafMatching b draw).card := by
  have hdisj : ((hardLeafBlocks b draw : Finset _) : Set _).PairwiseDisjoint
      (fun z => (hardLeafSlots draw z).map (stagePairSlot z)) := by
    intro z _ w _ hne
    change Disjoint ((hardLeafSlots draw z).map (stagePairSlot z))
      ((hardLeafSlots draw w).map (stagePairSlot w))
    rw [Finset.disjoint_left]
    intro e he hw
    obtain ⟨c, _, rfl⟩ := Finset.mem_map.mp he
    obtain ⟨c', _, heq⟩ := Finset.mem_map.mp hw
    exact hne ((congrArg (fun e : HardEdge p N C => (e.1, e.2.1)) heq).symm)
  conv_rhs => rw [hardLeafMatching, Finset.card_biUnion hdisj, Finset.mul_sum]
  rw [← hardLeafBlocks_card b draw]
  have hsum : (hardLeafBlocks b draw).card * retainedSize ql (Fintype.card C ^ 2) =
      ∑ _z ∈ hardLeafBlocks b draw, retainedSize ql (Fintype.card C ^ 2) := by simp
  rw [hsum]
  simp only [Finset.card_map]
  apply Finset.sum_le_sum
  intro z _
  have hz := stageDraw_slot_card_of_pos ql (draw.2 z.1)
    (((hardDrawMass_pos_iff b qb ql draw).mp hμ).2 z.1) z.2
  rw [← hz]
  exact bestSlotLabel_ge_average _

omit [AddCommGroup C] in
/-- Vertex counts of the two sides give the deterministic upper matching
size for every set of potential stage edges. -/
theorem hardMatching_card_upper (M : Finset (HardEdge p N C)) (hM : HardMatching M) :
    M.card ≤ 2 * p * N * Fintype.card C := by
  rw [← Finset.card_image_iff.mpr hM.1]
  have h := Finset.card_le_univ (M.image hardLeft)
  simpa [Fintype.card_prod, Fintype.card_sum, two_mul, Nat.mul_assoc, Nat.mul_add, Nat.add_mul,
    Nat.mul_comm, Nat.mul_left_comm] using h

/-- With `3H ≤ 2N` and sufficiently many clones to absorb the floor,
every realization with positive mass has an arrived matching of size at
least `q_l n / 12`. Here `n = 4pNK` is the announced padded vertex count. -/
theorem hardLeafMatching_linear_size (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) (qb ql : ℝ)
    (hμ : 0 < hardDrawMass b qb ql draw) (hH : 3 * H ≤ 2 * N)
    (hlarge : 2 ≤ ql * (Fintype.card C : ℝ) ^ 2) :
    ql * (4 * p * N * (Fintype.card C : ℝ)) / 12 ≤ (hardLeafMatching b draw).card := by
  let K := Fintype.card C
  let B := 2 * (N - H)
  let k := retainedSize ql (K ^ 2)
  have hK : (0 : ℝ) < K := by dsimp [K]; positivity
  have hk : ql * (K : ℝ) ^ 2 / 2 ≤ (k : ℝ) := by
    have hk := (Nat.sub_one_lt_floor (ql * (K : ℝ) ^ 2)).le
    change ql * (K : ℝ) ^ 2 - 1 ≤ _ at hk
    have hkc : (k : ℝ) = (↑(⌊ql * (K : ℝ) ^ 2⌋₊) : ℝ) := by
      simp [k, retainedSize]
    rw [hkc]
    linarith
  have hBnat : 2 * N ≤ 3 * B := by dsimp [B]; omega
  have hB : (2 : ℝ) * N ≤ 3 * B := by exact_mod_cast hBnat
  have hc : (p : ℝ) * B * k ≤ (K : ℝ) * (hardLeafMatching b draw).card := by
    exact_mod_cast hardLeafMatching_card b draw qb ql hμ
  apply (le_of_mul_le_mul_left ?_ hK)
  calc
    (K : ℝ) * (ql * (4 * p * N * (K : ℝ)) / 12) =
        ((2 : ℝ) * N / 3) * (p * (ql * (K : ℝ) ^ 2 / 2)) := by ring
    _ ≤ (B : ℝ) * (p * (ql * (K : ℝ) ^ 2 / 2)) := by
      apply mul_le_mul_of_nonneg_right _ (by positivity)
      linarith
    _ ≤ (B : ℝ) * (p * k) := by gcongr
    _ ≤ (K : ℝ) * (hardLeafMatching b draw).card := by
      convert hc using 1; ring

end

end SubmodularMatching.LowerBoundGlobal
