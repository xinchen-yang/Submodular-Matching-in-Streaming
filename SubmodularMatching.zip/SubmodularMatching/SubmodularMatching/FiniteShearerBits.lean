import SubmodularMatching.FiniteShearerLaw

/-!
# Bounded rejection for rational choices

A uniform word in `Fin K` is accepted exactly when its value is below a
specified denominator `q`. Each of the `q` outcomes has mass (1/K)
on an attempt, and miss mass is (1-q/K). Capping the number of attempts
preserves exact relative weights, with bounded abortion probability.
-/

namespace SubmodularMatching.ShearerSampler

open scoped BigOperators

/-- Probability of a single specified accepted integer, with `attempts`
independent uniform words. All accepted integers have equal probability. -/
noncomputable def boundedUniform (q K : ℕ) : ℕ → ℝ
  | 0 => 0
  | b+1 => (K : ℝ)⁻¹ + (1 - (q : ℝ) / K) * boundedUniform q K b

theorem boundedUniform_formula (q K b : ℕ) (hq : 0 < q) (hK : 0 < K) :
    boundedUniform q K b = (1-(1-(q : ℝ)/K)^b)/q := by
  have hq' : (q : ℝ) ≠ 0 := by exact_mod_cast hq.ne'
  have hK' : (K : ℝ) ≠ 0 := by exact_mod_cast hK.ne'
  induction b with
  | zero => simp [boundedUniform]
  | succ b ih =>
    rw [boundedUniform, ih, pow_succ]
    field_simp
    ring

theorem boundedUniform_abort_bound (q K b : ℕ) (hqK : q ≤ K) (hKq : K ≤ 2*q)
    (hK : 0 < K) : 0 ≤ (1-(q : ℝ)/K)^b ∧ (1-(q : ℝ)/K)^b ≤ ((2 : ℝ)^b)⁻¹ := by
  have hK' : 0 < (K : ℝ) := by exact_mod_cast hK
  have hqK' : (q : ℝ) ≤ K := by exact_mod_cast hqK
  have hKq' : (K : ℝ) ≤ 2*q := by exact_mod_cast hKq
  have hLower : 0 ≤ 1-(q : ℝ)/K := sub_nonneg.mpr ((div_le_one hK').2 hqK')
  have hUpper : 1-(q : ℝ)/K ≤ (2 : ℝ)⁻¹ := by
    have hHalf := (le_div_iff₀ hK').2 (by linarith only [hKq'] :
      (1 / (2 : ℝ)) * K ≤ q)
    rw [← one_div]
    linarith
  exact ⟨pow_nonneg hLower _, by rw [← inv_pow]; exact pow_le_pow_left₀ hLower hUpper _⟩

/-- Compensated probability of any event specified by a subset of the
`q` accepted cells. It is exactly its target probability times survival. -/
theorem boundedUniform_event {q K : ℕ} (b : ℕ) (hq : 0 < q) (hK : 0 < K)
    (event : Finset (Fin q)) :
    (∑ _ ∈ event, boundedUniform q K b) =
      ((event.card : ℝ)/q) * (1-(1-(q : ℝ)/K)^b) := by
  rw [Finset.sum_const, nsmul_eq_mul, boundedUniform_formula q K b hq hK]
  ring

theorem boundedUniform_total (q K b : ℕ) (hq : 0 < q) (hK : 0 < K) :
    (∑ _ : Fin q, boundedUniform q K b) + (1-(q : ℝ)/K)^b = 1 := by
  have h := boundedUniform_event b hq hK (Finset.univ : Finset (Fin q))
  have hq' : (q : ℝ) ≠ 0 := by exact_mod_cast hq.ne'
  simp only [Finset.card_univ, Fintype.card_fin, div_self hq', one_mul] at h
  rw [h]
  ring

/-- The loss of a single event from discarding aborted words is at most
the abort budget. This applies to arbitrary rational Bernoulli thresholds
and to interval subsets for categorical choices. -/
theorem boundedUniform_event_loss {q K : ℕ} (b : ℕ) (hq : 0 < q) (hK : 0 < K)
    (hqK : q ≤ K) (hKq : K ≤ 2*q) (event : Finset (Fin q)) :
    (event.card : ℝ)/q - (∑ _ ∈ event, boundedUniform q K b) ≤ ((2 : ℝ)^b)⁻¹ := by
  rw [boundedUniform_event b hq hK event]
  have hq' : 0 < (q : ℝ) := by exact_mod_cast hq
  have hcard : (event.card : ℝ) ≤ q := by exact_mod_cast (by simpa using Finset.card_le_univ event : event.card ≤ q)
  have habort := boundedUniform_abort_bound q K b hqK hKq hK
  rw [show (event.card : ℝ)/q - (event.card : ℝ)/q * (1-(1-(q : ℝ)/K)^b) =
    (event.card : ℝ)/q * (1-(q : ℝ)/K)^b by ring]
  exact (mul_le_of_le_one_left habort.1 ((div_le_one hq').2 hcard)).trans habort.2

/-- A dyadic grid at the least sufficient bit width satisfies the
half-success condition, including denominator one. -/
theorem rejection_grid_bounds (q bits : ℕ) (hq : 0 < q)
    (hlen : q ≤ 2^bits) (hmin : ∀ j < bits, 2^j < q) :
    q ≤ 2^bits ∧ 2^bits ≤ 2*q := by
  refine ⟨hlen,?_⟩
  cases bits with
  | zero => simp; omega
  | succ bits =>
    rw [pow_succ]
    have h := hmin bits (Nat.lt_succ_self bits)
    omega

/-- An aborting execution with at most (Q) remaining primitive choices
can lose at most (Qarepsilon) mass if each fresh choice loses at
most (arepsilon), even when the next choice depends on previous outcomes. -/
theorem sequential_abort_budget (ε : ℝ) (hε : 0 ≤ ε)
    (survival : ℕ → ℝ) (h0 : survival 0 = 1)
    (hs : ∀ n, 0 ≤ survival n ∧ survival n ≤ 1)
    (hStep : ∀ n, survival n * (1-ε) ≤ survival (n+1)) (Q : ℕ) :
    1 - survival Q ≤ Q * ε := by
  induction Q with
  | zero => simp [h0]
  | succ Q ih =>
    have ht := hStep Q
    have hb := mul_le_mul_of_nonneg_right (hs Q).2 hε
    rw [Nat.cast_succ]
    linarith only [ih,ht,hb]

end SubmodularMatching.ShearerSampler
