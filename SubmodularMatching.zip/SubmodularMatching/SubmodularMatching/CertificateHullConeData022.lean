import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull022_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 966, 975, 1, 0x1e7bc6⟩ (by decide +kernel)

private def hull022_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 975, 993, 1, 0x1f0bcf⟩ (by decide +kernel)

private def hull022_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 955, 957, 1, 0x1debbb⟩ (by decide +kernel)

private def hull022_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 954, 957, 1, 0x1debba⟩ (by decide +kernel)

private def hull022_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 952, 957, 1, 0x1debb8⟩ (by decide +kernel)

private def hull022_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 948, 957, 1, 0x1debb4⟩ (by decide +kernel)

private def hull022_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 939, 957, 1, 0x1debab⟩ (by decide +kernel)

private def hull022_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 922, 957, 1, 0x1deb9a⟩ (by decide +kernel)

private def hull022_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 957, 961, 1, 0x1e0bbd⟩ (by decide +kernel)

private def hull022_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 961, 966, 1, 0x1e33c1⟩ (by decide +kernel)

private def hull022_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 957, 959, 2, 0xefddf3bd⟩ (by decide +kernel)

private def hull022_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 959, 961, 1, 0x1e0bbf⟩ (by decide +kernel)

private def hull022_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 52, 56, 4, 0x3806e0d81a834⟩ (by decide +kernel)

private def hull022_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 957, 958, 1, 0x1df3bd⟩ (by decide +kernel)

private def hull022_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 958, 959, 1, 0x1dfbbe⟩ (by decide +kernel)

private def hull022_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 959, 960, 1, 0x1e03bf⟩ (by decide +kernel)

private def hull022_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 960, 961, 1, 0x1e0bc0⟩ (by decide +kernel)

private def hull022_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 961, 963, 2, 0xf0de13c1⟩ (by decide +kernel)

private def hull022_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 963, 966, 1, 0x1e33c3⟩ (by decide +kernel)

private def hull022_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 961, 962, 1, 0x1e13c1⟩ (by decide +kernel)

private def hull022_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 962, 963, 1, 0x1e1bc2⟩ (by decide +kernel)

private def hull022_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 70, 35, 0x8c114220430841042003f07c0f41e03b0740e41c03706c0d41a0330640c41802f05c0b41602b0540a41402704c09412023⟩ (by decide +kernel)

private def hull022_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 963, 964, 1, 0x1e23c3⟩ (by decide +kernel)

private def hull022_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 964, 966, 1, 0x1e33c4⟩ (by decide +kernel)

private def hull022_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 43, 47, 4, 0x2f05c0b41602b⟩ (by decide +kernel)

private def hull022_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 47, 52, 5, 0x1a0330640c41802f⟩ (by decide +kernel)

private def hull022_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 47, 49, 2, 0xc41802f⟩ (by decide +kernel)

private def hull022_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 49, 52, 3, 0x680cc19031⟩ (by decide +kernel)

private def hull022_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 964, 965, 1, 0x1e2bc4⟩ (by decide +kernel)

private def hull022_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 965, 966, 1, 0x1e33c5⟩ (by decide +kernel)

private def hull022_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 966, 970, 1, 0x1e53c6⟩ (by decide +kernel)

private def hull022_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 970, 975, 1, 0x1e7bca⟩ (by decide +kernel)

private def hull022_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 966, 968, 1, 0x1e43c6⟩ (by decide +kernel)

private def hull022_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 968, 970, 1, 0x1e53c8⟩ (by decide +kernel)

private def hull022_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 966, 967, 1, 0x1e3bc6⟩ (by decide +kernel)

private def hull022_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 967, 968, 1, 0x1e43c7⟩ (by decide +kernel)

private def hull022_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 957, 966, 1, 0x1e33bd⟩ (by decide +kernel)

private def hull022_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 968, 969, 1, 0x1e4bc8⟩ (by decide +kernel)

private def hull022_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 969, 970, 1, 0x1e53c9⟩ (by decide +kernel)

private def hull022_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 283, 156, 0x11b1522a0530a51462885009f13a2704d89913025c4b09512824c4909112023c4708d11822c4508911021c4308510820c410811001fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull022_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 970, 972, 2, 0xf31e5bca⟩ (by decide +kernel)

private def hull022_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 972, 975, 1, 0x1e7bcc⟩ (by decide +kernel)

private def hull022_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 970, 971, 1, 0x1e5bca⟩ (by decide +kernel)

private def hull022_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 971, 972, 1, 0x1e63cb⟩ (by decide +kernel)

private def hull022_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 52, 17, 0x1a0330640c41802f05c0b41602b0540a41402704c09412023⟩ (by decide +kernel)

private def hull022_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 972, 973, 1, 0x1e6bcc⟩ (by decide +kernel)

private def hull022_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 973, 975, 2, 0xf3de73cd⟩ (by decide +kernel)

private def hull022_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 39, 43, 4, 0x2b0540a414027⟩ (by decide +kernel)

private def hull022_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 973, 974, 1, 0x1e73cd⟩ (by decide +kernel)

private def hull022_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 39, 41, 2, 0xa414027⟩ (by decide +kernel)

private def hull022_050 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 974, 975, 1, 0x1e7bce⟩ (by decide +kernel)

private def hull022_051 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 41, 43, 2, 0xac15029⟩ (by decide +kernel)

private def hull022_052 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 975, 984, 1, 0x1ec3cf⟩ (by decide +kernel)

private def hull022_053 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 984, 993, 1, 0x1f0bd8⟩ (by decide +kernel)

private def hull022_054 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 975, 979, 1, 0x1e9bcf⟩ (by decide +kernel)

private def hull022_055 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 979, 984, 1, 0x1ec3d3⟩ (by decide +kernel)

private def hull022_056 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 975, 977, 2, 0xf45e83cf⟩ (by decide +kernel)

private def hull022_057 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 977, 979, 1, 0x1e9bd1⟩ (by decide +kernel)

private def hull022_058 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 957, 975, 1, 0x1e7bbd⟩ (by decide +kernel)

private def hull022_059 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 975, 976, 1, 0x1e83cf⟩ (by decide +kernel)

private def hull022_060 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 976, 977, 1, 0x1e8bd0⟩ (by decide +kernel)

private def hull022_061 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 977, 978, 1, 0x1e93d1⟩ (by decide +kernel)

private def hull022_062 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 978, 979, 1, 0x1e9bd2⟩ (by decide +kernel)

private def hull022_063 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 43, 8, 0x2b0540a41402704c09412023⟩ (by decide +kernel)

private def hull022_064 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 979, 981, 2, 0xf55ea3d3⟩ (by decide +kernel)

private def hull022_065 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 981, 984, 1, 0x1ec3d5⟩ (by decide +kernel)

private def hull022_066 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 979, 980, 1, 0x1ea3d3⟩ (by decide +kernel)

private def hull022_067 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 980, 981, 1, 0x1eabd4⟩ (by decide +kernel)

private def hull022_068 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 981, 982, 1, 0x1eb3d5⟩ (by decide +kernel)

private def hull022_069 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 982, 984, 1, 0x1ec3d6⟩ (by decide +kernel)

private def hull022_070 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 982, 983, 1, 0x1ebbd6⟩ (by decide +kernel)

private def hull022_071 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 983, 984, 1, 0x1ec3d7⟩ (by decide +kernel)

private def supportedCone2816 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨966, 975, 966, 966, 975⟩, ⟨0, 0, 4517060943764, 21998687022, 16721312587760, 928478710939⟩⟩
    hull022_000 0 (by decide +kernel)

private def supportedCone2817 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 993, 975, 975, 993⟩, ⟨0, 0, 12422180097535, 32648068003, 21238373531524, 950477397961⟩⟩
    hull022_001 0 (by decide +kernel)

private def supportedCone2818 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨955, 957, 957, 955, 957⟩, ⟨311267448123, 2993321002, 0, 0, 12962162550980, 900600893922⟩⟩
    hull022_002 1 (by decide +kernel)

private def supportedCone2819 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨954, 957, 957, 954, 957⟩, ⟨1018947434375, 10121164684, 0, 0, 12962162550980, 900600893922⟩⟩
    hull022_003 1 (by decide +kernel)

private def supportedCone2820 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨952, 957, 957, 952, 957⟩, ⟨1315906281480, 13172420316, 0, 0, 12962162550980, 900600893922⟩⟩
    hull022_004 1 (by decide +kernel)

private def supportedCone2821 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨948, 957, 957, 948, 957⟩, ⟨2445360023920, 26626246496, 0, 0, 12962162550980, 900600893922⟩⟩
    hull022_005 1 (by decide +kernel)

private def supportedCone2822 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨939, 957, 957, 939, 957⟩, ⟨4850641138830, 64604704816, 0, 0, 12962162550980, 900600893922⟩⟩
    hull022_006 1 (by decide +kernel)

private def supportedCone2823 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨922, 957, 957, 922, 957⟩, ⟨7801002943150, 142950319490, 0, 0, 12962162550980, 900600893922⟩⟩
    hull022_007 1 (by decide +kernel)

private def supportedCone2824 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 961, 957, 957, 961⟩, ⟨0, 0, 1428286142720, 11965999234, 12962162550980, 900600893922⟩⟩
    hull022_008 0 (by decide +kernel)

private def supportedCone2825 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨961, 966, 961, 961, 966⟩, ⟨0, 0, 2330863894060, 15911817783, 14390448693700, 912566893156⟩⟩
    hull022_009 0 (by decide +kernel)

private def supportedCone2826 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 959, 957, 957, 958⟩, ⟨0, 0, 438345213549, 3771800756, 12962162550980, 900600893922⟩⟩
    hull022_010 0 (by decide +kernel)

private def supportedCone2827 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨959, 961, 959, 959, 961⟩, ⟨0, 0, 435496470230, 3417864814, 13954952223470, 909149028342⟩⟩
    hull022_011 0 (by decide +kernel)

private def supportedCone2828 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 959, 958, 957, 959⟩, ⟨438345213549, 3771800756, 554444458941, 4776333664, 13400507764529, 904372694678⟩⟩
    hull022_010 1 (by decide +kernel)

private def supportedCone2829 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 56, 54, 53, 55⟩, ⟨2001185206, 173452311, 1998814794, 184328284, 282001185206, 2158314778⟩⟩
    hull022_012 2 (by decide +kernel)

private def supportedCone2830 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 958, 957, 957, 958⟩, ⟨0, 0, 438345213549, 3771800756, 12962162550980, 900600893922⟩⟩
    hull022_013 0 (by decide +kernel)

private def supportedCone2831 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 958, 958, 957, 958⟩, ⟨438345213549, 3771800756, 0, 0, 13400507764529, 904372694678⟩⟩
    hull022_013 1 (by decide +kernel)

private def supportedCone2832 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 56, 52, 52, 53⟩, ⟨0, 0, 501910433, 43066537, 279498089567, 1941795930⟩⟩
    hull022_012 0 (by decide +kernel)

private def supportedCone2833 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨958, 959, 958, 958, 959⟩, ⟨0, 0, 554444458941, 4776333664, 13400507764529, 904372694678⟩⟩
    hull022_014 0 (by decide +kernel)

private def supportedCone2834 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 959, 959, 958, 959⟩, ⟨554444458941, 4776333664, 0, 0, 13954952223470, 909149028342⟩⟩
    hull022_010 2 (by decide +kernel)

private def supportedCone2835 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 56, 55, 54, 56⟩, ⟨1998814794, 184328284, 1000000000, 94363393, 284000000000, 2342643062⟩⟩
    hull022_012 3 (by decide +kernel)

private def supportedCone2836 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨958, 959, 959, 958, 959⟩, ⟨554444458941, 4776333664, 0, 0, 13954952223470, 909149028342⟩⟩
    hull022_014 1 (by decide +kernel)

private def supportedCone2837 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨959, 961, 961, 959, 961⟩, ⟨435496470230, 3417864814, 0, 0, 14390448693700, 912566893156⟩⟩
    hull022_011 1 (by decide +kernel)

private def supportedCone2838 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨959, 960, 959, 959, 960⟩, ⟨0, 0, 239585545374, 1908510464, 13954952223470, 909149028342⟩⟩
    hull022_015 0 (by decide +kernel)

private def supportedCone2839 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨960, 961, 960, 960, 961⟩, ⟨0, 0, 195910924856, 1509354350, 14194537768844, 911057538806⟩⟩
    hull022_016 0 (by decide +kernel)

private def supportedCone2840 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨959, 960, 960, 959, 960⟩, ⟨239585545374, 1908510464, 0, 0, 14194537768844, 911057538806⟩⟩
    hull022_015 1 (by decide +kernel)

private def supportedCone2841 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨960, 961, 961, 960, 961⟩, ⟨195910924856, 1509354350, 0, 0, 14390448693700, 912566893156⟩⟩
    hull022_016 1 (by decide +kernel)

private def supportedCone2842 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 961, 961, 957, 961⟩, ⟨1428286142720, 11965999234, 0, 0, 14390448693700, 912566893156⟩⟩
    hull022_008 1 (by decide +kernel)

private def supportedCone2843 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨961, 966, 966, 961, 966⟩, ⟨2330863894060, 15911817783, 0, 0, 16721312587760, 928478710939⟩⟩
    hull022_009 1 (by decide +kernel)

private def supportedCone2844 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨961, 963, 961, 961, 962⟩, ⟨0, 0, 645168315118, 4761421467, 14390448693700, 912566893156⟩⟩
    hull022_017 0 (by decide +kernel)

private def supportedCone2845 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨963, 966, 963, 963, 966⟩, ⟨0, 0, 1445674523320, 9360829196, 15275638064440, 919117881743⟩⟩
    hull022_018 0 (by decide +kernel)

private def supportedCone2846 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨961, 963, 962, 961, 963⟩, ⟨645168315118, 4761421467, 240021055622, 1789567120, 15035617008818, 917328314623⟩⟩
    hull022_017 1 (by decide +kernel)

private def supportedCone2847 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨961, 963, 963, 962, 963⟩, ⟨240021055622, 1789567120, 0, 0, 15275638064440, 919117881743⟩⟩
    hull022_017 2 (by decide +kernel)

def appendixHullConeBlock0088 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2816,
    supportedCone2817,
    supportedCone2818,
    supportedCone2819,
    supportedCone2820,
    supportedCone2821,
    supportedCone2822,
    supportedCone2823,
    supportedCone2824,
    supportedCone2825,
    supportedCone2826,
    supportedCone2827,
    supportedCone2828,
    supportedCone2829,
    supportedCone2830,
    supportedCone2831,
    supportedCone2832,
    supportedCone2833,
    supportedCone2834,
    supportedCone2835,
    supportedCone2836,
    supportedCone2837,
    supportedCone2838,
    supportedCone2839,
    supportedCone2840,
    supportedCone2841,
    supportedCone2842,
    supportedCone2843,
    supportedCone2844,
    supportedCone2845,
    supportedCone2846,
    supportedCone2847,
  ], rfl⟩

private def supportedCone2848 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨961, 962, 961, 961, 962⟩, ⟨0, 0, 645168315118, 4761421467, 14390448693700, 912566893156⟩⟩
    hull022_019 0 (by decide +kernel)

private def supportedCone2849 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨961, 962, 962, 961, 962⟩, ⟨645168315118, 4761421467, 0, 0, 15035617008818, 917328314623⟩⟩
    hull022_019 1 (by decide +kernel)

private def supportedCone2850 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨962, 963, 962, 962, 963⟩, ⟨0, 0, 240021055622, 1789567120, 15035617008818, 917328314623⟩⟩
    hull022_020 0 (by decide +kernel)

private def supportedCone2851 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 37, 36, 38⟩, ⟨1418082341, 71124003, 1099837485, 58486581, 262674663295, 783963433⟩⟩
    hull022_021 2 (by decide +kernel)

private def supportedCone2852 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨963, 966, 966, 963, 966⟩, ⟨1445674523320, 9360829196, 0, 0, 16721312587760, 928478710939⟩⟩
    hull022_018 1 (by decide +kernel)

private def supportedCone2853 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨963, 964, 963, 963, 964⟩, ⟨0, 0, 650895262490, 4303907533, 15275638064440, 919117881743⟩⟩
    hull022_022 0 (by decide +kernel)

private def supportedCone2854 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨964, 966, 964, 964, 966⟩, ⟨0, 0, 794779260830, 5056921663, 15926533326930, 923421789276⟩⟩
    hull022_023 0 (by decide +kernel)

private def supportedCone2855 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨963, 964, 964, 963, 964⟩, ⟨650895262490, 4303907533, 0, 0, 15926533326930, 923421789276⟩⟩
    hull022_022 1 (by decide +kernel)

private def supportedCone2856 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨43, 47, 47, 46, 47⟩, ⟨1084869137, 78356954, 0, 0, 273497418860, 1463478459⟩⟩
    hull022_024 4 (by decide +kernel)

private def supportedCone2857 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨47, 52, 49, 48, 50⟩, ⟨1183935478, 87538993, 888204788, 69012269, 275000000000, 1574557180⟩⟩
    hull022_025 2 (by decide +kernel)

private def supportedCone2858 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨47, 52, 50, 49, 51⟩, ⟨888204788, 69012269, 1280097444, 102309752, 275888204788, 1643569449⟩⟩
    hull022_025 3 (by decide +kernel)

private def supportedCone2859 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨47, 49, 49, 48, 49⟩, ⟨1183935478, 87538993, 0, 0, 275000000000, 1574557180⟩⟩
    hull022_026 2 (by decide +kernel)

private def supportedCone2860 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨49, 52, 50, 49, 51⟩, ⟨888204788, 69012269, 1280097444, 102309752, 275888204788, 1643569449⟩⟩
    hull022_027 1 (by decide +kernel)

private def supportedCone2861 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨964, 965, 964, 964, 965⟩, ⟨0, 0, 49582756440, 333706224, 15926533326930, 923421789276⟩⟩
    hull022_028 0 (by decide +kernel)

private def supportedCone2862 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨965, 966, 965, 965, 966⟩, ⟨0, 0, 745196504390, 4723215439, 15976116083370, 923755495500⟩⟩
    hull022_029 0 (by decide +kernel)

private def supportedCone2863 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨964, 965, 965, 964, 965⟩, ⟨49582756440, 333706224, 0, 0, 15976116083370, 923755495500⟩⟩
    hull022_028 1 (by decide +kernel)

private def supportedCone2864 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨965, 966, 966, 965, 966⟩, ⟨745196504390, 4723215439, 0, 0, 16721312587760, 928478710939⟩⟩
    hull022_029 1 (by decide +kernel)

private def supportedCone2865 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨964, 966, 966, 964, 966⟩, ⟨794779260830, 5056921663, 0, 0, 16721312587760, 928478710939⟩⟩
    hull022_023 1 (by decide +kernel)

private def supportedCone2866 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨966, 970, 966, 966, 970⟩, ⟨0, 0, 1582492037480, 8831293233, 16721312587760, 928478710939⟩⟩
    hull022_030 0 (by decide +kernel)

private def supportedCone2867 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨970, 975, 970, 970, 975⟩, ⟨0, 0, 2934568906284, 13167393789, 18303804625240, 937310004172⟩⟩
    hull022_031 0 (by decide +kernel)

private def supportedCone2868 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨966, 968, 966, 966, 968⟩, ⟨0, 0, 1015193795190, 5760659911, 16721312587760, 928478710939⟩⟩
    hull022_032 0 (by decide +kernel)

private def supportedCone2869 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨968, 970, 968, 968, 970⟩, ⟨0, 0, 567298242290, 3070633322, 17736506382950, 934239370850⟩⟩
    hull022_033 0 (by decide +kernel)

private def supportedCone2870 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨966, 967, 967, 966, 967⟩, ⟨148927167950, 868588379, 0, 0, 16870239755710, 929347299318⟩⟩
    hull022_034 1 (by decide +kernel)

private def supportedCone2871 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨967, 968, 967, 967, 968⟩, ⟨0, 0, 866266627240, 4892071532, 16870239755710, 929347299318⟩⟩
    hull022_035 0 (by decide +kernel)

private def supportedCone2872 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨966, 967, 966, 966, 967⟩, ⟨0, 0, 148927167950, 868588379, 16721312587760, 928478710939⟩⟩
    hull022_034 0 (by decide +kernel)

private def supportedCone2873 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 966, 966, 957, 966⟩, ⟨3759150036780, 27877817017, 0, 0, 16721312587760, 928478710939⟩⟩
    hull022_036 1 (by decide +kernel)

private def supportedCone2874 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨967, 968, 968, 967, 968⟩, ⟨866266627240, 4892071532, 0, 0, 17736506382950, 934239370850⟩⟩
    hull022_035 1 (by decide +kernel)

private def supportedCone2875 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨966, 968, 968, 966, 968⟩, ⟨1015193795190, 5760659911, 0, 0, 17736506382950, 934239370850⟩⟩
    hull022_032 1 (by decide +kernel)

private def supportedCone2876 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨968, 969, 968, 968, 969⟩, ⟨0, 0, 133357922920, 731501644, 17736506382950, 934239370850⟩⟩
    hull022_037 0 (by decide +kernel)

private def supportedCone2877 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨969, 970, 969, 969, 970⟩, ⟨0, 0, 433940319370, 2339131678, 17869864305870, 934970872494⟩⟩
    hull022_038 0 (by decide +kernel)

private def supportedCone2878 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨968, 970, 970, 968, 970⟩, ⟨567298242290, 3070633322, 0, 0, 18303804625240, 937310004172⟩⟩
    hull022_033 1 (by decide +kernel)

private def supportedCone2879 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 48, 47, 49⟩, ⟨318645662, 23539728, 1183935478, 87538993, 273816064522, 1487018187⟩⟩
    hull022_039 39 (by decide +kernel)

def appendixHullConeBlock0089 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2848,
    supportedCone2849,
    supportedCone2850,
    supportedCone2851,
    supportedCone2852,
    supportedCone2853,
    supportedCone2854,
    supportedCone2855,
    supportedCone2856,
    supportedCone2857,
    supportedCone2858,
    supportedCone2859,
    supportedCone2860,
    supportedCone2861,
    supportedCone2862,
    supportedCone2863,
    supportedCone2864,
    supportedCone2865,
    supportedCone2866,
    supportedCone2867,
    supportedCone2868,
    supportedCone2869,
    supportedCone2870,
    supportedCone2871,
    supportedCone2872,
    supportedCone2873,
    supportedCone2874,
    supportedCone2875,
    supportedCone2876,
    supportedCone2877,
    supportedCone2878,
    supportedCone2879,
  ], rfl⟩

private def supportedCone2880 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨968, 969, 969, 968, 969⟩, ⟨133357922920, 731501644, 0, 0, 17869864305870, 934970872494⟩⟩
    hull022_037 1 (by decide +kernel)

private def supportedCone2881 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨969, 970, 970, 969, 970⟩, ⟨433940319370, 2339131678, 0, 0, 18303804625240, 937310004172⟩⟩
    hull022_038 1 (by decide +kernel)

private def supportedCone2882 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨966, 970, 970, 966, 970⟩, ⟨1582492037480, 8831293233, 0, 0, 18303804625240, 937310004172⟩⟩
    hull022_030 1 (by decide +kernel)

private def supportedCone2883 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨970, 972, 970, 970, 971⟩, ⟨0, 0, 624915709166, 3005589968, 18303804625240, 937310004172⟩⟩
    hull022_040 0 (by decide +kernel)

private def supportedCone2884 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨972, 975, 972, 972, 975⟩, ⟨0, 0, 1547501417754, 6495625055, 19690872113770, 943981772906⟩⟩
    hull022_041 0 (by decide +kernel)

private def supportedCone2885 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨970, 972, 972, 971, 972⟩, ⟨762151779364, 3666178766, 0, 0, 19690872113770, 943981772906⟩⟩
    hull022_040 2 (by decide +kernel)

private def supportedCone2886 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨970, 972, 971, 970, 972⟩, ⟨624915709166, 3005589968, 762151779364, 3666178766, 18928720334406, 940315594140⟩⟩
    hull022_040 1 (by decide +kernel)

private def supportedCone2887 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨970, 971, 970, 970, 971⟩, ⟨0, 0, 624915709166, 3005589968, 18303804625240, 937310004172⟩⟩
    hull022_042 0 (by decide +kernel)

private def supportedCone2888 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨971, 972, 971, 971, 972⟩, ⟨0, 0, 762151779364, 3666178766, 18928720334406, 940315594140⟩⟩
    hull022_043 0 (by decide +kernel)

private def supportedCone2889 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨970, 971, 971, 970, 971⟩, ⟨624915709166, 3005589968, 0, 0, 18928720334406, 940315594140⟩⟩
    hull022_042 1 (by decide +kernel)

private def supportedCone2890 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 37, 36, 38⟩, ⟨1418082341, 71124003, 1099837485, 58486581, 262674663295, 783963433⟩⟩
    hull022_044 2 (by decide +kernel)

private def supportedCone2891 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 45, 44, 46⟩, ⟨734647838, 50900754, 412549723, 29103357, 272000000000, 1356018148⟩⟩
    hull022_044 10 (by decide +kernel)

private def supportedCone2892 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨971, 972, 972, 971, 972⟩, ⟨762151779364, 3666178766, 0, 0, 19690872113770, 943981772906⟩⟩
    hull022_043 1 (by decide +kernel)

private def supportedCone2893 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨972, 973, 972, 972, 973⟩, ⟨0, 0, 345190366420, 1598673137, 19690872113770, 943981772906⟩⟩
    hull022_045 0 (by decide +kernel)

private def supportedCone2894 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨973, 975, 973, 973, 974⟩, ⟨0, 0, 14255046868, 52577923, 20036062480190, 945580446043⟩⟩
    hull022_046 0 (by decide +kernel)

private def supportedCone2895 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨972, 973, 973, 972, 973⟩, ⟨345190366420, 1598673137, 0, 0, 20036062480190, 945580446043⟩⟩
    hull022_045 1 (by decide +kernel)

private def supportedCone2896 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 44, 43, 45⟩, ⟨1265352162, 86554930, 734647838, 50900754, 271265352162, 1305117394⟩⟩
    hull022_044 9 (by decide +kernel)

private def supportedCone2897 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨973, 975, 974, 973, 975⟩, ⟨14255046868, 52577923, 1188056004466, 4844373995, 20050317527058, 945633023966⟩⟩
    hull022_046 1 (by decide +kernel)

private def supportedCone2898 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨973, 975, 975, 974, 975⟩, ⟨1188056004466, 4844373995, 0, 0, 21238373531524, 950477397961⟩⟩
    hull022_046 2 (by decide +kernel)

private def supportedCone2899 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨39, 43, 43, 42, 43⟩, ⟨1798390801, 116302336, 0, 0, 270000000000, 1218562464⟩⟩
    hull022_047 4 (by decide +kernel)

private def supportedCone2900 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨973, 974, 974, 973, 974⟩, ⟨14255046868, 52577923, 0, 0, 20050317527058, 945633023966⟩⟩
    hull022_048 1 (by decide +kernel)

private def supportedCone2901 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨39, 41, 41, 40, 41⟩, ⟨1466867611, 87366046, 0, 0, 267379752800, 1050933123⟩⟩
    hull022_049 2 (by decide +kernel)

private def supportedCone2902 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨974, 975, 975, 974, 975⟩, ⟨1188056004466, 4844373995, 0, 0, 21238373531524, 950477397961⟩⟩
    hull022_050 1 (by decide +kernel)

private def supportedCone2903 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨41, 43, 42, 41, 43⟩, ⟨821856399, 51327005, 1798390801, 116302336, 268201609199, 1102260128⟩⟩
    hull022_051 1 (by decide +kernel)

private def supportedCone2904 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨974, 975, 974, 974, 975⟩, ⟨0, 0, 1188056004466, 4844373995, 20050317527058, 945633023966⟩⟩
    hull022_050 0 (by decide +kernel)

private def supportedCone2905 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨41, 43, 43, 42, 43⟩, ⟨1798390801, 116302336, 0, 0, 270000000000, 1218562464⟩⟩
    hull022_051 2 (by decide +kernel)

private def supportedCone2906 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨972, 975, 975, 972, 975⟩, ⟨1547501417754, 6495625055, 0, 0, 21238373531524, 950477397961⟩⟩
    hull022_041 1 (by decide +kernel)

private def supportedCone2907 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 984, 975, 975, 984⟩, ⟨0, 0, 5499154612488, 17884191629, 21238373531524, 950477397961⟩⟩
    hull022_052 0 (by decide +kernel)

private def supportedCone2908 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨984, 993, 984, 984, 993⟩, ⟨0, 0, 6923025485047, 14763876374, 26737528144012, 968361589590⟩⟩
    hull022_053 0 (by decide +kernel)

private def supportedCone2909 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 979, 975, 975, 979⟩, ⟨0, 0, 2591473510204, 9345088278, 21238373531524, 950477397961⟩⟩
    hull022_054 0 (by decide +kernel)

private def supportedCone2910 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨979, 984, 979, 979, 984⟩, ⟨0, 0, 2907681102284, 8539103351, 23829847041728, 959822486239⟩⟩
    hull022_055 0 (by decide +kernel)

private def supportedCone2911 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 977, 975, 975, 976⟩, ⟨0, 0, 622213679356, 2533368209, 21238373531524, 950477397961⟩⟩
    hull022_056 0 (by decide +kernel)

def appendixHullConeBlock0090 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2880,
    supportedCone2881,
    supportedCone2882,
    supportedCone2883,
    supportedCone2884,
    supportedCone2885,
    supportedCone2886,
    supportedCone2887,
    supportedCone2888,
    supportedCone2889,
    supportedCone2890,
    supportedCone2891,
    supportedCone2892,
    supportedCone2893,
    supportedCone2894,
    supportedCone2895,
    supportedCone2896,
    supportedCone2897,
    supportedCone2898,
    supportedCone2899,
    supportedCone2900,
    supportedCone2901,
    supportedCone2902,
    supportedCone2903,
    supportedCone2904,
    supportedCone2905,
    supportedCone2906,
    supportedCone2907,
    supportedCone2908,
    supportedCone2909,
    supportedCone2910,
    supportedCone2911,
  ], rfl⟩

private def supportedCone2912 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨977, 979, 977, 977, 979⟩, ⟨0, 0, 1897587168488, 6493978223, 21932259873240, 953328508016⟩⟩
    hull022_057 0 (by decide +kernel)

private def supportedCone2913 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨970, 975, 975, 970, 975⟩, ⟨2934568906284, 13167393789, 0, 0, 21238373531524, 950477397961⟩⟩
    hull022_031 1 (by decide +kernel)

private def supportedCone2914 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨966, 975, 975, 966, 975⟩, ⟨4517060943764, 21998687022, 0, 0, 21238373531524, 950477397961⟩⟩
    hull022_000 1 (by decide +kernel)

private def supportedCone2915 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 975, 975, 957, 975⟩, ⟨8276210980544, 49876504039, 0, 0, 21238373531524, 950477397961⟩⟩
    hull022_058 1 (by decide +kernel)

private def supportedCone2916 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 977, 976, 975, 977⟩, ⟨622213679356, 2533368209, 71672662360, 317741846, 21860587210880, 953010766170⟩⟩
    hull022_056 1 (by decide +kernel)

private def supportedCone2917 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 977, 977, 976, 977⟩, ⟨71672662360, 317741846, 0, 0, 21932259873240, 953328508016⟩⟩
    hull022_056 2 (by decide +kernel)

private def supportedCone2918 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 976, 975, 975, 976⟩, ⟨0, 0, 622213679356, 2533368209, 21238373531524, 950477397961⟩⟩
    hull022_059 0 (by decide +kernel)

private def supportedCone2919 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 976, 976, 975, 976⟩, ⟨622213679356, 2533368209, 0, 0, 21860587210880, 953010766170⟩⟩
    hull022_059 1 (by decide +kernel)

private def supportedCone2920 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨976, 977, 976, 976, 977⟩, ⟨0, 0, 71672662360, 317741846, 21860587210880, 953010766170⟩⟩
    hull022_060 0 (by decide +kernel)

private def supportedCone2921 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨977, 978, 978, 977, 978⟩, ⟨564566406734, 1939821162, 0, 0, 22496826279974, 955268329178⟩⟩
    hull022_061 1 (by decide +kernel)

private def supportedCone2922 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨978, 979, 978, 978, 979⟩, ⟨0, 0, 1333020761754, 4554157061, 22496826279974, 955268329178⟩⟩
    hull022_062 0 (by decide +kernel)

private def supportedCone2923 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨977, 979, 979, 977, 979⟩, ⟨1897587168488, 6493978223, 0, 0, 23829847041728, 959822486239⟩⟩
    hull022_057 1 (by decide +kernel)

private def supportedCone2924 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨977, 978, 977, 977, 978⟩, ⟨0, 0, 564566406734, 1939821162, 21932259873240, 953328508016⟩⟩
    hull022_061 0 (by decide +kernel)

private def supportedCone2925 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨978, 979, 979, 978, 979⟩, ⟨1333020761754, 4554157061, 0, 0, 23829847041728, 959822486239⟩⟩
    hull022_062 1 (by decide +kernel)

private def supportedCone2926 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 43, 39, 38, 40⟩, ⟨1225499220, 67598571, 912885189, 53518492, 265000000000, 910048585⟩⟩
    hull022_063 4 (by decide +kernel)

private def supportedCone2927 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 43, 41, 40, 42⟩, ⟨1466867611, 87366046, 821856399, 51327005, 267379752800, 1050933123⟩⟩
    hull022_063 6 (by decide +kernel)

private def supportedCone2928 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨979, 981, 979, 979, 980⟩, ⟨0, 0, 178064873262, 602721355, 23829847041728, 959822486239⟩⟩
    hull022_064 0 (by decide +kernel)

private def supportedCone2929 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨981, 984, 981, 981, 984⟩, ⟨0, 0, 2468147364762, 7039541091, 24269380779250, 961322048499⟩⟩
    hull022_065 0 (by decide +kernel)

private def supportedCone2930 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 979, 979, 975, 979⟩, ⟨2591473510204, 9345088278, 0, 0, 23829847041728, 959822486239⟩⟩
    hull022_054 1 (by decide +kernel)

private def supportedCone2931 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨979, 981, 980, 979, 981⟩, ⟨178064873262, 602721355, 261468864260, 896840905, 24007911914990, 960425207594⟩⟩
    hull022_064 1 (by decide +kernel)

private def supportedCone2932 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨979, 980, 979, 979, 980⟩, ⟨0, 0, 178064873262, 602721355, 23829847041728, 959822486239⟩⟩
    hull022_066 0 (by decide +kernel)

private def supportedCone2933 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨980, 981, 980, 980, 981⟩, ⟨0, 0, 261468864260, 896840905, 24007911914990, 960425207594⟩⟩
    hull022_067 0 (by decide +kernel)

private def supportedCone2934 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨979, 981, 981, 980, 981⟩, ⟨261468864260, 896840905, 0, 0, 24269380779250, 961322048499⟩⟩
    hull022_064 2 (by decide +kernel)

private def supportedCone2935 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨981, 984, 984, 981, 984⟩, ⟨2468147364762, 7039541091, 0, 0, 26737528144012, 968361589590⟩⟩
    hull022_065 1 (by decide +kernel)

private def supportedCone2936 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨981, 982, 981, 981, 982⟩, ⟨0, 0, 972473470106, 2799389630, 24269380779250, 961322048499⟩⟩
    hull022_068 0 (by decide +kernel)

private def supportedCone2937 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨982, 984, 982, 982, 984⟩, ⟨0, 0, 1495673894656, 4240151461, 25241854249356, 964121438129⟩⟩
    hull022_069 0 (by decide +kernel)

private def supportedCone2938 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨981, 982, 982, 981, 982⟩, ⟨972473470106, 2799389630, 0, 0, 25241854249356, 964121438129⟩⟩
    hull022_068 1 (by decide +kernel)

private def supportedCone2939 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨982, 983, 982, 982, 983⟩, ⟨0, 0, 1038147804654, 2990367467, 25241854249356, 964121438129⟩⟩
    hull022_070 0 (by decide +kernel)

private def supportedCone2940 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨983, 984, 983, 983, 984⟩, ⟨0, 0, 457526090002, 1249783994, 26280002054010, 967111805596⟩⟩
    hull022_071 0 (by decide +kernel)

private def supportedCone2941 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨982, 983, 983, 982, 983⟩, ⟨1038147804654, 2990367467, 0, 0, 26280002054010, 967111805596⟩⟩
    hull022_070 1 (by decide +kernel)

private def supportedCone2942 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨983, 984, 984, 983, 984⟩, ⟨457526090002, 1249783994, 0, 0, 26737528144012, 968361589590⟩⟩
    hull022_071 1 (by decide +kernel)

private def supportedCone2943 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨982, 984, 984, 982, 984⟩, ⟨1495673894656, 4240151461, 0, 0, 26737528144012, 968361589590⟩⟩
    hull022_069 1 (by decide +kernel)

def appendixHullConeBlock0091 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2912,
    supportedCone2913,
    supportedCone2914,
    supportedCone2915,
    supportedCone2916,
    supportedCone2917,
    supportedCone2918,
    supportedCone2919,
    supportedCone2920,
    supportedCone2921,
    supportedCone2922,
    supportedCone2923,
    supportedCone2924,
    supportedCone2925,
    supportedCone2926,
    supportedCone2927,
    supportedCone2928,
    supportedCone2929,
    supportedCone2930,
    supportedCone2931,
    supportedCone2932,
    supportedCone2933,
    supportedCone2934,
    supportedCone2935,
    supportedCone2936,
    supportedCone2937,
    supportedCone2938,
    supportedCone2939,
    supportedCone2940,
    supportedCone2941,
    supportedCone2942,
    supportedCone2943,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
