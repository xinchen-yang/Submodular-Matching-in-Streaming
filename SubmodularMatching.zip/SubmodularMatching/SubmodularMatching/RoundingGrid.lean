import SubmodularMatching.TwoStageShearer

/-!
# Grid rounding before the second sampler

FJ7 floors the compensated edge coordinate, then multiplies by the
unmatched-pair probability. This preserves joint feasibility and costs
at most `m * mesh * τ` in the linear objective.
-/

open scoped BigOperators

namespace SubmodularMatching.TwoStage

noncomputable section

variable {E V : Type*} [Fintype E] [DecidableEq E] [DecidableEq V]

def floorOnGrid (mesh a : ℝ) : ℝ := mesh * (Int.floor (a / mesh) : ℝ)

theorem floorOnGrid_bounds (mesh a : ℝ) (hmesh : 0 < mesh) (ha : 0 ≤ a) :
    0 ≤ floorOnGrid mesh a ∧ floorOnGrid mesh a ≤ a ∧
      a - mesh ≤ floorOnGrid mesh a := by
  unfold floorOnGrid
  have hlo : (0 : ℤ) ≤ Int.floor (a / mesh) := Int.floor_nonneg.mpr (div_nonneg ha hmesh.le)
  have hi := (le_div_iff₀ hmesh).mp (Int.floor_le (a / mesh))
  have hl := (div_lt_iff₀ hmesh).mp (Int.lt_floor_add_one (a / mesh))
  exact ⟨mul_nonneg hmesh.le (by exact_mod_cast hlo), by linarith, by linarith⟩

def gridCoordinate (x q mesh : ℝ) : ℝ := q * floorOnGrid mesh (x / q)

theorem gridCoordinate_bounds (x q mesh : ℝ) (hx : 0 ≤ x) (hq : 0 < q) (hq1 : q ≤ 1)
    (hmesh : 0 < mesh) :
    0 ≤ gridCoordinate x q mesh ∧ gridCoordinate x q mesh ≤ x ∧
      x - mesh ≤ gridCoordinate x q mesh := by
  have h := floorOnGrid_bounds mesh (x / q) hmesh (div_nonneg hx hq.le)
  have hqx : q * (x / q) = x := by field_simp
  have hhi := mul_le_mul_of_nonneg_left h.2.1 hq.le
  have hlo := mul_le_mul_of_nonneg_left h.2.2 hq.le
  have hqm := mul_le_mul_of_nonneg_right hq1 hmesh.le
  rw [hqx] at hhi
  rw [mul_sub, hqx] at hlo
  exact ⟨mul_nonneg hq.le h.1, hhi, by unfold gridCoordinate; linarith⟩

omit [DecidableEq E] in
/-- Replacing the linear coordinates by the floored compensated values
preserves the physical constraints and loses at most one mesh per edge. -/
theorem grid_feasible_and_loss (ends : E → V × V)
    (p D mesh tau : ℝ) (hmesh : 0 < mesh)
    (x y w q : E → ℝ) (hxy : Joint.Feasible p D ends ends x y)
    (hq : ∀ e, 0 < q e ∧ q e ≤ 1) (hw : ∀ e, 0 ≤ w e ∧ w e ≤ tau) :
    let x' := fun e => gridCoordinate (x e) (q e) mesh
    Joint.Feasible p D ends ends x' y ∧
      (∑ e, w e * x e) - (Fintype.card E : ℝ) * mesh * tau ≤ ∑ e, w e * x' e := by
  dsimp only
  let x' (e : E) := gridCoordinate (x e) (q e) mesh
  have hb (e : E) := gridCoordinate_bounds (x e) (q e) mesh (hxy.x_nonneg e)
    (hq e).1 (hq e).2 hmesh
  refine ⟨⟨fun e => (hb e).1, hxy.y_nonneg, hxy.y_degree, ?_, ?_⟩, ?_⟩
  · intro v
    have hdeg : Joint.degree ends x' v ≤ Joint.degree ends x v :=
      Finset.sum_le_sum (fun e _ =>
        mul_le_mul_of_nonneg_left (hb e).2.1 (Joint.incidence_bounds ends v e).1)
    exact (add_le_add hdeg le_rfl).trans (hxy.shared_degree v)
  · intro e
    exact (add_le_add (hb e).2.1 le_rfl).trans (hxy.edge_bound e)
  · have hsum : (∑ e, (w e * x e - w e * x' e)) ≤ ∑ _e : E, mesh * tau := by
      apply Finset.sum_le_sum
      intro e he
      have h := mul_le_mul_of_nonneg_left (hb e).2.2 (hw e).1
      have hh := mul_le_mul_of_nonneg_left (hw e).2 hmesh.le
      change w e * x e - w e * x' e ≤ mesh * tau
      nlinarith only [h, hh]
    rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul] at hsum
    change (∑ e, w e * x e) - (Fintype.card E : ℝ) * mesh * tau ≤ ∑ e, w e * x' e
    nlinarith only [hsum]

/-- Instantiation with the genuine Shearer unmatched-pair probabilities. -/
theorem shearer_grid_feasible_and_loss (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (p D r mesh tau : ℝ) (hD : 2 * D < 1) (hDr : D = r * (1 - r))
    (hr0 : 0 < r) (hr1 : r ≤ 1) (hmesh : 0 < mesh)
    (x y w : E → ℝ) (hxy : Joint.Feasible p D ends ends x y)
    (hw : ∀ e, 0 ≤ w e ∧ w e ≤ tau) :
    let x' := fun e => gridCoordinate (x e) (pairProbability ends y (ends e).1 (ends e).2) mesh
    Joint.Feasible p D ends ends x' y ∧
      (∑ e, w e * x e) - (Fintype.card E : ℝ) * mesh * tau ≤ ∑ e, w e * x' e := by
  classical
  apply grid_feasible_and_loss ends p D mesh tau hmesh x y w _ hxy _ hw
  intro e
  let u := (ends e).1
  let v := (ends e).2
  let T := pairEnds ends
  have hy : ∀ i ∈ (Finset.univ : Finset E), 0 ≤ y i := fun i _ => hxy.y_nonneg i
  have hends : ∀ i ∈ (Finset.univ : Finset E), (T i).card = 2 :=
    fun i _ => pairEnds_card_two ends hloop i
  have hdegree (v : V) : Shearer.vertexDegree T Finset.univ y v ≤ r * (1 - r) := by
    rw [← hDr, show T = pairEnds ends from rfl, vertexDegree_pairEnds]
    exact hxy.y_degree v
  constructor
  · have hq := Shearer.unmatchedPair_union_bound T Finset.univ y r hr0 hr1 hy hends hdegree u v
    have hu := hdegree u
    have hv := hdegree v
    rw [← hDr] at hu hv
    change 0 < Shearer.unmatchedPair T Finset.univ y u v
    linarith
  · change Shearer.expectation T Finset.univ y
      (fun M => GibbsMatching.unmatched T u M * GibbsMatching.unmatched T v M) ≤ 1
    rw [← Shearer.expectation_const T Finset.univ y 1]
    apply Shearer.expectation_mono T Finset.univ y r hr0 hr1 hy hends hdegree
    intro M hM
    rcases Shearer.unmatched_zero_one T u M with hu | hu <;>
      rcases Shearer.unmatched_zero_one T v M with hv | hv <;> simp [hu, hv]

end

end SubmodularMatching.TwoStage
