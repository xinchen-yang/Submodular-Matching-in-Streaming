import SubmodularMatching.UpperBoundParametricStored
import SubmodularMatching.UpperBoundParametricSource
import SubmodularMatching.UpperBoundParametricScan

/-! # Family trial guarantee on the actual scheduled suffix and scan -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint Streaming TwoStage SourceCertificate GibbsSampler NumericalCertificate
open scoped BigOperators

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable {Ns Ng : ℕ}

/-- A surviving nonempty guess uses its own stored order and the fixed
family precision. -/
def parametricFinalGuessCandidate (P : ScheduledSource E V) (K : ℕ) (hK : 0 < K)
    (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ j < P.arrivals, P.edges i = P.edges j → i = j)
    (hloop : ∀ e, (P.ends e).1 ≠ (P.ends e).2)
    (Q : ℕ → ℕ) (draw : ∀ j, AppendixDraw (finalGuessCount P batches j) Ng)
    (j : ℕ) (hm : 0 < finalGuessCount P batches j) : CandidateLaw (Finset E) :=
  let C := finalGuessConfig P j
  parametricCompactGuessCandidate hm K hK C.p C.tau C.p_pos.le
    (P.probability_le_one (finalGuessScale P j)) (finalGuessEmbedding P batches hunique j) P.ends hloop
    (finalGuessFrozen P batches j) P.objective (Q j) (draw j)

def parametricFinalGuessCandidates (P : ScheduledSource E V) (K : ℕ) (hK : 0 < K)
    (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ j < P.arrivals, P.edges i = P.edges j → i = j)
    (hloop : ∀ e, (P.ends e).1 ≠ (P.ends e).2)
    (Q : ℕ → ℕ) (draw : ∀ j, AppendixDraw (finalGuessCount P batches j) Ng) : List (CandidateLaw (Finset E)) :=
  ((finalGuessIndices P).sort (· ≤ ·)).filterMap fun j =>
    if hm : 0 < finalGuessCount P batches j then
      some (parametricFinalGuessCandidate P K hK batches hunique hloop Q draw j hm) else none

theorem parametricFinalGuessCandidates_legal (P : ScheduledSource E V) (K : ℕ) (hK : 0 < K)
    (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ j < P.arrivals, P.edges i = P.edges j → i = j)
    (hloop : ∀ e, (P.ends e).1 ≠ (P.ends e).2)
    (Q : ℕ → ℕ) (draw : ∀ j, AppendixDraw (finalGuessCount P batches j) Ng) :
    ∀ q ∈ parametricFinalGuessCandidates P K hK batches hunique hloop Q draw,
      q.outcomes ⊆ arrivedMatchings P.ends P.edges P.arrivals := by
  intro q hq
  unfold parametricFinalGuessCandidates at hq
  obtain ⟨j, _, h⟩ := List.mem_filterMap.mp hq
  split_ifs at h with hm
  · obtain rfl := Option.some.inj h
    unfold parametricFinalGuessCandidate
    apply parametricCompactGuessCandidate_feasible
    unfold finalGuessEmbedding
    rw [storedEmbedding_image]
    exact finalGuessStored_arrived P batches j

def parametricGoodFinalOptimizers (P : ScheduledSource E V) (K : ℕ) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ j < P.arrivals, P.edges i = P.edges j → i = j)
    (Q : ℕ → ℕ) (draw : ∀ j, AppendixDraw (finalGuessCount P batches j) Ng) : Prop :=
  ∀ j ∈ finalGuessIndices P, ∀ hm : 0 < finalGuessCount P batches j,
    let m := finalGuessCount P batches j
    let e : ℝ := 1 / K
    let D := NumericalCertificate.degree
    let C := finalGuessConfig P j
    let emb := finalGuessEmbedding P batches hunique j
    let w := finalGuessFrozen P batches j ∘ emb
    let f := reindexedObjective emb P.objective
    0 < Q j ∧ (FiniteGreedy.stages D m e : ℝ) / Q j ≤ FiniteGreedy.accuracy D m e / 2 ∧
      parametricOptimizerAccurate hm K C.p C.tau (restrictEnds (P.ends ∘ emb)) w f (Q j) (draw j)

variable [Fintype E] [Fintype V]

/-- On the good finite trace, the same decisive-guess charge and sampler
schemes give FJ8 for the full range of chosen family parameters. -/
theorem parametricFinalTrial_quality
    (P : ScheduledSource E V) (hn : 2 ≤ P.vertices) (hvertices : P.vertices = Fintype.card V)
    (K : ℕ) (hK : 0 < K) (p : ℚ) (hp : 0 < p) (hp0 : (p : ℝ) ≤ coordinateCap)
    (he4 : (1 : ℝ) / K < 1 / 4) (hcap : (p : ℝ) ≤ (1 / (K : ℝ)) ^ 5 / 163840)
    (hε : P.epsilon = 1 / (K : ℝ)) (hconfig : P.config = parametricGuessConfig P.vertices hn K hK p hp hp0)
    (hcert : AppendixSourceObligation P.vertices hn)
    (batches : ℕ → Fin Ns → ℝ) (hNs : 0 < Ns)
    (hunique : ∀ i < P.arrivals, ∀ j < P.arrivals, P.edges i = P.edges j → i = j)
    (hloop : ∀ e, (P.ends e).1 ≠ (P.ends e).2)
    (hsimple : Function.Injective (pairEnds P.ends))
    (harrived : ∀ e, e ∈ arrivedEdges P.edges P.arrivals)
    (hv : 0 < Fintype.card V) (hE : 0 < Fintype.card E)
    (Q : ℕ → ℕ) (draw : ∀ j, AppendixDraw (finalGuessCount P batches j) Ng)
    (hstream : goodStreamingBatches P batches)
    (hoptimize : parametricGoodFinalOptimizers P K batches hunique Q draw)
    (M initial : Finset E) (hM : M ∈ arrivedMatchings P.ends P.edges P.arrivals)
    (hbest : P.objective initial = singletonMaximum P.value P.arrivals)
    (hB : 0 < singletonMaximum P.value P.arrivals) :
    let B := singletonMaximum P.value P.arrivals
    let e : ℝ := 1 / K
    let qs := parametricFinalGuessCandidates P K hK batches hunique hloop Q draw
    let y := scanExpectation P.objective (e * B / 2) P.objective qs initial
    B ≤ y ∧ (1 - e) * sigma * P.objective M ≤ y + 5 * e * B := by
  intro B e qs y
  have hε' : P.epsilon = e := hε
  have he : 0 < e := hε' ▸ P.epsilon_pos
  have he1 : e < 1 := by linarith
  have hv' : (2 : ℝ) ≤ P.vertices := by exact_mod_cast hn
  have hW : 2 ≤ P.width := by
    rw [ScheduledSource.width, hε']
    exact (le_div_iff₀ he).2 (by linarith)
  have ep_le : P.epsilon ≤ 1 / 4 := hε ▸ he4.le
  have hη : min sigma beta = sigma := min_eq_left (by norm_num [sigma, beta])
  have hRecip : 2 / e = ↑((2 * K : ℕ) : ℤ) := by
    dsimp only [e]
    rw [div_div_eq_mul_div, div_one]
    push_cast
    rfl
  obtain ⟨j, ha, hbelow, hupper⟩ := finalGuess_exists P hW hB
  let τ := finalGuessScale P j
  let C := finalGuessConfig P j
  let input := finalGuessInput P batches j
  let n := finalGuessLength P j
  have hτ : 0 < τ := hB.trans_le hbelow
  have hCt : C.tau = τ := P.config_tau τ hτ
  have hpC : C.p = p := by unfold C finalGuessConfig; rw [hconfig, parametricGuessConfig_p]
  have hpD : C.p ≤ 1 - NumericalCertificate.degree := by
    rw [hpC]
    exact hp0.trans (by norm_num [coordinateCap, degree_exact])
  have hj : j ∈ finalGuessIndices P :=
    (mem_activeGuessIndices _ _ _ _ _ (guessAnchor_pos _ _ _ hB) (guessAnchor_le _ _ _) P.width_bound).2 ha
  obtain ⟨hsubM, hmatching⟩ := (GibbsMatching.mem_matchings _ _ _).mp hM
  have hsize : 2 * M.card ≤ P.vertices := by
    rw [hvertices]
    exact arrived_matching_card P.ends P.edges P.arrivals (fun d _ => hloop d) M hM
  have hcharge := P.final_suffix_charge batches j M hNs ep_le hn hmatching hsubM hsize
    (fun i _ => hloop (P.edges i)) ha (fun t ht => by
      rw [hconfig, hε]
      have h := parametricGuessConfig_spec P.vertices hn K hK p hp hp0 t ht
      rw [h.1, parametricGuessConfig_p]
      exact ⟨h.2.1, h.2.2.2⟩) hstream
  dsimp only at hcharge
  rw [hε'] at hcharge
  have hτB : C.tau ≤ 2 * B := hCt ▸ hupper.le
  have hBτ : B ≤ C.tau := hCt ▸ hbelow
  by_cases hm : 0 < finalGuessCount P batches j
  · let emb := finalGuessEmbedding P batches hunique j
    let w := finalGuessFrozen P batches j
    let q := parametricFinalGuessCandidate P K hK batches hunique hloop Q draw j hm
    let O := compactOptimum emb M
    let I := coveredBit P.ends (O.map emb)
    let X := C.p * ((runPotential C P.ends input n).stored.sum w) +
      ∑ v, unmatched (I v) * idealPotential C P.ends input n v
    let g := traceResidual C P.ends input P.objective n (O.map emb)
    have hu := finalGuessInput_distinct P batches j hunique
    have hS : Finset.univ.map emb = (runPotential C P.ends input n).stored :=
      storedEmbedding_image C P.ends input n hu
    have hrec (i : ℕ) (hi : i < n) : (input i).2 = w (input i).1 :=
      (traceWeightIndex_record input n hu i hi).symm
    have hwbox := finalGuessInput_bounds P batches j ha hstream
    have hCnonneg : 0 ≤ C.tau := by rw [hCt]; exact hτ.le
    have hw : ∀ d, 0 ≤ w d ∧ w d ≤ C.tau := traceWeightIndex_bounds input n _ hCnonneg hu
      (fun i hi => ⟨(hwbox i hi).1, (hwbox i hi).2.1⟩)
    have hacc : ∀ i < n, (input i).2 ≤ traceWeight C P.ends input P.objective i :=
      fun i hi => (hwbox i hi).2.2
    have hcompact : P.objective M ≤ X + g + 6 * e * C.tau :=
      charge_on_compact_optimum C P.ends input n w P.objective M _ _ hu hrec emb hS hcharge
    have hX : 0 ≤ X := by
      apply add_nonneg (mul_nonneg C.p_pos.le (Finset.sum_nonneg fun d _ => (hw d).1))
      exact Finset.sum_nonneg fun v _ => mul_nonneg (by cases I v <;> norm_num [unmatched, bit])
        (ideal_trace_nonnegative C P.ends input n v)
    have hg : 0 ≤ g := by
      have hh := traceResidual_properties C P.ends input P.objective n
        (P.probability_le_one τ) P.submodular P.monotone
      rw [← hh.1]
      exact hh.2.1 ∅ _ (Finset.empty_subset _)
    have hsingle (d : E) : P.objective {d} ≤ B := by
      obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp (harrived d)
      exact singleton_le_maximum P.value (Finset.mem_range.mp hi)
    have hcert' : RunSourceConditions appendixPotentialTable.sourceFunction C
        NumericalCertificate.degree sigma (SourceRateTable.appendixCmax : ℝ) := by
      unfold C finalGuessConfig
      rw [hconfig]
      exact parametricGuessConfig_source P.vertices hn K hK p hp hp0 τ hτ hcert
    obtain ⟨hQ, hgrid, hmean⟩ := hoptimize j hj hm
    have hcap' : C.p ≤ e ^ 5 / 163840 := hpC.symm ▸ hcap
    have hvalue := parametricCompactGuessCandidate_value K hK C appendixPotentialTable.sourceFunction _ hcert'
      (P.probability_le_one τ) hpD he1 hcap' P.ends hloop hsimple hv hE input n hu
      P.objective P.submodular P.monotone P.normalized B hB.le hBτ hsingle w hw hrec hacc hm emb hS rfl
      (storedEmbedding_order C P.ends input n hu hm) O
      (compactOptimum_isMatching emb M P.ends hmatching) I (coveredBit_compact emb O P.ends)
      (Q j) hQ (draw j) hgrid hmean
    have hin : q ∈ qs := List.mem_filterMap.mpr ⟨j, (Finset.mem_sort (· ≤ ·)).2 hj, dif_pos hm⟩
    have h := parametricScan_error_budget P.objective qs initial q hin e (1 - e) sigma beta
      (P.objective M) X g C.tau B he (sub_nonneg.mpr he1.le) (by linarith)
      sigma_pos.le (by norm_num [beta]) (by norm_num [beta]) _ hRecip
      hbest hB hτB hX hg hcompact hvalue
    simpa only [hη] using h
  · have hm0 : finalGuessCount P batches j = 0 := Nat.eq_zero_of_not_pos hm
    have hempty : (runPotential C P.ends input n).stored = ∅ := by
      rw [← acceptedOrder_toFinset]
      have hz : (acceptedOrder C P.ends input n).length = 0 := hm0
      rw [List.length_eq_zero_iff.mp hz, List.toFinset_nil]
    have hsmall := empty_guess_charge C P.ends input P.objective n M e
      (P.probability_le_one τ) P.submodular P.monotone hempty hcharge
    let step := e * B / 2
    have hs : 0 < step := by dsimp [step]; positivity
    have href : P.objective initial = step * ↑((2 * K : ℕ) : ℤ) := by
      rw [hbest, ← hRecip]
      change B = (e * B / 2) * (2 / e)
      field_simp
    have hkeep := hbest.symm.le.trans
      (scanExpectation_keeps_reference P.objective step hs qs initial _ href)
    refine ⟨hkeep, ?_⟩
    have hM0 : 0 ≤ P.objective M := by
      simpa only [P.normalized] using P.monotone ∅ M (Finset.empty_subset M)
    have hθσ : (1 - e) * sigma ≤ 1 / 4 := by
      calc
        _ ≤ 1 * sigma := mul_le_mul_of_nonneg_right (by linarith) sigma_pos.le
        _ ≤ _ := by norm_num [sigma]
    have h0 := mul_nonneg he.le hB.le
    have hs' : 6 * e * C.tau ≤ 12 * e * B := by nlinarith only [mul_le_mul_of_nonneg_left hτB he.le]
    calc
      _ ≤ (1 / 4 : ℝ) * P.objective M := mul_le_mul_of_nonneg_right hθσ hM0
      _ ≤ (1 / 4 : ℝ) * (12 * e * B) := mul_le_mul_of_nonneg_left (hsmall.trans hs') (by norm_num)
      _ ≤ y + 5 * e * B := by nlinarith only [hkeep, hB.le, h0]

end

end SubmodularMatching.UpperBoundAssembly
