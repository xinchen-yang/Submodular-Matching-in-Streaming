import SubmodularMatching.SampledGreedyProduct
import SubmodularMatching.SampledGreedyHistory

/-!
# One fresh stage of the sampled optimizer

The single-coordinate pair law is pushed onto pairs of subsets of the stored
graph. This makes its outcome type independent of the incoming iterate. A
stage draws these fixed-type batches for every coordinate and may use them
in the subsequent Euler update.
-/

open MeasureTheory ProbabilityTheory

namespace SubmodularMatching.Multilinear

noncomputable section

variable {E : Type*} [DecidableEq E]

private theorem roundedProbability_valid (p : ℝ) (bits : ℕ) (hp : 0 ≤ p ∧ p ≤ 1) :
    0 ≤ Streaming.bitProbability p bits ∧ Streaming.bitProbability p bits ≤ 1 := by
  have h := Streaming.bitProbability_bounds hp.1 bits
  exact ⟨h.1, h.2.1.trans hp.2⟩

private theorem omittedProbability_valid (q : ℕ → ℝ) (k n : ℕ)
    (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1) :
    ∀ i < n, 0 ≤ omitCoordinate q k i ∧ omitCoordinate q k i ≤ 1 := by
  intro i hi
  by_cases h : i = k
  · simp [omitCoordinate, h]
  · simpa only [omitCoordinate, h, ↓reduceIte] using hq i hi

/-- Distribution of the actual pair of sets, in `(R,Z)` order. Its type is
the same for every conditional history and every coordinate. -/
def dyadicPairLaw (edges : ℕ → E) (p : ℝ) (q : ℕ → ℝ) (n k bits : ℕ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1) :
    PMF (Finset E × Finset E) :=
  let bp := fun _ => Streaming.bitProbability p bits
  let bq := fun i => Streaming.bitProbability (omitCoordinate q k i) bits
  let zs := bernoulliOutcomes edges bq n
  let rs := bernoulliOutcomes edges bp n
  (samplePairLaw zs rs (bernoulliOutcomes_total_mass edges bq n)
    (bernoulliOutcomes_total_mass edges bp n)
    (bernoulliOutcomes_nonnegative edges bq n (fun i hi =>
      roundedProbability_valid _ bits (omittedProbability_valid q k n hq i hi)))
    (bernoulliOutcomes_nonnegative edges bp n (fun _ _ => roundedProbability_valid p bits hp))).map
    (fun i => ((rs.get i.2).1, (zs.get i.1).1))

variable [Fintype E]

/-- A whole fresh batch, with sample outcomes represented directly as sets. -/
theorem dyadic_pair_average_failure (edges : ℕ → E) (p : ℝ) (q : ℕ → ℝ)
    (f : Finset E → ℝ) (n k bits : ℕ) (τ ξ δ : ℝ) (hk : k < n)
    (hτ : 0 < τ) (hξ : 0 < ξ) (hδ : 0 < δ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1)
    (hF : ∀ A, 0 ≤ marginal f (edges k) A ∧ marginal f (edges k) A ≤ τ)
    (hb : (n : ℝ) * (1 / (2 : ℝ) ^ bits) ≤ ξ / 16)
    (N : ℕ) (hN : 0 < N) (hcount : 8 / ξ ^ 2 * Real.log (2 / δ) ≤ N)
    [MeasurableSpace (Finset E × Finset E)]
    [MeasurableSingletonClass (Finset E × Finset E)] :
    let μ := Measure.pi (fun _ : Fin N => (dyadicPairLaw edges p q n k bits hp hq).toMeasure)
    let gradient := coordinateDerivative edges q (residualValue edges p f n) n k
    μ.real {ω | ξ * τ / 2 < |Streaming.sourceAverage (ξ * τ / 2) (fun i =>
      derivativeSample f (edges k) (ω i).1 (ω i).2) - gradient|} ≤ δ := by
  intro μ gradient
  let bp : ℕ → ℝ := fun _ => Streaming.bitProbability p bits
  let bq := fun i => Streaming.bitProbability (omitCoordinate q k i) bits
  let zs := bernoulliOutcomes edges bq n
  let rs := bernoulliOutcomes edges bp n
  let Pair := Fin zs.length × Fin rs.length
  letI : MeasurableSpace Pair := ⊤
  letI : MeasurableSingletonClass Pair := ⟨fun _ => trivial⟩
  let law := samplePairLaw zs rs (bernoulliOutcomes_total_mass edges bq n)
    (bernoulliOutcomes_total_mass edges bp n)
    (bernoulliOutcomes_nonnegative edges bq n (fun i hi =>
      roundedProbability_valid _ bits (omittedProbability_valid q k n hq i hi)))
    (bernoulliOutcomes_nonnegative edges bp n (fun _ _ => roundedProbability_valid p bits hp))
  let decode (i : Pair) := ((rs.get i.2).1, (zs.get i.1).1)
  let mapped := fun ω : Fin N → Pair => fun i => decode (ω i)
  have hdecode : Measurable decode := measurable_of_finite _
  have hmapped : Measurable mapped :=
    measurable_pi_lambda _ (fun i => hdecode.comp (measurable_pi_apply i))
  have hprob (i : Fin N) : IsProbabilityMeasure (law.toMeasure.map decode) := by
    rw [PMF.toMeasure_map decode law hdecode]
    infer_instance
  letI : ∀ i : Fin N, SigmaFinite (law.toMeasure.map decode) := fun i => by
    letI := hprob i
    infer_instance
  have hmap : (Measure.pi (fun _ : Fin N => law.toMeasure)).map mapped = μ := by
    rw [Measure.pi_map_pi (fun _ => hdecode.aemeasurable)]
    simp only [PMF.toMeasure_map decode law hdecode]
    rfl
  rw [← hmap, map_measureReal_apply hmapped (Set.toFinite _).measurableSet]
  exact dyadic_derivative_failure edges p q f n k bits τ ξ δ hk hτ hξ hδ hp hq hF hb N hN hcount

end

end SubmodularMatching.Multilinear
