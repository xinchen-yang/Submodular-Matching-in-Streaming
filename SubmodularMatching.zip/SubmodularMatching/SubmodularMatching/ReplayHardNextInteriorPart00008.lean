import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step100 : ProjectedGoal ⟨432, 647, 0, 283, 283, 567⟩ :=
  projectedGoal_chunk _ (.leaf 0xd7f0000574fbde600061022) (by decide +kernel)

theorem Part00008 : ProjectedGoal ⟨432, 647, 0, 283, 283, 567⟩ := step100

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
