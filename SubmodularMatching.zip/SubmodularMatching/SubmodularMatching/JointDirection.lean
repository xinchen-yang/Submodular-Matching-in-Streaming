import SubmodularMatching.JointPolytope

/-!
# An actual finite direction solver for the joint polytope

This instantiates the proved clipped-dual packing algorithm with the concrete
joint matrix and objective coefficients. The output is exactly feasible and
has a physical objective loss at most `epsilon * tau` against every feasible
comparator. No linear-optimization oracle is assumed.
-/

open scoped BigOperators

namespace SubmodularMatching.Joint

noncomputable section

variable {X Y V : Type*} [Fintype X] [Fintype Y] [Fintype V]
  [DecidableEq X] [DecidableEq Y] [DecidableEq V]

/-- The physical weighted direction objective. -/
def directionObjective (kappa a : ℝ) (w : X → ℝ) (gradient : Y → ℝ)
    (x : X → ℝ) (y : Y → ℝ) : ℝ :=
  kappa * (∑ e, w e * x e) + a * (∑ f, gradient f * y f)

/-- Normalized coefficients supplied to the bounded packing solver. -/
def directionCoefficient (p D tau kappa a : ℝ) (w : X → ℝ) (gradient : Y → ℝ) :
    X ⊕ Y → ℝ
  | .inl e => kappa * p * w e / tau
  | .inr f => a * D * gradient f / tau

omit [Fintype X] [Fintype Y] [Fintype V] [DecidableEq X] [DecidableEq Y] [DecidableEq V] in
/-- All supplied coefficients lie in the range required by the finite solver. -/
theorem directionCoefficient_bounds (p D tau kappa a : ℝ) (w : X → ℝ) (gradient : Y → ℝ)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (hD : 0 ≤ D) (hD1 : D ≤ 1)
    (htau : 0 < tau) (hk : 0 ≤ kappa) (hk1 : kappa ≤ 1) (ha : 0 ≤ a) (ha1 : a ≤ 1)
    (hw : ∀ e, 0 ≤ w e ∧ w e ≤ tau) (hg : ∀ f, 0 ≤ gradient f ∧ gradient f ≤ tau) :
    ∀ c, 0 ≤ directionCoefficient p D tau kappa a w gradient c ∧
      directionCoefficient p D tau kappa a w gradient c ≤ 1 := by
  intro c
  rcases c with e | f
  · refine ⟨div_nonneg (mul_nonneg (mul_nonneg hk hp) (hw e).1) htau.le, ?_⟩
    apply (div_le_one htau).2
    exact (mul_le_mul_of_nonneg_right (mul_le_one₀ hk1 hp hp1) (hw e).1).trans
      (by simpa using (hw e).2)
  · refine ⟨div_nonneg (mul_nonneg (mul_nonneg ha hD) (hg f).1) htau.le, ?_⟩
    apply (div_le_one htau).2
    exact (mul_le_mul_of_nonneg_right (mul_le_one₀ ha1 hD hD1) (hg f).1).trans
      (by simpa using (hg f).2)

omit [Fintype V] [DecidableEq X] [DecidableEq Y] [DecidableEq V] in
/-- Rescaling the normalized objective gives exactly the physical objective. -/
theorem directionObjective_scaled (p D tau kappa a : ℝ) (w : X → ℝ) (gradient : Y → ℝ)
    (htau : tau ≠ 0) (t : X ⊕ Y → ℝ) :
    tau * LinearPacking.objective (directionCoefficient p D tau kappa a w gradient) t =
      directionObjective kappa a w gradient
        (fun e => p * t (.inl e)) (fun f => D * t (.inr f)) := by
  simp only [LinearPacking.objective, Fintype.sum_sum_type, directionCoefficient,
    directionObjective, mul_add, Finset.mul_sum]
  congr 1
  · apply Finset.sum_congr rfl
    intro e _
    field_simp
  · apply Finset.sum_congr rfl
    intro f _
    field_simp

/-- Normalizing any physical comparator. -/
def normalize (p D : ℝ) (x : X → ℝ) (y : Y → ℝ) : X ⊕ Y → ℝ
  | .inl e => x e / p
  | .inr f => y f / D

/-- The actual deterministic finite direction algorithm. -/
def solveDirection (p D tau kappa a epsilon : ℝ)
    (endsX : X → V × V) (endsY : Y → V × V) (w : X → ℝ) (gradient : Y → ℝ) :
    X ⊕ Y → ℝ :=
  LinearPacking.solve (matrix p D endsX endsY)
    (directionCoefficient p D tau kappa a w gradient) epsilon

omit [DecidableEq Y] in
/-- Exact feasibility and additive optimality of the actual direction solver.
Every feasible comparator is covered simultaneously by this conclusion. -/
theorem solveDirection_correct (p D tau kappa a epsilon : ℝ)
    (endsX : X → V × V) (endsY : Y → V × V) (w : X → ℝ) (gradient : Y → ℝ)
    (hp : 0 < p) (hp1 : p ≤ 1) (hD : 0 < D) (hD2 : 2 * D ≤ 1)
    (htau : 0 < tau) (hk : 0 ≤ kappa) (hk1 : kappa ≤ 1) (ha : 0 ≤ a) (ha1 : a ≤ 1)
    (hw : ∀ e, 0 ≤ w e ∧ w e ≤ tau) (hg : ∀ f, 0 ≤ gradient f ∧ gradient f ≤ tau)
    (hM : 1 ≤ Fintype.card (V ⊕ V ⊕ X)) (hN : 1 ≤ Fintype.card (X ⊕ Y))
    (heps : 0 < epsilon) (heps1 : epsilon ≤ 1) :
    let t := solveDirection p D tau kappa a epsilon endsX endsY w gradient
    Feasible p D endsX endsY (fun e => p * t (.inl e)) (fun f => D * t (.inr f)) ∧
      ∀ x y, Feasible p D endsX endsY x y →
        directionObjective kappa a w gradient x y - epsilon * tau ≤
          directionObjective kappa a w gradient
            (fun e => p * t (.inl e)) (fun f => D * t (.inr f)) := by
  have hD1 : D ≤ 1 := by linarith
  have hc := LinearPacking.solve_correct (matrix p D endsX endsY)
    (directionCoefficient p D tau kappa a w gradient) epsilon
    (matrix_bounds p D endsX endsY hp.le hp1 hD.le hD2)
    (directionCoefficient_bounds p D tau kappa a w gradient hp.le hp1 hD.le hD1
      htau hk hk1 ha ha1 hw hg) hM hN heps heps1
  dsimp only
  constructor
  · exact feasible_of_packing p D endsX endsY hp.le hD.le _ (fun c => (hc.1 c).1) hc.2.1
  · intro x y hxy
    have hpx : (fun e => p * normalize p D x y (.inl e)) = x := by
      funext e
      dsimp [normalize]
      field_simp
    have hDy : (fun f => D * normalize p D x y (.inr f)) = y := by
      funext f
      dsimp [normalize]
      field_simp
    have hn : Feasible p D endsX endsY
        (fun e => p * normalize p D x y (.inl e))
        (fun f => D * normalize p D x y (.inr f)) := by
      rw [hpx, hDy]
      exact hxy
    have hnorm := packing_of_feasible p D endsX endsY hp hD _ hn
    have hh := mul_le_mul_of_nonneg_left
      (hc.2.2 (normalize p D x y) hnorm.1 hnorm.2) htau.le
    rw [mul_sub, directionObjective_scaled p D tau kappa a w gradient htau.ne',
      directionObjective_scaled p D tau kappa a w gradient htau.ne', hpx, hDy] at hh
    simpa only [solveDirection, mul_comm tau epsilon] using hh

end

end SubmodularMatching.Joint
