import SubmodularMatching.CapacityFlagProduct
import Mathlib.Data.Fintype.Perm
import Mathlib.Data.Fintype.EquivFin

/-! # Uniform occupied slot sets as the images of uniform incidence injections -/

namespace SubmodularMatching.Capacity
open Finset
noncomputable section

abbrev Filling (k b : ℕ) (s : Finset (Fin b)) := {f : Fin k ↪ Fin b // univ.map f = s}

def fillingBijections (k b : ℕ) (s : Finset (Fin b)) : Filling k b s ≃ (Fin k ≃ ↑s) where
  toFun f := Equiv.ofBijective (fun i => (⟨f.val i, by exact (congrArg (fun t : Finset (Fin b) => f.val i ∈ t) f.property).mp (mem_map.mpr ⟨i,mem_univ _,rfl⟩)⟩ : s)) (by
    refine ⟨fun i j h => f.val.injective (congrArg Subtype.val h),?_⟩
    intro x
    have hx := (congrArg (fun t : Finset (Fin b) => x.val ∈ t) f.property).mpr x.property
    obtain ⟨i,_,hi⟩ := mem_map.mp hx
    exact ⟨i,Subtype.ext hi⟩)
  invFun g := ⟨g.toEmbedding.trans (Function.Embedding.subtype _),by
    ext x
    constructor
    · intro hx
      obtain ⟨i,_,rfl⟩ := mem_map.mp hx
      exact (g i).property
    · intro hx
      obtain ⟨i,hi⟩ := g.surjective ⟨x,hx⟩
      exact mem_map.mpr ⟨i,mem_univ _,congrArg Subtype.val hi⟩⟩
  left_inv _ := by ext i; rfl
  right_inv _ := by ext i; rfl

/-- Every occupied shape in the uniform flag sample is attainable, and its
number of fillings is independent of the shape. -/
theorem filling_count (k b : ℕ) (s : Occupied b k) :
    Fintype.card (Filling k b s.val) = Fintype.card (Equiv.Perm (Fin k)) := by
  classical
  have hc : Fintype.card (↑s.val) = Fintype.card (Fin k) := by
    simpa only [Fintype.card_coe,Fintype.card_fin] using (mem_powersetCard.mp s.property).2
  exact (Fintype.card_congr (fillingBijections k b s.val)).trans
    (Fintype.card_congr (Equiv.equivCongr (Equiv.refl (Fin k)) (Fintype.equivOfCardEq hc)))

theorem realizes_occupied_shape {E V : Type*} [DecidableEq V] (ends : E → V × V)
    (O : Finset E) (b : V → ℕ) (v : V) (s : Occupied (b v) (incidences ends O v).card) :
    ∃ f : ↑(incidences ends O v) ↪ Fin (b v), univ.map f = s.val := by
  classical
  let k := (incidences ends O v).card
  have hp : 0 < Fintype.card (Filling k (b v) s.val) := (filling_count k _ s) ▸ Fintype.card_pos
  obtain ⟨f⟩ := Fintype.card_pos_iff.mp hp
  let e : ↑(incidences ends O v) ≃ Fin k := Fintype.equivFinOfCardEq (Fintype.card_coe _)
  refine ⟨e.toEmbedding.trans f.val,?_⟩
  rw [← map_map,univ_map_equiv_to_embedding]
  exact f.property

end
end SubmodularMatching.Capacity
