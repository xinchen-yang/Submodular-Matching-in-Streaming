import SubmodularMatching.StreamingOnlineReplay

/-!
# Reading one fresh compact batch from the sparse archive
-/

namespace SubmodularMatching.Streaming

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The actual estimator reads exactly the context's compact word block
when the sparse archive has its reference order. -/
theorem OnlineInstance.weightIndex_wordObserve (st : OnlineInstance E V)
    (ctx : EstimateContext E V) (oracle : Finset E → ℚ) (p gap : ℚ)
    (hordered : st.edges.map Prod.fst = ctx.ordered) (hgap : (gap : ℝ) = ctx.config.gap)
    {N : ℕ} (draw : WordBatch N ctx.ordered.length ctx.bits) :
    st.weightIndex oracle (ctx.input ctx.index).1 gap (dyadicThreshold p ctx.bits) N
        (fun k => if hk : k < N then finiteWord (2 ^ ctx.bits) ctx.ordered.length (draw ⟨k, hk⟩)
          else fun _ => 0) =
      sourceWeightIndex N (sourceIndex ctx.config.gap (fun j => ctx.wordObserve oracle p (draw j))) := by
  let edge := (ctx.input ctx.index).1
  have hlen : st.edges.length = ctx.ordered.length := by
    rw [← hordered, List.length_map]
  have hget : (fun i => (st.edges.getD i (edge, 0)).1) = fun i => ctx.ordered.getD i edge := by
    funext i
    rw [← hordered]
    exact (List.getD_map st.edges (edge, 0) Prod.fst).symm
  unfold OnlineInstance.weightIndex
  dsimp only
  rw [accumulateMarginalLoop_eq, zero_add, accumulateMarginal_eq_sourceIndex, hgap, hget, hlen]
  apply congrArg (sourceWeightIndex N)
  apply congrArg (sourceIndex ctx.config.gap)
  funext j
  rw [dif_pos j.isLt]
  rfl

end

end SubmodularMatching.Streaming
