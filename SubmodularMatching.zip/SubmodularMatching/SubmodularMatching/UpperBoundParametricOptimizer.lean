import SubmodularMatching.UpperBoundOptimizerTapeFailure

/-! # Chronological sampled-optimizer law at fixed family accuracy -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint Streaming GibbsSampler MeasureTheory ProbabilityTheory
open NumericalCertificate (degree_bounds)

noncomputable section

/-- The adaptive sampler uses the same fixed p and finite error at every stage. -/
structure FamilyOptimizerSettings where
  p : ℝ
  error : ℝ
  probabilityBounds : 0 ≤ p ∧ p ≤ 1
  error_pos : 0 < error
  error_lt_one : error < 1

variable {m N : ℕ} {V : Type*} [Fintype V] [DecidableEq V]
variable (cfg : FamilyOptimizerSettings)

def parametricOptimizerPoint (ends : Fin m → V × V) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) (Q : ℕ) (t : OptimizerTape m N) :
    ℕ → Fin m ⊕ Fin m → ℝ :=
  sampledPoint cfg.p NumericalCertificate.degree tau cfg.error ends w
    (oracleCoefficient NumericalCertificate.degree tau cfg.error Q f t.draw)

theorem parametricOptimizerPoint_prefix (ends : Fin m → V × V) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) (Q : ℕ) (t u : OptimizerTape m N) (j : ℕ)
    (h : ∀ k < j, t.batches k = u.batches k) :
    parametricOptimizerPoint cfg ends tau w f Q t j = parametricOptimizerPoint cfg ends tau w f Q u j := by
  induction j with
  | zero => rfl
  | succ j ih =>
    unfold parametricOptimizerPoint
    rw [sampledPoint_batch_update, sampledPoint_batch_update,
      show sampledPoint cfg.p NumericalCertificate.degree tau cfg.error ends w
        (oracleCoefficient NumericalCertificate.degree tau cfg.error Q f t.draw) j =
        sampledPoint cfg.p NumericalCertificate.degree tau cfg.error ends w
        (oracleCoefficient NumericalCertificate.degree tau cfg.error Q f u.draw) j from
        ih (fun k hk => h k (Nat.lt_succ_of_lt hk))]
    have h' := h j (Nat.lt_succ_self j)
    simp only [OptimizerTape.draw, h']

def parametricOptimizerStageGood (hm : 0 < m) (tau : ℝ) (f : Finset (Fin m) → ℝ)
    (j : ℕ) (t : Fin m ⊕ Fin m → ℝ) (samples : DerivativeSamples m N) : Bool := by
  classical
  let D := NumericalCertificate.degree
  let K := FiniteGreedy.stages D m cfg.error
  let ξ := FiniteGreedy.accuracy D m cfg.error
  let g := residualValue (enumerateEdge hm) cfg.p f m
  exact decide (∀ e : Fin m, ¬(j < K ∧ ξ * tau / 2 <
    |snappedCoordinate f ξ tau samples e - exactGradient hm D g t e|))

def parametricOptimizerTapeNext (hm : 0 < m) (ends : Fin m → V × V) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) (Q : ℕ) (j : ℕ) (t : OptimizerTape m N)
    (samples : DerivativeSamples m N) : OptimizerTape m N :=
  ⟨Function.update t.batches j samples,
    t.good && parametricOptimizerStageGood cfg hm tau f j (parametricOptimizerPoint cfg ends tau w f Q t j) samples⟩

theorem parametricOptimizerTapeNext_point (hm : 0 < m) (ends : Fin m → V × V) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) (Q : ℕ) (j : ℕ) (t : OptimizerTape m N)
    (samples : DerivativeSamples m N) :
    parametricOptimizerPoint cfg ends tau w f Q (parametricOptimizerTapeNext cfg hm ends tau w f Q j t samples) (j + 1) =
      advanceSampledPoint cfg.p NumericalCertificate.degree tau cfg.error Q ends f w j
        (parametricOptimizerPoint cfg ends tau w f Q t j) samples := by
  let u := parametricOptimizerTapeNext cfg hm ends tau w f Q j t samples
  have h := parametricOptimizerPoint_prefix cfg ends tau w f Q u t j (fun k hk => by
    simp [u, parametricOptimizerTapeNext, Function.update_of_ne (Nat.ne_of_lt hk)])
  change sampledPoint cfg.p NumericalCertificate.degree tau cfg.error ends w
    (oracleCoefficient NumericalCertificate.degree tau cfg.error Q f u.draw) (j + 1) = _
  rw [sampledPoint_batch_update]
  change advanceSampledPoint _ _ _ _ _ _ _ _ _ (parametricOptimizerPoint cfg ends tau w f Q u j)
      (u.batches j) = _
  have hSample : u.batches j = samples := by simp [u, parametricOptimizerTapeNext]
  rw [h, hSample]

/-- One chronological stage, with a finite distribution on the fresh
sample batch conditional on the current point. -/
def parametricOptimizerTapeStep (hm : 0 < m) (ends : Fin m → V × V) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) (Q bits : ℕ) (j : ℕ) (t : OptimizerTape m N) :
    CandidateLaw (OptimizerTape m N) := by
  classical
  letI : MeasurableSpace (Finset (Fin m) × Finset (Fin m)) := ⊤
  letI : MeasurableSingletonClass (Finset (Fin m) × Finset (Fin m)) := ⟨fun _ => trivial⟩
  let μ := stageMeasure (N := N) hm cfg.p NumericalCertificate.degree bits cfg.probabilityBounds
    (parametricOptimizerPoint cfg ends tau w f Q t j)
  exact (CandidateLaw.ofMeasure μ).map (parametricOptimizerTapeNext cfg hm ends tau w f Q j t)

/-- The schedule uses a finite number of freshly drawn adaptive stages. -/
def parametricOptimizerTapeLaw (hm : 0 < m) (ends : Fin m → V × V) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) (Q bits : ℕ) : CandidateLaw (OptimizerTape m N) :=
  CandidateLaw.execute (parametricOptimizerTapeStep cfg hm ends tau w f Q bits)
    (FiniteGreedy.stages NumericalCertificate.degree m cfg.error) 0 (OptimizerTape.empty m N)


private def parametricOptimizerPrefixAccurate (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q q : ℕ)
    (t : OptimizerTape m N) : Prop :=
  t.good = true → ∀ j < q, j < FiniteGreedy.stages NumericalCertificate.degree m cfg.error →
    ∀ e, let ξ := FiniteGreedy.accuracy NumericalCertificate.degree m cfg.error
      let g := residualValue (enumerateEdge hm) cfg.p f m
      |snappedCoordinate f ξ tau (t.batches j) e - exactGradient hm NumericalCertificate.degree g
        (parametricOptimizerPoint cfg ends tau w f Q t j) e| ≤ ξ * tau / 2

theorem parametricOptimizerTape_accurate (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q bits : ℕ)
    (t : OptimizerTape m N) (ht : t ∈ (parametricOptimizerTapeLaw cfg hm ends tau w f Q bits).outcomes)
    (hg : t.good = true) : ∀ j < FiniteGreedy.stages NumericalCertificate.degree m cfg.error, ∀ e,
      let ξ := FiniteGreedy.accuracy NumericalCertificate.degree m cfg.error
      let g := residualValue (enumerateEdge hm) cfg.p f m
      |snappedCoordinate f ξ tau (t.batches j) e - exactGradient hm NumericalCertificate.degree g
        (parametricOptimizerPoint cfg ends tau w f Q t j) e| ≤ ξ * tau / 2 := by
  classical
  let D := NumericalCertificate.degree
  let K := FiniteGreedy.stages D m cfg.error
  let ξ := FiniteGreedy.accuracy D m cfg.error
  let g := residualValue (enumerateEdge hm) cfg.p f m
  let inv := parametricOptimizerPrefixAccurate cfg (N := N) hm ends tau w f Q
  have hi : inv 0 (OptimizerTape.empty m N) := by intro _ j hj; omega
  have hstep (j : ℕ) (s : OptimizerTape m N) (hs : inv j s)
      (u : OptimizerTape m N) (hu : u ∈ (parametricOptimizerTapeStep cfg hm ends tau w f Q bits j s).outcomes) :
      inv (j + 1) u := by
    unfold parametricOptimizerTapeStep CandidateLaw.map at hu
    obtain ⟨batch, _, rfl⟩ := Finset.mem_image.mp hu
    let u := parametricOptimizerTapeNext cfg hm ends tau w f Q j s batch
    have hup (k : ℕ) (hk : k < j) : u.batches k = s.batches k := by
      simp [u, parametricOptimizerTapeNext, Function.update_of_ne (Nat.ne_of_lt hk)]
    have hpoint (k : ℕ) (hk : k ≤ j) :
        parametricOptimizerPoint cfg ends tau w f Q u k = parametricOptimizerPoint cfg ends tau w f Q s k :=
      parametricOptimizerPoint_prefix cfg ends tau w f Q u s k (fun a ha => hup a (ha.trans_le hk))
    intro hgood k hk hkK e
    change (s.good && parametricOptimizerStageGood cfg hm tau f j (parametricOptimizerPoint cfg ends tau w f Q s j) batch) = true
      at hgood
    simp only [Bool.and_eq_true] at hgood
    obtain ⟨hsg, hlocal⟩ := hgood
    change |snappedCoordinate f ξ tau (u.batches k) e -
      exactGradient hm D g (parametricOptimizerPoint cfg ends tau w f Q u k) e| ≤ ξ * tau / 2
    rw [hpoint k (by omega)]
    rcases lt_or_eq_of_le (Nat.le_of_lt_succ hk) with hlt | heq
    · rw [hup k hlt]
      exact hs hsg k hlt hkK e
    · subst k
      have hbatch : u.batches j = batch := by simp [u, parametricOptimizerTapeNext]
      rw [hbatch]
      unfold parametricOptimizerStageGood at hlocal
      have h := of_decide_eq_true hlocal e
      exact le_of_not_gt (fun hlt => h ⟨hkK, hlt⟩)
  have h := CandidateLaw.execute_invariant (parametricOptimizerTapeStep cfg hm ends tau w f Q bits)
    inv hstep K 0 (OptimizerTape.empty m N) hi t ht
  intro j hj e
  exact h hg j (by simpa only [Nat.zero_add] using hj) hj e


def parametricOptimizerStageMass (hm : 0 < m) (bits : ℕ) (t : Fin m ⊕ Fin m → ℝ)
    (sample : DerivativeSamples m N) : ℝ := by
  letI : MeasurableSpace (Finset (Fin m) × Finset (Fin m)) := ⊤
  exact (stageMeasure hm cfg.p NumericalCertificate.degree bits cfg.probabilityBounds t).real {sample}

theorem parametricOptimizerStageMass_total (hm : 0 < m) (bits : ℕ) (t : Fin m ⊕ Fin m → ℝ) :
    (∑ x : DerivativeSamples m N, parametricOptimizerStageMass cfg hm bits t x) = 1 := by
  letI : MeasurableSpace (Finset (Fin m) × Finset (Fin m)) := ⊤
  letI : MeasurableSingletonClass (Finset (Fin m) × Finset (Fin m)) := ⟨fun _ => trivial⟩
  let μ := stageMeasure (N := N) hm cfg.p NumericalCertificate.degree bits cfg.probabilityBounds t
  exact (CandidateLaw.ofMeasure μ).probability.total

theorem parametricOptimizerTapeStep_expected (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q bits j : ℕ)
    (t : OptimizerTape m N) (test : OptimizerTape m N → ℝ) :
    let q := parametricOptimizerTapeStep cfg hm ends tau w f Q bits j t
    expected q.outcomes q.mass test = ∑ sample, parametricOptimizerStageMass cfg hm bits
      (parametricOptimizerPoint cfg ends tau w f Q t j) sample * test (parametricOptimizerTapeNext cfg hm ends tau w f Q j t sample) := by
  dsimp only
  unfold parametricOptimizerTapeStep
  rw [CandidateLaw.map_expected]
  rfl

theorem parametricOptimizerTape_failure_unroll (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q bits k j : ℕ)
    (t : OptimizerTape m N) :
    let law := CandidateLaw.execute (parametricOptimizerTapeStep cfg hm ends tau w f Q bits) k j t
    expected law.outcomes law.mass optimizerTapeFailureIndicator =
      if t.good then adaptiveFailure (Outcome := DerivativeSamples m N) (fun _ => parametricOptimizerStageMass cfg hm bits)
        (advanceSampledPoint cfg.p NumericalCertificate.degree tau cfg.error Q ends f w)
        (parametricOptimizerStageGood cfg hm tau f) k j (parametricOptimizerPoint cfg ends tau w f Q t j) else 1 := by
  dsimp only
  induction k generalizing j t with
  | zero =>
    change expected (CandidateLaw.pure t).outcomes (CandidateLaw.pure t).mass _ = _
    simp [optimizerTapeFailureIndicator, adaptiveFailure]
  | succ k ih =>
    rw [CandidateLaw.execute_expected, parametricOptimizerTapeStep_expected cfg]
    simp_rw [ih, parametricOptimizerTapeNext_point cfg]
    by_cases h : t.good = true
    · simp only [h, if_true, adaptiveFailure, parametricOptimizerTapeNext, Bool.true_and]
    · have hfalse : t.good = false := Bool.eq_false_of_not_eq_true h
      simp [parametricOptimizerTapeNext, hfalse, parametricOptimizerStageMass_total cfg]

theorem parametricOptimizerTape_failure_le (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q bits : ℕ)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (h0 : f ∅ = 0)
    (htau : 0 < tau) (hF : ∀ e, f {e} ≤ tau) (hN : 0 < N) (δ : ℝ) (hδ : 0 < δ)
    (hbits : (m : ℝ) * (1 / (2 : ℝ) ^ bits) ≤
      FiniteGreedy.accuracy NumericalCertificate.degree m cfg.error / 16)
    (hcount : 8 / (FiniteGreedy.accuracy NumericalCertificate.degree m cfg.error) ^ 2 *
      Real.log (2 / (δ / ((FiniteGreedy.stages NumericalCertificate.degree m cfg.error : ℝ) * m))) ≤ N) :
    let law := parametricOptimizerTapeLaw cfg (N := N) hm ends tau w f Q bits
    expected law.outcomes law.mass optimizerTapeFailureIndicator ≤ δ := by
  dsimp only
  unfold parametricOptimizerTapeLaw
  rw [parametricOptimizerTape_failure_unroll cfg]
  have h := sampled_execution_failure hm cfg.p NumericalCertificate.degree tau cfg.error δ
    Q bits ends f w hf hmono h0 cfg.probabilityBounds degree_bounds.1 (by linarith [degree_bounds.2])
    htau cfg.error_pos cfg.error_lt_one.le hδ hF hN hbits hcount
  simpa only [OptimizerTape.empty, if_true, parametricOptimizerPoint, sampledPoint, LinearPacking.iterate] using h


end

end SubmodularMatching.UpperBoundAssembly
