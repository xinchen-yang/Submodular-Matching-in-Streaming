import SubmodularMatching.CapacityNonmonotoneProgram
import SubmodularMatching.CapacitySignedTheoremResources
import SubmodularMatching.NonmonotoneBankSelectionCosts
import SubmodularMatching.ProjectedShearerGraphLimits
import SubmodularMatching.CapacityOriginalMatchingNumber

/-! Resources at the exact public capacity, rank, confidence and retained
rounding scales used by the nonmonotone program in Theorem 5.1. -/
namespace SubmodularMatching.Capacity
open AppendixM UpperBoundAssembly LinearPacking Streaming Streaming.OracleQuery NonmonotoneOptimizer
  NonmonotoneCandidate TwoLayerDiffuse GibbsSampler Finset
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

def paperOracleWork (n J : ℕ) : ℕ :=
  let H := 2^37*(2*n^2+1)
  let K := 2^35*(n+1)^4
  let w := Nat.clog 2 (n+1)+1
  (4*n^2+2)*(4*8^4*J*H^40+1)*H^8+2*oracleReads K*(2*(2*n^2+160*w+1))

theorem paper_retained_work (S : SimpleEdgeStream E V) (b : V→ℕ)
    (st : SparseSlots (Admissible S b) (effectiveCapacity b))
    (hg : LayoutGuard (admissibleStream S b) (effectiveCapacity b) st) (J : ℕ) :
    let n := Fintype.card V
    let v := n^2
    let R := retainedLayout (admissibleStream S b) (effectiveCapacity b) st hg
    let s := (st.machine.edges.map Prod.fst).length
    let K := GridRow.scaleFor (S:=R.graph) (paperSlotRank b)
    let H := 2^37*(2*v+1)
    let q := Nat.clog 2 n
    (∀ i, effectiveCapacity b i≤2^q) ∧
    ((∑ j : ActionKey s, actionBatch R.l J*keyCalls j)*ascentFuel (paperExponent R.l)+
      2*oracleReads K*(2*layerSampleCap s K) ≤ paperOracleWork n J) ∧
    (ascentFuel (paperExponent R.l)*projectionFuel (paperExponent R.l)*
      packingIterationsNat R.m R.l ((scale (paperExponent R.l))^5) ≤ 1024*(5*v)^2*(2*v)^6*H^43) ∧
    2*R.m+12*R.l≤34*s := by
  intro n v R s K H q
  have sizes := retainedLayout_dimensions (admissibleStream S b) (effectiveCapacity b) st hg
  have hl : R.l=2*s := sizes.1
  have hsEq : Fintype.card (↑(st.machine.edges.map Prod.fst).toFinset)=s := by
    simp only [Fintype.card_coe,List.toFinset_card_of_nodup R.nodup,s]
  have hs : s≤v := hsEq ▸ physical_ground_size R.graph
  have prep := retained_packing_resources R.graph.ends _ (slotPair R.graph.ends _ R.left R.right) R.rows R.cols J
  rw [hsEq] at prep
  have geo := GridRow.physical_graph_precision R.graph (effectiveCapacity b) (paperSlotRank b) n le_rfl (effectiveCapacity_le b)
  let Kmax := 2^35*(n+1)^4
  let w := Nat.clog 2 (n+1)+1
  have hK : K≤Kmax := geo.2.1
  have hL : layerSampleCap s K ≤ 2*v+160*w+1 := by
    rw [physicalLayerExponent_cap]
    have hexp : physicalLayerExponent K≤160*w := geo.2.2.2.1
    omega
  have hop := action_oracle_calls s R.l J
  have hP : 2^37*(R.l+1) ≤ H := by dsimp only [H]; rw [hl]; gcongr
  refine ⟨fun i => (effectiveCapacity_le b i).trans (Nat.le_pow_clog (by decide) n),?_,?_,prep.1⟩
  · change _ ≤ _+_
    apply Nat.add_le_add
    · rw [hop.1]
      exact hop.2.trans (by gcongr)
    · change 2*oracleReads K*(2*layerSampleCap s K) ≤ 2*oracleReads Kmax*(2*(2*v+160*w+1))
      exact Nat.mul_le_mul (Nat.mul_le_mul_left 2 (Nat.mul_le_mul_left 512 (Nat.pow_le_pow_left hK 9)))
        (Nat.mul_le_mul_left 2 hL)
  · apply prep.2.1.trans
    dsimp only [H]
    gcongr

theorem paper_bank_oracle_work (S : SimpleEdgeStream E V) (b : V→ℕ) (f : Finset E→ℝ)
    (c : ℝ) (amp : Bool) (edges : ℕ→Admissible S b)
    (draw : ℕ→ℕ→ℕ→ℕ→ℕ) (k : ℕ) (hk : k≤(Fintype.card V)^2)
    (inc : Option (Admissible S b)×ℝ) :
    let n := Fintype.card V
    let v := n^2
    let δ := confidenceTarget n c
    let J := sourceFailureBudget δ
    let K := sourceWordScale v (v^2)
    let g := fun x => f (originalLabels S b x)
    let hpos := fun e : Admissible S b => And.intro
      (effectiveCapacity_pos b ((admissibleStream S b).ends e).1)
      (effectiveCapacity_pos b ((admissibleStream S b).ends e).2)
    let bank := RealOracle.countedBank (admissibleStream S b).ends (effectiveCapacity b) hpos v
      (batchCount K J) (batchBits K) g edges draw k
    let outer := countedAfterSignedPass g δ amp (paperRounding S b f) (bank.1,inc)
    let R := max 1 (⌈1/trialSuccess⌉₊*(Nat.clog 2 (max 1 n)*⌈c⌉₊+1))
    let G := signedGuessCountConstant*(v+2)
    let Jmax := 2000000000+2*(max 1 n)^⌈c⌉₊
    let src := 1+v*(1+2*(4*(2^42*(v^2+2)*(v^2+1)+v^2)^3*Jmax+1)*G)
    ∀ z∈outer.outcomes, bank.2+z.2.trials*paperOracleWork n J+2*z.2.comparisons ≤
      src+(R*G)*paperOracleWork n Jmax+2*(R*(G+1)) := by
  intro n v δ J K g hpos bank outer R G Jmax src z hz
  have exactCost := countedAfterSignedPass_work g δ amp (paperRounding S b f) (bank.1,inc) z hz
  have P := RealOracle.forward_queries_polynomial (admissibleStream S b).ends _ hpos n J k hk g edges draw
  have hJ : J≤Jmax := sourceFailureBudget_polynomial n c
  have hc : bank.2≤src := P.2.trans (by dsimp only [src,G]; gcongr)
  have hg : bank.1.states.length ≤ G := by
    change (RealOracle.countedBank _ _ _ _ _ _ _ _ _ _).1.states.length ≤ _
    rw [P.1]
    exact (RealOracle.GuessBank.state_count _ _ _ _ _ _).trans ((signedGuessCount_le v).trans
      (Nat.mul_le_mul_left _ (Nat.succ_le_succ (Nat.log2_le_self _))))
  have hR : (if amp then postprocessCount δ else 1)≤R := by
    split <;> first | exact (postprocessCount_logarithmic n c).trans (le_max_right ..) | exact le_max_left .. 
  have hT := exactCost.1.trans (Nat.mul_le_mul hR hg)
  have hC := exactCost.2.trans (Nat.mul_le_mul hR (Nat.succ_le_succ hg))
  have hwork : paperOracleWork n J ≤ paperOracleWork n Jmax := by dsimp [paperOracleWork]; gcongr
  exact Nat.add_le_add (Nat.add_le_add hc (Nat.mul_le_mul hT hwork)) (Nat.mul_le_mul_left _ hC)

end
end SubmodularMatching.Capacity
