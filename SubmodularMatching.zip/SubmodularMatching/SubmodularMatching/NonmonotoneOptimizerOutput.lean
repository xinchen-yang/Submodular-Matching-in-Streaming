import SubmodularMatching.NonmonotoneOptimizerRun
import SubmodularMatching.NonmonotoneOptimizerSchedule
import SubmodularMatching.NonmonotoneChainQueries

/-! The action returned by the concrete finite optimizer satisfies (28) on
any transcript with the stated errors in the gradient and value queries. -/

namespace SubmodularMatching.NonmonotoneOptimizer

open GibbsMatching

variable {M N : ℕ} {E : Type*} [DecidableEq E]

def scheduledRun (K : PackingGrid M N) (k : ℕ)
    (grad : ℕ → Vec N → Vec N) (score : ℕ → Vec N → ℚ) (t : ℕ) : Registers N :=
  run K (schedule k) (projectionFuel k) (stepSize k) grad score t

theorem run_bounds (K : PackingGrid M N) (k : ℕ) (hk : 2 ≤ scale k) (hN : N ≤ scale k)
    (grad : ℕ → Vec N → Vec N) (score : ℕ → Vec N → ℚ)
    (hgrad : ∀ t r, feasible K.entry K.den (coordinates r) → ∀ i, |coordinates (grad t r) i| ≤ scale k)
    (t : ℕ) :
    let R := scheduledRun K k grad score
    let g := coordinates (grad t (R t).state)
    feasible K.entry K.den (coordinates (R t).state) ∧ dot g g ≤ (scale k:ℝ)^3 ∧
    ∀ o, feasible K.entry K.den o →
      dot (fun i => coordinates (R t).state i+(stepSize k:ℝ)*g i-coordinates (R (t+1)).state i)
        (fun i => o i-coordinates (R (t+1)).state i) ≤ (schedule k).residual := by
  let P : ℝ := scale k
  have hP : 1 ≤ P := by change (1:ℝ) ≤ (scale k:ℝ); exact_mod_cast (show 1 ≤ scale k by omega)
  have h0 : 0 < P := by linarith
  have hη : (stepSize k:ℝ) = 1/P^4 := by simp [stepSize,P]
  have hη0 : 0 < (stepSize k:ℝ) := by rw [hη]; positivity
  have hηP : (stepSize k:ℝ)*P ≤ 1 := by
    rw [hη,one_div_mul_eq_div]
    exact (div_le_one (by positivity)).mpr (by simpa only [pow_one] using pow_le_pow_right₀ hP (show 1 ≤ 4 by decide))
  have hy (t : ℕ) (r : Vec N) (hr : feasible K.entry K.den (coordinates r)) (i : Fin N) :
      |coordinates (nextTarget r (grad t r) (stepSize k)) i| ≤ ((schedule k).bound:ℝ) := by
    have h := abs_le.mp (hgrad t r hr i)
    have h₁ := mul_le_mul_of_nonneg_left h.1 hη0.le
    have h₂ := mul_le_mul_of_nonneg_left h.2 hη0.le
    have he : coordinates (nextTarget r (grad t r) (stepSize k)) i =
        coordinates r i+(stepSize k:ℝ)*coordinates (grad t r) i := by simp [coordinates,atRat,nextTarget]
    rw [he]
    change |coordinates r i + _| ≤ 2
    change (stepSize k:ℝ)*(-P) ≤ _ at h₁
    change _ ≤ (stepSize k:ℝ)*P at h₂
    exact abs_le.mpr ⟨by linarith [(hr.1 i).1],by linarith [(hr.1 i).2]⟩
  obtain ⟨hr,hproj⟩ := run_projection K _ (schedule_valid k) (projectionFuel k) (stepSize k)
    grad score hy (projectionFuel_suffices k N hk hN) t
  refine ⟨hr, ?_, hproj⟩
  let x := (scheduledRun K k grad score t).state
  let g := coordinates (grad t x)
  have hsq (i : Fin N) : g i * g i ≤ P^2 := by
    have hb : |g i| ≤ P := hgrad t x hr i
    obtain ⟨hl,hr'⟩ := abs_le.mp hb
    nlinarith only [mul_nonneg (sub_nonneg.mpr hr') (show 0 ≤ P+g i by linarith)]
  have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hsq i)
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at h
  change ∑ i, g i*g i ≤ P^3
  have hn : (N:ℝ) ≤ P := by change (N:ℝ) ≤ (scale k:ℝ); exact_mod_cast hN
  nlinarith only [h,mul_le_mul_of_nonneg_right hn (sq_nonneg P)]

/-- A single realized, finite, rational packing-oracle execution. The encoding
identity specifies the exact linear payoff on the normalized packing columns.
Pointwise gradient errors and estimated-score errors refer to the supplied
sample transcript. No optimal projection, regret, or action-selection premise
is required. -/
theorem finite_optimizer_output (K : PackingGrid M N) (k : ℕ) (hk : 2 ≤ scale k) (hN : N ≤ scale k)
    (grad : ℕ → Vec N → Vec N) (score : ℕ → Vec N → ℚ)
    (hgrad : ∀ t r, feasible K.entry K.den (coordinates r) → ∀ i, |coordinates (grad t r) i| ≤ scale k)
    (edges : ℕ → ℕ → E) (n : ℕ) (O : Finset E) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hpos : ∀ B, 0 ≤ f B) (u : ℕ → ℕ → ℝ) (L : ℕ → ℝ)
    (W α β γ c gradErr scoreErr : ℝ) (hc : 0 < c) (hβ : 0 ≤ β)
    (hγ : β*(1+c+1/(4*c))=γ) (hα : γ-β*c=α)
    (o : Fin N → ℝ) (ho : feasible K.entry K.den o) (trueGrad : ℕ → Fin N → ℝ)
    (hcover : ∀ t < ascentFuel k, O ⊆ replacementPrefix (edges t) n)
    (hinj : ∀ t < ascentFuel k, ∀ i < n, ∀ j < n, edges t i = edges t j → i = j)
    (hu : ∀ t < ascentFuel k, ∀ i < n, 0 ≤ u t i ∧ u t i ≤ 1)
    (hsort : ∀ t < ascentFuel k, ∀ i < n, ∀ j < n, i ≤ j → weight c (u t i) ≤ weight c (u t j))
    (henc : ∀ t < ascentFuel k, W-L t + β*(∑ i ∈ Finset.range n,
      queriedPayoff (edges t) n f c (u t) i*((if edges t i ∈ O then 1 else 0)-u t i)) ≤
      dot (trueGrad t) (fun i => o i-coordinates (scheduledRun K k grad score t).state i))
    (hgradErr : ∀ t < ascentFuel k, ∀ i,
      |trueGrad t i-coordinates (grad t (scheduledRun K k grad score t).state) i| ≤ gradErr)
    (hval : ∀ t < ascentFuel k, |(score t (scheduledRun K k grad score t).state:ℝ)-
      (L t + γ*(bernoulliExpectation (edges t) (fun i => action c (u t i)) f n-f ∅))| ≤ scoreErr) :
    let best := scheduledRun K k grad score (ascentFuel k)
    best.bestState = (scheduledRun K k grad score best.bestTime).state ∧
    W + β*(f O-f ∅) - (α-β)*f ∅ - (5/(scale k:ℝ) + N*gradErr) - 2*scoreErr ≤
      L best.bestTime + γ*(bernoulliExpectation (edges best.bestTime)
        (fun i => action c (u best.bestTime i)) f n-f ∅) := by
  let R := scheduledRun K k grad score
  let x := fun t => coordinates (R t).state
  let g := fun t => coordinates (grad t (R t).state)
  let T := ascentFuel k
  have hT : 0 < T := by dsimp [T,ascentFuel,scale]; positivity
  have hrun := run_bounds K k hk hN grad score hgrad
  have hη : 0 < (stepSize k:ℝ) := by simp [stepSize,scale]
  have hstep := ascentFuel_suffices k N hk hN
  have hinit : distSq (x 0) o ≤ N := feasible_diam K _ _ (hrun 0).1 ho
  have H := projected_action edges n T hT O f hf hpos u L W α β γ c hc hβ hγ hα
    hcover hinj hu hsort x g o (stepSize k) (schedule k).residual ((scale k:ℝ)^3)
    (N*gradErr) (5/(scale k:ℝ)) hη (fun t _ => (hrun t).2.1) (fun t _ => (hrun t).2.2 o ho)
    (fun t ht => ?_) (by linarith only [hstep,hinit])
  · let value := fun t => L t + γ*(bernoulliExpectation (edges t) (fun i => action c (u t i)) f n-f ∅)
    obtain ⟨t,ht,hgood⟩ := H
    have hb := run_best K (schedule k) (projectionFuel k) (stepSize k) grad score T
    have htime : (R T).bestTime < T := by simpa [max_eq_right (show 1 ≤ T by omega)] using hb.2.2.2
    refine ⟨hb.2.1,?_⟩
    have hle := hb.1 t ht
    have heq : (R T).bestScore = score (R T).bestTime (R (R T).bestTime).state :=
      hb.2.2.1.trans (congrArg _ hb.2.1)
    rw [show (run K (schedule k) (projectionFuel k) (stepSize k) grad score T).bestScore = _ from heq] at hle
    have hle' : (score t (R t).state:ℝ) ≤ (score (R T).bestTime (R (R T).bestTime).state:ℝ) := by exact_mod_cast hle
    have h1 := (abs_le.mp (hval t ht)).1
    have h2 := (abs_le.mp (hval _ htime)).2
    change _ ≤ value (R T).bestTime
    change _ ≤ value t at hgood
    change _ ≤ (score t (R t).state:ℝ)-value t at h1
    change (score (R T).bestTime (R (R T).bestTime).state:ℝ)-value (R T).bestTime ≤ _ at h2
    linarith only [h1,h2,hle',hgood]
  · have he := direction_error (trueGrad t) (g t) o (x t) gradErr (hgradErr t ht) ho.1 (hrun t).1.1
    have he' := (abs_le.mp he).2
    simp only [Fintype.card_fin] at he'
    change dot (trueGrad t) _ - dot (g t) _ ≤ (N:ℝ)*gradErr at he'
    linarith only [henc t ht,he']

end SubmodularMatching.NonmonotoneOptimizer
