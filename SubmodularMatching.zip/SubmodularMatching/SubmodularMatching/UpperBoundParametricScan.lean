import SubmodularMatching.UpperBoundK1Envelope
import SubmodularMatching.UpperBoundApproximationFamily
import SubmodularMatching.UpperBoundOutcomeLaw
import SubmodularMatching.UpperBoundProgramQuality

/-! # Finite trial and expectation assembly for any fixed accuracy -/

namespace SubmodularMatching.UpperBoundAssembly

open NumericalCertificate GibbsSampler
open scoped BigOperators

noncomputable section

variable {A T : Type*}

/-- The finite K.4 inequality uses only the charge, the candidate bound
and the fact that the best singleton is an exact grid value. -/
theorem parametricScan_error_budget (value : A → ℝ) (qs : List (CandidateLaw A))
    (initial : A) (q : CandidateLaw A) (hq : q ∈ qs)
    (e θ σ b opt X g τ B : ℝ) (he : 0 < e) (ht0 : 0 ≤ θ) (ht1 : θ ≤ 1)
    (hσ : 0 ≤ σ) (hb : 0 ≤ b) (hb1 : b ≤ 1 / 4)
    (k : ℤ) (hgrid : 2 / e = (k : ℝ)) (hinit : value initial = B)
    (hB : 0 < B) (hτ : τ ≤ 2 * B) (hX : 0 ≤ X) (hg : 0 ≤ g)
    (hcharge : opt ≤ X + g + 6 * e * τ)
    (hround : θ * (σ * X + b * g - (5 / 8) * e * τ) - e * B / 4 ≤
      expected q.outcomes q.mass value) :
    let y := scanExpectation value (e * B / 2) value qs initial
    B ≤ y ∧ θ * min σ b * opt ≤ y + 5 * e * B := by
  intro y
  let step := e * B / 2
  have hs : 0 < step := by dsimp [step]; positivity
  have hbest : value initial = step * (k : ℝ) := by
    rw [hinit, ← hgrid]
    dsimp only [step]
    field_simp
  have hBval : B ≤ y := hinit.symm.le.trans
    (scanExpectation_keeps_reference value step hs qs initial k hbest)
  refine ⟨hBval, ?_⟩
  apply conditional_error_budget opt X g (σ * X + b * g - e * τ / 2)
    (θ * (σ * X + b * g - (5 / 8) * e * τ)) (expected q.outcomes q.mass value)
    y B τ e σ b θ hB.le hτ he.le hX hg hσ hb hb1 ht0 ht1 hcharge le_rfl _ hround
    (scanExpectation_keeps_candidate value step hs qs initial q hq)
  apply le_of_eq
  ring

/-- Absorbing the additive loss with the retained singleton gives the
conditional family factor for one successful-preparation transcript. -/
theorem parametricConditional_trialValue (e opt B Y : ℝ) (he : 0 ≤ e) (he1 : e < 1)
    (hbest : B ≤ Y) (hvalue : (1 - e) * sigma * opt ≤ Y + 5 * e * B) :
    opt / familyTrialFactor e ≤ Y := by
  have h := FiniteError.absorb_additive Y B (5 * e) ((1 - e) * sigma * opt) (by positivity) hbest hvalue
  have hd : 0 < 1 + 5 * e := by positivity
  have hσ := sigma_pos
  have h1 : 0 < 1 - e := sub_pos.mpr he1
  unfold familyTrialFactor
  rw [div_div_eq_mul_div]
  exact (div_le_iff₀ hd).mpr (by nlinarith only [h])

/-- The actual output law from one completed scan satisfies the family
expected factor with the family comparison mesh. -/
theorem parametricProgram_expected (prep : CandidateLaw T) (good : T → Prop) [DecidablePred good]
    (states : Finset A) (value : A → ℝ) (qs : T → List (CandidateLaw A)) (initial : A)
    (e opt B : ℝ) (he : 0 ≤ e) (he1 : e < 1) (hopt : 0 ≤ opt)
    (hi : initial ∈ states) (hs : ∀ t, ∀ q ∈ qs t, q.outcomes ⊆ states)
    (hrange : ∀ a ∈ states, 0 ≤ value a ∧ value a ≤ opt)
    (hbad : (∑ t ∈ prep.outcomes, if good t then 0 else prep.mass t) ≤ e)
    (hgood : ∀ t ∈ prep.outcomes, good t →
      let Y := scanExpectation value (e * B / 2) value (qs t) initial
      B ≤ Y ∧ (1 - e) * sigma * opt ≤ Y + 5 * e * B) :
    let law := expectedOutputLaw prep states value (e * B / 2) qs initial hi hs
    opt / familyExpectedFactor e ≤ expected law.outcomes law.mass value := by
  dsimp only
  have h := expectedOutputLaw_FJ2 prep good states value qs initial e (1 - e) sigma opt B
    he (sub_nonneg.mpr he1.le) sigma_pos.le hopt hi hs hrange hbad hgood
  change (1 - e) * (1 - e) * sigma / (1 + 5 * e) * opt ≤ _ at h
  calc
    _ = (1 - e) * (1 - e) * sigma / (1 + 5 * e) * opt := by
      unfold familyExpectedFactor
      rw [div_div_eq_mul_div]
      ring
    _ ≤ _ := h

end

end SubmodularMatching.UpperBoundAssembly
