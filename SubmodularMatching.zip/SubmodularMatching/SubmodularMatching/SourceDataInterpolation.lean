import SubmodularMatching.CertificateSoundness
import SubmodularMatching.CertificateInterpolation

/-!
# Continuous interpolants induced by rational knot tables

A clipped ramp represents the increase on one interval. The sum of the ramps
agrees with linear interpolation and is constant outside the knot domain.
-/

namespace SubmodularMatching.SourceCertificate

open MeasureTheory Set Filter
open scoped BigOperators Topology

noncomputable section

/-- Consecutive knots increase strictly throughout the used entries. -/
def OrderedKnots (n : ℕ) (knot : ℕ → ℝ) : Prop :=
  ∀ i < n, knot i < knot (i + 1)

theorem OrderedKnots.lt {n : ℕ} {knot : ℕ → ℝ} (h : OrderedKnots n knot)
    {i j : ℕ} (hij : i < j) (hj : j ≤ n) : knot i < knot j := by
  induction j with
  | zero => omega
  | succ j ih =>
    have hstep := h j (by omega)
    by_cases hi : i = j
    · simpa [hi] using hstep
    · exact (ih (by omega) (by omega)).trans hstep

theorem OrderedKnots.le {n : ℕ} {knot : ℕ → ℝ} (h : OrderedKnots n knot)
    {i j : ℕ} (hij : i ≤ j) (hj : j ≤ n) : knot i ≤ knot j := by
  obtain heq | hlt := hij.eq_or_lt
  · simp [heq]
  · exact (h.lt hlt hj).le

/-- The interpolation coefficient for a single interval, clipped to `[0,1]`. -/
def ramp (a b x : ℝ) : ℝ := min 1 (max 0 ((x - a) / (b - a)))

theorem ramp_zero (a b x : ℝ) (hab : a < b) (hx : x ≤ a) :
    ramp a b x = 0 := by
  rw [ramp, max_eq_left (div_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr hx)
    (sub_pos.mpr hab).le), min_eq_right zero_le_one]

theorem ramp_one (a b x : ℝ) (hab : a < b) (hx : b ≤ x) :
    ramp a b x = 1 := by
  apply min_eq_left
  apply le_max_of_le_right
  apply (le_div_iff₀ (sub_pos.mpr hab)).2
  linarith only [hx]

theorem ramp_linear (a b x : ℝ) (hab : a < b) (hx : a ≤ x) (hx' : x ≤ b) :
    ramp a b x = (x - a) / (b - a) := by
  rw [ramp, max_eq_right (div_nonneg (sub_nonneg.mpr hx) (sub_pos.mpr hab).le)]
  exact min_eq_right ((div_le_one (sub_pos.mpr hab)).2 (by linarith only [hx']))

/-- Interpolation through entries zero to `n`, extended constantly at
both ends. -/
def realInterpolate (n : ℕ) (knot height : ℕ → ℝ) (x : ℝ) : ℝ :=
  height 0 + ∑ j ∈ Finset.range n, (height (j + 1) - height j) * ramp (knot j) (knot (j + 1)) x

theorem realInterpolate_continuous (n : ℕ) (knot height : ℕ → ℝ) :
    Continuous (realInterpolate n knot height) := by
  apply continuous_const.add
  · exact continuous_finset_sum _ (fun j _ =>
      continuous_const.mul (continuous_const.min (continuous_const.max
        ((continuous_id.sub continuous_const).div_const _))))

theorem realInterpolate_monotone (n : ℕ) (knot height : ℕ → ℝ)
    (hk : OrderedKnots n knot) (hh : ∀ i < n, height i ≤ height (i + 1)) :
    Monotone (realInterpolate n knot height) := by
  intro x y hxy
  apply add_le_add le_rfl
  apply Finset.sum_le_sum
  intro j hj
  have h := Finset.mem_range.mp hj
  apply mul_le_mul_of_nonneg_left _ (sub_nonneg.mpr (hh j h))
  unfold ramp
  exact min_le_min le_rfl (max_le_max le_rfl
    (div_le_div_of_nonneg_right (sub_le_sub_right hxy _) (sub_pos.mpr (hk j h)).le))

theorem realInterpolate_below (n : ℕ) (knot height : ℕ → ℝ)
    (hk : OrderedKnots n knot) {x : ℝ} (hx : x ≤ knot 0) :
    realInterpolate n knot height x = height 0 := by
  unfold realInterpolate
  have hz : (∑ j ∈ Finset.range n, (height (j + 1) - height j) *
      ramp (knot j) (knot (j + 1)) x) = 0 := by
    apply Finset.sum_eq_zero
    intro i hi
    have h := Finset.mem_range.mp hi
    rw [ramp_zero _ _ x (hk i h) (hx.trans (hk.le (Nat.zero_le i) h.le)), mul_zero]
  rw [hz, add_zero]

theorem realInterpolate_above (n : ℕ) (knot height : ℕ → ℝ)
    (hk : OrderedKnots n knot) {x : ℝ} (hx : knot n ≤ x) :
    realInterpolate n knot height x = height n := by
  unfold realInterpolate
  have hsum : (∑ j ∈ Finset.range n, (height (j + 1) - height j) *
      ramp (knot j) (knot (j + 1)) x) = ∑ j ∈ Finset.range n, (height (j + 1) - height j) := by
    apply Finset.sum_congr rfl
    intro i hi
    have h := Finset.mem_range.mp hi
    rw [ramp_one _ _ _ (hk i h) ((hk.le (Nat.succ_le_of_lt h) le_rfl).trans hx), mul_one]
  rw [hsum, Finset.sum_range_sub]
  ring

theorem realInterpolate_cell (n : ℕ) (knot height : ℕ → ℝ)
    (hk : OrderedKnots n knot) (i : ℕ) (hi : i < n) (x : ℝ)
    (hx : knot i ≤ x) (hx' : x ≤ knot (i + 1)) :
    realInterpolate n knot height x =
      height i + (height (i + 1) - height i) * (x - knot i) / (knot (i + 1) - knot i) := by
  unfold realInterpolate
  let term (j : ℕ) := (height (j + 1) - height j) * ramp (knot j) (knot (j + 1)) x
  change height 0 + ∑ j ∈ Finset.range n, term j = _
  have hz : (∑ j ∈ Finset.range (i + 1), term j) = ∑ j ∈ Finset.range n, term j := by
    apply Finset.sum_subset (Finset.range_mono (Nat.succ_le_of_lt hi))
    intro j hj hj'
    have hjn := Finset.mem_range.mp hj
    have hjge : i + 1 ≤ j := by simpa only [Finset.mem_range, not_lt] using hj'
    dsimp only [term]
    rw [ramp_zero _ _ _ (hk j hjn) (hx'.trans (hk.le hjge hjn.le)), mul_zero]
  have hbefore : (∑ j ∈ Finset.range i, term j) = height i - height 0 := by
    rw [← Finset.sum_range_sub height]
    apply Finset.sum_congr rfl
    intro j hj
    have hjn := Finset.mem_range.mp hj
    dsimp only [term]
    rw [ramp_one _ _ _ (hk j (hjn.trans hi)) ((hk.le (Nat.succ_le_of_lt hjn) hi.le).trans hx),
      mul_one]
  rw [← hz, Finset.sum_range_succ, hbefore]
  dsimp only [term]
  rw [ramp_linear _ _ _ (hk i hi) hx hx']
  ring

theorem realInterpolate_realizes (n : ℕ) (knot height : ℕ → ℚ)
    (hk : OrderedKnots n (fun i => (knot i : ℝ))) :
    RealizesKnotTable (realInterpolate n (fun i => knot i) (fun i => height i)) n knot height := by
  exact ⟨fun _ hx => realInterpolate_below _ _ _ hk hx,
    fun _ hx => realInterpolate_above _ _ _ hk hx,
    fun i hi x hx hx' => realInterpolate_cell _ _ _ hk i hi x hx hx'⟩

end

end SubmodularMatching.SourceCertificate
