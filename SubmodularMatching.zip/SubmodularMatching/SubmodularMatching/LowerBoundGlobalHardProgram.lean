import SubmodularMatching.LowerBoundGlobalFinishFinite

/-! # A legal randomized streaming program on the hard-instance family -/

namespace SubmodularMatching.LowerBoundGlobal

open LowerBoundAssembly LowerBoundSoundness
open scoped BigOperators

noncomputable section

variable {p N P t H : ℕ} {C State Coin : Type*}
  [Fintype C] [DecidableEq C] [AddCommGroup C] [Nonempty (Fin t)] [Fintype Coin]

/-- The random tape is drawn independently of the input. Fixing it defines
the legal deterministic execution used by both information estimates. The
number of states counts the entire mutable state at every cutoff. -/
structure HardProgram (b : BlueprintExpansion N P t H) (qBase qClone : ℝ)
    (p : ℕ) (C State Coin : Type*) [Fintype C] [DecidableEq C] [AddCommGroup C] [Fintype Coin] where
  machine : Coin → Machine (HardEdge p N C) State
  coinLaw : Coin → ℝ
  coin_nonneg : ∀ coin, 0 ≤ coinLaw coin
  coin_total : ∑ coin, coinLaw coin = 1
  legal : ∀ draw : HardDraw p N P t C, ∀ coin, 0 < hardDrawMass b qBase qClone draw →
    0 < coinLaw coin →
      let mass := 1 / (hardNormalizer C N H : ℝ)
      (machine coin).legal (hardOracle mass draw) (hardStream b draw) ∧
        HardMatching (hardOutput b machine mass (draw, coin))

namespace HardProgram

variable {b : BlueprintExpansion N P t H} {qBase qClone : ℝ}

def outputValue (alg : HardProgram b qBase qClone p C State Coin)
    (d : HardDraw p N P t C) (coin : Coin) : ℝ :=
  hardOracle (1 / (hardNormalizer C N H : ℝ)) d
    (hardOutput b alg.machine (1 / (hardNormalizer C N H : ℝ)) (d, coin))

def witnessValue (d : HardDraw p N P t C) : ℝ :=
  hardOracle (1 / (hardNormalizer C N H : ℝ)) d (hardWitness b d)

def experiment (alg : HardProgram b qBase qClone p C State Coin)
    (hN : 0 < N) (hqb0 : 0 ≤ qBase) (hqb1 : qBase ≤ 1)
    (hql0 : 0 ≤ qClone) (hql1 : qClone ≤ 1)
    (cap ξ : ℝ) (hcap0 : 0 ≤ cap) (hcap1 : cap ≤ 1) (hcap : leafFraction ((H : ℝ) / N) ≤ cap) :
    FiniteExperiment (HardDraw p N P t C × Coin) (cap * (p + 1 : ℝ) / (1 + cap))
      ((p : ℝ) * (1 - ξ)) :=
  hardExperiment b hN qBase qClone hqb0 hqb1 hql0 hql1 alg.machine alg.coinLaw
    alg.coin_nonneg alg.coin_total cap ξ hcap0 hcap1 hcap alg.legal

theorem experiment_failure_eq (alg : HardProgram b qBase qClone p C State Coin)
    (hN : 0 < N) (hqb0 : 0 ≤ qBase) (hqb1 : qBase ≤ 1)
    (hql0 : 0 ≤ qClone) (hql1 : qClone ≤ 1)
    (cap ξ : ℝ) (hcap0 : 0 ≤ cap) (hcap1 : cap ≤ 1) (hcap : leafFraction ((H : ℝ) / N) ≤ cap) :
    (alg.experiment hN hqb0 hqb1 hql0 hql1 cap ξ hcap0 hcap1 hcap).failure =
      eventMass (hardDrawMass (p := p) (C := C) b qBase qClone) (fun d => ¬hardComplete b ξ d) :=
  eventMass_coin_constant (hardDrawMass (C := C) b qBase qClone) alg.coinLaw alg.coin_total
    (fun d => ¬hardComplete b ξ d)

variable [Fintype State] [Nonempty State]

theorem experiment_recovery_le (alg : HardProgram b qBase qClone p C State Coin)
    (hN : 0 < N) (hqb0 : 0 < qBase) (hqb1 : qBase < 1)
    (hql0 : 0 < qClone) (hql1 : qClone < 1)
    (cap ξ : ℝ) (hcap0 : 0 ≤ cap) (hcap1 : cap ≤ 1) (hcap : leafFraction ((H : ℝ) / N) ≤ cap)
    (s : ℕ) (hstates : Fintype.card State ≤ 2 ^ s) :
    let K := (Fintype.card C : ℝ)
    let M := (hardNormalizer C N H : ℝ)
    (alg.experiment hN hqb0.le hqb1.le hql0.le hql1.le cap ξ hcap0 hcap1 hcap).recoveryMean ≤
        (p : ℝ) * ((K * s * (P : ℝ) ^ 2 / ((t : ℝ) * Real.logb 2 (1 / qBase)) +
          s / (K * Real.logb 2 (1 / qClone))) / M) := by
  classical
  intro K M
  apply le_trans (le_of_eq ?_) (global_hard_recovery_mean_le b qBase qClone hqb0 hqb1 hql0 hql1
    alg.machine alg.coinLaw alg.coin_nonneg alg.coin_total alg.legal s hstates)
  unfold FiniteExperiment.recoveryMean
  apply Finset.sum_congr rfl
  intro input _
  let mass := hardJointMass (p := p) (C := C) b qBase qClone alg.coinLaw input
  let e := hardRecovery b input.1
    (hardOutput b alg.machine (1 / (hardNormalizer C N H : ℝ)) input)
  change mass * (if 0 < mass then e else 0) = mass * e
  by_cases hp : 0 < mass
  · simp only [if_pos hp]
  · rw [le_antisymm (not_lt.mp hp) (hardJointMass_nonneg b qBase qClone alg.coinLaw
      alg.coin_nonneg input), zero_mul, zero_mul]

omit [Fintype State] [Nonempty State] in
/-- Convert the finite experiment's success bound to a violating legal input. -/
theorem supported_probability_bad (alg : HardProgram b qBase qClone p C State Coin)
    (hN : 0 < N) (hqb0 : 0 ≤ qBase) (hqb1 : qBase ≤ 1)
    (hql0 : 0 ≤ qClone) (hql1 : qClone ≤ 1)
    (cap ξ : ℝ) (hcap0 : 0 ≤ cap) (hcap1 : cap ≤ 1) (hcap : leafFraction ((H : ℝ) / N) ≤ cap)
    (R prob : ℝ)
    (hbad : (alg.experiment hN hqb0 hqb1 hql0 hql1 cap ξ hcap0 hcap1 hcap).success R < prob) :
    ∃ d : HardDraw p N P t C, 0 < hardDrawMass b qBase qClone d ∧
      eventMass alg.coinLaw (fun c => witnessValue (b := b) d ≤ R * alg.outputValue d c) < prob := by
  apply supported_success_failure (hardDrawMass b qBase qClone) alg.coinLaw
    (fun x => witnessValue (b := b) x.1 ≤ R * alg.outputValue x.1 x.2)
    (hardDrawMass_nonneg b qBase qClone) (hardDrawMass_total b qBase qClone hqb0 hqb1 hql0 hql1)
  convert hbad using 1
  unfold FiniteExperiment.success eventMass
  apply Finset.sum_congr rfl
  intro input _
  let mass := hardJointMass (p := p) (C := C) b qBase qClone alg.coinLaw input
  change (if witnessValue (b := b) input.1 ≤ R * alg.outputValue input.1 input.2 then mass else 0) =
    (if witnessValue (b := b) input.1 ≤ R * (if 0 < mass then alg.outputValue input.1 input.2 else 0)
      then mass else 0)
  by_cases hp : 0 < mass
  · simp only [if_pos hp]
  · rw [le_antisymm (not_lt.mp hp) (hardJointMass_nonneg b qBase qClone alg.coinLaw
      alg.coin_nonneg input)]
    split_ifs <;> rfl

omit [Fintype State] [Nonempty State] in
/-- Convert the averaged expected-value contradiction to a violating legal input. -/
theorem supported_expectation_bad (alg : HardProgram b qBase qClone p C State Coin)
    (hN : 0 < N) (hqb0 : 0 ≤ qBase) (hqb1 : qBase ≤ 1)
    (hql0 : 0 ≤ qClone) (hql1 : qClone ≤ 1)
    (cap ξ : ℝ) (hcap0 : 0 ≤ cap) (hcap1 : cap ≤ 1) (hcap : leafFraction ((H : ℝ) / N) ≤ cap)
    (R : ℝ)
    (hbad : let e := alg.experiment hN hqb0 hqb1 hql0 hql1 cap ξ hcap0 hcap1 hcap
      R * (∑ ω, e.law ω * e.output ω) < ∑ ω, e.law ω * e.witness ω) :
    ∃ d : HardDraw p N P t C, 0 < hardDrawMass b qBase qClone d ∧
      R * (∑ c, alg.coinLaw c * alg.outputValue d c) < witnessValue (b := b) d := by
  apply supported_expected_failure (hardDrawMass b qBase qClone) alg.coinLaw
    (fun x => alg.outputValue x.1 x.2) (witnessValue (b := b))
    (hardDrawMass_nonneg b qBase qClone) alg.coin_total R
  have heq :
      (∑ x : HardDraw p N P t C × Coin,
        hardJointMass b qBase qClone alg.coinLaw x * alg.outputValue x.1 x.2) =
      ∑ x, (alg.experiment hN hqb0 hqb1 hql0 hql1 cap ξ hcap0 hcap1 hcap).law x *
        (alg.experiment hN hqb0 hqb1 hql0 hql1 cap ξ hcap0 hcap1 hcap).output x := by
    apply Finset.sum_congr rfl
    intro input _
    let mass := hardJointMass (p := p) (C := C) b qBase qClone alg.coinLaw input
    change mass * alg.outputValue input.1 input.2 =
      mass * (if 0 < mass then alg.outputValue input.1 input.2 else 0)
    by_cases hp : 0 < mass
    · simp only [if_pos hp]
    · rw [le_antisymm (not_lt.mp hp) (hardJointMass_nonneg b qBase qClone alg.coinLaw
        alg.coin_nonneg input), zero_mul, zero_mul]
  change R * (∑ x : HardDraw p N P t C × Coin,
      hardJointMass b qBase qClone alg.coinLaw x * alg.outputValue x.1 x.2) <
    ∑ x : HardDraw p N P t C × Coin,
      hardJointMass b qBase qClone alg.coinLaw x * witnessValue (b := b) x.1
  rw [heq]
  exact hbad

end HardProgram

end

end SubmodularMatching.LowerBoundGlobal
