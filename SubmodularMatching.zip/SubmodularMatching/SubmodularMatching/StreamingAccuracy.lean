import SubmodularMatching.StreamingSampledCharge

/-!
# Accuracy of rounded marginal estimates

The history samples use downward-rounded dyadic Bernoulli probabilities. The
source estimator separately rounds each marginal value down by one quarter
of the estimate grid. These errors are accounted for before invoking SF1.
-/

namespace SubmodularMatching.Streaming

/-- The actual Bernoulli probability generated with a uniform `bits`-bit draw. -/
noncomputable def bitProbability (p : ℝ) (bits : ℕ) : ℝ :=
  (⌊2 ^ bits * p⌋ : ℤ) / (2 : ℝ) ^ bits

/-- The inclusion probability is rounded downward by less than one grid unit. -/
theorem bitProbability_bounds {p : ℝ} (hp : 0 ≤ p) (bits : ℕ) :
    0 ≤ bitProbability p bits ∧ bitProbability p bits ≤ p ∧
      p - bitProbability p bits < 1 / (2 : ℝ) ^ bits := by
  have hpow : (0 : ℝ) < 2 ^ bits := by positivity
  unfold bitProbability
  refine ⟨div_nonneg ?_ hpow.le, ?_, ?_⟩
  · exact_mod_cast Int.floor_nonneg.mpr (mul_nonneg hpow.le hp)
  · exact (div_le_iff₀ hpow).2 (by simpa [mul_comm] using Int.floor_le ((2 : ℝ) ^ bits * p))
  · rw [lt_div_iff₀ hpow, sub_mul, div_mul_cancel₀ _ hpow.ne']
    nlinarith [Int.lt_floor_add_one ((2 : ℝ) ^ bits * p)]

variable {E : Type*} [DecidableEq E]

/-- Perturbing each independent inclusion probability by at most `delta`
changes the expectation of a function in `[0, cap]` by at most `n * delta * cap`.
This bounds the bias directly on the same finite law used by `traceWeight`. -/
theorem bernoulliExpectation_probability_gap (edges : ℕ → E) (q r : ℕ → ℝ)
    (F : Finset E → ℝ) (n : ℕ) (cap delta : ℝ) (hcap : 0 ≤ cap)
    (hqr : ∀ i < n, 0 ≤ q i ∧ q i ≤ r i ∧ r i ≤ 1 ∧ r i - q i ≤ delta)
    (hF : ∀ A, 0 ≤ F A ∧ F A ≤ cap) :
    |bernoulliExpectation edges r F n - bernoulliExpectation edges q F n| ≤
      (n : ℝ) * delta * cap := by
  induction n generalizing F with
  | zero => simp
  | succ n ih =>
    have hn := hqr n (Nat.lt_succ_self _)
    have hqr' : ∀ i < n, 0 ≤ q i ∧ q i ≤ r i ∧ r i ≤ 1 ∧ r i - q i ≤ delta :=
      fun i hi => hqr i (Nat.lt_succ_of_lt hi)
    let H := fun A => F (A ∪ {edges n})
    have hr : ∀ i < n, 0 ≤ r i ∧ r i ≤ 1 := fun i hi =>
      ⟨(hqr' i hi).1.trans (hqr' i hi).2.1, (hqr' i hi).2.2.1⟩
    have bound (G : Finset E → ℝ) (hG : ∀ A, 0 ≤ G A ∧ G A ≤ cap) :
        0 ≤ bernoulliExpectation edges r G n ∧ bernoulliExpectation edges r G n ≤ cap := by
      refine ⟨bernoulliExpectation_nonnegative edges r G n hr (fun A => (hG A).1), ?_⟩
      simpa using bernoulliExpectation_mono edges r G (fun _ => cap) n hr (fun A => (hG A).2)
    have hG := bound F hF
    have hH := bound H (fun A => hF _)
    have hdiff : |bernoulliExpectation edges r H n - bernoulliExpectation edges r F n| ≤ cap := by
      apply abs_le.2
      constructor <;> linarith [hG.1, hG.2, hH.1, hH.2]
    have hmix1 := mul_le_mul_of_nonneg_left (ih F hqr' hF)
      (sub_nonneg.mpr (hn.2.1.trans hn.2.2.1))
    have hmix2 := mul_le_mul_of_nonneg_left (ih H hqr' (fun A => hF _)) hn.1
    have hmix3 := (mul_le_mul_of_nonneg_left hdiff (sub_nonneg.mpr hn.2.1)).trans
      (mul_le_mul_of_nonneg_right hn.2.2.2 hcap)
    rw [bernoulliExpectation_succ, bernoulliExpectation_succ]
    change |((1 - r n) * bernoulliExpectation edges r F n + r n * bernoulliExpectation edges r H n) -
      ((1 - q n) * bernoulliExpectation edges q F n + q n * bernoulliExpectation edges q H n)| ≤ _
    rw [show ((1 - r n) * bernoulliExpectation edges r F n + r n * bernoulliExpectation edges r H n) -
      ((1 - q n) * bernoulliExpectation edges q F n + q n * bernoulliExpectation edges q H n) =
        ((1 - q n) * (bernoulliExpectation edges r F n - bernoulliExpectation edges q F n) +
          q n * (bernoulliExpectation edges r H n - bernoulliExpectation edges q H n)) +
          (r n - q n) * (bernoulliExpectation edges r H n - bernoulliExpectation edges r F n) by ring]
    apply (abs_add_le _ _).trans
    apply (add_le_add (abs_add_le _ _) le_rfl).trans
    simp only [abs_mul, abs_of_nonneg (sub_nonneg.mpr (hn.2.1.trans hn.2.2.1)),
      abs_of_nonneg hn.1, abs_of_nonneg (sub_nonneg.mpr hn.2.1)]
    have hbound := add_le_add (add_le_add hmix1 hmix2) hmix3
    push_cast
    convert hbound using 1
    ring

/-- Sampling against the actual integer-grid history probabilities. -/
noncomputable def bitTraceProbability {V : Type*} [DecidableEq V]
    (C : PotentialConfig) (ends : E → V × V) (input : ℕ → E × ℝ)
    (bits i : ℕ) : ℝ := by
  classical
  exact if acceptedAt C ends input i then bitProbability C.p bits else 0

/-- The exact marginal mean of the dyadic sample on the actually stored prefix. -/
noncomputable def bitTraceWeight {V : Type*} [DecidableEq V]
    (C : PotentialConfig) (ends : E → V × V) (input : ℕ → E × ℝ)
    (f : Finset E → ℝ) (bits i : ℕ) : ℝ :=
  bernoulliExpectation (fun j => (input j).1) (bitTraceProbability C ends input bits)
    (fun A => marginal f (input i).1 A) i

/-- The marginal's bias is at most one sixty-fourth of the source grid for
the number of bits in SF6. The statement applies to any fixed prefix
of the actual sampled program. -/
theorem bitTraceWeight_error {V : Type*} [DecidableEq V]
    (C : PotentialConfig) (ends : E → V × V) (input : ℕ → E × ℝ)
    (f : Finset E → ℝ) (bits i vertices : ℕ) (epsilon : ℝ)
    (hp : C.p ≤ 1) (he : 0 < epsilon) (hv : 0 < vertices)
    (hi : i ≤ vertices ^ 2)
    (hgap : C.gap = epsilon * C.tau / (vertices : ℝ) ^ 2)
    (hb : 64 * (vertices : ℝ) ^ 4 / epsilon ≤ 2 ^ bits)
    (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0)
    (hcap : f {(input i).1} ≤ C.tau) :
    |traceWeight C ends input f i - bitTraceWeight C ends input f bits i| ≤ C.gap / 64 := by
  have htau : 0 ≤ C.tau := C.theta_pos.le.trans C.theta_le_tau
  have hbit := bitProbability_bounds C.p_pos.le bits
  apply (bernoulliExpectation_probability_gap _ _ _ _ i C.tau
    (1 / (2 : ℝ) ^ bits) htau ?_ ?_).trans
  · have hv' : (0 : ℝ) < vertices := by exact_mod_cast hv
    have hi' : (i : ℝ) ≤ (vertices : ℝ) ^ 2 := by exact_mod_cast hi
    have hpow : (0 : ℝ) < 2 ^ bits := by positivity
    have hwidth : (vertices : ℝ) ^ 2 * (1 / (2 : ℝ) ^ bits) ≤
        epsilon / (64 * (vertices : ℝ) ^ 2) := by
      have hmul := (div_le_iff₀ he).1 hb
      apply (le_div_iff₀ (by positivity : 0 < 64 * (vertices : ℝ) ^ 2)).2
      calc
        _ = ((vertices : ℝ) ^ 2 * (64 * (vertices : ℝ) ^ 2)) / 2 ^ bits := by ring
        _ ≤ epsilon := (div_le_iff₀ hpow).2 (by convert hmul using 1 <;> ring)
    rw [hgap]
    calc
      _ ≤ (vertices : ℝ) ^ 2 * (1 / (2 : ℝ) ^ bits) * C.tau := by gcongr
      _ ≤ epsilon / (64 * (vertices : ℝ) ^ 2) * C.tau :=
        mul_le_mul_of_nonneg_right hwidth htau
      _ = _ := by ring
  · intro j _
    unfold bitTraceProbability traceProbability
    split_ifs
    · exact ⟨hbit.1, hbit.2.1, hp, hbit.2.2.le⟩
    · exact ⟨le_rfl, le_rfl, zero_le_one, by simp⟩
  · intro A
    refine ⟨marginal_nonnegative f hm _ A, ?_⟩
    have hh := marginal_antitone f hf hm ∅ A (input i).1 (Finset.empty_subset A)
    have hsingle : marginal f (input i).1 ∅ = f {(input i).1} := by simp [marginal, hzero]
    exact hh.trans (hsingle.trans_le hcap)


/-- The average of the actual marginal samples before quarter-grid snapping. -/
noncomputable def rawSampleAverage {N : ℕ} (samples : Fin N → ℝ) : ℝ :=
  (∑ i, samples i) / (N : ℝ)

/-- The quarter-grid adjustment in the actual integer accumulator costs
at most one quarter of an estimate grid unit. -/
theorem sourceAverage_snap_error {N : ℕ} (d : ℝ) (samples : Fin N → ℝ)
    (hd : 0 < d) (hN : 0 < N) :
    sourceAverage d samples ≤ rawSampleAverage samples ∧
      rawSampleAverage samples ≤ sourceAverage d samples + d / 4 := by
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have hsum : sourceAverage d samples =
      (∑ i : Fin N, d * (⌊4 * samples i / d⌋ : ℝ) / 4) / N := by
    unfold sourceAverage sourceIndex
    push_cast
    rw [show (∑ i : Fin N, d * (⌊4 * samples i / d⌋ : ℝ) / 4) =
        (d / 4) * (∑ i : Fin N, (⌊4 * samples i / d⌋ : ℝ)) by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun i _ => by ring)]
    ring
  have hfloor_le (i : Fin N) : d * (⌊4 * samples i / d⌋ : ℝ) / 4 ≤ samples i := by
    have hh := (le_div_iff₀ hd).1 (Int.floor_le (4 * samples i / d))
    linarith
  have hfloor_ge (i : Fin N) :
      samples i ≤ d * (⌊4 * samples i / d⌋ : ℝ) / 4 + d / 4 := by
    have hh := (div_lt_iff₀ hd).1 (Int.lt_floor_add_one (4 * samples i / d))
    linarith
  rw [hsum, rawSampleAverage]
  constructor
  · exact div_le_div_of_nonneg_right (Finset.sum_le_sum (fun i _ => hfloor_le i)) hNr.le
  · calc
      _ ≤ (∑ i : Fin N, (d * (⌊4 * samples i / d⌋ : ℝ) / 4 + d / 4)) / N :=
        div_le_div_of_nonneg_right (Finset.sum_le_sum (fun i _ => hfloor_ge i)) hNr.le
      _ = _ := by
        rw [Finset.sum_add_distrib]
        simp [add_div, Finset.sum_const, hNr.ne']

/-- Combining the mean bias, raw sample deviation and actual floor snapping
gives the snapped accuracy event consumed by `sampled_charge_six_epsilon`. -/
theorem sourceAverage_accuracy_of_deviation {N : ℕ} (d w bitMean : ℝ)
    (samples : Fin N → ℝ) (hd : 0 < d) (hN : 0 < N)
    (hmean : |w - bitMean| ≤ d / 64)
    (hsample : |rawSampleAverage samples - bitMean| ≤ d / 2) :
    w - d ≤ sourceAverage d samples ∧ sourceAverage d samples ≤ w + d := by
  have hsnap := sourceAverage_snap_error d samples hd hN
  obtain ⟨hmlo, hmhi⟩ := abs_le.1 hmean
  obtain ⟨hslo, hshi⟩ := abs_le.1 hsample
  exact ⟨by linarith [hsnap.2], by linarith [hsnap.1]⟩

end SubmodularMatching.Streaming
