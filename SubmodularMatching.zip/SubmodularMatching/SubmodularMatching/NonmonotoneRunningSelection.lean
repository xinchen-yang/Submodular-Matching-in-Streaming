import SubmodularMatching.NonmonotoneSelectedGuarantees

/-! The running selectors consume one challenger at a time. Feasible
support sets are used in the proofs and are not an input to selection. -/
namespace SubmodularMatching.UpperBoundAssembly
open GibbsSampler Finset
noncomputable section
variable {A T : Type*}

def incumbentScan (f : A → ℝ) (step : ℝ) : List (CandidateLaw A) → A → CandidateLaw A
  | [],a => CandidateLaw.pure a
  | q::qs,a => by
    classical
    exact q.bind fun b => incumbentScan f step qs (keepBetter f step a b)

def incumbentRepeat (f : A → ℝ) (step : ℝ) (q : CandidateLaw A) :
    ℕ → A → CandidateLaw A
  | 0,a => CandidateLaw.pure a
  | n+1,a => by
    classical
    exact q.bind fun b => incumbentRepeat f step q n (keepBetter f step a b)

theorem incumbentScan_observe (f test : A → ℝ) (step : ℝ) (qs : List (CandidateLaw A)) (a : A) :
    let q := incumbentScan f step qs a
    expected q.outcomes q.mass test = scanExpectation f step test qs a := by
  induction qs generalizing a with
  | nil => exact CandidateLaw.pure_expected _ _
  | cons q qs ih =>
    dsimp only [incumbentScan,scanExpectation]
    rw [CandidateLaw.bind_expected]
    refine sum_congr rfl fun b _ => ?_
    dsimp only
    rw [ih]

theorem incumbentScan_invariant (f : A → ℝ) (step : ℝ) (qs : List (CandidateLaw A))
    (s : Finset A) (a : A) (ha : a∈s) (hs : ∀ q∈qs, q.outcomes ⊆ s) :
    (incumbentScan f step qs a).outcomes ⊆ s := by
  classical
  induction qs generalizing a with
  | nil => simpa [incumbentScan,CandidateLaw.pure] using ha
  | cons q qs ih =>
    intro b hb
    dsimp only [incumbentScan] at hb
    obtain ⟨x,hx,hb⟩ := (CandidateLaw.mem_bind _ _ _).mp hb
    apply ih _ ?_ (fun d hd => hs d (List.mem_cons_of_mem _ hd)) hb
    unfold keepBetter
    split_ifs
    · exact hs q List.mem_cons_self hx
    · exact ha

theorem incumbentRepeat_law (f : A → ℝ) (step : ℝ) (q : CandidateLaw A) (n : ℕ) (a : A) :
    incumbentRepeat f step q n a = incumbentScan f step (List.replicate n q) a := by
  induction n generalizing a with
  | zero => rfl
  | succ n ih =>
    rw [incumbentRepeat,List.replicate_succ,incumbentScan]
    simp only [ih]

theorem incumbentRepeat_congr (f test : A → ℝ) (step : ℝ) (q r : CandidateLaw A)
    (h : ∀ g, expected q.outcomes q.mass g = expected r.outcomes r.mass g) (n : ℕ) (a : A) :
    let p := incumbentRepeat f step q n a
    let u := incumbentRepeat f step r n a
    expected p.outcomes p.mass test = expected u.outcomes u.mass test := by
  classical
  induction n generalizing a with
  | zero => rfl
  | succ n ih =>
    dsimp only [incumbentRepeat]
    rw [CandidateLaw.bind_expected,CandidateLaw.bind_expected,h]
    refine sum_congr rfl fun b _ => ?_
    dsimp only
    rw [ih]

def physicalExpected (prep : CandidateLaw T) (f : A → ℝ) (step : ℝ)
    (qs : T → List (CandidateLaw A)) (a : A) : CandidateLaw A := by
  classical
  exact prep.bind fun t => incumbentScan f step (qs t) a

def physicalAmplified (prep : CandidateLaw T) (f : A → ℝ) (step decisionStep : ℝ)
    (qs : T → List (CandidateLaw A)) (a : A) (n : ℕ) : CandidateLaw A := by
  classical
  exact prep.bind fun t => incumbentRepeat f decisionStep (incumbentScan f step (qs t) a) n a

theorem physicalExpected_observe (prep : CandidateLaw T) (f test : A → ℝ) (step : ℝ)
    (qs : T → List (CandidateLaw A)) (a : A) (states : Finset A)
    (ha : a∈states) (hs : ∀ t, ∀ q∈qs t, q.outcomes ⊆ states) :
    let p := physicalExpected prep f step qs a
    let q := expectedOutputLaw prep states f step qs a ha hs
    expected p.outcomes p.mass test = expected q.outcomes q.mass test := by
  dsimp only
  rw [expectedOutputLaw_value]
  unfold physicalExpected
  rw [CandidateLaw.bind_expected]
  refine sum_congr rfl fun t _ => ?_
  dsimp only
  rw [incumbentScan_observe]

theorem physicalAmplified_observe (prep : CandidateLaw T) (f test : A → ℝ)
    (step decisionStep : ℝ) (qs : T → List (CandidateLaw A)) (a : A) (n : ℕ)
    (states : Finset A) (ha : a∈states) (hs : ∀ t, ∀ q∈qs t, q.outcomes ⊆ states) :
    let p := physicalAmplified prep f step decisionStep qs a n
    let q := refinedOutputLaw prep states f step decisionStep qs a ha hs n
    expected p.outcomes p.mass test = expected q.outcomes q.mass test := by
  classical
  dsimp only
  unfold physicalAmplified refinedOutputLaw
  rw [CandidateLaw.bind_expected,CandidateLaw.bind_expected]
  refine sum_congr rfl fun t _ => ?_
  let spec := oneTrialLaw states f step (qs t) a ha (hs t)
  have h (g : A → ℝ) :
      let q := incumbentScan f step (qs t) a
      expected q.outcomes q.mass g = expected spec.outcomes spec.mass g := by
    dsimp only
    rw [incumbentScan_observe]
    exact (scanMass_expected states f g step (qs t) a ha (hs t)).symm
  dsimp only
  apply congrArg (prep.mass t * ·)
  rw [incumbentRepeat_congr f test decisionStep _ spec h n a]
  rw [incumbentRepeat_law,incumbentScan_observe]
  exact (scanMass_expected states f test decisionStep (List.replicate n spec) a ha (by
    intro d hd
    obtain ⟨_,rfl⟩ := List.mem_replicate.mp hd
    exact fun x hx => hx)).symm

theorem physicalExpected_invariant (prep : CandidateLaw T) (f : A → ℝ) (step : ℝ)
    (qs : T → List (CandidateLaw A)) (a : A) (states : Finset A)
    (ha : a∈states) (hs : ∀ t, ∀ q∈qs t, q.outcomes ⊆ states) :
    (physicalExpected prep f step qs a).outcomes ⊆ states := by
  classical
  intro b hb
  obtain ⟨t,_,ht⟩ := (CandidateLaw.mem_bind _ _ b).mp hb
  exact incumbentScan_invariant f step (qs t) states a ha (hs t) ht

theorem physicalAmplified_invariant (prep : CandidateLaw T) (f : A → ℝ)
    (step decisionStep : ℝ) (qs : T → List (CandidateLaw A)) (a : A) (n : ℕ)
    (states : Finset A) (ha : a∈states) (hs : ∀ t, ∀ q∈qs t, q.outcomes ⊆ states) :
    (physicalAmplified prep f step decisionStep qs a n).outcomes ⊆ states := by
  classical
  intro b hb
  obtain ⟨t,_,ht⟩ := (CandidateLaw.mem_bind _ _ b).mp hb
  rw [incumbentRepeat_law] at ht
  apply incumbentScan_invariant f decisionStep _ states _ ha ?_ ht
  intro r hr
  obtain ⟨_,rfl⟩ := List.mem_replicate.mp hr
  exact incumbentScan_invariant f step (qs t) states a ha (hs t)

end
end SubmodularMatching.UpperBoundAssembly
