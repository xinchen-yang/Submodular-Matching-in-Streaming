import SubmodularMatching.FiniteShearerBudget
import Mathlib.Data.Nat.Log

/-!
# Concrete integer word grids for the Shearer primitives

When the edge vector shares denominator `Q` and the stop probability
is `a/b`, each family of choices has a common integer denominator.
This makes the primitive survival factors in the binary law concrete.
-/

namespace SubmodularMatching.ShearerSampler

open GibbsMatching GibbsSampler Shearer
open scoped BigOperators

/-- The smallest word width covering the positive denominator. -/
def ChoiceGrid.ofDenominator (q : ℕ) (hq : 0 < q) : ChoiceGrid where
  denominator := q
  bits := Nat.clog 2 q
  covers := Nat.le_pow_clog (by decide) _
  notTooLarge := (rejection_grid_bounds q _ hq (Nat.le_pow_clog (by decide) _)
    (fun j hj => Nat.pow_lt_of_lt_clog hj)).2

structure RationalShearerInput (E : Type*) where
  a : ℕ
  b : ℕ
  Q : ℕ
  numerator : E → ℕ
  a_pos : 0 < a
  a_lt_b : a < b
  Q_pos : 0 < Q

namespace RationalShearerInput

variable {E V : Type*}

noncomputable def stop (c : RationalShearerInput E) : ℝ := c.a/c.b

noncomputable def x (c : RationalShearerInput E) (e : E) : ℝ := c.numerator e/c.Q

def stopGrid (c : RationalShearerInput E) : ChoiceGrid :=
  ChoiceGrid.ofDenominator c.b (c.a_pos.trans c.a_lt_b)

def neighborGrid (c : RationalShearerInput E) : ChoiceGrid :=
  ChoiceGrid.ofDenominator (c.Q*c.a*(c.b-c.a))
    (Nat.mul_pos (Nat.mul_pos c.Q_pos c.a_pos) (Nat.sub_pos_of_lt c.a_lt_b))

def edgeGrid (c : RationalShearerInput E) : ChoiceGrid :=
  ChoiceGrid.ofDenominator (c.Q*c.a^2) (Nat.mul_pos c.Q_pos (pow_pos c.a_pos _))

def edgeCells (c : RationalShearerInput E) (e : E) : ℕ := c.numerator e * c.b^2

theorem x_nonneg (c : RationalShearerInput E) (e : E) : 0 ≤ c.x e := by
  unfold x
  positivity

theorem stop_grid_value (c : RationalShearerInput E) :
    c.stop = (c.a:ℝ)/c.stopGrid.denominator := rfl

theorem neighbor_grid_value (c : RationalShearerInput E) (e : E) :
    c.x e / (c.stop*(1-c.stop)) = (c.edgeCells e:ℝ)/c.neighborGrid.denominator := by
  have hB : (c.b:ℝ) ≠ 0 := by exact_mod_cast (c.a_pos.trans c.a_lt_b).ne'
  have hA : (c.a:ℝ) ≠ 0 := by exact_mod_cast c.a_pos.ne'
  have hQ : (c.Q:ℝ) ≠ 0 := by exact_mod_cast c.Q_pos.ne'
  have hAB : (c.b:ℝ)-(c.a:ℝ) ≠ 0 := sub_ne_zero.mpr (by exact_mod_cast c.a_lt_b.ne')
  dsimp [x, stop, edgeCells, neighborGrid, ChoiceGrid.ofDenominator]
  rw [Nat.cast_mul, Nat.cast_pow, Nat.cast_mul, Nat.cast_mul, Nat.cast_sub c.a_lt_b.le]
  field_simp [hA,hB,hQ,hAB]

theorem edge_grid_value (c : RationalShearerInput E) (e : E) :
    c.x e / c.stop^2 = (c.edgeCells e:ℝ)/c.edgeGrid.denominator := by
  have hB : (c.b:ℝ) ≠ 0 := by exact_mod_cast (c.a_pos.trans c.a_lt_b).ne'
  have hA : (c.a:ℝ) ≠ 0 := by exact_mod_cast c.a_pos.ne'
  have hQ : (c.Q:ℝ) ≠ 0 := by exact_mod_cast c.Q_pos.ne'
  dsimp [x, stop, edgeCells, edgeGrid, ChoiceGrid.ofDenominator]
  rw [Nat.cast_mul, Nat.cast_pow, Nat.cast_mul, Nat.cast_pow]
  field_simp [hA,hB,hQ]

variable [DecidableEq E] [DecidableEq V]

omit [DecidableEq E] in
/-- The neighbor intervals fit within the common denominator. Every
unused index is the null choice. -/
theorem neighbor_cells_fit (c : RationalShearerInput E) (ends : E → Finset V)
    (edges : Finset E) (v : V) (hDegree : ∑ e ∈ incident ends edges v, c.x e ≤ c.stop*(1-c.stop)) :
    (∑ e ∈ incident ends edges v, c.edgeCells e) ≤ c.neighborGrid.denominator := by
  have hr : 0 < c.stop := by
    have hA : (0:ℝ) < c.a := by exact_mod_cast c.a_pos
    have hB : (0:ℝ) < c.b := by exact_mod_cast c.a_pos.trans c.a_lt_b
    exact div_pos hA hB
  have hr₁ : c.stop < 1 := by
    unfold stop
    have hB : (0:ℝ) < c.b := by exact_mod_cast c.a_pos.trans c.a_lt_b
    apply (div_lt_iff₀ hB).2
    norm_num
    exact_mod_cast c.a_lt_b
  have hBound : (∑ e ∈ incident ends edges v, c.x e/(c.stop*(1-c.stop))) ≤ 1 := by
    rw [← Finset.sum_div]
    exact (div_le_one (mul_pos hr (sub_pos.mpr hr₁))).2 hDegree
  simp_rw [c.neighbor_grid_value] at hBound
  rw [← Finset.sum_div, ← Nat.cast_sum] at hBound
  have hPos : 0 < (c.neighborGrid.denominator:ℝ) := by
    change 0 < ((c.Q*c.a*(c.b-c.a):ℕ):ℝ)
    have h := Nat.mul_pos (Nat.mul_pos c.Q_pos c.a_pos) (Nat.sub_pos_of_lt c.a_lt_b)
    exact_mod_cast h
  exact_mod_cast (div_le_one hPos).1 hBound

omit [DecidableEq E] in
/-- Exact cell accounting for the extra Bernoulli draw before the two
recursive calls. Its threshold is at most the common denominator. -/
theorem edge_cells_fit (c : RationalShearerInput E) (e : E)
    (hx : c.x e ≤ c.stop^2) :
    c.edgeCells e ≤ c.edgeGrid.denominator := by
  have hDen : 0 < (c.edgeGrid.denominator:ℝ) := by
    change 0 < ((c.Q*c.a^2 : ℕ):ℝ)
    exact_mod_cast Nat.mul_pos c.Q_pos (pow_pos c.a_pos 2)
  have hr : 0 < c.stop := by
    have hA : (0:ℝ) < c.a := by exact_mod_cast c.a_pos
    have hB : (0:ℝ) < c.b := by exact_mod_cast c.a_pos.trans c.a_lt_b
    exact div_pos hA hB
  have hb := (div_le_one (sq_pos_of_pos hr)).2 hx
  rw [c.edge_grid_value] at hb
  exact_mod_cast (div_le_one hDen).1 hb

/-- On a common grid, the prescribed-error binary law has a concrete
choice of all three primitive word widths. -/
theorem sampler_prescribed_error (c : RationalShearerInput E)
    (ends : E → Finset V) (vertices : E → V × V) (edges : Finset E)
    (hStop : c.b < 2*c.a)
    (hends : ∀ e ∈ edges, (ends e).card = 2)
    (hpairs : ∀ e ∈ edges, ends e = {(vertices e).1, (vertices e).2})
    (hdegree : ∀ v, (∑ e ∈ incident ends edges v, c.x e) ≤ c.stop*(1-c.stop))
    (δ : ℝ) (hδ : 0 < δ ∧ δ ≤ 1)
    (order : List E) (hnodup : order.Nodup) (h : order.toFinset ⊆ edges) :
    let L := samplerFuel c.stop δ order.length
    let B := samplerAttempts δ order.length L
    let law := binaryShearerLaw ends vertices edges c.x c.stop (2*L) B
      (fun _ => c.stopGrid) (fun _ => c.neighborGrid) (fun _ => c.edgeGrid) order h
    IsProbability (matchings ends edges) law ∧
      variation (matchings ends edges) (mass ends order.toFinset c.x) law ≤ δ := by
  have hB : (0:ℝ) < c.b := by exact_mod_cast c.a_pos.trans c.a_lt_b
  have hHalf : 1/2 < c.stop := by
    apply (lt_div_iff₀ hB).2
    have h : (c.b:ℝ) < 2*c.a := by exact_mod_cast hStop
    linarith only [h]
  have hOne : c.stop < 1 := by
    apply (div_lt_iff₀ hB).2
    rw [one_mul]
    exact_mod_cast c.a_lt_b
  exact binaryShearerLaw_prescribed_error ends vertices edges c.x c.stop hHalf hOne
    (fun e _ => c.x_nonneg e) hends hpairs hdegree δ hδ
    (fun _ => c.stopGrid) (fun _ => c.neighborGrid) (fun _ => c.edgeGrid) order hnodup h

end RationalShearerInput

/-- Consecutive cells beginning at an integer offset. This representation
can be realized with interval membership and does not enumerate the words. -/
def cellInterval (q offset count : ℕ) (h : offset+count ≤ q) : Finset (Fin q) :=
  Finset.univ.map
    ⟨fun i : Fin count => ⟨offset+i.val, by omega⟩,
      fun a b hab => Fin.ext (by have he := congrArg Fin.val hab; simp at he; exact he)⟩

@[simp] theorem card_cellInterval (q offset count : ℕ) (h : offset+count ≤ q) :
    (cellInterval q offset count h).card = count := by
  simp [cellInterval]

theorem mem_cellInterval (q offset count : ℕ) (h : offset+count ≤ q) (i : Fin q) :
    i ∈ cellInterval q offset count h ↔ offset ≤ i.val ∧ i.val < offset+count := by
  unfold cellInterval
  constructor
  · intro hi
    obtain ⟨j,_,heq⟩ := Finset.mem_map.mp hi
    have hj : offset+j.val = i.val := congrArg Fin.val heq
    omega
  · intro hi
    let j : Fin count := ⟨i.val-offset, by omega⟩
    exact Finset.mem_map.mpr ⟨j,Finset.mem_univ _,Fin.ext (by dsimp [j]; omega)⟩

theorem ChoiceGrid.interval_probability (B : ℕ) (g : ChoiceGrid)
    (offset count : ℕ) (h : offset+count ≤ g.denominator) :
    (∑ _ ∈ cellInterval g.denominator offset count h,
      boundedUniform g.denominator (2^g.bits) B) =
        (count:ℝ)/g.denominator * g.alive B := by
  rw [g.event_probability B, card_cellInterval]

end SubmodularMatching.ShearerSampler
