import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step203 : ProjectedGoal ⟨432, 647, 283, 567, 567, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0xd7ff0000000000000002400f) (by decide +kernel)

theorem Part00018 : ProjectedGoal ⟨432, 647, 283, 567, 567, 1135⟩ := step203

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
