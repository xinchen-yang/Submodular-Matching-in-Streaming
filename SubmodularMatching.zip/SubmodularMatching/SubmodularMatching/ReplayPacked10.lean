import SubmodularMatching.ReplaySupportedPartition
import SubmodularMatching.ReplayQuickRate
import SubmodularMatching.CertificateRateRunRegion
import SubmodularMatching.CertificateConeLiterals

namespace SubmodularMatching.SourceCertificate.Replay.Packed10

set_option maxRecDepth 4000
set_option maxHeartbeats 8000000

def ClassGoal (box : PriceBox) : Prop :=
  (∀ z < 2^32, (runRegion quickRow z).Valid) →
  (∀ z < 72, (appendixFastConeAt z).Sufficient) → AppendixBoxGoal true false box

private theorem chunk0 : ClassGoal ⟨0, 6911, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 9 0xfcf 0xaeaddc9e00028001aeaddc9e00027001aeaddc9e00026001aeaddc9e00026001aeaddc9e00025001 (by decide +kernel)
private theorem chunk1 : ClassGoal ⟨6912, 10367, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 17 0x3cf3c3f 0xaeaddc9e0002b001aeaddc9e0002b001aeaddc9e0002a001aeaddc9e0002a001aeaddc9e00029001aeaddc9e00029001aeaddc9e00028001aeaddc9e00028001aeaddc9e00028001 (by decide +kernel)
private theorem chunk2 : ClassGoal ⟨10368, 12095, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 11 0xf3cf 0xaeaddc9e0002d02caeaddc9e0002d02caeaddc9e0002d02caeaddc9e0002d02caeaddc9e0002b001aeaddc9e0002b001 (by decide +kernel)
private theorem chunk3 : ClassGoal ⟨12096, 13823, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 15 0xf3c3cf 0xaeaddc9e0002e02caeaddc9e0002e02caeaddc9e0002e02caeaddc9e0002e02caeaddc9e0002d02caeaddc9e0002d02caeaddc9e0002d02caeaddc9e0002d02c (by decide +kernel)
private theorem chunk4 : ClassGoal ⟨13824, 17279, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 19 0xf3c3c3cf 0xaeaddc9e0003202caeaddc9e0003202caeaddc9e0003102caeaddc9e0003002caeaddc9e0003002caeaddc9e0002f02caeaddc9e0002f02caeaddc9e0002f02caeaddc9e0002f02caeaddc9e0002f02c (by decide +kernel)
private theorem chunk5 : ClassGoal ⟨17280, 20735, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 9 0x3ccf 0xaeaddc9e0003702caeaddc9e0003602caeaddc9e0003502caeaddc9e0003402caeaddc9e0003302c (by decide +kernel)
private theorem chunk6 : ClassGoal ⟨20736, 27647, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 5 0xcf 0xaeaddc9e0003a02caeaddc9e0003902caeaddc9e0003802c (by decide +kernel)
private theorem chunk7 : ClassGoal ⟨27648, 55295, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 5 0xcf 0xaeaddc9e0003f03eaeaddc9e0003d02caeaddc9e0003c03b (by decide +kernel)
private theorem chunk8 : ClassGoal ⟨0, 55295, 283, 567, 0, 567⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 17 0xdc0f1fcf 0x44002000000000004404600000000000440415756ee4f000450410000000000044043aeaddc9e000320426241cc18e003c0416d2ca9e2c002f040aeaddc9e00025040 (by decide +kernel)
private theorem chunk9 : ClassGoal ⟨0, 55295, 0, 567, 567, 1135⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 5 0x3f 0x2400300000000000240030000000000024003 (by decide +kernel)
private theorem chunk10 : ClassGoal ⟨0, 55295, 567, 1135, 0, 1135⟩ := by
  intro rates cones
  exact packedGoalSupported (runRegion quickRow) appendixFastConeAt 72 rates cones true false _ 1 0x3 0x47004 (by decide +kernel)
private theorem branch0 : ClassGoal ⟨10368, 13823, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 12095 (by decide) (by decide) (chunk2 rates cones) (chunk3 rates cones)
private theorem branch1 : ClassGoal ⟨6912, 13823, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 10367 (by decide) (by decide) (chunk1 rates cones) (branch0 rates cones)
private theorem branch2 : ClassGoal ⟨0, 13823, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 6911 (by decide) (by decide) (chunk0 rates cones) (branch1 rates cones)
private theorem branch3 : ClassGoal ⟨13824, 20735, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 17279 (by decide) (by decide) (chunk4 rates cones) (chunk5 rates cones)
private theorem branch4 : ClassGoal ⟨13824, 27647, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 20735 (by decide) (by decide) (branch3 rates cones) (chunk6 rates cones)
private theorem branch5 : ClassGoal ⟨0, 27647, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 13823 (by decide) (by decide) (branch2 rates cones) (branch4 rates cones)
private theorem branch6 : ClassGoal ⟨0, 55295, 0, 283, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 27647 (by decide) (by decide) (branch5 rates cones) (chunk7 rates cones)
private theorem branch7 : ClassGoal ⟨0, 55295, 0, 567, 0, 567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 283 (by decide) (by decide) (branch6 rates cones) (chunk8 rates cones)
private theorem branch8 : ClassGoal ⟨0, 55295, 0, 567, 0, 1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 567 (by decide) (by decide) (branch7 rates cones) (chunk9 rates cones)
private theorem branch9 : ClassGoal ⟨0, 55295, 0, 1135, 0, 1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 567 (by decide) (by decide) (branch8 rates cones) (chunk10 rates cones)

theorem checked : ClassGoal appendixPriceRoot := branch9

end SubmodularMatching.SourceCertificate.Replay.Packed10
