import SubmodularMatching.ShearerTimeCloneSpace

namespace SubmodularMatching.Shearer

open GibbsMatching
open scoped BigOperators
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem clone_product (x : E → ℝ) (k : ℕ) (K : Finset (E×ℕ))
    (hi : Set.InjOn Prod.fst (K : Set (E×ℕ))) :
    weight (fun c : E×ℕ => x c.1 / (k:ℝ)) K = weight x (K.image Prod.fst) / (k:ℝ)^K.card := by
  unfold weight
  rw [Finset.prod_div_distrib, Finset.prod_const, Finset.prod_image]
  exact fun _ ha _ hb hab => hi ha hb hab

private theorem marked_product (ends : E → Finset V) (S : Finset E) (k : ℕ)
    (hend : ∀ e ∈ S, (ends e).Nonempty) (x : E → ℝ) (M : Outcome ends S) (g : M.val → Fin k) :
    weight (fun c : E×ℕ => x c.1/(k:ℝ)) (markedGraph M.val g) = weight x M.val/(k:ℝ)^M.val.card := by
  have hi := clone_fst_injOn ends S k hend _ (markedGraph_isMatching ends S M.val M.property g)
  have hc := Finset.card_image_of_injOn hi
  rw [markedGraph_projection] at hc
  rw [clone_product x k _ hi,markedGraph_projection, ← hc]

theorem clone_partition (ends : E → Finset V) (S : Finset E) (k : ℕ) (hk : 0 < k)
    (hend : ∀ e ∈ S, (ends e).Nonempty) (x : E → ℝ) :
    partition (cloneEnds ends) (timedSupport S k) (fun c => x c.1 / (k:ℝ)) =
      partition ends S x := by
  let F (z : Outcome (cloneEnds ends) (timedSupport S k)) := weight (fun c : E×ℕ => x c.1/k) z.val
  have hs : (∑ z, F z) = ∑ z : MarkAssignments ends S k, F (cloneMatchingEquiv ends S k hend z) :=
    ((cloneMatchingEquiv ends S k hend).sum_comp F).symm
  unfold partition
  conv_lhs => rw [← Finset.sum_coe_sort]
  conv_rhs => rw [← Finset.sum_coe_sort]
  change (∑ z, F z) = _
  rw [hs,Fintype.sum_sigma]
  apply Finset.sum_congr rfl
  intro M _
  change (∑ g : M.val → Fin k, weight (fun c : E×ℕ => x c.1/k) (markedGraph M.val g)) = weight x M.val
  simp only [marked_product ends S k hend x M,Finset.sum_const,Finset.card_univ,Fintype.card_fun,
    Fintype.card_fin,Fintype.card_coe,nsmul_eq_mul,Nat.cast_pow]
  field_simp

theorem clone_signedPartition (ends : E → Finset V) (S : Finset E) (k : ℕ) (hk : 0 < k)
    (hend : ∀ e ∈ S, (ends e).Nonempty) (x : E → ℝ) :
    signedPartition (cloneEnds ends) (timedSupport S k) (fun c => x c.1/(k:ℝ)) =
      signedPartition ends S x := by
  simpa only [signedPartition, neg_div] using clone_partition ends S k hk hend (fun e => -x e)

theorem clone_residualEdges (ends : E → Finset V) (S : Finset E) (k : ℕ)
    (hend : ∀ e ∈ S, (ends e).Nonempty) (K : Finset (E×ℕ)) :
    residualEdges (cloneEnds ends) (timedSupport S k) K =
      timedSupport (residualEdges ends S (K.image Prod.fst)) k := by
  ext ⟨e,t⟩
  simp only [mem_residualEdges,timedSupport,Finset.mem_product]
  constructor
  · rintro ⟨⟨he,ht⟩,_,hdis⟩
    refine ⟨⟨he,?_,?_⟩,ht⟩
    · intro h
      obtain ⟨c,hc,hc'⟩ := Finset.mem_image.mp h
      have hd : Disjoint (ends c.1) (ends e) := hdis c hc
      obtain ⟨v,hv⟩ := hend _ he
      rw [hc'] at hd
      exact (Finset.disjoint_left.mp hd hv hv)
    · intro d hd
      obtain ⟨c,hc,rfl⟩ := Finset.mem_image.mp hd
      exact hdis c hc
  · rintro ⟨⟨he,hn,hd⟩,ht⟩
    refine ⟨⟨he,ht⟩,fun h => hn (Finset.mem_image_of_mem Prod.fst h),?_⟩
    exact fun c hc => hd _ (Finset.mem_image_of_mem Prod.fst hc)

/-- The exact mass of any fixed set of independently marked selected edges.
The denominator is one k-way choice per selected edge. -/
theorem timeClone_mass (ends : E → Finset V) (S : Finset E) (x : E → ℝ) (k : ℕ) (hk : 0 < k)
    (hend : ∀ e ∈ S, (ends e).Nonempty) (K : Finset (E×ℕ))
    (hK : K ∈ matchings (cloneEnds ends) (timedSupport S k)) :
    mass (cloneEnds ends) (timedSupport S k) (fun c => x c.1/k) K =
      mass ends S x (K.image Prod.fst)/(k:ℝ)^K.card := by
  have hP := clone_projection_matching ends S k K hK
  rw [mass_of_mem _ _ _ _ hK,mass_of_mem _ _ _ _ hP,
    clone_product x k K (clone_fst_injOn ends S k hend K hK), clone_residualEdges ends S k hend K,
    clone_signedPartition ends _ k hk (fun e he => hend e (residualEdges_subset _ _ _ he))]
  ring

theorem timeClone_expectation (ends : E → Finset V) (S : Finset E) (x : E → ℝ) (k : ℕ) (hk : 0 < k)
    (hend : ∀ e ∈ S, (ends e).Nonempty) (H : Finset (E×ℕ) → ℝ) :
    expectation (cloneEnds ends) (timedSupport S k) (fun c => x c.1/k) H =
      expectation ends S x (fun M => (∑ g : M → Fin k, H (markedGraph M g))/(k:ℝ)^M.card) := by
  let F (z : Outcome (cloneEnds ends) (timedSupport S k)) :=
    mass (cloneEnds ends) (timedSupport S k) (fun c => x c.1/k) z.val * H z.val
  have hs : (∑ z, F z) = ∑ z : MarkAssignments ends S k, F (cloneMatchingEquiv ends S k hend z) :=
    ((cloneMatchingEquiv ends S k hend).sum_comp F).symm
  unfold expectation
  conv_lhs => rw [← Finset.sum_coe_sort]
  conv_rhs => rw [← Finset.sum_coe_sort]
  change (∑ z, F z) = _
  rw [hs,Fintype.sum_sigma]
  apply Finset.sum_congr rfl
  intro M _
  change (∑ g : M.val → Fin k, mass (cloneEnds ends) (timedSupport S k) (fun c => x c.1/k)
    (markedGraph M.val g)* H (markedGraph M.val g)) = _
  have hterm (g : M.val → Fin k) : mass (cloneEnds ends) (timedSupport S k) (fun c => x c.1/k)
      (markedGraph M.val g) = mass ends S x M.val/(k:ℝ)^M.val.card := by
    have hm := markedGraph_isMatching ends S _ M.property g
    have hc := Finset.card_image_of_injOn (clone_fst_injOn ends S k hend _ hm)
    rw [markedGraph_projection] at hc
    rw [timeClone_mass ends S x k hk hend _ hm,markedGraph_projection, ← hc]
  simp only [hterm,← Finset.mul_sum]
  ring

/-- Forgetting all time stamps recovers the original Shearer distribution
exactly, for every observable, without a positivity restriction on its values. -/
theorem timeClone_projected_expectation (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (k : ℕ) (hk : 0 < k) (hend : ∀ e ∈ S, (ends e).Nonempty) (H : Finset E → ℝ) :
    expectation (cloneEnds ends) (timedSupport S k) (fun c => x c.1/k) (fun K => H (K.image Prod.fst)) =
      expectation ends S x H := by
  rw [timeClone_expectation ends S x k hk hend]
  apply expectation_congr
  intro M _
  simp only [markedGraph_projection,Finset.sum_const,Finset.card_univ,Fintype.card_fun,Fintype.card_fin,
    Fintype.card_coe,nsmul_eq_mul,Nat.cast_pow]
  field_simp

end
end SubmodularMatching.Shearer
