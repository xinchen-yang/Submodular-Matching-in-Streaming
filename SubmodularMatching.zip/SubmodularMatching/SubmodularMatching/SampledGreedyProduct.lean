import SubmodularMatching.SampledGreedyAdaptive
import SubmodularMatching.SamplingSemantics
import SubmodularMatching.StreamingAccuracyHoeffding
import Mathlib.Probability.ProbabilityMassFunction.Integrals

/-!
# A concrete law for fresh derivative samples

Each sample uses two independent Bernoulli sets. The weighted Bernoulli
outcome lists give an explicit finite probability law for the pair. A
product of this law over the sample indices gives the actual independence
and mean hypotheses in the per-history Hoeffding estimate.
-/

open scoped BigOperators ENNReal
open MeasureTheory ProbabilityTheory

namespace SubmodularMatching.Multilinear

noncomputable section

variable {E : Type*} [DecidableEq E]

omit [DecidableEq E] in
private theorem weightedOutcomeSum_index (F : Finset E → ℝ)
    (xs : List (Finset E × ℝ)) :
    weightedOutcomeSum F xs = ∑ i : Fin xs.length, (xs.get i).2 * F (xs.get i).1 := by
  induction xs with
  | nil => simp
  | cons x xs ih =>
    rw [weightedOutcomeSum_cons]
    change _ = ∑ i : Fin (xs.length + 1), ((x :: xs).get i).2 * F ((x :: xs).get i).1
    rw [Fin.sum_univ_succ, ih]
    rfl

/-- Product mass of the two independent Bernoulli outcomes, indexed by
their positions in the finite lists. Equal sets may have separate indices. -/
def samplePairLaw (zs rs : List (Finset E × ℝ))
    (hz : weightedOutcomeSum (fun _ => 1) zs = 1)
    (hr : weightedOutcomeSum (fun _ => 1) rs = 1)
    (hZ : ∀ z ∈ zs, 0 ≤ z.2) (hR : ∀ r ∈ rs, 0 ≤ r.2) :
    PMF (Fin zs.length × Fin rs.length) :=
  PMF.ofFintype (fun i => ENNReal.ofReal ((zs.get i.1).2 * (rs.get i.2).2)) (by
    rw [← ENNReal.ofReal_sum_of_nonneg
      (fun i _ => mul_nonneg (hZ _ (List.get_mem _ _)) (hR _ (List.get_mem _ _)))]
    rw [Fintype.sum_prod_type]
    simp_rw [← Finset.mul_sum]
    rw [← Finset.sum_mul]
    simp only [weightedOutcomeSum_index, mul_one] at hz hr
    rw [hz, hr]
    simp)

omit [DecidableEq E] in
/-- The expectation under the concrete pair law is the nested independent
expectation used in the multilinear calculation. -/
theorem samplePairLaw_integral (zs rs : List (Finset E × ℝ))
    (hz : weightedOutcomeSum (fun _ => 1) zs = 1)
    (hr : weightedOutcomeSum (fun _ => 1) rs = 1)
    (hZ : ∀ z ∈ zs, 0 ≤ z.2) (hR : ∀ r ∈ rs, 0 ≤ r.2)
    [MeasurableSpace (Fin zs.length × Fin rs.length)]
    [MeasurableSingletonClass (Fin zs.length × Fin rs.length)]
    (sample : Finset E → Finset E → ℝ) :
    (∫ i, sample (rs.get i.2).1 (zs.get i.1).1 ∂(samplePairLaw zs rs hz hr hZ hR).toMeasure) =
      weightedOutcomeSum (fun Z => weightedOutcomeSum (fun R => sample R Z) rs) zs := by
  rw [PMF.integral_eq_sum, Fintype.sum_prod_type, weightedOutcomeSum_index]
  simp only [samplePairLaw, PMF.ofFintype_apply,
    ENNReal.toReal_ofReal (mul_nonneg (hZ _ (List.get_mem _ _)) (hR _ (List.get_mem _ _))),
    smul_eq_mul, weightedOutcomeSum_index, Finset.mul_sum, mul_assoc]

/-- The Hoeffding estimate for an actual fresh product of Bernoulli pairs.
The two input inclusion vectors are already fixed by the preceding history. -/
theorem derivativeSample_product_failure (edges : ℕ → E) (p q : ℕ → ℝ)
    (f : Finset E → ℝ) (e : E) (n : ℕ) (τ u : ℝ) (hu : 0 ≤ u)
    (hp : ∀ i < n, 0 ≤ p i ∧ p i ≤ 1) (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1)
    (hF : ∀ A, 0 ≤ marginal f e A ∧ marginal f e A ≤ τ) (N : ℕ) (hN : 0 < N) :
    let zs := bernoulliOutcomes edges q n
    let rs := bernoulliOutcomes edges p n
    letI : MeasurableSpace (Fin zs.length × Fin rs.length) := ⊤
    let μ₀ := (samplePairLaw zs rs (bernoulliOutcomes_total_mass edges q n)
      (bernoulliOutcomes_total_mass edges p n) (bernoulliOutcomes_nonnegative edges q n hq)
      (bernoulliOutcomes_nonnegative edges p n hp)).toMeasure
    let μ := Measure.pi (fun _ : Fin N => μ₀)
    let mean := bernoulliExpectation edges q (fun Z =>
      bernoulliExpectation edges p (fun R => derivativeSample f e R Z) n) n
    μ.real {ω | u < |Streaming.rawSampleAverage (fun i =>
      derivativeSample f e (rs.get (ω i).2).1 (zs.get (ω i).1).1) - mean|} ≤
      2 * Real.exp (-(2 * N * u ^ 2) / τ ^ 2) := by
  dsimp only
  let zs := bernoulliOutcomes edges q n
  let rs := bernoulliOutcomes edges p n
  let Pair := Fin zs.length × Fin rs.length
  letI : MeasurableSpace Pair := ⊤
  letI : MeasurableSingletonClass Pair := ⟨fun _ => trivial⟩
  let law := samplePairLaw zs rs (bernoulliOutcomes_total_mass edges q n)
    (bernoulliOutcomes_total_mass edges p n) (bernoulliOutcomes_nonnegative edges q n hq)
    (bernoulliOutcomes_nonnegative edges p n hp)
  let sample (o : Pair) := derivativeSample f e (rs.get o.2).1 (zs.get o.1).1
  let μ := Measure.pi (fun _ : Fin N => law.toMeasure)
  let X (i : Fin N) (ω : Fin N → Pair) := sample (ω i)
  have hs : Measurable sample := measurable_of_finite _
  have hX : ∀ i, Measurable (X i) := fun i => hs.comp (measurable_pi_apply i)
  have hmean : (∫ o, sample o ∂law.toMeasure) =
      bernoulliExpectation edges q (fun Z =>
        bernoulliExpectation edges p (fun R => derivativeSample f e R Z) n) n := by
    rw [bernoulliExpectation_eq_weighted_sum]
    simp_rw [bernoulliExpectation_eq_weighted_sum]
    exact samplePairLaw_integral zs rs (bernoulliOutcomes_total_mass edges q n)
      (bernoulliOutcomes_total_mass edges p n) (bernoulliOutcomes_nonnegative edges q n hq)
      (bernoulliOutcomes_nonnegative edges p n hp) (derivativeSample f e)
  have hproduct (i : Fin N) : (∫ ω, X i ω ∂μ) = (∫ o, sample o ∂law.toMeasure) := by
    rw [← (measurePreserving_eval (fun _ : Fin N => law.toMeasure) i).map_eq]
    exact (integral_map (μ := μ) (φ := fun ω : Fin N → Pair => ω i) (f := sample)
      (measurable_pi_apply i).aemeasurable hs.aestronglyMeasurable).symm
  exact Streaming.sample_mean_two_tails
    (iIndepFun_pi (μ := fun _ : Fin N => law.toMeasure) (fun _ => hs.aemeasurable)) hX
    τ _ u hu hN
    (fun i => ae_of_all _ (fun ω => hF _))
    (fun i => (hproduct i).trans hmean)

/-- The natural-log sample budget in Appendix F suffices for accuracy
`ξ τ / 4` in the raw average of each derivative estimate. -/
theorem derivative_sample_count (ξ τ δ : ℝ) (N : ℕ) (hξ : 0 < ξ)
    (hτ : 0 < τ) (hδ : 0 < δ)
    (hcount : 8 / ξ ^ 2 * Real.log (2 / δ) ≤ N) :
    2 * Real.exp (-(2 * N * (ξ * τ / 4) ^ 2) / τ ^ 2) ≤ δ := by
  have htau : τ ^ 2 ≠ 0 := pow_ne_zero _ hτ.ne'
  have h := (div_le_iff₀ (sq_pos_of_pos hξ)).1
    (show 8 * Real.log (2 / δ) / ξ ^ 2 ≤ N by simpa only [div_mul_eq_mul_div] using hcount)
  have he : -(2 * N * (ξ * τ / 4) ^ 2) / τ ^ 2 ≤ Real.log (δ / 2) := by
    rw [show -(2 * N * (ξ * τ / 4) ^ 2) / τ ^ 2 = -(N : ℝ) * ξ ^ 2 / 8 by
      field_simp [htau]; ring,
      show δ / 2 = (2 / δ)⁻¹ by field_simp, Real.log_inv]
    linarith
  calc
    _ ≤ 2 * Real.exp (Real.log (δ / 2)) :=
      mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr he) (by norm_num)
    _ = δ := by rw [Real.exp_log (by positivity)]; ring

/-- One fixed-history fresh batch of dyadic samples gives the empirical
accuracy of the paper's actual snapped derivative estimator. -/
theorem dyadic_derivative_failure (edges : ℕ → E) (p : ℝ) (q : ℕ → ℝ)
    (f : Finset E → ℝ) (n k bits : ℕ) (τ ξ δ : ℝ) (hk : k < n)
    (hτ : 0 < τ) (hξ : 0 < ξ) (hδ : 0 < δ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1)
    (hF : ∀ A, 0 ≤ marginal f (edges k) A ∧ marginal f (edges k) A ≤ τ)
    (hb : (n : ℝ) * (1 / (2 : ℝ) ^ bits) ≤ ξ / 16)
    (N : ℕ) (hN : 0 < N) (hcount : 8 / ξ ^ 2 * Real.log (2 / δ) ≤ N) :
    let bp := fun _ => Streaming.bitProbability p bits
    let bq := fun i => Streaming.bitProbability (omitCoordinate q k i) bits
    let hp' : ∀ i < n, 0 ≤ bp i ∧ bp i ≤ 1 := fun _ _ =>
      let hb := Streaming.bitProbability_bounds hp.1 bits
      ⟨hb.1, hb.2.1.trans hp.2⟩
    let hq' : ∀ i < n, 0 ≤ bq i ∧ bq i ≤ 1 := fun i hi => by
      have hpq : 0 ≤ omitCoordinate q k i ∧ omitCoordinate q k i ≤ 1 := by
        by_cases h : i = k
        · simp [omitCoordinate, h]
        · simpa only [omitCoordinate, h, ↓reduceIte] using hq i hi
      have hb := Streaming.bitProbability_bounds hpq.1 bits
      exact ⟨hb.1, hb.2.1.trans hpq.2⟩
    let zs := bernoulliOutcomes edges bq n
    let rs := bernoulliOutcomes edges bp n
    letI : MeasurableSpace (Fin zs.length × Fin rs.length) := ⊤
    let μ₀ := (samplePairLaw zs rs (bernoulliOutcomes_total_mass edges bq n)
      (bernoulliOutcomes_total_mass edges bp n) (bernoulliOutcomes_nonnegative edges bq n hq')
      (bernoulliOutcomes_nonnegative edges bp n hp')).toMeasure
    let μ := Measure.pi (fun _ : Fin N => μ₀)
    let gradient := coordinateDerivative edges q (residualValue edges p f n) n k
    μ.real {ω | ξ * τ / 2 < |Streaming.sourceAverage (ξ * τ / 2) (fun i =>
      derivativeSample f (edges k) (rs.get (ω i).2).1 (zs.get (ω i).1).1) - gradient|} ≤ δ := by
  intro bp bq hp' hq' zs rs μ₀ μ gradient
  have hbias := roundedDerivativeMean_error edges p q f n k bits τ hk hτ.le hp hq hF
  have hbias' : |gradient - roundedDerivativeMean edges p q f n k bits| ≤ ξ * τ / 8 := by
    refine hbias.trans ?_
    have h := mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hb hτ.le)
      (by norm_num : (0 : ℝ) ≤ 2)
    nlinarith only [h]
  have ht := derivativeSample_product_failure edges bp bq f (edges k) n τ (ξ * τ / 4)
    (by positivity) hp' hq' hF N hN
  have htail := ht.trans (derivative_sample_count ξ τ δ N hξ hτ hδ hcount)
  refine (measureReal_mono (s₂ := {ω : Fin N → Fin zs.length × Fin rs.length |
    ξ * τ / 4 < |Streaming.rawSampleAverage (fun i =>
      derivativeSample f (edges k) (rs.get (ω i).2).1 (zs.get (ω i).1).1) -
        roundedDerivativeMean edges p q f n k bits|}) ?_).trans htail
  intro ω hω
  by_contra hgood
  have hdev : |Streaming.rawSampleAverage (fun i =>
      derivativeSample f (edges k) (rs.get (ω i).2).1 (zs.get (ω i).1).1) -
        roundedDerivativeMean edges p q f n k bits| ≤ ξ * τ / 4 :=
    le_of_not_gt hgood
  exact (not_lt_of_ge (snappedDerivative_accuracy ξ τ gradient
    (roundedDerivativeMean edges p q f n k bits) _ hN hξ hτ hbias' hdev)) hω


end

end SubmodularMatching.Multilinear
