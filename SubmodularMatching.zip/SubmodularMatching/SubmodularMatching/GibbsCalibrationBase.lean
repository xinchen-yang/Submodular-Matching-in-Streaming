import SubmodularMatching.GibbsConditioning
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Fintype.Lattice

/-!
# Exact recursions and residual estimates for Gibbs calibration

These estimates compare the genuine unmatched probabilities with the
reciprocal fixed-point equations used to choose edge activities.
-/

namespace SubmodularMatching.GibbsMatching

open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

omit [DecidableEq E] in
theorem neighborActivity_self (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (v : V) : neighborActivity ends S activity v v = 0 := by
  simp [neighborActivity]

omit [DecidableEq E] in
theorem neighborActivity_deleted_row (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (v u : V) :
    neighborActivity ends (deleteVertex ends S v) activity v u = 0 := by
  apply Finset.sum_eq_zero
  intro e he
  have hem := Finset.mem_filter.mp he
  exact False.elim ((Finset.mem_filter.mp hem.1).2 hem.2)

omit [DecidableEq E] in
theorem neighborActivity_deleted_column (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (v u : V) :
    neighborActivity ends (deleteVertex ends S v) activity u v = 0 := by
  apply Finset.sum_eq_zero
  intro e he
  have hve := (Finset.mem_filter.mp (Finset.mem_filter.mp he).1).2
  simp only [Finset.mem_erase, hve, and_false, ↓reduceIte]

omit [DecidableEq E] in
theorem neighborActivity_symm (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (v u : V) :
    neighborActivity ends S activity v u = neighborActivity ends S activity u v := by
  classical
  unfold neighborActivity incident
  simp_rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro e _
  by_cases huv : u = v
  · subst u
    rfl
  · simp only [Finset.mem_erase]
    split_ifs <;> simp_all

omit [DecidableEq E] in
/-- For surviving vertices deletion removes exactly the coefficient of the
deleted neighbor. -/
theorem neighborActivity_delete (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (hends : ∀ e ∈ S, (ends e).card = 2)
    (v u w : V) (huv : u ≠ v) :
    neighborActivity ends (deleteVertex ends S v) activity u w =
      if w = v then 0 else neighborActivity ends S activity u w := by
  classical
  by_cases hwv : w = v
  · subst w
    rw [neighborActivity_deleted_column, if_pos rfl]
  · rw [if_neg hwv]
    unfold neighborActivity incident deleteVertex
    simp_rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro e he
    by_cases hue : u ∈ ends e
    · by_cases hwe : w ∈ (ends e).erase u
      · have hpair := ends_eq_pair_of_mem ends e (hends e he) u w hue
          (Finset.mem_erase.mp hwe).2 (Finset.mem_erase.mp hwe).1
        have hve : v ∉ ends e := by simp [hpair, Ne.symm huv, Ne.symm hwv]
        simp [hue, hwe, hve]
      · simp [hue, hwe]
    · simp [hue]

omit [DecidableEq E] in
theorem extensionLoad_empty (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) :
    extensionLoad ends S activity v ∅ = ∑ e ∈ incident ends S v, activity e := by
  unfold extensionLoad
  apply Finset.sum_congr rfl
  intro e he
  obtain ⟨w, hwv, hew⟩ := exists_other_endpoint ends e
    (hends e (Finset.mem_filter.mp he).1) v (Finset.mem_filter.mp he).2
  simp [hew, hwv.symm, unmatched]

section FiniteVertices

variable [Fintype V]

omit [DecidableEq E] in
theorem neighborActivity_row_sum (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) :
    (∑ u, neighborActivity ends S activity v u) = ∑ e ∈ incident ends S v, activity e := by
  have h := extensionLoad_eq_weighted_unmatched ends S activity v ∅
  simp only [unmatched, Finset.biUnion_empty, Finset.notMem_empty, ↓reduceIte, mul_one] at h
  rw [← h, extensionLoad_empty ends S activity hends v]

/-- The exact monomer recursion, expressed in the neighbor-activity matrix. -/
theorem unmatchedMean_inv_recursion
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) :
    (unmatchedMean ends S activity v)⁻¹ =
      1 + ∑ u, neighborActivity ends S activity v u *
        unmatchedMean ends (deleteVertex ends S v) activity u := by
  rw [unmatchedMean_eq_partition_ratio, inv_div,
    partition_ratio_eq_expected_extension ends S activity ha hends v]
  congr 1
  have hload : extensionLoad ends S activity v =
      fun M => ∑ u, neighborActivity ends S activity v u * unmatched ends u M := by
    funext M
    exact extensionLoad_eq_weighted_unmatched ends S activity v M
  rw [hload, expectation_weighted_unmatched]

/-- The genuine unmatched probabilities satisfy the reciprocal fixed-point
equations up to additive error at most the largest edge activity. -/
theorem unmatchedMean_reciprocal_residual
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (hsimple : Set.InjOn ends (S : Set E)) (h : ℝ) (hh : 0 ≤ h)
    (hcap : ∀ e ∈ S, activity e ≤ h) (v : V) :
    |(unmatchedMean ends S activity v)⁻¹ -
      (1 + ∑ u, neighborActivity ends S activity v u *
        unmatchedMean ends S activity u)| ≤ h := by
  rw [unmatchedMean_inv_recursion ends S activity ha hends v]
  rw [add_sub_add_left_eq_sub, ← Finset.sum_sub_distrib]
  have hpoint (u : V) :
      |neighborActivity ends S activity v u *
          unmatchedMean ends (deleteVertex ends S v) activity u -
        neighborActivity ends S activity v u * unmatchedMean ends S activity u| ≤
      h * (if u = v then 0 else
        |unmatchedMean ends (deleteVertex ends S v) activity u -
          unmatchedMean ends S activity u|) := by
    by_cases huv : u = v
    · subst u
      simp [neighborActivity_self]
    · rw [if_neg huv, ← mul_sub, abs_mul,
        abs_of_nonneg (neighborActivity_nonnegative ends S activity ha v u)]
      exact mul_le_mul_of_nonneg_right
        (neighborActivity_le_cap ends S activity hends hsimple h hh hcap v u) (abs_nonneg _)
  calc
    _ ≤ ∑ u, |neighborActivity ends S activity v u *
          unmatchedMean ends (deleteVertex ends S v) activity u -
        neighborActivity ends S activity v u * unmatchedMean ends S activity u| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ u, h * (if u = v then 0 else
        |unmatchedMean ends (deleteVertex ends S v) activity u -
          unmatchedMean ends S activity u|) := Finset.sum_le_sum fun u _ => hpoint u
    _ ≤ h * (1 - unmatchedMean ends S activity v) := by
      rw [← Finset.mul_sum]
      exact mul_le_mul_of_nonneg_left
        (unmatchedMean_deletion_l1 ends S activity ha hends v) hh
    _ ≤ h := by
      have hav := (unmatchedMean_bounds ends S activity ha v).1
      nlinarith only [mul_nonneg hh hav]

end FiniteVertices

/-- Logarithm is one-Lipschitz on `[1, ∞)`, in scalar form. -/
theorem abs_log_sub_log_le_abs_sub (x y : ℝ) (hx : 1 ≤ x) (hy : 1 ≤ y) :
    |Real.log x - Real.log y| ≤ |x - y| := by
  have hxp : 0 < x := by linarith
  have hyp : 0 < y := by linarith
  have hdir : ∀ a b : ℝ, 1 ≤ a → 1 ≤ b → b ≤ a →
      Real.log a - Real.log b ≤ a - b := by
    intro a b ha hb hba
    have hap : 0 < a := by linarith
    have hbp : 0 < b := by linarith
    have hlog := Real.log_le_sub_one_of_pos (div_pos hap hbp)
    rw [Real.log_div hap.ne' hbp.ne'] at hlog
    have hdiv : a / b - 1 ≤ a - b := by
      apply (sub_le_iff_le_add).mpr
      apply (div_le_iff₀ hbp).mpr
      nlinarith only [mul_nonneg (sub_nonneg.mpr hba) (sub_nonneg.mpr hb)]
    exact hlog.trans hdiv
  by_cases hxy : y ≤ x
  · rw [abs_of_nonneg (sub_nonneg.mpr hxy),
      abs_of_nonneg (sub_nonneg.mpr (Real.log_le_log hyp hxy))]
    exact hdir x y hx hy hxy
  · have hyx : x ≤ y := le_of_not_ge hxy
    rw [abs_sub_comm (Real.log x), abs_sub_comm x,
      abs_of_nonneg (sub_nonneg.mpr hyx),
      abs_of_nonneg (sub_nonneg.mpr (Real.log_le_log hxp hyx))]
    exact hdir y x hy hx hyx

theorem unmatchedMean_log_residual [Fintype V]
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (hsimple : Set.InjOn ends (S : Set E)) (h : ℝ) (hh : 0 ≤ h)
    (hcap : ∀ e ∈ S, activity e ≤ h) (v : V) :
    |Real.log (unmatchedMean ends S activity v) +
      Real.log (1 + ∑ u, neighborActivity ends S activity v u *
        unmatchedMean ends S activity u)| ≤ 2 * h := by
  have hap := unmatchedMean_positive ends S activity ha v
  have ha1 := (unmatchedMean_bounds ends S activity ha v).2
  have hai : 1 ≤ (unmatchedMean ends S activity v)⁻¹ := by
    have hdiv : (1 : ℝ) ≤ 1 / unmatchedMean ends S activity v :=
      (le_div_iff₀ hap).mpr (by simpa only [one_mul] using ha1)
    simpa only [one_div] using hdiv
  have hd : 1 ≤ 1 + ∑ u, neighborActivity ends S activity v u *
      unmatchedMean ends S activity u := by
    have hs := Finset.sum_nonneg (s := Finset.univ) fun u _ => mul_nonneg
      (neighborActivity_nonnegative ends S activity ha v u)
      (unmatchedMean_bounds ends S activity ha u).1
    linarith
  calc
    _ = |Real.log (1 + ∑ u, neighborActivity ends S activity v u *
          unmatchedMean ends S activity u) -
        Real.log (unmatchedMean ends S activity v)⁻¹| := by rw [Real.log_inv]; congr 1; ring
    _ ≤ |(1 + ∑ u, neighborActivity ends S activity v u *
          unmatchedMean ends S activity u) - (unmatchedMean ends S activity v)⁻¹| :=
      abs_log_sub_log_le_abs_sub _ _ hd hai
    _ ≤ h := by
      rw [abs_sub_comm]
      exact unmatchedMean_reciprocal_residual ends S activity ha hends hsimple h hh hcap v
    _ ≤ 2 * h := by linarith

/-- The reference unmatched vector on a deleted graph assigns probability
one to the absent vertex and retains every other prescribed coordinate. -/
def deletedReference (q : V → ℝ) (v u : V) : ℝ := if u = v then 1 else q u

omit [DecidableEq E] in
theorem deletedReference_bounds (q : V → ℝ) (hq : ∀ u, 0 < q u ∧ q u ≤ 1) (v u : V) :
    0 < deletedReference q v u ∧ deletedReference q v u ≤ 1 := by
  unfold deletedReference
  split_ifs
  · norm_num
  · exact hq u

omit [DecidableEq E] in
theorem deleted_reference_denominator [Fintype V]
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (hends : ∀ e ∈ S, (ends e).card = 2) (q : V → ℝ) (v u : V) (huv : u ≠ v) :
    (1 + ∑ w, neighborActivity ends (deleteVertex ends S v) activity u w *
        deletedReference q v w) + neighborActivity ends S activity u v * q v =
      1 + ∑ w, neighborActivity ends S activity u w * q w := by
  classical
  have hterms : (∑ w, neighborActivity ends (deleteVertex ends S v) activity u w *
      deletedReference q v w) =
      ∑ w, if w = v then 0 else neighborActivity ends S activity u w * q w := by
    apply Finset.sum_congr rfl
    intro w _
    rw [neighborActivity_delete ends S activity hends v u w huv]
    by_cases hwv : w = v <;> simp [deletedReference, hwv]
  have hsplit : (∑ w, neighborActivity ends S activity u w * q w) =
      neighborActivity ends S activity u v * q v +
        ∑ w, if w = v then 0 else neighborActivity ends S activity u w * q w := by
    calc
      _ = ∑ w, ((if w = v then neighborActivity ends S activity u v * q v else 0) +
          (if w = v then 0 else neighborActivity ends S activity u w * q w)) := by
        apply Finset.sum_congr rfl
        intro w _
        by_cases hwv : w = v <;> simp [hwv]
      _ = _ := by rw [Finset.sum_add_distrib]; simp
  rw [hterms, hsplit]
  ring

omit [DecidableEq E] in
/-- Deleting one vertex perturbs the logarithmic fixed-point equation for
the surviving reference coordinates by at most one edge activity. -/
theorem deleted_reference_log_residual [Fintype V]
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (hsimple : Set.InjOn ends (S : Set E)) (h : ℝ) (hh : 0 ≤ h)
    (hcap : ∀ e ∈ S, activity e ≤ h)
    (q : V → ℝ) (hq : ∀ u, 0 < q u ∧ q u ≤ 1)
    (hfix : ∀ u, (q u)⁻¹ = 1 + ∑ w, neighborActivity ends S activity u w * q w)
    (v u : V) :
    |Real.log (deletedReference q v u) +
      Real.log (1 + ∑ w, neighborActivity ends (deleteVertex ends S v) activity u w *
        deletedReference q v w)| ≤ h := by
  by_cases huv : u = v
  · subst u
    simpa only [deletedReference, ↓reduceIte, neighborActivity_deleted_row, zero_mul,
      Finset.sum_const_zero, add_zero, Real.log_one, abs_zero] using hh
  · have haH : ∀ e ∈ deleteVertex ends S v, 0 ≤ activity e :=
      fun e he => ha e (deleteVertex_subset ends S v he)
    have hd : 1 ≤ 1 + ∑ w,
        neighborActivity ends (deleteVertex ends S v) activity u w * deletedReference q v w := by
      have hs := Finset.sum_nonneg (s := Finset.univ) fun w _ => mul_nonneg
        (neighborActivity_nonnegative ends (deleteVertex ends S v) activity haH u w)
        (deletedReference_bounds q hq v w).1.le
      linarith
    have hqi : 1 ≤ (q u)⁻¹ := by
      have hdiv : (1 : ℝ) ≤ 1 / q u :=
        (le_div_iff₀ (hq u).1).mpr (by simpa only [one_mul] using (hq u).2)
      simpa only [one_div] using hdiv
    have hden := deleted_reference_denominator ends S activity hends q v u huv
    rw [← hfix u] at hden
    have hc0 := mul_nonneg (neighborActivity_nonnegative ends S activity ha u v) (hq v).1.le
    have hc1 : neighborActivity ends S activity u v * q v ≤ h := by
      calc
        _ ≤ neighborActivity ends S activity u v := by
          simpa only [mul_one] using mul_le_mul_of_nonneg_left (hq v).2
            (neighborActivity_nonnegative ends S activity ha u v)
        _ ≤ h := neighborActivity_le_cap ends S activity hends hsimple h hh hcap u v
    rw [deletedReference, if_neg huv]
    calc
      _ = |Real.log (1 + ∑ w,
            neighborActivity ends (deleteVertex ends S v) activity u w *
              deletedReference q v w) - Real.log (q u)⁻¹| := by
        rw [Real.log_inv]
        congr 1
        ring
      _ ≤ |(1 + ∑ w,
            neighborActivity ends (deleteVertex ends S v) activity u w *
              deletedReference q v w) - (q u)⁻¹| :=
        abs_log_sub_log_le_abs_sub _ _ hd hqi
      _ = neighborActivity ends S activity u v * q v := by
        rw [← hden]
        have habs : ∀ x c : ℝ, 0 ≤ c → |x - (x + c)| = c := by
          intro x c hc
          rw [show x - (x + c) = -c by ring, abs_neg, abs_of_nonneg hc]
        exact habs _ _ hc0
      _ ≤ h := hc1

/-- Exact factorization of an edge marginal into its activity and two
successive monomer probabilities. -/
theorem edgeMean_eq_endpoint_product
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e) (e : E) (v w : V)
    (hew : ends e = {v, w}) :
    edgeMean ends S activity e = activity e * unmatchedMean ends S activity v *
      unmatchedMean ends (deleteVertex ends S v) activity w := by
  have hz := (partition_positive ends (deleteVertex ends S v) activity
    (fun d hd => ha d (deleteVertex_subset ends S v hd))).ne'
  rw [edgeMean, unmatchedMean_eq_partition_ratio, unmatchedMean_eq_partition_ratio,
    compatibleEdges_eq_delete_pair ends S e v w hew]
  field_simp

end SubmodularMatching.GibbsMatching
