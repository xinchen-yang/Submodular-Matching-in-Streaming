import SubmodularMatching.CapacitySignedTrace
import SubmodularMatching.JointPolytope

/-! # Normalizing the capacitated joint packing constraints in equation (23) -/

namespace SubmodularMatching.Capacity
open Finset
open scoped BigOperators
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

def slotInc (ends : E → V × V) (cap : V → ℕ) (v : V) (e : E) :=
  (cap v : ℝ)⁻¹ * Joint.incidence ends v e

def slotLoad (ends : E → V × V) (cap : V → ℕ) (u : E → ℝ) (v : V) :=
  ∑ e, slotInc ends cap v e * u e

theorem slotLoad_indicator (ends : E → V × V) (cap : V → ℕ) (O : Finset E) (v : V) :
    slotLoad ends cap (Joint.edgeIndicator O) v = (incidences ends O v).card / (cap v : ℝ) := by
  unfold slotLoad slotInc
  simp only [mul_assoc,← mul_sum]
  change _ * Joint.degree ends (Joint.edgeIndicator O) v = _
  rw [Joint.degree_indicator_card]
  rw [div_eq_inv_mul]
  rfl

/-- Variables are F = x/(p Ae) and u = Y/d. Row types respectively give normalized
per-vertex layer load, assigned-slot budget, and assigned-edge budget. -/
def capacityMatrix (ends : E → V × V) (cap : V → ℕ) (pair : E → BSlot cap × BSlot cap)
    (p d Av Bv Ae Be : ℝ) : (V ⊕ BSlot cap ⊕ E) → (E ⊕ E) → ℝ
  | .inl _, .inl _ => 0
  | .inl v, .inr e => slotInc ends cap v e
  | .inr (.inl x), .inl e => (p*Ae/Av)*Joint.incidence pair x e
  | .inr (.inl x), .inr e => (Bv*d/Av)*slotInc ends cap x.1 e
  | .inr (.inr e), .inl f => if f=e then 1 else 0
  | .inr (.inr e), .inr f => (Be*d/Ae)*(slotInc ends cap (ends e).1 f+slotInc ends cap (ends e).2 f)

theorem capacityMatrix_load (ends : E → V × V) (cap : V → ℕ) (pair : E → BSlot cap × BSlot cap)
    (p d Av Bv Ae Be : ℝ) (F u : E → ℝ) (row : V ⊕ BSlot cap ⊕ E) :
    LinearPacking.load (capacityMatrix ends cap pair p d Av Bv Ae Be) (Sum.elim F u) row =
    match row with
    | .inl v => slotLoad ends cap u v
    | .inr (.inl x) => (p*Ae/Av)*Joint.degree pair F x + (Bv*d/Av)*slotLoad ends cap u x.1
    | .inr (.inr e) => F e + (Be*d/Ae)*(slotLoad ends cap u (ends e).1+slotLoad ends cap u (ends e).2) := by
  rcases row with v|x|e <;>
    simp [LinearPacking.load,Fintype.sum_sum_type,capacityMatrix,slotLoad,Joint.degree,
      mul_sum,mul_add,add_mul,sum_add_distrib,mul_assoc,ite_mul]

/-- The attained source comparator gives a legal witness to the normalized
linear optimizer at every capacity, including vertices with zero capacity. -/
theorem capacity_comparator_feasible (ends : E → V × V) (cap : V → ℕ) (pair : E → BSlot cap × BSlot cap)
    (p d Av Bv Ae Be : ℝ) (hp : 0 < p) (hv : 0 < Av) (he : 0 < Ae) (hB : 0 ≤ Be*d)
    (O : Finset E) (hO : feasible ends cap O) (z : E → ℝ)
    (hz : ∀ e, 0 ≤ z e ∧ z e ≤ p*(Ae-Be*d*((incidences ends O (ends e).1).card/(cap (ends e).1 : ℝ)+
      (incidences ends O (ends e).2).card/(cap (ends e).2 : ℝ))))
    (hdeg : ∀ x : BSlot cap, Joint.degree pair z x ≤ Av-Bv*d*((incidences ends O x.1).card/(cap x.1 : ℝ))) :
    let t := Sum.elim (fun e => z e/(p*Ae)) (Joint.edgeIndicator O)
    (∀ c, 0 ≤ t c ∧ t c ≤ 1) ∧ ∀ r, LinearPacking.load (capacityMatrix ends cap pair p d Av Bv Ae Be) t r ≤ 1 := by
  classical
  intro t
  let D := fun v => (incidences ends O v).card / (cap v : ℝ)
  have hD v : 0 ≤ D v := div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _)
  have hD1 v : D v ≤ 1 := by
    by_cases h : cap v = 0
    · simp [D,h]
    · exact (div_le_one (by exact_mod_cast Nat.pos_of_ne_zero h : (0:ℝ)<cap v)).mpr
        (by exact_mod_cast hO v)
  have hpa := mul_pos hp he
  constructor
  · intro c
    rcases c with e|e
    · change 0 ≤ z e/(p*Ae) ∧ z e/(p*Ae) ≤ 1
      refine ⟨div_nonneg (hz e).1 hpa.le,(div_le_one hpa).mpr ?_⟩
      exact (hz e).2.trans (mul_le_mul_of_nonneg_left
        (sub_le_self _ (mul_nonneg hB (add_nonneg (hD _) (hD _)))) hp.le)
    · by_cases h : e ∈ O <;> simp [t,Joint.edgeIndicator,h]
  · intro r
    change LinearPacking.load _ (Sum.elim _ _) r ≤ 1
    rw [capacityMatrix_load]
    rcases r with v|x|e <;> dsimp only
    · exact (slotLoad_indicator ends cap O v).le.trans (hD1 v)
    · rw [slotLoad_indicator]
      have hd : Joint.degree pair (fun e => z e/(p*Ae)) x = (p*Ae)⁻¹ * Joint.degree pair z x := by
        simp only [div_eq_inv_mul, Joint.degree_scale]
      rw [hd]
      change p*Ae/Av*((p*Ae)⁻¹*Joint.degree pair z x) + Bv*d/Av*D x.1 ≤ 1
      have h : Joint.degree pair z x ≤ Av-Bv*d*D x.1 := hdeg x
      apply (le_of_mul_le_mul_right _ hv)
      field_simp [hv.ne',hp.ne',he.ne'] <;> nlinarith only [h,hp,he,mul_pos hp he]
    · rw [slotLoad_indicator,slotLoad_indicator]
      change z e/(p*Ae) + Be*d/Ae*(D (ends e).1 + D (ends e).2) ≤ 1
      have h : z e ≤ p*(Ae-Be*d*(D (ends e).1 + D (ends e).2)) := (hz e).2
      apply (le_of_mul_le_mul_right _ hpa)
      field_simp [hp.ne',he.ne'] <;> nlinarith only [h,hp,he,mul_pos hp he]

end
end SubmodularMatching.Capacity
