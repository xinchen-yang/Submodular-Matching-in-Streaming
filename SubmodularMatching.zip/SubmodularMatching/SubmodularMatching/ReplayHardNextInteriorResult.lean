import SubmodularMatching.ReplayRateLookup
import SubmodularMatching.CertificateHullConeData
import SubmodularMatching.ReplayHardNextInteriorPart00021

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

theorem checked : AppendixBoxGoal false false ⟨432, 647, 0, 1135, 0, 1135⟩ :=
  Part00021 (fun z _ => runRegion_valid quickRow quickRow_eq quickRow_boundary z)
    appendixFastConeAt_sufficient

#print axioms checked

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
