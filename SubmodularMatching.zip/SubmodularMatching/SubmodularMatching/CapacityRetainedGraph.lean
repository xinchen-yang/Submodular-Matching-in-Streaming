import SubmodularMatching.CapacitySparseOnline
import SubmodularMatching.UpperBoundGraphInput

/-! # Simple graph on the physically retained labels, in their stored order -/

namespace SubmodularMatching.Capacity
open UpperBoundAssembly
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def retainedGraph (S : SimpleEdgeStream E V) (s : List E) (hs : s.Nodup) :
    SimpleEdgeStream (↑s.toFinset) V where
  arrivals := s.attach.map (fun e => ⟨e.val,List.mem_toFinset.mpr e.property⟩)
  ends := fun e => S.ends e.val
  loopless e := S.loopless e.val
  simple _ _ he := Subtype.ext (S.simple he)
  distinct := hs.attach.map (by
    intro a b h
    apply Subtype.ext
    exact congrArg (fun x : ↑s.toFinset => x.val) h)
  complete e := List.mem_map.mpr ⟨⟨e.val,List.mem_toFinset.mp e.property⟩,by simp,rfl⟩

theorem retainedGraph_labels (S : SimpleEdgeStream E V) (s : List E) (hs : s.Nodup) :
    (retainedGraph S s hs).arrivals.map Subtype.val = s := by simp [retainedGraph,List.map_map]

end SubmodularMatching.Capacity
