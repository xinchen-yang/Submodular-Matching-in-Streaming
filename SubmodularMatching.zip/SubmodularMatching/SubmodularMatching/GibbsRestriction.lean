import SubmodularMatching.GibbsVariance

/-!
# The exact density of a restricted Gibbs matching

Deleting a vertex by restriction changes the Gibbs law by the extension
weight `1 + extensionLoad`. This is a finite combinatorial identity.
-/

namespace SubmodularMatching.GibbsMatching

open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The total relative weight of extensions that match the deleted vertex.
For an incident graph edge the inner sum contains its one other endpoint. -/
noncomputable def extensionLoad (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (v : V) (M : Finset E) : ℝ :=
  ∑ e ∈ incident ends S v, activity e *
    ∑ u ∈ (ends e).erase v, unmatched ends u M

/-- The coefficient of one neighbor's unmatched indicator in the extension
weight. For a simple graph this is the activity of its unique joining edge. -/
noncomputable def neighborActivity (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (v u : V) : ℝ :=
  ∑ e ∈ incident ends S v, if u ∈ (ends e).erase v then activity e else 0

theorem weightedObservable_congr (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (F H : Finset E → ℝ)
    (hFH : ∀ M ∈ matchings ends S, F M = H M) :
    weightedObservable ends S activity F = weightedObservable ends S activity H := by
  unfold weightedObservable
  apply Finset.sum_congr rfl
  intro M hM
  rw [hFH M hM]

theorem weightedObservable_add (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (F H : Finset E → ℝ) :
    weightedObservable ends S activity (fun M => F M + H M) =
      weightedObservable ends S activity F + weightedObservable ends S activity H := by
  simp only [weightedObservable, mul_add, Finset.sum_add_distrib]

theorem weightedObservable_sum {I : Type*} (ends : E → Finset V)
    (S : Finset E) (activity : E → ℝ) (Iset : Finset I) (F : I → Finset E → ℝ) :
    weightedObservable ends S activity (fun M => ∑ i ∈ Iset, F i M) =
      ∑ i ∈ Iset, weightedObservable ends S activity (F i) := by
  simp only [weightedObservable, Finset.mul_sum]
  rw [Finset.sum_comm]

theorem weightedObservable_const_mul (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (c : ℝ) (F : Finset E → ℝ) :
    weightedObservable ends S activity (fun M => c * F M) =
      c * weightedObservable ends S activity F := by
  simp only [weightedObservable, mul_left_comm _ c, Finset.mul_sum]

omit [DecidableEq E] in
theorem extensionLoad_eq_weighted_unmatched [Fintype V]
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (v : V) (M : Finset E) :
    extensionLoad ends S activity v M =
      ∑ u, neighborActivity ends S activity v u * unmatched ends u M := by
  classical
  unfold neighborActivity extensionLoad
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  rw [Finset.mul_sum]
  simp only [ite_mul, zero_mul]
  rw [← Finset.sum_filter]
  congr 1
  ext u
  simp

omit [DecidableEq E] in
theorem neighborActivity_nonnegative (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (ha : ∀ e ∈ S, 0 ≤ activity e) (v u : V) :
    0 ≤ neighborActivity ends S activity v u := by
  apply Finset.sum_nonneg
  intro e he
  split_ifs
  · exact ha e (Finset.mem_filter.mp he).1
  · exact le_rfl

omit [DecidableEq E] in
theorem extensionLoad_nonnegative (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (ha : ∀ e ∈ S, 0 ≤ activity e) (v : V) (M : Finset E) :
    0 ≤ extensionLoad ends S activity v M := by
  apply Finset.sum_nonneg
  intro e he
  exact mul_nonneg (ha e (Finset.mem_filter.mp he).1)
    (Finset.sum_nonneg fun u _ => (unmatched_bounds ends u M).1)

/-- Restricting to `G-v` removes the newly inserted incident edge and leaves
every compatible matching intact. -/
theorem insert_inter_deleteVertex
    (ends : E → Finset V) (S : Finset E) (v : V) (e : E)
    (hve : v ∈ ends e) (N : Finset E)
    (hN : N ∈ matchings ends (compatibleEdges ends S e)) :
    (insert e N) ∩ deleteVertex ends S v = N := by
  obtain ⟨hsub, _⟩ := (mem_matchings _ _ _).mp hN
  ext d
  simp only [Finset.mem_inter, Finset.mem_insert]
  constructor
  · rintro ⟨rfl | hd, hdH⟩
    · exact False.elim ((Finset.mem_filter.mp hdH).2 hve)
    · exact hd
  · intro hd
    have hdcomp := (mem_compatibleEdges ends S e d).mp (hsub hd)
    refine ⟨Or.inr hd, Finset.mem_filter.mpr ⟨hdcomp.1, ?_⟩⟩
    exact fun hvd => Finset.disjoint_left.mp hdcomp.2.2 hve hvd

/-- The unnormalized law of a restricted matching is tilted by its total
extension weight. -/
theorem weightedObservable_restriction
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) (F : Finset E → ℝ) :
    weightedObservable ends S activity (fun M => F (M ∩ deleteVertex ends S v)) =
      weightedObservable ends (deleteVertex ends S v) activity
        (fun N => (1 + extensionLoad ends S activity v N) * F N) := by
  classical
  rw [weightedObservable_vertex_decomposition ends S activity _ v]
  have hfirst : weightedObservable ends (deleteVertex ends S v) activity
      (fun M => F (M ∩ deleteVertex ends S v)) =
        weightedObservable ends (deleteVertex ends S v) activity F := by
    apply weightedObservable_congr
    intro M hM
    rw [Finset.inter_eq_left.mpr ((mem_matchings _ _ _).mp hM).1]
  rw [hfirst]
  have hbranch : ∀ e ∈ incident ends S v,
      weightedObservable ends (compatibleEdges ends S e) activity
        (fun N => F (insert e N ∩ deleteVertex ends S v)) =
      weightedObservable ends (deleteVertex ends S v) activity
        (fun N => (∑ u ∈ (ends e).erase v, unmatched ends u N) * F N) := by
    intro e he
    have hve := (Finset.mem_filter.mp he).2
    obtain ⟨w, hwv, hew⟩ := exists_other_endpoint ends e
      (hends e (Finset.mem_filter.mp he).1) v hve
    calc
      _ = weightedObservable ends (compatibleEdges ends S e) activity F := by
        apply weightedObservable_congr
        intro N hN
        rw [insert_inter_deleteVertex ends S v e hve N hN]
      _ = weightedObservable ends (deleteVertex ends S v) activity
          (fun N => unmatched ends w N * F N) := by
        rw [weighted_unmatched_restriction, compatibleEdges_eq_delete_pair ends S e v w hew]
      _ = _ := by simp [hew, hwv.symm]
  have hsum : (∑ e ∈ incident ends S v, activity e *
      weightedObservable ends (compatibleEdges ends S e) activity
        (fun N => F (insert e N ∩ deleteVertex ends S v))) =
      ∑ e ∈ incident ends S v, activity e *
        weightedObservable ends (deleteVertex ends S v) activity
          (fun N => (∑ u ∈ (ends e).erase v, unmatched ends u N) * F N) := by
    apply Finset.sum_congr rfl
    intro e he
    rw [hbranch e he]
  rw [hsum]
  simp only [extensionLoad, add_mul, one_mul, Finset.sum_mul,
    weightedObservable_add, weightedObservable_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro e _
  simp only [mul_assoc, weightedObservable_const_mul, Finset.sum_mul,
    weightedObservable_sum]

/-- The partition ratio is the expected extension weight. -/
theorem partition_ratio_eq_expected_extension
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) :
    partition ends S activity / partition ends (deleteVertex ends S v) activity =
      1 + expectation ends (deleteVertex ends S v) activity
        (extensionLoad ends S activity v) := by
  have h := weightedObservable_restriction ends S activity hends v (fun _ => 1)
  simp only [mul_one] at h
  have h' : partition ends S activity =
      weightedObservable ends (deleteVertex ends S v) activity
        (fun N => 1 + extensionLoad ends S activity v N) := by
    simpa only [weightedObservable, mul_one, partition] using h
  rw [h']
  change expectation ends (deleteVertex ends S v) activity _ = _
  rw [expectation_add, expectation_const]
  exact fun e he => ha e (deleteVertex_subset ends S v he)

/-- Exact law of the restriction as a density tilt of the Gibbs law after
deletion, stated for every test observable. -/
theorem expectation_restriction
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) (F : Finset E → ℝ) :
    expectation ends S activity (fun M => F (M ∩ deleteVertex ends S v)) =
      expectation ends (deleteVertex ends S v) activity
        (fun N => (1 + extensionLoad ends S activity v N) * F N) /
      (1 + expectation ends (deleteVertex ends S v) activity
        (extensionLoad ends S activity v)) := by
  rw [← partition_ratio_eq_expected_extension ends S activity ha hends v]
  have hd := (partition_positive ends (deleteVertex ends S v) activity
    (fun e he => ha e (deleteVertex_subset ends S v he))).ne'
  unfold expectation
  rw [weightedObservable_restriction ends S activity hends v]
  field_simp

end SubmodularMatching.GibbsMatching
