import SubmodularMatching.CertificatePricePartition

/-!
# Universal endpoint goals for the actual Appendix L data

These definitions expose the exact objective quantified by the source
lemma, letting different numerical checks feed the same rate-chain proof.
-/

namespace SubmodularMatching.SourceCertificate

open Streaming

noncomputable section

def appendixWeightA (mode : ℕ) (i : Bool) : ℝ :=
  vertexCapacity NumericalCertificate.degree i * (appendixRateTable.high mode : ℝ)

def appendixWeightB (mode : ℕ) (j : Bool) : ℝ :=
  vertexCapacity NumericalCertificate.degree j * (appendixRateTable.low mode : ℝ)

def appendixTarget (mode : ℕ) (i j : Bool) : ℝ :=
  NumericalCertificate.sigma * (1 + unmatched i * (appendixRateTable.high mode : ℝ) +
    unmatched j * (appendixRateTable.low mode : ℝ))

def appendixRatio (mode : ℕ) (upper : Bool) : ℝ :=
  (appendixRateTable.boundary (mode + if upper then 1 else 0) : ℝ)

/-- Local inequality of one interval endpoint in one capacity class. -/
def AppendixEndpointGoal (mode : ℕ) (upper i j : Bool) (a d : ℝ) : Prop :=
  appendixTarget mode i j ≤
    gridValue (fun x => appendixWeightA mode i * appendixPotentialTable.value i x)
      (fun y => appendixWeightB mode j * appendixPotentialTable.value j y)
      (edgeCapacity NumericalCertificate.degree i j) (appendixRatio mode upper) a d

theorem appendixWeightA_nonnegative (mode : ℕ) (hm : mode < 27648) (i : Bool) :
    0 ≤ appendixWeightA mode i := by
  have hcap : 2 * NumericalCertificate.degree ≤ 1 := by
    linarith only [NumericalCertificate.degree_bounds.2]
  rw [appendixWeightA]
  apply mul_nonneg (vertexCapacity_nonnegative _ hcap i)
  rw [← appendixRateTable_count] at hm
  have hrate := (appendixRateTable.positive_rates mode hm).le.trans
    (appendixRateTable.ordered_rates mode hm)
  exact_mod_cast hrate

theorem appendixWeightB_nonnegative (mode : ℕ) (hm : mode < 27648) (j : Bool) :
    0 ≤ appendixWeightB mode j := by
  have hcap : 2 * NumericalCertificate.degree ≤ 1 := by
    linarith only [NumericalCertificate.degree_bounds.2]
  rw [appendixWeightB]
  apply mul_nonneg (vertexCapacity_nonnegative _ hcap j)
  rw [← appendixRateTable_count] at hm
  exact_mod_cast (appendixRateTable.positive_rates mode hm).le

theorem appendixEndpointGoal_of_box (mode : ℕ) (upper i j : Bool)
    (weightA weightB penaltyA penaltyB t L R a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d)
    (hweightA : weightA ≤ appendixWeightA mode i) (hweightB : weightB ≤ appendixWeightB mode j)
    (hpenaltyA : t * appendixRatio mode upper ≤ penaltyA)
    (hpenaltyB : t * (1 - appendixRatio mode upper) ≤ penaltyB)
    (ht0 : 0 ≤ t) (htq : t ≤ edgeCapacity NumericalCertificate.degree i j)
    (hL : L ≤ weightA * appendixPotentialTable.value i a - penaltyA * a)
    (hR : R ≤ weightB * appendixPotentialTable.value j d - penaltyB * d)
    (htarget : appendixTarget mode i j ≤ L + R + t) :
    AppendixEndpointGoal mode upper i j a d :=
  source_box_dual_lower appendixPotentialTable i j _ _ _ _ _ _ _ _ _ t L R a d
    ha hd hweightA hweightB hpenaltyA hpenaltyB ht0 htq hL hR htarget

theorem appendixEndpointGoal_of_tail (mode : ℕ) (hm : mode < 27648) (upper i j : Bool)
    (x y a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d)
    (hX : appendixTarget mode i j ≤ appendixWeightA mode i * appendixPotentialTable.value i x)
    (hY : appendixTarget mode i j ≤ appendixWeightB mode j * appendixPotentialTable.value j y)
    (htail : x ≤ a ∨ y ≤ d) : AppendixEndpointGoal mode upper i j a d := by
  have hcap : 2 * NumericalCertificate.degree ≤ 1 := by
    linarith only [NumericalCertificate.degree_bounds.2]
  exact source_tail_lower appendixPotentialTable i j _ _ _ _ _ x y a d
    (appendixWeightA_nonnegative mode hm i) (appendixWeightB_nonnegative mode hm j)
    (edgeCapacity_nonnegative _ hcap i j) ha hd hX hY htail

/-- The endpoint statement from any sound checker supplies every local
source inequality required by the streaming rate recursion. -/
theorem actualSourceConditions_of_endpoints (tau theta gap grid : ℝ)
    (hθ : 0 < theta) (hθτ : theta ≤ tau) (hd : 0 ≤ gap) (hg : 0 < grid)
    (hgτ : grid ≤ NumericalCertificate.coordinateCap * tau)
    (hcheck : ∀ mode < 27648, ∀ upper i j a d, 0 ≤ a → 0 ≤ d →
      AppendixEndpointGoal mode upper i j a d) :
    RunSourceConditions appendixPotentialTable.sourceFunction
      (appendixPotentialConfig tau theta gap grid hθ hθτ hd hg hgτ)
      NumericalCertificate.degree NumericalCertificate.sigma (SourceRateTable.appendixCmax : ℝ) := by
  apply actualSourceConditions_of_locals tau theta gap grid hθ hθτ hd hg hgτ
  intro i j mode hm a d ha hd
  constructor
  · simpa only [AppendixEndpointGoal, gridValue, localValue, appendixTarget, appendixRatio,
      appendixWeightA, appendixWeightB, SourcePotentialTable.sourceFunction, SourceRateTable.stage,
      Bool.false_eq_true, ↓reduceIte, Nat.add_zero] using hcheck mode hm false i j a d ha hd
  · simpa only [AppendixEndpointGoal, gridValue, localValue, appendixTarget, appendixRatio,
      appendixWeightA, appendixWeightB, SourcePotentialTable.sourceFunction, SourceRateTable.stage,
      ↓reduceIte] using hcheck mode hm true i j a d ha hd

end

end SubmodularMatching.SourceCertificate
