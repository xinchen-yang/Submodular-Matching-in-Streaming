import SubmodularMatching.CapacityResidual
import SubmodularMatching.StreamingPotential
import Mathlib.Data.Fintype.Sigma
import Mathlib.Data.Fintype.BigOperators

/-! # Deterministic retained-label space on assigned slots -/

namespace SubmodularMatching.Capacity
open Finset
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

theorem incidences_summed (ends : E → V × V) (hl : ∀ e, (ends e).1 ≠ (ends e).2) (s : Finset E) :
    (∑ v, (incidences ends s v).card) = 2 * s.card := by
  have h := endpoint_sum_by_vertex ends hl s (fun _ => 1)
  simp only [one_add_one_eq_two, sum_const, nsmul_eq_mul, mul_one, ← Nat.cast_sum] at h
  exact_mod_cast (by linarith : (∑ v, (incidences ends s v).card : ℕ) = (2 : ℝ) * s.card)

theorem saturated_for_outside (ends : E → V × V) (cap : V → ℕ) (K : Finset E)
    (hk : feasible ends cap K) (hm : ∀ s, feasible ends cap s → s.card ≤ K.card)
    (e : E) (he : e ∉ K) : ∃ v, touches ends v e ∧ cap v ≤ (incidences ends K v).card := by
  by_contra! h
  have hh : feasible ends cap (insert e K) := by
    intro v
    by_cases ht : touches ends v e
    · have hc := h v ht
      have hne : e ∉ incidences ends K v := fun h => he (mem_filter.mp h).1
      simpa [incidences, ht, filter_insert, hne, show e ∉ K.filter (touches ends v) from hne]
        using Nat.succ_le_of_lt hc
    · simpa [incidences,ht,filter_insert] using hk v
  have h' := hm (insert e K) hh
  simp [card_insert_of_notMem he] at h'

/-- The same bound on retained *labels* holds for an arbitrary assignment of one
copy per label, even when the stored labels themselves do not form a b-matching. -/
theorem stored_labels_card (ends : E → V × V) (hl : ∀ e, (ends e).1 ≠ (ends e).2)
    (cap : V → ℕ) (K S : Finset E) (hk : feasible ends cap K)
    (hm : ∀ s, feasible ends cap s → s.card ≤ K.card)
    (left : (e : E) → Fin (cap (ends e).1)) (right : (e : E) → Fin (cap (ends e).2))
    (I : ℕ)
    (hi : ∀ (x : Σ v, Fin (cap v)), (S.filter (fun e =>
      x = ⟨(ends e).1,left e⟩ ∨ x = ⟨(ends e).2,right e⟩)).card ≤ I) :
    S.card ≤ (1 + 2 * I) * K.card := by
  classical
  let C := univ.filter fun v => cap v ≤ (incidences ends K v).card
  let X : Finset (Σ v, Fin (cap v)) := C.sigma fun _ => univ
  have hcard : X.card ≤ 2 * K.card := by
    change (C.sigma (fun v => (univ : Finset (Fin (cap v))))).card ≤ _
    rw [card_sigma]
    simp only [card_univ,Fintype.card_fin]
    calc
      _ ≤ ∑ v ∈ C, (incidences ends K v).card := sum_le_sum fun v hv => (mem_filter.mp hv).2
      _ ≤ ∑ v, (incidences ends K v).card := sum_le_univ_sum_of_nonneg fun _ => Nat.zero_le _
      _ = _ := incidences_summed ends hl K
  let R := S \ K
  let a (e : E) : Σ v, Fin (cap v) := ⟨(ends e).1,left e⟩
  let b (e : E) : Σ v, Fin (cap v) := ⟨(ends e).2,right e⟩
  let charged (e : E) := if (a e).1 ∈ C then a e else b e
  have hchoice (e : E) : charged e = a e ∨ charged e = b e := by
    by_cases h : (a e).1 ∈ C <;> simp [charged,h]
  have hmap : Set.MapsTo charged (↑R) (↑X) := by
    intro e he
    obtain ⟨v,ht,hs⟩ := saturated_for_outside ends cap K hk hm e (mem_sdiff.mp he).2
    have hv : v ∈ C := mem_filter.mpr ⟨mem_univ _,hs⟩
    by_cases ha : (a e).1 ∈ C
    · simp [charged, ha, X]
    · have hb : (b e).1 ∈ C := by
        rcases ht with rfl | rfl
        · exact False.elim (ha hv)
        · exact hv
      simp [charged, ha, X, hb]
  have hR : R.card ≤ X.card * I := by
    rw [card_eq_sum_card_fiberwise hmap]
    calc
      _ ≤ ∑ _x ∈ X, I := by
        apply sum_le_sum
        intro x _
        refine (card_le_card ?_).trans (hi x)
        intro e he
        obtain ⟨hr,heq⟩ := mem_filter.mp he
        exact mem_filter.mpr ⟨(mem_sdiff.mp hr).1,heq ▸ hchoice e⟩
      _ = _ := by simp
  have hk' : (S ∩ K).card ≤ K.card := card_le_card inter_subset_right
  have part := card_sdiff_add_card_inter S K
  have hb := hR.trans (Nat.mul_le_mul_right I hcard)
  change (S \ K).card ≤ _ at hb
  nlinarith only [hk',part,hb]

end
end SubmodularMatching.Capacity
