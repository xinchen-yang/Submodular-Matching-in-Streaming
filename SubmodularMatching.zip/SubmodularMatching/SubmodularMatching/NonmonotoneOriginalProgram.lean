import SubmodularMatching.NonmonotoneEffectiveProgram

/-! The signed program under the paper's original capacities and set oracle. -/
namespace SubmodularMatching.AppendixM
open Capacity UpperBoundAssembly Streaming GibbsSampler Finset
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

def signedOriginalOutputs (S : SimpleEdgeStream E V) (b : V → ℕ)
    (f : Finset E → ℝ) (δ : ℝ)
    (rounding : ℕ → ℝ → SparseSlots (Admissible S b) (effectiveCapacity b) →
      CandidateLaw (Finset (Admissible S b))) : CandidateLaw (Finset E) × CandidateLaw (Finset E) :=
  let q := signedEffectiveOutputs (admissibleStream S b) (effectiveCapacity b)
    (effectiveCapacity_pos b) (fun A => f (originalLabels S b A)) δ rounding
  (q.1.map (originalLabels S b), q.2.map (originalLabels S b))

theorem signed_original_quality (S : SimpleEdgeStream E V) (b : V → ℕ)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hn : ∀ a,0≤f a) (M : Finset E)
    (hM : Capacity.feasible S.ends b M) (hmax : ∀ a, Capacity.feasible S.ends b a → f a≤f M)
    (δ : ℝ) (hd : 0<δ)
    (rounding : ℕ → ℝ → SparseSlots (Admissible S b) (effectiveCapacity b) →
      CandidateLaw (Finset (Admissible S b)))
    (hfeasible : ∀ J τ st, ∀ a∈(rounding J τ st).outcomes,
      Capacity.feasible (admissibleStream S b).ends (effectiveCapacity b) a)
    (hquality : ∀ C : Finset (Admissible S b), originalLabels S b C = M →
      RoundingGuarantee (admissibleStream S b) (effectiveCapacity b)
        (fun a => f (originalLabels S b a)) C (sourceFailureBudget δ) rounding) :
    let p := signedOriginalOutputs S b f δ rounding
    (∀ a∈p.1.outcomes, Capacity.feasible S.ends b a) ∧
    (∀ a∈p.2.outcomes, Capacity.feasible S.ends b a) ∧
      f M/(4727/1000) ≤ expected p.1.outcomes p.1.mass f ∧ failureMass p.2 f (f M/(4727/1000)) ≤ δ := by
  classical
  obtain ⟨T,hT,ht,hm⟩ := original_optimum_lifts S b f M hM hmax
  let R := admissibleStream S b
  let f' := fun a => f (originalLabels S b a)
  have hh := signed_effective_quality R (effectiveCapacity b) (effectiveCapacity_pos b) f'
    (positive_objective_submodular S.ends (clipped b) f hf)
    (fun a => hn _) T ht hm δ hd rounding hfeasible (hquality T hT)
  let q := signedEffectiveOutputs R (effectiveCapacity b) (effectiveCapacity_pos b) f' δ rounding
  have hfeas (law : CandidateLaw (Finset (Admissible S b)))
      (legal : ∀ a∈law.outcomes, Capacity.feasible R.ends (effectiveCapacity b) a) :
      ∀ a∈(law.map (originalLabels S b)).outcomes, Capacity.feasible S.ends b a := by
    intro a ha
    obtain ⟨a',hm,rfl⟩ := mem_image.mp ha
    exact (effective_feasible_iff S b _).mp (legal a' hm)
  simp only [signedOriginalOutputs]
  refine ⟨hfeas q.1 hh.1,hfeas q.2 hh.2.1,?_,?_⟩
  · rw [CandidateLaw.map_expected]
    simpa only [f',hT,Function.comp_apply] using
      (show f M/(4727/1000) ≤ expected q.1.outcomes q.1.mass f' from by
        have hv := hh.2.2.1
        change (1000/4727)*f (originalLabels S b T) ≤ _ at hv
        rw [hT] at hv
        linarith only [hv])
  · unfold failureMass
    rw [CandidateLaw.map_expected]
    have hp := hh.2.2.2
    change failureMass q.2 f' (f (originalLabels S b T)/(4727/1000)) ≤ δ at hp
    rw [hT] at hp
    exact hp

end
end SubmodularMatching.AppendixM
