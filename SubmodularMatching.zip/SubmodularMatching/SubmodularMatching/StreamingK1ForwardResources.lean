import SubmodularMatching.StreamingK1Resources
import SubmodularMatching.StreamingOnlineAppendixWorkspace

/-! # Actual forward source state on an arbitrary Appendix K rational instance -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming SourceCertificate

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- At every prefix reached by the exact rational word execution, there is
one header per active guess and a sparse row for each stored edge or
touched vertex. This bound is independent of estimate accuracy. -/
theorem k1SourceExecution_rows_le (R : SourceRateTable) (k : ℕ) (hk : 8 < k)
    (p : ℚ) (hp : 0 < p) (hp1 : (p : ℝ) ≤ 1) (minimum : ℝ) (hmin : 0 < minimum)
    (hlow : ∀ i < R.count, minimum ≤ (R.low i : ℝ)) (hgrowth : minimum * (p : ℝ) ≤ 1)
    (edges : ℕ → E) (ends : E → V × V)
    (oracle : Finset E → ℚ) (n arrivals : ℕ) (hn : 2 ≤ n) (ha : arrivals ≤ n ^ 2)
    (hf : IsSubmodular (fun A => (oracle A : ℝ))) (hm : IsMonotone (fun A => (oracle A : ℝ)))
    (hzero : (oracle ∅ : ℝ) = 0) {N : ℕ} (hN : 0 < N) (ρ : SourceWordExecution N)
    (stop : ℕ) (hstop : stop ≤ arrivals) (allEdges M : Finset E)
    (hunique : ∀ i < stop, ∀ j < stop, edges i = edges j → i = j)
    (hin : ∀ i < stop, edges i ∈ allEdges) (hloop : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet ends) A → A.card ≤ M.card) :
    let P := k1ScheduledSource R edges ends (fun A => (oracle A : ℝ)) n arrivals k hn ha hk p hp hp1
      minimum hmin hlow hgrowth hf hm hzero
    let G := k1OnlineGrid R n k p
    let e : ℚ := 2 / (k : ℚ)
    let W := (n : ℚ) / e
    let w := (n + 1).log2 + 1
    let I := k1IncidenceBound R k hk p hp minimum hmin hlow hgrowth
    let st := runOnlineStreamForward G ends W e P.span n oracle
      (dyadicThreshold p P.bits) N edges (P.wordStream ρ.words) stop
    ρ ∈ (sourceExecution P N oracle p).outcomes →
    st.archiveRows + st.instances.length ≤ (6 * M.card * I * w + 1) * ((3 + k.log2) * w) := by
  intro P G e W w I st hρ
  have he : (e : ℝ) = P.epsilon := by
    change (((2 : ℚ) / (k : ℚ) : ℚ) : ℝ) = 2 / (k : ℝ)
    push_cast
    rfl
  have hw : (W : ℝ) = P.width := by
    change (((n : ℚ) / e : ℚ) : ℝ) = _
    push_cast
    rw [he]
    rfl
  have hwspan : W ≤ 2 ^ P.span := by
    have hr : (W : ℝ) ≤ 2 ^ P.span := hw.symm ▸ P.width_bound
    exact_mod_cast hr
  have hepos : 0 < e := by
    have hh : (0 : ℝ) < (e : ℝ) := he.symm ▸ P.epsilon_pos
    exact_mod_cast hh
  have he1 : e ≤ 1 := by
    have hh : (e : ℝ) ≤ 1 := he.trans_le ((k1Epsilon_bounds k hk).2.le.trans (by norm_num))
    exact_mod_cast hh
  have hone : 1 ≤ W := by
    have hv : (1 : ℚ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
    change (1 : ℚ) ≤ (n : ℚ) / e
    exact (le_div_iff₀ hepos).2 (by simpa only [one_mul] using he1.trans hv)
  have hG (τ : ℝ) (hτ : 0 < τ) : G.Matches (P.config τ) :=
    k1OnlineGrid_matches R n k hn hk p hp minimum hmin hlow hgrowth τ hτ
  have hlegal := sourceExecution_legal P N oracle p ρ hρ
  have hread : ∀ t < P.calls.length, P.HasWordBatch oracle p ρ.batches t := by
    intro t ht
    obtain ⟨draw, _, htrue⟩ := hlegal t ht
    exact ⟨draw, htrue⟩
  have hc := P.runOnlineStream_eq_wordTape_of_read G W e p oracle rfl
    hone hwspan hw he hG ρ.batches ρ.words hlegal stop hstop
  have hc' : st = runOnlineIndexed G P.ends W P.span (fun i => oracle {P.edges i}) P.edges
      (P.tapeIndex ρ.batches) stop := by
    unfold st
    rw [runOnlineStreamForward_eq]
    exact hc
  have hrows := P.online_snapshot_archiveRows_bound G W p oracle rfl hone hwspan hw hG
    ρ.batches stop hstop hN hread hunique (I * w) allEdges M hin hloop hMsub hM hmax
    (k1GuessConfig_incidence_le R k hk p hp minimum hmin hlow hgrowth n hn)
  have hheaders : st.instances.length ≤ P.span + 1 := runOnlineStreamForward_instance_count_le
    G ends W e P.span n oracle (dyadicThreshold p P.bits) N edges (P.wordStream ρ.words) stop
  have hspan : P.span + 1 ≤ (3 + k.log2) * w := k1GuessSpan_le n k
  calc
    _ ≤ 3 * (2 * M.card * (I * w) * (P.span + 1)) + (P.span + 1) :=
      Nat.add_le_add (hc'.symm ▸ hrows) hheaders
    _ = (6 * M.card * I * w + 1) * (P.span + 1) := by ring
    _ ≤ _ := Nat.mul_le_mul_left _ hspan

end SubmodularMatching.UpperBoundAssembly
