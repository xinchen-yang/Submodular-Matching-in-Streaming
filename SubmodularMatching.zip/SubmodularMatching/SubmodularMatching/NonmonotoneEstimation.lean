import SubmodularMatching.NonmonotoneSampledCharge
import SubmodularMatching.StreamingAccuracyHoeffding

/-! Signed marginal range, dyadic sampling bias and concentration on a fixed transcript. -/

namespace SubmodularMatching.Streaming
open scoped BigOperators
open MeasureTheory ProbabilityTheory

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem signed_sample_range (f : Finset E → ℝ) (hf : IsSubmodular f) (hn : ∀ A, 0 ≤ f A)
    (A : Finset E) (e : E) (tau : ℝ) (ht : 0 ≤ tau) (h0 : f ∅ ≤ tau)
    (ha : ∀ x ∈ A, f {x} ≤ tau) (he : f {e} ≤ tau) :
    -((A.card : ℝ) + 1) * tau ≤ marginal f e A ∧ marginal f e A ≤ tau := by
  have hA := signed_disjoint_singleton_charge f hf (hn ∅) ∅ A (by simp)
  simp only [Finset.empty_union] at hA
  have hb := Finset.sum_le_sum (s := A) (fun x hx => ha x hx)
  simp only [Finset.sum_const, nsmul_eq_mul] at hb
  constructor
  · unfold marginal
    nlinarith only [hA, hb, h0, hn (A ∪ {e})]
  · by_cases h : e ∈ A
    · simpa [marginal, Finset.union_eq_left.mpr (Finset.singleton_subset_iff.mpr h)] using ht
    · have hu := diminishing_returns f hf ∅ A e (Finset.empty_subset _) h
      simp only [Finset.empty_union] at hu
      unfold marginal
      linarith [hn ∅]

private theorem restrict_product (edges : ℕ → E) (q : ℕ → ℝ) (G : Finset E) (n : ℕ)
    (hin : ∀ j < n, edges j ∈ G) (F : Finset E → ℝ) :
    bernoulliExpectation edges q (fun A => F (A ∩ G)) n = bernoulliExpectation edges q F n := by
  induction n generalizing F with
  | zero => simp
  | succ n ih =>
    have hi := fun j (hj : j < n) => hin j (Nat.lt_succ_of_lt hj)
    have ha (A : Finset E) : (A ∪ {edges n}) ∩ G = (A ∩ G) ∪ {edges n} := by
      ext e
      simp only [Finset.mem_inter, Finset.mem_union, Finset.mem_singleton]
      constructor
      · rintro ⟨he|he,hg⟩
        · exact Or.inl ⟨he,hg⟩
        · exact Or.inr he
      · rintro (⟨he,hg⟩|rfl)
        · exact ⟨Or.inl he,hg⟩
        · exact ⟨Or.inr rfl,hin n (Nat.lt_succ_self n)⟩
    simp only [bernoulliExpectation_succ, ha, ih hi F, ih hi (fun A => F (A ∪ {edges n}))]

theorem product_restrict_support (edges : ℕ → E) (q : ℕ → ℝ) (G : Finset E) (n : ℕ)
    (hin : ∀ j < n, edges j ∈ G) (F : Finset E → ℝ) :
    bernoulliExpectation edges q (fun A => F (A ∩ G)) n = bernoulliExpectation edges q F n :=
  restrict_product edges q G n hin F

theorem signed_bitTraceWeight_error (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (f : Finset E → ℝ) (bits i : ℕ) (G : Finset E)
    (hp : C.p ≤ 1) (hf : IsSubmodular f) (hn : ∀ A, 0 ≤ f A)
    (h0 : f ∅ ≤ C.tau) (hs : ∀ e ∈ G, f {e} ≤ C.tau)
    (hi : ∀ j ≤ i, (input j).1 ∈ G) :
    |traceWeight C ends input f i - bitTraceWeight C ends input f bits i| ≤
      i * (1 / (2 : ℝ)^bits) * (((G.card : ℝ) + 2) * C.tau) := by
  let edge := fun j => (input j).1
  let H := marginal f (edge i)
  let a := ((G.card : ℝ) + 1) * C.tau
  let F := fun A : Finset E => H (A ∩ G) + a
  have ht := C.theta_pos.le.trans C.theta_le_tau
  have hbit := bitProbability_bounds C.p_pos.le bits
  have h := bernoulliExpectation_probability_gap edge (bitTraceProbability C ends input bits)
    (traceProbability C ends input) F i (((G.card : ℝ) + 2) * C.tau) (1 / 2^bits)
    (by positivity) (fun j _ => by
      unfold bitTraceProbability traceProbability
      split_ifs
      · exact ⟨hbit.1, hbit.2.1, hp, hbit.2.2.le⟩
      · exact ⟨le_rfl, le_rfl, zero_le_one, by simp⟩) (fun A => by
        have hA := signed_sample_range f hf hn (A ∩ G) (edge i) C.tau ht h0
          (fun e he => hs e (Finset.mem_inter.mp he).2) (hs _ (hi i le_rfl))
        have hcard : ((A ∩ G).card : ℝ) ≤ G.card := by exact_mod_cast
          (Finset.card_le_card (Finset.inter_subset_right : A ∩ G ⊆ G))
        dsimp [F,H,a]
        constructor <;> nlinarith only [hA.1, hA.2, mul_le_mul_of_nonneg_right hcard ht])
  have heval (q : ℕ → ℝ) : bernoulliExpectation edge q F i =
      bernoulliExpectation edge q H i + a := by
    unfold F
    rw [bernoulliExpectation_add, bernoulliExpectation_const, restrict_product]
    exact fun j hj => hi j hj.le
  rw [heval, heval, add_sub_add_right_eq_sub] at h
  exact h

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {N : ℕ} {X : Fin N → Ω → ℝ}

/-- Conditional signed concentration for the rounded accumulator; the sampling
range and finite-bit hypothesis are explicit, allowing arbitrary precision. -/
theorem signed_estimate_failure (hind : iIndepFun X μ) (hX : ∀ j, Measurable (X j))
    (lo hi d w mean : ℝ) (hd : 0 < d) (hN : 0 < N)
    (hbounded : ∀ j, ∀ᵐ ω ∂μ, X j ω ∈ Set.Icc lo hi)
    (hmean : ∀ j, μ[X j] = mean) (hbias : |w - mean| ≤ d/64) :
    μ.real {ω | ¬(w-d ≤ sourceAverage d (fun j => X j ω) ∧
      sourceAverage d (fun j => X j ω) ≤ w+d)} ≤
      2 * Real.exp (-(2 * N * (d/2)^2) / (hi-lo)^2) := by
  let Y := fun (j : Fin N) ω => X j ω - lo
  have hy : iIndepFun Y μ := by
    simpa only [Y, Function.comp_def] using
      hind.comp (γ := fun _ => ℝ) (fun _ x => x-lo) (fun _ => by fun_prop)
  have hymean j : μ[Y j] = mean - lo := by
    have hib : Integrable (X j) μ :=
      MeasureTheory.Integrable.of_mem_Icc lo hi (hX j).aemeasurable (hbounded j)
    simp [Y, integral_sub hib (integrable_const _), hmean]
  have ht := sample_mean_two_tails hy (fun j => (hX j).sub_const lo) (hi-lo) (mean-lo) (d/2)
    (by positivity) hN (fun j => by
      filter_upwards [hbounded j] with ω hw
      exact ⟨sub_nonneg.mpr hw.1, sub_le_sub_right hw.2 _⟩) hymean
  apply (measureReal_mono (s₂ := _) ?_).trans ht
  intro ω hw
  change d / 2 < |(∑ j, Y j ω) / (N : ℝ) - (mean-lo)|
  have hNr : (N : ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  have hid : (∑ j, Y j ω) / (N : ℝ) - (mean-lo) = rawSampleAverage (fun j => X j ω) - mean := by
    simp only [Y, rawSampleAverage, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
      Fintype.card_fin, nsmul_eq_mul]
    field_simp
    ring
  rw [hid]
  exact lt_of_not_ge (fun h => hw (sourceAverage_accuracy_of_deviation _ _ _ _ hd hN hbias h))

end SubmodularMatching.Streaming
