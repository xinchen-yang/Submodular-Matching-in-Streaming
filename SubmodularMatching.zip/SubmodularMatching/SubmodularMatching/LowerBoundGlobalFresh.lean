import SubmodularMatching.LowerBoundGlobalPhaseContext

/-! # A sampled base pair cannot enter through another arrival block -/

namespace SubmodularMatching.LowerBoundGlobal

open LowerBoundAssembly Information

noncomputable section

variable {p N P t H : ℕ} {C : Type*} [DecidableEq C]

namespace PhaseContext

omit [DecidableEq C] in
theorem before_fresh [Nonempty (Fin t)] (b : BlueprintExpansion N P t H) (q : ℝ)
    (ctx : PhaseContext p N P t C) (hpast : 0 < pastPhaseLaw b q ctx.phase ctx.history)
    (e : LiftEdge (Fin N) (Fin N) C) (he : CloneLift.basePair e ∈ ctx.oldUniverse b) :
    embedOriginalClone ctx.stage e ∉ ctx.before b := by
  intro ha
  rcases List.mem_append.mp ha with hs | hp
  · obtain ⟨j, _, hj⟩ := List.mem_flatMap.mp hs
    have htag : ctx.stage = j.val := ((mem_stageStream _ _ _ _).mp hj).1
    exact ne_of_lt ((mem_stagesBefore _ _).mp j.property) htag.symm
  · have hb := ((mem_stageStream _ _ _ _).mp hp).2.1
    change embedBase (CloneLift.basePair e) ∈ ctx.priorBaseOrder at hb
    obtain ⟨j, _, hj⟩ := List.mem_flatMap.mp hb
    have hlt := (mem_stagesBefore _ _).mp j.property
    have hsub := (phaseRetainedMass_supported b q (representative ctx.phase ctx.history.1)
      j.val _ (pastPhaseLaw_pos b q ctx.phase ctx.history hpast ⟨j.val, hlt⟩)).1
    have hdis := b.phases_disjoint (representative ctx.phase ctx.history.1) (ne_of_gt hlt)
    rw [expansionBlock, List.mem_map] at hj
    obtain ⟨base, hb, heq⟩ := hj
    have hmem : CloneLift.basePair e ∈
        b.phases (representative ctx.phase ctx.history.1) j.val := by
      rw [← embedBase.injective heq]
      exact hsub (Finset.mem_toList.mp hb)
    exact (Finset.disjoint_left.mp hdis) he hmem

omit [DecidableEq C] in
theorem after_fresh [Nonempty (Fin t)] (b : BlueprintExpansion N P t H) (q : ℝ)
    (ctx : PhaseContext p N P t C) (next : ctx.Draw)
    (hnext : 0 < nextPhaseLaw b q ctx.phase ctx.history.1 next)
    (e : LiftEdge (Fin N) (Fin N) C) (he : CloneLift.basePair e ∈ ctx.oldUniverse b) :
    embedOriginalClone ctx.stage e ∉ ctx.after b next := by
  intro ha
  rcases List.mem_append.mp ha with hf | hs
  · have hb := ((mem_stageStream _ _ _ _).mp hf).2.1
    change embedBase (CloneLift.basePair e) ∈ ctx.nextBaseOrder b next at hb
    let J' := unexposedTupleEquiv ctx.phase ctx.history.1 next.1
    rcases List.mem_append.mp hb with hl | hl
    · obtain ⟨j, _, hj⟩ := List.mem_flatMap.mp hl
      have hgt := (mem_stagesAfter _ _).mp j.property
      have hsub := (phaseRetainedMass_supported b q J' j.val _
        (nextPhaseLaw_pos b q ctx.phase ctx.history.1 next hnext ⟨j.val, hgt⟩)).1
      have hdis := blueprint_phase_disjoint_others b ctx.phase
        (representative ctx.phase ctx.history.1) J' j.val (ne_of_gt hgt) _ hsub
      obtain ⟨base, hb, heq⟩ := List.mem_map.mp hj
      exact (Finset.disjoint_left.mp hdis) (Finset.mem_map.mpr ⟨_, he, rfl⟩)
        (Finset.mem_map.mpr ⟨base, Finset.mem_toList.mp hb, heq⟩)
    · have hdis := blueprint_phase_disjoint_leaves b ctx.phase
        (representative ctx.phase ctx.history.1) J'
      exact (Finset.disjoint_left.mp hdis) (Finset.mem_map.mpr ⟨_, he, rfl⟩)
        (Finset.mem_toList.mp hl)
  · obtain ⟨j, _, hj⟩ := List.mem_flatMap.mp hs
    have htag : ctx.stage = j.val := ((mem_stageStream _ _ _ _).mp hj).1
    exact ne_of_gt ((mem_stagesAfter _ _).mp j.property) htag.symm

end PhaseContext

end

end SubmodularMatching.LowerBoundGlobal
