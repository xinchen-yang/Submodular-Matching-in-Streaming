import SubmodularMatching.CapacitySelectedConfidence
import SubmodularMatching.CapacityRealBankVerified

/-! The conditional finite source law supplies the selected physical payload
and its two certificates with failure mass at most 1/J. -/
namespace SubmodularMatching.AppendixM
open Capacity Streaming Streaming.OracleQuery UpperBoundAssembly SourceCertificate Finset
noncomputable section
attribute [local irreducible] rescaledRateTable
variable {E V : Type*} [Fintype E] [DecidableEq E] [Nonempty E] [Fintype V] [DecidableEq V]

theorem selected_pass_confidence (S : SimpleEdgeStream E V) (cap : V → ℕ)
    (hpos : ∀ e, 0<cap (S.ends e).1 ∧ 0<cap (S.ends e).2)
    (f : Finset E → ℝ) (edges : ℕ → E) (other : ℕ → ℕ → ℕ → ℕ → ℕ)
    (k j J : ℕ) (hJ : 0<J) (M : Finset E) (initial : SourceWordTape)
    (hk : k ≤ (Fintype.card V)^2) (hf : IsSubmodular f) (hn : ∀ A, 0≤f A)
    (hinj : ∀ i < k, ∀ l < k, edges i=edges l → i=l) (hM : Capacity.feasible S.ends cap M)
    (hMsub : M ⊆ (range k).image edges) :
    let v := (Fintype.card V)^2
    let W := (guessWidth v:ℝ)
    let b := signedBirth W (f ∅) (fun i => f {edges i}) j k
    let P : WordWindow E V := ⟨S.ends,cap,hpos,f,edges,other,v,k,j,b⟩
    let K := sourceWordScale v (v^2)
    let N := batchCount K J
    let bits := batchBits K
    let p := P.law N bits P.gap initial
    guessActive W (guessAnchor W (RealOracle.edgeClock edges f) (k+1))
      (singletonMaximum (RealOracle.edgeClock edges f) (k+1)) j →
    (∑ z ∈ p.outcomes, if z.2 then 0 else p.mass z) ≤ 1/(J:ℝ) ∧
      ∀ z ∈ p.outcomes, z.2=true →
      let draw := tapeDraw z.1 b j other
      let st := P.state N bits P.calls z.1
      (RealOracle.forwardBank S.ends cap hpos v N bits f edges draw k).lookup j = some st ∧
        ∃ ht : 0 < P.scale, ∃ (l : (e : E) → Fin (cap (S.ends e).1))
            (r : (e : E) → Fin (cap (S.ends e).2)),
          let C := signedConfig v (capacityScheduleVertices S) P.scale ht
          let pair := slotPair S.ends cap l r
          let input := sampledInput P.gap (fun i => edges (b+i)) (fun i => P.raw N bits i z.1)
          (∀ a ∈ st.assigned, a.2 = pair a.1) ∧ CapacityPassWitness C S.ends cap pair input P.calls
            (st.machine.edges.map Prod.fst).toFinset M f streamTolerance := by
  intro v W b P K N bits p ha
  have hv : 2≤v := capacityScheduleVertices S
  have hk' : k≤v^2 := hk.trans (by change v≤v^2; nlinarith)
  obtain ⟨hbad,hgood⟩ := P.selected_source_confidence J hJ hv hk' hf hn ha initial
  refine ⟨hbad,?_⟩
  intro z hz hzgood draw st
  have hgood' := hgood z hz hzgood
  have hN : 0<N := by dsimp only [N,batchCount]; omega
  obtain ⟨hw,hw'⟩ := guessWidth_bounds v hv
  have hw1 : (1:ℝ)≤W := by dsimp only [W]; exact_mod_cast (le_trans (by norm_num : (1:ℚ)≤2) hw)
  have hw2 : W ≤ 2^guessSpan v := by dsimp only [W]; exact_mod_cast hw'
  have hactive := (RealSource.runOnlineEpoch_active_iff W (guessSpan v) (RealOracle.edgeClock edges f)
    hw1 hw2 (k+1) j).mpr ha
  have hm (i : ℕ) : draw (b+i) j = z.1 i := by simp [draw,tapeDraw]
  have hr (i : ℕ) : (fun r : Fin N => RealOracle.bankRaw (P.state N bits i z.1) f (edges (b+i))
      bits (draw (b+i) j) r) = P.raw N bits i z.1 := by rw [hm]; rfl
  let xs := fun i (r : Fin N) => RealOracle.bankRaw (P.state N bits i z.1) f (edges (b+i)) bits
    (draw (b+i) j) r
  let conclusion (Y : ℕ → Fin N → ℝ) : Prop :=
    (RealOracle.forwardBank S.ends cap hpos v N bits f edges draw k).lookup j = some st ∧
      ∃ ht : 0 < P.scale, ∃ (l : (e : E) → Fin (cap (S.ends e).1))
          (r : (e : E) → Fin (cap (S.ends e).2)),
        let C := signedConfig v (capacityScheduleVertices S) P.scale ht
        let pair := slotPair S.ends cap l r
        let input := sampledInput P.gap (fun i => edges (b+i)) Y
        (∀ a ∈ st.assigned, a.2 = pair a.1) ∧ CapacityPassWitness C S.ends cap pair input P.calls
          (st.machine.edges.map Prod.fst).toFinset M f streamTolerance
  have hh : conclusion xs := capacity_real_forward_bank_verified S cap hpos N bits hN f edges draw k j M hk hf hn
    hinj hM hMsub hactive (fun i hi => by
      change (P.Q N bits i z.1).target-P.gap ≤ sourceAverage P.gap (xs i) ∧
        sourceAverage P.gap (xs i) ≤ (P.Q N bits i z.1).target+P.gap
      rw [show xs i=P.raw N bits i z.1 from hr i]
      exact hgood' i hi)
  rw [show xs=(fun i => P.raw N bits i z.1) from funext hr] at hh
  exact hh

end
end SubmodularMatching.AppendixM
