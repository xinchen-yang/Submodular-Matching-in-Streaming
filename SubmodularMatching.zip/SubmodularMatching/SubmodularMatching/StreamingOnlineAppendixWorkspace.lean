import SubmodularMatching.StreamingOnlineAppendixRun
import SubmodularMatching.StreamingOnlineSchedulerCount
import SubmodularMatching.StreamingOnlineExecutionLaw
import SubmodularMatching.UpperBoundVertexPeak

/-! # Physical archive and guess headers of the appendix implementation -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming NumericalCertificate

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The forward streaming program uses one header per active guess and at
most a quadratic logarithmic number of sparse archive rows. The claim is
pointwise on all actual generated words, independent of accuracy. -/
theorem appendixSourceExecution_rows_le (edges : ℕ → E) (ends : E → V × V)
    (oracle : Finset E → ℚ) (n arrivals : ℕ) (hn : 2 ≤ n) (ha : arrivals ≤ n ^ 2)
    (hf : IsSubmodular (fun A => (oracle A : ℝ))) (hm : IsMonotone (fun A => (oracle A : ℝ)))
    (hzero : (oracle ∅ : ℝ) = 0) {N : ℕ} (hN : 0 < N) (ρ : SourceWordExecution N)
    (k : ℕ) (hk : k ≤ arrivals) (allEdges M : Finset E)
    (hunique : ∀ i < k, ∀ j < k, edges i = edges j → i = j)
    (hin : ∀ i < k, edges i ∈ allEdges) (hloop : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet ends) A → A.card ≤ M.card) :
    let P := appendixScheduledSource edges ends (fun A => (oracle A : ℝ)) n arrivals hn ha hf hm hzero
    let R := appendixOnlineGrid n
    let W := (n : ℚ) / rationalEpsilon
    let w := (n + 1).log2 + 1
    let st := runOnlineStreamForward R ends W rationalEpsilon P.span n oracle
      (dyadicThreshold rationalCoordinateCap P.bits) N edges (P.wordStream ρ.words) k
    ρ ∈ (sourceExecution P N oracle rationalCoordinateCap).outcomes →
    st.archiveRows + st.instances.length ≤
      (6 * M.card * appendixIncidenceConstant * w + 1) * (appendixGuessCountConstant * w) := by
  intro P R W w st hρ
  have he : (rationalEpsilon : ℝ) = P.epsilon := by
    change (rationalEpsilon : ℝ) = finiteError
    norm_num [rationalEpsilon, finiteError]
  have hw : (W : ℝ) = P.width := by
    change (((n : ℚ) / rationalEpsilon : ℚ) : ℝ) = _
    push_cast
    rw [he]
    rfl
  have hwspan : W ≤ 2 ^ P.span := by
    have hr : (W : ℝ) ≤ 2 ^ P.span := hw.symm ▸ P.width_bound
    exact_mod_cast hr
  have hone : 1 ≤ W := by
    have hv : (1 : ℚ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
    change 1 ≤ (n : ℚ) / rationalEpsilon
    apply (le_div_iff₀ (by norm_num [rationalEpsilon] : 0 < rationalEpsilon)).2
    norm_num [rationalEpsilon]
    exact (by norm_num : (1 / 10000000000 : ℚ) ≤ 1).trans hv
  have hR (τ : ℝ) (hτ : 0 < τ) : R.Matches (P.config τ) := appendixOnlineGrid_matches n hn τ hτ
  have hlegal := sourceExecution_legal P N oracle rationalCoordinateCap ρ hρ
  have hread : ∀ t < P.calls.length, P.HasWordBatch oracle rationalCoordinateCap ρ.batches t := by
    intro t ht
    obtain ⟨draw, _, htrue⟩ := hlegal t ht
    exact ⟨draw, htrue⟩
  have hc := P.runOnlineStream_eq_wordTape_of_read R W rationalEpsilon rationalCoordinateCap oracle rfl
    hone hwspan hw he hR ρ.batches ρ.words hlegal k hk
  have hc' : st = runOnlineIndexed R P.ends W P.span (fun i => oracle {P.edges i}) P.edges (P.tapeIndex ρ.batches) k := by
    unfold st
    rw [runOnlineStreamForward_eq]
    exact hc
  have hrows := P.online_snapshot_archiveRows_bound R W rationalCoordinateCap oracle rfl hone hwspan hw hR
    ρ.batches k hk hN hread hunique (appendixIncidenceConstant * w) allEdges M hin hloop hMsub hM hmax
    (appendixGuessConfig_incidenceLimit_le n hn)
  have hheaders : st.instances.length ≤ P.span + 1 := runOnlineStreamForward_instance_count_le
    R ends W rationalEpsilon P.span n oracle (dyadicThreshold rationalCoordinateCap P.bits)
    N edges (P.wordStream ρ.words) k
  have hspan : P.span + 1 ≤ appendixGuessCountConstant * w := appendixGuessCount_le n
  calc
    _ ≤ 3 * (2 * M.card * (appendixIncidenceConstant * w) * (P.span + 1)) + (P.span + 1) :=
      Nat.add_le_add (hc'.symm ▸ hrows) hheaders
    _ = (6 * M.card * appendixIncidenceConstant * w + 1) * (P.span + 1) := by ring
    _ ≤ _ := Nat.mul_le_mul_left _ hspan

end SubmodularMatching.UpperBoundAssembly
