import SubmodularMatching.CapacityWordScheduler
import SubmodularMatching.CapacityStoredWordQuery

/-! Per-guess size for the forward executable on every tape, including
tapes with inaccurate estimates. -/
namespace SubmodularMatching.Capacity
open Streaming AppendixM
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem slotWeight_le (cap : V → ℕ) (v N bits : ℕ) (hv : 2≤v) (hN : 0<N)
    (oracle : Finset E → ℚ) (hf : IsSubmodular (fun A => (oracle A:ℝ)))
    (hn : ∀ A, 0 ≤ (oracle A:ℝ)) (τ : ℚ) (ht : 0<τ) (e : E) (he : oracle {e} ≤ τ)
    (st : SparseSlots E cap) (draw : ℕ → ℕ → ℕ) :
    ((streamTolerance*τ/(v:ℚ)^2:ℚ):ℝ) * slotWeight v N bits oracle τ e st draw ≤ τ := by
  let gap := streamTolerance*τ/(v:ℚ)^2
  have hv0 : (0:ℚ)<v := by exact_mod_cast (by omega : 0<v)
  have hg : (0:ℝ)<(gap:ℚ) := by
    exact_mod_cast (show (0:ℚ)<gap by dsimp [gap]; positivity [show 0<streamTolerance by norm_num [streamTolerance]])
  have ht' : (0:ℝ)≤τ := by exact_mod_cast ht.le
  unfold slotWeight
  rw [OnlineInstance.weightIndex_real]
  apply (sourceWeight_signed_bounds _ _ _ hg hN ht' ?_).2
  intro r
  unfold sampleIndexedMarginal
  rw [Rat.cast_sub]
  let f := fun A : Finset E => (oracle A:ℝ)
  have he' : f {e} ≤ τ := by dsimp [f]; exact_mod_cast he
  have hAll (A : Finset E) : f (insert e A)-f A ≤ τ := by
    by_cases h : e ∈ A
    · simpa [Finset.insert_eq_of_mem h] using ht'
    · have hu := diminishing_returns f hf ∅ A e (Finset.empty_subset _) h
      simp only [Finset.union_singleton] at hu
      rw [show insert e (∅ : Finset E) = {e} by ext x; simp] at hu
      have hf0 : 0 ≤ f ∅ := hn ∅
      linarith only [hu,he',hf0]
  exact hAll _

theorem suffixRun_sparse (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0<cap (ends e).1 ∧ 0<cap (ends e).2)
    (R : GridUpdateParameters) (edges : ℕ → E) (weight : ℕ → SparseSlots E cap → ℕ)
    (b n : ℕ) :
    let F (i : ℕ) (st : SparseSlots E cap) := sparseStep ends cap hpos R st (edges i) (weight i st)
    let run := suffixRun (sparseEmpty cap) F b
    run n = sparseRun ends cap hpos R (fun i => (edges (b+i),weight (b+i) (run i))) n := by
  intro F run
  induction n with
  | zero => rfl
  | succ n ih =>
    change sparseStep ends cap hpos R (run n) (edges (b+n)) (weight (b+n) (run n)) = _
    rw [sparseRun, ← ih]

theorem active_tick_scale (W : ℚ) (span : ℕ) (values : ℕ → ℚ) (j k s : ℕ)
    (ha : guessActive W (guessAnchor W (fun i => (values i:ℝ)) k)
      (singletonMaximum (fun i => (values i:ℝ)) k) j)
    (hb : guessBirth W (fun i => (values i:ℝ)) j k < s) (hs : s ≤ k) :
    (runOnlineEpoch W span values s).scale j = (runOnlineEpoch W span values k).scale j := by
  have hx := (guess_active_since_birth W (fun i => (values i:ℝ)) j k ha hb hs).1
  have hh : ((runOnlineEpoch W span values s).anchor:ℝ) =
      ((runOnlineEpoch W span values k).anchor:ℝ) := by
    rw [(runOnlineEpoch_real W span values s).2,(runOnlineEpoch_real W span values k).2,hx]
  have he : (runOnlineEpoch W span values s).anchor = (runOnlineEpoch W span values k).anchor := by exact_mod_cast hh
  simp [OnlineEpoch.scale, he]

theorem active_edge_value (W : ℚ) (span : ℕ) (edges : ℕ → E) (oracle : Finset E → ℚ)
    (j k : ℕ) (ha : guessActive W (guessAnchor W (fun i => (edgeClock edges oracle i:ℝ)) (k+1))
        (singletonMaximum (fun i => (edgeClock edges oracle i:ℝ)) (k+1)) j)
    (i : ℕ) (hi : i<k) :
    oracle {edges i} ≤ (runOnlineEpoch W span (edgeClock edges oracle) (k+1)).scale j := by
  let v := fun l => (edgeClock edges oracle l:ℝ)
  have h := (singleton_le_maximum v (i := i+1) (k := k+1) (by omega)).trans ha.2.1
  have hs := (runOnlineEpoch_real W span (edgeClock edges oracle) (k+1)).2
  change v (i+1) ≤ _ at h
  unfold OnlineEpoch.scale
  apply (Rat.cast_le (K := ℝ)).mp
  push_cast
  rw [hs]
  exact h

end SubmodularMatching.Capacity
