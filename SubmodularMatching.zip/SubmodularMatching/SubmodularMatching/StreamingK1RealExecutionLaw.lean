import SubmodularMatching.StreamingK1RealCoupling
import SubmodularMatching.StreamingOnlineExecutionLaw

/-! # Distribution of the compact real-oracle stream -/

namespace SubmodularMatching.Streaming.RealSource

open GibbsSampler UpperBoundAssembly

noncomputable section

private theorem batches_update {N : ℕ} (ρ : SourceWordExecution N)
    (t : ℕ) (entry : (Fin N → ℝ) × (ℕ → ℕ → ℕ)) [DecidableEq ℕ] :
    SourceWordExecution.batches (Function.update ρ t entry) = Function.update ρ.batches t entry.1 := by
  funext i
  by_cases h : i = t
  · subst i
    simp only [SourceWordExecution.batches, Function.update_self]
  · simp only [SourceWordExecution.batches, Function.update_of_ne h]

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Generate the adaptive trace with a fresh product of uniform bit words
at each call. The number of columns is the current archive size. -/
def sourceExecutionFrom (P : ScheduledSource E V) (N : ℕ) (p : ℚ) :
    ℕ → ℕ → SourceWordExecution N → CandidateLaw (SourceWordExecution N)
  | 0, _, ρ => CandidateLaw.pure ρ
  | steps + 1, t, ρ => by
    classical
    let ctx := P.context t (P.history ρ.batches t)
    exact (CandidateLaw.ofMeasure (wordBatchLaw N ctx.ordered.length ctx.bits)).bind
      (fun draw => sourceExecutionFrom P N p steps (t + 1)
        (Function.update ρ t (fun j => ctx.realWordObserve p (draw j), wordBatchRead draw)))

def sourceExecution (P : ScheduledSource E V) (N : ℕ) (p : ℚ) :
    CandidateLaw (SourceWordExecution N) := sourceExecutionFrom P N p P.calls.length 0
      (fun _ => (fun _ => 0, fun _ _ => 0))

/-- Forgetting the actual words gives exactly the law of the raw tape. -/
theorem sourceExecutionFrom_batches_expected (P : ScheduledSource E V) (N : ℕ)
    (p : ℚ) (steps t : ℕ) (ρ : SourceWordExecution N)
    (test : (ℕ → Fin N → ℝ) → ℝ) :
    expected (sourceExecutionFrom P N p steps t ρ).outcomes
      (sourceExecutionFrom P N p steps t ρ).mass (test ∘ SourceWordExecution.batches) =
    expected (sourceRealWordTapeFrom P N p steps t ρ.batches).outcomes
      (sourceRealWordTapeFrom P N p steps t ρ.batches).mass test := by
  classical
  induction steps generalizing t ρ with
  | zero => rw [sourceExecutionFrom, sourceRealWordTapeFrom, CandidateLaw.pure_expected, CandidateLaw.pure_expected]; rfl
  | succ steps ih =>
    rw [sourceExecutionFrom, sourceRealWordTapeFrom, CandidateLaw.bind_expected, CandidateLaw.bind_expected]
    unfold expected
    apply Finset.sum_congr rfl
    intro draw _
    congr 1
    let ctx := P.context t (P.history ρ.batches t)
    let raw := fun j => ctx.realWordObserve p (draw j)
    let Δ := sourceExecutionFrom P N p steps (t + 1) (Function.update ρ t (raw, wordBatchRead draw))
    let δ := sourceRealWordTapeFrom P N p steps (t + 1) (Function.update ρ.batches t raw)
    change expected Δ.outcomes Δ.mass (test ∘ SourceWordExecution.batches) = expected δ.outcomes δ.mass test
    unfold Δ
    rw [ih, batches_update]

/-- The batch projection preserves support even for outcomes assigned zero mass. -/
theorem sourceExecutionFrom_batches_mem (P : ScheduledSource E V) (N : ℕ) (p : ℚ)
    (steps t : ℕ) (ρ σ : SourceWordExecution N)
    (h : σ ∈ (sourceExecutionFrom P N p steps t ρ).outcomes) :
    σ.batches ∈ (sourceRealWordTapeFrom P N p steps t ρ.batches).outcomes := by
  classical
  induction steps generalizing t ρ with
  | zero =>
    have he : σ = ρ := Finset.mem_singleton.mp h
    subst σ
    exact Finset.mem_singleton_self _
  | succ steps ih =>
    rw [sourceExecutionFrom] at h
    obtain ⟨draw, hd, hs⟩ := (CandidateLaw.mem_bind _ _ _).1 h
    rw [sourceRealWordTapeFrom]
    apply (CandidateLaw.mem_bind _ _ _).2
    refine ⟨draw, hd, ?_⟩
    have hm := ih (t + 1) _ hs
    rwa [batches_update] at hm

theorem sourceExecution_batches_mem (P : ScheduledSource E V) (N : ℕ) (p : ℚ)
    (ρ : SourceWordExecution N) (h : ρ ∈ (sourceExecution P N p).outcomes) :
    ρ.batches ∈ (sourceRealWordTape P N p).outcomes :=
  sourceExecutionFrom_batches_mem P N p P.calls.length 0 _ ρ h

/-- Each tape entry is witnessed by precisely the words stored in that
execution outcome. The kernel size depends only on the preceding rows. -/
theorem sourceExecutionFrom_legal (P : ScheduledSource E V) (N : ℕ)
    (p : ℚ) (steps t : ℕ) (ρ σ : SourceWordExecution N)
    (h : σ ∈ (sourceExecutionFrom P N p steps t ρ).outcomes) :
    (∀ j < t, σ j = ρ j) ∧ ∀ i, t ≤ i → i < t + steps →
      let ctx := P.context i (P.history σ.batches i)
      ∃ draw : WordBatch N ctx.ordered.length ctx.bits,
        σ.words i = wordBatchRead draw ∧ σ.batches i = fun j => ctx.realWordObserve p (draw j) := by
  classical
  induction steps generalizing t ρ with
  | zero =>
    have hh : σ = ρ := Finset.mem_singleton.mp h
    subst σ
    exact ⟨fun _ _ => rfl, by intro i h1 h2; omega⟩
  | succ steps ih =>
    let ctx := P.context t (P.history ρ.batches t)
    let entry := fun draw : WordBatch N ctx.ordered.length ctx.bits =>
      ((fun j => ctx.realWordObserve p (draw j)), wordBatchRead draw)
    let next := fun draw => Function.update ρ t (entry draw)
    change σ ∈ ((CandidateLaw.ofMeasure (wordBatchLaw N ctx.ordered.length ctx.bits)).bind
      (fun draw => sourceExecutionFrom P N p steps (t + 1) (next draw))).outcomes at h
    obtain ⟨draw, -, hd⟩ := (CandidateLaw.mem_bind _ _ _).1 h
    obtain ⟨hp, hw⟩ := ih (t + 1) (next draw) hd
    have hprev (j : ℕ) (hj : j < t) : σ j = ρ j := by
      rw [hp j (Nat.lt_succ_of_lt hj)]
      exact Function.update_of_ne hj.ne _ _
    refine ⟨hprev, ?_⟩
    intro j hj hlast
    by_cases he : j = t
    · subst j
      have hh := P.history_prefix_congr σ.batches ρ.batches t
        (fun i hi => congrArg Prod.fst (hprev i hi))
      dsimp only
      rw [hh]
      have hr : σ t = entry draw := (hp t (Nat.lt_succ_self t)).trans (Function.update_self _ _ _)
      exact ⟨draw, congrArg Prod.snd hr, congrArg Prod.fst hr⟩
    · exact hw j (by omega) (by omega)

/-- Every generated block is genuinely the block used by its observed
raw value, even on unsuccessful transcripts. -/
theorem sourceExecution_legal (P : ScheduledSource E V) (N : ℕ)
    (p : ℚ) (ρ : SourceWordExecution N)
    (h : ρ ∈ (sourceExecution P N p).outcomes) :
    ∀ i < P.calls.length,
      let ctx := P.context i (P.history ρ.batches i)
      ∃ draw : WordBatch N ctx.ordered.length ctx.bits,
        ρ.words i = wordBatchRead draw ∧ ρ.batches i = fun j => ctx.realWordObserve p (draw j) := by
  intro i hi
  exact (sourceExecutionFrom_legal P N p P.calls.length 0 _ ρ h).2 i
    (Nat.zero_le i) (by simpa using hi)

/-- Expected observations of the genuine sparse forward program coincide
with those of the raw-tape archives, jointly with the raw observations
and at every stopping position. -/
theorem sourceExecution_joint_online_expected
    (P : ScheduledSource E V) (R : GridUpdateParameters) (W epsilon : ℝ) (p : ℚ)
        (hW : 1 ≤ W) (hspan : W ≤ 2 ^ P.span) (hwidth : W = P.width)
    (hepsilon : epsilon = P.epsilon) (hR : ∀ tau > 0, R.Matches (P.config tau))
    (N a : ℕ) (ha : a ≤ P.arrivals) (test : (ℕ → Fin N → ℝ) → OnlineStreamState E V → ℝ) :
    let q := sourceExecution P N p
    let raw := sourceRealWordTape P N p
    expected q.outcomes q.mass (fun ρ => test ρ.batches
      (runOnlineStreamForward R P.ends W epsilon P.span P.vertices P.objective
        (dyadicThreshold p P.bits) N P.edges (P.wordStream ρ.words) a)) =
    expected raw.outcomes raw.mass (fun batches => test batches
      (runOnlineIndexed R P.ends W P.span P.value P.edges (P.tapeIndex batches) a)) := by
  dsimp only
  let replay := fun (batches : ℕ → Fin N → ℝ) => test batches
    (runOnlineIndexed R P.ends W P.span P.value P.edges (P.tapeIndex batches) a)
  calc
    _ = expected (sourceExecution P N p).outcomes (sourceExecution P N p).mass
        (replay ∘ SourceWordExecution.batches) := by
      unfold expected
      apply Finset.sum_congr rfl
      intro ρ hρ
      congr 1
      change test ρ.batches (runOnlineStreamForward R P.ends W epsilon P.span P.vertices P.objective
        (dyadicThreshold p P.bits) N P.edges (P.wordStream ρ.words) a) = replay ρ.batches
      rw [runOnlineStreamForward_eq]
      unfold replay
      apply congrArg (test ρ.batches)
      exact runOnlineStream_eq_wordTape_of_read P R W epsilon p hW hspan hwidth hepsilon hR
        ρ.batches ρ.words (sourceExecution_legal P N p ρ hρ) a ha
    _ = _ := sourceExecutionFrom_batches_expected P N p _ _ _ replay

/-- Expected observations of the genuine sparse forward program coincide
with those of the raw-tape archives, at every stopping position. -/
theorem sourceExecution_online_expected
    (P : ScheduledSource E V) (R : GridUpdateParameters) (W epsilon : ℝ) (p : ℚ)
        (hW : 1 ≤ W) (hspan : W ≤ 2 ^ P.span) (hwidth : W = P.width)
    (hepsilon : epsilon = P.epsilon) (hR : ∀ tau > 0, R.Matches (P.config tau))
    (N a : ℕ) (ha : a ≤ P.arrivals) (test : OnlineStreamState E V → ℝ) :
    let q := sourceExecution P N p
    let raw := sourceRealWordTape P N p
    expected q.outcomes q.mass (fun ρ => test
      (runOnlineStreamForward R P.ends W epsilon P.span P.vertices P.objective
        (dyadicThreshold p P.bits) N P.edges (P.wordStream ρ.words) a)) =
    expected raw.outcomes raw.mass (fun batches => test
      (runOnlineIndexed R P.ends W P.span P.value P.edges (P.tapeIndex batches) a)) :=
  sourceExecution_joint_online_expected P R W epsilon p hW hspan hwidth hepsilon hR
    N a ha (fun _ => test)


end

end SubmodularMatching.Streaming.RealSource
