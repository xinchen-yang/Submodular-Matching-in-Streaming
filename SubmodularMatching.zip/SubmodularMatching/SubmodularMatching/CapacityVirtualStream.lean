import SubmodularMatching.CapacityLift
import SubmodularMatching.UpperBoundGraphInput
import Mathlib.Data.Fintype.Sets
import Mathlib.Data.Fintype.Sigma

/-! # The emitted slot graph as an ordinary simple edge stream -/

namespace SubmodularMatching.Capacity

open Finset UpperBoundAssembly

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

abbrev Emitted (out : List (Copy E)) := {c // c ∈ out}
/-- One isolated slot at a zero-capacity vertex keeps the announced virtual graph
at least as large as the source without changing any emitted edge. -/
abbrev Slot (cap : V → ℕ) := Σ v, Fin (max 1 (cap v))

def slotEnds (ends : E → V × V) (cap : V → ℕ) (out : List (Copy E))
    (hv : ∀ c ∈ out, valid ends cap c) (e : Emitted out) : Slot cap × Slot cap :=
  (⟨(ends e.val.label).1, ⟨e.val.left, ((hv e.val e.property).1.trans_le (le_max_right _ _))⟩⟩,
   ⟨(ends e.val.label).2, ⟨e.val.right, ((hv e.val e.property).2.trans_le (le_max_right _ _))⟩⟩)

private theorem slot_eq {cap : V → ℕ} {a b : Slot cap}
    (hv : a.1 = b.1) (hi : a.2.val = b.2.val) : a = b := by
  rcases a with ⟨v, i⟩
  rcases b with ⟨w, j⟩
  cases hv
  exact congrArg (Sigma.mk v) (Fin.ext hi)

theorem mem_slotEnds_iff (ends : E → V × V) (hl : ∀ e, (ends e).1 ≠ (ends e).2)
    (cap : V → ℕ) (out : List (Copy E)) (hv : ∀ c ∈ out, valid ends cap c)
    (e : Emitted out) (s : Slot cap) :
    s ∈ Streaming.endpointSet (slotEnds ends cap out hv) e ↔
      touches ends s.1 e.val.label ∧ index ends e.val s.1 = s.2.val := by
  simp only [Streaming.endpointSet, mem_insert, mem_singleton]
  constructor
  · rintro (rfl | rfl)
    · exact ⟨Or.inl rfl, by simp [slotEnds, index]⟩
    · exact ⟨Or.inr rfl, by simp [slotEnds, index, Ne.symm (hl _)]⟩
  · rintro ⟨h, hi⟩
    rcases h with h | h
    · exact Or.inl (slot_eq h (by simpa only [index, if_pos h, slotEnds] using hi.symm))
    · have hne : s.1 ≠ (ends e.val.label).1 := h ▸ Ne.symm (hl _)
      exact Or.inr (slot_eq h (by simpa only [index, if_neg hne, slotEnds] using hi.symm))

theorem index_lt_capacity (ends : E → V × V) (cap : V → ℕ)
    (c : Copy E) (hv : valid ends cap c) (v : V) (ht : touches ends v c.label) :
    index ends c v < cap v := by
  by_cases hl : v = (ends c.label).1
  · rw [index, if_pos hl, hl]; exact hv.1
  · have hr := ht.resolve_left hl
    rw [index, if_neg hl, hr]; exact hv.2

def rawCopies {out : List (Copy E)} (s : Finset (Emitted out)) : Finset (Copy E) :=
  s.image Subtype.val

theorem matching_slotEnds_iff (ends : E → V × V) (hl : ∀ e, (ends e).1 ≠ (ends e).2)
    (cap : V → ℕ) (out : List (Copy E)) (hv : ∀ c ∈ out, valid ends cap c)
    (s : Finset (Emitted out)) :
    Streaming.IsMatchingOn (Streaming.endpointSet (slotEnds ends cap out hv)) s ↔
      matching ends (rawCopies s) := by
  constructor
  · intro hs v x hx y hy hxy
    obtain ⟨hxs, hxt⟩ := mem_filter.mp hx
    obtain ⟨hys, hyt⟩ := mem_filter.mp hy
    obtain ⟨i, hi, rfl⟩ := mem_image.mp hxs
    obtain ⟨j, hj, rfl⟩ := mem_image.mp hys
    let w : Slot cap := ⟨v, ⟨index ends i.val v, (index_lt_capacity ends cap _ (hv _ i.property) v hxt).trans_le (le_max_right _ _)⟩⟩
    have hw := (mem_slotEnds_iff ends hl cap out hv i w).2 ⟨hxt, rfl⟩
    have hw' := (mem_slotEnds_iff ends hl cap out hv j w).2 ⟨hyt, hxy.symm⟩
    exact congrArg Subtype.val (Finset.pairwiseDisjoint_iff.mp hs hi hj ⟨w, mem_inter.mpr ⟨hw, hw'⟩⟩)
  · intro hs
    apply Finset.pairwiseDisjoint_iff.mpr
    intro i hi j hj h
    obtain ⟨w, hw⟩ := h
    obtain ⟨hw₁, hw₂⟩ := mem_inter.mp hw
    obtain ⟨hti, hei⟩ := (mem_slotEnds_iff ends hl cap out hv i w).1 hw₁
    obtain ⟨htj, hej⟩ := (mem_slotEnds_iff ends hl cap out hv j w).1 hw₂
    apply Subtype.ext
    exact hs w.1 (mem_filter.mpr ⟨mem_image_of_mem _ hi, hti⟩)
      (mem_filter.mpr ⟨mem_image_of_mem _ hj, htj⟩) (hei.trans hej.symm)

private theorem slotEnds_simple (S : SimpleEdgeStream E V) (cap : V → ℕ)
    (out : List (Copy E)) (hv : ∀ c ∈ out, valid S.ends cap c) :
    Function.Injective (TwoStage.pairEnds (slotEnds S.ends cap out hv)) := by
  intro i j h
  have hl : i.val.label = j.val.label := by
    apply S.simple
    have h' := congrArg (Finset.image (fun s : Slot cap => s.1)) h
    simpa only [TwoStage.pairEnds, Finset.image_insert, Finset.image_singleton, slotEnds] using h'
  have hpair : Streaming.endpointSet (slotEnds S.ends cap out hv) i =
      Streaming.endpointSet (slotEnds S.ends cap out hv) j := h
  have hleft : (slotEnds S.ends cap out hv i).1 ∈ Streaming.endpointSet (slotEnds S.ends cap out hv) j := by
    rw [← hpair]; simp [Streaming.endpointSet]
  have hright : (slotEnds S.ends cap out hv i).2 ∈ Streaming.endpointSet (slotEnds S.ends cap out hv) j := by
    rw [← hpair]; simp [Streaming.endpointSet]
  have hli := ((mem_slotEnds_iff _ S.loopless _ _ hv j _).1 hleft).2
  have hri := ((mem_slotEnds_iff _ S.loopless _ _ hv j _).1 hright).2
  have el : i.val.left = j.val.left := by simpa [slotEnds, index, hl] using hli.symm
  have er : i.val.right = j.val.right := by simpa [slotEnds, index, hl, Ne.symm (S.loopless _)] using hri.symm
  apply Subtype.ext
  rcases i with ⟨⟨il, ix, iy⟩, ih⟩
  rcases j with ⟨⟨jl, jx, jy⟩, jh⟩
  congr

/-- Feed each emitted edge to the ordinary solver in its actual arrival order. -/
def virtualStream (S : SimpleEdgeStream E V) (cap : V → ℕ) (out : List (Copy E))
    (hn : out.Nodup) (hv : ∀ c ∈ out, valid S.ends cap c) :
    SimpleEdgeStream (Emitted out) (Slot cap) where
  arrivals := out.attach
  ends := slotEnds S.ends cap out hv
  loopless := fun e he => S.loopless _ (congrArg Sigma.fst he)
  simple := slotEnds_simple S cap out hv
  distinct := hn.attach
  complete := by simp

end

end SubmodularMatching.Capacity
