import SubmodularMatching.UpperBoundAppendixSamplers
import SubmodularMatching.GibbsSpectralIntegerBudget

/-! # Exact conditional Gibbs call in the upper-bound program -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint TwoStage GibbsSampler NumericalCertificate

noncomputable section

variable {V : Type*} [Fintype V] [DecidableEq V] {m : ℕ}

/-- The same rounded coordinate constraints also give the unit upper
bound on activities required for the explicit Sinclair parameters. -/
theorem appendixSecondActivity_le_one (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (x y : Fin m → ℝ) (hxy : Feasible coordinateCap degree ends ends x y)
    (T : Finset (Fin m)) (e : Fin m) :
    secondActivity ends x y (roundingError / 4) (roundingError / 2) T e ≤ 1 := by
  have hr0 : 0 < sampler := (by norm_num : (0 : ℝ) < 1 / 2).trans sampler_bounds.1
  have hz := shearer_alteration_correct ends hloop hsimple coordinateCap degree sampler
    (roundingError / 4) coordinate_condition.1.le hr0 sampler_bounds.2.le rfl
    mean_excess_below_tolerance x y hxy
  let z := shearerAltered ends x y (roundingError / 4) T
  have hzdeg (v : V) : GibbsMatching.vertexLoad (pairEnds ends) Finset.univ z v ≤ 1 := by
    change Shearer.vertexDegree (pairEnds ends) Finset.univ z v ≤ 1
    rw [vertexDegree_pairEnds]
    exact hz.2.1 T v
  let a := 1 - (roundingError / 2) / 4
  have h := GibbsMatching.calibratedActivity_cap (pairEnds ends) Finset.univ z
    (fun e _ => (hz.1 T e).1) hzdeg (fun e _ => pairEnds_card_two ends hloop e)
    a coordinateCap (by norm_num [a, roundingError]) (by norm_num [a, roundingError])
    (fun e _ => (hz.1 T e).2) e (Finset.mem_univ _)
  exact h.trans (by norm_num [a, roundingError, coordinateCap])

def appendixGibbsSupport (ends : Fin m → V × V) (x y : Fin m → ℝ) (T : Finset (Fin m)) :
    Finset (Fin m) :=
  GibbsMatching.positiveEdges Finset.univ (secondActivity ends x y
    (roundingError / 4) (roundingError / 2) T)

def appendixGibbsDenominator (vertices : ℕ) : ℕ := 4 * vertices * 10000000000

theorem appendixGibbsDenominator_error (vertices : ℕ) :
    1 / (appendixGibbsDenominator vertices : ℝ) = appendixSamplerError vertices := by
  unfold appendixGibbsDenominator appendixSamplerError finiteError
  push_cast
  ring

def appendixGibbsSteps (ends : Fin m → V × V) (x y : Fin m → ℝ) (T : Finset (Fin m)) : ℕ :=
  let s := appendixGibbsSupport ends x y T
  lowActivitySteps (Fintype.card V) s.card (lowActivityPrecision (appendixGibbsDenominator (Fintype.card V)))

def appendixGibbsBits (ends : Fin m → V × V) (x y : Fin m → ℝ) (T : Finset (Fin m)) : ℕ :=
  lowActivityBits (appendixGibbsSteps ends x y T) (appendixGibbsSupport ends x y T).card
    (appendixGibbsDenominator (Fintype.card V))

/-- The actual finite chain, with derived step count and word width, meets
its error budget on every conditional first matching. -/
theorem appendixGibbs_variation (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (x y : Fin m → ℝ) (hxy : Feasible coordinateCap degree ends ends x y)
    (hv : 0 < Fintype.card V) (T : Finset (Fin m)) :
    let ep := pairEnds ends
    let a := secondActivity ends x y (roundingError / 4) (roundingError / 2) T
    let edges := appendixGibbsSupport ends x y T
    let states := GibbsMatching.matchings ep edges
    variation states (iterateKernel states (roundedTransition ep edges a (appendixGibbsBits ends x y T))
      (pointMass ∅) (appendixGibbsSteps ends x y T)) (GibbsMatching.probability ep edges a) ≤
        appendixSamplerError (Fintype.card V) := by
  dsimp only
  let a := secondActivity ends x y (roundingError / 4) (roundingError / 2) T
  let support := appendixGibbsSupport ends x y T
  let D := appendixGibbsDenominator (Fintype.card V)
  have hD : 0 < D := by dsimp [D, appendixGibbsDenominator]; positivity
  have hActivity (e : Fin m) (he : e ∈ support) : 0 < a e ∧ a e ≤ 1 :=
    ⟨(Finset.mem_filter.mp he).2, appendixSecondActivity_le_one ends hloop hsimple x y hxy T e⟩
  rw [← appendixGibbsDenominator_error]
  exact lowActivity_gibbs_support_variation (pairEnds ends) support a hActivity
    (fun e _ => pairEnds_card_two ends hloop e) D hD

end

end SubmodularMatching.UpperBoundAssembly
