import SubmodularMatching.CapacityActionQueryCosts
import SubmodularMatching.CapacityRealAccumulatorWords

/-! Simultaneous bank, frozen actions, incumbent and sequential scratch
on the physical nonmonotone capacity pass. -/
namespace SubmodularMatching.Capacity
open AppendixM UpperBoundAssembly ShearerSampler Streaming
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def frozenCells (cap : V → ℕ) (bank : RealOracle.GuessBank (SparseSlots E cap)) :=
  (bank.states.map (fun a => 2*(a.2.machine.edges.map Prod.fst).toFinset.card)).sum

theorem frozenCells_le (cap : V → ℕ) (bank : RealOracle.GuessBank (SparseSlots E cap)) :
    frozenCells cap bank ≤ RealOracle.bankCells bank := by
  have hlist (xs : List (ℕ × SparseSlots E cap)) :
      (xs.map (fun a => 2*(a.2.machine.edges.map Prod.fst).toFinset.card)).sum ≤
      (xs.map (fun a => payloadCells a.2)).sum := by
    induction xs with
    | nil => rfl
    | cons a xs ih =>
      simp only [List.map_cons,List.sum_cons]
      have h := (List.toFinset_card_le (a.2.machine.edges.map Prod.fst)).trans_eq (List.length_map _)
      exact Nat.add_le_add (by unfold payloadCells; omega) ih
  exact (hlist bank.states).trans (Nat.le_add_left _ 4)

theorem retainedCells_le (cap : V → ℕ) (bank : RealOracle.GuessBank (SparseSlots E cap))
    (a : ℕ × SparseSlots E cap) (ha : a ∈ bank.states) :
    (a.2.machine.edges.map Prod.fst).toFinset.card ≤ RealOracle.bankCells bank := by
  have h := (List.toFinset_card_le (a.2.machine.edges.map Prod.fst)).trans_eq (List.length_map _)
  have h' : a.2.machine.edges.length ≤ payloadCells a.2 := by unfold payloadCells; omega
  have hmem : payloadCells a.2 ≤ (bank.states.map (fun v => payloadCells v.2)).sum :=
    List.le_sum_of_mem (List.mem_map.mpr ⟨a,ha,rfl⟩)
  exact ((h.trans h').trans hmem).trans (Nat.le_add_left _ 4)

/-- The entire live bank plus two frozen action coordinates per retained
label, a feasible incumbent, 34s optimizer cells, two compact mate arrays,
a priority score per selected copy and two-layer sweep storage are linear in
the bank plus the input word width. The layer precision denominator D may
be any prescribed polynomial in the original graph size. -/
theorem signed_sequential_workspace (cap : V → ℕ) (bank : RealOracle.GuessBank (SparseSlots E cap))
    (a : ℕ × SparseSlots E cap) (ha : a ∈ bank.states) (n ν C d D layerCount : ℕ)
    (hD : D≤C*(n+1)^d) (s := (a.2.machine.edges.map Prod.fst).toFinset.card)
    (hs : s=(a.2.machine.edges.map Prod.fst).toFinset.card) (hn : s≤n^2)
    (hm : layerCount≤s*n^2) (bankConstant : ℕ)
    (hbank : RealOracle.bankCells bank ≤ bankConstant*(ν+1)*((n+1).log2+1)^2) :
    let w := (n+1).log2+1
    let q := Nat.clog 2 D
    let K := 2*s+q+1
    let L := samplerFuel (51/100) (((2:ℝ)^q)⁻¹) layerCount
    let T := d+C.log2+1
    let roles := max (34*s) (4*s + 8*(2*K+2*L))
    RealOracle.bankCells bank + frozenCells cap bank + roles + 2*ν + 16 ≤
      (38*bankConstant+8*(5000*(7+T)+2*T+4)+18)*(ν+1)*w^2 := by
  intro w q K L T roles
  have hA := frozenCells_le cap bank
  have hsbank : s ≤ RealOracle.bankCells bank := hs ▸ retainedCells_le cap bank a ha
  have hreserve : 2*K+2*L ≤ 4*s+(5000*(7+T)+2*T+4)*w := reserve_graph_bound s layerCount D n C d hn hm hD
  let B := 5000*(7+T)+2*T+4
  let H := (ν+1)*w^2
  have hw : 1≤w := by dsimp only [w]; omega
  have hunit : 1≤H := Nat.succ_le_of_lt (Nat.mul_pos (Nat.succ_pos _) (pow_pos (by omega) _))
  have hν : ν≤H := by dsimp only [H]; nlinarith only [Nat.mul_le_mul_left (ν+1) (one_le_pow₀ hw (n:=2))]
  have hwH : w≤H := (show w≤w^2 by nlinarith only [Nat.mul_le_mul_left w hw]).trans
    (by dsimp only [H]; exact Nat.le_mul_of_pos_left _ (Nat.succ_pos _))
  have hR : roles ≤ 36*s+8*B*w := by
    change 2*K+2*L ≤ 4*s+B*w at hreserve
    rw [Nat.mul_assoc 8 B w]; dsimp only [roles]; apply max_le <;> omega
  have hW := Nat.mul_le_mul_left (8*B) hwH
  rw [Nat.mul_assoc] at hbank
  change RealOracle.bankCells bank ≤ bankConstant*H at hbank
  calc
    _ ≤ 38*(bankConstant*H)+8*B*H+2*H+16*H := by omega
    _ = _ := by dsimp only [H,B]; ring

end
end SubmodularMatching.Capacity
