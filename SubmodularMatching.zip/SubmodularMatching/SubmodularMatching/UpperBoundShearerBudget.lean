import SubmodularMatching.UpperBoundSamplingParameters

/-! # Integer doubling bounds for the rational recursive sampler -/

namespace SubmodularMatching.UpperBoundAssembly

open NumericalCertificate

noncomputable section

/-- A fixed multiple of a binary logarithm bounds the recursion fuel. -/
def appendixShearerFuel (m : ℕ) (δ : ℝ) : ℕ :=
  2048 * binaryBudget (4 * ((m : ℝ) + 1) / δ)

def appendixShearerAttempts (m fuel : ℕ) (δ : ℝ) : ℕ :=
  binaryBudget (2 * ((m : ℝ) + 1) * (8 * (fuel : ℝ) + 1) / δ)

/-- One fixed block of trials reduces the stopping tail by at least half. -/
theorem appendixShearer_decay : (4 * sampler * (1 - sampler)) ^ (2048 : ℕ) ≤ 1 / 2 := by
  have h0 : 0 ≤ 4 * sampler * (1 - sampler) := by norm_num [sampler]
  have h : 4 * sampler * (1 - sampler) ≤ 1 - 1 / (2048 : ℝ) := by norm_num [sampler]
  calc
    _ ≤ (1 - 1 / (2048 : ℝ)) ^ (2048 : ℕ) := pow_le_pow_left₀ h0 h _
    _ ≤ Real.exp (-(1 : ℝ)) := by
      exact_mod_cast (Real.one_sub_div_pow_le_exp_neg (n := 2048) (t := 1) (by norm_num))
    _ ≤ 1 / 2 := by
      rw [Real.exp_neg, ← one_div]
      apply div_le_div_of_nonneg_left (by norm_num) (by norm_num)
      linarith [Real.add_one_lt_exp (show (1 : ℝ) ≠ 0 by norm_num)]

theorem appendixShearer_budget (m : ℕ) (δ : ℝ) (hδ : 0 < δ) :
    let L := appendixShearerFuel m δ
    let B := appendixShearerAttempts m L δ
    (m : ℝ) * (2 * (4 * sampler * (1 - sampler)) ^ L + (8 * L + 1) * ((2 : ℝ) ^ B)⁻¹) ≤ δ := by
  dsimp only
  let b := binaryBudget (4 * ((m : ℝ) + 1) / δ)
  let L := appendixShearerFuel m δ
  let B := appendixShearerAttempts m L δ
  have hb := (div_le_iff₀ hδ).mp (binaryBudget_capacity (4 * ((m : ℝ) + 1) / δ))
  have hB := (div_le_iff₀ hδ).mp
    (binaryBudget_capacity (2 * ((m : ℝ) + 1) * (8 * (L : ℝ) + 1) / δ))
  have hv : (4 * sampler * (1 - sampler)) ^ L ≤ ((2 : ℝ) ^ b)⁻¹ := by
    change _ ^ (2048 * b) ≤ _
    rw [pow_mul, ← inv_pow, ← one_div]
    exact pow_le_pow_left₀ (pow_nonneg (by norm_num [sampler]) _) appendixShearer_decay _
  have hc : 4 * ((m : ℝ) + 1) * ((2 : ℝ) ^ b)⁻¹ ≤ δ := by
    rw [← div_eq_mul_inv]
    exact (div_le_iff₀ (by positivity)).2 (by rw [mul_comm δ]; exact hb)
  have hd : 2 * ((m : ℝ) + 1) * (8 * (L : ℝ) + 1) * ((2 : ℝ) ^ B)⁻¹ ≤ δ := by
    rw [← div_eq_mul_inv]
    exact (div_le_iff₀ (by positivity)).2 (by rw [mul_comm δ]; exact hB)
  have hh := mul_le_mul_of_nonneg_left hv (by positivity : 0 ≤ 2 * (m : ℝ))
  change (m : ℝ) * (2 * (4 * sampler * (1 - sampler)) ^ L +
    (8 * (L : ℝ) + 1) * ((2 : ℝ) ^ B)⁻¹) ≤ δ
  nlinarith only [hc, hd, hh, show 0 ≤ ((2 : ℝ) ^ b)⁻¹ by positivity,
    mul_nonneg (show 0 ≤ 8 * (L : ℝ) + 1 by positivity)
      (show 0 ≤ ((2 : ℝ) ^ B)⁻¹ by positivity)]

end

end SubmodularMatching.UpperBoundAssembly
