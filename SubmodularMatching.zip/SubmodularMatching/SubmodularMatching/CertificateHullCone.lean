import SubmodularMatching.CertificateFastCone
import SubmodularMatching.CertificateConvexAxisCheck

/-!
# Cone minima from a shared lower envelope

A verified lower envelope can supply the support proof for all the cones
that refer to the same source interval.
-/

namespace SubmodularMatching.SourceCertificate

def AppendixFastCone.Sufficient (C : AppendixFastCone) : Prop :=
  C.coordinates = C.cone.appendixCoordinates C.covered ∧
    ∀ w p : ℤ, 0 ≤ w → C.coordinates.minCheck w p = true →
      ∀ k, C.cone.lo ≤ k → k ≤ C.cone.hi →
        integerAxisCheck sourceScale (appendixGridX k) (appendixGridHeight C.covered k)
          w p (C.coordinates.value w p) = true

theorem AppendixFastCone.Valid.sufficient {C : AppendixFastCone} (h : C.Valid) : C.Sufficient := by
  refine ⟨h.2, ?_⟩
  intro w p hw hm k hl hh
  rw [C.minCheck_eq h] at hm
  rw [h.2]
  exact C.cone.minimum_sound sourceScale appendixGridX (appendixGridHeight C.covered)
    w p hw h.1 hm k hl hh

/-- Neighbor records are identified with consecutive vertices of the verified
envelope. The end vertices use themselves on the missing side. -/
structure AxisCone.HullIndices (C : AxisCone) (vertex : ℕ → ℕ) (count m : ℕ) : Prop where
  bound : m ≤ count
  current : C.ix = vertex m
  left : C.prev = vertex (m - 1)
  right : C.next = vertex (min (m + 1) count)

theorem AppendixFastCone.sufficient_of_hull (C : AppendixFastCone) (vertex : ℕ → ℕ)
    (count m : ℕ)
    (hull : ConvexAxisEnvelope appendixGridX (appendixGridHeight C.covered)
      C.cone.lo C.cone.hi count vertex)
    (hmono : ∀ i j, i ≤ j → j ≤ C.cone.hi → appendixGridX i ≤ appendixGridX j)
    (indices : C.cone.HullIndices vertex count m)
    (coords : C.coordinates = C.cone.appendixCoordinates C.covered) : C.Sufficient := by
  refine ⟨coords, ?_⟩
  intro w p hw hm k hkl hkh
  have htests : w * C.coordinates.leftDh ≤ p * C.coordinates.leftDx ∧
      p * C.coordinates.rightDx ≤ w * C.coordinates.rightDh := of_decide_eq_true hm
  rw [coords] at htests
  simp only [AxisCone.appendixCoordinates, axisDiff, indices.current, indices.left, indices.right] at htests
  have hL (hl : 0 < m) : hullStep appendixGridX (appendixGridHeight C.covered) vertex w p (m - 1) ≤ 0 := by
    apply sub_nonpos.mpr
    unfold hullDH hullDX
    rw [show m - 1 + 1 = m by omega]
    exact htests.1
  have hR (hr : m < count) : 0 ≤ hullStep appendixGridX (appendixGridHeight C.covered) vertex w p m := by
    apply sub_nonneg.mpr
    unfold hullDH hullDX
    have hm : m + 1 ≤ count := Nat.succ_le_of_lt hr
    simpa only [min_eq_left hm] using htests.2
  rw [coords]
  change integerAxisCheck sourceScale (appendixGridX k) (appendixGridHeight C.covered k) w p
    (hullScore appendixGridX (appendixGridHeight C.covered) w p C.cone.ix) = true
  rw [indices.current]
  exact integer_axis_minimum_of_hull sourceScale _ _ vertex _ _ count hull hmono
    w p hw m indices.bound hL hR k hkl hkh

theorem appendixGridX_monotone (i j : ℕ) (hij : i ≤ j) (hj : j ≤ 1135) :
    appendixGridX i ≤ appendixGridX j := by
  have h := appendixPotentialTable.ordered.le hij hj
  rw [appendixRealKnot_data, appendixRealKnot_data] at h
  exact_mod_cast (div_le_div_iff_of_pos_right sourceScale_real_pos).mp h

theorem appendixFastLeaf_sound_of_support (modeAt : ℕ → AppendixModeRegion) (modeCount : ℕ)
    (coneAt : ℕ → AppendixFastCone) (coneCount : ℕ)
    (modeValid : ∀ z < modeCount, (modeAt z).Valid)
    (coneValid : ∀ z < coneCount, (coneAt z).Sufficient)
    (i j : Bool) (box : PriceBox) (w : AppendixCachedWitness)
    (hvalid : box.IsValid 55296 1135)
    (hcheck : appendixFastLeafCheck modeAt modeCount coneAt coneCount i j box w = true)
    (e : ℕ) (a d : ℝ) (hpoint : box.Contains appendixPotentialTable.realKnot e a d) :
    AppendixIndexedGoal i j e a d := by
  simp only [appendixFastLeafCheck, Bool.and_eq_true, decide_eq_true_eq] at hcheck
  obtain ⟨⟨hm, hx, hy, hml, hmh, hxi, hyj, hxlo, hxhi, hylo, hyhi⟩, hminx, hminy, hmul, hgap⟩ := hcheck
  let x := coneAt w.xCone
  let y := coneAt w.yCone
  let p := (modeAt w.region).p
  change x.covered = i at hxi
  change y.covered = j at hyj
  change x.cone.lo = box.xLo at hxlo
  change x.cone.hi = box.xHi at hxhi
  change y.cone.lo = box.yLo at hylo
  change y.cone.hi = box.yHi at hyhi
  change boxGapCheckCoordinates p i j w.t x.coordinates y.coordinates = true at hgap
  have xs : x.Sufficient := coneValid _ hx
  have ys : y.Sufficient := coneValid _ hy
  have hxcheck := xs.2 (boxWeightX p i) (boxPenaltyX p w.t) (boxWeightX_nonnegative _ _) hminx
  have hycheck := ys.2 (boxWeightY p j) (boxPenaltyY p w.t) (boxWeightY_nonnegative _ _) hminy
  rw [xs.1, hxi, hxlo, hxhi] at hxcheck
  rw [ys.1, hyj, hylo, hyhi] at hycheck
  rw [show boxGapCheckCoordinates p i j w.t x.coordinates y.coordinates =
      boxGapCheck p i j w.t x.cone.ix y.cone.ix by
    rw [xs.1, ys.1, hxi, hyj]
    rfl] at hgap
  exact appendixIntegerLeaf_sound i j box p w.t x.cone.ix y.cone.ix hvalid
    hxcheck hycheck hmul hgap e a d hpoint (modeValid _ hm e (hml.trans hpoint.1) (hpoint.2.1.trans hmh))

end SubmodularMatching.SourceCertificate
