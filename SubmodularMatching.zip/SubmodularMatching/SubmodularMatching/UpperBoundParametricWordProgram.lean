import SubmodularMatching.UpperBoundParametricProgram
import SubmodularMatching.UpperBoundParametricWordStage
import SubmodularMatching.StreamingSourceWordTape

/-! # Word-based source and optimizer law for the accuracy family -/

namespace SubmodularMatching.UpperBoundAssembly.FamilyProgramInput

open GibbsSampler Streaming NumericalCertificate

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]
variable {slack : ℝ} {a : FamilyParameters slack} (I : FamilyProgramInput a E V)

theorem familyProbability_config (tau : ℝ) : (a.p : ℝ) = (I.P.config tau).p := by
  rw [I.configuration, parametricGuessConfig_p]

def wordPreprocessed (oracle : Finset E → ℚ) (ω : ℝ) : CandidateLaw (I.Tape ω) := by
  classical
  exact (sourceWordTape I.P (I.Ns ω) oracle a.p).bind
    (fun b => (parametricFinalOptimizerWordLaw a.settings I.P b I.noRepeat).map (PreparedTape.mk b))

set_option maxHeartbeats 800000 in
/-- The source and optimizer can both generate their finite word draws
on the current compact instance with the same law of final observables. -/
theorem wordPreprocessed_value (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ)) (ω : ℝ) (test : I.Tape ω → ℝ) :
    expected (I.wordPreprocessed oracle ω).outcomes (I.wordPreprocessed oracle ω).mass test =
      expected (I.preprocessed ω).outcomes (I.preprocessed ω).mass test := by
  classical
  unfold wordPreprocessed preprocessed parametricPreparationLaw
  rw [CandidateLaw.bind_expected, CandidateLaw.bind_expected]
  let src := sourceWordTape I.P (I.Ns ω) oracle a.p
  let obs := fun b : ℕ → Fin (I.Ns ω) → ℝ =>
    let q := parametricFinalOptimizerLaw (Ng := I.Ng ω) a.settings I.P b I.noRepeat
    expected (q.map (PreparedTape.mk b)).outcomes (q.map (PreparedTape.mk b)).mass test
  calc
    _ = expected src.outcomes src.mass obs := by
      unfold expected
      apply Finset.sum_congr rfl
      intro b _
      congr 1
      let q := (parametricFinalOptimizerWordLaw (Ng := I.Ng ω) a.settings I.P b I.noRepeat).map (PreparedTape.mk b)
      change expected q.outcomes q.mass test = obs b
      simp only [q, obs, CandidateLaw.map_expected]
      exact parametricFinalOptimizerWordLaw_value a.settings I.P b I.noRepeat (test ∘ PreparedTape.mk b)
    _ = _ := sourceWordTapeFrom_expected I.P (I.Ns ω) oracle a.p
      I.familyProbability_config hobj obs _ _ _

def wordExpectedLaw (oracle : Finset E → ℚ) : CandidateLaw (Finset E) :=
  expectedOutputLaw (I.wordPreprocessed oracle a.error) I.feasible I.P.objective
    (a.error * I.B / 2) (I.candidates a.error) I.initial I.initial_legal
    (I.candidates_legal a.error)

def wordAmplifiedLaw (oracle : Finset E → ℚ) (delta : ℝ) : CandidateLaw (Finset E) :=
  let ω := min a.error (delta / 2)
  amplifiedOutputLaw (I.wordPreprocessed oracle ω) I.feasible I.P.objective
    (a.error * I.B / 2) (I.candidates ω) I.initial I.initial_legal
    (I.candidates_legal ω) (a.trials delta)

theorem wordExpectedLaw_value (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ)) (test : Finset E → ℝ) :
    expected (I.wordExpectedLaw oracle).outcomes (I.wordExpectedLaw oracle).mass test =
      expected I.expectedLaw.outcomes I.expectedLaw.mass test := by
  unfold wordExpectedLaw expectedLaw
  rw [expectedOutputLaw_value, expectedOutputLaw_value]
  exact I.wordPreprocessed_value oracle hobj a.error _

theorem wordAmplifiedLaw_value (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ)) (delta : ℝ) (test : Finset E → ℝ) :
    expected (I.wordAmplifiedLaw oracle delta).outcomes (I.wordAmplifiedLaw oracle delta).mass test =
      expected (I.amplifiedLaw delta).outcomes (I.amplifiedLaw delta).mass test := by
  unfold wordAmplifiedLaw amplifiedLaw
  rw [amplifiedOutputLaw_value, amplifiedOutputLaw_value]
  exact I.wordPreprocessed_value oracle hobj _ _


end

end SubmodularMatching.UpperBoundAssembly.FamilyProgramInput
