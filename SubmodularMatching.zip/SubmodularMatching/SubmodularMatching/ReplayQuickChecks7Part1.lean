import SubmodularMatching.ReplayQuickRate

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 16000
set_option maxHeartbeats 5000000

theorem quick22528 : allIndexed compareQuick 22528 sourceRates22528 = true := by decide +kernel

end SubmodularMatching.SourceCertificate.Replay
