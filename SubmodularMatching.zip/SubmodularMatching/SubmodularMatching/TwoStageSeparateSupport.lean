import SubmodularMatching.TwoStageSeparateAlteration

/-!
# Appendix J for separate, possibly overlapping supports

The first matching and independent residual extension use `A`. The
stored arrival sequence and conditional Gibbs matching use `S`. No
ordering relationship between the supports is assumed.
-/

namespace SubmodularMatching.TwoStage

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The exact separate-support composed value. -/
noncomputable def separateTwoStageValue [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (εA εG : ℝ) (f : Finset E → ℝ) : ℝ :=
  Shearer.expectation (pairEnds ends) A y
    (conditionalValue (pairEnds ends) S (separateAltered ends A S x y εA) εG f)

/-- Appendix J (GJ5) for arbitrary distinct or overlapping supports,
using the explicit small-coordinate Gibbs coefficient. -/
theorem separate_two_stage_rounding_value [Fintype E] [Finite V]
    (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends))
    (A S : Finset E) (x y : E → ℝ) (p D r εA εG : ℝ)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (hr0 : 0 < r) (hr1 : r ≤ 1)
    (hDr : D = r*(1-r)) (hgap : meanAllowance p D < εA)
    (hG0 : 0 < εG) (hG1 : εG < 1) (hcap : p ≤ εG^5 / 5120)
    (hFeas : SeparateFeasible ends A S x y p D)
    (stored : ℕ → E) (n : ℕ)
    (hmem : ∀ i < n, stored i ∈ S) (hcover : S ⊆ replacementPrefix stored n)
    (hdistinct : ∀ i < n, ∀ j < n, stored i = stored j → i = j)
    (active : ℕ → E) (m : ℕ)
    (hAmem : ∀ i < m, active i ∈ A) (hAcover : A ⊆ replacementPrefix active m)
    (hAdistinct : ∀ i < m, ∀ j < m, active i = active j → i = j)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f) (hzero : f ∅ = 0)
    (wh : ℕ → ℝ) (hwh0 : ∀ i < n, 0 ≤ wh i)
    (hwh : ∀ i < n, wh i ≤ arrivalWeight stored p f i) :
    (1-εG) * (bernoulliExpectation active (fun i => y (active i)) (residualValue stored p f n) m +
      retentionCoefficient p D εA * ∑ i ∈ Finset.range n, wh i * x (stored i)) ≤
      separateTwoStageValue ends A S x y εA εG f := by
  let z := separateAltered ends A S x y εA
  have hA := separate_alteration_correct ends hloop hsimple A S x y p D r εA hp hr0 hr1 hDr hgap hFeas
  have hCard (e : E) : (pairEnds ends e).card = 2 := by simp [pairEnds,Finset.card_pair (hloop e)]
  have hyD (v : V) :
      (∑ e ∈ incident (pairEnds ends) A v, y e) ≤ r*(1-r) := by
    rw [← hDr]
    exact hFeas.y_degree v
  exact two_stage_value (pairEnds ends) S A y x z r εG p (retentionCoefficient p D εA)
    hr0 hr1 hG0 hG1 hp hp1 hcap hFeas.y_nonneg (fun e _ => hCard e) hyD
    stored n hmem hcover hdistinct (fun e _ => hCard e) hsimple.injOn
    active m hAmem hAcover hAdistinct f hf hmono hzero wh hwh0 hwh
    (fun T _ e _ => hA.1 T e) (fun T _ v => hA.2.1 T v) hA.2.2.2

/-- The separate-support alteration itself guarantees that every
positive-probability pair of draws has a feasible union. -/
theorem separate_two_stage_positive_union_matching [Fintype E]
    (ends : E → V × V) (A S : Finset E) (x y : E → ℝ) (εA εG : ℝ) (T N : Finset E)
    (hFirst : 0 < Shearer.mass (pairEnds ends) A y T)
    (hSecond : 0 < probability (pairEnds ends) S
      (calibratedActivity (pairEnds ends) S (separateAltered ends A S x y εA T) (1-εG/4)) N) :
    Streaming.IsMatchingOn (pairEnds ends) (T ∪ N) := by
  classical
  have hT : T ∈ matchings (pairEnds ends) A := by
    by_contra hn
    rw [Shearer.mass_of_not_mem _ _ _ _ hn] at hFirst
    exact (lt_irrefl (0:ℝ)) hFirst
  refine positive_probability_union_matching (pairEnds ends) S T N
    (separateAltered ends A S x y εA T) (1-εG/4) ((mem_matchings ..).mp hT).2 ?_ hSecond
  intro e he hn
  rw [separateAltered_eq ends A S x y εA] at hn
  exact altered_avoids_matching ends (fun M : Finset E => M)
    (compensatedEdge ends (zeroOutside S x) (zeroOutside A y)) εA T e hn

/-- The pair denominator has the GJ2 lower bound on the actual first
support. In particular, both stored and unstored pairs are safe. -/
theorem separatePairProbability_lower (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (A S : Finset E)
    (x y : E → ℝ) (p D r : ℝ) (hr0 : 0 < r) (hr1 : r ≤ 1)
    (hDr : D = r*(1-r)) (hFeas : SeparateFeasible ends A S x y p D) (u v : V) :
    1-vertexLoad (pairEnds ends) A y u-vertexLoad (pairEnds ends) A y v ≤
      separatePairProbability ends A y u v := by
  exact Shearer.unmatchedPair_union_bound (pairEnds ends) A y r hr0 hr1 hFeas.y_nonneg
    (fun e _ => by simp [pairEnds,Finset.card_pair (hloop e)])
    (fun v => hDr ▸ hFeas.y_degree v) u v


/-- The small-coordinate loss specialization of Appendix J, on two
independently specified overlapping or disjoint supports. -/
theorem explicit_separate_two_stage_rounding [Fintype E] [Finite V]
    (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends))
    (A S : Finset E) (x y : E → ℝ) (p D r ε : ℝ)
    (hp : 0 ≤ p) (hr0 : 0 < r) (hr1 : r ≤ 1) (hDr : D = r*(1-r))
    (hε0 : 0 < ε) (hε1 : ε < 1) (hcap : p ≤ ε^5/163840)
    (hFeas : SeparateFeasible ends A S x y p D)
    (stored : ℕ → E) (n : ℕ)
    (hmem : ∀ i < n, stored i ∈ S) (hcover : S ⊆ replacementPrefix stored n)
    (hdistinct : ∀ i < n, ∀ j < n, stored i = stored j → i = j)
    (active : ℕ → E) (m : ℕ)
    (hAmem : ∀ i < m, active i ∈ A) (hAcover : A ⊆ replacementPrefix active m)
    (hAdistinct : ∀ i < m, ∀ j < m, active i = active j → i = j)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f) (hzero : f ∅ = 0)
    (wh : ℕ → ℝ) (hwh0 : ∀ i < n, 0 ≤ wh i) (hwh : ∀ i < n, wh i ≤ arrivalWeight stored p f i) :
    (1-ε) * (bernoulliExpectation active (fun i => y (active i)) (residualValue stored p f n) m +
      ∑ i ∈ Finset.range n, wh i * x (stored i)) ≤
        separateTwoStageValue ends A S x y (ε/4) (ε/2) f := by
  have hD0 : 0 ≤ D := by rw [hDr]; exact mul_nonneg hr0.le (sub_nonneg.mpr hr1)
  have hD1 : D ≤ 1/4 := by rw [hDr]; nlinarith only [sq_nonneg (r-1/2)]
  have hp1 := (explicit_two_stage_side_conditions p D ε hp hD0 hD1 hε0 hε1 hcap).1
  have hgap := (explicit_two_stage_side_conditions p D ε hp hD0 hD1 hε0 hε1 hcap).2.2.1
  have hcap' : p ≤ (ε/2)^5/5120 := by calc
    p ≤ ε^5/163840 := hcap
    _ = _ := by ring
  have hb := separate_two_stage_rounding_value ends hloop hsimple A S x y p D r (ε/4) (ε/2)
    hp hp1 hr0 hr1 hDr hgap (by positivity) (by linarith) hcap'
    hFeas stored n hmem hcover hdistinct active m hAmem hAcover hAdistinct f hf hmono hzero
    wh hwh0 hwh
  have hκ : 1-ε ≤ (1-ε/2)*retentionCoefficient p D (ε/4) :=
    (explicit_two_stage_retention p D ε hp hD0 hD1 hε0 hε1 hcap).2
  have hx : 0 ≤ ∑ i ∈ Finset.range n, wh i * x (stored i) :=
    Finset.sum_nonneg (fun i hi =>
      mul_nonneg (hwh0 i (Finset.mem_range.mp hi))
        (hFeas.x_nonneg _ (hmem i (Finset.mem_range.mp hi))))
  have hY (e : E) (he : e ∈ A) : 0 ≤ y e ∧ y e ≤ 1 := by
    let v := (ends e).1
    have hInc : e ∈ incident (pairEnds ends) A v :=
      Finset.mem_filter.mpr ⟨he,by simp [v,pairEnds]⟩
    have hOne : y e ≤ vertexLoad (pairEnds ends) A y v :=
      Finset.single_le_sum (fun d hd => hFeas.y_nonneg d (Finset.mem_filter.mp hd).1) hInc
    exact ⟨hFeas.y_nonneg e he, hOne.trans ((hFeas.y_degree v).trans (by linarith))⟩
  have hRes : 0 ≤ bernoulliExpectation active (fun i => y (active i)) (residualValue stored p f n) m := by
    apply bernoulliExpectation_nonnegative _ _ _ m (fun i hi => hY _ (hAmem i hi))
    intro T
    have h := residualValue_monotone stored p f hmono hp hp1 n ∅ T (Finset.empty_subset T)
    simpa only [residualValue_empty] using h
  apply le_trans _ hb
  have hLinear := mul_le_mul_of_nonneg_right hκ hx
  have hResidual := mul_le_mul_of_nonneg_right (show 1-ε ≤ 1-ε/2 by linarith) hRes
  nlinarith only [hLinear,hResidual]

end SubmodularMatching.TwoStage
