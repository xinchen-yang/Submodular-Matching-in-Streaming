import SubmodularMatching.NonmonotoneGridRow
import SubmodularMatching.ProjectedShearerBestSchedule
import SubmodularMatching.CapacitySignedSamplerResources

/-! Fixed resource parameters for the actual GridRow finite-word samplers. -/
namespace SubmodularMatching.AppendixM
open Capacity NonmonotoneCandidate ShearerSampler ShearerCappedSampler GibbsMatching UpperBoundAssembly
noncomputable section

def physicalLayerExponent (K : ℕ) := 4*Nat.clog 2 K+3
def rowFuelLimit (m K : ℕ) := 2500*(2+Nat.clog 2 (m+1)+physicalLayerExponent K)+1
def rowAttemptsLimit (m K : ℕ) := 2+Nat.clog 2 (m+1)+Nat.clog 2 (8*rowFuelLimit m K+1)+physicalLayerExponent K

theorem physicalLayerExponent_cap (m K : ℕ) : layerSampleCap m K = 2*m+physicalLayerExponent K+1 := by
  unfold layerSampleCap physicalLayerExponent; omega

theorem physicalLayerExponent_share (K : ℕ) (hk : 0<K) : ((2:ℝ)^physicalLayerExponent K)⁻¹ ≤ layerShare K := by
  have hl : (K:ℝ) ≤ 2^(Nat.clog 2 K) := by exact_mod_cast Nat.le_pow_clog (by decide : 1<2) K
  have u := mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (Nat.cast_nonneg K) hl 2) (by norm_num : (0:ℝ)≤4)
  have hp : 4*(2:ℝ)^(Nat.clog 2 K*2) ≤ (2:ℝ)^physicalLayerExponent K := by
    calc
      _ = (2:ℝ)^(2+Nat.clog 2 K*2) := by rw [pow_add]; norm_num
      _ ≤ _ := pow_le_pow_right₀ (by norm_num) (by unfold physicalLayerExponent; omega)
  rw [pow_mul] at hp
  unfold layerShare
  rw [one_div]
  exact inv_anti₀ (by positivity) (u.trans hp)

private theorem cutoff_le {a x y : ℝ} (ha : 0<a) (ha' : a<1) (hx : 0<x) (hy : x≤y) :
    decayCutoff a x ≤ decayCutoff a y :=
  Nat.ceil_mono (div_le_div_of_nonneg_right (Real.log_le_log hx hy) (neg_nonneg.mpr (Real.log_neg ha ha').le))

theorem grid_sampler_limits (m K : ℕ) (hk : 0<K) :
    let δ := layerShare K
    let L := samplerFuel (51/100) δ m
    let A := samplerAttempts δ m L
    L ≤ rowFuelLimit m K ∧ A ≤ rowAttemptsLimit m K := by
  intro δ L A
  let q := physicalLayerExponent K
  let small := ((2:ℝ)^q)⁻¹
  let Ld := samplerFuel (51/100) small m
  have hs : 0<small := by dsimp [small]; positivity
  have hd : 0<δ := (layerShare_range K hk).1
  have hle : small≤δ := physicalLayerExponent_share K hk
  have hf : L≤Ld := cutoff_le (by norm_num) (by norm_num) (by positivity) (div_le_div_of_nonneg_left (by positivity) hs hle)
  have hm : (0:ℝ)≤m := by positivity
  have hnum : 2*((m:ℝ)+1)*(8*(L:ℝ)+1) ≤ 2*((m:ℝ)+1)*(8*(Ld:ℝ)+1) := by
    gcongr
  have hb : A≤samplerAttempts small m Ld := cutoff_le (by norm_num) (by norm_num) (by positivity)
    ((div_le_div_of_nonneg_right hnum hd.le).trans (div_le_div_of_nonneg_left (by positivity) hs hle))
  have bounds := physical_sampler_limits m q
  have hL : Ld≤rowFuelLimit m K := bounds.1
  exact ⟨hf.trans hL, hb.trans (bounds.2.trans (by
    change 2+Nat.clog 2 (m+1)+Nat.clog 2 (8*Ld+1)+q ≤ 2+Nat.clog 2 (m+1)+Nat.clog 2 (8*rowFuelLimit m K+1)+q
    have hstep := Nat.clog_mono_right 2 (show 8*Ld+1≤8*rowFuelLimit m K+1 by omega)
    omega))⟩

end
end SubmodularMatching.AppendixM

namespace SubmodularMatching.NonmonotoneCandidate.GridRow
open AppendixM Capacity TwoLayerDiffuse UpperBoundAssembly ShearerCappedSampler ShearerSampler
noncomputable section
variable {I V : Type*} [Fintype I] [DecidableEq I] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream I V} {b : V→ℕ}

theorem physical_inputs_limits (g : GridRow S b) (hb : ∀ v, 0<b v) (rank : Slots b↪ℕ) :
    let K := scaleFor (S:=S) rank
    let m := (layerSupport S b rank).card
    let layers := g.layers hb rank
    let δ := layerShare K
    let condition := fun (I : Input pairVertices (layerSupport S b rank)) =>
      I.rational.stop = 51/100 ∧ I.order.length = m ∧ fuel I δ ≤ rowFuelLimit m K ∧ attempts I δ ≤ rowAttemptsLimit m K
    condition layers.1.input ∧ condition layers.2.input := by
  intro K m layers δ condition
  have h (I : Input pairVertices (layerSupport S b rank)) (eq : I.rational.stop=51/100) : condition I := by
    have size : I.order.length=m := by
      rw [←List.toFinset_card_of_nodup I.distinct,I.cover]
    have bounds := grid_sampler_limits m K (g.scale_pos rank)
    refine ⟨eq,size,?_,?_⟩
    · simpa only [fuel,eq,size] using bounds.1
    · simpa only [attempts,fuel,eq,size] using bounds.2
  exact ⟨h _ rfl,h _ rfl⟩

end
end SubmodularMatching.NonmonotoneCandidate.GridRow
