import SubmodularMatching.LowerBoundWitnessValue

/-! # Completeness under the actual mixed law -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly LowerBoundSoundness
open scoped BigOperators

noncomputable section

variable {p N P t H : ℕ} {C : Type*} [Fintype C] [DecidableEq C] [AddCommGroup C]

/-- Group the hidden tuples and hidden labels before the two thinning steps. -/
abbrev WitnessSide (p P t : ℕ) (C : Type*) :=
  (Fin p → Fin P → Fin t) × (Fin p → C)

abbrev WitnessSamples (p N P : ℕ) (C : Type*) :=
  Fin p → ((Fin P → PhaseSample N) × (PaddedPair N → Finset (C × C)))

def witnessDrawEquiv (p N P t : ℕ) (C : Type*) :
    HardDraw p N P t C ≃ WitnessSide p P t C × WitnessSamples p N P C where
  toFun d := ((fun j => (d.1 j).1, fun j => (d.2 j).2),
    fun j => ((d.1 j).2, (d.2 j).1))
  invFun s := (fun j => (s.1.1 j, (s.2 j).1), fun j => ((s.2 j).2, s.1.2 j))
  left_inv := fun _ => rfl
  right_inv := fun _ => rfl

/-- Tuples and labels are sampled uniformly and independently. -/
def witnessSideMass (_ : WitnessSide p P t C) : ℝ :=
  (∏ _i : Fin p, 1 / (Fintype.card (Fin P → Fin t) : ℝ)) *
  (∏ _i : Fin p, 1 / (Fintype.card C : ℝ))

omit [DecidableEq C] in
theorem witnessSideMass_nonneg (side : WitnessSide p P t C) : 0 ≤ witnessSideMass side :=
  mul_nonneg (Finset.prod_nonneg (fun _ _ => by positivity))
    (Finset.prod_nonneg (fun _ _ => by positivity))

omit [DecidableEq C] in
theorem witnessSideMass_total [Nonempty (Fin t)] :
    ∑ side : WitnessSide p P t C, witnessSideMass side = 1 := by
  have htuple0 : (Fintype.card (Fin P → Fin t) : ℝ) ≠ 0 := by positivity
  have hlabel0 : (Fintype.card C : ℝ) ≠ 0 := by positivity
  have htuple : (∑ _S : Fin p → Fin P → Fin t,
      ∏ _i : Fin p, 1 / (Fintype.card (Fin P → Fin t) : ℝ)) = 1 := by
    rw [← Fintype.prod_sum (fun (_ : Fin p) (_ : Fin P → Fin t) =>
      (1 : ℝ) / Fintype.card (Fin P → Fin t))]
    simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one_div, div_self htuple0, Finset.prod_const_one]
  have hlabel : (∑ _S : Fin p → C, ∏ _i : Fin p, 1 / (Fintype.card C : ℝ)) = 1 := by
    rw [← Fintype.prod_sum (fun (_ : Fin p) (_ : C) => (1 : ℝ) / Fintype.card C)]
    simp [hlabel0, nsmul_eq_mul]
  rw [Fintype.sum_prod_type]
  simp only [witnessSideMass, ← Finset.mul_sum, hlabel, mul_one, htuple]

omit [AddCommGroup C] in
theorem hardDrawMass_eq_witnessStageLaw (b : BlueprintExpansion N P t H)
    (δb δl : ℝ) (side : WitnessSide p P t C) (samples : WitnessSamples p N P C) :
    hardDrawMass b (1 - δb) (1 - δl) ((witnessDrawEquiv p N P t C).symm (side, samples)) =
      witnessSideMass side *
        independentStageMass (fun z sample =>
          independentSubsetMass (b.phases (side.1 z))
            (fun i => retainedSize (1 - δb) (b.phases (side.1 z) i).card) sample.1 *
          independentSubsetMass (allCloneSlots N C)
            (fun _ => retainedSize (1 - δl) (Fintype.card C ^ 2)) sample.2) samples := by
  have he : (witnessDrawEquiv p N P t C).symm (side, samples) =
      (fun j => (side.1 j, (samples j).1), fun j => ((samples j).2, side.2 j)) := rfl
  rw [he]
  unfold hardDrawMass baseDrawMass stageDrawMass witnessSideMass independentStageMass
  simp only [phaseRetainedMass, independentSubsetMass, allCloneSlots, Finset.card_univ,
    Fintype.card_prod, pow_two, Finset.prod_mul_distrib, div_eq_mul_inv, one_mul]
  ring

/-- Empty phases can be padded for the concentration proof. The
original retention law will still draw the empty subset in that phase. -/
def padEmptyPhase {E : Type*} [DecidableEq E] (extra : E) (S : Finset E) : Finset E :=
  if S = ∅ then {extra} else S

theorem padEmptyPhase_nonempty {E : Type*} [DecidableEq E] (extra : E) (S : Finset E) :
    (padEmptyPhase extra S).Nonempty := by
  unfold padEmptyPhase
  split_ifs with h
  · simp
  · exact Finset.nonempty_iff_ne_empty.mpr h

theorem padEmptyPhase_subset {E : Type*} [DecidableEq E] (extra : E) (S : Finset E) :
    S ⊆ padEmptyPhase extra S := by
  unfold padEmptyPhase
  split_ifs with h
  · simp [h]
  · exact subset_rfl

theorem padEmptyPhase_law_eq {E : Type*} [DecidableEq E] (extra : E)
    (S sample : Finset E) (q : ℝ) (hq : q < 1) :
    uniformSubsetMass (padEmptyPhase extra S) (retainedSize q (padEmptyPhase extra S).card) sample =
      uniformSubsetMass S (retainedSize q S.card) sample := by
  by_cases h : S = ∅
  · subst S
    have hq0 : retainedSize q 1 = 0 := by simpa [retainedSize] using (Nat.floor_eq_zero.mpr hq)
    simp [padEmptyPhase, uniformSubsetMass, retainedSize, Nat.floor_eq_zero.mpr hq]
  · simp [padEmptyPhase, h]

/-- Finite completeness of all actual stages, with the exact two Chebyshev
error terms. The input law is `hardDrawMass`, including the base tuple and
each stage's independently chosen distinguished label. -/
theorem hardComplete_failure_le [Nonempty (Fin t)]
    (b : BlueprintExpansion N P t H) (δb δl γ ξ : ℝ)
    (hb : 0 < δb) (hl : 0 ≤ δl) (hγ : 0 < γ)
    (hξ : δb + δl + 3 * γ ≤ ξ) (hξ1 : ξ < 1)
    (hgap : 0 < γ * (H : ℝ) - P)
    (hlarge : 1 ≤ γ * (Fintype.card C : ℝ) ^ 2) :
    eventMass (hardDrawMass b (1 - δb) (1 - δl)) (fun d : HardDraw p N P t C =>
      ¬hardComplete b ξ d) ≤ (p : ℝ) *
        ((H : ℝ) / (4 * (γ * (H : ℝ) - P) ^ 2) +
          (hardNormalizer C N H : ℝ) / (4 * (γ * (hardNormalizer C N H : ℝ)) ^ 2)) := by
  classical
  let Z := WitnessSide p P t C
  let S := WitnessSamples p N P C
  let Q (z : Z) (j : Fin p) := canonicalTagged b (z.1 j)
  let W (z : Z) (j : Fin p) (x : Fin P → PhaseSample N) := witnessBeforeClone b (z.1 j) x (z.2 j)
  have hK : 0 < Fintype.card C := Fintype.card_pos
  have hH : 0 < H := by
    by_contra! hh
    have hh' : H = 0 := by omega
    simp [hh'] at hgap
    exact (not_lt_of_ge (Nat.cast_nonneg P : (0 : ℝ) ≤ P)) hgap
  let J : Fin P → Fin t := fun _ => Classical.choice inferInstance
  have hHN : H ≤ N := by
    rw [← b.canonical_card J, ← Finset.card_image_iff.mpr (b.canonical_matching J).1]
    simpa only [Fintype.card_fin] using Finset.card_le_univ ((b.canonical J).image Prod.fst)
  let zero : Fin N := ⟨0, hH.trans_le hHN⟩
  let U (z : Z) (j : Fin p) (i : Fin P) := padEmptyPhase (zero, zero) (b.phases (z.1 j) i)
  have hUlaw (z : Z) (j : Fin p) (sample : Fin P → PhaseSample N) :
      independentSubsetMass (U z j) (fun i => retainedSize (1 - δb) (U z j i).card) sample =
      independentSubsetMass (b.phases (z.1 j))
        (fun i => retainedSize (1 - δb) (b.phases (z.1 j) i).card) sample := by
    unfold independentSubsetMass
    apply Finset.prod_congr rfl
    intro i _
    exact padEmptyPhase_law_eq (zero, zero) _ _ (1 - δb) (by linarith)
  have hHB : 0 < H + 2 * (N - H) := by omega
  have h := all_stage_thinnings_failure_le (I := Fin P) (Stage := Fin p)
    (Side := Z) witnessSideMass witnessSideMass_nonneg witnessSideMass_total U Q
    (fun z j e he => by
      have he' := (Finset.mem_filter.mp (canonicalTagged_subset b (z.1 j) he)).2
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,
        padEmptyPhase_subset (zero, zero) _ he'⟩)
    (fun z j i => Finset.card_pos.mpr (padEmptyPhase_nonempty (zero, zero) _))
    (fun _ _ => allCloneSlots N C) W (fun _ _ _ => by simp [taggedSample, allCloneSlots])
    H (2 * (N - H)) (Fintype.card C) hK hHB
    (fun z j => canonicalTagged_card b (z.1 j))
    (fun _ _ _ => by simp [allCloneSlots, Fintype.card_prod, pow_two])
    (fun z j samples => witnessBeforeClone_card b (z.1 j) samples (z.2 j))
    δb δl γ ξ hb.le hl hγ hξ hξ1
    (by simpa using hgap) hlarge
  dsimp only at h
  simp only [Fintype.card_fin, ← Nat.cast_add, ← Nat.cast_mul] at h
  refine le_trans ?_ h
  unfold eventMass
  let eqv := witnessDrawEquiv p N P t C
  refine le_of_eq (Fintype.sum_equiv eqv _ _ ?_)
  intro draw
  have hfactor := hardDrawMass_eq_witnessStageLaw b δb δl (eqv draw).1 (eqv draw).2
  rw [← Prod.eta (eqv draw), Equiv.symm_apply_apply] at hfactor
  have htest : (¬hardComplete b ξ draw) ↔ ∃ i : Fin p,
      (((W (eqv draw).1 i ((eqv draw).2 i).1 ∩ taggedSample ((eqv draw).2 i).2).card : ℝ) <
        (1 - ξ) * ((Fintype.card C : ℝ) * (H + (2 * (N - H) : ℕ) : ℝ))) := by
    simp only [hardComplete, not_forall, not_le, hardNormalizer, Nat.cast_mul, Nat.cast_add]
    rfl
  simp only [htest, hfactor, Nat.cast_mul, Nat.cast_add, hUlaw]

end

end SubmodularMatching.LowerBoundGlobal
