import SubmodularMatching.NonmonotoneOutputSound
import SubmodularMatching.CapacitySignedCommonResources

/-! The public inverse-polynomial confidence uses polynomial sample counts
and logarithmically many independent repetitions of the retained bank. -/
namespace SubmodularMatching.AppendixM
open Capacity UpperBoundAssembly Streaming Streaming.OracleQuery
noncomputable section

theorem sourceFailureBudget_polynomial (n : ℕ) (c : ℝ) :
    sourceFailureBudget (confidenceTarget n c) ≤ 2000000000 + 2*(max 1 n)^⌈c⌉₊ := by
  unfold sourceFailureBudget confidenceTarget
  apply Nat.ceil_le.mpr
  push_cast
  let p : ℝ := (max 1 (n:ℝ))^⌈c⌉₊
  have hp : 0<p := pow_pos (zero_lt_one.trans_le (le_max_left _ _)) _
  have hi : 1/((p⁻¹)/2) = 2*p := by field_simp
  change 1/min outerError (p⁻¹/2) ≤ 2000000000+2*p
  rcases le_total outerError (p⁻¹/2) with h|h
  · rw [min_eq_left h,show 1/outerError=2000000000 from by norm_num [outerError,implementationUnit]]
    linarith
  · rw [min_eq_right h,hi]
    linarith

theorem postprocessCount_antitone (a b : ℝ) (ha : 0<a) (h : a≤b) :
    postprocessCount b ≤ postprocessCount a := by
  have hb : 0<b := ha.trans_le h
  have hrat : 2/b ≤ 2/a :=
    div_le_div_of_nonneg_left (by norm_num) ha h
  unfold postprocessCount
  exact Nat.ceil_mono (div_le_div_of_nonneg_right (Real.log_le_log (by positivity) hrat) trialSuccess_pos.le)

theorem postprocessCount_logarithmic (n : ℕ) (c : ℝ) :
    postprocessCount (confidenceTarget n c) ≤
      ⌈1/trialSuccess⌉₊*(Nat.clog 2 (max 1 n)*⌈c⌉₊+1) := by
  let r := max 1 n
  let p := ⌈c⌉₊
  let q := Nat.clog 2 r * p
  have hNat : r ≤ 2 ^ Nat.clog 2 r := Nat.le_pow_clog (by decide : 1 < 2) r
  have hr : (0:ℝ)<r := by dsimp [r]; positivity
  have hreal : (r:ℝ) ≤ (2:ℝ)^Nat.clog 2 r := by exact_mod_cast hNat
  have hP : (r:ℝ)^p ≤ (2:ℝ)^q := by
    change (r:ℝ)^p≤(2:ℝ)^(Nat.clog 2 r*p)
    rw [pow_mul]
    exact pow_le_pow_left₀ hr.le hreal p
  have ht : ((2:ℝ)^q)⁻¹ ≤ confidenceTarget n c := by
    change ((2:ℝ)^q)⁻¹ ≤ ((r:ℝ)^p)⁻¹
    exact (inv_le_inv₀ (by positivity : (0:ℝ)<(2:ℝ)^q) (pow_pos hr p)).2 hP
  exact (postprocessCount_antitone _ _ (by positivity) ht).trans (inverse_polynomial_repetitions q)

end
end SubmodularMatching.AppendixM
