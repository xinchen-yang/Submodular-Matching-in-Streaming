import SubmodularMatching.UpperBoundK1PhysicalRuntime
import SubmodularMatching.StreamingK1Space

/-! # Simultaneous storage for the actual K.1 archive and one trial -/

namespace SubmodularMatching.UpperBoundAssembly.K1ProgramInput

open Streaming Joint

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]
variable {a : K1Parameters} (I : K1ProgramInput a E V)

/-- Preparing the final optimizer points preserves the reached physical
source archive, on every outcome of the actual samplewise execution. -/
theorem archivedPreparation_state_mem (ω : ℝ) (t : I.ArchivedPreparation)
    (ht : t ∈ (I.archivedPreparation ω).outcomes) : t.state ∈ (I.freshSource ω).outcomes := by
  classical
  unfold archivedPreparation at ht
  obtain ⟨st, _, hpoint⟩ := (CandidateLaw.mem_bind _ _ _).mp ht
  unfold prepareArchivedState CandidateLaw.map at hpoint
  obtain ⟨_, _, rfl⟩ := Finset.mem_image.mp hpoint
  exact st.property

/-- All archived guesses, their frozen optimizer points, the current
guess's actual scratch arrays and a feasible incumbent fit the word and
integer bit bounds of Appendix K.1. -/
theorem archivedWorkspace_le (ω : ℝ)
    (hspan : I.P.span = Nat.clog 2 ((I.P.vertices * a.k + 1) / 2))
    (t : I.ArchivedPreparation) (ht : t ∈ (I.archivedPreparation ω).outcomes)
    (M incumbent : Finset E) (hM : IsMatchingOn (endpointSet I.P.ends) M)
    (hmax : ∀ A : Finset E, IsMatchingOn (endpointSet I.P.ends) A → A.card ≤ M.card)
    (hincumbent : IsMatchingOn (endpointSet I.P.ends) incumbent)
    (j : ArchivedActive t.state) (wordMultiplier : ℕ) :
    let w := (I.P.vertices + 1).log2 + 1
    let incidence := k1IncidenceBound a.rates a.k a.k_large a.p a.p_pos
      a.minimumRate a.minimumRate_pos a.minimumRate_le a.growth
    let guesses := 3 + a.k.log2
    let C := 288 * incidence * guesses + 48 * guesses + 50
    let scratch := sequentialGuessScratch (Fintype.card (IncidentVertex (I.archivedEnds j))) (archivedSize j)
    let cells := t.state.postprocessWorkspace scratch incumbent.card
    cells ≤ C * (M.card + 1) * w ^ 2 ∧
      cells * wordMultiplier * w ≤ (C * wordMultiplier) * (M.card + 1) * w ^ 3 := by
  intro w incidence guesses C scratch cells
  have hN : 0 < I.Ns ω := Nat.succ_pos _
  have hstate := I.freshSource_support ω (I.archivedPreparation_state_mem ω t ht)
  have hinc (tau : ℝ) (htau : 0 < tau) : (I.P.config tau).incidenceLimit ≤ incidence * w := by
    rw [I.configuration]
    exact k1GuessConfig_incidence_le a.rates a.k a.k_large a.p a.p_pos
      a.minimumRate a.minimumRate_pos a.minimumRate_le a.growth
      I.P.vertices I.atLeastTwo tau htau
  have hguesses : I.P.span + 1 ≤ guesses * w := by
    rw [hspan]
    exact k1GuessSpan_le I.P.vertices a.k
  exact RealSource.freshPrefix_postprocessWorkspace_le I.P I.onlineGrid a.p
    I.width_one_le I.onlineGrid_matches hN I.P.arrivals le_rfl I.noRepeat
    incidence guesses Finset.univ M (fun _ _ => Finset.mem_univ _)
    (fun e _ => I.loopless e) (Finset.subset_univ M) hM (fun A _ => hmax A)
    t.state hstate incumbent.card (hmax _ hincumbent) (I.archivedEnds j) j.val le_rfl
    wordMultiplier hinc hguesses

end

end SubmodularMatching.UpperBoundAssembly.K1ProgramInput
