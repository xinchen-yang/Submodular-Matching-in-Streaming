import SubmodularMatching.UpperBoundParametricQueries
import SubmodularMatching.UpperBoundVertexRuntime

/-! # Polynomial visits for the exact fixed-accuracy family schedules -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint NumericalCertificate GibbsSampler
open scoped BigOperators

noncomputable section

variable {slack : ℝ} (a : FamilyParameters slack)
variable {m : ℕ} {V : Type*} [DecidableEq V]

/-- Whole Euler pass for the exact packing stage count and solver schedule. -/
theorem parametricPacking_visits_all_stages (hm : 0 < m) (ends : Fin m → V × V) :
    let v := Fintype.card (IncidentVertex ends)
    let K := FiniteGreedy.stages NumericalCertificate.degree m a.error
    let J := LinearPacking.iterationCount (v + (v + m)) (m + m) (a.error / 8)
    K * J * compactDirectionScalarVisits v m ≤
      ((2*a.K+1) * (160000 * (8*a.K) ^ 4 + 1) * 19) * (m + 1) ^ 11 := by
  intro v K J
  have hK := parametricOptimizer_stages_le a.K a.K_pos m
  have hJ := (parametricPacking_loop_bounds a.K a.K_pos hm ends).2.1
  simp only [Fintype.card_sum, Fintype.card_fin] at hJ
  have hs : compactDirectionScalarVisits v m ≤ 19 * (m + 1) :=
    (compactDirectionScalarVisits_le ends).trans (Nat.mul_le_mul_left _ (Nat.le_succ _))
  calc
    _ ≤ ((2*a.K+1) * (m + 1) ^ 2) * ((160000 * (8*a.K) ^ 4 + 1) * (m + 1) ^ 8) *
        (19 * (m + 1)) := Nat.mul_le_mul (Nat.mul_le_mul hK hJ) hs
    _ = _ := by ring

/-- Compact preparation over all the final guesses satisfies the
manuscript's degree-22 arithmetic-visit bound before accounting for the
logarithmic number of guesses. -/
theorem allParametricPacking_visits_le {G : Type*} [Fintype G]
    (n L : ℕ) (stored : G → ℕ) (ends : (j : G) → Fin (stored j) → V × V)
    (hL : Fintype.card G ≤ L) (hm : ∀ j, 0 < stored j ∧ stored j ≤ n ^ 2) :
    let C := (2*a.K+1) * (160000 * (8*a.K) ^ 4 + 1) * 19
    (∑ j : G,
      let t := stored j
      let v := Fintype.card (IncidentVertex (ends j))
      let K := FiniteGreedy.stages NumericalCertificate.degree t a.error
      let J := LinearPacking.iterationCount (v + (v + t)) (t + t) (a.error / 8)
      K * J * compactDirectionScalarVisits v t) ≤ L * C * (n + 1) ^ 22 := by
  intro C
  have h (j : G) : stored j + 1 ≤ (n + 1) ^ 2 := by nlinarith only [(hm j).2, Nat.zero_le n]
  calc
    _ ≤ ∑ _j : G, C * (n + 1) ^ 22 := by
      apply Finset.sum_le_sum
      intro j _
      exact (parametricPacking_visits_all_stages a (hm j).1 (ends j)).trans (by
        calc
          _ ≤ C * ((n + 1) ^ 2) ^ 11 := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (h j) _)
          _ = _ := by ring)
    _ = Fintype.card G * (C * (n + 1) ^ 22) := by simp
    _ ≤ L * (C * (n + 1) ^ 22) := Nat.mul_le_mul_right _ hL
    _ = _ := by ring


/-- Simultaneous arithmetic count of all actual rounded candidates,
including the integer confidence repetitions on the same stored graphs. -/
theorem parametricAllRoundingVisits_le {Guess : Type*} [Fintype Guess]
    (n c : ℕ) (stored : Guess → ℕ) (ends : (i : Guess) → Fin (stored i) → V × V)
    (hcard : Fintype.card Guess ≤ Nat.clog 2 (n * a.K) + 1)
    (hstored : ∀ i, 0 < stored i ∧ stored i ≤ n ^ 2)
    (active : (i : Guess) → Fin (a.trials (((n : ℝ) ^ c)⁻¹)) → ℕ)
    (ha : ∀ i j, active i j ≤ stored i) :
    let w := (n + 1).log2 + 1
    let coefficient := (parametricGuessCountConstant a) * (parametricTrialCountConstant a c) *
      (parametricRoundVisitConstant a.K)
    (∑ i : Guess, ∑ j, parametricRoundVisitBudget a.K (Fintype.card (IncidentVertex (ends i)))
      (stored i) (active i j)) ≤ coefficient * (n + 1) ^ 16 * w ^ 2 := by
  intro w coefficient
  let T := a.trials (((n : ℝ) ^ c)⁻¹)
  let C := (parametricRoundVisitConstant a.K)
  have hT : T ≤ (parametricTrialCountConstant a c) * w := parametricTrials_le a n c
  have hL : Fintype.card Guess ≤ (parametricGuessCountConstant a) * w :=
    hcard.trans (parametricGuessCount_le a n)
  have hsize (i : Guess) : stored i + 1 ≤ (n + 1) ^ 2 := by
    nlinarith only [(hstored i).2, Nat.zero_le n]
  have h (i : Guess) (j : Fin T) : parametricRoundVisitBudget a.K (Fintype.card (IncidentVertex (ends i)))
      (stored i) (active i j) ≤ C * (n + 1) ^ 16 := by
    have hl := parametricRoundVisitBudget_le a.K _ _ _ a.K_pos (incidentVertex_card_pos (hstored i).1 (ends i))
      (incidentVertex_card_le (ends i)) (ha i j)
    refine hl.trans ?_
    calc
      _ ≤ C * ((n + 1) ^ 2) ^ 8 := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (hsize i) _)
      _ = _ := by ring
  calc
    _ ≤ ∑ _i : Guess, ∑ _j : Fin T, C * (n + 1) ^ 16 :=
      Finset.sum_le_sum (fun i _ => Finset.sum_le_sum (fun j _ => h i j))
    _ = Fintype.card Guess * (T * (C * (n + 1) ^ 16)) := by simp
    _ ≤ ((parametricGuessCountConstant a) * w) *
        (((parametricTrialCountConstant a c) * w) * (C * (n + 1) ^ 16)) :=
      Nat.mul_le_mul hL (Nat.mul_le_mul_right _ hT)
    _ = _ := by dsimp only [coefficient, C]; ring

/-- The number of finite scalar visits in the direction solves and
scalar discount recurrence across every actual final guess. -/
theorem parametricAllDirectionVisits_le {Guess : Type*} [Fintype Guess]
    (n : ℕ) (stored : Guess → ℕ) (ends : (i : Guess) → Fin (stored i) → V × V)
    (hcard : Fintype.card Guess ≤ Nat.clog 2 (n * a.K) + 1)
    (hstored : ∀ i, 0 < stored i ∧ stored i ≤ n ^ 2) :
    let w := (n + 1).log2 + 1
    let A := (2*a.K+1) * (160000 * (8*a.K) ^ 4 + 1) * 19
    let B := (2*a.K+1) ^ 2
    (∑ i : Guess,
      let m := stored i
      let v := Fintype.card (IncidentVertex (ends i))
      let K := FiniteGreedy.stages NumericalCertificate.degree m a.error
      let J := LinearPacking.iterationCount (v + (v + m)) (m + m) (a.error / 8)
      K * J * compactDirectionScalarVisits v m + K ^ 2) ≤
        ((parametricGuessCountConstant a) * (A + B)) * (n + 1) ^ 22 * w := by
  intro w A B
  let L := Nat.clog 2 (n * a.K) + 1
  have hL : L ≤ (parametricGuessCountConstant a) * w := parametricGuessCount_le a n
  simp only [Finset.sum_add_distrib]
  have h := allParametricPacking_visits_le a n L stored ends hcard hstored
  have hhsize (i : Guess) : stored i + 1 ≤ (n + 1) ^ 2 := by
    nlinarith only [(hstored i).2, Nat.zero_le n]
  have hdisc (i : Guess) : (FiniteGreedy.stages NumericalCertificate.degree (stored i) a.error) ^ 2 ≤
      B * (n + 1) ^ 22 := by
    calc
      _ ≤ ((2*a.K+1) * (stored i + 1) ^ 2) ^ 2 :=
        Nat.pow_le_pow_left (parametricOptimizer_stages_le a.K a.K_pos (stored i)) _
      _ ≤ ((2*a.K+1) * ((n + 1) ^ 2) ^ 2) ^ 2 :=
        Nat.pow_le_pow_left (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (hhsize i) _)) _
      _ = B * (n + 1) ^ 8 := by dsimp only [B]; ring
      _ ≤ _ := Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) (by decide))
  have hd : (∑ i : Guess, (FiniteGreedy.stages NumericalCertificate.degree (stored i) a.error) ^ 2) ≤
      L * B * (n + 1) ^ 22 := by
    calc
      _ ≤ ∑ _i : Guess, B * (n + 1) ^ 22 := Finset.sum_le_sum (fun i _ => hdisc i)
      _ = Fintype.card Guess * (B * (n + 1) ^ 22) := by simp
      _ ≤ L * (B * (n + 1) ^ 22) := Nat.mul_le_mul_right _ hcard
      _ = _ := by ring
  calc
    _ ≤ L * A * (n + 1) ^ 22 + L * B * (n + 1) ^ 22 := Nat.add_le_add h hd
    _ = L * ((A + B) * (n + 1) ^ 22) := by ring
    _ ≤ ((parametricGuessCountConstant a) * w) * ((A + B) * (n + 1) ^ 22) := Nat.mul_le_mul_right _ hL
    _ = _ := by ring

private def familySourceQueryConstant (c : ℕ) : ℕ :=
  let Cs := c + 3 + (4 * (2 * (parametricGuessCountConstant a)) * (a.K + 2)).log2 + 1
  2 * (parametricGuessCountConstant a) * ((2 * a.K ^ 2) * Cs + 1) +
    (parametricGuessCountConstant a) * (parametricTrialCountConstant a c) + 2

private def familyGradientQueryConstant (c : ℕ) : ℕ :=
  let Cg := c + 7 + (4 * (2 * (parametricGuessCountConstant a)) * (2*a.K+1) *
    (a.K + 2)).log2 + 1
  2 * (parametricGuessCountConstant a) * (2*a.K+1) * (8 * (16*a.K) ^ 2 * Cg + 2)

/-- A constant depending on the chosen confidence exponent and fixed rates. -/
def parametricQueryBoundConstant (c : ℕ) : ℕ := familyGradientQueryConstant a c + familySourceQueryConstant a c

/-- The exact uniform query allocation, with an additive one for the
empty-set normalization and one per arrived singleton. -/
def parametricQueryCount {Guess : Type*} [Fintype Guess] (n arrivals c : ℕ) (stored : Guess → ℕ) : ℕ :=
  let L := Nat.clog 2 (n * a.K) + 1
  let δ := ((n : ℝ) ^ c)⁻¹
  let ω := min a.error (δ / 2)
  let N := parametricGradientSamples a.error (n ^ 2) L ω
  Fintype.card (Σ i : Guess,
      Fin (FiniteGreedy.stages NumericalCertificate.degree (stored i) a.error) ×
        Fin (stored i) × Fin N × Fin 2) +
    (1 + arrivals + 2 * arrivals * L * parametricSourceSamples a.error n L ω + L * a.trials δ)

theorem parametricQueryCount_le {Guess : Type*} [Fintype Guess] (n arrivals c : ℕ)
    (hn : 0 < n) (harrivals : arrivals ≤ n ^ 2) (stored : Guess → ℕ)
    (hGuess : Fintype.card Guess ≤ Nat.clog 2 (n * a.K) + 1)
    (hstored : ∀ i, stored i ≤ n ^ 2) :
    parametricQueryCount a n arrivals c stored ≤
      parametricQueryBoundConstant a c * (n + 1) ^ 10 * ((n + 1).log2 + 1) ^ 2 := by
  have hG := parametricGradientQueries_le a n c hn stored hGuess hstored
  have hR := parametricSourceAndRoundingQueries_le a n arrivals c hn harrivals
  let w := (n + 1).log2 + 1
  have hS : (n + 1) ^ 6 ≤ (n + 1) ^ 10 := Nat.pow_le_pow_right (by omega) (by decide)
  unfold parametricQueryCount
  calc
    _ ≤ familyGradientQueryConstant a c * (n + 1) ^ 10 * w ^ 2 +
        familySourceQueryConstant a c * (n + 1) ^ 6 * w ^ 2 := Nat.add_le_add hG hR
    _ ≤ familyGradientQueryConstant a c * (n + 1) ^ 10 * w ^ 2 +
        familySourceQueryConstant a c * (n + 1) ^ 10 * w ^ 2 :=
      Nat.add_le_add_left (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ hS)) _
    _ = _ := by unfold parametricQueryBoundConstant; ring

private def familyDirectionVisitConstant : ℕ :=
  (parametricGuessCountConstant a) * ((2*a.K+1) * (160000 * (8*a.K) ^ 4 + 1) * 19 + (2*a.K+1) ^ 2)

private def familyRoundingVisitConstant (c : ℕ) : ℕ :=
  (parametricGuessCountConstant a) * (parametricTrialCountConstant a c) * (parametricRoundVisitConstant a.K)

/-- A fixed scalar-visit multiplier for the chosen confidence exponent. -/
def parametricVisitBoundConstant (c : ℕ) : ℕ :=
  familyDirectionVisitConstant a + 8 * parametricQueryBoundConstant a c + 2 * familyRoundingVisitConstant a c

/-- Arithmetic visits account for each actual compact direction solve,
scalar discount recurrence and rounding iteration. The query preparation
term permits four scans of an `n²`-size stored array per value query. -/
def parametricVisitCount {Guess : Type*} [Fintype Guess] (n arrivals c : ℕ) (stored : Guess → ℕ)
    (ends : (i : Guess) → Fin (stored i) → V × V)
    (active : (i : Guess) → Fin (a.trials (((n : ℝ) ^ c)⁻¹)) → ℕ) : ℕ :=
  (∑ i : Guess,
    let m := stored i
    let v := Fintype.card (IncidentVertex (ends i))
    let K := FiniteGreedy.stages NumericalCertificate.degree m a.error
    let J := LinearPacking.iterationCount (v + (v + m)) (m + m) (a.error / 8)
    K * J * compactDirectionScalarVisits v m + K ^ 2) +
  (4 * (n + 1) ^ 2 * parametricQueryCount a n arrivals c stored) +
  (∑ i : Guess, ∑ j, parametricRoundVisitBudget a.K (Fintype.card (IncidentVertex (ends i)))
    (stored i) (active i j))

theorem parametricVisitCount_le {Guess : Type*} [Fintype Guess] (n arrivals c : ℕ)
    (hn : 0 < n) (harrivals : arrivals ≤ n ^ 2) (stored : Guess → ℕ)
    (ends : (i : Guess) → Fin (stored i) → V × V)
    (active : (i : Guess) → Fin (a.trials (((n : ℝ) ^ c)⁻¹)) → ℕ)
    (hGuess : Fintype.card Guess ≤ Nat.clog 2 (n * a.K) + 1)
    (hstored : ∀ i, 0 < stored i ∧ stored i ≤ n ^ 2)
    (hactive : ∀ i j, active i j ≤ stored i) :
    parametricVisitCount a n arrivals c stored ends active ≤
      parametricVisitBoundConstant a c * (n + 1) ^ 22 * ((n + 1).log2 + 1) := by
  let w := (n + 1).log2 + 1
  have hw : w ≤ 2 * (n + 1) := by have h := Nat.log2_le_self (n + 1); dsimp [w]; omega
  have hD := parametricAllDirectionVisits_le a n stored ends hGuess hstored
  have hA := parametricAllRoundingVisits_le a n c stored ends hGuess hstored active hactive
  have hQ := parametricQueryCount_le a n arrivals c hn harrivals stored hGuess (fun i => (hstored i).2)
  have hS : 4 * (n + 1) ^ 2 * parametricQueryCount a n arrivals c stored ≤
      (4 * parametricQueryBoundConstant a c) * (n + 1) ^ 12 * w ^ 2 := by
    calc
      _ ≤ 4 * (n + 1) ^ 2 * (parametricQueryBoundConstant a c * (n + 1) ^ 10 * w ^ 2) :=
        Nat.mul_le_mul_left _ hQ
      _ = _ := by ring
  have h := appendix_arithmeticVisitBound (Cp := familyDirectionVisitConstant a)
    (Cs := 4 * parametricQueryBoundConstant a c) (Cr := familyRoundingVisitConstant a c) hw hD hS hA
  calc
    _ ≤ (familyDirectionVisitConstant a + 2 * (4 * parametricQueryBoundConstant a c) +
        2 * familyRoundingVisitConstant a c) * (n + 1) ^ 22 * w := h
    _ = _ := by unfold parametricVisitBoundConstant; ring

/-- Combine the family's exact query and visit counts with the simultaneous
storage bound from `parametricSourceWorkspace_le`. -/
theorem parametricResourceBounds {Guess : Type*} [Fintype Guess] (n arrivals c ν : ℕ)
    (hn : 0 < n) (harrivals : arrivals ≤ n ^ 2) (stored : Guess → ℕ)
    (ends : (i : Guess) → Fin (stored i) → V × V)
    (active : (i : Guess) → Fin (a.trials (((n : ℝ) ^ c)⁻¹)) → ℕ)
    (hGuess : Fintype.card Guess ≤ Nat.clog 2 (n * a.K) + 1)
    (hstored : ∀ i, 0 < stored i ∧ stored i ≤ n ^ 2)
    (hactive : ∀ i j, active i j ≤ stored i) (cells wordsPerCell : ℕ)
    (hWorkspace : cells ≤ (96 * (parametricIncidenceConstant a) * (parametricGuessCountConstant a) +
      8 * (parametricGuessCountConstant a) + 50) * (ν + 1) * ((n + 1).log2 + 1) ^ 2) :
    let w := (n + 1).log2 + 1
    let C := 96 * (parametricIncidenceConstant a) * (parametricGuessCountConstant a) + 8 * (parametricGuessCountConstant a) + 50
    parametricQueryCount a n arrivals c stored ≤ parametricQueryBoundConstant a c * (n + 1) ^ 10 * w ^ 2 ∧
      parametricVisitCount a n arrivals c stored ends active ≤ parametricVisitBoundConstant a c * (n + 1) ^ 22 * w ∧
      cells * wordsPerCell * w ≤ (C * wordsPerCell) * (ν + 1) * w ^ 3 := by
  exact ⟨parametricQueryCount_le a n arrivals c hn harrivals stored hGuess (fun i => (hstored i).2),
    parametricVisitCount_le a n arrivals c hn harrivals stored ends active hGuess hstored hactive,
    sequentialWorkspace_bitCapacity hWorkspace⟩


end

end SubmodularMatching.UpperBoundAssembly
