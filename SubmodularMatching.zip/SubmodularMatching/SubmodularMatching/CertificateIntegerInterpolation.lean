import SubmodularMatching.CertificateIntegerAxis

/-!
# Binary-search interpolation with integer cross-products

The input fraction denotes a coordinate in grid units, and the output
fraction denotes a height in grid units. Neither the search nor the
interpolation need rational normalization or fixed-width arithmetic.
-/

namespace SubmodularMatching.SourceCertificate

/-- A cell search comparing the coordinate fraction `n / d` with a
grid coordinate `k` by comparing the integers `n` and `d * k`. -/
def findScaledCell (knots : ℕ → ℕ) (n d : ℤ) (lo hi : ℕ) : ℕ :=
  if h : lo + 1 < hi then
    let mid := (lo + hi) / 2
    if n ≤ d * (knots mid : ℤ) then findScaledCell knots n d lo mid
    else findScaledCell knots n d mid hi
  else lo
termination_by hi - lo
decreasing_by all_goals omega

theorem findScaledCell_spec (knots : ℕ → ℕ) (n d : ℤ) (lo hi : ℕ)
    (hlo : d * (knots lo : ℤ) ≤ n) (hhi : n ≤ d * (knots hi : ℤ)) (hlt : lo < hi) :
    let i := findScaledCell knots n d lo hi
    lo ≤ i ∧ i < hi ∧ d * (knots i : ℤ) ≤ n ∧ n ≤ d * (knots (i + 1) : ℤ) := by
  dsimp only
  rw [findScaledCell]
  split
  · rename_i hsplit
    dsimp only
    let mid := (lo + hi) / 2
    have hmidL : lo < mid := by dsimp [mid]; omega
    have hmidU : mid < hi := by dsimp [mid]; omega
    by_cases h : n ≤ d * (knots mid : ℤ)
    · rw [if_pos h]
      obtain ⟨hl, hu, hs, ht⟩ := findScaledCell_spec knots n d lo mid hlo h hmidL
      exact ⟨hl, hu.trans hmidU, hs, ht⟩
    · rw [if_neg h]
      obtain ⟨hl, hu, hs, ht⟩ := findScaledCell_spec knots n d mid hi
        (le_of_lt (lt_of_not_ge h)) hhi hmidU
      exact ⟨hmidL.le.trans hl, hu, hs, ht⟩
  · rename_i hunsplit
    have heq : hi = lo + 1 := by omega
    exact ⟨le_rfl, hlt, hlo, heq ▸ hhi⟩
termination_by hi - lo
decreasing_by all_goals dsimp only [mid] at *; omega

/-- An integer numerator and positive denominator for the interpolated height
in grid units. Callers supply a positive coordinate denominator. -/
def integerInterpolate (count : ℕ) (knots height : ℕ → ℕ) (n d : ℤ) : ℤ × ℤ :=
  if n ≤ d * (knots 0 : ℤ) then ((height 0 : ℤ), 1)
  else if d * (knots count : ℤ) ≤ n then ((height count : ℤ), 1)
  else
    let i := findScaledCell knots n d 0 count
    let x₀ : ℤ := knots i
    let x₁ : ℤ := knots (i + 1)
    let h₀ : ℤ := height i
    let h₁ : ℤ := height (i + 1)
    (h₀ * (d * x₁ - n) + h₁ * (n - d * x₀), d * (x₁ - x₀))

noncomputable section

theorem interpolation_cross_product (n d x₀ x₁ h₀ h₁ g : ℝ)
    (hd : 0 < d) (hg : 0 < g) (horder : x₀ < x₁) :
    h₀ / g + (h₁ / g - h₀ / g) * (n / (d * g) - x₀ / g) / (x₁ / g - x₀ / g) =
      (h₀ * (d * x₁ - n) + h₁ * (n - d * x₀)) / ((d * (x₁ - x₀)) * g) := by
  have hx : x₁ - x₀ ≠ 0 := (sub_pos.mpr horder).ne'
  have hx' : x₁ / g - x₀ / g ≠ 0 := by
    rw [← sub_div]
    exact div_ne_zero hx hg.ne'
  field_simp
  ring

theorem integerInterpolate_sound (T : SourcePotentialTable) (b : Bool)
    (knots height : ℕ → ℕ) (gridScale : ℕ) (hg : 0 < gridScale)
    (hk : ∀ i ≤ T.count, T.realKnot i = (knots i : ℝ) / gridScale)
    (hh : ∀ i ≤ T.count, T.realHeight b i = (height i : ℝ) / gridScale)
    (n d : ℤ) (hd : 0 < d) :
    let evaluated := integerInterpolate T.count knots height n d
    0 < evaluated.2 ∧ T.value b ((n : ℝ) / ((d : ℝ) * (gridScale : ℝ))) =
      (evaluated.1 : ℝ) / ((evaluated.2 : ℝ) * gridScale) := by
  have hg' : (0 : ℝ) < gridScale := by exact_mod_cast hg
  have hd' : (0 : ℝ) < (d : ℝ) := by exact_mod_cast hd
  let x := (n : ℝ) / ((d : ℝ) * (gridScale : ℝ))
  have hle (k : ℕ) (hkn : k ≤ T.count) (h : n ≤ d * (knots k : ℤ)) :
      x ≤ T.realKnot k := by
    have h' : (n : ℝ) ≤ (d : ℝ) * (knots k : ℝ) := by exact_mod_cast h
    rw [hk k hkn]
    dsimp only [x]
    apply (div_le_iff₀ (mul_pos hd' hg')).2
    convert h' using 1
    field_simp
  have hge (k : ℕ) (hkn : k ≤ T.count) (h : d * (knots k : ℤ) ≤ n) :
      T.realKnot k ≤ x := by
    have h' : (d : ℝ) * (knots k : ℝ) ≤ (n : ℝ) := by exact_mod_cast h
    rw [hk k hkn]
    dsimp only [x]
    apply (le_div_iff₀ (mul_pos hd' hg')).2
    convert h' using 1
    field_simp
  dsimp only
  change 0 < (integerInterpolate T.count knots height n d).2 ∧
    T.value b x = _ / (_ * (gridScale : ℝ))
  unfold integerInterpolate
  split
  · rename_i hc
    refine ⟨by norm_num, ?_⟩
    simp only [Int.cast_natCast, Int.cast_one]
    rw [SourcePotentialTable.value,
      realInterpolate_below T.count T.realKnot (T.realHeight b) T.ordered (hle 0 (Nat.zero_le _) hc),
      hh 0 (Nat.zero_le _), one_mul]
  · rename_i hn0
    split
    · rename_i hc
      refine ⟨by norm_num, ?_⟩
      simp only [Int.cast_natCast, Int.cast_one]
      rw [T.value_tail b x (hge T.count le_rfl hc), hh T.count le_rfl, one_mul]
    · rename_i hn1
      obtain ⟨_, hi, hx₀, hx₁⟩ := findScaledCell_spec knots n d 0 T.count
        (lt_of_not_ge hn0).le (lt_of_not_ge hn1).le T.positive_count
      let i := findScaledCell knots n d 0 T.count
      have hstep := T.ordered i hi
      rw [hk i hi.le, hk (i + 1) (Nat.succ_le_of_lt hi)] at hstep
      have horder : (knots i : ℝ) < (knots (i + 1) : ℝ) :=
        (div_lt_div_iff_of_pos_right hg').mp hstep
      have horderI : (knots i : ℤ) < (knots (i + 1) : ℤ) := by exact_mod_cast horder
      refine ⟨mul_pos hd (sub_pos.mpr horderI), ?_⟩
      rw [SourcePotentialTable.value, realInterpolate_cell _ _ _ T.ordered i hi x
        (hge i hi.le hx₀) (hle (i + 1) (Nat.succ_le_of_lt hi) hx₁),
        hh i hi.le, hh (i + 1) (Nat.succ_le_of_lt hi),
        hk i hi.le, hk (i + 1) (Nat.succ_le_of_lt hi)]
      dsimp [x, i]
      push_cast
      exact interpolation_cross_product _ _ _ _ _ _ _ hd' hg' horder

end

end SubmodularMatching.SourceCertificate
