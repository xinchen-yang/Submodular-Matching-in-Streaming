import SubmodularMatching.CapacityRealWordScheduler
import SubmodularMatching.CapacityStoredWordQuery
import SubmodularMatching.CapacityActiveStorage

/-! # Exact real marginal queries and integer accumulation in a surviving capacity guess -/

namespace SubmodularMatching.Capacity.RealOracle

open Streaming AppendixM

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def bankRaw {cap : V → ℕ} (st : SparseSlots E cap) (oracle : Finset E → ℝ) (e : E)
    (bits : ℕ) (draw : ℕ → ℕ → ℕ) (r : ℕ) : ℝ :=
  marginal oracle e (selectDyadic (fun i => (st.machine.edges.getD i (e,0)).1)
    (draw r) (dyadicThreshold sourceProbability bits) st.machine.edges.length)

theorem bankRaw_marginal {cap : V → ℕ} (st : SparseSlots E cap)
    (oracle : Finset E → ℝ) (e : E) (bits : ℕ) (draw : ℕ → ℕ → ℕ) (r : ℕ) :
    ∃ A, bankRaw st oracle e bits draw r = marginal oracle e A := ⟨_, rfl⟩

theorem slotWeight_sourceIndex {cap : V → ℕ} (st : SparseSlots E cap)
    (v N bits : ℕ) (oracle : Finset E → ℝ) (e : E) (τ : ℝ) (draw : ℕ → ℕ → ℕ) :
    slotWeight v N bits oracle τ e st draw =
      sourceWeightIndex N (sourceIndex ((streamTolerance : ℝ)*τ/(v:ℝ)^2)
        (fun r : Fin N => bankRaw st oracle e bits draw r)) := by
  simp only [slotWeight, RealSource.weightIndex, RealSource.accumulateMarginalLoop_eq, zero_add, bankRaw]

theorem slotWeight_le (cap : V → ℕ) (v N bits : ℕ) (hv : 2≤v) (hN : 0<N)
    (oracle : Finset E → ℝ) (hf : IsSubmodular oracle) (hn : ∀ A, 0 ≤ oracle A)
    (τ : ℝ) (ht : 0<τ) (e : E) (he : oracle {e} ≤ τ)
    (st : SparseSlots E cap) (draw : ℕ → ℕ → ℕ) :
    ((streamTolerance:ℝ)*τ/(v:ℝ)^2) * slotWeight v N bits oracle τ e st draw ≤ τ := by
  rw [slotWeight_sourceIndex, ←sourceWeight_eq_index]
  have hg : 0 < (streamTolerance:ℝ)*τ/(v:ℝ)^2 := by
    positivity [show (0:ℝ) < v by exact_mod_cast (show 0 < v by omega),
      show (0:ℝ) < streamTolerance by norm_num [streamTolerance]]
  apply (sourceWeight_signed_bounds _ _ _ hg hN ht.le ?_).2
  intro r
  obtain ⟨A, hA⟩ := bankRaw_marginal st oracle e bits draw r
  rw [hA, marginal,Finset.union_singleton]
  by_cases h : e ∈ A
  · simpa only [Finset.insert_eq_of_mem h, sub_self] using ht.le
  · have hu := diminishing_returns oracle hf ∅ A e (Finset.empty_subset _) h
    simp only [Finset.union_singleton] at hu
    rw [show insert e (∅ : Finset E) = {e} by ext x; simp] at hu
    linarith only [hu,he,hn ∅]

theorem active_tick_scale (W : ℝ) (span : ℕ) (values : ℕ → ℝ) (j k s : ℕ)
    (ha : guessActive W (guessAnchor W values k) (singletonMaximum values k) j)
    (hb : guessBirth W values j k < s) (hs : s ≤ k) :
    (RealSource.runOnlineEpoch W span values s).scale j = (RealSource.runOnlineEpoch W span values k).scale j := by
  have hx := (guess_active_since_birth W values j k ha hb hs).1
  simp only [RealSource.OnlineEpoch.scale, (RealSource.runOnlineEpoch_real W span values s).2,
    (RealSource.runOnlineEpoch_real W span values k).2, hx]

theorem active_edge_value (W : ℝ) (span : ℕ) (edges : ℕ → E) (oracle : Finset E → ℝ)
    (j k : ℕ) (ha : guessActive W (guessAnchor W (edgeClock edges oracle) (k+1))
        (singletonMaximum (edgeClock edges oracle) (k+1)) j)
    (i : ℕ) (hi : i<k) :
    oracle {edges i} ≤ (RealSource.runOnlineEpoch W span (edgeClock edges oracle) (k+1)).scale j := by
  have h := (singleton_le_maximum (edgeClock edges oracle) (i := i+1) (k := k+1) (by omega)).trans ha.2.1
  simpa only [RealSource.OnlineEpoch.scale, (RealSource.runOnlineEpoch_real W span _ (k+1)).2] using h

def bankPrefix (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0 < cap (ends e).1 ∧ 0 < cap (ends e).2)
    (v N bits : ℕ) (oracle : Finset E → ℝ) (edges : ℕ → E)
    (draw : ℕ → ℕ → ℕ → ℕ → ℕ) (b j : ℕ) : ℕ → SparseSlots E cap :=
  let ep := RealSource.runOnlineEpoch (guessWidth v) (guessSpan v) (edgeClock edges oracle)
  suffixRun (sparseEmpty cap) (fun i st => sparseStep ends cap hpos (wordGrid v) st (edges i)
    (slotWeight v N bits oracle ((ep (i+2)).scale j) (edges i) st (draw i j))) b

theorem active_bank_replay (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0 < cap (ends e).1 ∧ 0 < cap (ends e).2)
    (v N bits : ℕ) (hv : 2 ≤ v) (oracle : Finset E → ℝ) (edges : ℕ → E)
    (draw : ℕ → ℕ → ℕ → ℕ → ℕ) (k j : ℕ) :
    let W := (guessWidth v:ℝ)
    let q := seededScale (oracle ∅:ℝ) (fun i => (oracle {edges i}:ℝ))
    let ep := RealSource.runOnlineEpoch (guessWidth v) (guessSpan v) (edgeClock edges oracle)
    let τ := (ep (k+1)).scale j
    let b := signedBirth W (oracle ∅) (fun i => (oracle {edges i}:ℝ)) j k
    let run := bankPrefix ends cap hpos v N bits oracle edges draw b j
    let samples := fun i (r : Fin N) => (bankRaw (run i) oracle (edges (b+i)) bits (draw (b+i) j) r:ℝ)
    let gap := ((streamTolerance*τ/(v:ℝ)^2:ℝ):ℝ)
    let idx := fun i => (edges (b+i), sourceWeightIndex N (sourceIndex gap (samples i)))
    guessActive W (guessAnchor W q (k+1)) (singletonMaximum q (k+1)) j →
    (forwardBank ends cap hpos v N bits oracle edges draw k).lookup j = some (run (k-b)) ∧
      ∀ i ≤ k-b, run i = sparseRun ends cap hpos (wordGrid v) idx i := by
  intro W q ep τ b run samples gap idx ha
  refine ⟨forwardBank_suffix ends cap hpos v N bits hv oracle edges draw k j ha,?_⟩
  have hq : edgeClock edges oracle = q := by funext i; cases i <;> rfl
  intro i
  induction i with
  | zero => exact fun _ => rfl
  | succ i ih =>
    intro hi
    have hba : guessBirth W q j (k+1) < b+i+2 := by
      change guessBirth W q j (k+1) < guessBirth W q j (k+1)-1+i+2
      omega
    have hsc := active_tick_scale (guessWidth v) (guessSpan v) (edgeClock edges oracle) j
      (k+1) (b+i+2) (by rw [hq]; exact ha) (by rw [hq]; exact hba) (by omega)
    change sparseStep ends cap hpos (wordGrid v) (run i) (edges (b+i))
      (slotWeight v N bits oracle ((ep (b+i+2)).scale j) (edges (b+i)) (run i) (draw (b+i) j))
      = sparseStep ends cap hpos (wordGrid v) (sparseRun ends cap hpos (wordGrid v) idx i)
        (edges (b+i)) (idx i).2
    rw [show (ep (b+i+2)).scale j = τ from hsc, slotWeight_sourceIndex]
    change sparseStep ends cap hpos (wordGrid v) (run i) (edges (b+i)) (idx i).2 = _
    rw [ih (by omega)]

end

end SubmodularMatching.Capacity.RealOracle
