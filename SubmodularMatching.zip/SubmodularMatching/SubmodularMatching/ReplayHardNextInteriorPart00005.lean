import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step59 : ProjectedGoal ⟨567, 570, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x2380237e8d4a51000048049) (.x (.leaf 0x2380237e8d4a5100004804a) (.x (.leaf 0x2380237e8d4a5100004804b) (.x (.x (.leaf 0x2380237e8d4a51000048050) (.x (.y (.y (.leaf 0x2380237e8d4a51000049051) (.y (.leaf 0x2380237e8d4a5100004a051) (.y (.leaf 0x2380237e8d4a5100004b051) (.y (.m (.leaf 0x2370237e8d4a5100004c051) (.leaf 0x2380238e8d4a5100004c051)) (.leaf 0x2380237e8d4a5100004d051))))) (.leaf 0x2380237e8d4a5100004e051)) (.leaf 0x2380237e8d4a51000048052))) (.leaf 0x2380237e8d4a5100004804d))))) (.leaf 0x2380237e8d4a5100004804e)) (.x (.x (.leaf 0x23a0239e8d4a51000048049) (.x (.leaf 0x23a0239e8d4a5100004804a) (.x (.leaf 0x23a0239e8d4a5100004804b) (.x (.x (.leaf 0x23a0239e8d4a51000048050) (.x (.y (.y (.leaf 0x23a0239e8d4a51000049051) (.y (.leaf 0x23a0239e8d4a5100004a051) (.y (.leaf 0x23a0239e8d4a5100004b051) (.y (.m (.leaf 0x2390239e8d4a5100004c051) (.leaf 0x23a023ae8d4a5100004c051)) (.leaf 0x23a0239e8d4a5100004d051))))) (.leaf 0x23a0239e8d4a5100004e051)) (.leaf 0x23a0239e8d4a51000048052))) (.leaf 0x23a0239e8d4a5100004804d))))) (.leaf 0x23a0239e8d4a5100004804e))) (by decide +kernel)

private theorem step60 : ProjectedGoal ⟨571, 573, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x23c023be8d4a51000048049) (.x (.leaf 0x23c023be8d4a5100004804a) (.x (.leaf 0x23c023be8d4a5100004804b) (.x (.x (.leaf 0x23c023be8d4a51000048050) (.x (.y (.y (.leaf 0x23c023be8d4a51000049051) (.y (.leaf 0x23c023be8d4a5100004a051) (.y (.leaf 0x23c023be8d4a5100004b051) (.y (.m (.leaf 0x23b023be8d4a5100004c051) (.leaf 0x23c023ce8d4a5100004c051)) (.leaf 0x23c023be8d4a5100004d051))))) (.leaf 0x23c023be8d4a5100004e051)) (.leaf 0x23c023be8d4a51000048052))) (.leaf 0x23c023be8d4a5100004804d))))) (.leaf 0x23c023be8d4a5100004804e)) (.leaf 0x23d023de8d4a5100004800a)) (by decide +kernel)

private theorem step61 : ProjectedGoal ⟨567, 573, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 570 (by decide) (by decide) (step59 rates cones) (step60 rates cones)

private theorem step62 : ProjectedGoal ⟨574, 580, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0x23e023ee8d4a5100004800a) (.leaf 0x23f023fe8d4a5100004800a)) (.m (.leaf 0x2400240e8d4a5100004800a) (.leaf 0x2410241e8d4a5100004800a))) (.x (.x (.leaf 0x2440242e8d4a51000048049) (.x (.leaf 0x2440242e8d4a5100004804a) (.x (.leaf 0x2440242e8d4a5100004804b) (.x (.x (.leaf 0x2440242e8d4a51000048050) (.x (.y (.y (.leaf 0x2440242e8d4a51000049051) (.y (.leaf 0x2440242e8d4a5100004a051) (.y (.leaf 0x2440242e8d4a5100004b051) (.y (.m (.m (.leaf 0x2420242e8d4a5100004c051) (.leaf 0x2430243e8d4a5100004c051)) (.leaf 0x2440244e8d4a5100004c051)) (.leaf 0x2440242e8d4a5100004d051))))) (.leaf 0x2440242e8d4a5100004e051)) (.leaf 0x2440242e8d4a51000048052))) (.leaf 0x2440242e8d4a5100004804d))))) (.leaf 0x2440242e8d4a5100004804e))) (by decide +kernel)

private theorem step63 : ProjectedGoal ⟨567, 580, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 573 (by decide) (by decide) (step61 rates cones) (step62 rates cones)

private theorem step64 : ProjectedGoal ⟨581, 584, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x2460245e8d4a51000048049) (.x (.leaf 0x2460245e8d4a5100004804a) (.x (.leaf 0x2460245e8d4a5100004804b) (.x (.x (.leaf 0x2460245e8d4a51000048050) (.x (.y (.y (.leaf 0x2460245e8d4a51000049051) (.y (.leaf 0x2460245e8d4a5100004a051) (.y (.leaf 0x2460245e8d4a5100004b051) (.y (.m (.leaf 0x2450245e8d4a5100004c051) (.leaf 0x2460246e8d4a5100004c051)) (.leaf 0x2460245e8d4a5100004d051))))) (.leaf 0x2460245e8d4a5100004e051)) (.leaf 0x2460245e8d4a51000048052))) (.leaf 0x2460245e8d4a5100004804d))))) (.leaf 0x2460245e8d4a5100004804e)) (.x (.x (.leaf 0x2480247e8d4a51000048049) (.x (.leaf 0x2480247e8d4a5100004804a) (.x (.leaf 0x2480247e8d4a5100004804b) (.x (.x (.leaf 0x2480247e8d4a51000048050) (.x (.y (.y (.leaf 0x2480247e8d4a51000049051) (.y (.leaf 0x2480247e8d4a5100004a051) (.y (.leaf 0x2480247e8d4a5100004b051) (.y (.m (.leaf 0x2470247e8d4a5100004c051) (.leaf 0x2480248e8d4a5100004c051)) (.leaf 0x2480247e8d4a5100004d051))))) (.leaf 0x2480247e8d4a5100004e051)) (.leaf 0x2480247e8d4a51000048052))) (.leaf 0x2480247e8d4a5100004804d))))) (.leaf 0x2480247e8d4a5100004804e))) (by decide +kernel)

private theorem step65 : ProjectedGoal ⟨585, 587, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x24a0249e8d4a51000048049) (.x (.leaf 0x24a0249e8d4a5100004804a) (.x (.leaf 0x24a0249e8d4a5100004804b) (.x (.x (.leaf 0x24a0249e8d4a51000048050) (.x (.y (.y (.leaf 0x24a0249e8d4a51000049051) (.y (.leaf 0x24a0249e8d4a5100004a051) (.y (.leaf 0x24a0249e8d4a5100004b051) (.y (.m (.leaf 0x2490249e8d4a5100004c051) (.leaf 0x24a024ae8d4a5100004c051)) (.leaf 0x24a0249e8d4a5100004d051))))) (.leaf 0x24a0249e8d4a5100004e051)) (.leaf 0x24a0249e8d4a51000048052))) (.leaf 0x24a0249e8d4a5100004804d))))) (.leaf 0x24a0249e8d4a5100004804e)) (.leaf 0x24b024be8d4a5100004800a)) (by decide +kernel)

private theorem step66 : ProjectedGoal ⟨581, 587, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 584 (by decide) (by decide) (step64 rates cones) (step65 rates cones)

private theorem step67 : ProjectedGoal ⟨588, 590, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.x (.x (.leaf 0x24e024ce8d4a51000048049) (.x (.leaf 0x24e024ce8d4a5100004804a) (.x (.leaf 0x24e024ce8d4a5100004804b) (.x (.x (.leaf 0x24e024ce8d4a51000048050) (.x (.y (.y (.leaf 0x24e024ce8d4a51000049051) (.y (.leaf 0x24e024ce8d4a5100004a051) (.y (.leaf 0x24e024ce8d4a5100004b051) (.y (.m (.m (.leaf 0x24c024ce8d4a5100004c051) (.leaf 0x24d024de8d4a5100004c051)) (.leaf 0x24e024ee8d4a5100004c051)) (.leaf 0x24e024ce8d4a5100004d051))))) (.leaf 0x24e024ce8d4a5100004e051)) (.leaf 0x24e024ce8d4a51000048052))) (.leaf 0x24e024ce8d4a5100004804d))))) (.leaf 0x24e024ce8d4a5100004804e)) (by decide +kernel)

private theorem step68 : ProjectedGoal ⟨591, 593, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x250024fe8d4a51000048049) (.x (.leaf 0x250024fe8d4a5100004804a) (.x (.leaf 0x250024fe8d4a5100004804b) (.x (.x (.leaf 0x250024fe8d4a51000048050) (.x (.y (.y (.leaf 0x250024fe8d4a51000049051) (.y (.leaf 0x250024fe8d4a5100004a051) (.y (.leaf 0x250024fe8d4a5100004b051) (.y (.m (.leaf 0x24f024fe8d4a5100004c051) (.leaf 0x2500250e8d4a5100004c051)) (.leaf 0x250024fe8d4a5100004d051))))) (.leaf 0x250024fe8d4a5100004e051)) (.leaf 0x250024fe8d4a51000048052))) (.leaf 0x250024fe8d4a5100004804d))))) (.leaf 0x250024fe8d4a5100004804e)) (.leaf 0x2510251e8d4a5100004800a)) (by decide +kernel)

private theorem step69 : ProjectedGoal ⟨588, 593, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 590 (by decide) (by decide) (step67 rates cones) (step68 rates cones)

private theorem step70 : ProjectedGoal ⟨581, 593, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 587 (by decide) (by decide) (step66 rates cones) (step69 rates cones)

private theorem step71 : ProjectedGoal ⟨567, 593, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 580 (by decide) (by decide) (step63 rates cones) (step70 rates cones)

theorem Part00005 : ProjectedGoal ⟨567, 593, 0, 283, 0, 283⟩ := step71

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
