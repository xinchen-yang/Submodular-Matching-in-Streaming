import SubmodularMatching.CertificateCachedReplay

/-!
# Extrema of consecutive rates from monotone runs

A rate interval overlaps only a few monotone subsequences of the source
table. On each overlap, the two rates are bounded by their endpoint values.
-/

namespace SubmodularMatching.SourceCertificate

structure RateRun where
  lo : ℕ
  hi : ℕ
  highRises : Bool
  lowRises : Bool

def rateStepDirection (rises : Bool) (x y : ℕ) : Prop :=
  if rises then x ≤ y else y ≤ x

instance (rises : Bool) (x y : ℕ) : Decidable (rateStepDirection rises x y) := by
  unfold rateStepDirection
  infer_instance

def RateRun.step (r : RateRun) (a b : RawSourceMode) : Prop :=
  rateStepDirection r.highRises a.high b.high ∧ rateStepDirection r.lowRises a.low b.low

instance (r : RateRun) (a b : RawSourceMode) : Decidable (r.step a b) := by
  unfold RateRun.step
  infer_instance

def RateRun.Valid (r : RateRun) (row : ℕ → RawSourceMode) : Prop :=
  ∀ k, r.lo ≤ k → k < r.hi → r.step (row k) (row (k + 1))

theorem rateStepDirection_between (f : ℕ → ℕ) (rises : Bool) (lo hi : ℕ)
    (hstep : ∀ i, lo ≤ i → i < hi → rateStepDirection rises (f i) (f (i + 1)))
    (i j : ℕ) (hil : lo ≤ i) (hij : i ≤ j) (hjh : j ≤ hi) :
    rateStepDirection rises (f i) (f j) := by
  induction j with
  | zero =>
    have hi₀ : i = 0 := by omega
    subst i
    cases rises <;> simp [rateStepDirection]
  | succ j ih =>
    by_cases he : i = j + 1
    · rw [he]
      cases rises <;> simp [rateStepDirection]
    · have hij' : i ≤ j := by omega
      have h1 := ih hij' (by omega)
      have h2 := hstep j (by omega) (by omega)
      cases rises
      · exact h2.trans h1
      · exact h1.trans h2

theorem rate_between_of_steps (f : ℕ → ℕ) (rises : Bool) (lo hi k : ℕ)
    (hstep : ∀ i, lo ≤ i → i < hi → rateStepDirection rises (f i) (f (i + 1)))
    (hl : lo ≤ k) (hh : k ≤ hi) :
    min (f lo) (f hi) ≤ f k ∧ f k ≤ max (f lo) (f hi) := by
  have h1 := rateStepDirection_between f rises lo hi hstep lo k le_rfl hl hh
  have h2 := rateStepDirection_between f rises lo hi hstep k hi hl hh le_rfl
  cases rises
  · exact ⟨(min_le_right _ _).trans h2, h1.trans (le_max_left _ _)⟩
  · exact ⟨(min_le_left _ _).trans h1, h2.trans (le_max_right _ _)⟩

structure RateBoundsAB where
  amin : ℕ
  amax : ℕ
  bmin : ℕ
  bmax : ℕ
  deriving Inhabited

def RateBoundsAB.Bounds (bounds : RateBoundsAB) (p : RawSourceMode) : Prop :=
  bounds.amin ≤ p.high ∧ p.high ≤ bounds.amax ∧ bounds.bmin ≤ p.low ∧ p.low ≤ bounds.bmax

def RateBoundsAB.join (p q : RateBoundsAB) : RateBoundsAB :=
  ⟨min p.amin q.amin, max p.amax q.amax, min p.bmin q.bmin, max p.bmax q.bmax⟩

theorem RateBoundsAB.join_left (p q : RateBoundsAB) (m : RawSourceMode) (h : p.Bounds m) :
    (p.join q).Bounds m :=
  ⟨(min_le_left _ _).trans h.1, h.2.1.trans (le_max_left _ _),
    (min_le_left _ _).trans h.2.2.1, h.2.2.2.trans (le_max_left _ _)⟩

theorem RateBoundsAB.join_right (p q : RateBoundsAB) (m : RawSourceMode) (h : q.Bounds m) :
    (p.join q).Bounds m :=
  ⟨(min_le_right _ _).trans h.1, h.2.1.trans (le_max_right _ _),
    (min_le_right _ _).trans h.2.2.1, h.2.2.2.trans (le_max_right _ _)⟩

def RateRun.boundsAt (r : RateRun) (row : ℕ → RawSourceMode) (lo hi : ℕ) :
    Option RateBoundsAB :=
  let first := max r.lo lo
  let last := min r.hi hi
  if first ≤ last then
    let a := row first
    let b := row last
    some ⟨min a.high b.high, max a.high b.high, min a.low b.low, max a.low b.low⟩
  else none

theorem RateRun.boundsAt_sound (r : RateRun) (row : ℕ → RawSourceMode)
    (valid : r.Valid row) (lo hi k : ℕ) (hlo : lo ≤ k) (hhi : k ≤ hi)
    (hrl : r.lo ≤ k) (hrh : k ≤ r.hi) :
    ∃ b, r.boundsAt row lo hi = some b ∧ b.Bounds (row k) := by
  let l := max r.lo lo
  let h := min r.hi hi
  have kl : l ≤ k := max_le hrl hlo
  have kh : k ≤ h := le_min hrh hhi
  have hab (i : ℕ) (hi₁ : l ≤ i) (hi₂ : i < h) : r.step (row i) (row (i+1)) :=
    valid i ((le_max_left _ _).trans hi₁) (hi₂.trans_le (min_le_left _ _))
  have ha := rate_between_of_steps (fun i => (row i).high) r.highRises l h k
    (fun i hi₁ hi₂ => (hab i hi₁ hi₂).1) kl kh
  have hb := rate_between_of_steps (fun i => (row i).low) r.lowRises l h k
    (fun i hi₁ hi₂ => (hab i hi₁ hi₂).2) kl kh
  unfold boundsAt
  rw [if_pos (kl.trans kh)]
  exact ⟨_, rfl, ha.1, ha.2, hb.1, hb.2⟩

def rateJoinOptions : Option RateBoundsAB → Option RateBoundsAB → Option RateBoundsAB
  | none, b => b
  | a, none => a
  | some a, some b => some (a.join b)

def rateRunBounds (row : ℕ → RawSourceMode) (lo hi : ℕ) : List RateRun → Option RateBoundsAB
  | [] => none
  | r :: rs => rateJoinOptions (r.boundsAt row lo hi) (rateRunBounds row lo hi rs)

theorem rateRunBounds_of_member (row : ℕ → RawSourceMode) (lo hi k : ℕ)
    (runs : List RateRun) (r : RateRun) (mem : r ∈ runs) (valid : r.Valid row)
    (hlo : lo ≤ k) (hhi : k ≤ hi) (hrl : r.lo ≤ k) (hrh : k ≤ r.hi) :
    ∃ b, rateRunBounds row lo hi runs = some b ∧ b.Bounds (row k) := by
  induction runs with
  | nil => simp at mem
  | cons x xs ih =>
    rw [rateRunBounds]
    rcases List.mem_cons.mp mem with he | ht
    · subst x
      obtain ⟨a, ha, hab⟩ := r.boundsAt_sound row valid lo hi k hlo hhi hrl hrh
      rw [ha]
      cases rateRunBounds row lo hi xs with
      | none => exact ⟨a, rfl, hab⟩
      | some b => exact ⟨a.join b, rfl, a.join_left b _ hab⟩
    · obtain ⟨b, hb, hbb⟩ := ih ht
      rw [hb]
      cases x.boundsAt row lo hi with
      | none => exact ⟨b, rfl, hbb⟩
      | some a => exact ⟨a.join b, rfl, a.join_right b _ hbb⟩

theorem rateRunBounds_sound (row : ℕ → RawSourceMode) (lo hi k : ℕ)
    (runs : List RateRun) (inc : ∃ r ∈ runs, r.Valid row ∧ r.lo ≤ k ∧ k ≤ r.hi)
    (hlo : lo ≤ k) (hhi : k ≤ hi) :
    ((rateRunBounds row lo hi runs).getD default).Bounds (row k) := by
  obtain ⟨r, mem, valid, hrl, hrh⟩ := inc
  obtain ⟨b, hb, ok⟩ := rateRunBounds_of_member row lo hi k runs r mem valid hlo hhi hrl hrh
  rw [hb]
  exact ok

end SubmodularMatching.SourceCertificate
