import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step135 : ProjectedGoal ⟨486, 492, 0, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.leaf 0x1ec01e600e8d4a5105b33b8) (.y (.y (.y (.leaf 0x1ec01e6e8d4a5100059d59c) (.y (.m (.m (.y (.leaf 0x1e701e601d1a94a205b64fb) (.y (.y (.y (.m (.leaf 0x1e601e600e531527b5b94fc) (.leaf 0x1e701e700e8d4a5105ba4fb)) (.leaf 0x1e701e600000000005bb4f7)) (.leaf 0x1e701e600000000005bc4f7)) (.leaf 0x1e701e600000000005bd4f7))) (.y (.leaf 0x1e901e801d1a94a205b64fb) (.y (.y (.y (.m (.leaf 0x1e801e800e531527b5b94fc) (.leaf 0x1e901e900e8d4a5105ba4fb)) (.leaf 0x1e901e800000000005bb4f7)) (.leaf 0x1e901e800000000005bc4f7)) (.leaf 0x1e901e800000000005bd4f7)))) (.m (.y (.leaf 0x1eb01ea01d1a94a205b64fb) (.y (.y (.y (.m (.leaf 0x1ea01ea00e531527b5b94fc) (.leaf 0x1eb01eb00e8d4a5105ba4fb)) (.leaf 0x1eb01ea00000000005bb4f7)) (.leaf 0x1eb01ea00000000005bc4f7)) (.leaf 0x1eb01ea00000000005bd4f7))) (.y (.leaf 0x1ec01ec01d1a94a205b64fb) (.y (.leaf 0x1ec01ec00e531527b5be4fc) (.leaf 0x1ec01ec00000000005bd4f7))))) (.leaf 0x1ec01e600000000005a74f7))) (.leaf 0x1ec01e600000000005b04f7)) (.leaf 0x1ec01e600000000005b14f7))) (.leaf 0x1ec01e600000000005b21c9)) (.leaf 0x1ec01e600000000005b217f)) (by decide +kernel)

private theorem step136 : ProjectedGoal ⟨493, 499, 0, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.leaf 0x1f301ed00e8d4a5105b33b8) (.y (.y (.y (.leaf 0x1f301ede8d4a5100059d59c) (.y (.m (.m (.y (.leaf 0x1ee01ed01d1a94a205b64fb) (.y (.y (.y (.m (.leaf 0x1ed01ed00e8d4a5105ba4fb) (.leaf 0x1ee01ee00e531527b5b94fc)) (.leaf 0x1ee01ed00000000005bb4f7)) (.leaf 0x1ee01ed00000000005bc4f7)) (.leaf 0x1ee01ed00000000005bd4f7))) (.y (.leaf 0x1f001ef01d1a94a205b64fb) (.y (.y (.y (.m (.leaf 0x1ef01ef00e8d4a5105ba4fb) (.leaf 0x1f001f000e531527b5b94fc)) (.leaf 0x1f001ef00000000005bb4f7)) (.leaf 0x1f001ef00000000005bc4f7)) (.leaf 0x1f001ef00000000005bd4f7)))) (.y (.leaf 0x1f301f101d1a94a205b64fb) (.y (.y (.y (.m (.m (.leaf 0x1f101f100e8d4a5105ba4fb) (.leaf 0x1f201f200e531527b5b94fc)) (.leaf 0x1f301f300e8d4a5105ba4fb)) (.leaf 0x1f301f100000000005bb4f7)) (.leaf 0x1f301f100000000005bc4f7)) (.leaf 0x1f301f100000000005bd4f7)))) (.leaf 0x1f301ed00000000005a74f7))) (.leaf 0x1f301ed00000000005b04f7)) (.leaf 0x1f301ed00000000005b14f7))) (.leaf 0x1f301ed00000000005b21c9)) (.leaf 0x1f301ed00000000005b217f)) (by decide +kernel)

private theorem step137 : ProjectedGoal ⟨486, 499, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 492 (by decide) (by decide) (step135 rates cones) (step136 rates cones)

private theorem step138 : ProjectedGoal ⟨500, 512, 0, 8, 567, 851⟩ :=
  projectedGoal_chunk _ (.leaf 0x20001f400e8d4a5105b33b8) (by decide +kernel)

private theorem step139 : ProjectedGoal ⟨500, 512, 8, 17, 567, 638⟩ :=
  projectedGoal_chunk _ (.y (.leaf 0x20001f4e8d4a5100059d59c) (.y (.m (.m (.y (.leaf 0x1f701f401d1a94a205b64fb) (.y (.y (.y (.m (.m (.leaf 0x1f401f400e531527b5b94fc) (.leaf 0x1f501f500e8d4a5105ba4fb)) (.m (.leaf 0x1f601f600e531527b5b94fc) (.leaf 0x1f701f700e8d4a5105ba4fb))) (.leaf 0x1f701f400000000005bb4f7)) (.leaf 0x1f701f400000000005bc4f7)) (.leaf 0x1f701f400000000005bd4f7))) (.y (.leaf 0x1fa01f801d1a94a205b64fb) (.y (.y (.y (.m (.m (.leaf 0x1f801f800e702fbc55ba4fb) (.leaf 0x1f901f900e8d4a5105ba4fb)) (.leaf 0x1fa01fa00e702fbc55ba4fb)) (.leaf 0x1fa01f800000000005bb4f7)) (.leaf 0x1fa01f800000000005bc4f7)) (.leaf 0x1fa01f800000000005bd4f7)))) (.y (.leaf 0x20001fb01d1a94a205b64fb) (.y (.y (.m (.y (.m (.m (.leaf 0x1fb01fb00e8d4a5105ba4fb) (.leaf 0x1fc01fc00e702fbc55ba4fb)) (.leaf 0x1fd01fd00e8d4a5105ba4fb)) (.leaf 0x1fd01fb00000000005bb4f7)) (.m (.y (.m (.leaf 0x1fe01fe00e702fbc55ba4fb) (.leaf 0x1ff01ff00e8d4a5105ba4fb)) (.leaf 0x1ff01fe00000000005bb4f7)) (.leaf 0x200020000e61a27205bf4fc))) (.leaf 0x20001fb00000000005bc4f7)) (.leaf 0x20001fb00000000005bd4f7)))) (.leaf 0x20001f400000000005a74f7))) (by decide +kernel)

private theorem step140 : ProjectedGoal ⟨500, 512, 8, 17, 638, 709⟩ :=
  projectedGoal_chunk _ (.leaf 0x20001f400000000005b04f7) (by decide +kernel)

private theorem step141 : ProjectedGoal ⟨500, 512, 8, 17, 567, 709⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 638 (by decide) (by decide) (step139 rates cones) (step140 rates cones)

private theorem step142 : ProjectedGoal ⟨500, 512, 8, 17, 709, 851⟩ :=
  projectedGoal_chunk _ (.leaf 0x20001f400000000005b14f7) (by decide +kernel)

private theorem step143 : ProjectedGoal ⟨500, 512, 8, 17, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 709 (by decide) (by decide) (step141 rates cones) (step142 rates cones)

private theorem step144 : ProjectedGoal ⟨500, 512, 0, 17, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 8 (by decide) (by decide) (step138 rates cones) (step143 rates cones)

private theorem step145 : ProjectedGoal ⟨500, 512, 17, 35, 567, 851⟩ :=
  projectedGoal_chunk _ (.leaf 0x20001f400000000005b21c9) (by decide +kernel)

private theorem step146 : ProjectedGoal ⟨500, 512, 0, 35, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 17 (by decide) (by decide) (step144 rates cones) (step145 rates cones)

private theorem step147 : ProjectedGoal ⟨500, 512, 35, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.leaf 0x20001f400000000005b217f) (by decide +kernel)

private theorem step148 : ProjectedGoal ⟨500, 512, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 35 (by decide) (by decide) (step146 rates cones) (step147 rates cones)

private theorem step149 : ProjectedGoal ⟨486, 512, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 499 (by decide) (by decide) (step137 rates cones) (step148 rates cones)

private theorem step150 : ProjectedGoal ⟨513, 519, 0, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.leaf 0x207020100e8d4a5105b33b8) (.y (.y (.y (.leaf 0x2070201e8d4a5100059d59c) (.y (.y (.leaf 0x207020101d1a94a205b64fb) (.y (.y (.m (.m (.m (.leaf 0x201020100e8d4a5105bf4fb) (.leaf 0x202020200e61a27205bf4fc)) (.m (.leaf 0x203020300e8d4a5105bf4fb) (.leaf 0x204020400e61a27205bf4fc))) (.m (.m (.leaf 0x205020500e8d4a5105bf4fb) (.leaf 0x206020600e61a27205bf4fc)) (.leaf 0x207020700e8d4a5105bf4fb))) (.leaf 0x207020100000000005bc4f7)) (.leaf 0x207020100000000005bd4f7))) (.leaf 0x207020100000000005a74f7))) (.leaf 0x207020100000000005b04f7)) (.leaf 0x207020100000000005b14f7))) (.leaf 0x207020100000000005b21c9)) (.leaf 0x207020100000000005b217f)) (by decide +kernel)

private theorem step151 : ProjectedGoal ⟨520, 526, 0, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.leaf 0x20e020800e8d4a5105b33b8) (.y (.y (.y (.leaf 0x20e0208e8d4a5100059d59c) (.y (.m (.y (.leaf 0x20b020803a35294405b64f9) (.y (.y (.m (.m (.leaf 0x208020800e61a27205bf4fc) (.leaf 0x209020900e8d4a5105bf4fb)) (.m (.leaf 0x20a020a00e61a27205bf4fc) (.leaf 0x20b020b00e8d4a5105bf4fb))) (.leaf 0x20b020800000000005bc4f7)) (.leaf 0x20b020800000000005bd4f7))) (.y (.leaf 0x20e020c03a35294405b64f9) (.y (.y (.m (.m (.leaf 0x20c020c00e61a27205c04fc) (.leaf 0x20d020d00e8d4a5105bf4fb)) (.leaf 0x20e020e00e61a27205c04fc)) (.leaf 0x20e020c00000000005bc4f7)) (.leaf 0x20e020c00000000005bd4f7)))) (.leaf 0x20e020800000000005a74f7))) (.leaf 0x20e020800000000005b04f7)) (.leaf 0x20e020800000000005b14f7))) (.leaf 0x20e020800000000005b21c9)) (.leaf 0x20e020800000000005b217f)) (by decide +kernel)

private theorem step152 : ProjectedGoal ⟨513, 526, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 519 (by decide) (by decide) (step150 rates cones) (step151 rates cones)

private theorem step153 : ProjectedGoal ⟨527, 533, 0, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.leaf 0x215020f00e8d4a5105b33b8) (.y (.y (.y (.leaf 0x215020fe8d4a5100059d59c) (.y (.y (.leaf 0x215020f03a35294405b64f9) (.y (.y (.m (.m (.m (.leaf 0x20f020f00e8d4a5105bf4fb) (.leaf 0x210021000e61a27205c04fc)) (.m (.leaf 0x211021100e8d4a5105bf4fb) (.leaf 0x212021200e61a27205c04fc))) (.m (.m (.leaf 0x213021300e8d4a5105bf4fb) (.leaf 0x214021400e61a27205c04fc)) (.leaf 0x215021500e8d4a5105bf4fb))) (.leaf 0x215020f00000000005bc4f7)) (.leaf 0x215020f00000000005bd4f7))) (.leaf 0x215020f00000000005a74f7))) (.leaf 0x215020f00000000005b04f7)) (.leaf 0x215020f00000000005b14f7))) (.leaf 0x215020f00000000005b21c9)) (.leaf 0x215020f00000000005b217f)) (by decide +kernel)

private theorem step154 : ProjectedGoal ⟨534, 539, 0, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.leaf 0x21b021600e8d4a5105b33b8) (.y (.y (.y (.leaf 0x21b0216e8d4a5100059d59c) (.y (.y (.leaf 0x21b021603a35294405b64f9) (.y (.y (.m (.m (.m (.leaf 0x216021600e61a27205c04fb) (.leaf 0x217021700e8d4a5105bf4fb)) (.leaf 0x218021800e61a27205c04fb)) (.m (.m (.leaf 0x219021900e8d4a5105bf4fb) (.leaf 0x21a021a00e61a27205c04fb)) (.leaf 0x21b021b00e8d4a5105bf4fb))) (.leaf 0x21b021600000000005bc4f7)) (.leaf 0x21b021600000000005bd4f7))) (.leaf 0x21b021600000000005a74f7))) (.leaf 0x21b021600000000005b04f7)) (.leaf 0x21b021600000000005b14f7))) (.leaf 0x21b021600000000005b21c9)) (.leaf 0x21b021600000000005b217f)) (by decide +kernel)

private theorem step155 : ProjectedGoal ⟨527, 539, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 533 (by decide) (by decide) (step153 rates cones) (step154 rates cones)

private theorem step156 : ProjectedGoal ⟨513, 539, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 526 (by decide) (by decide) (step152 rates cones) (step155 rates cones)

private theorem step157 : ProjectedGoal ⟨486, 539, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 512 (by decide) (by decide) (step149 rates cones) (step156 rates cones)

theorem Part00012 : ProjectedGoal ⟨486, 539, 0, 70, 567, 851⟩ := step157

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
