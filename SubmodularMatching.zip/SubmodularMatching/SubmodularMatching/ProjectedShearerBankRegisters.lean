import SubmodularMatching.ProjectedShearerAllGuessWords
import SubmodularMatching.CapacityActiveObjectiveRange

/-! Word width for every retained guess in the actual finite-word source bank. -/
namespace SubmodularMatching.Capacity.RealOracle
open AppendixM Streaming Streaming.OracleQuery Shearer UpperBoundAssembly
noncomputable section
variable {E V C : Type*} [DecidableEq E] [DecidableEq V] [DecidableEq C]

theorem bank_priority_registers (ends : E→V×V) (cap : V→ℕ)
    (hpos : ∀ e,0<cap (ends e).1 ∧ 0<cap (ends e).2)
    (v sourceN sourceBits : ℕ) (hv : 2≤v) (f : Finset E→ℝ) (hf : IsSubmodular f)
    (hn : ∀ A,0≤f A) (edge : ℕ→E) (draw : ℕ→ℕ→ℕ→ℕ→ℕ) (k : ℕ) :
    let bank := forwardBank ends cap hpos v sourceN sourceBits f edge draw k
    ∀ a∈bank.states,
      let I := (a.2.machine.edges.map Prod.fst).toFinset
      let τ := bank.epoch.scale a.1
      ∀ (slots vertices : ℕ) (lab : C→↑I) (xs : List C) (hist : ℕ→↑I) (s N : ℕ) (p : ℝ),
      let K := trialScale slots (Fintype.card ↑I) vertices
      ∀ (tape : WordBatch N s (oracleWidth K)), 0≤p ∧ p≤1 → N≤oracleReads K →
        let reg := scanScoreWords hist s (oracleWidth K) p (fun U => f (U.image Subtype.val))
          (oracleTolerance K τ) (seekScoreColumn lab xs ∅) N tape (Vector.replicate xs.length 0)
        ∀ i : Fin xs.length, |(reg[i]:ℝ)|≤8704*(K:ℝ)^12 := by
  intro bank a hm I τ slots vertices lab xs hist s N p K tape hp hN
  obtain ⟨ht,h₀,hs⟩ := every_active_objective_bounds ends cap hpos v sourceN sourceBits hv f edge draw k a hm
  exact active_score_prefix_registers f hf hn (fun i : I => i.val) τ ht h₀
    (fun i => hs i.val (List.mem_toFinset.mp i.property)) slots vertices lab xs hist s N p hp hN tape
end
end SubmodularMatching.Capacity.RealOracle
