import SubmodularMatching.GibbsDeletion

/-!
# Correlation control for the finite Gibbs matching law

The vertex-deletion estimate is proved directly from the exact conditional
laws, by induction on the finite edge set. Its consequence is the covariance
row bound used in the variance estimate of the paper.
-/

namespace SubmodularMatching.GibbsMatching

open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

omit [DecidableEq E] in
/-- A convex mixture of perturbations of ℓ1 norm at most one has norm at most
the total mass of its mixing coefficients. -/
theorem weighted_l1_le (I : Finset E) (v : V) (q : E → ℝ) (d : E → V → ℝ)
    (hq : ∀ e ∈ I, 0 ≤ q e)
    (hd : ∀ e ∈ I, (∑ u, if u = v then 0 else |d e u|) ≤ 1) :
    (∑ u, if u = v then 0 else |∑ e ∈ I, q e * d e u|) ≤ ∑ e ∈ I, q e := by
  classical
  calc
    _ ≤ ∑ u, ∑ e ∈ I, q e * (if u = v then 0 else |d e u|) := by
      apply Finset.sum_le_sum
      intro u _
      by_cases huv : u = v
      · simp [huv]
      · simp only [if_neg huv]
        calc
          _ ≤ ∑ e ∈ I, |q e * d e u| := Finset.abs_sum_le_sum_abs _ _
          _ = ∑ e ∈ I, q e * |d e u| := by
            apply Finset.sum_congr rfl
            intro e he
            rw [abs_mul, abs_of_nonneg (hq e he)]
    _ = ∑ e ∈ I, q e * (∑ u, if u = v then 0 else |d e u|) := by
      rw [Finset.sum_comm]
      simp_rw [Finset.mul_sum]
    _ ≤ ∑ e ∈ I, q e := by
      apply Finset.sum_le_sum
      intro e he
      simpa only [mul_one] using mul_le_mul_of_nonneg_left (hd e he) (hq e he)

/-- A branch matching `v` to `w` costs `b w` at `w`, and otherwise is bounded
by the deletion discrepancy for `w`. -/
theorem branch_l1_le (v w : V) (hvw : w ≠ v) (b c : V → ℝ) (hb : 0 ≤ b w) :
    (∑ u, if u = v then 0 else |b u - (if u ∈ ({v, w} : Finset V) then 0 else c u)|) ≤
      b w + ∑ u, if u = w then 0 else |c u - b u| := by
  classical
  calc
    _ ≤ ∑ u, ((if u = w then b w else 0) + (if u = w then 0 else |c u - b u|)) := by
      apply Finset.sum_le_sum
      intro u _
      by_cases huv : u = v
      · subst u
        simp [hvw.symm, abs_nonneg]
      · by_cases huw : u = w
        · subst u
          simp [hvw, abs_of_nonneg hb]
        · simp [huv, huw, abs_sub_comm]
    _ = _ := by rw [Finset.sum_add_distrib]; simp

/-- Deleting one vertex changes the unmatched probabilities at the other
vertices by total ℓ1 distance at most its original matching probability.
The proof applies to finite loopless multigraphs as well as simple graphs. -/
theorem unmatchedMean_deletion_l1
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) :
    (∑ u, if u = v then 0 else
      |unmatchedMean ends (deleteVertex ends S v) activity u -
        unmatchedMean ends S activity u|) ≤ 1 - unmatchedMean ends S activity v := by
  classical
  induction S using Finset.strongInductionOn generalizing v with
  | _ S ih =>
    by_cases hI : (incident ends S v).Nonempty
    · have hsub := deleteVertex_subset ends S v
      have hstrict : deleteVertex ends S v ⊂ S := by
        refine Finset.ssubset_iff_subset_ne.mpr ⟨hsub, ?_⟩
        intro heq
        obtain ⟨e, he⟩ := hI
        have hd : e ∈ deleteVertex ends S v := by
          rw [heq]
          exact (Finset.mem_filter.mp he).1
        exact (Finset.mem_filter.mp hd).2 (Finset.mem_filter.mp he).2
      have haH : ∀ e ∈ deleteVertex ends S v, 0 ≤ activity e :=
        fun e he => ha e (hsub he)
      have heH : ∀ e ∈ deleteVertex ends S v, (ends e).card = 2 :=
        fun e he => hends e (hsub he)
      have hbranches : ∀ e ∈ incident ends S v,
          (∑ u, if u = v then 0 else
            |unmatchedMean ends (deleteVertex ends S v) activity u -
              (if u ∈ ends e then 0 else
                unmatchedMean ends (compatibleEdges ends S e) activity u)|) ≤ 1 := by
        intro e he
        obtain ⟨w, hwv, hew⟩ := exists_other_endpoint ends e
          (hends e (Finset.mem_filter.mp he).1) v (Finset.mem_filter.mp he).2
        have hIH := ih (deleteVertex ends S v) hstrict haH heH w
        have hb := (unmatchedMean_bounds ends (deleteVertex ends S v) activity haH w).1
        rw [compatibleEdges_eq_delete_pair ends S e v w hew, hew]
        have hbranch := branch_l1_le v w hwv
          (unmatchedMean ends (deleteVertex ends S v) activity)
          (unmatchedMean ends (deleteVertex ends (deleteVertex ends S v) w) activity) hb
        linarith
      calc
        _ = ∑ u, if u = v then 0 else
            |∑ e ∈ incident ends S v, edgeMean ends S activity e *
              (unmatchedMean ends (deleteVertex ends S v) activity u -
                (if u ∈ ends e then 0 else
                  unmatchedMean ends (compatibleEdges ends S e) activity u))| := by
          apply Finset.sum_congr rfl
          intro u _
          rw [unmatchedMean_difference_decomposition ends S activity ha v u]
        _ ≤ ∑ e ∈ incident ends S v, edgeMean ends S activity e := by
          apply weighted_l1_le
          · intro e he
            exact edgeMean_nonnegative ends S activity ha e (Finset.mem_filter.mp he).1
          · exact hbranches
        _ = 1 - unmatchedMean ends S activity v := by
          linarith [vertex_status_total ends S activity ha v]
    · have hdel : deleteVertex ends S v = S := by
        apply Finset.Subset.antisymm (deleteVertex_subset ends S v)
        intro e he
        refine Finset.mem_filter.mpr ⟨he, ?_⟩
        intro hve
        exact hI ⟨e, Finset.mem_filter.mpr ⟨he, hve⟩⟩
      simp only [hdel, sub_self, abs_zero, ite_self, Finset.sum_const_zero]
      exact sub_nonneg.mpr (unmatchedMean_bounds ends S activity ha v).2

omit [Fintype V] in
/-- Conditioning a Gibbs matching on leaving `v` unmatched gives the Gibbs
law after deleting `v`, for every finite observable. -/
theorem expectation_unmatched_mul
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e) (v : V) (F : Finset E → ℝ) :
    expectation ends S activity (fun M => unmatched ends v M * F M) =
      unmatchedMean ends S activity v *
        expectation ends (deleteVertex ends S v) activity F := by
  have hS := (partition_positive ends S activity ha).ne'
  have hdel := (partition_positive ends (deleteVertex ends S v) activity
    (fun e he => ha e (deleteVertex_subset ends S v he))).ne'
  rw [unmatchedMean_eq_partition_ratio]
  unfold expectation
  rw [weighted_unmatched_restriction]
  field_simp

/-- Covariance of the two unmatched indicators under the actual Gibbs law. -/
noncomputable def unmatchedCovariance
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ) (u v : V) : ℝ :=
  expectation ends S activity (fun M => unmatched ends u M * unmatched ends v M) -
    unmatchedMean ends S activity u * unmatchedMean ends S activity v

omit [Fintype V] in
theorem unmatchedCovariance_symm
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ) (u v : V) :
    unmatchedCovariance ends S activity u v =
      unmatchedCovariance ends S activity v u := by
  simp only [unmatchedCovariance, mul_comm]

omit [Fintype V] in
theorem unmatchedCovariance_eq_deletion
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e) (u v : V) :
    unmatchedCovariance ends S activity u v =
      unmatchedMean ends S activity v *
        (unmatchedMean ends (deleteVertex ends S v) activity u -
          unmatchedMean ends S activity u) := by
  have h := expectation_unmatched_mul ends S activity ha v (unmatched ends u)
  simp only [mul_comm] at h
  unfold unmatchedCovariance
  rw [h]
  change unmatchedMean ends (deleteVertex ends S v) activity u *
      unmatchedMean ends S activity v -
        unmatchedMean ends S activity u * unmatchedMean ends S activity v = _
  ring

omit [Fintype V] in
theorem unmatchedCovariance_diag
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ) (v : V) :
    unmatchedCovariance ends S activity v v =
      unmatchedMean ends S activity v * (1 - unmatchedMean ends S activity v) := by
  have heq : expectation ends S activity
      (fun M => unmatched ends v M * unmatched ends v M) =
        unmatchedMean ends S activity v := by
    apply expectation_congr
    intro M _
    unfold unmatched
    split_ifs <;> norm_num
  unfold unmatchedCovariance
  rw [heq]
  ring

/-- GM1: the off-diagonal absolute covariance sum is bounded by the
variance of the chosen unmatched indicator. -/
theorem unmatchedCovariance_offdiag_sum
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) :
    (∑ u, if u = v then 0 else |unmatchedCovariance ends S activity u v|) ≤
      unmatchedMean ends S activity v * (1 - unmatchedMean ends S activity v) := by
  have hav := (unmatchedMean_bounds ends S activity ha v).1
  calc
    _ = unmatchedMean ends S activity v *
        (∑ u, if u = v then 0 else
          |unmatchedMean ends (deleteVertex ends S v) activity u -
            unmatchedMean ends S activity u|) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro u _
      by_cases huv : u = v
      · simp [huv]
      · simp only [if_neg huv, unmatchedCovariance_eq_deletion ends S activity ha,
          abs_mul, abs_of_nonneg hav]
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (unmatchedMean_deletion_l1 ends S activity ha hends v) hav

/-- The full absolute covariance row bound for the finite Gibbs law. -/
theorem unmatchedCovariance_row_sum
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) :
    (∑ u, |unmatchedCovariance ends S activity v u|) ≤
      2 * unmatchedMean ends S activity v * (1 - unmatchedMean ends S activity v) := by
  classical
  obtain ⟨hav, hav1⟩ := unmatchedMean_bounds ends S activity ha v
  have hvar : 0 ≤ unmatchedMean ends S activity v *
      (1 - unmatchedMean ends S activity v) := mul_nonneg hav (sub_nonneg.mpr hav1)
  have hsplit : (∑ u, |unmatchedCovariance ends S activity v u|) =
      unmatchedMean ends S activity v * (1 - unmatchedMean ends S activity v) +
        (∑ u, if u = v then 0 else |unmatchedCovariance ends S activity u v|) := by
    calc
      _ = ∑ u, ((if u = v then unmatchedMean ends S activity v *
            (1 - unmatchedMean ends S activity v) else 0) +
          (if u = v then 0 else |unmatchedCovariance ends S activity u v|)) := by
        apply Finset.sum_congr rfl
        intro u _
        by_cases huv : u = v
        · subst u
          simp [unmatchedCovariance_diag, abs_of_nonneg hvar]
        · simp [huv, unmatchedCovariance_symm]
      _ = _ := by rw [Finset.sum_add_distrib]; simp
  rw [hsplit]
  nlinarith [unmatchedCovariance_offdiag_sum ends S activity ha hends v]

end SubmodularMatching.GibbsMatching
