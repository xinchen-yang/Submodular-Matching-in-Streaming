import SubmodularMatching.NonmonotoneRetainedRegisters
import SubmodularMatching.NonmonotoneOptimizerReachedWords

/-! Every optimizer register outcome at an intermediate time is realized by a
single finite prefix of actual fresh word batches, including zero-probability
outcomes retained by a finite law's representation. -/
namespace SubmodularMatching.NonmonotoneOptimizer.BlockData
open Streaming UpperBoundAssembly GibbsSampler
noncomputable section
variable {E : Type*} [DecidableEq E] {m n l rows s bits : ℕ} [NeZero n]
variable (B : BlockData E n l) (G : PackingGrid rows l) (h : ℕ→E) (p : ℕ→ℝ)
variable (hp : ∀ i<m,0≤p i ∧ p i≤1) (F : Finset E→ℝ) (τ : ℝ)

private theorem same_prefix (tape upd : ℕ → ActionRound m n s bits) (t : ℕ)
    (eq : ∀ j<t,tape j=upd j) :
    B.executeRounds G h p hp F τ tape t = B.executeRounds G h p hp F τ upd t := by
  induction t with
  | zero => rfl
  | succ t ih =>
    simp only [executeRounds]
    rw [ih (fun k hk => eq k (hk.trans (Nat.lt_succ_self _))),eq t (Nat.lt_succ_self _)]

theorem fresh_registers_reached (t : ℕ) (regs : Option (Registers l))
    (mem : regs∈(CandidateLaw.execute (B.freshRegisterStep G h p hp F τ s bits) t 0 none).outcomes) :
    ∃ tape : ℕ → ActionRound m n s bits, B.executeRounds G h p hp F τ tape t=regs := by
  classical
  let Inv := fun j r => ∃ tape : ℕ → ActionRound m n s bits, B.executeRounds G h p hp F τ tape j=r
  have step (j : ℕ) (r : Option (Registers l)) (ir : Inv j r) (o : Option (Registers l))
      (hm : o∈(B.freshRegisterStep G h p hp F τ s bits j r).outcomes) : Inv (j+1) o := by
    obtain ⟨prev,he⟩ := ir
    obtain ⟨w,_,rfl⟩ := Finset.mem_image.mp hm
    let tape := Function.update prev j w
    have back := B.same_prefix G h p hp F τ tape prev j (fun i hi => Function.update_of_ne hi.ne _ _)
    refine ⟨tape,?_⟩
    rw [executeRounds,back,he]
    simp only [tape,Function.update_self]
  have init : Inv 0 none := ⟨fun _ _ _ _ => ⟨0,by positivity⟩,rfl⟩
  exact (CandidateLaw.execute_invariant _ Inv step t 0 none init regs mem : Inv (0+t) regs) |>.elim
    (fun tape eq => ⟨tape,by simpa using eq⟩)

theorem fresh_state_shape (t : ℕ) (regs : Option (Registers l))
    (mem : regs∈(CandidateLaw.execute (B.freshRegisterStep G h p hp F τ s bits) (t+1) 0 none).outcomes) :
    ∃ tape : ℕ → ActionRound m n s bits,
      regs = some (B.candidateRun G (paperExponent l)
        (B.paperAnswers h p m F τ hp (roundWords tape)) (t+1)) := by
  obtain ⟨tape,he⟩ := B.fresh_registers_reached G h p hp F τ _ _ mem
  exact ⟨tape,he.symm.trans (B.executeRounds_correct G h p hp F τ tape t)⟩

end
end SubmodularMatching.NonmonotoneOptimizer.BlockData
