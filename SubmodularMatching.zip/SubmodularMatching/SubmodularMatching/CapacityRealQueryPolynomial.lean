import SubmodularMatching.CapacityRealBankQueries
import SubmodularMatching.NonmonotoneLocalScale

/-! Dimension-only call bounds for the forward bank on the fixed confidence schedule. -/
namespace SubmodularMatching.Capacity.RealOracle
open Streaming Streaming.OracleQuery AppendixM
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The same word width and batch count apply to all guesses and times.
The right-hand side is an explicit polynomial in the vertex count and inverse
failure parameter. -/
theorem forward_queries_polynomial (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0 < cap (ends e).1 ∧ 0 < cap (ends e).2)
    (n J k : ℕ) (hk : k ≤ n^2) (oracle : Finset E → ℝ) (edges : ℕ → E)
    (draw : ℕ → ℕ → ℕ → ℕ → ℕ) :
    let v := n^2
    let K := sourceWordScale v (v^2)
    let st := countedBank ends cap hpos v (batchCount K J) (batchBits K) oracle edges draw k
    st.1 = forwardBank ends cap hpos v (batchCount K J) (batchBits K) oracle edges draw k ∧
      st.2 ≤ 1 + n^2*(1 + 2*(4*(2^42*(v^2+2)*(v^2+1)+v^2)^3*J+1)*
        (signedGuessCountConstant*(v+2))) := by
  intro v K st
  have h := countedBank_exact ends cap hpos v (batchCount K J) (batchBits K) oracle edges draw k
  refine ⟨h.1,h.2.trans ?_⟩
  have hs := signedGuessCount_le v
  change guessSpan v+1 ≤ signedGuessCountConstant*((v+1).log2+1) at hs
  have hl : (v+1).log2+1 ≤ v+2 := Nat.succ_le_succ (Nat.log2_le_self (v+1))
  have hg := hs.trans (Nat.mul_le_mul_left signedGuessCountConstant hl)
  exact Nat.add_le_add_left (Nat.mul_le_mul hk (Nat.add_le_add_left
    (Nat.mul_le_mul_left (2*batchCount K J) hg) 1)) 1

end
end SubmodularMatching.Capacity.RealOracle
