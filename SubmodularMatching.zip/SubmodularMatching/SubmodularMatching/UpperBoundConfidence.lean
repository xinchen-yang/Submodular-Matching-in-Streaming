import SubmodularMatching.UpperBoundIntegerRepeats
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-! # Rational confidence budgets for every fixed real exponent -/

namespace SubmodularMatching.UpperBoundAssembly

/-- Choose an integer confidence exponent once. This supports the exact
`n⁻ᶜ` probability goal while only using a rational program input. -/
theorem confidence_integer_le (n : ℕ) (hn : 1 ≤ n) (c : ℝ) :
    (((n : ℝ) ^ ⌈c⌉₊)⁻¹) ≤ (n : ℝ) ^ (-c) := by
  have hn' : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hpos := zero_lt_one.trans_le hn'
  have hpow := Real.rpow_le_rpow_of_exponent_le hn' (Nat.le_ceil c)
  rw [Real.rpow_natCast] at hpow
  rw [Real.rpow_neg hpos.le]
  exact inv_le_inv₀ (pow_pos hpos _) (Real.rpow_pos_of_pos hpos c) |>.2 hpow

end SubmodularMatching.UpperBoundAssembly
