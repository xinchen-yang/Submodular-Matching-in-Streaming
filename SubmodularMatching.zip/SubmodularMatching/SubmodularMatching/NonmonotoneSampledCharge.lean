import SubmodularMatching.NonmonotoneFiniteCharge

/-! Signed sample bounds and the six-epsilon charging inequality for M.2. -/
open scoped BigOperators

namespace SubmodularMatching.Streaming

theorem sourceWeight_signed_bounds {N : ℕ} (d tau : ℝ) (samples : Fin N → ℝ)
    (hd : 0 < d) (hN : 0 < N) (htau : 0 ≤ tau) (hs : ∀ i, samples i ≤ tau) :
    0 ≤ sourceWeight d samples ∧ sourceWeight d samples ≤ tau := by
  let q := fun i => max (samples i) 0
  have hq := sourceWeight_bounds d tau q hd hN
    (fun i => ⟨le_max_right _ _, max_le (hs i) htau⟩)
  have hindex : sourceIndex d samples ≤ sourceIndex d q := by
    apply Finset.sum_le_sum
    intro i _
    apply Int.floor_le_floor
    exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left (le_max_left _ _) (by norm_num)) hd.le
  have hratio : (sourceIndex d samples : ℝ) / (4 * N) ≤ (sourceIndex d q : ℝ) / (4 * N) :=
    div_le_div_of_nonneg_right (by exact_mod_cast hindex) (by positivity)
  have h : sourceWeight d samples ≤ sourceWeight d q := by
    apply mul_le_mul_of_nonneg_left _ hd.le
    exact_mod_cast max_le_max_left (0 : ℤ) (sub_le_sub_right (Int.floor_le_floor hratio) 1)
  exact ⟨mul_nonneg hd.le (by exact_mod_cast (le_max_left (0 : ℤ) _)), h.trans hq.2⟩

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

theorem signed_sampled_charge_six_epsilon (C : PotentialConfig) (ends : E → V × V)
    {N : ℕ} (hN : 0 < N) (edges : ℕ → E) (samples : ℕ → Fin N → ℝ)
    (f : Finset E → ℝ) (arrivals vertices : ℕ) (M : Finset E) (epsilon : ℝ)
    (hp1 : C.p ≤ 1) (heps : 0 < epsilon) (heps4 : epsilon ≤ 1 / 4)
    (hv : 2 ≤ vertices) (hn : arrivals ≤ vertices ^ 2) (hsize : 2 * M.card ≤ vertices)
    (htheta : C.theta = epsilon * C.tau / vertices)
    (hgap : C.gap = epsilon * C.tau / (vertices : ℝ) ^ 2)
    (hgrid : C.grid = C.p * epsilon ^ 2 * C.tau / (vertices : ℝ) ^ 4)
    (hf : IsSubmodular f) (hpos : ∀ A, 0 ≤ f A)
    (hinj : ∀ i < arrivals, ∀ j < arrivals, edges i = edges j → i = j)
    (hM : IsMatchingOn (endpointSet ends) M)
    (hloop : ∀ i < arrivals, (ends (edges i)).1 ≠ (ends (edges i)).2)
    (hs : ∀ i < arrivals, ∀ j, samples i j ≤ C.tau)
    (haccurate : ∀ i < arrivals,
      traceWeight C ends (sampledInput C.gap edges samples) f i - C.gap ≤
        sourceAverage C.gap (samples i) ∧
      sourceAverage C.gap (samples i) ≤
        traceWeight C ends (sampledInput C.gap edges samples) f i + C.gap)
    (hprefix : (∑ e ∈ M \ (Finset.range arrivals).image edges, f {e}) ≤ epsilon * C.tau / 2) :
    let input := sampledInput C.gap edges samples
    let S := (runPotential C ends input arrivals).stored
    (1-C.p)*f M ≤ f ∅ + traceRecordedValue C ends input arrivals + traceResidual C ends input f arrivals (M ∩ S) +
      (∑ v ∈ Finset.univ \ (M ∩ S).biUnion (endpointSet ends),
        idealPotential C ends input arrivals v) + 6 * epsilon * C.tau := by
  let input := sampledInput C.gap edges samples
  have htau : 0 < C.tau := C.theta_pos.trans_le C.theta_le_tau
  have hvpos : (0 : ℝ) < vertices := by exact_mod_cast (lt_of_lt_of_le (by decide : 0 < 2) hv)
  have hd : 0 < C.gap := by rw [hgap]; positivity
  have hw : ∀ i < arrivals, (input i).2 ≤ C.tau := by
    intro i hi
    exact (sourceWeight_signed_bounds C.gap C.tau (samples i) hd hN htau.le (hs i hi)).2
  have ha (i : ℕ) (hi : i < arrivals) := sourceWeight_signed_accuracy C.gap
    (traceWeight C ends input f i) (samples i) hd (haccurate i hi).1 (haccurate i hi).2
  have hc := signed_trace_finite_charge_with_prefix C ends input f arrivals M (epsilon * C.tau / 2)
    hp1 hf hpos hinj hM hloop hw (fun i hi => (ha i hi).2.1)
    (fun i hi hacc => (ha i hi).2.2 (C.theta_pos.trans_le hacc.1)) hprefix
  have hb := finite_charge_error_budget C.p C.tau epsilon vertices arrivals M.card
    hp1 htau.le heps heps4 hv hn hsize
  rw [← htheta, ← hgap, ← hgrid] at hb
  dsimp only at hc ⊢
  linarith

end SubmodularMatching.Streaming
