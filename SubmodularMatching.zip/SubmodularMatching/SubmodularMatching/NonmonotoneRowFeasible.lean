import SubmodularMatching.NonmonotoneGridRowProgram

/-! Feasibility of every optimizer-action branch, independent of score
estimation, including rare unsuccessful optimizer transcripts. -/

namespace SubmodularMatching.NonmonotoneCandidate

open Capacity UpperBoundAssembly NonmonotoneLayers AppendixM TwoLayerDiffuse
open Shearer ShearerCappedSampler GibbsMatching GibbsSampler TwoStage
noncomputable section

variable {I C V : Type*} [Fintype I] [LinearOrder I] [LinearOrder C] [DecidableEq V]

theorem row_run_feasible {b : V → ℕ} {base : C → Finset (Slots b)} {active : Finset C}
    (R : PhysicalWordData I base active) (orig : I → V×V) (lab : C→I) (copy : I→C)
    (hlabel : ∀ i, lab (copy i)=i) {v : ℕ} (slot : Fin v ↪ Slots b) (ep : I → Fin v × Fin v)
    (geom : ∀ i, base (copy i)=pairEnds (fun j => (slot (ep j).1,slot (ep j).2)) i)
    (hgeom : ∀ c∈active ∪ Finset.univ.image copy, ∀ i, touches orig i (lab c) → ∃ w∈base c,w.1=i)
    (loop : ∀ i,(ep i).1 ≠ (ep i).2) (hk : 0<R.k) (hQ : 0<R.Q)
    (hl : ∀ z w, gridLoadNumerator (pairEnds (fun i => (slot (ep i).1,slot (ep i).2))) Finset.univ (R.num z) w ≤ R.Q)
    (hs : ∀ z i, R.num z i ≠ 0 →
      vacant base active (slot (ep i).1) (forgetMark z.1,forgetMark z.2)=1 ∧
      vacant base active (slot (ep i).2) (forgetMark z.1,forgetMark z.2)=1)
    (hist : ℕ→I) (m : ℕ) (p : ℝ) (hp : 0≤p ∧ p≤1) (f : Finset I → ℝ) :
    ∀ M∈(R.run ep Finset.univ (Function.Embedding.refl I) lab hist m p hp f).outcomes, Capacity.feasible orig b M := by
  let first := binaryPair R.one R.two R.δ R.hδ R.capOne R.capTwo R.a R.b R.t R.ha R.hb R.hend
  let h := shiftResidual hist p f m
  let D := Marked base active R.a × Marked base active R.b
  apply wordGibbsTrial_support base active R.a R.b lab first ep Finset.univ R.num R.k R.Q R.D
    (Function.Embedding.refl I) hist m R.samples R.bits p hp f R.ε
  intro estimate
  let T := fun z : D => (estimatedOutput base lab h estimate z.1.val z.2.val).image Prod.fst
  have hT : priorityLabels base active R.a R.b lab h estimate = fun z : D => (T z).image lab := by
    funext z
    dsimp only [priorityLabels,T]
    rw [Finset.image_image]
    rfl
  change ∀ M ∈ (trial first ep Finset.univ R.num R.k R.Q R.D (priorityLabels _ _ _ _ lab h estimate) _).outcomes, _
  rw [hT]
  exact trial_feasible b base active orig lab first ep Finset.univ slot copy (Function.Embedding.refl I)
    hlabel geom hgeom R.k R.Q R.D hk hQ R.num Finset.univ.toList (Finset.toList_toFinset _) (Finset.nodup_toList _)
    (fun i _ => loop i) (fun z w => (compact_load slot ep _ (fun _ => rfl) (R.num z) w).trans_le (hl z (slot w)))
    (fun z => (forgetMark z.1,forgetMark z.2)) T (fun z i _ => hs z i)
    (fun z => estimated_unmarked_support base lab h estimate z.1.val z.2.val)

namespace GridRow
variable {I V : Type*} [Fintype I] [LinearOrder I] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream I V} {b : V → ℕ} (g : GridRow S b)

theorem trial_feasible_all (hb : ∀ v, 0<b v) (rank : Slots b ↪ ℕ) (fallback : I) (hist : ℕ→I) (m : ℕ)
    (τ : ℝ) (f : Finset I→ℝ) : ∀ M∈(g.trial hb rank fallback hist m τ f).outcomes, Capacity.feasible S.ends b M := by
  letI : LinearOrder (Slots b × Slots b) := keyedOrder (slotPairKey b rank)
  let R := g.wordData hb rank τ
  have Kpos := g.scale_pos rank
  have hk : 0<R.k := by change 0<(2:ℕ)^30; positivity
  have hQ : 0<R.Q := by change 0<assignedGrid (scaleFor (S:=S) rank); dsimp [assignedGrid]; positivity
  have facts := g.diffuse_facts hb rank
  apply row_run_feasible R S.ends (sourceSlotLabel S b fallback) g.pair
    (sourceSlotLabel_assigned S b fallback g.left g.right) g.slot g.endpoints g.endpoint_geometry
    (sourceSlotLabel_geometry S b rank fallback g.left g.right) g.endpoints_loopless hk hQ _ _ hist m
    sourceProbability (by norm_num [sourceProbability]) f
  · rw [g.lifted_endpoints]; exact facts.2.1
  · intro z i hn
    rw [(g.endpoint_values i).1,(g.endpoint_values i).2]
    exact facts.2.2.1 z i hn

end GridRow
end
end SubmodularMatching.NonmonotoneCandidate
