import SubmodularMatching.NonmonotonePreparationLaw
import SubmodularMatching.CapacityStoredWordQuery
import SubmodularMatching.NonmonotoneParameters

/-! Scale-normalized conditional accuracy of the actual source calls, with
one polynomial schedule valid for all live guesses and their different scales. -/
namespace SubmodularMatching.Streaming.OracleQuery
open GibbsMatching AppendixM
noncomputable section
variable {E : Type*} [DecidableEq E]

def normalized (Q : OracleQuery E) (τ : ℝ) : OracleQuery E :=
  {Q with evaluate := fun A => τ⁻¹*Q.evaluate A}

theorem normalized_target (Q : OracleQuery E) (τ : ℝ) :
    (Q.normalized τ).target = τ⁻¹*Q.target := bernoulli_const_mul _ _ _ _ _

theorem normalized_range (Q : OracleQuery E) (τ a b : ℝ) (ht : 0<τ)
    (h : ∀ A ⊆ (Finset.range Q.size).image Q.edges,
      a*τ ≤ Q.evaluate A ∧ Q.evaluate A ≤ b*τ) :
    ∀ A ⊆ (Finset.range Q.size).image Q.edges,
      a ≤ (Q.normalized τ).evaluate A ∧ (Q.normalized τ).evaluate A ≤ b := by
  intro A hA
  obtain ⟨hl,hu⟩ := h A hA
  change a ≤ τ⁻¹*Q.evaluate A ∧ τ⁻¹*Q.evaluate A ≤ b
  rw [← div_eq_inv_mul]
  exact ⟨(le_div_iff₀ ht).mpr hl,(div_le_iff₀ ht).mpr hu⟩

theorem sourceAverage_scaled {N : ℕ} (s d : ℝ) (hs : s ≠ 0) (X : Fin N → ℝ) :
    sourceAverage (s*d) (fun j => s*X j) = s*sourceAverage d X := by
  have he (j : Fin N) : 4*(s*X j)/(s*d) = 4*X j/d := by
    rw [show 4*(s*X j)=s*(4*X j) by ring,mul_div_mul_left _ _ hs]
  unfold sourceAverage sourceIndex
  simp only [he]
  ring

theorem normalized_accurate (Q : OracleQuery E) (τ d : ℝ) (ht : 0<τ) (N bits : ℕ)
    (ω : WordBatch N Q.size bits)
    (h : (Q.normalized τ).target-d ≤ sourceAverage d (fun j => (Q.normalized τ).wordValue bits (ω j)) ∧
      sourceAverage d (fun j => (Q.normalized τ).wordValue bits (ω j)) ≤ (Q.normalized τ).target+d) :
    Q.target-τ*d ≤ sourceAverage (τ*d) (fun j => Q.wordValue bits (ω j)) ∧
      sourceAverage (τ*d) (fun j => Q.wordValue bits (ω j)) ≤ Q.target+τ*d := by
  have hp (j : Fin N) : (Q.normalized τ).wordValue bits (ω j) = τ⁻¹*Q.wordValue bits (ω j) := rfl
  have ha : sourceAverage d (fun j => (Q.normalized τ).wordValue bits (ω j)) =
      τ⁻¹*sourceAverage (τ*d) (fun j => Q.wordValue bits (ω j)) := by
    simp only [hp]
    simpa only [inv_mul_cancel_left₀ ht.ne'] using sourceAverage_scaled τ⁻¹ (τ*d) (inv_ne_zero ht.ne')
      (fun j => Q.wordValue bits (ω j))
  rw [normalized_target,ha] at h
  have hl := mul_le_mul_of_nonneg_left h.1 ht.le
  have hu := mul_le_mul_of_nonneg_left h.2 ht.le
  simpa only [mul_sub,mul_add,mul_inv_cancel_left₀ ht.ne'] using And.intro hl hu

def sourceWordScale (v calls : ℕ) : ℕ := 2^42 * (v^2+2) * (v^2+1) + calls

/-- The same sample width and count work across epochs. Ratios and support
sizes depend only on the input size and the fixed accuracy constant. -/
theorem sourceWordScale_bounds (v calls m : ℕ) (hv : 2≤v) (hm : m≤v^2) :
    m ≤ sourceWordScale v calls ∧ calls ≤ sourceWordScale v calls ∧
    (v^2+2:ℕ) ≤ (sourceWordScale v calls:ℝ) * ((streamTolerance:ℝ)/(v:ℝ)^2) := by
  have hv0 : (0:ℝ)<v := by exact_mod_cast (by omega : 0<v)
  have hnat : v^2+1 ≤ 2^42*(v^2+2)*(v^2+1) := by
    have hone : (1:ℕ) ≤ 2^42*(v^2+2) := Nat.succ_le_of_lt (by positivity)
    simpa only [one_mul] using Nat.mul_le_mul_right (v^2+1) hone
  refine ⟨hm.trans ((Nat.le_succ _).trans (hnat.trans (Nat.le_add_right _ _))),Nat.le_add_left _ _,?_⟩
  push_cast
  rw [mul_div_assoc',le_div_iff₀ (sq_pos_of_pos hv0)]
  unfold sourceWordScale streamTolerance
  push_cast
  norm_num
  nlinarith only [show 0≤(v:ℝ)^2 by positivity, Nat.cast_nonneg (α:=ℝ) calls]

end
end SubmodularMatching.Streaming.OracleQuery
