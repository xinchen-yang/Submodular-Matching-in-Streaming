import SubmodularMatching.AppendixMNumericalBoxes
import SubmodularMatching.AppendixMNumerical
import SubmodularMatching.CertificateIntegerBox

/-! # Outward bounds for a full interval of update-rate parameters -/

namespace SubmodularMatching.AppendixM
open SourceCertificate

private def dQ : ℚ := 13/40
private def oneQ : ℚ := 15609923359958673284671/62500000000000000000000
private def mixQ : ℚ := (oneQ/dQ) * (1-oneQ/dQ)
private def bitRat (b : Bool) : ℚ := if b then 1 else 0
private def capQ (z t : ℚ) := 1 - mixQ*t^2 - (1-2*mixQ*t)*dQ*z
def vertexQ (b : Bool) := capQ (bitRat b) (dQ/5)
def edgeQ (i j : Bool) := capQ (bitRat i + bitRat j) (13/20*dQ)

private def sQ := dQ - oneQ
private def rootLoQ : ℚ := 836083186673 / 10^12
private def rootHiQ : ℚ := 836083186674 / 10^12
private def areaQ : ℚ := sQ/2 + sQ^2/2 - (1-(1-4*sQ)*rootHiQ)/12
private def lossQ : ℚ := 1/2 + sQ - rootLoQ/2
private def betaQ : ℚ := (1-(2*areaQ+(oneQ-sQ)*lossQ)/dQ)*dQ/(1+dQ/2)^2
private def alphaQ : ℚ := betaQ*(1+dQ/4)
private def unitsQ (n : ℕ) : ℚ := n/1000000

private theorem betaQ_cast : (betaQ : ℝ) = beta := by
  norm_num [betaQ, areaQ, lossQ, oneQ, sQ, dQ, rootLoQ, rootHiQ, beta, gamma, retention,
    priorityArea, priorityLoss, rootHi, rootLo, discriminant, layerOne, layerTwo, degree]
private theorem alphaQ_cast : (alphaQ : ℝ) = alpha := by
  rw [alphaQ, Rat.cast_mul, betaQ_cast]
  norm_num [alpha, dQ, degree]

noncomputable def vertexCoeff (b : Bool) : ℝ := vertexQ b
noncomputable def edgeCoeff (i j : Bool) : ℝ := edgeQ i j

theorem vertexCoeff_formula (i : Bool) :
    vertexCoeff i = let a := (layerOne/degree)*(1-layerOne/degree)
                    let t := degree/5
                    1-a*t^2-(1-2*a*t)*degree*bit i := by
  cases i <;> norm_num [vertexCoeff, vertexQ, capQ, bitRat, mixQ, dQ, oneQ, layerOne, degree, bit]

theorem edgeCoeff_formula (i j : Bool) :
    edgeCoeff i j = let a := (layerOne/degree)*(1-layerOne/degree)
                    let t := 13/20*degree
                    1-a*t^2-(1-2*a*t)*degree*(bit i+bit j) := by
  cases i <;> cases j <;> norm_num [edgeCoeff, edgeQ, capQ, bitRat, mixQ, dQ, oneQ, layerOne, degree, bit]

private theorem vertexCoeff_nonneg (i : Bool) : 0 ≤ vertexCoeff i := by
  cases i <;> norm_num [vertexCoeff, vertexQ, capQ, bitRat, mixQ, dQ, oneQ]

def coeffCheck (p : AppendixBoxParameters) (den : ℕ) (e : Endpoint) (i j side : Bool) : Bool :=
  decide (unitsQ e.u ≤ vertexQ i * ((p.amin : ℚ)/den) ∧
    unitsQ e.v ≤ vertexQ j * ((p.bmin : ℚ)/den) ∧
    unitsQ e.q ≤ edgeQ i j ∧
    alphaQ + 1/1000000 + betaQ * ((1-bitRat i)*((p.amax : ℚ)/den) +
                            (1-bitRat j)*((p.bmax : ℚ)/den)) ≤ unitsQ e.target ∧
    (if side then (p.cHi : ℚ)/10^12 ≤ unitsQ e.c else unitsQ e.c ≤ (p.cLo : ℚ)/10^12))

noncomputable def localTarget (i j : Bool) (A B : ℝ) : ℝ :=
  alpha + 1/1000000 + beta*(unmatched i*A + unmatched j*B)

noncomputable def localValue (i j : Bool) (A B c a d : ℝ) : ℝ :=
  gridValue (fun x => vertexCoeff i*A*profile.value i x)
    (fun y => vertexCoeff j*B*profile.value j y) (edgeCoeff i j) c a d

def Envelope (p : AppendixBoxParameters) (den : ℕ) (i j : Bool) : Prop :=
  ∀ (A B c : ℝ), (p.amin : ℝ)/den ≤ A → A ≤ (p.amax : ℝ)/den →
    (p.bmin : ℝ)/den ≤ B → B ≤ (p.bmax : ℝ)/den →
    (p.cLo : ℝ)/10^12 ≤ c → c ≤ (p.cHi : ℝ)/10^12 →
    ∀ a d, 0 ≤ a → 0 ≤ d → localTarget i j A B ≤ localValue i j A B c a d

private theorem unitsQ_cast (n : ℕ) : (unitsQ n : ℝ) = units n := by
  norm_num [unitsQ, units]

private theorem unmatched_cast (b : Bool) : (((1-bitRat b : ℚ) : ℝ)) = unmatched b := by
  cases b <;> norm_num [bitRat, bit, unmatched]

private theorem lift_coefficients (p : AppendixBoxParameters) (den : ℕ) (e : Endpoint)
    (i j side : Bool) (hc : coeffCheck p den e i j side = true)
    (A B c a d : ℝ)
    (hA : (p.amin : ℝ)/den ≤ A) (hA' : A ≤ (p.amax : ℝ)/den)
    (hB : (p.bmin : ℝ)/den ≤ B) (hB' : B ≤ (p.bmax : ℝ)/den)
    (hcL : (p.cLo : ℝ)/10^12 ≤ c) (hcH : c ≤ (p.cHi : ℝ)/10^12)
    (hdir : if side then d ≤ a else a ≤ d)
    (ha : 0 ≤ a) (hd : 0 ≤ d) (he : e.Goal i j a d) :
    localTarget i j A B ≤ localValue i j A B c a d := by
  have ch := of_decide_eq_true hc
  obtain ⟨w1,w2,wq,tar,cr⟩ := ch
  have cu := (Rat.cast_le (K := ℝ)).2 w1
  have cv := (Rat.cast_le (K := ℝ)).2 w2
  have cq := (Rat.cast_le (K := ℝ)).2 wq
  have z := (Rat.cast_le (K := ℝ)).2 tar
  simp only [Rat.cast_add, Rat.cast_mul, Rat.cast_div, Rat.cast_pow, Rat.cast_natCast,
    Rat.cast_ofNat, Rat.cast_one, alphaQ_cast, betaQ_cast, unitsQ_cast, unmatched_cast] at cu cv cq z
  change units e.u ≤ vertexCoeff i * _ at cu
  change units e.v ≤ vertexCoeff j * _ at cv
  change units e.q ≤ edgeCoeff i j at cq
  have ui : 0 ≤ unmatched i := by cases i <;> norm_num [unmatched,bit]
  have uj : 0 ≤ unmatched j := by cases j <;> norm_num [unmatched,bit]
  apply le_trans _ (le_trans he _)
  · unfold localTarget
    apply le_trans _ z
    apply add_le_add le_rfl
    apply mul_le_mul_of_nonneg_left _ limiting_factor.1.le
    exact add_le_add (mul_le_mul_of_nonneg_left hA' ui) (mul_le_mul_of_nonneg_left hB' uj)
  · unfold localValue gridValue
    apply add_le_add
    · apply add_le_add
      · apply mul_le_mul_of_nonneg_right _ (profile.value_nonnegative i a ha)
        exact cu.trans (mul_le_mul_of_nonneg_left hA (vertexCoeff_nonneg i))
      · apply mul_le_mul_of_nonneg_right _ (profile.value_nonnegative j d hd)
        exact cv.trans (mul_le_mul_of_nonneg_left hB (vertexCoeff_nonneg j))
    · apply mul_le_mul cq _ (le_max_right _ _) (cq.trans' (by unfold units; positivity))
      apply max_le_max_right
      cases side
      · simp only [Bool.false_eq_true, ↓reduceIte] at cr hdir
        have cr' := (Rat.cast_le (K := ℝ)).2 cr
        simp only [Rat.cast_div, Rat.cast_pow, Rat.cast_natCast, Rat.cast_ofNat, unitsQ_cast] at cr'
        nlinarith only [mul_nonneg (sub_nonneg.mpr (cr'.trans hcL)) (sub_nonneg.mpr hdir)]
      · simp only [↓reduceIte] at cr hdir
        have cr' := (Rat.cast_le (K := ℝ)).2 cr
        simp only [Rat.cast_div, Rat.cast_pow, Rat.cast_natCast, Rat.cast_ofNat, unitsQ_cast] at cr'
        nlinarith only [mul_nonneg (sub_nonneg.mpr (hcH.trans cr')) (sub_nonneg.mpr hdir)]

theorem envelope_of_endpoints (p : AppendixBoxParameters) (den : ℕ) (i j : Bool)
    (l r : Endpoint) (hL : coeffCheck p den l i j false = true)
    (hR : coeffCheck p den r i j true = true)
    (hl : ∀ a d, 0 ≤ a → 0 ≤ d → l.Goal i j a d)
    (hr : ∀ a d, 0 ≤ a → 0 ≤ d → r.Goal i j a d) : Envelope p den i j := by
  intro A B c hA hA' hB hB' hcL hcH a d ha hd
  rcases le_total a d with hs | hs
  · exact lift_coefficients p den l i j false hL A B c a d hA hA' hB hB' hcL hcH hs ha hd (hl a d ha hd)
  · exact lift_coefficients p den r i j true hR A B c a d hA hA' hB hB' hcL hcH hs ha hd (hr a d ha hd)

end SubmodularMatching.AppendixM
