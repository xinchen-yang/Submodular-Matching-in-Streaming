import SubmodularMatching.StreamingOnlinePointwise
import SubmodularMatching.StreamingOnlineWitnessTape

/-!
# Execution of every compact word tape by the one-pass program

The full transcript appears only in the law and equivalence proof. The
executable transition reads the current edge and fresh words and updates
its current collection of sparse instances.
-/

namespace SubmodularMatching.Streaming

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

noncomputable section

/-- Readdress an external word source from chronological call numbers to the
online `(arrival, guess)` coordinates. This is a coupling of the input
interface and the proof-side tape, not an operation of the stream program. -/
def ScheduledSource.wordStream (P : ScheduledSource E V) (read : ℕ → ℕ → ℕ → ℕ) (a j : ℕ) :
    ℕ → ℕ → ℕ := by
  classical
  exact if h : ∃ t < P.calls.length, P.call t = (a, j) then read (Classical.choose h)
    else fun _ _ => 0

omit [DecidableEq V] in
theorem ScheduledSource.wordStream_at_call (P : ScheduledSource E V) (read : ℕ → ℕ → ℕ → ℕ)
    {t : ℕ} (ht : t < P.calls.length) : P.wordStream read (P.call t).1 (P.call t).2 = read t := by
  classical
  have hex : ∃ u < P.calls.length, P.call u = ((P.call t).1, (P.call t).2) := ⟨t, ht, rfl⟩
  unfold ScheduledSource.wordStream
  rw [dif_pos hex]
  obtain ⟨hc, hcall⟩ := Classical.choose_spec hex
  rw [P.call_injective_on hc ht hcall]

/-- Read a compact block through the indexed interface used by the online
estimator. The default is outside the actual legal draw positions. -/
def wordBatchRead {N length bits : ℕ} (draw : WordBatch N length bits) (k : ℕ) : ℕ → ℕ :=
  if hk : k < N then finiteWord (2 ^ bits) length (draw ⟨k, hk⟩) else fun _ => 0

/-- Every actual recorded block realizes the reference index at the same
pick. This compares the two processes on the very same words. -/
theorem ScheduledSource.runOnlineStream_eq_wordTape_of_read
    (P : ScheduledSource E V) (R : GridUpdateParameters) (W epsilon p : ℚ)
    (oracle : Finset E → ℚ) (hobj : P.objective = fun A => (oracle A : ℝ))
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ P.span) (hwidth : (W : ℝ) = P.width)
    (hepsilon : (epsilon : ℝ) = P.epsilon) (hR : ∀ tau > 0, R.Matches (P.config tau))
    {N : ℕ} (batches : ℕ → Fin N → ℝ) (read : ℕ → ℕ → ℕ → ℕ)
    (h : ∀ t < P.calls.length,
      let ctx := P.context t (P.history batches t)
      ∃ draw : WordBatch N ctx.ordered.length ctx.bits,
        read t = wordBatchRead draw ∧ batches t = fun j => ctx.wordObserve oracle p (draw j))
    (a : ℕ) (ha : a ≤ P.arrivals) :
    runOnlineStream R P.ends W epsilon P.span P.vertices oracle (dyadicThreshold p P.bits)
        N P.edges (P.wordStream read) a =
      runOnlineIndexed R P.ends W P.span (fun i => oracle {P.edges i}) P.edges (P.tapeIndex batches) a := by
  let context := fun t => P.context t (P.history batches t)
  let coins := P.wordStream read
  apply P.runOnlineStream_eq_of_batches R W epsilon oracle hobj hW hspan hwidth _ batches coins _ a ha
  intro t ht
  let c := P.call t
  let ctx := context t
  let value := fun i => oracle {P.edges i}
  let old := runOnlineIndexed R P.ends W P.span value P.edges (P.tapeIndex batches) c.1
  let st := old.initialize (old.epoch.resets W (value c.1)) c.2
  let scale := (old.epoch.step W P.span (value c.1)).scale c.2
  let gap := epsilon * scale / (P.vertices : ℚ) ^ 2
  change st.weightIndex oracle (P.edges c.1) gap (dyadicThreshold p P.bits) N (coins c.1 c.2) =
    P.tapeIndex batches c.1 c.2
  have hst := (P.online_prefix_represents R W oracle hobj hW hspan hwidth hR batches ht).2
  have hs : (scale : ℝ) = P.tau c := by
    unfold scale
    rw [runOnlineIndexed_epoch]
    exact P.replay_scale W oracle hobj hwidth c.1 c.2
  have hact := (P.call_active ht).2
  have htau : 0 < P.tau c := hact.1.trans_le hact.2.1
  have hgap : (gap : ℝ) = ctx.config.gap := by
    change (gap : ℝ) = (P.config (P.tau c)).gap
    unfold gap
    push_cast
    rw [hepsilon, hs, P.config_gap _ htau, P.config_tau _ htau]
  obtain ⟨block, hread, hraw⟩ := h t ht
  have hcoins : coins c.1 c.2 = wordBatchRead block :=
    (P.wordStream_at_call read ht).trans hread
  rw [hcoins]
  have hweight := st.weightIndex_wordObserve ctx oracle p gap hst hgap block
  have htape : P.tapeIndex batches c.1 c.2 = sourceWeightIndex N (sourceIndex ctx.config.gap (batches t)) := by
    change sourceWeightIndex N (sourceIndex ctx.config.gap (P.history batches P.calls.length c)) = _
    rw [P.history_at_completed batches ht le_rfl]
  rw [htape, hraw]
  have he : (ctx.input ctx.index).1 = P.edges c.1 := P.context_edge t (P.history batches t)
  simpa only [he] using hweight


/-- Each legal tape can be executed online, with agreement at every prefix.
All sample batches, including those failing the accuracy event, are covered. -/
theorem ScheduledSource.exists_runOnlineStream_eq_wordTape
    (P : ScheduledSource E V) (R : GridUpdateParameters) (W epsilon p : ℚ)
    (oracle : Finset E → ℚ) (hobj : P.objective = fun A => (oracle A : ℝ))
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ P.span) (hwidth : (W : ℝ) = P.width)
    (hepsilon : (epsilon : ℝ) = P.epsilon) (hR : ∀ tau > 0, R.Matches (P.config tau))
    {N : ℕ} (batches : ℕ → Fin N → ℝ)
    (h : ∀ t < P.calls.length, P.HasWordBatch oracle p batches t) :
    ∃ coins : ℕ → ℕ → ℕ → ℕ → ℕ, ∀ a ≤ P.arrivals,
      runOnlineStream R P.ends W epsilon P.span P.vertices oracle (dyadicThreshold p P.bits)
          N P.edges coins a =
        runOnlineIndexed R P.ends W P.span (fun i => oracle {P.edges i}) P.edges (P.tapeIndex batches) a := by
  let context := fun t => P.context t (P.history batches t)
  let block (t : ℕ) (ht : t < P.calls.length) : WordBatch N (context t).ordered.length (context t).bits :=
    Classical.choose (h t ht)
  let read (t : ℕ) : ℕ → ℕ → ℕ :=
    if ht : t < P.calls.length then wordBatchRead (block t ht) else fun _ _ => 0
  refine ⟨P.wordStream read, ?_⟩
  intro a ha
  apply P.runOnlineStream_eq_wordTape_of_read R W epsilon p oracle hobj hW hspan hwidth hepsilon hR batches read _ a ha
  intro t ht
  refine ⟨block t ht, dif_pos ht, ?_⟩
  exact Classical.choose_spec (h t ht)

end

end SubmodularMatching.Streaming
