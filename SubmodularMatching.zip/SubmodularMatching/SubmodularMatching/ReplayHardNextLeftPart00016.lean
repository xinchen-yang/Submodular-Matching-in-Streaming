import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextLeft

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step85 : ProjectedGoal ⟨216, 431, 141, 283, 567, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0x35ff0000000000000002404e) (by decide +kernel)

theorem Part00016 : ProjectedGoal ⟨216, 431, 141, 283, 567, 1135⟩ := step85

end SubmodularMatching.SourceCertificate.Replay.HardNextLeft
