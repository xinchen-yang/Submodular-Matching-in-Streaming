import SubmodularMatching.CertificateOriginalGrid

/-!
# Rectangular lower bounds from one-dimensional certificates

A multiplier for the positive-part term separates the two price variables
inside a rectangle. Each one-dimensional lower bound then follows from
its two interval endpoints and the knots inside that interval.
-/

namespace SubmodularMatching.SourceCertificate

noncomputable section

theorem source_affine_on_box_axis (T : SourcePotentialTable) (b : Bool)
    (weight penalty lower lo hi x : ℝ)
    (hlo : 0 ≤ lo) (hxlo : lo ≤ x) (hxhi : x ≤ hi)
    (hleft : lower ≤ weight * T.value b lo - penalty * lo)
    (hright : lower ≤ weight * T.value b hi - penalty * hi)
    (hknots : ∀ i ≤ T.count, lo ≤ T.realKnot i → T.realKnot i ≤ hi →
      lower ≤ weight * T.value b (T.realKnot i) - penalty * T.realKnot i) :
    lower ≤ weight * T.value b x - penalty * x := by
  have hcover := clippedKnots_cover T.realKnot T.count hi (T.value b)
    T.knot_zero (T.piecewiseAffine b).1 (T.piecewiseAffine b).2
  obtain ⟨l, hl_mem, r, hr_mem, hl, hr, slope, intercept, hlin⟩ :=
    hcover x (hlo.trans hxlo) hxhi
  let l' := max lo l
  let r' := min hi r
  have hL : l' ≤ x := max_le hxlo hl
  have hR : x ≤ r' := le_min hxhi hr
  have hcell (y : ℝ) (hy : l' ≤ y) (hy' : y ≤ r') :
      weight * T.value b y - penalty * y = (weight * slope - penalty) * y + weight * intercept := by
    rw [hlin y ((le_max_right _ _).trans hy) (hy'.trans (min_le_right _ _))]
    ring
  have hL' : lower ≤ weight * T.value b l' - penalty * l' := by
    rcases max_choice lo l with h | h
    · rw [show l' = lo from h]
      exact hleft
    · have hll : lo ≤ l := h ▸ le_max_left lo l
      rcases clippedKnots_cases T hi l hl_mem with heq | ⟨i, hi', heq⟩
      · rw [show l' = l from h, heq]
        exact hright
      · rw [show l' = l from h, heq]
        exact hknots i hi' (heq ▸ hll) (heq ▸ (hl.trans hxhi))
  have hR' : lower ≤ weight * T.value b r' - penalty * r' := by
    rcases min_choice hi r with h | h
    · rw [show r' = hi from h]
      exact hright
    · have hrr : r ≤ hi := h ▸ min_le_left hi r
      rcases clippedKnots_cases T hi r hr_mem with heq | ⟨i, hi', heq⟩
      · rw [show r' = r from h, heq]
        exact hright
      · rw [show r' = r from h, heq]
        exact hknots i hi' (heq ▸ (hxlo.trans hr)) (heq ▸ hrr)
  rw [hcell l' le_rfl (hL.trans hR)] at hL'
  rw [hcell r' (hL.trans hR) le_rfl] at hR'
  rw [hcell x hL hR]
  exact affine_lower_of_endpoints _ _ _ _ _ _ hL hR hL' hR'

theorem source_affine_axis_at_knots (T : SourcePotentialTable) (b : Bool)
    (weight penalty lower : ℝ) (lo hi : ℕ) (hlohi : lo ≤ hi) (hhi : hi ≤ T.count)
    (hknots : ∀ k, lo ≤ k → k ≤ hi →
      lower ≤ weight * T.value b (T.realKnot k) - penalty * T.realKnot k)
    (x : ℝ) (hx : T.realKnot lo ≤ x) (hx' : x ≤ T.realKnot hi) :
    lower ≤ weight * T.value b x - penalty * x := by
  apply source_affine_on_box_axis T b weight penalty lower _ _ x
    (T.nonnegative _ (hlohi.trans hhi)) hx hx'
    (hknots lo le_rfl hlohi) (hknots hi hlohi le_rfl)
  intro k hk hkl hku
  have hl : lo ≤ k := by
    by_contra h
    have h' := T.ordered.lt (lt_of_not_ge h) (hlohi.trans hhi)
    exact (not_le_of_gt h') hkl
  have hu : k ≤ hi := by
    by_contra h
    have h' := T.ordered.lt (lt_of_not_ge h) hk
    exact (not_le_of_gt h') hku
  exact hknots k hl hu

/-- One multiplier and two univariate certificates give a lower bound on an
entire price rectangle, and may be reused across a range of mode parameters. -/
theorem source_box_dual_lower (T : SourcePotentialTable) (i j : Bool)
    (weightA weightB weightA' weightB' penaltyA penaltyB q c target : ℝ)
    (t L R a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d)
    (hweightA : weightA' ≤ weightA) (hweightB : weightB' ≤ weightB)
    (hpenaltyA : t * c ≤ penaltyA) (hpenaltyB : t * (1 - c) ≤ penaltyB)
    (ht0 : 0 ≤ t) (htq : t ≤ q)
    (hL : L ≤ weightA' * T.value i a - penaltyA * a)
    (hR : R ≤ weightB' * T.value j d - penaltyB * d)
    (htarget : target ≤ L + R + t) :
    target ≤ gridValue (fun x => weightA * T.value i x) (fun y => weightB * T.value j y)
      q c a d := by
  have hW1 := mul_le_mul_of_nonneg_right hweightA (T.value_nonnegative i a ha)
  have hW2 := mul_le_mul_of_nonneg_right hweightB (T.value_nonnegative j d hd)
  have hP1 := mul_le_mul_of_nonneg_right hpenaltyA ha
  have hP2 := mul_le_mul_of_nonneg_right hpenaltyB hd
  have hmax :
      t * (1 - c * a - (1 - c) * d) ≤ q * max (1 - c * a - (1 - c) * d) 0 :=
    (mul_le_mul_of_nonneg_left (le_max_left _ _) ht0).trans
      (mul_le_mul_of_nonneg_right htq (le_max_right _ _))
  unfold gridValue
  nlinarith only [hW1, hW2, hP1, hP2, hmax, hL, hR, htarget]

/-- At either saturated price the other summands are nonnegative. -/
theorem source_tail_lower (T : SourcePotentialTable) (i j : Bool)
    (u v q c target x y a d : ℝ) (hu : 0 ≤ u) (hv : 0 ≤ v) (hq : 0 ≤ q)
    (ha : 0 ≤ a) (hd : 0 ≤ d)
    (hX : target ≤ u * T.value i x) (hY : target ≤ v * T.value j y)
    (htail : x ≤ a ∨ y ≤ d) :
    target ≤ gridValue (fun s => u * T.value i s) (fun s => v * T.value j s) q c a d := by
  have hpositive := mul_nonneg hq (le_max_right (1 - c * a - (1 - c) * d) 0)
  unfold gridValue
  rcases htail with h | h
  · have hmono := mul_le_mul_of_nonneg_left (T.value_monotone i h) hu
    linarith only [hX, hmono, hpositive, mul_nonneg hv (T.value_nonnegative j d hd)]
  · have hmono := mul_le_mul_of_nonneg_left (T.value_monotone j h) hv
    linarith only [hY, hmono, hpositive, mul_nonneg hu (T.value_nonnegative i a ha)]

end

end SubmodularMatching.SourceCertificate
