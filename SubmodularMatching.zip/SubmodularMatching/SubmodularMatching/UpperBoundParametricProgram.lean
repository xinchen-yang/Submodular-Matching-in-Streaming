import SubmodularMatching.UpperBoundParametricPreparation
import SubmodularMatching.UpperBoundParametricAmplification
import SubmodularMatching.UpperBoundGraphInput

/-! # Finite positive-value program for the approximation family -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler Streaming NumericalCertificate
open scoped BigOperators

noncomputable section

/-- The source rates stay fixed. These rational and integer choices specify
one member of the approximation family and its two target factors. -/
structure FamilyParameters (slack : ℝ) where
  K : ℕ
  K_pos : 0 < K
  p : ℚ
  p_pos : 0 < p
  p_source : (p : ℝ) ≤ coordinateCap
  error_small : (1 : ℝ) / K < 1 / 4
  p_round : (p : ℝ) ≤ (1 / (K : ℝ)) ^ 5 / 163840
  factor_margin : familyExpectedFactor (1 / (K : ℝ)) < 1 / sigma + slack / 2
  selector_margin : 1 / (1 / sigma + slack) ≤ 1 / (1 / sigma + slack / 2) - (1 / (K : ℝ)) / 2

namespace FamilyParameters

variable {slack : ℝ} (a : FamilyParameters slack)

abbrev error : ℝ := 1 / (a.K : ℝ)
abbrev intermediate (_params : FamilyParameters slack) : ℝ := 1 / sigma + slack / 2
abbrev target (_params : FamilyParameters slack) : ℝ := 1 / sigma + slack

theorem error_pos : 0 < a.error := div_pos one_pos (by exact_mod_cast a.K_pos)

theorem error_lt_one : a.error < 1 := a.error_small.trans (by norm_num)

theorem p_le_one : (a.p : ℝ) ≤ 1 := a.p_source.trans (coordinate_condition.2.trans (min_le_left _ _))

def settings : FamilyOptimizerSettings :=
  ⟨a.p, a.error, ⟨by exact_mod_cast a.p_pos.le, a.p_le_one⟩, a.error_pos, a.error_lt_one⟩

theorem intermediate_gt_one (hs : 0 < slack) : 1 < a.intermediate := by
  have h : (1 : ℝ) < 1 / sigma := by norm_num [sigma]
  dsimp only [intermediate]
  linarith

theorem target_ge_one (hs : 0 < slack) : 1 ≤ a.target := by
  have h : (1 : ℝ) < 1 / sigma := by norm_num [sigma]
  dsimp only [target]
  linarith

theorem intermediate_lt_target (hs : 0 < slack) : a.intermediate < a.target := by
  dsimp only [intermediate, target]
  linarith

theorem trial_factor_margin : familyTrialFactor a.error < a.intermediate :=
  (family_trial_factor_bound a.error a.error_pos.le a.error_small.le).trans_lt a.factor_margin

def trialSuccess : ℝ :=
  (a.intermediate - familyTrialFactor a.error) / (familyTrialFactor a.error * (a.intermediate - 1))

theorem trialSuccess_pos (hs : 0 < slack) : 0 < a.trialSuccess := by
  have hF : 0 < familyTrialFactor a.error := by
    unfold familyTrialFactor
    exact div_pos (by linarith only [a.error_pos]) (mul_pos (sub_pos.mpr a.error_lt_one) sigma_pos)
  exact div_pos (sub_pos.mpr a.trial_factor_margin) (mul_pos hF (sub_pos.mpr (a.intermediate_gt_one hs)))

/-- This integer is fixed when the family member is chosen. -/
def trialMultiplier : ℕ := ⌈1 / a.trialSuccess⌉₊

/-- The confidence budget uses natural multiplication by the fixed
success multiplier and a binary precision counter. -/
def trials (δ : ℝ) : ℕ := a.trialMultiplier * binaryBudget (2 / δ) + 1

theorem trials_ge (hs : 0 < slack) (δ : ℝ) (hδ : 0 < δ) :
    Real.log (2 / δ) / a.trialSuccess ≤ (a.trials δ : ℝ) := by
  have h := div_le_div_of_nonneg_right (binaryBudget_log (2 / δ) (by positivity))
    (a.trialSuccess_pos hs).le
  apply h.trans
  rw [div_eq_mul_inv, ← one_div, mul_comm]
  push_cast [trials]
  have hC : 1 / a.trialSuccess ≤ (a.trialMultiplier : ℝ) := Nat.le_ceil _
  exact (mul_le_mul_of_nonneg_right hC (Nat.cast_nonneg _)).trans (le_add_of_nonneg_right zero_le_one)

theorem exists_parameters (slack : ℝ) (hs : 0 < slack) : Nonempty (FamilyParameters slack) := by
  let p₀ : ℚ := 1 / 10 ^ 48
  have hp₀ : 0 < p₀ := by positivity
  obtain ⟨K, p, he, he4, _, hp, hpp₀, hpround, _, hfactor, hmargin⟩ :=
    family_parameter_choice slack p₀ hs hp₀
  have hK : 0 < K := by
    by_contra! h
    have hz : K = 0 := by omega
    simp [hz] at he
  have hpcast : (p : ℝ) ≤ coordinateCap := by
    have hr := Rat.cast_le (K := ℝ).2 hpp₀
    norm_num [p₀, coordinateCap] at hr ⊢
    exact hr
  exact ⟨⟨K, hK, p, hp, hpcast, he4, hpround, hfactor, hmargin.le⟩⟩

end FamilyParameters

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- A nontrivial scheduled source input. An empty or zero-valued graph is
handled by the outer graph wrapper. -/
structure FamilyProgramInput {slack : ℝ} (a : FamilyParameters slack)
    (E V : Type*) [DecidableEq E] [DecidableEq V] [Fintype V] where
  schedule : ScheduledSource E V
  atLeastTwo : 2 ≤ schedule.vertices
  vertices : schedule.vertices = Fintype.card V
  epsilon : schedule.epsilon = a.error
  configuration : schedule.config =
    parametricGuessConfig schedule.vertices atLeastTwo a.K a.K_pos a.p a.p_pos a.p_source
  noRepeat : ∀ i < schedule.arrivals, ∀ j < schedule.arrivals,
    schedule.edges i = schedule.edges j → i = j
  loopless : ∀ e, (schedule.ends e).1 ≠ (schedule.ends e).2
  simple : Function.Injective (TwoStage.pairEnds schedule.ends)
  allArrived : ∀ e, e ∈ arrivedEdges schedule.edges schedule.arrivals
  positiveBest : 0 < singletonMaximum schedule.value schedule.arrivals
  bestIndex : ℕ
  bestIndex_arrived : bestIndex < schedule.arrivals
  bestIndex_value : schedule.value bestIndex = singletonMaximum schedule.value schedule.arrivals

namespace FamilyProgramInput

variable {slack : ℝ} {a : FamilyParameters slack} (I : FamilyProgramInput a E V)

abbrev P : ScheduledSource E V := I.schedule
abbrev L : ℕ := I.P.span + 1
abbrev B : ℝ := singletonMaximum I.P.value I.P.arrivals

def initial : Finset E := {I.P.edges I.bestIndex}

def feasible : Finset (Finset E) := arrivedMatchings I.P.ends I.P.edges I.P.arrivals

omit [Fintype E] in
theorem initial_legal : I.initial ∈ I.feasible :=
  arrived_singleton_matching _ _ _ _ I.bestIndex_arrived

omit [Fintype E] in
theorem initial_value : I.P.objective I.initial = I.B := I.bestIndex_value

abbrev Ns (ω : ℝ) : ℕ := parametricSourceSamples a.error I.P.vertices I.L ω
abbrev Ng (ω : ℝ) : ℕ := parametricGradientSamples a.error (I.P.vertices ^ 2) I.L ω
abbrev Tape (ω : ℝ) := PreparedTape I.P (I.Ns ω) (I.Ng ω)

def preprocessed (ω : ℝ) : CandidateLaw (I.Tape ω) :=
  parametricPreparationLaw a.settings I.P (sourceTape I.P (I.Ns ω)) I.noRepeat

omit [Fintype E] in
theorem preprocessed_failure (ω : ℝ) (hω : 0 < ω) (hω1 : ω ≤ 1) :
    let q := I.preprocessed ω
    expected q.outcomes q.mass (preparationFailure I.P) ≤ ω := by
  have hsample := parametricSourceSamples_spec a.error I.P.vertices I.L ω hω
  apply parametricPreparationLaw_failure a.settings I.P _ I.noRepeat I.allArrived I.positiveBest ω hω hω1
  apply sourceTape_failure_budget I.P (I.Ns ω) (sourceSampleExponent I.P.vertices I.L ω) I.L ω
    hsample.1 (by rfl) _ hsample.2.2
  rw [I.epsilon]
  exact hsample.2.1

def candidates (ω : ℝ) (t : I.Tape ω) : List (CandidateLaw (Finset E)) :=
  parametricFinalGuessCandidates I.P a.K a.K_pos t.stream I.noRepeat I.loopless
    (parametricFinalDiscountGrid a.settings I.P t.stream) (fun j => (t.optimizer j).draw)

omit [Fintype E] in
theorem candidates_legal (ω : ℝ) (t : I.Tape ω) :
    ∀ q ∈ I.candidates ω t, q.outcomes ⊆ I.feasible :=
  parametricFinalGuessCandidates_legal _ _ _ _ I.noRepeat I.loopless _ _

theorem conditional_quality (ω : ℝ) (hω : 0 < ω)
    (hcert : AppendixSourceObligation I.P.vertices I.atLeastTwo)
    (O : Finset E) (hO : O ∈ I.feasible)
    (t : I.Tape ω) (ht : t ∈ (I.preprocessed ω).outcomes) (hg : preparedGood I.P t) :
    let y := scanExpectation I.P.objective (a.error * I.B / 2)
      I.P.objective (I.candidates ω t) I.initial
    I.B ≤ y ∧ (1 - a.error) * sigma * I.P.objective O ≤ y + 5 * a.error * I.B := by
  have hv : 0 < Fintype.card V := by rw [← I.vertices]; exact I.P.vertices_pos
  have hE : 0 < Fintype.card E := Fintype.card_pos_iff.mpr ⟨I.P.edges I.bestIndex⟩
  have hpre := parametricPreparationLaw_support a.settings I.P (sourceTape I.P (I.Ns ω)) I.noRepeat t ht
  have hp (j : ℕ) : a.settings.p = (finalGuessConfig I.P j).p := by
    unfold finalGuessConfig
    rw [I.configuration, parametricGuessConfig_p]
    rfl
  exact parametricFinalTrial_quality I.P I.atLeastTwo I.vertices a.K a.K_pos a.p a.p_pos a.p_source
    a.error_small a.p_round I.epsilon I.configuration hcert
    t.stream (parametricSourceSamples_spec a.error I.P.vertices I.L ω hω).1 I.noRepeat I.loopless I.simple
    I.allArrived hv hE (parametricFinalDiscountGrid a.settings I.P t.stream) (fun j => (t.optimizer j).draw)
    hg.1 (parametricOptimizerFamilyGood_accurate a.settings I.P t.stream I.noRepeat t.optimizer hpre.2 hg.2 a.K rfl hp)
    O I.initial hO I.initial_value I.positiveBest

def expectedLaw : CandidateLaw (Finset E) :=
  expectedOutputLaw (I.preprocessed a.error) I.feasible I.P.objective (a.error * I.B / 2)
    (I.candidates a.error) I.initial I.initial_legal (I.candidates_legal a.error)

def amplifiedLaw (δ : ℝ) : CandidateLaw (Finset E) :=
  let ω := min a.error (δ / 2)
  amplifiedOutputLaw (I.preprocessed ω) I.feasible I.P.objective (a.error * I.B / 2)
    (I.candidates ω) I.initial I.initial_legal (I.candidates_legal ω) (a.trials δ)

theorem output_legal (δ : ℝ) : I.expectedLaw.outcomes ⊆ I.feasible ∧
    (I.amplifiedLaw δ).outcomes ⊆ I.feasible :=
  ⟨expectedOutputLaw_supported _ _ _ _ _ _ _ _, amplifiedOutputLaw_supported _ _ _ _ _ _ _ _ _⟩

theorem preprocessed_bad_mass (ω : ℝ) (hω : 0 < ω) (hω1 : ω ≤ 1) :
    let q := I.preprocessed ω
    by classical exact (∑ t ∈ q.outcomes, if preparedGood I.P t then 0 else q.mass t) ≤ ω := by
  classical
  dsimp only
  have h := I.preprocessed_failure ω hω hω1
  unfold expected preparationFailure at h
  simpa only [mul_ite, mul_zero, mul_one] using h

theorem approximation_expectation (hs : 0 < slack)
    (hcert : AppendixSourceObligation I.P.vertices I.atLeastTwo)
    (O : Finset E) (hO : O ∈ I.feasible)
    (hopt : ∀ M ∈ I.feasible, I.P.objective M ≤ I.P.objective O) :
    I.P.objective O / a.target ≤ expected I.expectedLaw.outcomes I.expectedLaw.mass I.P.objective := by
  classical
  let e := a.error
  have hnonneg (M : Finset E) : 0 ≤ I.P.objective M := by
    simpa only [I.P.normalized] using I.P.monotone ∅ M (Finset.empty_subset M)
  have hF : 0 < familyExpectedFactor e := by
    unfold familyExpectedFactor
    exact div_pos (by linarith only [a.error_pos]) (mul_pos (sq_pos_of_pos (sub_pos.mpr a.error_lt_one)) sigma_pos)
  calc
    _ ≤ I.P.objective O / familyExpectedFactor e :=
      div_le_div_of_nonneg_left (hnonneg O) hF (a.factor_margin.trans (a.intermediate_lt_target hs)).le
    _ ≤ _ := parametricProgram_expected (I.preprocessed e) (preparedGood I.P) I.feasible I.P.objective
      (I.candidates e) I.initial e (I.P.objective O) I.B a.error_pos.le a.error_lt_one (hnonneg O)
      I.initial_legal (I.candidates_legal e) (fun M hM => ⟨hnonneg M, hopt M hM⟩)
      (I.preprocessed_bad_mass e a.error_pos a.error_lt_one.le)
      (I.conditional_quality e a.error_pos hcert O hO)

theorem approximation_high_probability (hs : 0 < slack)
    (hcert : AppendixSourceObligation I.P.vertices I.atLeastTwo)
    (O : Finset E) (hO : O ∈ I.feasible)
    (hopt : ∀ M ∈ I.feasible, I.P.objective M ≤ I.P.objective O) (δ : ℝ) (hδ : 0 < δ) :
    let q := I.amplifiedLaw δ
    expected q.outcomes q.mass (fun M => if I.P.objective O / a.target ≤ I.P.objective M
      then 0 else 1) ≤ δ := by
  classical
  dsimp only
  let ω := min a.error (δ / 2)
  have hw : 0 < ω := lt_min a.error_pos (by positivity)
  have hw1 : ω ≤ 1 := (min_le_left _ _).trans a.error_lt_one.le
  have hBopt : I.B ≤ I.P.objective O := I.initial_value ▸ hopt I.initial I.initial_legal
  exact parametricProgram_high_probability (I.preprocessed ω) (preparedGood I.P)
    I.feasible I.P.objective (I.candidates ω) I.initial a.error (I.P.objective O) I.B δ a.intermediate a.target
    a.error_pos a.error_lt_one (I.positiveBest.trans_le hBopt) I.positiveBest hBopt hδ
    (a.intermediate_gt_one hs) (zero_lt_one.trans_le (a.target_ge_one hs)) a.trial_factor_margin
    a.selector_margin I.initial_legal (I.candidates_legal ω) hopt
    ((I.preprocessed_bad_mass ω hw hw1).trans (min_le_right _ _))
    (I.conditional_quality ω hw hcert O hO) (a.trials δ) (a.trials_ge hs δ hδ)

end FamilyProgramInput

end

end SubmodularMatching.UpperBoundAssembly
