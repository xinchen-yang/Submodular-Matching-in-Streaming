import SubmodularMatching.UpperBoundParametricProgram
import SubmodularMatching.UpperBoundGeneralInput
import SubmodularMatching.UpperBoundConfidence

/-! # The family guarantee on arbitrary finite simple graph inputs -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler Streaming NumericalCertificate

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

namespace SimpleEdgeStream

variable (S : SimpleEdgeStream E V) {slack : ℝ} (a : FamilyParameters slack)

/-- Instantiate the schedule only in the branch with a positive singleton.
Its dummy edge is used solely for indices outside the finite input prefix. -/
def familyPositiveProgram (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (hzero : f ∅ = 0) (hpos : ∃ e, 0 < f {e}) : FamilyProgramInput a E V := by
  let e := hpos.choose
  let n := Fintype.card V
  let hn := S.vertices_atLeastTwo e
  let P := parametricScheduledSource (S.edgeAt e) S.ends f n S.arrivals.length hn
    S.arrivals_bound a.K a.K_pos a.p a.p_pos a.p_source hf hmono hzero
  have hB : 0 < singletonMaximum P.value P.arrivals := by
    obtain ⟨j, hj, he⟩ := Finset.mem_image.mp (S.edgeAt_complete e e)
    have hval : P.value j = f {e} := by change f {S.edgeAt e j} = f {e}; rw [he]
    have hh := singleton_le_maximum P.value (Finset.mem_range.mp hj)
    exact hpos.choose_spec.trans_le (hval ▸ hh)
  have hbest := singletonMaximum_attained P.value P.arrivals hB
  exact ⟨P, hn, rfl, rfl, rfl, S.edgeAt_distinct e, S.loopless, S.simple,
    S.edgeAt_complete e, hB, hbest.choose, hbest.choose_spec.1, hbest.choose_spec.2⟩

theorem familyPositiveProgram_feasible (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (hzero : f ∅ = 0) (hpos : ∃ e, 0 < f {e}) :
    (S.familyPositiveProgram a f hf hmono hzero hpos).feasible = S.matchings :=
  S.edgeAt_matchings hpos.choose

def familyExpectedOutput (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f) :
    CandidateLaw (Finset E) := by
  classical
  let g := normalizeObjective f
  have hg := normalizeObjective_properties f hf hmono
  exact if hB : ∃ e, 0 < g {e} then
    (S.familyPositiveProgram a g hg.1 hg.2.1 hg.2.2 hB).expectedLaw else CandidateLaw.pure ∅

def familyAmplifiedOutput (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (delta : ℝ) : CandidateLaw (Finset E) := by
  classical
  let g := normalizeObjective f
  have hg := normalizeObjective_properties f hf hmono
  exact if hB : ∃ e, 0 < g {e} then
    (S.familyPositiveProgram a g hg.1 hg.2.1 hg.2.2 hB).amplifiedLaw delta else CandidateLaw.pure ∅

set_option maxHeartbeats 1000000 in
/-- Corollary L.1 with the original objective and the same static source certificate
as Theorem 1.1. Both output laws cover arbitrary finite simple graphs. -/
theorem approximationFamily_value (hslack : 0 < slack) (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (h0 : 0 ≤ f ∅)
    (hcert : ∀ hn : 2 ≤ Fintype.card V, AppendixSourceObligation (Fintype.card V) hn)
    (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (delta : ℝ) (hδ : 0 < delta) :
    let p := S.familyExpectedOutput a f hf hmono
    let q := S.familyAmplifiedOutput a f hf hmono delta
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / a.target ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / a.target ≤ f M then 0 else 1) ≤ delta := by
  classical
  dsimp only
  let g := normalizeObjective f
  let hg := normalizeObjective_properties f hf hmono
  have hR : 1 ≤ a.target := a.target_ge_one hslack
  by_cases hpos : ∃ e, 0 < normalizeObjective f {e}
  · let p := S.familyPositiveProgram a g hg.1 hg.2.1 hg.2.2 hpos
    have hset := S.familyPositiveProgram_feasible a g hg.1 hg.2.1 hg.2.2 hpos
    have hO' : O ∈ p.feasible := by rw [hset]; exact hO
    have ho' (M : Finset E) (h : M ∈ p.feasible) : p.P.objective M ≤ p.P.objective O := by
      rw [hset] at h
      exact sub_le_sub_right (hopt M h) _
    have hl := p.output_legal delta
    rw [hset] at hl
    have he := p.approximation_expectation hslack (hcert p.atLeastTwo) O hO' ho'
    have hp := p.approximation_high_probability hslack (hcert p.atLeastTwo) O hO' ho' delta hδ
    simp only [familyExpectedOutput, familyAmplifiedOutput, dif_pos hpos]
    refine ⟨hl.1, hl.2, normalizeObjective_expected_transfer f O _ hR h0 _ _
      p.expectedLaw.probability he, ?_⟩
    refine le_trans ((p.amplifiedLaw delta).expected_le _ _ ?_) hp
    intro M _
    change (if f O / a.target ≤ f M then (0 : ℝ) else 1) ≤
      (if g O / a.target ≤ g M then 0 else 1)
    by_cases h : g O / a.target ≤ g M
    · have h' := normalizeObjective_transfer f M O _ hR h0 h
      rw [if_pos h, if_pos h']
    · rw [if_neg h]
      split_ifs <;> norm_num
  · have hz := objective_zero_of_empty_singletons g hg.1 hg.2.1 hg.2.2 hpos O
    have hfO : f O = f ∅ := sub_eq_zero.mp hz
    have hcase : f O / a.target ≤ f ∅ := by rw [hfO]; exact div_le_self h0 hR
    have hempty : ∅ ∈ S.matchings := GibbsMatching.empty_mem_matchings _ _
    simp only [familyExpectedOutput, familyAmplifiedOutput, dif_neg hpos, CandidateLaw.pure_expected]
    exact ⟨Finset.singleton_subset_iff.2 hempty, Finset.singleton_subset_iff.2 hempty, hcase,
      by simpa only [if_pos hcase] using hδ.le⟩

/-- The fixed-accuracy family uses the same inverse-polynomial confidence
parameter as the explicit theorem. -/
theorem approximationFamily_confidence (hslack : 0 < slack) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (h0 : 0 ≤ f ∅)
    (hcert : ∀ hn : 2 ≤ Fintype.card V, AppendixSourceObligation (Fintype.card V) hn)
    (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (hn : 1 ≤ Fintype.card V) (c : ℝ) :
    let n := Fintype.card V
    let δ := (((n : ℝ) ^ ⌈c⌉₊)⁻¹)
    let q := S.familyAmplifiedOutput a f hf hmono δ
    q.outcomes ⊆ S.matchings ∧
      expected q.outcomes q.mass (fun M => if f O / a.target ≤ f M then 0 else 1) ≤
        (n : ℝ) ^ (-c) := by
  classical
  dsimp only
  have hn' : (0 : ℝ) < Fintype.card V := by exact_mod_cast (Nat.zero_lt_one.trans_le hn)
  let δ := (((Fintype.card V : ℝ) ^ ⌈c⌉₊)⁻¹)
  have hδ : 0 < δ := inv_pos.mpr (pow_pos hn' _)
  have h := S.approximationFamily_value a hslack f hf hmono h0 hcert O hO hopt δ hδ
  exact ⟨h.2.1, h.2.2.2.trans (confidence_integer_le _ hn c)⟩

/-- The source certificate's limiting coefficient is the one printed
in the family corollary. -/
theorem limitingSourceFactor : (1 : ℝ) / sigma = 45246551 / 10000000 := by
  norm_num [sigma]

/-- For the chosen rational fixed-accuracy member, the target is exactly
the printed decimal plus the requested positive slack. -/
theorem familyTarget_exact : a.target = 45246551 / 10000000 + slack := by
  unfold FamilyParameters.target
  rw [limitingSourceFactor]

/-- A single rational parameter choice works for every finite input at the
requested approximation factor. -/
theorem approximationFamily_parameters (slack : ℝ) (hs : 0 < slack) :
    Nonempty (FamilyParameters slack) := FamilyParameters.exists_parameters slack hs

end SimpleEdgeStream

end

end SubmodularMatching.UpperBoundAssembly
