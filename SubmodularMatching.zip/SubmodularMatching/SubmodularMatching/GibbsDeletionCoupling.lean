import SubmodularMatching.GibbsDeletion

/-!
# Pathwise vertex-deletion coupling for Gibbs matchings

The two marginals are identified by equality of the expectations of every
test function. Every pair produced by the joint law satisfies the pathwise
unmatched-indicator property in Lemma H.1.
-/

open scoped BigOperators

namespace SubmodularMatching.GibbsMatching

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- An entry of a finite joint law, with duplicate outcomes allowed. -/
structure JointDraw (E : Type*) where
  first : Finset E
  second : Finset E
  mass : ℝ

/-- An expectation against the listed joint law. -/
def jointAverage (draws : List (JointDraw E)) (F : Finset E → Finset E → ℝ) : ℝ :=
  (draws.map (fun x => x.mass * F x.first x.second)).sum

omit [DecidableEq E] in
private theorem jointAverage_append (xs ys : List (JointDraw E))
    (F : Finset E → Finset E → ℝ) :
    jointAverage (xs ++ ys) F = jointAverage xs F + jointAverage ys F := by
  simp [jointAverage]

omit [DecidableEq E] in
private theorem jointAverage_flatMap {A : Type*} (xs : List A)
    (draws : A → List (JointDraw E)) (F : Finset E → Finset E → ℝ) :
    jointAverage (xs.flatMap draws) F = (xs.map (fun x => jointAverage (draws x) F)).sum := by
  induction xs with
  | nil => rfl
  | cons x xs ih => simp [List.flatMap_cons, jointAverage_append, ih]

omit [DecidableEq E] in
private theorem jointAverage_branch (draws : List (JointDraw E))
    (c : ℝ) (transform : Finset E → Finset E) (F : Finset E → Finset E → ℝ) :
    jointAverage (draws.map (fun x => ⟨transform x.second, x.first, c * x.mass⟩)) F =
      c * jointAverage draws (fun D P => F (transform P) D) := by
  induction draws with
  | nil => simp [jointAverage]
  | cons x xs ih =>
    change c * x.mass * F (transform x.second) x.first +
        jointAverage (xs.map (fun y => ⟨transform y.second, y.first, c * y.mass⟩)) F =
      c * (x.mass * F (transform x.second) x.first +
        jointAverage xs (fun D P => F (transform P) D))
    rw [ih]
    ring

private theorem sum_toList_eq {A : Type*} (s : Finset A) (f : A → ℝ) :
    (s.toList.map f).sum = ∑ x ∈ s, f x := by
  rw [Finset.sum_eq_multiset_sum, ← Multiset.sum_coe, ← Multiset.map_coe]
  simp only [Finset.toList, Multiset.coe_toList]

omit [DecidableEq E] in
/-- The two unmatched vectors can differ at one vertex other than `v`.
The matchings themselves agree whenever the first leaves `v` unmatched. -/
structure DeletionAgreement (ends : E → Finset V) (v : V) (M N : Finset E) : Prop where
  outside : ∃ w, ∀ u, u ≠ v → u ≠ w → unmatched ends u M = unmatched ends u N
  same_of_unmatched : unmatched ends v M = 1 → M = N

omit [DecidableEq E] [DecidableEq V] in
/-- A concrete finite coupling of two given expectation operators. -/
structure FiniteCoupling (left right : (Finset E → ℝ) → ℝ)
    (relation : Finset E → Finset E → Prop) where
  draws : List (JointDraw E)
  mass_nonnegative : ∀ x ∈ draws, 0 ≤ x.mass
  left_average : ∀ F, jointAverage draws (fun M _ => F M) = left F
  right_average : ∀ F, jointAverage draws (fun _ N => F N) = right F
  supported : ∀ x ∈ draws, relation x.first x.second

private def diagonal (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (c : ℝ) : List (JointDraw E) :=
  (matchings ends S).toList.map (fun M => ⟨M, M, c * probability ends S activity M⟩)

private theorem diagonal_average (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (c : ℝ) (F : Finset E → Finset E → ℝ) :
    jointAverage (diagonal ends S activity c) F =
      c * expectation ends S activity (fun M => F M M) := by
  simp only [jointAverage, diagonal, List.map_map, Function.comp_def]
  rw [sum_toList_eq, expectation_eq_probability_sum, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro M hM
  ring

private theorem diagonal_properties (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (ha : ∀ e ∈ S, 0 ≤ activity e)
    (c : ℝ) (hc : 0 ≤ c) (v : V) (x : JointDraw E)
    (hx : x ∈ diagonal ends S activity c) :
    0 ≤ x.mass ∧ DeletionAgreement ends v x.first x.second := by
  obtain ⟨M, _, rfl⟩ := List.mem_map.mp hx
  exact ⟨mul_nonneg hc (probability_nonnegative ends S activity ha M),
    ⟨⟨v, fun _ _ _ => rfl⟩, fun _ => rfl⟩⟩

private theorem inserted_deletion_agreement (ends : E → Finset V) (e : E) (v w : V)
    (hew : ends e = {v, w}) (D P : Finset E)
    (h : DeletionAgreement ends w D P) :
    DeletionAgreement ends v (insert e P) D := by
  have he : v ∈ ends e := by simp [hew]
  have hzero : unmatched ends v (insert e P) = 0 := by simp [unmatched_insert, he]
  refine ⟨?_, fun h1 => (by linarith : False).elim⟩
  by_cases hD : unmatched ends w D = 1
  · have hsame := h.same_of_unmatched hD
    refine ⟨w, ?_⟩
    intro u huv huw
    rw [← hsame, unmatched_insert]
    simp [hew, huv, huw]
  · obtain ⟨z, hz⟩ := h.outside
    refine ⟨z, ?_⟩
    intro u huv huz
    by_cases huw : u = w
    · subst u
      have hmatched : unmatched ends w D = 0 := by
        unfold unmatched at hD ⊢
        split_ifs at * <;> simp_all
      rw [unmatched_insert, hmatched, if_pos (by simp [hew])]
    · rw [unmatched_insert, if_neg (by simp [hew, huv, huw])]
      exact (hz u huw huz).symm

/-- Lemma H.1. The two matchings have the exact Gibbs marginals before and
after deletion. The construction first samples the status of `v`; a matched
branch reverses the recursive coupling at the opposite endpoint and inserts
the chosen edge into the smaller matching. -/
theorem exists_vertex_deletion_coupling
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) :
    Nonempty (FiniteCoupling (expectation ends S activity)
      (expectation ends (deleteVertex ends S v) activity) (DeletionAgreement ends v)) := by
  classical
  induction S using Finset.strongInductionOn generalizing v with
  | _ S ih =>
    let H := deleteVertex ends S v
    have hsub : H ⊆ S := deleteVertex_subset ends S v
    have haH : ∀ e ∈ H, 0 ≤ activity e := fun e he => ha e (hsub he)
    by_cases hn : (incident ends S v).Nonempty
    · have hstrict : H ⊂ S := by
        refine Finset.ssubset_iff_subset_ne.mpr ⟨hsub, ?_⟩
        intro heq
        obtain ⟨e, he⟩ := hn
        obtain ⟨heS, hev⟩ := Finset.mem_filter.mp he
        have heH : e ∈ H := heq ▸ heS
        exact (Finset.mem_filter.mp heH).2 hev
      have branch :
          ∀ e ∈ incident ends S v,
            Nonempty (FiniteCoupling (expectation ends H activity)
              (expectation ends (compatibleEdges ends S e) activity)
              (fun D P => DeletionAgreement ends v (insert e P) D)) := by
        intro e he
        obtain ⟨heS, hev⟩ := Finset.mem_filter.mp he
        obtain ⟨w, hwv, hew⟩ := exists_other_endpoint ends e (hends e heS) v hev
        obtain ⟨child⟩ := ih H hstrict haH (fun d hd => hends d (hsub hd)) w
        refine ⟨⟨child.draws, child.mass_nonnegative, child.left_average, ?_, ?_⟩⟩
        · rw [compatibleEdges_eq_delete_pair ends S e v w hew]
          exact child.right_average
        · intro x hx
          exact inserted_deletion_agreement ends e v w hew _ _ (child.supported x hx)
      let I := incident ends S v
      let C (e : I) := Classical.choice (branch e e.property)
      let mass := edgeMean ends S activity
      let uv := unmatchedMean ends S activity v
      let branchDraws (e : I) := (C e).draws.map (fun x =>
        (⟨insert e.val x.second, x.first, mass e.val * x.mass⟩ : JointDraw E))
      let draws := diagonal ends H activity uv ++ I.attach.toList.flatMap branchDraws
      have hmass (e : I) : 0 ≤ mass e.val :=
        edgeMean_nonnegative ends S activity ha _ (Finset.mem_filter.mp e.property).1
      have hdiag : ∀ x ∈ diagonal ends H activity uv,
          0 ≤ x.mass ∧ DeletionAgreement ends v x.first x.second :=
        diagonal_properties ends H activity haH uv (unmatchedMean_bounds ends S activity ha v).1 v
      have hsupport (x : JointDraw E) (hx : x ∈ draws) :
          0 ≤ x.mass ∧ DeletionAgreement ends v x.first x.second := by
        rcases List.mem_append.mp hx with hd | hb
        · exact hdiag x hd
        · obtain ⟨e, _, he⟩ := List.mem_flatMap.mp hb
          obtain ⟨y, hy, rfl⟩ := List.mem_map.mp he
          exact ⟨mul_nonneg (hmass e) ((C e).mass_nonnegative y hy), (C e).supported y hy⟩
      have hsum (F : Finset E → Finset E → ℝ) :
          jointAverage draws F = uv * expectation ends H activity (fun N => F N N) +
            ∑ e ∈ I.attach, mass e.val *
              jointAverage (C e).draws (fun D P => F (insert e.val P) D) := by
        unfold draws
        rw [jointAverage_append, diagonal_average, jointAverage_flatMap, sum_toList_eq]
        congr 1
        apply Finset.sum_congr rfl
        intro e _
        exact jointAverage_branch (C e).draws (mass e.val) (insert e.val) F
      refine ⟨⟨draws, fun x hx => (hsupport x hx).1, ?_, ?_, fun x hx => (hsupport x hx).2⟩⟩
      · intro F
        rw [hsum, expectation_vertex_decomposition ends S activity ha F v]
        congr 1
        simp_rw [(C _).right_average]
        exact Finset.sum_attach I (fun e : E => mass e *
          expectation ends (compatibleEdges ends S e) activity (fun N => F (insert e N)))
      · intro F
        rw [hsum]
        simp_rw [(C _).left_average]
        rw [← Finset.sum_mul, Finset.sum_attach, ← add_mul, vertex_status_total ends S activity ha v,
          one_mul]
    · have heq : H = S := by
        apply Finset.Subset.antisymm hsub
        intro e he
        refine Finset.mem_filter.mpr ⟨he, ?_⟩
        intro hev
        exact hn ⟨e, Finset.mem_filter.mpr ⟨he, hev⟩⟩
      change Nonempty (FiniteCoupling (expectation ends S activity)
        (expectation ends H activity) (DeletionAgreement ends v))
      rw [heq]
      have hd := diagonal_properties ends S activity ha 1 zero_le_one v
      refine ⟨⟨diagonal ends S activity 1, fun x hx => (hd x hx).1, ?_, ?_,
        fun x hx => (hd x hx).2⟩⟩
      · intro F
        simp only [diagonal_average, one_mul]
      · intro F
        simp only [diagonal_average, one_mul]

end

end SubmodularMatching.GibbsMatching
