import SubmodularMatching.ProjectedShearerMarkedScores
import SubmodularMatching.NonmonotoneGridSurvival

/-! # Certified finite-time priority retention for one joint pair of marked samples -/

namespace SubmodularMatching.Shearer
open GibbsMatching AppendixM
open scoped BigOperators

variable {E V L : Type*} [DecidableEq E] [DecidableEq V] [DecidableEq L]
variable (ends : E → Finset V) (label : E → L) (h : Finset L → ℝ) (S : Finset E) (Y : E → ℝ)

def binSupport (k : ℕ) := S ×ˢ Finset.range k
def binEnds (a : E × ℕ) := ends a.1
def binLabel (a : E × ℕ) := label a.1
noncomputable def binMass (Q : ℕ) (a : E × ℕ) := Y a.1 / degree / Q

private theorem earlier_binSupport (m t : ℕ) : earlierAt Prod.snd (binSupport S m) t = binSupport S (min t m) := by
  ext ⟨a,k⟩
  simp [earlierAt,binSupport,lt_min_iff,and_left_comm,and_comm,and_assoc]

private theorem bin_degree (hY : ∀ w, ∑ a ∈ incident ends S w, Y a ≤ degree) (Q k : ℕ) (w : V) :
    ∑ a ∈ incident (binEnds ends) (binSupport S k) w, binMass Y Q a ≤ (k:ℝ)/Q := by
  have he : incident (binEnds ends) (binSupport S k) w = incident ends S w ×ˢ Finset.range k := by
    ext ⟨a,t⟩
    simp [incident,binEnds,binSupport,and_assoc,and_left_comm,and_comm]
  rw [he,Finset.sum_product]
  simp only [binMass,Finset.sum_const,Finset.card_range,nsmul_eq_mul,← Finset.mul_sum,← Finset.sum_div]
  have hh := mul_le_mul_of_nonneg_left (div_le_div_of_nonneg_right
    (div_le_div_of_nonneg_right (hY w) (by norm_num [degree] : 0 ≤ degree)) (Nat.cast_nonneg Q)) (Nat.cast_nonneg k)
  simpa [div_self (by norm_num [degree] : degree ≠ 0), div_eq_mul_inv] using hh

theorem bin_interior (h0 : ∀ a ∈ S, 0 ≤ Y a) (hends : ∀ a ∈ S, (ends a).card = 2)
    (hY : ∀ w, ∑ a ∈ incident ends S w, Y a ≤ degree) (Q k : ℕ) (hk : (k:ℝ)/Q < 1/4) :
    InteriorLaw (binEnds ends) (binSupport S k) (binMass Y Q) := by
  have hr := priorityRoot_probability (div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _)) hk
  apply interiorLaw_of_degree _ hr.1 hr.2.1
  · exact fun a ha => div_nonneg (div_nonneg (h0 _ (Finset.mem_product.mp ha).1) (by norm_num [degree])) (Nat.cast_nonneg Q)
  · exact fun a ha => hends a.1 (Finset.mem_product.mp ha).1
  · exact fun w => (bin_degree ends S Y hY Q k w).trans hr.2.2.ge

/-- The contribution of the selected marks lying in the first input
sample, evaluated on the actual union of the input pair. -/
noncomputable def selectedValue (Q own opp : ℕ) (f : Finset (E×ℕ) → (E×ℕ) → ℝ) (a : E×ℕ) :=
  markedPair (binEnds ends) (binSupport S own) (binSupport S opp) (binMass Y Q) (binMass Y Q)
    (fun A B => if a ∈ A then f (A∪B) a else 0)

/-- The scalar two-layer estimate now acts on actual selected and
surviving coordinate scores from the joint finite experiment. -/
theorem bin_edge_retention (hf : IsSubmodular h) (h0 : ∀ a ∈ S, 0 ≤ Y a)
    (hends : ∀ a ∈ S, (ends a).card = 2) (hY : ∀ w, ∑ a ∈ incident ends S w, Y a ≤ degree)
    (Q m n : ℕ) (hQ : 0 < Q) (hn : 0 < n) (hm : (m:ℝ)/Q = layerOne) (hw : (n:ℝ)/Q = layerTwo)
    (a : E) (ha : a ∈ S) :
    let s := scoreAt (binEnds ends) (binLabel label) h Prod.snd
    let g := survivingAt (binEnds ends) (binLabel label) h Prod.snd
    gamma * ((∑ k ∈ Finset.range m, selectedValue ends S Y Q m n s (a,k)) +
      (∑ k ∈ Finset.range n, selectedValue ends S Y Q n m s (a,k))) ≤
      (∑ k ∈ Finset.range m, selectedValue ends S Y Q m n g (a,k)) +
      (∑ k ∈ Finset.range n, selectedValue ends S Y Q n m g (a,k)) := by
  intro s g
  obtain ⟨u,v,_,huv⟩ := Finset.card_eq_two.mp (hends a ha)
  let P := binSupport S m
  let R := binSupport S n
  let z := binMass Y Q
  let D := binEnds ends
  let labels := binLabel label
  have hq : 0 < (Q:ℝ) := by exact_mod_cast hQ
  obtain ⟨_,hm',_,hnm⟩ := layerDegrees
  have hn' := hnm.trans hm'
  have io : InteriorLaw D P z := bin_interior ends S Y h0 hends hY Q m (hm.trans_lt hm')
  have ip : InteriorLaw D R z := bin_interior ends S Y h0 hends hY Q n (hw.trans_lt hn')
  let c := commonMarkedScore D labels h Prod.snd P R z z u v (label a)
  let gain (k : ℕ) := z (a,0)*c k
  have z0 : 0 ≤ z (a,0) := div_nonneg (div_nonneg (h0 _ ha) (by norm_num [degree])) hq.le
  have hmem (k j : ℕ) (hk : k < j) : (a,k) ∈ binSupport S j := Finset.mem_product.mpr ⟨ha,Finset.mem_range.mpr hk⟩
  have eq1 (k : ℕ) (hk : k ∈ Finset.range m) : selectedValue ends S Y Q m n s (a,k) = gain k :=
    marked_score_contribution D labels h Prod.snd P R z z (a,k) (hmem _ _ (Finset.mem_range.mp hk)) u v huv
  have eq2 (k : ℕ) (hk : k ∈ Finset.range n) : selectedValue ends S Y Q n m s (a,k) = gain k := by
    have hg := marked_score_contribution D labels h Prod.snd R P z z (a,k) (hmem _ _ (Finset.mem_range.mp hk)) u v huv
    rw [commonMarkedScore_swap D labels h Prod.snd R P] at hg
    exact hg
  rw [Finset.sum_congr rfl eq1,Finset.sum_congr rfl eq2]
  have hanti := commonMarkedScore_antitone D labels h Prod.snd P R z z io ip hf u v (label a)
  have hpos := commonMarkedScore_nonneg D labels h Prod.snd P R z z io ip u v (label a)
  apply two_layer_grid_survival Q m n hQ hn hm hw gain _ _
    (fun _ _ hk => mul_le_mul_of_nonneg_left (hanti hk) z0) (fun k => mul_nonneg z0 (hpos k))
  all_goals intro k hk
  all_goals let t := min ((k:ℝ)/Q) layerTwo
  all_goals have hr := priorityRoot_probability (t := t) (le_min (div_nonneg (Nat.cast_nonneg k) hq.le) layerDegrees.2.2.1.le) ((min_le_right ((k:ℝ)/Q) layerTwo).trans_lt hn')
  all_goals have hdeg0 (w j : ℕ) (b : V) : ∑ e ∈ incident D (earlierAt Prod.snd (binSupport S j) w) b, z e ≤ (min w j:ℕ)/ (Q:ℝ) := by rw [earlier_binSupport]; exact bin_degree ends S Y hY Q _ _
  · have cap : ((min k n : ℕ):ℝ)/Q = t := by
      simp only [t,← hw,Nat.cast_min,min_div_div_right hq.le]
    have hv := marked_surviving_contribution D labels h Prod.snd P R z z (a,k) (hmem _ _ hk) u v huv io _ hr.1 hr.2.1
      ip.coordinate_nonneg (fun j hj => hends _ (Finset.mem_product.mp hj).1)
      (fun b => (hdeg0 k n b).trans (cap.trans hr.2.2.symm).le)
    change _ ≤ selectedValue ends S Y Q m n g (a,k)
    dsimp only [timeSurvival,gain]
    exact (le_of_eq (by ring : priorityRoot t ^ 2 * (z (a,0)*c k) = z (a,0)*(priorityRoot t^2*c k))).trans hv
  · have hkn : (k:ℝ)/Q ≤ layerTwo := hw ▸ div_le_div_of_nonneg_right (by exact_mod_cast hk.le) hq.le
    have hnmN : n ≤ m := by exact_mod_cast ((div_le_div_iff_of_pos_right hq).mp (hw.trans_le (hnm.le.trans_eq hm.symm)))
    have cap : ((min k m : ℕ):ℝ)/Q = t := by simp [t,min_eq_left hkn,min_eq_left (hk.le.trans hnmN)]
    have hv := marked_surviving_contribution D labels h Prod.snd R P z z (a,k) (hmem _ _ hk) u v huv ip _ hr.1 hr.2.1
      io.coordinate_nonneg (fun j hj => hends _ (Finset.mem_product.mp hj).1)
      (fun b => (hdeg0 k m b).trans (cap.trans hr.2.2.symm).le)
    rw [commonMarkedScore_swap D labels h Prod.snd R P] at hv
    exact (le_of_eq (by ring : priorityRoot t ^ 2 * (z (a,0)*c k) = z (a,0)*(priorityRoot t^2*c k))).trans hv

end SubmodularMatching.Shearer
