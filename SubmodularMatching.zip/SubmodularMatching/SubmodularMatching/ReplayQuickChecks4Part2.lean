import SubmodularMatching.ReplayQuickRate

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 16000
set_option maxHeartbeats 5000000

theorem quick14336 : allIndexed compareQuick 14336 sourceRates14336 = true := by decide +kernel

end SubmodularMatching.SourceCertificate.Replay
