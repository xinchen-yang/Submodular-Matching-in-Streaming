import SubmodularMatching.UpperBoundCandidateScan

/-! # Finite law of the incumbent returned by a candidate scan -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler

noncomputable section

variable {A B : Type*}

/-- Aggregate all paths that return the same final incumbent. -/
def scanMass (value : A → ℝ) (step : ℝ) (qs : List (CandidateLaw A)) (initial a : A) : ℝ := by
  classical
  exact scanExpectation value step (fun b => if b = a then 1 else 0) qs initial

theorem scanMass_expected (s : Finset A) (value test : A → ℝ) (step : ℝ)
    (qs : List (CandidateLaw A)) (initial : A) (hinit : initial ∈ s)
    (hsupport : ∀ q ∈ qs, q.outcomes ⊆ s) :
    expected s (scanMass value step qs initial) test =
      scanExpectation value step test qs initial := by
  classical
  induction qs generalizing initial with
  | nil =>
    simp only [expected, scanMass, scanExpectation, ite_mul, one_mul, zero_mul]
    rw [Finset.sum_ite_eq _ _ _, if_pos hinit]
  | cons q qs ih =>
    change (∑ b ∈ s, (∑ a ∈ q.outcomes, q.mass a *
        scanMass value step qs (keepBetter value step initial a) b) * test b) =
      ∑ a ∈ q.outcomes, q.mass a * scanExpectation value step test qs
        (keepBetter value step initial a)
    simp_rw [Finset.sum_mul, mul_assoc]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro a ha
    rw [← Finset.mul_sum]
    congr 1
    apply ih _ ?_ (fun r hr => hsupport r (List.mem_cons_of_mem q hr))
    unfold keepBetter
    split_ifs
    · exact hsupport q List.mem_cons_self ha
    · exact hinit

theorem scanMass_probability (s : Finset A) (value : A → ℝ) (step : ℝ)
    (qs : List (CandidateLaw A)) (initial : A) (hinit : initial ∈ s)
    (hsupport : ∀ q ∈ qs, q.outcomes ⊆ s) :
    IsProbability s (scanMass value step qs initial) := by
  classical
  refine ⟨fun b _ => ?_, ?_⟩
  · exact (scanExpectation_range value step _ (fun a => a ∈ s) 0 1 qs initial hinit
      (fun q hq a ha => hsupport q hq ha) (fun a _ => by split_ifs <;> norm_num)).1
  · have h := scanMass_expected s value (fun _ => 1) step qs initial hinit hsupport
    simpa only [expected, mul_one, scanExpectation_const] using h

/-- The same program can be sampled one trial at a time. The mass of its
incumbent is used to analyze repetitions and need not be enumerated. -/
def scanLaw (s : Finset A) (value : A → ℝ) (step : ℝ)
    (qs : List (CandidateLaw A)) (initial : A) (hinit : initial ∈ s)
    (hsupport : ∀ q ∈ qs, q.outcomes ⊆ s) : CandidateLaw A :=
  ⟨s, scanMass value step qs initial, scanMass_probability s value step qs initial hinit hsupport⟩

/-- Probability of a mapped outcome, summing over the source fiber. -/
def CandidateLaw.imageMass (q : CandidateLaw A) (convert : A → B) (b : B) : ℝ := by
  classical
  exact ∑ a ∈ q.outcomes, if convert a = b then q.mass a else 0

theorem CandidateLaw.imageMass_expected (q : CandidateLaw A) (convert : A → B) [DecidableEq B]
    (test : B → ℝ) :
    expected (q.outcomes.image convert) (q.imageMass convert) test =
      expected q.outcomes q.mass (test ∘ convert) := by
  classical
  unfold expected CandidateLaw.imageMass
  simp_rw [Finset.sum_mul, ite_mul, zero_mul]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun a ha => ?_
  rw [Finset.sum_ite_eq _ _ _, if_pos (Finset.mem_image_of_mem convert ha)]
  rfl

/-- Project a local rounding outcome to a matching on the original edges. -/
def CandidateLaw.map (q : CandidateLaw A) (convert : A → B) [DecidableEq B] : CandidateLaw B where
  outcomes := q.outcomes.image convert
  mass := q.imageMass convert
  probability := by
    classical
    constructor
    · intro b _
      unfold CandidateLaw.imageMass
      refine Finset.sum_nonneg fun a ha => ?_
      split_ifs
      · exact q.probability.nonnegative a ha
      · exact le_rfl
    · simpa only [expected, Function.comp_apply, mul_one] using
        (q.imageMass_expected convert (fun _ => 1)).trans (by
          simpa only [expected, Function.comp_apply, mul_one] using q.probability.total)

theorem CandidateLaw.map_expected (q : CandidateLaw A) (convert : A → B) [DecidableEq B]
    (test : B → ℝ) :
    expected (q.map convert).outcomes (q.map convert).mass test =
      expected q.outcomes q.mass (test ∘ convert) :=
  q.imageMass_expected convert test

end

end SubmodularMatching.UpperBoundAssembly
