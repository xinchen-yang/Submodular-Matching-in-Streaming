import SubmodularMatching.StreamingOnlineReplay
import SubmodularMatching.UpperBoundFinalGuess

/-!
# Frozen estimator values for postprocessing

The numerical coefficient read from an executable archived row is the
one used by the final stored-edge objective.
-/

namespace SubmodularMatching.Streaming

variable {E V : Type*} [DecidableEq V]

/-- An archived pair is an unmodified input edge and snapped weight. -/
theorem runOnlineInstance_frozen_record (R : GridUpdateParameters) (ends : E → V × V)
    (input : ℕ → E × ℕ) (n : ℕ) (row : E × ℕ)
    (h : row ∈ (runOnlineInstance R ends input n).edges) :
    ∃ i < n, input i = row := by
  induction n with
  | zero => simp [runOnlineInstance, OnlineInstance.empty] at h
  | succ n ih =>
    rw [runOnlineInstance, OnlineInstance.step] at h
    split at h
    · rw [List.mem_append] at h
      rcases h with h | h
      · obtain ⟨i, hi, he⟩ := ih h
        exact ⟨i, Nat.lt_succ_of_lt hi, he⟩
      · exact ⟨n, Nat.lt_succ_self _, (List.mem_singleton.1 h).symm⟩
    · obtain ⟨i, hi, he⟩ := ih h
      exact ⟨i, Nat.lt_succ_of_lt hi, he⟩

end SubmodularMatching.Streaming

namespace SubmodularMatching.UpperBoundAssembly

open Streaming

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Each physical edge-record weight agrees with the proved final
objective coefficient at the same edge, on every reference transcript. -/
theorem finalGuess_online_frozen_weight
    (P : ScheduledSource E V) (R : GridUpdateParameters) (W : ℚ)
    (oracle : Finset E → ℚ) (hobj : P.objective = fun A => (oracle A : ℝ))
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ P.span) (hwidth : (W : ℝ) = P.width)
    {N : ℕ} (batches : ℕ → Fin N → ℝ) (j : ℕ) (ha : finalGuessActive P j)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (st : OnlineInstance E V)
    (hst : (runOnlineIndexed R P.ends W P.span (fun i => oracle {P.edges i}) P.edges
      (P.tapeIndex batches) P.arrivals).instanceAt j = some st)
    (row : E × ℕ) (hrow : row ∈ st.edges) :
    (finalGuessConfig P j).gap * (row.2 : ℝ) =
      traceWeightIndex (finalGuessInput P batches j) (finalGuessLength P j) row.1 := by
  let value := fun i => oracle {P.edges i}
  have hv : (fun i => (value i : ℝ)) = P.value := by
    funext i
    change (oracle {P.edges i} : ℝ) = P.objective {P.edges i}
    rw [hobj]
  let birth := finalGuessBirth P j
  let len := finalGuessLength P j
  let C := finalGuessConfig P j
  let inp := finalGuessInput P batches j
  let indexed := fun i => (P.edges (birth + i), P.tapeIndex batches (birth + i) j)
  have hh := runOnlineIndexed_instanceAt R P.ends W P.span value P.edges
    (P.tapeIndex batches) hW hspan P.arrivals j
  unfold finalGuessActive at ha
  rw [hwidth, hv, expectedIndexView, if_pos ha] at hh
  have hstate : st = runOnlineInstance R P.ends indexed len := Option.some.inj (hst.symm.trans hh)
  rw [hstate] at hrow
  obtain ⟨i, hi, hrec⟩ := runOnlineInstance_frozen_record R P.ends indexed len row hrow
  have he : (inp i).1 = row.1 := congrArg Prod.fst hrec
  have hw : P.tapeIndex batches (birth + i) j = row.2 := congrArg Prod.snd hrec
  obtain ⟨t, -, hc, -, hs⟩ := P.final_suffix_call j i ha hi
  have hindex : P.tapeIndex batches (birth + i) j = sourceWeightIndex N
      (sourceIndex C.gap (finalGuessSamples P batches j i)) := by
    change P.tapeIndex batches (birth + i) j = sourceWeightIndex N
      (sourceIndex C.gap (P.history batches P.calls.length (birth + i, j)))
    unfold ScheduledSource.tapeIndex
    have hcall : P.call t = (birth + i, j) := hc
    have hscale : P.tau (P.call t) = finalGuessScale P j := hs
    rw [← hcall, hscale]
    rfl
  change C.gap * (row.2 : ℝ) = traceWeightIndex inp len row.1
  rw [← he, traceWeightIndex_record inp len (finalGuessInput_distinct P batches j hunique) i hi,
    ← hw, hindex]
  exact (sourceWeight_eq_index C.gap (finalGuessSamples P batches j i)).symm

end SubmodularMatching.UpperBoundAssembly
