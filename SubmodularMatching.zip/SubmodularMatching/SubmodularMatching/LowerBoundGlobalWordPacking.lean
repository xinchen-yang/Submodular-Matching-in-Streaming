import SubmodularMatching.LowerBoundAssemblyLimit
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Data.Fintype.BigOperators

/-! # Finite packings of words with few coordinate agreements -/

namespace SubmodularMatching.LowerBoundGlobal.AJX

open scoped BigOperators

noncomputable section

variable {m L : ℕ}

def agreement (x y : Fin m → Fin L) : ℕ :=
  (Finset.univ.filter (fun k => x k = y k)).card

@[simp] theorem agreement_self (x : Fin m → Fin L) : agreement x x = m := by
  simp [agreement]

theorem agreement_comm (x y : Fin m → Fin L) : agreement x y = agreement y x := by
  simp only [agreement, eq_comm]

private theorem two_pow_agreement (x y : Fin m → Fin L) :
    2 ^ agreement x y = ∏ k : Fin m, if x k = y k then 2 else 1 := by
  simp [agreement, Finset.prod_ite]

private theorem agreement_weights_sum (x : Fin m → Fin L) :
    ∑ y : Fin m → Fin L, 2 ^ agreement x y = (L + 1) ^ m := by
  have hset : (Finset.univ : Finset (Fin m → Fin L)) =
      Fintype.piFinset (fun _ : Fin m => Finset.univ) := by
    ext y
    simp
  have hs (k : Fin m) : (∑ j : Fin L, if x k = j then 2 else 1) = L + 1 := by
    have hsplit := Finset.add_sum_erase Finset.univ (fun j : Fin L =>
      if x k = j then 2 else 1) (Finset.mem_univ (x k))
    rw [← hsplit]
    have hrest :
        (∑ j ∈ Finset.univ.erase (x k), if x k = j then 2 else 1) =
        (Finset.univ.erase (x k)).card := by
      calc
        _ = ∑ _j ∈ Finset.univ.erase (x k), (1 : ℕ) := by
          apply Finset.sum_congr rfl
          intro j hj
          rw [if_neg (Finset.ne_of_mem_erase hj).symm]
        _ = _ := by simp
    simp only [if_true, hrest, Finset.card_erase_of_mem (Finset.mem_univ (x k)),
      Finset.card_univ, Fintype.card_fin]
    have hpos : 0 < L := (Nat.zero_le _).trans_lt (x k).isLt
    omega
  rw [hset]
  simp_rw [two_pow_agreement]
  refine (Finset.sum_prod_piFinset (Finset.univ : Finset (Fin L))
    (fun k : Fin m => fun j => if x k = j then (2 : ℕ) else 1)).trans ?_
  simp only [hs, Finset.prod_const, Finset.card_univ, Fintype.card_fin]

private def largeAgreement (k : ℕ) (x : Fin m → Fin L) : Finset (Fin m → Fin L) :=
  Finset.univ.filter fun y => k ≤ agreement x y

private theorem largeAgreement_card_mul_le (k : ℕ) (x : Fin m → Fin L) :
    (largeAgreement k x).card * 2 ^ k ≤ (L + 1) ^ m := by
  calc
    _ = ∑ _y ∈ largeAgreement k x, 2 ^ k := (Finset.sum_const_nat (fun _ _ => rfl)).symm
    _ ≤ ∑ y ∈ largeAgreement k x, 2 ^ agreement x y := by
      exact Finset.sum_le_sum fun y hy => Nat.pow_le_pow_right (by decide)
        ((Finset.mem_filter.mp hy).2)
    _ ≤ ∑ y, 2 ^ agreement x y :=
      Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun _ _ _ => Nat.zero_le _)
    _ = _ := agreement_weights_sum x

private theorem alphabet_step (hL : 0 < L) : (L + 1) ^ L ≤ 4 * L ^ L := by
  have hL' : (0 : ℝ) < L := by exact_mod_cast hL
  have hh : ((L : ℝ) + 1) = (L : ℝ) * (1 + 1 / (L : ℝ)) := by
    have he : (L : ℝ) * (1 / (L : ℝ)) = 1 := by field_simp
    rw [mul_add, mul_one, he]
  have hp : (1 + 1 / (L : ℝ)) ^ L ≤ Real.exp 1 := by
    have h := pow_le_pow_left₀ (by positivity : 0 ≤ 1 + 1 / (L : ℝ))
      (show 1 + 1 / (L : ℝ) ≤ Real.exp (1 / (L : ℝ)) by
        simpa only [add_comm] using Real.add_one_le_exp (1 / (L : ℝ))) L
    rw [← Real.exp_nat_mul, show (L : ℝ) * (1 / (L : ℝ)) = 1 by field_simp] at h
    exact h
  exact_mod_cast (show ((L : ℝ) + 1) ^ L ≤ 4 * (L : ℝ) ^ L by
    rw [hh, mul_pow, mul_comm (4 : ℝ)]
    exact mul_le_mul_of_nonneg_left (hp.trans (Real.exp_one_lt_three.le.trans (by norm_num))) (by positivity))

/-- An exponential-size family of words with fewer than (4s)
agreements exists on (Ls) coordinates. The proof takes a maximal
packing and counts its covering neighborhoods by the exact moment
(sum_y 2^{mathrm{agreement}(x,y)}=(L+1)^{Ls}). -/
theorem exists_low_agreement_packing (hL : 4 ≤ L) (s : ℕ) :
    ∃ words : Finset (Fin (L * s) → Fin L),
      4 ^ s ≤ words.card ∧
      (words : Set (Fin (L * s) → Fin L)).Pairwise (fun x y => agreement x y < 4 * s) := by
  classical
  let good := fun S : Finset (Fin (L * s) → Fin L) =>
    (S : Set (Fin (L * s) → Fin L)).Pairwise (fun x y => agreement x y < 4 * s)
  let candidates := (Finset.univ : Finset (Fin (L * s) → Fin L)).powerset.filter good
  have hne : candidates.Nonempty := ⟨∅, by simp [candidates, good]⟩
  obtain ⟨code, hcode, hmax⟩ := Finset.exists_max_image candidates Finset.card hne
  have hgood : good code := (Finset.mem_filter.mp hcode).2
  have hcover : (Finset.univ : Finset (Fin (L * s) → Fin L)) ⊆
      code.biUnion (largeAgreement (4 * s)) := by
    intro x _
    by_contra hx
    have hsmall (y : Fin (L * s) → Fin L) (hy : y ∈ code) : agreement y x < 4 * s := by
      apply lt_of_not_ge
      intro hag
      exact hx (Finset.mem_biUnion.mpr ⟨y, hy, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hag⟩⟩)
    have hnot : x ∉ code := by
      intro hx'
      have hh := hsmall x hx'
      rw [agreement_self] at hh
      exact (not_lt_of_ge (Nat.mul_le_mul_right s hL)) hh
    have hnew : good (insert x code) := by
      intro u hu v hv hne
      have hu' := Finset.mem_insert.mp (show u ∈ insert x code from hu)
      have hv' := Finset.mem_insert.mp (show v ∈ insert x code from hv)
      rcases hu' with hu' | hu'
      · subst u
        rcases hv' with hv' | hv'
        · exact (hne hv'.symm).elim
        · exact (agreement_comm x v).trans_lt (hsmall v hv')
      · rcases hv' with hv' | hv'
        · subst v
          exact hsmall u hu'
        · exact hgood hu' hv' hne
    have hins : insert x code ∈ candidates :=
      Finset.mem_filter.mpr ⟨Finset.mem_powerset.mpr (Finset.subset_univ _), hnew⟩
    have hbound := hmax (insert x code) hins
    rw [Finset.card_insert_of_notMem hnot] at hbound
    omega
  have htotal : L ^ (L * s) * 2 ^ (4 * s) ≤ code.card * (L + 1) ^ (L * s) := by
    calc
      _ = (Finset.univ : Finset (Fin (L * s) → Fin L)).card * 2 ^ (4 * s) := by simp
      _ ≤ (∑ x ∈ code, (largeAgreement (4 * s) x).card) * 2 ^ (4 * s) :=
        Nat.mul_le_mul_right _ ((Finset.card_le_card hcover).trans Finset.card_biUnion_le)
      _ = ∑ x ∈ code, (largeAgreement (4 * s) x).card * 2 ^ (4 * s) := Finset.sum_mul _ _ _
      _ ≤ ∑ _x ∈ code, (L + 1) ^ (L * s) :=
        Finset.sum_le_sum fun x _ => largeAgreement_card_mul_le _ x
      _ = _ := Finset.sum_const_nat fun _ _ => rfl
  have hstep := alphabet_step (L := L) (by omega : 0 < L)
  have hlarge : (L + 1) ^ (L * s) ≤ 4 ^ s * L ^ (L * s) := by
    rw [pow_mul, pow_mul L, ← mul_pow]
    exact Nat.pow_le_pow_left hstep _
  have hcancel : 4 ^ s * L ^ (L * s) * 4 ^ s ≤ code.card * (4 ^ s * L ^ (L * s)) := calc
    _ = L ^ (L * s) * 2 ^ (4 * s) := by
      rw [pow_mul 2, show (2 : ℕ) ^ 4 = 4 * 4 by decide, mul_pow]
      ac_rfl
    _ ≤ code.card * (L + 1) ^ (L * s) := htotal
    _ ≤ _ := Nat.mul_le_mul_left _ hlarge
  refine ⟨code, ?_, hgood⟩
  have hpositive : 0 < 4 ^ s * L ^ (L * s) :=
    Nat.mul_pos (by positivity) (pow_pos (by omega) _)
  exact Nat.le_of_mul_le_mul_left (by simpa only [Nat.mul_comm code.card] using hcancel) hpositive

end

end SubmodularMatching.LowerBoundGlobal.AJX
