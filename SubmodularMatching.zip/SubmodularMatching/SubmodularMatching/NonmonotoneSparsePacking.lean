import SubmodularMatching.NonmonotoneSparseDiffuse
import SubmodularMatching.NonmonotoneLayersDecoder

namespace SubmodularMatching.TwoLayerDiffuse

open GibbsMatching VarianceBound TwoStage
noncomputable section

variable {I C V : Type*} [Fintype I] [Fintype V] [DecidableEq I] [DecidableEq C] [DecidableEq V]

/-- Apply the same tangent constraints to ordinary vertices or slots, on any
sparse diffuse support and independently enumerated pair of sampled layers. -/
theorem packed_sparse_alteration (base : C → Finset V) (active : Finset C)
    (he : ∀ e ∈ active, (base e).card = 2) (ends : I → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (A B : Layer base active) (x : I → ℝ) (hx : ∀ e, 0 ≤ x e)
    (d p ξ θ₁ θ₂ tv te : ℝ) (hd : 0 ≤ d) (hd' : d ≤ 1/3) (hξ : 0 < ξ) (hp : 0 < p)
    (hpc : p ≤ coordinateCap ξ) (hθ₁ : 0 ≤ θ₁) (hθ₂ : 0 ≤ θ₂) (hsum : θ₁+θ₂=1)
    (ℓ : V → ℝ) (hdegree : ∀ v, ℓ v ≤ d)
    (hA : ∀ v, A.deg v = θ₁*ℓ v) (hB : ∀ v, B.deg v = θ₂*ℓ v)
    (hv : ∀ v, Joint.degree ends x v + (1-2*θ₁*θ₂*tv)*ℓ v ≤ 1 - θ₁*θ₂*tv^2)
    (hedge : ∀ e, x e / p + (1-2*θ₁*θ₂*te)*(ℓ (ends e).1 + ℓ (ends e).2)
      ≤ 1 - θ₁*θ₂*te^2) :
    let z := alteredSparse base active ends A B x ξ
    (∀ ω e, 0 ≤ z ω e ∧ z ω e ≤ p) ∧ (∀ ω v, Joint.degree ends (z ω) v ≤ 1) ∧
    (∀ ω e, z ω e ≠ 0 → vacant base active (ends e).1 ω = 1 ∧ vacant base active (ends e).2 ω = 1) ∧
    ∀ e, (1-ξ)*x e ≤ finiteMean (joint A B) (fun ω => z ω e) := by
  intro z
  apply sparse_alteration_verified base active he ends hloop hsimple A B d p ξ hd hd' hξ hp.le hpc _ x hx
  · intro v
    have h₂ := NonmonotoneLayers.freeProb_tangent θ₁ θ₂ (ℓ v) tv hθ₁ hθ₂ hsum
    dsimp only [Layer.free]
    rw [hA,hB]
    unfold NonmonotoneLayers.freeProb at h₂
    linarith only [hv v,h₂]
  · intro e
    have h₂ := NonmonotoneLayers.freeProb_tangent θ₁ θ₂ (ℓ (ends e).1 + ℓ (ends e).2) te hθ₁ hθ₂ hsum
    have hxq : x e / p ≤ NonmonotoneLayers.freeProb θ₁ θ₂ (ℓ (ends e).1 + ℓ (ends e).2) := by
      linarith only [hedge e,h₂]
    have h := (div_le_iff₀ hp).mp hxq
    rw [hA,hA,hB,hB]
    unfold NonmonotoneLayers.freeProb at h
    nlinarith only [h]
  · intro v
    rw [hA,hB,← add_mul,hsum,one_mul]
    exact hdegree v

end
end SubmodularMatching.TwoLayerDiffuse
