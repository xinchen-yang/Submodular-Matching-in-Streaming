import SubmodularMatching.UpperBoundOnlineProgram
import SubmodularMatching.UpperBoundLiveCandidates

/-!
# Rounding with the physical sparse archives

The final scan visits the actual surviving slots. A candidate reads only
that slot's retained edge identifiers and completed optimizer point.
-/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming GibbsSampler

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def archiveEntries (st : OnlineStreamState E V) (j : ℕ) : List (E × ℕ) :=
  ((st.instanceAt j).getD OnlineInstance.empty).edges

omit [DecidableEq E] in
private theorem archiveEntries_get_map (rows : List (E × ℕ))
    (i : Fin (rows.map Prod.fst).length) :
    (rows.map Prod.fst).get i = (rows.get (i.cast (show (rows.map Prod.fst).length = rows.length from List.length_map Prod.fst))).1 := by
  simp only [List.get_eq_getElem, List.getElem_map, Fin.val_cast]

/-- A final edge identifier is read at its bounded archive address. -/
def archiveEmbedding (rows : List (E × ℕ)) (h : (rows.map Prod.fst).Nodup) : Fin rows.length ↪ E :=
  ⟨fun i => (rows.get i).1, by
    intro i k he
    let i' := i.cast (show rows.length = (rows.map Prod.fst).length by simp only [List.length_map])
    let k' := k.cast (show rows.length = (rows.map Prod.fst).length by simp only [List.length_map])
    have hget : (rows.map Prod.fst).get i' = (rows.map Prod.fst).get k' := by
      rw [archiveEntries_get_map, archiveEntries_get_map]
      exact he
    have heq : i' = k' := h.injective_get hget
    exact Fin.ext (congrArg (fun index : Fin (rows.map Prod.fst).length => index.val) heq)⟩

abbrev ArchivePointFamily (st : OnlineStreamState E V) :=
  ∀ j, CurrentOptimizerPoint (archiveEntries st j).length

/-- Scan the physical guess list, ignoring precisely the empty archives on
all legal executions. A compact point is reindexed only by archived rows. -/
def archivedLiveCandidates (st : OnlineStreamState E V) (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (points : ArchivePointFamily st) :
    List (CandidateLaw (Finset E)) :=
  (st.instances.map Prod.fst).filterMap fun j =>
    let rows := archiveEntries st j
    if hm : 0 < rows.length then
      if hn : (rows.map Prod.fst).Nodup then
        some (liveGuessCandidate hm (archiveEmbedding rows hn) ends hloop (points j))
      else none
    else none

private theorem liveGuessCandidate_cast {m n : ℕ} (h : m = n)
    (hm : 0 < m) (hn : 0 < n) (e : Fin m ↪ E) (e' : Fin n ↪ E)
    (he : ∀ i : Fin m, e i = e' (i.cast h))
    (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (point : CurrentOptimizerPoint n) :
    liveGuessCandidate hm e ends hloop (h.symm ▸ point) = liveGuessCandidate hn e' ends hloop point := by
  subst n
  have heq : e = e' := Function.Embedding.ext he
  rw [heq]

variable [Fintype V]

namespace AppendixProgramInput

variable (I : AppendixProgramInput E V)

/-- This witness uses the same numerical points, with only a type-level
change of their compact index type. The archived scan itself has no tape
parameter. -/
def pointsOnArchive {N : ℕ} (st : OnlineStreamState E V) (batches : ℕ → Fin N → ℝ)
    (points : FinalPointFamily I.P batches) : ArchivePointFamily st := fun j =>
  if h : (archiveEntries st j).length = finalGuessCount I.P batches j then h.symm ▸ points j
  else fun _ => 0

/-- On every realized source run, the physical rounding scan agrees with
its proof-side counterpart on every completed optimizer point family. -/
theorem onlineArchiveCandidates_eq (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ)) (ω : ℝ)
    (ρ : SourceWordExecution (I.Ns ω))
    (hρ : ρ ∈ (sourceExecution I.P (I.Ns ω) oracle rationalCoordinateCap).outcomes)
    (points : FinalPointFamily I.P ρ.batches) :
    let st := I.onlineSourceState oracle ω (I.P.wordStream ρ.words) I.P.arrivals
    archivedLiveCandidates st I.P.ends I.loopless (I.pointsOnArchive st ρ.batches points) =
      liveGuessCandidates I.P ρ.batches I.noRepeat I.loopless points := by
  intro st
  have hkeys : st.instances.map Prod.fst = (finalGuessIndices I.P).sort (· ≤ ·) :=
    I.onlineGuessOrder_eq oracle hobj ω ρ hρ
  unfold archivedLiveCandidates liveGuessCandidates
  rw [hkeys]
  apply List.filterMap_congr
  intro j hj
  have hj' : j ∈ finalGuessIndices I.P := (Finset.mem_sort (· ≤ ·)).1 hj
  have ha : finalGuessActive I.P j := (mem_activeGuessIndices I.P.width _ _ _ j
    (guessAnchor_pos _ _ _ I.positiveBest) (guessAnchor_le _ _ _) I.P.width_bound).1 hj'
  let rows := archiveEntries st j
  let m := finalGuessCount I.P ρ.batches j
  let emb := finalGuessEmbedding I.P ρ.batches I.noRepeat j
  obtain ⟨hrows, -, horder, -⟩ := I.onlineGuess_handoff oracle hobj ω ρ hρ j ha
  have hlen : rows.length = m := hrows
  have hget (i : Fin rows.length) : (rows.get i).1 = emb (i.cast hlen) := by
    have h0 : (rows.get i).1 = archivedGuessEdge st (I.P.edges I.bestIndex) j i :=
      congrArg Prod.fst (List.getD_eq_get rows (I.P.edges I.bestIndex, 0) i).symm
    exact h0.trans (congrFun horder (i.cast hlen))
  have hnd : (rows.map Prod.fst).Nodup := by
    apply List.nodup_iff_injective_get.mpr
    intro i k he
    simp only [archiveEntries_get_map, hget] at he
    exact Fin.ext (congrArg (fun k : Fin m => k.val) (emb.injective he))
  dsimp only
  by_cases hm : 0 < m
  · have hr : 0 < rows.length := hlen.symm ▸ hm
    rw [dif_pos hr, dif_pos hm, dif_pos hnd]
    unfold pointsOnArchive
    rw [dif_pos hlen, Option.some.injEq]
    exact liveGuessCandidate_cast hlen hr hm _ emb hget I.P.ends I.loopless _
  · have hr : ¬0 < rows.length := hlen.symm ▸ hm
    rw [dif_neg hr, dif_neg hm]

/-- The family law on physical archives never needs a reference trace to
allocate a compact point. It overwrites only the active guess addresses. -/
def archivedOptimizerFamilyLaw (oracle : Finset E → ℚ) (N : ℕ) (st : OnlineStreamState E V) :
    CandidateLaw (ArchivePointFamily st) :=
  CandidateLaw.assign (I.actualArchiveOptimizerChoice oracle N st)
    (st.instances.map Prod.fst) (fun _ _ => 0)

private theorem compactPoint_cast_zero {m n : ℕ} (h : m = n) :
    (h ▸ (fun _ => 0 : CurrentOptimizerPoint m) : CurrentOptimizerPoint n) = (fun _ => 0) := by
  subst n
  rfl

private theorem compactPoint_cast_expected {m n : ℕ} (h : m = n)
    (law : CandidateLaw (CurrentOptimizerPoint m)) (test : CurrentOptimizerPoint m → ℝ) :
    let transported : CandidateLaw (CurrentOptimizerPoint n) := h ▸ law
    expected transported.outcomes transported.mass (test ∘ (fun x => h.symm ▸ x)) =
      expected law.outcomes law.mass test := by
  subst n
  rfl

/-- Physically allocating from the archive, including the empty-slot
fallback, gives the same law as the reference indexing of completed points. -/
theorem archivedOptimizerFamilyLaw_value (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ)) (ω : ℝ)
    (ρ : SourceWordExecution (I.Ns ω))
    (hρ : ρ ∈ (sourceExecution I.P (I.Ns ω) oracle rationalCoordinateCap).outcomes)
    (test : ArchivePointFamily (I.onlineSourceState oracle ω (I.P.wordStream ρ.words) I.P.arrivals) → ℝ) :
    let st := I.onlineSourceState oracle ω (I.P.wordStream ρ.words) I.P.arrivals
    let a := I.archivedOptimizerFamilyLaw oracle (I.Ng ω) st
    let b := I.onlineLiveOptimizerLaw oracle ω ρ
    expected a.outcomes a.mass test = expected b.outcomes b.mass (test ∘ I.pointsOnArchive st ρ.batches) := by
  dsimp only
  let st := I.onlineSourceState oracle ω (I.P.wordStream ρ.words) I.P.arrivals
  let keys := st.instances.map Prod.fst
  let ref := I.onlineLiveOptimizerChoice oracle (I.Ng ω) ρ.batches st
  let actual := I.actualArchiveOptimizerChoice oracle (I.Ng ω) st
  let project (j : ℕ) (point : CurrentOptimizerPoint (finalGuessCount I.P ρ.batches j)) :
      CurrentOptimizerPoint (archiveEntries st j).length :=
    if h : (archiveEntries st j).length = finalGuessCount I.P ρ.batches j then h.symm ▸ point else fun _ => 0
  have hchoice (j : ℕ) (obs : CurrentOptimizerPoint (archiveEntries st j).length → ℝ) :
      expected (ref j).outcomes (ref j).mass (obs ∘ project j) =
        expected (actual j).outcomes (actual j).mass obs := by
    by_cases he : (archiveEntries st j).length = finalGuessCount I.P ρ.batches j
    · have hc : (he ▸ actual j : CandidateLaw (CurrentOptimizerPoint (finalGuessCount I.P ρ.batches j))) = ref j :=
        I.onlineLiveOptimizerChoice_archive oracle (I.Ng ω) ρ.batches st j he
      rw [← hc]
      simp only [project, dif_pos he]
      exact compactPoint_cast_expected he _ obs
    · have hnot : j ∉ keys := by
        intro hm
        have hkeys : keys = (finalGuessIndices I.P).sort (· ≤ ·) := I.onlineGuessOrder_eq oracle hobj ω ρ hρ
        rw [hkeys] at hm
        have hj' := (Finset.mem_sort (· ≤ ·)).1 hm
        have ha : finalGuessActive I.P j := (mem_activeGuessIndices I.P.width _ _ _ j
          (guessAnchor_pos _ _ _ I.positiveBest) (guessAnchor_le _ _ _) I.P.width_bound).1 hj'
        exact he (I.onlineGuess_handoff oracle hobj ω ρ hρ j ha).1
      have hnone : st.instanceAt j = none := by
        cases h : st.instanceAt j with
        | none => rfl
        | some recs =>
          exact (hnot (List.mem_map.2 ⟨(j, recs), lookupInstance_some_mem _ _ _ h, rfl⟩)).elim
      have hz : ¬0 < (archiveEntries st j).length := by
        simp [archiveEntries, hnone, OnlineInstance.empty]
      have hz' : ¬0 < ((st.instanceAt j).getD OnlineInstance.empty).edges.length := hz
      have hconst : actual j = CandidateLaw.pure (fun _ => 0) := by
        change I.actualArchiveOptimizerChoice oracle (I.Ng ω) st j = _
        simp only [actualArchiveOptimizerChoice, optimizerFromCompactData, dif_neg hz']
      rw [hconst, CandidateLaw.pure_expected]
      simp only [project, dif_neg he, Function.comp_def]
      exact CandidateLaw.expected_const _ _
  have hinit : (fun j => project j (fun _ => 0)) = (fun _ _ => 0) := by
    funext j
    unfold project
    split
    · exact compactPoint_cast_zero _
    · rfl
  have hh := CandidateLaw.assign_project_expected ref actual project hchoice keys (fun _ _ => 0) test
  rw [hinit] at hh
  exact hh.symm

/-- The law of candidate lists from the archive-native optimizer and
rounding scan agrees with the proved final-point reference law. -/
theorem archivedCandidateLists_value (oracle : Finset E → ℚ)
    (hobj : I.P.objective = fun A => (oracle A : ℝ)) (ω : ℝ)
    (ρ : SourceWordExecution (I.Ns ω))
    (hρ : ρ ∈ (sourceExecution I.P (I.Ns ω) oracle rationalCoordinateCap).outcomes)
    (test : List (CandidateLaw (Finset E)) → ℝ) :
    let st := I.onlineSourceState oracle ω (I.P.wordStream ρ.words) I.P.arrivals
    let a := I.archivedOptimizerFamilyLaw oracle (I.Ng ω) st
    let b := finalLiveOptimizerLaw I.P ρ.batches I.noRepeat (I.Ng ω)
    expected a.outcomes a.mass (test ∘ archivedLiveCandidates st I.P.ends I.loopless) =
      expected b.outcomes b.mass (test ∘ liveGuessCandidates I.P ρ.batches I.noRepeat I.loopless) := by
  dsimp only
  rw [I.archivedOptimizerFamilyLaw_value oracle hobj ω ρ hρ, I.onlineLiveOptimizerLaw_eq oracle hobj ω ρ hρ]
  apply congrArg (expected _ _)
  funext points
  simp only [Function.comp_apply, I.onlineArchiveCandidates_eq oracle hobj ω ρ hρ points]

end AppendixProgramInput

end

end SubmodularMatching.UpperBoundAssembly
