import SubmodularMatching.FiniteShearerBits

/-!
# Finite coins with capped primitive draws

A capped integer draw preserves its intended conditional probabilities
given that it succeeds. An aborted primitive can be interpreted as failure
of the current edge. This module verifies the total error of this
implementation, including postponing the failure decision until an edge
is accepted or rejected.
-/

namespace SubmodularMatching.ShearerSampler

open scoped BigOperators

variable {F I : Type*}

/-- Probability that the stopped execution succeeds, with an explicit
survival probability for each of its two primitive draws. -/
noncomputable def coinWithAbort (r : ℝ) (choices : F → Finset I) (p : F → I → ℝ)
    (child : F → I → F) (topAlive neighborAlive : F → ℝ) : ℕ → List F → ℝ
  | _, [] => 1
  | 0, _ :: _ => 0
  | n+1, f :: rest => topAlive f *
      (r * coinWithAbort r choices p child topAlive neighborAlive n rest +
       (1-r) * neighborAlive f * ∑ i ∈ choices f, p f i *
         coinWithAbort r choices p child topAlive neighborAlive n (child f i :: f :: rest))

theorem coinWithAbort_bounds (r : ℝ) (hr : 0 ≤ r) (hr1 : r ≤ 1)
    (choices : F → Finset I) (p : F → I → ℝ) (child : F → I → F)
    (hp : ∀ f i, i ∈ choices f → 0 ≤ p f i) (htotal : ∀ f, ∑ i ∈ choices f, p f i ≤ 1)
    (topAlive neighborAlive : F → ℝ)
    (ε : ℝ) (hε : 0 ≤ ε) (hε1 : ε ≤ 1)
    (htop : ∀ f, 1-ε ≤ topAlive f ∧ topAlive f ≤ 1)
    (hneighbor : ∀ f, 1-ε ≤ neighborAlive f ∧ neighborAlive f ≤ 1)
    (n : ℕ) (stack : List F) :
    0 ≤ coinWithAbort r choices p child topAlive neighborAlive n stack ∧
      coinWithAbort r choices p child topAlive neighborAlive n stack ≤
        finiteCoin r choices p child n stack ∧
      finiteCoin r choices p child n stack -
        coinWithAbort r choices p child topAlive neighborAlive n stack ≤ 2*n*ε := by
  let exactCoin := finiteCoin r choices p child
  let bitCoin := coinWithAbort r choices p child topAlive neighborAlive
  have hExact (n : ℕ) (stack : List F) :
      0 ≤ exactCoin n stack ∧ exactCoin n stack ≤ 1 := by
    have h := finiteCoin_and_timeout_bounds r hr hr1 choices p child hp htotal n stack
    exact ⟨h.1, by
      change finiteCoin r choices p child n stack ≤ 1
      linarith only [h.2.1,h.2.2]⟩
  change 0 ≤ bitCoin n stack ∧ bitCoin n stack ≤ exactCoin n stack ∧
    exactCoin n stack - bitCoin n stack ≤ 2*n*ε
  induction n generalizing stack with
  | zero => cases stack <;> simp [exactCoin, bitCoin, finiteCoin, coinWithAbort]
  | succ n ih =>
    cases stack with
    | nil =>
      simp only [exactCoin, bitCoin, finiteCoin, coinWithAbort, zero_le_one, le_refl, sub_self, true_and]
      positivity
    | cons f stack =>
      have hTop := htop f
      have hNbr := hneighbor f
      have ht0 : 0 ≤ topAlive f := (sub_nonneg.mpr hε1).trans hTop.1
      have hn0 : 0 ≤ neighborAlive f := (sub_nonneg.mpr hε1).trans hNbr.1
      have hFall := sub_nonneg.mpr hr1
      let children := fun i => child f i :: f :: stack
      let A := ∑ i ∈ choices f, p f i * exactCoin n (children i)
      let B := ∑ i ∈ choices f, p f i * bitCoin n (children i)
      have hA0 : 0 ≤ A := Finset.sum_nonneg (fun i hi => mul_nonneg (hp f i hi) (hExact _ _).1)
      have hB0 : 0 ≤ B := Finset.sum_nonneg (fun i hi => mul_nonneg (hp f i hi) (ih _).1)
      have hBA : B ≤ A := Finset.sum_le_sum (fun i hi => mul_le_mul_of_nonneg_left (ih _).2.1 (hp f i hi))
      have hA1 : A ≤ 1 := by
        apply le_trans _ (htotal f)
        exact Finset.sum_le_sum (fun i hi => by
          simpa only [mul_one] using mul_le_mul_of_nonneg_left (hExact n (children i)).2 (hp f i hi))
      have hNε : 0 ≤ 2*(n:ℝ)*ε := by positivity
      have hGap : A - B ≤ 2*n*ε := by
        dsimp [A,B]
        rw [← Finset.sum_sub_distrib]
        calc
          _ ≤ ∑ i ∈ choices f, p f i * (2*n*ε) := Finset.sum_le_sum (fun i hi => by
            rw [← mul_sub]
            exact mul_le_mul_of_nonneg_left (ih _).2.2 (hp f i hi))
          _ ≤ _ := by
            rw [← Finset.sum_mul]
            simpa only [one_mul] using mul_le_mul_of_nonneg_right (htotal f) hNε
      let X := r * exactCoin n stack + (1-r)*A
      let Y := r * bitCoin n stack + (1-r)*neighborAlive f*B
      have hX1 : X ≤ 1 := by
        have h1 := mul_le_mul_of_nonneg_left (hExact n stack).2 hr
        have h2 := mul_le_mul_of_nonneg_left hA1 hFall
        dsimp [X]
        linarith
      have hY0 : 0 ≤ Y := add_nonneg (mul_nonneg hr (ih stack).1)
        (mul_nonneg (mul_nonneg hFall hn0) hB0)
      have hYX : Y ≤ X := by
        apply add_le_add (mul_le_mul_of_nonneg_left (ih stack).2.1 hr)
        rw [mul_assoc]
        apply mul_le_mul_of_nonneg_left _ hFall
        exact (mul_le_of_le_one_left hB0 hNbr.2).trans hBA
      have hNB : (1-neighborAlive f)*B ≤ ε :=
        (mul_le_mul_of_nonneg_right (by linarith only [hNbr.1] : 1-neighborAlive f ≤ ε) hB0).trans
          (by simpa only [mul_one] using mul_le_mul_of_nonneg_left (hBA.trans hA1) hε)
      have hXY : X - Y ≤ 2*n*ε + ε := by
        have h1 := mul_le_mul_of_nonneg_left (ih stack).2.2 hr
        have h2 := mul_le_mul_of_nonneg_left (add_le_add hGap hNB) hFall
        have h3 := mul_le_mul_of_nonneg_right hr1 hε
        have h4 := mul_nonneg hr hε
        dsimp only [X,Y]
        nlinarith only [h1,h2,h3,h4]
      have hTopLoss : (1-topAlive f)*Y ≤ ε :=
        (mul_le_mul_of_nonneg_right (by linarith only [hTop.1] : 1-topAlive f ≤ ε) hY0).trans
          (by simpa only [mul_one] using mul_le_mul_of_nonneg_left (hYX.trans hX1) hε)
      change 0 ≤ topAlive f*Y ∧ topAlive f*Y ≤ X ∧
        X - topAlive f*Y ≤ 2*(↑(n+1):ℝ)*ε
      refine ⟨mul_nonneg ht0 hY0, (mul_le_of_le_one_left hY0 hTop.2).trans hYX, ?_⟩
      push_cast
      nlinarith only [hXY,hTopLoss]

/-- Nonabortion probability for a rational primitive with denominator `q`. -/
noncomputable def primitiveAlive (q K B : ℕ) : ℝ :=
  1 - (1-(q:ℝ)/K)^B

theorem primitiveAlive_bounds (q K B : ℕ) (hq : q ≤ K) (hK : K ≤ 2*q)
    (hK₀ : 0 < K) : 1-((2:ℝ)^B)⁻¹ ≤ primitiveAlive q K B ∧ primitiveAlive q K B ≤ 1 := by
  have h := boundedUniform_abort_bound q K B hq hK hK₀
  unfold primitiveAlive
  constructor <;> linarith only [h.1,h.2]

end SubmodularMatching.ShearerSampler
