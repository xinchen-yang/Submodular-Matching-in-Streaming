import SubmodularMatching.UpperBoundVertexRoundingGrid
import SubmodularMatching.UpperBoundVertexResources

/-! # Bounded numerators for compact rounding coordinates -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint TwoStage NumericalCertificate LinearPacking
open scoped BigOperators

noncomputable section

variable {m : ℕ} {V : Type*} [DecidableEq V]

theorem appendixCompensatedEdge_bounds (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (x y : Fin m → ℝ)
    (hxy : Feasible coordinateCap NumericalCertificate.degree ends ends x y) (e : Fin m) :
    0 ≤ compensatedEdge ends x y e ∧ compensatedEdge ends x y e ≤ coordinateCap := by
  let A := pairEnds ends
  let S : Finset (Fin m) := Finset.univ
  have hr0 : 0 < sampler := (by norm_num : (0 : ℝ) < 1 / 2).trans sampler_bounds.1
  have hy : ∀ e ∈ S, 0 ≤ y e := fun e _ => hxy.y_nonneg e
  have he : ∀ e ∈ S, (A e).card = 2 := fun e _ => pairEnds_card_two ends hloop e
  have hdegree (v : V) : Shearer.vertexDegree A S y v ≤ sampler * (1 - sampler) := by
    rw [← show NumericalCertificate.degree = sampler * (1 - sampler) from rfl]
    exact (vertexDegree_pairEnds ends y v).le.trans (hxy.y_degree v)
  have hq := Shearer.unmatchedPair_union_bound A S y sampler hr0 sampler_bounds.2.le hy he hdegree
    (ends e).1 (ends e).2
  change _ ≤ pairProbability ends y (ends e).1 (ends e).2 at hq
  rw [vertexDegree_pairEnds, vertexDegree_pairEnds] at hq
  have hp := (appendixPairProbability_bounds ends hloop x y hxy (ends e).1 (ends e).2).1
  unfold compensatedEdge
  refine ⟨div_nonneg (hxy.x_nonneg e) hp.le, (div_le_iff₀ hp).mpr ?_⟩
  have hscaled := mul_le_mul_of_nonneg_left hq coordinate_condition.1.le
  nlinarith only [hscaled, hxy.edge_bound e]

variable [Fintype V]

/-- Unscaled numerators of the actual y, rounded x, compensated weight,
first-stage pair probability, and altered coordinate are bounded by their
respective common denominators. -/
theorem appendixRounding_coordinateNumerators (hm : 0 < m) (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) {N : ℕ} (Q : ℕ)
    (draw : AppendixDraw m N) (T : Finset (Fin m)) (e : Fin m) :
    let t := appendixRoundedPoint ends tau w f Q draw
    let d := appendixShearerDenominator (Fintype.card V) m
    let B := appendixCompensatedDenominator m
    let A := appendixAlteredDenominator m
    (∃ k : ℕ, k ≤ d ∧ (d : ℝ) * t.2 e = k) ∧
    (∃ k : ℕ, k ≤ d ^ 2 * B ∧ ((d ^ 2 * B : ℕ) : ℝ) * t.1 e = k) ∧
    (∃ k : ℕ, k ≤ B ∧ (B : ℝ) * compensatedEdge ends t.1 t.2 e = k) ∧
    (∃ k : ℕ, k ≤ d ^ 2 ∧ ((d ^ 2 : ℕ) : ℝ) *
      pairProbability ends t.2 (ends e).1 (ends e).2 = k) ∧
    (∃ k : ℕ, k ≤ A ∧ (A : ℝ) *
      shearerAltered ends t.1 t.2 (NumericalCertificate.roundingError / 4) T e = k) := by
  intro t d B A
  have hg (e : Fin m) := appendixRoundedPoint_xy_grids hm ends hloop tau w f Q draw e
  have ht : Feasible coordinateCap NumericalCertificate.degree ends ends t.1 t.2 :=
    appendixRoundedPoint_feasible hm ends hloop tau w f Q draw
  have hcap : coordinateCap ≤ 1 := coordinate_condition.2.trans (min_le_left _ _)
  have hy1 : t.2 e ≤ 1 := (coordinate_le_degree ends t.2 ht.y_nonneg e).trans
    ((ht.y_degree (ends e).1).trans (by linarith [degree_bounds.2]))
  have hx1 : t.1 e ≤ 1 := by
    have h := add_nonneg (degree_nonneg ends t.2 ht.y_nonneg (ends e).1)
      (degree_nonneg ends t.2 ht.y_nonneg (ends e).2)
    exact ((le_add_of_nonneg_right (mul_nonneg coordinate_condition.1.le h)).trans (ht.edge_bound e)).trans hcap
  have ha := appendixCompensatedEdge_bounds ends hloop t.1 t.2 ht e
  have hq := appendixPairProbability_bounds ends hloop t.1 t.2 ht (ends e).1 (ends e).2
  have hqg := pairProbability_onGrid ends hloop d t.2 (fun i => (hg i).1) _ _ (hloop e)
  have hzg := appendixShearerAltered_onGrid ends t.1 t.2 (fun i => (hg i).2.2) T e
  have hz := shearer_alteration_correct ends hloop hsimple coordinateCap NumericalCertificate.degree
    sampler (NumericalCertificate.roundingError / 4) coordinate_condition.1.le
    ((by norm_num : (0 : ℝ) < 1 / 2).trans sampler_bounds.1) sampler_bounds.2.le rfl
    NumericalCertificate.mean_excess_below_tolerance t.1 t.2 ht
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · simpa only [Nat.mul_one, Nat.cast_one] using
      (OnGrid.bounded_numerator (R := 1) (hg e).1 (ht.y_nonneg e) (by simpa using hy1))
  · simpa only [Nat.mul_one, Nat.cast_one] using
      (OnGrid.bounded_numerator (R := 1) (hg e).2.1 (ht.x_nonneg e) (by simpa using hx1))
  · simpa only [Nat.mul_one, Nat.cast_one] using
      (OnGrid.bounded_numerator (R := 1) (hg e).2.2 ha.1 (by simpa using ha.2.trans hcap))
  · simpa only [Nat.mul_one, Nat.cast_one] using
      (OnGrid.bounded_numerator (R := 1) hqg hq.1.le (by simpa using hq.2))
  · simpa only [Nat.mul_one, Nat.cast_one] using
      (OnGrid.bounded_numerator (R := 1) hzg (hz.1 T e).1 (by simpa using (hz.1 T e).2.trans hcap))

/-- Computing every pair probability by nested edge and vertex scans
requires no dense matrix of neighbor activities. -/
theorem compact_pairProbability_scan_count (ends : Fin m → V × V) :
    Fintype.card (Fin m × IncidentVertex ends × Fin m) ≤ 2 * m ^ 3 := by
  simp only [Fintype.card_prod, Fintype.card_fin]
  calc
    _ ≤ m * ((2 * m) * m) := Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ (incidentVertex_card_le ends))
    _ = _ := by ring

end

end SubmodularMatching.UpperBoundAssembly
