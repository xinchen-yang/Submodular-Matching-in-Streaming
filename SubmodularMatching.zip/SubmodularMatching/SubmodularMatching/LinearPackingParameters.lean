import SubmodularMatching.LinearPacking
import Mathlib.Data.Real.Archimedean

/-!
# Concrete parameter choices and a verified packing solver

The clipping radius, step size, iteration count and output rescaling are exactly
the quantities in (PK2). The correctness theorem applies to every feasible
competitor, so it also applies to an attained optimum without introducing a
linear-programming duality axiom. Arithmetic is represented over the reals here;
the rational-grid bit-size and operational space bounds are separate claims.
-/

namespace SubmodularMatching.LinearPacking

noncomputable section

def radius (N : ℕ) (epsilon : ℝ) : ℝ := Nat.ceil (4 * (N : ℝ) ^ 2 / epsilon)

def stepSize (M N : ℕ) (epsilon : ℝ) : ℝ := epsilon / (2 * M * (N : ℝ) ^ 2)

def iterationCount (M N : ℕ) (epsilon : ℝ) : ℕ :=
  Nat.ceil (2 * radius N epsilon ^ 2 * M / (stepSize M N epsilon * epsilon))

def rescaling (N : ℕ) (epsilon : ℝ) : ℝ := epsilon / (2 * N)

theorem concrete_parameters (M N : ℕ) (epsilon : ℝ)
    (hM : 1 ≤ M) (hN : 1 ≤ N) (heps : 0 < epsilon) (heps1 : epsilon ≤ 1) :
    0 < radius N epsilon ∧ 0 < stepSize M N epsilon ∧
    0 < iterationCount M N epsilon ∧ 0 ≤ rescaling N epsilon ∧
    (M : ℝ) * radius N epsilon ^ 2 +
      iterationCount M N epsilon *
        (stepSize M N epsilon ^ 2 * ((M : ℝ) * (N : ℝ) ^ 2)) ≤
      2 * stepSize M N epsilon * iterationCount M N epsilon * (epsilon / 2) ∧
    (N : ℝ) + epsilon / 2 ≤ radius N epsilon * rescaling N epsilon := by
  have hMr : (1 : ℝ) ≤ M := by exact_mod_cast hM
  have hNr : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hMp : (0 : ℝ) < M := lt_of_lt_of_le zero_lt_one hMr
  have hNp : (0 : ℝ) < N := lt_of_lt_of_le zero_lt_one hNr
  have hbase : 0 < 4 * (N : ℝ) ^ 2 / epsilon := by positivity
  have hrad : 4 * (N : ℝ) ^ 2 / epsilon ≤ radius N epsilon := Nat.le_ceil _
  have hR : 0 < radius N epsilon := hbase.trans_le hrad
  have heta : 0 < stepSize M N epsilon := by unfold stepSize; positivity
  have hJ : 0 < iterationCount M N epsilon := by
    apply Nat.ceil_pos.mpr
    positivity
  have hscale : 0 ≤ rescaling N epsilon := by unfold rescaling; positivity
  refine ⟨hR, heta, hJ, hscale, ?_, ?_⟩
  · have hceil := Nat.le_ceil
      (2 * radius N epsilon ^ 2 * M / (stepSize M N epsilon * epsilon))
    change _ ≤ (iterationCount M N epsilon : ℝ) at hceil
    have hJbudget := (div_le_iff₀ (mul_pos heta heps)).mp hceil
    have hstep : stepSize M N epsilon * ((M : ℝ) * (N : ℝ) ^ 2) = epsilon / 2 := by
      unfold stepSize
      field_simp
    have hterm : stepSize M N epsilon ^ 2 * ((M : ℝ) * (N : ℝ) ^ 2) =
        stepSize M N epsilon * (epsilon / 2) := by
      rw [← hstep]
      ring
    rw [hterm]
    nlinarith [hJbudget]
  · have hm := mul_le_mul_of_nonneg_right hrad hscale
    have heq : (4 * (N : ℝ) ^ 2 / epsilon) * rescaling N epsilon = 2 * N := by
      unfold rescaling
      field_simp
      ring
    rw [heq] at hm
    linarith

variable {Row Col : Type*} [Fintype Row] [Fintype Col]

/-- The explicit finite packing algorithm with the paper's parameter choices. -/
def solve (A : Row → Col → ℝ) (c : Col → ℝ) (epsilon : ℝ) : Col → ℝ :=
  output A c (radius (Fintype.card Col) epsilon)
    (stepSize (Fintype.card Row) (Fintype.card Col) epsilon)
    (rescaling (Fintype.card Col) epsilon)
    (iterationCount (Fintype.card Row) (Fintype.card Col) epsilon)

/-- Mathematical correctness of the concrete solver in the linear-packing
lemma: its actual output is feasible and loses at most `epsilon` against any
feasible point. There is no assumed optimization oracle in this theorem. -/
theorem solve_correct (A : Row → Col → ℝ) (c : Col → ℝ) (epsilon : ℝ)
    (hA : ∀ h i, 0 ≤ A h i ∧ A h i ≤ 1)
    (hc : ∀ i, 0 ≤ c i ∧ c i ≤ 1)
    (hM : 1 ≤ Fintype.card Row) (hN : 1 ≤ Fintype.card Col)
    (heps : 0 < epsilon) (heps1 : epsilon ≤ 1) :
    (∀ i, 0 ≤ solve A c epsilon i ∧ solve A c epsilon i ≤ 1) ∧
    (∀ h, load A (solve A c epsilon) h ≤ 1) ∧
    (∀ t : Col → ℝ, (∀ i, 0 ≤ t i ∧ t i ≤ 1) → (∀ h, load A t h ≤ 1) →
      objective c t - epsilon ≤ objective c (solve A c epsilon)) := by
  obtain ⟨hR, heta, hJ, hscale, hbudget, hradius⟩ :=
    concrete_parameters (Fintype.card Row) (Fintype.card Col) epsilon hM hN heps heps1
  have hcorr := output_correct A c _ _ (epsilon / 2) _ _ hA hN hc hR heta hJ hscale
    (by positivity) hbudget hradius
  refine ⟨hcorr.1, hcorr.2.1, ?_⟩
  intro t ht htA
  have h := hcorr.2.2 t ht htA
  have hNpos : (0 : ℝ) < Fintype.card Col := by exact_mod_cast lt_of_lt_of_le Nat.zero_lt_one hN
  have hs : rescaling (Fintype.card Col) epsilon * Fintype.card Col = epsilon / 2 := by
    unfold rescaling
    field_simp
  rw [hs] at h
  change _ ≤ objective c (solve A c epsilon) at h
  linarith

end

end SubmodularMatching.LinearPacking
