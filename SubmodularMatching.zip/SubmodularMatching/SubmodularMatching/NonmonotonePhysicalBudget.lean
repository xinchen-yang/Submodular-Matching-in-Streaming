import SubmodularMatching.NonmonotoneMarkedPriority
import SubmodularMatching.NonmonotoneFiniteMargin

/-! # Polynomial precision choices for the complete postprocessing loss -/

namespace SubmodularMatching.AppendixM
open Shearer
noncomputable section

/-- A scale dominating support sizes and value ranges suffices. The time
denominator is fifth-order in this scale; the sampling errors, coordinate
errors and value tolerances have degree at most three. -/
theorem physical_round_budget (K opt H B W ε α η e₁ e₂ ξ : ℝ) (N m Q D t : ℕ)
    (hk : 2000000000 ≤ K) (ho : 0≤opt) (hH : 0≤H) (hB : 0≤B) (hW : 0≤W)
    (hN : (N:ℝ)≤K) (hm : (m:ℝ)≤K) (hRange : H≤K*opt) (hValue : B≤K*opt) (hWeight : W≤K*opt)
    (hQ : K^5 ≤ (Q:ℝ)) (hD : K^2 ≤ (D:ℝ))
    (hε : ε≤opt/K^2) (hα : α≤1/K^3) (hη : η≤1/K^2)
    (he₁ : e₁≤1/K^2) (he₂ : e₂≤1/K^2) (ht : ((2:ℝ)^t)⁻¹≤1/K^2)
    (hξ0 : 0≤ξ) (hξ1 : ξ≤1) :
    (1-ξ)*(priorityLossBudget N m Q H ε α + η*W) + B/D + (e₁+e₂+2*((2:ℝ)^t)⁻¹)*B ≤
      implementationUnit*opt := by
  have hk1 : 1≤K := by linarith only [hk]
  have hk0 : 0<K := by linarith only [hk]
  have hg : 0≤gamma ∧ gamma≤1 := by
    norm_num [gamma,retention,priorityArea,priorityLoss,rootHi,rootLo,degree,layerOne,layerTwo,discriminant]
  have coeff : gamma+2*N ≤ 3*K := by linarith only [hg.2,hN,hk1]
  have hg0 := hg.1
  have coeff0 : 0≤gamma+2*(N:ℝ) := by positivity
  have hcoll : (gamma+2*N)*H*(3*(N:ℝ)^2/Q) ≤ 9*opt/K := calc
    _ ≤ 3*K*(K*opt)*(3*K^2/K^5) := by
      apply mul_le_mul (mul_le_mul coeff hRange hH (by positivity)) _ (by positivity) (by positivity)
      exact div_le_div₀ (by positivity) (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (Nat.cast_nonneg N) hN 2) (by norm_num)) (by positivity) hQ
    _ = _ := by field_simp <;> ring
  have hnoise : 2*N*ε ≤ 2*opt/K := calc
    _ ≤ 2*N*(opt/K^2) := mul_le_mul_of_nonneg_left hε (by positivity)
    _ ≤ 2*K*(opt/K^2) := mul_le_mul_of_nonneg_right (by linarith only [hN]) (by positivity)
    _ = _ := by field_simp <;> ring
  have hdecoder : gamma*(2*m*α*H) ≤ 2*opt/K := calc
    _ ≤ gamma*(2*m*(1/K^3)*H) := by gcongr
    _ ≤ 1*(2*K*(1/K^3)*(K*opt)) := by gcongr; exact hg.2
    _ = _ := by field_simp <;> ring
  have hcoord : η*W ≤ opt/K := calc
    _ ≤ (1/K^2)*W := mul_le_mul_of_nonneg_right hη hW
    _ ≤ (1/K^2)*(K*opt) := mul_le_mul_of_nonneg_left hWeight (by positivity)
    _ = _ := by field_simp <;> ring
  have hsignal : priorityLossBudget N m Q H ε α+η*W ≤ 14*opt/K := by
    unfold priorityLossBudget
    exact (add_le_add (add_le_add (add_le_add hcoll hnoise) hdecoder) hcoord).trans_eq (by ring)
  have hpre := (mul_le_mul_of_nonneg_left hsignal (sub_nonneg.mpr hξ1)).trans
    (mul_le_of_le_one_left (show 0≤14*opt/K by positivity) (by linarith only [hξ0]))
  have hmix : B/D ≤ opt/K := calc
    _ ≤ K*opt/K^2 := div_le_div₀ (by positivity) hValue (by positivity) hD
    _ = _ := by field_simp <;> ring
  have hsamp : (e₁+e₂+2*((2:ℝ)^t)⁻¹)*B ≤ 4*opt/K := calc
    _ ≤ (4/K^2)*B := mul_le_mul_of_nonneg_right (by exact (add_le_add (add_le_add he₁ he₂) (mul_le_mul_of_nonneg_left ht (by norm_num : (0:ℝ)≤2))).trans_eq (by ring)) hB
    _ ≤ (4/K^2)*(K*opt) := mul_le_mul_of_nonneg_left hValue (by positivity)
    _ = _ := by field_simp <;> ring
  have hfinal : 19/K ≤ implementationUnit := by rw [div_le_iff₀ hk0]; norm_num [implementationUnit]; linarith only [hk]
  have hfinal' := mul_le_mul_of_nonneg_right hfinal ho
  exact (add_le_add (add_le_add hpre hmix) hsamp).trans ((by ring : 14*opt/K+opt/K+4*opt/K = (19/K)*opt).le.trans hfinal')

end
end SubmodularMatching.AppendixM
