import SubmodularMatching.UpperBoundK1Parameters
import SubmodularMatching.UpperBoundK1Optimizer
import SubmodularMatching.UpperBoundK1RoundingInput

/-! # Executable optimizer and sampler parameters for Appendix K -/

namespace SubmodularMatching.UpperBoundAssembly

noncomputable section

namespace K1Parameters

variable (a : K1Parameters)

def optimizerSettings : K1OptimizerSettings :=
  ⟨a.p, a.error, a.degree, ⟨a.probability_pos.le, a.probability_le_one⟩,
    a.error_pos, a.error_lt_one, a.degree_pos, a.degree_lt_quarter.le⟩

private theorem rational_natRatio (q : ℚ) (hq : 0 < q) :
    (q.num.natAbs : ℝ) / q.den = (q : ℝ) := by
  have h := Rat.num_pos.mpr hq
  rw [Rat.cast_def, ← Int.cast_natCast (R := ℝ), Int.natAbs_of_nonneg h.le]

private theorem rational_natRatio_bounds (q : ℚ) (hq : 0 < q) (hq1 : (q : ℝ) < 1) :
    0 < q.num.natAbs ∧ q.num.natAbs < q.den := by
  have hd : (0 : ℝ) < q.den := by exact_mod_cast q.pos
  have he := rational_natRatio q hq
  have hn : 0 < q.num.natAbs := by
    exact Int.natAbs_pos.mpr (Rat.num_pos.mpr hq).ne'
  have hnd : (q.num.natAbs : ℝ) < q.den :=
    (div_lt_one hd).mp (he ▸ hq1)
  exact ⟨hn, by exact_mod_cast hnd⟩

private theorem rationalStop_pos : 0 < a.r := by linarith only [a.r_lower]

private theorem rationalStop_half :
    a.r.den < 2 * a.r.num.natAbs := by
  have hd : (0 : ℝ) < a.r.den := by exact_mod_cast a.r.pos
  have h := (lt_div_iff₀ hd).mp ((rational_natRatio a.r a.rationalStop_pos) ▸ a.r_bounds.1)
  have h' : (a.r.den : ℝ) < 2 * (a.r.num.natAbs : ℝ) := by linarith only [h]
  exact_mod_cast h'

def roundingSettings : K1RoundingSettings :=
  ⟨a.k, a.r.num.natAbs, a.r.den, a.roundingError.num.natAbs, a.roundingError.den,
    by have := a.k_large; omega,
    (rational_natRatio_bounds a.r a.rationalStop_pos a.r_bounds.2).1,
    (rational_natRatio_bounds a.r a.rationalStop_pos a.r_bounds.2).2,
    a.rationalStop_half,
    (rational_natRatio_bounds a.roundingError a.roundingError_pos a.roundingError_bounds.2).1,
    (rational_natRatio_bounds a.roundingError a.roundingError_pos a.roundingError_bounds.2).2⟩

theorem roundingSettings_stop : a.roundingSettings.stop = (a.r : ℝ) :=
  rational_natRatio a.r a.rationalStop_pos

theorem roundingSettings_degree : a.optimizerSettings.degree = a.roundingSettings.degree := by
  change a.degree = a.roundingSettings.stop * (1 - a.roundingSettings.stop)
  rw [a.roundingSettings_stop]

theorem roundingSettings_epsilon : a.optimizerSettings.error = a.roundingSettings.epsilon := rfl

theorem roundingSettings_error : a.roundingSettings.error = (a.roundingError : ℝ) :=
  rational_natRatio a.roundingError a.roundingError_pos

theorem roundingSettings_cap : a.optimizerSettings.p ≤ a.roundingSettings.error ^ 5 / 163840 := by
  rw [a.roundingSettings_error]
  exact a.coordinate_cap

end K1Parameters

end

end SubmodularMatching.UpperBoundAssembly
