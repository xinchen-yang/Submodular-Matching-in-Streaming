import SubmodularMatching.UpperBoundK1PhysicalPoint
import SubmodularMatching.UpperBoundK1Rounding

/-! # Finite rounding from the actual final optimizer point -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint Streaming TwoStage GibbsSampler LinearPacking

noncomputable section

variable {m N : ℕ} {V : Type*} [DecidableEq V]

/-- A total candidate law on physical vectors. All points handed off by
the finite optimizer satisfy the decoding and feasibility witnesses. -/
def k1CandidateFromPoint (cfg : K1OptimizerSettings) (R : K1RoundingSettings) (hm : 0 < m)
    (ends : Fin m → V × V) (hloop : ∀ i, (ends i).1 ≠ (ends i).2)
    (hsimple : Function.Injective (pairEnds ends)) (hcap : cfg.p ≤ R.error ^ 5 / 163840)
    (t : (Fin m → ℝ) × (Fin m → ℝ)) (P Y : ℕ) (hP : 0 < P) (hY : 0 < Y) :
    CandidateLaw (Finset (Fin m)) := by
  classical
  exact if hxy : Feasible cfg.p R.degree ends ends t.1 t.2 then
    if hg : (∀ i, OnGrid P (t.1 i)) ∧ ∀ i, OnGrid Y (t.2 i) then
      k1RoundingCandidate R hm ends hloop hsimple cfg.p cfg.probabilityBounds.1 hcap
        t.1 t.2 hxy P Y hP hY hg.1 hg.2
    else CandidateLaw.pure ∅
  else CandidateLaw.pure ∅

theorem k1CandidateFromPoint_feasible (cfg : K1OptimizerSettings) (R : K1RoundingSettings) (hm : 0 < m)
    (ends : Fin m → V × V) (hloop : ∀ i, (ends i).1 ≠ (ends i).2)
    (hsimple : Function.Injective (pairEnds ends)) (hcap : cfg.p ≤ R.error ^ 5 / 163840)
    (t : (Fin m → ℝ) × (Fin m → ℝ)) (P Y : ℕ) (hP : 0 < P) (hY : 0 < Y)
    (M : Finset (Fin m))
    (hM : M ∈ (k1CandidateFromPoint cfg R hm ends hloop hsimple hcap t P Y hP hY).outcomes) :
    IsMatchingOn (pairEnds ends) M := by
  classical
  unfold k1CandidateFromPoint at hM
  split at hM
  · rename_i hxy
    split at hM
    · rename_i hg
      exact k1RoundingCandidate_feasible R hm ends hloop hsimple cfg.p cfg.probabilityBounds.1
        hcap t.1 t.2 hxy P Y hP hY hg.1 hg.2 M hM
    · simp only [CandidateLaw.pure, Finset.mem_singleton] at hM
      subst M
      intro _ he
      simp at he
  · simp only [CandidateLaw.pure, Finset.mem_singleton] at hM
    subst M
    intro _ he
    simp at he

variable [Fintype V]

/-- Run the finite word samplers on the same point checked by FJ6. -/
def k1SampledCandidate (cfg : K1OptimizerSettings) (R : K1RoundingSettings) (hm : 0 < m)
    (tau : ℝ) (ends : Fin m → V × V) (hloop : ∀ i, (ends i).1 ≠ (ends i).2)
    (hsimple : Function.Injective (pairEnds ends)) (hcap : cfg.p ≤ R.error ^ 5 / 163840)
    (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ)
    (draw : ℕ → (Fin m ⊕ Fin m → ℝ) → DerivativeSamples m N)
    (P Y : ℕ) (hP : 0 < P) (hY : 0 < Y) : CandidateLaw (Finset (Fin m)) :=
  k1CandidateFromPoint cfg R hm ends hloop hsimple hcap
    (k1PhysicalPoint cfg tau ends w f Q draw) P Y hP hY

theorem k1SampledCandidate_feasible (cfg : K1OptimizerSettings) (R : K1RoundingSettings) (hm : 0 < m)
    (tau : ℝ) (ends : Fin m → V × V) (hloop : ∀ i, (ends i).1 ≠ (ends i).2)
    (hsimple : Function.Injective (pairEnds ends)) (hcap : cfg.p ≤ R.error ^ 5 / 163840)
    (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ)
    (draw : ℕ → (Fin m ⊕ Fin m → ℝ) → DerivativeSamples m N)
    (P Y : ℕ) (hP : 0 < P) (hY : 0 < Y) (M : Finset (Fin m))
    (hM : M ∈ (k1SampledCandidate cfg R hm tau ends hloop hsimple hcap w f Q draw P Y hP hY).outcomes) :
    IsMatchingOn (pairEnds ends) M :=
  k1CandidateFromPoint_feasible cfg R hm ends hloop hsimple hcap
    (k1PhysicalPoint cfg tau ends w f Q draw) P Y hP hY M hM

/-- Compose the sampled optimizer bound and both finite sampler errors before
the final comparison of candidates. -/
theorem k1SampledCandidate_value (cfg : K1OptimizerSettings) (R : K1RoundingSettings)
    (hD : cfg.degree = R.degree) (hError : cfg.error = R.epsilon) (hm : 0 < m)
    (tau b lower B : ℝ) (hp : 0 < cfg.p) (htau : 0 < tau) (hB : 0 ≤ B) (hBtau : B ≤ tau)
    (ends : Fin m → V × V) (hloop : ∀ i, (ends i).1 ≠ (ends i).2)
    (hsimple : Function.Injective (pairEnds ends)) (hcap : cfg.p ≤ R.error ^ 5 / 163840)
    (w : Fin m → ℝ) (hw : ∀ i, 0 ≤ w i ∧ w i ≤ tau)
    (f : Finset (Fin m) → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f) (hzero : f ∅ = 0)
    (hsingle : ∀ i, f {i} ≤ B)
    (harrival : ∀ i < m, w (enumerateEdge hm i) ≤ arrivalWeight (enumerateEdge hm) cfg.p f i)
    (O : Finset (Fin m)) (hO : IsMatchingOn (pairEnds ends) O)
    (hsource : lower ≤ sSup (comparisonValues cfg.p cfg.degree ends w O))
    (hb : b ≤ 1 - Real.exp (-cfg.degree))
    (Q : ℕ) (hQ : 0 < Q) (draw : ℕ → (Fin m ⊕ Fin m → ℝ) → DerivativeSamples m N)
    (hgrid : (FiniteGreedy.stages cfg.degree m cfg.error : ℝ) / Q ≤
      FiniteGreedy.accuracy cfg.degree m cfg.error / 2)
    (hmean : k1OptimizerAccurate cfg hm tau ends w f Q draw)
    (P Y : ℕ) (hP : 0 < P) (hY : 0 < Y)
    (hx : ∀ i, OnGrid P ((k1PhysicalPoint cfg tau ends w f Q draw).1 i))
    (hy : ∀ i, OnGrid Y ((k1PhysicalPoint cfg tau ends w f Q draw).2 i)) :
    let g := residualValue (enumerateEdge hm) cfg.p f m
    let q := k1SampledCandidate cfg R hm tau ends hloop hsimple hcap w f Q draw P Y hP hY
    (1 - R.error) * (lower + b * g O - (5 / 8) * cfg.error * tau) - cfg.error * B / 4 ≤
      expected q.outcomes q.mass f := by
  classical
  intro g q
  let t := k1PhysicalPoint cfg tau ends w f Q draw
  have hxy : Feasible cfg.p R.degree ends ends t.1 t.2 :=
    hD ▸ k1PhysicalPoint_feasible cfg hm tau ends w f Q draw
  have hscore := k1PhysicalPoint_lower cfg hm tau b lower hp htau ends w hw f hf hmono hzero
    (fun i => (hsingle i).trans hBtau) O hO hsource hb Q hQ draw hgrid hmean
  have hval := k1RoundingCandidate_lower R hm ends hloop hsimple cfg.p cfg.probabilityBounds.1
    hcap t.1 t.2 hxy P Y hP hY hx hy f hf hmono hzero B hB hsingle w tau hw harrival
    (lower + b * g O - cfg.error * tau / 2) hscore
  dsimp only [q, k1SampledCandidate, k1CandidateFromPoint]
  rw [dif_pos hxy, dif_pos (show (∀ i, OnGrid P (t.1 i)) ∧ ∀ i, OnGrid Y (t.2 i) from ⟨hx, hy⟩)]
  have hbudget : (1 - R.error) *
      ((lower + b * g O - cfg.error * tau / 2) - R.epsilon * tau / 8) - R.epsilon * B / 4 =
      (1 - R.error) * (lower + b * g O - (5 / 8) * cfg.error * tau) - cfg.error * B / 4 := by
    rw [← hError]
    ring
  simpa only [hbudget] using hval

end

end SubmodularMatching.UpperBoundAssembly
