import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step188 : ProjectedGoal ⟨54864, 55079, 70, 141, 1064, 1135⟩ :=
  projectedGoal_chunk _ (.leaf 0xd7ffd6500000000000bf10e8) (by decide +kernel)

theorem Part00019 : ProjectedGoal ⟨54864, 55079, 70, 141, 1064, 1135⟩ := step188

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
