import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull018_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 815, 816, 1, 0x19832f⟩ (by decide +kernel)

private def hull018_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 816, 817, 1, 0x198b30⟩ (by decide +kernel)

private def hull018_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 815, 817, 1, 0x198b2f⟩ (by decide +kernel)

private def hull018_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 815, 819, 1, 0x199b2f⟩ (by decide +kernel)

private def hull018_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 815, 824, 1, 0x19c32f⟩ (by decide +kernel)

private def hull018_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 817, 819, 1, 0x199b31⟩ (by decide +kernel)

private def hull018_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 817, 818, 1, 0x199331⟩ (by decide +kernel)

private def hull018_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 818, 819, 1, 0x199b32⟩ (by decide +kernel)

private def hull018_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 815, 833, 1, 0x1a0b2f⟩ (by decide +kernel)

private def hull018_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 819, 821, 1, 0x19ab33⟩ (by decide +kernel)

private def hull018_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 821, 824, 1, 0x19c335⟩ (by decide +kernel)

private def hull018_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 819, 820, 1, 0x19a333⟩ (by decide +kernel)

private def hull018_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 820, 821, 1, 0x19ab34⟩ (by decide +kernel)

private def hull018_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 819, 824, 1, 0x19c333⟩ (by decide +kernel)

private def hull018_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 821, 822, 1, 0x19b335⟩ (by decide +kernel)

private def hull018_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 822, 824, 1, 0x19c336⟩ (by decide +kernel)

private def hull018_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 822, 823, 1, 0x19bb36⟩ (by decide +kernel)

private def hull018_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 823, 824, 1, 0x19c337⟩ (by decide +kernel)

private def hull018_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 824, 828, 1, 0x19e338⟩ (by decide +kernel)

private def hull018_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 828, 833, 1, 0x1a0b3c⟩ (by decide +kernel)

private def hull018_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 824, 826, 1, 0x19d338⟩ (by decide +kernel)

private def hull018_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 826, 828, 1, 0x19e33a⟩ (by decide +kernel)

private def hull018_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 824, 825, 1, 0x19cb38⟩ (by decide +kernel)

private def hull018_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 825, 826, 1, 0x19d339⟩ (by decide +kernel)

private def hull018_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 828, 830, 1, 0x19f33c⟩ (by decide +kernel)

private def hull018_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 830, 833, 1, 0x1a0b3e⟩ (by decide +kernel)

private def hull018_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 828, 829, 1, 0x19eb3c⟩ (by decide +kernel)

private def hull018_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 829, 830, 1, 0x19f33d⟩ (by decide +kernel)

private def hull018_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 830, 831, 1, 0x19fb3e⟩ (by decide +kernel)

private def hull018_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 831, 833, 1, 0x1a0b3f⟩ (by decide +kernel)

private def hull018_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 831, 832, 1, 0x1a033f⟩ (by decide +kernel)

private def hull018_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 832, 833, 1, 0x1a0b40⟩ (by decide +kernel)

private def hull018_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 824, 833, 1, 0x1a0b38⟩ (by decide +kernel)

private def hull018_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 833, 837, 1, 0x1a2b41⟩ (by decide +kernel)

private def hull018_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 837, 842, 4, 0x34a692d21a3b45⟩ (by decide +kernel)

private def hull018_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 842, 851, 3, 0x6a6d35a634a⟩ (by decide +kernel)

private def hull018_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 833, 835, 1, 0x1a1b41⟩ (by decide +kernel)

private def hull018_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 835, 837, 1, 0x1a2b43⟩ (by decide +kernel)

private def hull018_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 833, 834, 1, 0x1a1341⟩ (by decide +kernel)

private def hull018_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 834, 835, 1, 0x1a1b42⟩ (by decide +kernel)

private def hull018_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 835, 836, 1, 0x1a2343⟩ (by decide +kernel)

private def hull018_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 836, 837, 1, 0x1a2b44⟩ (by decide +kernel)

private def hull018_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 833, 851, 5, 0x1a9b4d698d21a3b41⟩ (by decide +kernel)

private def hull018_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 815, 851, 5, 0x1a9b4d698d21a3b2f⟩ (by decide +kernel)

private def hull018_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 837, 838, 1, 0x1a3345⟩ (by decide +kernel)

private def hull018_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 838, 839, 1, 0x1a3b46⟩ (by decide +kernel)

private def hull018_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 839, 842, 3, 0x694d25a4347⟩ (by decide +kernel)

private def hull018_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 837, 839, 1, 0x1a3b45⟩ (by decide +kernel)

private def hull018_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 833, 842, 4, 0x34a692d21a3b41⟩ (by decide +kernel)

private def hull018_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 567, 851, 49, 0x1a9b4d698d2195b2a61ec3185af95f0b9d72ae45c6b716dada5b2b5d6b2d55a8b4d622c2582afd5f2ab554a9d53295528a4948a895109fd3f27b4f49cd392624c29812fa37⟩ (by decide +kernel)

private def hull018_050 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 26, 35, 9, 0x118220420800f81e03a0700d81a⟩ (by decide +kernel)

private def hull018_051 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 842, 843, 1, 0x1a5b4a⟩ (by decide +kernel)

private def hull018_052 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 843, 844, 1, 0x1a634b⟩ (by decide +kernel)

private def hull018_053 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 844, 846, 2, 0xd39a6b4c⟩ (by decide +kernel)

private def hull018_054 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 846, 851, 1, 0x1a9b4e⟩ (by decide +kernel)

private def hull018_055 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 32, 35, 3, 0x4608810820⟩ (by decide +kernel)

private def hull018_056 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 842, 846, 3, 0x69cd35a634a⟩ (by decide +kernel)

private def hull018_057 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 846, 848, 1, 0x1a834e⟩ (by decide +kernel)

private def hull018_058 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 848, 851, 1, 0x1a9b50⟩ (by decide +kernel)

private def hull018_059 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 846, 847, 1, 0x1a7b4e⟩ (by decide +kernel)

private def hull018_060 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 847, 848, 1, 0x1a834f⟩ (by decide +kernel)

private def hull018_061 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 848, 849, 1, 0x1a8b50⟩ (by decide +kernel)

private def hull018_062 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 849, 851, 1, 0x1a9b51⟩ (by decide +kernel)

private def hull018_063 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 849, 850, 1, 0x1a9351⟩ (by decide +kernel)

private def hull018_064 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 850, 851, 1, 0x1a9b52⟩ (by decide +kernel)

private def hull018_065 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 70, 61, 0x2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull018_066 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 141, 132, 0x8d11822c4508911021c4308510820c410811001fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull018_067 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 993, 1, 0x1f0b53⟩ (by decide +kernel)

private def hull018_068 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 993, 1135, 1, 0x237be1⟩ (by decide +kernel)

private def hull018_069 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 922, 39, 0x734e4dc8b9071ee39c6b8b714e25c4385708e09c0b806fedf9beb7c6f6de9bcb786eedd9bab716e0dbdb53696ced99b2b646b6d69acb53⟩ (by decide +kernel)

private def hull018_070 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 922, 993, 1, 0x1f0b9a⟩ (by decide +kernel)

private def hull018_071 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 855, 1, 0x1abb53⟩ (by decide +kernel)

private def hull018_072 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 855, 859, 4, 0x35b6b4d65ac357⟩ (by decide +kernel)

private def supportedCone2304 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨815, 816, 815, 815, 816⟩, ⟨0, 0, 5000000000, 79271711, 2680000000000, 677759075252⟩⟩
    hull018_000 0 (by decide +kernel)

private def supportedCone2305 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨816, 817, 816, 816, 817⟩, ⟨0, 0, 5000000000, 79000508, 2685000000000, 677838346963⟩⟩
    hull018_001 0 (by decide +kernel)

private def supportedCone2306 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨815, 817, 817, 815, 817⟩, ⟨10000000000, 158272219, 0, 0, 2690000000000, 677917347471⟩⟩
    hull018_002 1 (by decide +kernel)

private def supportedCone2307 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨815, 816, 816, 815, 816⟩, ⟨5000000000, 79271711, 0, 0, 2685000000000, 677838346963⟩⟩
    hull018_000 1 (by decide +kernel)

private def supportedCone2308 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨816, 817, 817, 816, 817⟩, ⟨5000000000, 79000508, 0, 0, 2690000000000, 677917347471⟩⟩
    hull018_001 1 (by decide +kernel)

private def supportedCone2309 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨815, 819, 819, 815, 819⟩, ⟨16000000000, 252656851, 0, 0, 2696000000000, 678011732103⟩⟩
    hull018_003 1 (by decide +kernel)

private def supportedCone2310 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨815, 824, 824, 815, 824⟩, ⟨40000000000, 626217779, 0, 0, 2720000000000, 678385293031⟩⟩
    hull018_004 1 (by decide +kernel)

private def supportedCone2311 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨817, 819, 819, 817, 819⟩, ⟨6000000000, 94384632, 0, 0, 2696000000000, 678011732103⟩⟩
    hull018_005 1 (by decide +kernel)

private def supportedCone2312 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨817, 818, 817, 817, 818⟩, ⟨0, 0, 5000000000, 78694143, 2690000000000, 677917347471⟩⟩
    hull018_006 0 (by decide +kernel)

private def supportedCone2313 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨818, 819, 818, 818, 819⟩, ⟨0, 0, 1000000000, 15690489, 2695000000000, 677996041614⟩⟩
    hull018_007 0 (by decide +kernel)

private def supportedCone2314 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨817, 818, 818, 817, 818⟩, ⟨5000000000, 78694143, 0, 0, 2695000000000, 677996041614⟩⟩
    hull018_006 1 (by decide +kernel)

private def supportedCone2315 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨818, 819, 819, 818, 819⟩, ⟨1000000000, 15690489, 0, 0, 2696000000000, 678011732103⟩⟩
    hull018_007 1 (by decide +kernel)

private def supportedCone2316 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨815, 833, 833, 815, 833⟩, ⟨80000000000, 1234608936, 0, 0, 2760000000000, 678993684188⟩⟩
    hull018_008 1 (by decide +kernel)

private def supportedCone2317 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨819, 821, 819, 819, 821⟩, ⟨0, 0, 9000000000, 140866948, 2696000000000, 678011732103⟩⟩
    hull018_009 0 (by decide +kernel)

private def supportedCone2318 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨821, 824, 821, 821, 824⟩, ⟨0, 0, 15000000000, 232693980, 2705000000000, 678152599051⟩⟩
    hull018_010 0 (by decide +kernel)

private def supportedCone2319 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨819, 821, 821, 819, 821⟩, ⟨9000000000, 140866948, 0, 0, 2705000000000, 678152599051⟩⟩
    hull018_009 1 (by decide +kernel)

private def supportedCone2320 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨819, 820, 819, 819, 820⟩, ⟨0, 0, 4000000000, 62726638, 2696000000000, 678011732103⟩⟩
    hull018_011 0 (by decide +kernel)

private def supportedCone2321 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨820, 821, 820, 820, 821⟩, ⟨0, 0, 5000000000, 78140310, 2700000000000, 678074458741⟩⟩
    hull018_012 0 (by decide +kernel)

private def supportedCone2322 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨819, 820, 820, 819, 820⟩, ⟨4000000000, 62726638, 0, 0, 2700000000000, 678074458741⟩⟩
    hull018_011 1 (by decide +kernel)

private def supportedCone2323 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨820, 821, 821, 820, 821⟩, ⟨5000000000, 78140310, 0, 0, 2705000000000, 678152599051⟩⟩
    hull018_012 1 (by decide +kernel)

private def supportedCone2324 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨819, 824, 824, 819, 824⟩, ⟨24000000000, 373560928, 0, 0, 2720000000000, 678385293031⟩⟩
    hull018_013 1 (by decide +kernel)

private def supportedCone2325 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨821, 822, 822, 821, 822⟩, ⟨5000000000, 77840263, 0, 0, 2710000000000, 678230439314⟩⟩
    hull018_014 1 (by decide +kernel)

private def supportedCone2326 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨822, 824, 822, 822, 824⟩, ⟨0, 0, 10000000000, 154853717, 2710000000000, 678230439314⟩⟩
    hull018_015 0 (by decide +kernel)

private def supportedCone2327 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨821, 822, 821, 821, 822⟩, ⟨0, 0, 5000000000, 77840263, 2705000000000, 678152599051⟩⟩
    hull018_014 0 (by decide +kernel)

private def supportedCone2328 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨821, 824, 824, 821, 824⟩, ⟨15000000000, 232693980, 0, 0, 2720000000000, 678385293031⟩⟩
    hull018_010 1 (by decide +kernel)

private def supportedCone2329 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨822, 823, 822, 822, 823⟩, ⟨0, 0, 5000000000, 77574143, 2710000000000, 678230439314⟩⟩
    hull018_016 0 (by decide +kernel)

private def supportedCone2330 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨823, 824, 823, 823, 824⟩, ⟨0, 0, 5000000000, 77279574, 2715000000000, 678308013457⟩⟩
    hull018_017 0 (by decide +kernel)

private def supportedCone2331 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨822, 823, 823, 822, 823⟩, ⟨5000000000, 77574143, 0, 0, 2715000000000, 678308013457⟩⟩
    hull018_016 1 (by decide +kernel)

private def supportedCone2332 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨822, 824, 824, 822, 824⟩, ⟨10000000000, 154853717, 0, 0, 2720000000000, 678385293031⟩⟩
    hull018_015 1 (by decide +kernel)

private def supportedCone2333 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨823, 824, 824, 823, 824⟩, ⟨5000000000, 77279574, 0, 0, 2720000000000, 678385293031⟩⟩
    hull018_017 1 (by decide +kernel)

private def supportedCone2334 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨824, 828, 824, 824, 828⟩, ⟨0, 0, 15000000000, 230188188, 2720000000000, 678385293031⟩⟩
    hull018_018 0 (by decide +kernel)

private def supportedCone2335 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨828, 833, 828, 828, 833⟩, ⟨0, 0, 25000000000, 378202969, 2735000000000, 678615481219⟩⟩
    hull018_019 0 (by decide +kernel)

def appendixHullConeBlock0072 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2304,
    supportedCone2305,
    supportedCone2306,
    supportedCone2307,
    supportedCone2308,
    supportedCone2309,
    supportedCone2310,
    supportedCone2311,
    supportedCone2312,
    supportedCone2313,
    supportedCone2314,
    supportedCone2315,
    supportedCone2316,
    supportedCone2317,
    supportedCone2318,
    supportedCone2319,
    supportedCone2320,
    supportedCone2321,
    supportedCone2322,
    supportedCone2323,
    supportedCone2324,
    supportedCone2325,
    supportedCone2326,
    supportedCone2327,
    supportedCone2328,
    supportedCone2329,
    supportedCone2330,
    supportedCone2331,
    supportedCone2332,
    supportedCone2333,
    supportedCone2334,
    supportedCone2335,
  ], rfl⟩

private def supportedCone2336 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨824, 826, 824, 824, 826⟩, ⟨0, 0, 10000000000, 153738236, 2720000000000, 678385293031⟩⟩
    hull018_020 0 (by decide +kernel)

private def supportedCone2337 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨826, 828, 826, 826, 828⟩, ⟨0, 0, 5000000000, 76449952, 2730000000000, 678539031267⟩⟩
    hull018_021 0 (by decide +kernel)

private def supportedCone2338 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨824, 825, 824, 824, 825⟩, ⟨0, 0, 5000000000, 77012600, 2720000000000, 678385293031⟩⟩
    hull018_022 0 (by decide +kernel)

private def supportedCone2339 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨825, 826, 825, 825, 826⟩, ⟨0, 0, 5000000000, 76725636, 2725000000000, 678462305631⟩⟩
    hull018_023 0 (by decide +kernel)

private def supportedCone2340 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨824, 825, 825, 824, 825⟩, ⟨5000000000, 77012600, 0, 0, 2725000000000, 678462305631⟩⟩
    hull018_022 1 (by decide +kernel)

private def supportedCone2341 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨824, 826, 826, 824, 826⟩, ⟨10000000000, 153738236, 0, 0, 2730000000000, 678539031267⟩⟩
    hull018_020 1 (by decide +kernel)

private def supportedCone2342 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨825, 826, 826, 825, 826⟩, ⟨5000000000, 76725636, 0, 0, 2730000000000, 678539031267⟩⟩
    hull018_023 1 (by decide +kernel)

private def supportedCone2343 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨824, 828, 828, 824, 828⟩, ⟨15000000000, 230188188, 0, 0, 2735000000000, 678615481219⟩⟩
    hull018_018 1 (by decide +kernel)

private def supportedCone2344 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨826, 828, 828, 826, 828⟩, ⟨5000000000, 76449952, 0, 0, 2735000000000, 678615481219⟩⟩
    hull018_021 1 (by decide +kernel)

private def supportedCone2345 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨828, 830, 828, 828, 830⟩, ⟨0, 0, 10000000000, 152088391, 2735000000000, 678615481219⟩⟩
    hull018_024 0 (by decide +kernel)

private def supportedCone2346 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨830, 833, 830, 830, 833⟩, ⟨0, 0, 15000000000, 226114578, 2745000000000, 678767569610⟩⟩
    hull018_025 0 (by decide +kernel)

private def supportedCone2347 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨828, 830, 830, 828, 830⟩, ⟨10000000000, 152088391, 0, 0, 2745000000000, 678767569610⟩⟩
    hull018_024 1 (by decide +kernel)

private def supportedCone2348 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨828, 829, 828, 828, 829⟩, ⟨0, 0, 5000000000, 76196705, 2735000000000, 678615481219⟩⟩
    hull018_026 0 (by decide +kernel)

private def supportedCone2349 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨829, 830, 829, 829, 830⟩, ⟨0, 0, 5000000000, 75891686, 2740000000000, 678691677924⟩⟩
    hull018_027 0 (by decide +kernel)

private def supportedCone2350 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨828, 829, 829, 828, 829⟩, ⟨5000000000, 76196705, 0, 0, 2740000000000, 678691677924⟩⟩
    hull018_026 1 (by decide +kernel)

private def supportedCone2351 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨829, 830, 830, 829, 830⟩, ⟨5000000000, 75891686, 0, 0, 2745000000000, 678767569610⟩⟩
    hull018_027 1 (by decide +kernel)

private def supportedCone2352 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨830, 831, 830, 830, 831⟩, ⟨0, 0, 5000000000, 75651248, 2745000000000, 678767569610⟩⟩
    hull018_028 0 (by decide +kernel)

private def supportedCone2353 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨831, 833, 831, 831, 833⟩, ⟨0, 0, 10000000000, 150463330, 2750000000000, 678843220858⟩⟩
    hull018_029 0 (by decide +kernel)

private def supportedCone2354 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨830, 833, 833, 830, 833⟩, ⟨15000000000, 226114578, 0, 0, 2760000000000, 678993684188⟩⟩
    hull018_025 1 (by decide +kernel)

private def supportedCone2355 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨830, 831, 831, 830, 831⟩, ⟨5000000000, 75651248, 0, 0, 2750000000000, 678843220858⟩⟩
    hull018_028 1 (by decide +kernel)

private def supportedCone2356 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨828, 833, 833, 828, 833⟩, ⟨25000000000, 378202969, 0, 0, 2760000000000, 678993684188⟩⟩
    hull018_019 1 (by decide +kernel)

private def supportedCone2357 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨831, 833, 833, 831, 833⟩, ⟨10000000000, 150463330, 0, 0, 2760000000000, 678993684188⟩⟩
    hull018_029 1 (by decide +kernel)

private def supportedCone2358 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨831, 832, 831, 831, 832⟩, ⟨0, 0, 5000000000, 75352102, 2750000000000, 678843220858⟩⟩
    hull018_030 0 (by decide +kernel)

private def supportedCone2359 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨832, 833, 832, 832, 833⟩, ⟨0, 0, 5000000000, 75111228, 2755000000000, 678918572960⟩⟩
    hull018_031 0 (by decide +kernel)

private def supportedCone2360 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨831, 832, 832, 831, 832⟩, ⟨5000000000, 75352102, 0, 0, 2755000000000, 678918572960⟩⟩
    hull018_030 1 (by decide +kernel)

private def supportedCone2361 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨824, 833, 833, 824, 833⟩, ⟨40000000000, 608391157, 0, 0, 2760000000000, 678993684188⟩⟩
    hull018_032 1 (by decide +kernel)

private def supportedCone2362 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨832, 833, 833, 832, 833⟩, ⟨5000000000, 75111228, 0, 0, 2760000000000, 678993684188⟩⟩
    hull018_031 1 (by decide +kernel)

private def supportedCone2363 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 837, 833, 833, 837⟩, ⟨0, 0, 15000000000, 223710275, 2760000000000, 678993684188⟩⟩
    hull018_033 0 (by decide +kernel)

private def supportedCone2364 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨837, 842, 837, 837, 839⟩, ⟨0, 0, 10000000000, 147886797, 2775000000000, 679217394463⟩⟩
    hull018_034 0 (by decide +kernel)

private def supportedCone2365 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨842, 851, 842, 842, 844⟩, ⟨0, 0, 10000000000, 159372971, 2795000000000, 679523781680⟩⟩
    hull018_035 0 (by decide +kernel)

private def supportedCone2366 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 835, 833, 833, 835⟩, ⟨0, 0, 8000000000, 119564850, 2760000000000, 678993684188⟩⟩
    hull018_036 0 (by decide +kernel)

private def supportedCone2367 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨835, 837, 835, 835, 837⟩, ⟨0, 0, 7000000000, 104145425, 2768000000000, 679113249038⟩⟩
    hull018_037 0 (by decide +kernel)

def appendixHullConeBlock0073 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2336,
    supportedCone2337,
    supportedCone2338,
    supportedCone2339,
    supportedCone2340,
    supportedCone2341,
    supportedCone2342,
    supportedCone2343,
    supportedCone2344,
    supportedCone2345,
    supportedCone2346,
    supportedCone2347,
    supportedCone2348,
    supportedCone2349,
    supportedCone2350,
    supportedCone2351,
    supportedCone2352,
    supportedCone2353,
    supportedCone2354,
    supportedCone2355,
    supportedCone2356,
    supportedCone2357,
    supportedCone2358,
    supportedCone2359,
    supportedCone2360,
    supportedCone2361,
    supportedCone2362,
    supportedCone2363,
    supportedCone2364,
    supportedCone2365,
    supportedCone2366,
    supportedCone2367,
  ], rfl⟩

private def supportedCone2368 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 834, 833, 833, 834⟩, ⟨0, 0, 5000000000, 74819226, 2760000000000, 678993684188⟩⟩
    hull018_038 0 (by decide +kernel)

private def supportedCone2369 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨834, 835, 834, 834, 835⟩, ⟨0, 0, 3000000000, 44745624, 2765000000000, 679068503414⟩⟩
    hull018_039 0 (by decide +kernel)

private def supportedCone2370 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 834, 834, 833, 834⟩, ⟨5000000000, 74819226, 0, 0, 2765000000000, 679068503414⟩⟩
    hull018_038 1 (by decide +kernel)

private def supportedCone2371 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 835, 835, 833, 835⟩, ⟨8000000000, 119564850, 0, 0, 2768000000000, 679113249038⟩⟩
    hull018_036 1 (by decide +kernel)

private def supportedCone2372 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨834, 835, 835, 834, 835⟩, ⟨3000000000, 44745624, 0, 0, 2768000000000, 679113249038⟩⟩
    hull018_039 1 (by decide +kernel)

private def supportedCone2373 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨835, 837, 837, 835, 837⟩, ⟨7000000000, 104145425, 0, 0, 2775000000000, 679217394463⟩⟩
    hull018_037 1 (by decide +kernel)

private def supportedCone2374 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨835, 836, 836, 835, 836⟩, ⟨2000000000, 29810004, 0, 0, 2770000000000, 679143059042⟩⟩
    hull018_040 1 (by decide +kernel)

private def supportedCone2375 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨836, 837, 836, 836, 837⟩, ⟨0, 0, 5000000000, 74335421, 2770000000000, 679143059042⟩⟩
    hull018_041 0 (by decide +kernel)

private def supportedCone2376 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 851, 851, 845, 851⟩, ⟨30000000000, 509557104, 0, 0, 2840000000000, 680275614632⟩⟩
    hull018_042 5 (by decide +kernel)

private def supportedCone2377 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨836, 837, 837, 836, 837⟩, ⟨5000000000, 74335421, 0, 0, 2775000000000, 679217394463⟩⟩
    hull018_041 1 (by decide +kernel)

private def supportedCone2378 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 837, 837, 833, 837⟩, ⟨15000000000, 223710275, 0, 0, 2775000000000, 679217394463⟩⟩
    hull018_033 1 (by decide +kernel)

private def supportedCone2379 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨815, 851, 840, 839, 844⟩, ⟨5000000000, 76519217, 15000000000, 241354174, 2790000000000, 679441800477⟩⟩
    hull018_043 2 (by decide +kernel)

private def supportedCone2380 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨837, 838, 837, 837, 838⟩, ⟨0, 0, 5000000000, 74002616, 2775000000000, 679217394463⟩⟩
    hull018_044 0 (by decide +kernel)

private def supportedCone2381 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨838, 839, 838, 838, 839⟩, ⟨0, 0, 5000000000, 73884181, 2780000000000, 679291397079⟩⟩
    hull018_045 0 (by decide +kernel)

private def supportedCone2382 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨839, 842, 839, 839, 840⟩, ⟨0, 0, 5000000000, 76519217, 2785000000000, 679365281260⟩⟩
    hull018_046 0 (by decide +kernel)

private def supportedCone2383 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨837, 839, 839, 837, 839⟩, ⟨10000000000, 147886797, 0, 0, 2785000000000, 679365281260⟩⟩
    hull018_047 1 (by decide +kernel)

private def supportedCone2384 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨837, 839, 837, 837, 839⟩, ⟨0, 0, 10000000000, 147886797, 2775000000000, 679217394463⟩⟩
    hull018_047 0 (by decide +kernel)

private def supportedCone2385 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨837, 838, 838, 837, 838⟩, ⟨5000000000, 74002616, 0, 0, 2780000000000, 679291397079⟩⟩
    hull018_044 1 (by decide +kernel)

private def supportedCone2386 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨838, 839, 839, 838, 839⟩, ⟨5000000000, 73884181, 0, 0, 2785000000000, 679365281260⟩⟩
    hull018_045 1 (by decide +kernel)

private def supportedCone2387 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨837, 842, 839, 837, 840⟩, ⟨10000000000, 147886797, 5000000000, 76519217, 2785000000000, 679365281260⟩⟩
    hull018_034 1 (by decide +kernel)

private def supportedCone2388 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 851, 839, 833, 840⟩, ⟨25000000000, 371597072, 5000000000, 76519217, 2785000000000, 679365281260⟩⟩
    hull018_042 1 (by decide +kernel)

private def supportedCone2389 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 842, 840, 839, 841⟩, ⟨5000000000, 76519217, 2000000000, 32722243, 2790000000000, 679441800477⟩⟩
    hull018_048 2 (by decide +kernel)

private def supportedCone2390 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 842, 841, 840, 842⟩, ⟨2000000000, 32722243, 3000000000, 49258960, 2792000000000, 679474522720⟩⟩
    hull018_048 3 (by decide +kernel)

private def supportedCone2391 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 845, 844, 851⟩, ⟨5000000000, 82902877, 30000000000, 509557104, 2810000000000, 679766057528⟩⟩
    hull018_049 48 (by decide +kernel)

private def supportedCone2392 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨26, 35, 32, 31, 33⟩, ⟨1405628119, 52888125, 1263823080, 49116029, 256405628119, 499191035⟩⟩
    hull018_050 6 (by decide +kernel)

private def supportedCone2393 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨833, 842, 842, 841, 842⟩, ⟨3000000000, 49258960, 0, 0, 2795000000000, 679523781680⟩⟩
    hull018_048 4 (by decide +kernel)

private def supportedCone2394 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨842, 843, 842, 842, 843⟩, ⟨0, 0, 5000000000, 80399524, 2795000000000, 679523781680⟩⟩
    hull018_051 0 (by decide +kernel)

private def supportedCone2395 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨843, 844, 843, 843, 844⟩, ⟨0, 0, 5000000000, 78973447, 2800000000000, 679604181204⟩⟩
    hull018_052 0 (by decide +kernel)

private def supportedCone2396 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨844, 846, 844, 844, 845⟩, ⟨0, 0, 5000000000, 82902877, 2805000000000, 679683154651⟩⟩
    hull018_053 0 (by decide +kernel)

private def supportedCone2397 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨846, 851, 846, 846, 851⟩, ⟨0, 0, 25000000000, 423935591, 2815000000000, 679851679041⟩⟩
    hull018_054 0 (by decide +kernel)

private def supportedCone2398 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨842, 843, 843, 842, 843⟩, ⟨5000000000, 80399524, 0, 0, 2800000000000, 679604181204⟩⟩
    hull018_051 1 (by decide +kernel)

private def supportedCone2399 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨842, 851, 851, 845, 851⟩, ⟨30000000000, 509557104, 0, 0, 2840000000000, 680275614632⟩⟩
    hull018_035 3 (by decide +kernel)

def appendixHullConeBlock0074 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2368,
    supportedCone2369,
    supportedCone2370,
    supportedCone2371,
    supportedCone2372,
    supportedCone2373,
    supportedCone2374,
    supportedCone2375,
    supportedCone2376,
    supportedCone2377,
    supportedCone2378,
    supportedCone2379,
    supportedCone2380,
    supportedCone2381,
    supportedCone2382,
    supportedCone2383,
    supportedCone2384,
    supportedCone2385,
    supportedCone2386,
    supportedCone2387,
    supportedCone2388,
    supportedCone2389,
    supportedCone2390,
    supportedCone2391,
    supportedCone2392,
    supportedCone2393,
    supportedCone2394,
    supportedCone2395,
    supportedCone2396,
    supportedCone2397,
    supportedCone2398,
    supportedCone2399,
  ], rfl⟩

private def supportedCone2400 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨842, 851, 845, 844, 851⟩, ⟨5000000000, 82902877, 30000000000, 509557104, 2810000000000, 679766057528⟩⟩
    hull018_035 2 (by decide +kernel)

private def supportedCone2401 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨843, 844, 844, 843, 844⟩, ⟨5000000000, 78973447, 0, 0, 2805000000000, 679683154651⟩⟩
    hull018_052 1 (by decide +kernel)

private def supportedCone2402 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 844, 840, 845⟩, ⟨15000000000, 241354174, 5000000000, 82902877, 2805000000000, 679683154651⟩⟩
    hull018_049 47 (by decide +kernel)

private def supportedCone2403 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨32, 35, 35, 34, 35⟩, ⟨1503327172, 68709630, 0, 0, 260000000000, 651686301⟩⟩
    hull018_055 3 (by decide +kernel)

private def supportedCone2404 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨842, 846, 845, 844, 846⟩, ⟨5000000000, 82902877, 5000000000, 85621513, 2810000000000, 679766057528⟩⟩
    hull018_056 2 (by decide +kernel)

private def supportedCone2405 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨842, 846, 846, 845, 846⟩, ⟨5000000000, 85621513, 0, 0, 2815000000000, 679851679041⟩⟩
    hull018_056 3 (by decide +kernel)

private def supportedCone2406 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨846, 848, 846, 846, 848⟩, ⟨0, 0, 10000000000, 170319097, 2815000000000, 679851679041⟩⟩
    hull018_057 0 (by decide +kernel)

private def supportedCone2407 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨848, 851, 848, 848, 851⟩, ⟨0, 0, 15000000000, 253616494, 2825000000000, 680021998138⟩⟩
    hull018_058 0 (by decide +kernel)

private def supportedCone2408 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨846, 848, 848, 846, 848⟩, ⟨10000000000, 170319097, 0, 0, 2825000000000, 680021998138⟩⟩
    hull018_057 1 (by decide +kernel)

private def supportedCone2409 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨846, 847, 846, 846, 847⟩, ⟨0, 0, 5000000000, 85263214, 2815000000000, 679851679041⟩⟩
    hull018_059 0 (by decide +kernel)

private def supportedCone2410 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨847, 848, 847, 847, 848⟩, ⟨0, 0, 5000000000, 85055883, 2820000000000, 679936942255⟩⟩
    hull018_060 0 (by decide +kernel)

private def supportedCone2411 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨846, 847, 847, 846, 847⟩, ⟨5000000000, 85263214, 0, 0, 2820000000000, 679936942255⟩⟩
    hull018_059 1 (by decide +kernel)

private def supportedCone2412 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨847, 848, 848, 847, 848⟩, ⟨5000000000, 85055883, 0, 0, 2825000000000, 680021998138⟩⟩
    hull018_060 1 (by decide +kernel)

private def supportedCone2413 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨848, 849, 849, 848, 849⟩, ⟨5000000000, 84697909, 0, 0, 2830000000000, 680106696047⟩⟩
    hull018_061 1 (by decide +kernel)

private def supportedCone2414 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨849, 851, 849, 849, 851⟩, ⟨0, 0, 10000000000, 168918585, 2830000000000, 680106696047⟩⟩
    hull018_062 0 (by decide +kernel)

private def supportedCone2415 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨848, 849, 848, 848, 849⟩, ⟨0, 0, 5000000000, 84697909, 2825000000000, 680021998138⟩⟩
    hull018_061 0 (by decide +kernel)

private def supportedCone2416 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨849, 850, 849, 849, 850⟩, ⟨0, 0, 5000000000, 84529305, 2830000000000, 680106696047⟩⟩
    hull018_063 0 (by decide +kernel)

private def supportedCone2417 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨850, 851, 850, 850, 851⟩, ⟨0, 0, 5000000000, 84389280, 2835000000000, 680191225352⟩⟩
    hull018_064 0 (by decide +kernel)

private def supportedCone2418 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨849, 850, 850, 849, 850⟩, ⟨5000000000, 84529305, 0, 0, 2835000000000, 680191225352⟩⟩
    hull018_063 1 (by decide +kernel)

private def supportedCone2419 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨849, 851, 851, 849, 851⟩, ⟨10000000000, 168918585, 0, 0, 2840000000000, 680275614632⟩⟩
    hull018_062 1 (by decide +kernel)

private def supportedCone2420 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 55, 54, 56⟩, ⟨1998814794, 184328284, 1000000000, 94363393, 284000000000, 2342643062⟩⟩
    hull018_065 46 (by decide +kernel)

private def supportedCone2421 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨850, 851, 851, 850, 851⟩, ⟨5000000000, 84389280, 0, 0, 2840000000000, 680275614632⟩⟩
    hull018_064 1 (by decide +kernel)

private def supportedCone2422 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨846, 851, 851, 846, 851⟩, ⟨25000000000, 423935591, 0, 0, 2840000000000, 680275614632⟩⟩
    hull018_054 1 (by decide +kernel)

private def supportedCone2423 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 109, 108, 110⟩, ⟨3276468983, 611626172, 1723531017, 330987296, 348276468983, 11646846934⟩⟩
    hull018_066 100 (by decide +kernel)

private def supportedCone2424 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 993, 851, 851, 993⟩, ⟨0, 0, 30820553629059, 302849851332, 2840000000000, 680275614632⟩⟩
    hull018_067 0 (by decide +kernel)

private def supportedCone2425 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 1135, 993, 993, 1135⟩, ⟨0, 0, 1999999999966339446370941, 49016874534036, 33660553629059, 983125465964⟩⟩
    hull018_068 0 (by decide +kernel)

private def supportedCone2426 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 851, 851, 857⟩, ⟨0, 0, 25000000000, 421527664, 2840000000000, 680275614632⟩⟩
    hull018_069 0 (by decide +kernel)

private def supportedCone2427 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨922, 993, 922, 922, 993⟩, ⟨0, 0, 28499394021229, 225474891532, 5161159607830, 757650574432⟩⟩
    hull018_070 0 (by decide +kernel)

private def supportedCone2428 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 857, 851, 858⟩, ⟨25000000000, 421527664, 5000000000, 85544279, 2865000000000, 680697142296⟩⟩
    hull018_069 1 (by decide +kernel)

private def supportedCone2429 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 870, 869, 871⟩, ⟨5000000000, 94232469, 5000000000, 95505920, 2930000000000, 681895150564⟩⟩
    hull018_069 6 (by decide +kernel)

private def supportedCone2430 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 855, 851, 851, 855⟩, ⟨0, 0, 20000000000, 337784524, 2840000000000, 680275614632⟩⟩
    hull018_071 0 (by decide +kernel)

private def supportedCone2431 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨855, 859, 855, 855, 856⟩, ⟨0, 0, 4000000000, 66888548, 2860000000000, 680613399156⟩⟩
    hull018_072 0 (by decide +kernel)

def appendixHullConeBlock0075 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2400,
    supportedCone2401,
    supportedCone2402,
    supportedCone2403,
    supportedCone2404,
    supportedCone2405,
    supportedCone2406,
    supportedCone2407,
    supportedCone2408,
    supportedCone2409,
    supportedCone2410,
    supportedCone2411,
    supportedCone2412,
    supportedCone2413,
    supportedCone2414,
    supportedCone2415,
    supportedCone2416,
    supportedCone2417,
    supportedCone2418,
    supportedCone2419,
    supportedCone2420,
    supportedCone2421,
    supportedCone2422,
    supportedCone2423,
    supportedCone2424,
    supportedCone2425,
    supportedCone2426,
    supportedCone2427,
    supportedCone2428,
    supportedCone2429,
    supportedCone2430,
    supportedCone2431,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
