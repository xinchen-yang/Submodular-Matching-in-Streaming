import SubmodularMatching.NonmonotoneGridRowRational
import SubmodularMatching.NonmonotoneRetainedRuntime

/-! The Gibbs chain reads the integer compensated numerator computed directly
from the diffuse and nonlinear registers of the optimizer. -/
namespace SubmodularMatching.NonmonotoneCandidate.GridRow
open Capacity TwoLayerDiffuse Shearer GibbsMatching TwoStage AppendixM NonmonotoneLayers UpperBoundAssembly
variable {I V : Type*} [Fintype I] [DecidableEq I] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream I V} {b : V→ℕ} (g : GridRow S b)

def rationalUpper (rank : Slots b ↪ ℕ) (i : I) : ℚ :=
  let T := rationalTable S.ends (decodedCoordinate S b g.k g.q g.w)
  let m := pairScanGrid (scaleFor (S:=S) rank)
  let θ := firstDegreeQ/layerDegreeQ
  rationalPairUpper b T θ m (g.pair i).1 (g.pair i).2 *
    rationalPairUpper b T (1-θ) m (g.pair i).1 (g.pair i).2

theorem rationalUpper_cast (rank : Slots b ↪ ℕ) (i : I) : (g.rationalUpper rank i:ℝ)=g.upper rank i := by
  simp only [rationalUpper,upper,Rat.cast_mul,rationalPairUpper_cast,rationalTable_cast,table,
    Rat.cast_sub,Rat.cast_one,Rat.cast_div,cast_firstDegreeQ,cast_degreeQ,firstProportion,secondProportion]
  rfl

def rationalNumerator (rank : Slots b ↪ ℕ) (x : I→ℚ) :=
  let K := scaleFor (S:=S) rank
  let Sslot := layerSupport S b rank
  let ε := min (1/(2:ℚ)^30) 1 / 2
  fun (z : Marked pairVertices Sslot (firstBins K) × Marked pairVertices Sslot (secondBins K)) (i : I) =>
    rationalAlteration g.pair (assignedGrid K) x (g.rationalUpper rank) ε
      (freeRegister pairVertices (forgetMark z.1).val (forgetMark z.2).val) i

theorem rationalNumerator_eq (rank : Slots b ↪ ℕ) (x : I→ℚ) (hx : ∀i,(x i:ℝ)=g.x i) :
    g.rationalNumerator rank x = g.numerator rank := by
  funext z i
  let ω := (forgetMark z.1,forgetMark z.2)
  have eqn := rationalAlteration_cast g.pair (assignedGrid (scaleFor (S:=S) rank)) x (g.rationalUpper rank)
    (min (1/(2:ℚ)^30) 1 / 2) (freeRegister pairVertices ω.1.val ω.2.val)
    (vacant pairVertices (layerSupport S b rank)) ω (fun v => freeRegister_cast _ _ _ v) i
  have ep : ((min (1/(2:ℚ)^30) 1 / 2 : ℚ) : ℝ) = tolerance roundingTolerance := by
    norm_num [tolerance,roundingTolerance]
  simpa only [rationalNumerator,numerator,markedNumerator,hx,rationalUpper_cast,ep,ω] using eqn

/-- Every optimizer register vector with its finite packing certificate feeds
the integer Gibbs walk by rational coordinates alone. -/
theorem ofCoordinates_gibbs_words {m l : ℕ} (S : SimpleEdgeStream I V) (b : V→ℕ) (hb : ∀ v,0<b v)
    (left : (i:I)→Fin (b (S.ends i).1)) (right : (i:I)→Fin (b (S.ends i).2))
    (rows : Fin m ≃ ↑(activeRows S.ends b (slotPair S.ends b left right))) (cols : Fin l ≃ I⊕I)
    (rowBits : ℕ) (hm : 0<m) (hl : 0<l) (k q T : ℕ) (hT : 0<T)
    (it : Fin l→ℚ) (num : Fin l→ℕ) (words : ∀ j,it j=(num j:ℚ)/T)
    (rank : Slots b ↪ ℕ) :
    let G := actualGrid S.ends b (slotPair S.ends b left right) sourceProbability
      (by norm_num [sourceProbability]) (by norm_num [sourceProbability]) rows cols rowBits hm hl
    ∀ feasible : NonmonotoneOptimizer.feasible G.entry G.den (fun j => (it j:ℝ)),
    let r := ofCoordinates S b hb left right rows cols rowBits hm hl k q T hT it num words feasible
    r.rationalNumerator rank (fun i => sourceProbability*edgeInterceptQ*it (cols.symm (.inl i))) =
      r.numerator rank := by
  intro G feasible r
  apply r.rationalNumerator_eq
  intro i
  change ((sourceProbability*edgeInterceptQ*it (cols.symm (.inl i)):ℚ):ℝ) =
    (sourceProbability:ℝ)*edgeIntercept*it (cols.symm (.inl i))
  simp only [Rat.cast_mul,cast_edgeA]

end SubmodularMatching.NonmonotoneCandidate.GridRow
