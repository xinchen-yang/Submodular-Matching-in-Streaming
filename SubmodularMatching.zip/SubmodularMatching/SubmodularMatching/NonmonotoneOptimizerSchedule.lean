import SubmodularMatching.NonmonotoneOptimizerSearch

/-! Explicit polynomial iteration and mesh schedules for inverse-polynomial
regret. Increasing the dyadic scale supports growing dimensions and gradients. -/

namespace SubmodularMatching.NonmonotoneOptimizer

/-- `2^k` dominates the number of columns, all normalized gradient coordinates,
and the desired inverse error. -/
def scale (k : ℕ) := 2^k

def schedule (k : ℕ) : ProjectParams :=
  ⟨1/(scale k:ℚ)^9,1/(scale k:ℚ)^5,1/(scale k:ℚ)^5,2,18*k⟩

def stepSize (k : ℕ) : ℚ := 1/(scale k:ℚ)^4

def projectionFuel (k : ℕ) : ℕ := 16*(scale k)^15

def ascentFuel (k : ℕ) : ℕ := (scale k)^8

theorem schedule_valid (k : ℕ) : (schedule k).Valid := by
  have hP : (1:ℚ) ≤ scale k := by exact_mod_cast (show 1 ≤ scale k by unfold scale; exact Nat.one_le_iff_ne_zero.mpr (pow_ne_zero _ (by decide)))
  have h1 (e : ℕ) : 0 < 1/(scale k:ℚ)^e ∧ 1/(scale k:ℚ)^e ≤ 1 := by
    have hpp : (1:ℚ) ≤ (scale k:ℚ)^e := one_le_pow₀ hP
    exact ⟨one_div_pos.mpr (by linarith),(div_le_one (by linarith)).mpr hpp⟩
  exact ⟨(h1 9).1,(h1 9).2,(h1 5).1,(h1 5).2,by norm_num [schedule]⟩

theorem schedule_mesh (k : ℕ) : ((schedule k).mesh : ℝ) = 1/(scale k:ℝ)^18 := by
  simp only [ProjectParams.mesh,schedule,scale,Rat.cast_div,Rat.cast_one,Rat.cast_pow,
    Rat.cast_ofNat,Nat.cast_pow,Nat.cast_ofNat,← pow_mul,Nat.mul_comm]

theorem schedule_residual (k : ℕ) : (schedule k).residual = 3/(scale k:ℝ)^5 := by
  unfold ProjectParams.residual schedule
  push_cast
  ring

/-- Explicit fuel suffices uniformly for all targets bounded by two. -/
theorem projectionFuel_suffices (k N : ℕ) (hscale : 2 ≤ scale k) (hN : N ≤ scale k) :
    (N:ℝ)*(1+((schedule k).bound:ℝ))^2 < projectionFuel k * (schedule k).decrease N := by
  let P : ℝ := scale k
  have h2 : 2 ≤ P := by change (2:ℝ) ≤ (scale k:ℝ); exact_mod_cast hscale
  have h0 : 0 < P := by linarith
  have hn : (N:ℝ) ≤ P := by change (N:ℝ) ≤ (scale k:ℝ); exact_mod_cast hN
  have hc : (5:ℝ)*N ≤ P^4 := by
    have hp3 : (2:ℝ)^3 ≤ P^3 := pow_le_pow_left₀ (by norm_num) h2 3
    nlinarith only [hn,h0,mul_le_mul_of_nonneg_right hp3 h0.le]
  have hdec : 1/P^14 ≤ (schedule k).decrease N := by
    rw [ProjectParams.decrease,schedule_mesh]
    change 1/P^14 ≤ 2*((1/(scale k:ℚ)^9:ℚ):ℝ)*((1/(scale k:ℚ)^5:ℚ):ℝ) -
      ((1/(scale k:ℚ)^9:ℚ):ℝ)^2*N-N*(2*(2:ℝ)*(1/P^18))
    push_cast
    change 1/P^14 ≤ 2*(1/P^9)*(1/P^5)-(1/P^9)^2*N-N*(2*2*(1/P^18))
    field_simp
    nlinarith only [hc]
  have hf : (projectionFuel k:ℝ) = 16*P^15 := by simp [projectionFuel,P]
  have hmul := mul_le_mul_of_nonneg_left hdec (show 0 ≤ 16*P^15 by positivity)
  have hprod : 16*P^15*(1/P^14) = 16*P := by field_simp
  rw [hprod] at hmul
  rw [hf]
  change (N:ℝ)*(1+(2:ℝ))^2 < _
  linarith only [hn,h0,hmul]

/-- When the squared gradient norm is bounded by `P³`, the average regret of
the finite outer run is at most `5/P` against every feasible state. -/
theorem ascentFuel_suffices (k N : ℕ) (hscale : 2 ≤ scale k) (hN : N ≤ scale k) :
    let P : ℝ := scale k
    (N:ℝ) + ascentFuel k * ((stepSize k:ℝ)^2*P^3+2*(schedule k).residual) ≤
      2*(stepSize k:ℝ)*(ascentFuel k*(5/P)) := by
  intro P
  have h2 : 2 ≤ P := by change (2:ℝ) ≤ (scale k:ℝ); exact_mod_cast hscale
  have h0 : 0 < P := by linarith
  have hn : (N:ℝ) ≤ P := by change (N:ℝ) ≤ (scale k:ℝ); exact_mod_cast hN
  have hp : P ≤ P^3 := by
    nlinarith only [mul_le_mul_of_nonneg_right (one_le_pow₀ (show 1 ≤ P by linarith) (n := 2)) h0.le]
  have he : (stepSize k:ℝ) = 1/P^4 := by simp [stepSize,P]
  have ht : (ascentFuel k:ℝ) = P^8 := by simp [ascentFuel,P]
  rw [he,ht,schedule_residual]
  change (N:ℝ) + P^8*((1/P^4)^2*P^3+2*(3/P^5)) ≤ 2*(1/P^4)*(P^8*(5/P))
  have h1 : P^8*((1/P^4)^2*P^3+2*(3/P^5)) = 7*P^3 := by field_simp; ring
  have h2' : 2*(1/P^4)*(P^8*(5/P)) = 10*P^3 := by field_simp; ring
  rw [h1,h2']; linarith

end SubmodularMatching.NonmonotoneOptimizer
