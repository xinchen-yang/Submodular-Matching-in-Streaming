import SubmodularMatching.GuessLifecycleSchedule

/-! # Forward compact source over exact real-oracle arithmetic -/

namespace SubmodularMatching.Streaming.RealSource

noncomputable section

open scoped BigOperators

/-- Advance to the first eligible scale by testing at most `fuel` doublings. -/
def seekDyadic (candidate target : ℝ) : ℕ → ℕ
  | 0 => 0
  | fuel + 1 =>
      if target ≤ candidate then 0 else 1 + seekDyadic (2 * candidate) target fuel

theorem seekDyadic_correct (candidate target : ℝ) (fuel : ℕ)
    (hu : target ≤ candidate * 2 ^ fuel) :
    seekDyadic candidate target fuel ≤ fuel ∧
      target ≤ candidate * 2 ^ seekDyadic candidate target fuel ∧
      ∀ i < seekDyadic candidate target fuel, candidate * 2 ^ i < target := by
  induction fuel generalizing candidate with
  | zero => simpa [seekDyadic] using hu
  | succ fuel ih =>
    rw [seekDyadic]
    by_cases h : target ≤ candidate
    · rw [if_pos h]
      simp [h]
    · rw [if_neg h]
      have hu' : target ≤ (2 * candidate) * 2 ^ fuel := by
        rw [pow_succ] at hu
        convert hu using 1; ring
      obtain ⟨hlen, hgood, hmin⟩ := ih _ hu'
      refine ⟨by omega, ?_, ?_⟩
      · rw [add_comm 1, pow_succ]
        convert hgood using 1; ring
      · intro i hi
        cases i with
        | zero => simpa using lt_of_not_ge h
        | succ i =>
          have hi' := hmin i (by omega)
          rw [pow_succ]
          convert hi' using 1; ring

/-- The scalar streaming state that is independent of the sampled
estimates. It retains the current best singleton and reference scale. -/
structure OnlineEpoch where
  best : ℝ
  anchor : ℝ
  least : ℕ

def OnlineEpoch.empty : OnlineEpoch := ⟨0, 0, 0⟩

def OnlineEpoch.scale (st : OnlineEpoch) (j : ℕ) : ℝ :=
  st.anchor * 2 ^ j

def OnlineEpoch.resets (st : OnlineEpoch) (W singleton : ℝ) : Bool :=
  decide (0 < max st.best singleton ∧
    (st.best = 0 ∨ W * st.best < max st.best singleton))

/-- Updating uses only the previous state and the arriving singleton. -/
def OnlineEpoch.step (st : OnlineEpoch) (W : ℝ) (span : ℕ) (singleton : ℝ) : OnlineEpoch :=
  let next := max st.best singleton
  if st.resets W singleton then ⟨next, next, 0⟩
  else ⟨next, st.anchor, st.least + seekDyadic (st.scale st.least) next span⟩

/-- The active guesses are enumerated from a window of at most `span+1`
indices. The anchor and the least exponent are retained across arrivals. -/
def OnlineEpoch.active (st : OnlineEpoch) (W : ℝ) (span : ℕ) : List ℕ :=
  if 0 < st.best then
    ((List.range (span + 1)).map (st.least + ·)).filter
      (fun j => decide (st.scale j ≤ W * st.best))
  else []

/-- The largest singleton is nonnegative, and the stored lower exponent is
the least one whose dyadic scale reaches it. -/
structure OnlineEpoch.Valid (st : OnlineEpoch) : Prop where
  best_nonneg : 0 ≤ st.best
  anchor_le : st.anchor ≤ st.best
  positive : 0 < st.best → 0 < st.anchor
  reaches : st.best ≤ st.scale st.least
  minimal : ∀ j < st.least, st.scale j < st.best

theorem OnlineEpoch.empty_valid : OnlineEpoch.empty.Valid := by
  refine ⟨le_rfl, le_rfl, ?_, ?_, ?_⟩
  · simp [OnlineEpoch.empty]
  · simp [OnlineEpoch.empty, OnlineEpoch.scale]
  · simp [OnlineEpoch.empty]

theorem OnlineEpoch.step_valid (st : OnlineEpoch) (h : st.Valid) (W : ℝ) (span : ℕ)
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ span) (singleton : ℝ) :
    (st.step W span singleton).Valid := by
  let next := max st.best singleton
  have hnext : st.best ≤ next := le_max_left _ _
  have hpos : 0 ≤ next := h.best_nonneg.trans hnext
  unfold OnlineEpoch.step
  change (if st.resets W singleton then ⟨next, next, 0⟩ else
    ⟨next, st.anchor, st.least + seekDyadic (st.scale st.least) next span⟩ : OnlineEpoch).Valid
  by_cases hreset : st.resets W singleton = true
  · rw [if_pos hreset]
    refine ⟨hpos, le_rfl, id, ?_, ?_⟩
    · simp [OnlineEpoch.scale]
    · simp
  · rw [if_neg hreset]
    have hr := hreset
    simp only [OnlineEpoch.resets, decide_eq_true_eq] at hr
    have hupper : next ≤ W * st.best := by
      by_contra! hgt
      exact hr ⟨(mul_nonneg (zero_le_one.trans hW) h.best_nonneg).trans_lt hgt, Or.inr hgt⟩
    have hupper' : next ≤ st.scale st.least * 2 ^ span :=
      hupper.trans ((mul_le_mul hspan h.reaches h.best_nonneg (by positivity)).trans_eq (mul_comm _ _))
    obtain ⟨hlen, hgood, hmin⟩ := seekDyadic_correct _ _ span hupper'
    refine ⟨hpos, h.anchor_le.trans hnext, ?_, ?_, ?_⟩
    · intro ht
      apply h.positive
      refine lt_of_le_of_ne h.best_nonneg ?_
      intro he
      exact hr ⟨ht, Or.inl he.symm⟩
    · simp only [OnlineEpoch.scale] at hgood ⊢
      rw [pow_add, ← mul_assoc]
      exact hgood
    · intro j hj
      change j < st.least + seekDyadic (st.scale st.least) next span at hj
      by_cases hsmall : j < st.least
      · exact (h.minimal j hsmall).trans_le hnext
      · let i := j - st.least
        have hi : j = st.least + i := by dsimp [i]; omega
        have hm := hmin i (by omega)
        change st.anchor * 2 ^ j < next
        rw [hi, pow_add, ← mul_assoc]
        exact hm

/-- The current enumeration contains exactly the intended dyadic guesses. -/
theorem OnlineEpoch.mem_active_iff (st : OnlineEpoch) (h : st.Valid)
    (W : ℝ) (span j : ℕ) (hspan : W ≤ 2 ^ span) :
    j ∈ st.active W span ↔ 0 < st.best ∧ st.best ≤ st.scale j ∧ st.scale j ≤ W * st.best := by
  unfold OnlineEpoch.active
  by_cases hp : 0 < st.best
  · rw [if_pos hp, List.mem_filter, List.mem_map]
    simp only [List.mem_range, decide_eq_true_eq, hp, true_and]
    constructor
    · rintro ⟨⟨u, hu, rfl⟩, htop⟩
      refine ⟨h.reaches.trans ?_, htop⟩
      unfold OnlineEpoch.scale
      exact mul_le_mul_of_nonneg_left
        (pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (by omega)) (h.positive hp).le
    · rintro ⟨hlo, htop⟩
      have hl : st.least ≤ j := by
        by_contra! hj
        exact (h.minimal j hj).not_ge hlo
      have hhi : j ≤ st.least + span := by
        have htop' := calc
          st.scale j ≤ W * st.best := htop
          _ ≤ (2 : ℝ) ^ span * st.best := mul_le_mul_of_nonneg_right hspan hp.le
          _ ≤ (2 : ℝ) ^ span * st.scale st.least :=
            mul_le_mul_of_nonneg_left h.reaches (by positivity)
          _ = st.scale (st.least + span) := by unfold OnlineEpoch.scale; rw [pow_add]; ring
        unfold OnlineEpoch.scale at htop'
        exact (pow_le_pow_iff_right₀ (by norm_num : (1 : ℝ) < 2)).1
          ((mul_le_mul_iff_right₀ (h.positive hp)).1 (by simpa [mul_comm] using htop'))
      refine ⟨⟨j - st.least, by omega, by omega⟩, htop⟩
  · simp [hp]

def runOnlineEpoch (W : ℝ) (span : ℕ) (value : ℕ → ℝ) : ℕ → OnlineEpoch
  | 0 => OnlineEpoch.empty
  | n + 1 => (runOnlineEpoch W span value n).step W span (value n)

theorem runOnlineEpoch_valid (W : ℝ) (span : ℕ) (value : ℕ → ℝ)
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ span) (n : ℕ) :
    (runOnlineEpoch W span value n).Valid := by
  induction n with
  | zero => exact OnlineEpoch.empty_valid
  | succ n ih => exact OnlineEpoch.step_valid _ ih W span hW hspan _

/-- The scalar fields agree with the reference schedule. -/
theorem runOnlineEpoch_real (W : ℝ) (span : ℕ) (value : ℕ → ℝ) (n : ℕ) :
    let st := runOnlineEpoch W span value n
    st.best = singletonMaximum value n ∧ st.anchor = guessAnchor W value n := by
  classical
  dsimp only
  induction n with
  | zero => simp [runOnlineEpoch, OnlineEpoch.empty, singletonMaximum, guessAnchor]
  | succ n ih =>
    let st := runOnlineEpoch W span value n
    have hb : max st.best (value n) = singletonMaximum value (n + 1) := by
      change max (runOnlineEpoch W span value n).best (value n) = _
      rw [ih.1]
      rfl
    have he : st.resets W (value n) = true ↔
        guessReset W (singletonMaximum value n) (singletonMaximum value (n + 1)) := by
      rw [← ih.1, ← hb]
      unfold OnlineEpoch.resets guessReset
      rw [decide_eq_true_eq]
    rw [runOnlineEpoch, OnlineEpoch.step, guessAnchor]
    rw [if_congr he rfl rfl]
    split_ifs
    · exact ⟨hb, hb⟩
    · exact ⟨hb, ih.2⟩

theorem runOnlineEpoch_active_iff (W : ℝ) (span : ℕ) (value : ℕ → ℝ)
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ span) (n j : ℕ) :
    j ∈ (runOnlineEpoch W span value n).active W span ↔
      guessActive W (guessAnchor W value n) (singletonMaximum value n) j := by
  let st := runOnlineEpoch W span value n
  rw [st.mem_active_iff (runOnlineEpoch_valid W span value hW hspan n) W span j hspan]
  obtain ⟨hb, ha⟩ := runOnlineEpoch_real W span value n
  rw [← hb, ← ha]
  rfl

end

end SubmodularMatching.Streaming.RealSource
