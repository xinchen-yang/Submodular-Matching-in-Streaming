import SubmodularMatching.NonmonotoneLayersDecoderWork
import SubmodularMatching.NonmonotoneLayersPhysicalDecoder
import SubmodularMatching.NonmonotoneOptimizerGradientWords

/-! Exact physical decoder cost and rational arithmetic through every bisection
midpoint and every intermediate slot-polynomial accumulator. -/
namespace SubmodularMatching.NonmonotoneLayers
open NonmonotoneOptimizer AppendixM UpperBoundAssembly

def bracketStep (est : ℚ→ℚ) (target : ℚ) (bounds : ℚ×ℚ) : ℚ×ℚ :=
  let mid := (bounds.1+bounds.2)/2
  if est mid ≤ target then (mid,bounds.2) else (bounds.1,mid)

theorem bracket_value (est : ℚ→ℚ) (target l r : ℚ) (j : ℕ) :
    ((bracketStep est target)^[j] (l,r)).1 = ratBisect est target l r j := by
  induction j generalizing l r with
  | zero => rfl
  | succ j ih =>
    rw [Function.iterate_succ_apply,ratBisect]
    dsimp only [bracketStep]; split_ifs <;> apply ih

theorem bracket_width (est : ℚ→ℚ) (target l r : ℚ) (j : ℕ) :
    let b := (bracketStep est target)^[j] (l,r)
    b.2-b.1 = (r-l)/(2:ℚ)^j := by
  induction j generalizing l r with
  | zero => simp
  | succ j ih =>
    simp only [Function.iterate_succ_apply,bracketStep,pow_succ]
    split_ifs <;> rw [ih] <;> ring

theorem bisect_strict_grid (est : ℚ→ℚ) (target l r : ℚ) (k : ℕ) :
    ∃ i : ℕ, i < 2^k ∧ ratBisect est target l r k=l+(r-l)*i/(2:ℚ)^k := by
  induction k generalizing l r with
  | zero => exact ⟨0,by decide,by simp [ratBisect]⟩
  | succ k ih =>
    let mid := (l+r)/2
    by_cases h : est mid ≤ target
    · obtain ⟨i,hi,eq⟩ := ih mid r
      refine ⟨2^k+i,by rw [pow_succ]; omega,?_⟩
      rw [ratBisect,if_pos h,eq]
      simp only [mid,Nat.cast_add,Nat.cast_pow,Nat.cast_ofNat,pow_succ]
      field_simp
      ring
    · obtain ⟨i,hi,eq⟩ := ih l mid
      refine ⟨i,by rw [pow_succ]; omega,?_⟩
      rw [ratBisect,if_neg h,eq]
      simp only [mid,pow_succ]; field_simp; ring

theorem bracket_midpoint (est : ℚ→ℚ) (target r : ℚ) (j : ℕ) :
    let b := (bracketStep est target)^[j] (0,r)
    ∃ i : ℕ,i ≤ 2^(j+1) ∧ (b.1+b.2)/2 = r*i/(2:ℚ)^(j+1) := by
  intro b
  obtain ⟨i,hi,eq⟩ := bisect_strict_grid est target 0 r j
  have left : b.1=r*i/(2:ℚ)^j := by simpa only [bracket_value,sub_zero,zero_add,b] using eq
  have width : b.2-b.1 = r/(2:ℚ)^j := by simpa using bracket_width est target 0 r j
  have right : b.2 = b.1+r/(2:ℚ)^j := by linarith only [width]
  refine ⟨2*i+1,by rw [pow_succ]; omega,?_⟩
  rw [right,left,pow_succ]
  push_cast
  ring

variable {E V : Type*} [DecidableEq V]
theorem decodedCoordinate_work (S : SimpleEdgeStream E V) (b : V→ℕ) (k q : ℕ) (w : E→ℚ) (e : E) :
    let a := b (S.ends e).1
    let c := b (S.ends e).2
    let bits := decoderBits k q
    let steps := decoderSteps k
    countSearch (measuredEstimate a c bits firstRateQ secondRateQ) (w e/(1/layerDegreeQ+w e))
      0 (layerDegreeQ*w e) steps 0 = (decodedCoordinate S b k q w e, steps*(2*min a c)) :=
  decoder_exact_work .. 

theorem physical_midpoint_registers (a b k q T : ℕ) (ha : 0<a) (hb : 0<b) (hT : 0<T)
    (w : ℚ) (z : ℕ) (hz : z≤T) (hw : w=(z:ℚ)/T) (j i : ℕ) (hs : j<decoderSteps k)
    (hi : i≤min a b) :
    let est := estimateUnion a b (decoderBits k q) firstRateQ secondRateQ
    let B := (bracketStep est (w/(1/layerDegreeQ+w)))^[j] (0,layerDegreeQ*w)
    let y := (B.1+B.2)/2
    y.den ≤ layerDegreeQ.den*T*2^(decoderSteps k) ∧
    ∀ θ∈[firstRateQ,secondRateQ],
      let s := y*θ/((a:ℚ)*b)
      let state := slotRun a b (decoderBits k q) s i
      ∃ term total : ℤ, state.term=slotMesh (decoderBits k q)*term ∧
        state.total=slotMesh (decoderBits k q)*total ∧
        |term|≤(2:ℤ)^(decoderBits k q)+min a b ∧
        |total|≤((min a b:ℕ)+1:ℤ)*2^(decoderBits k q)+(min a b:ℕ)^2 := by
  intro est B y
  obtain ⟨n,hn,mid⟩ := bracket_midpoint est (w/(1/layerDegreeQ+w)) (layerDegreeQ*w) j
  change y=layerDegreeQ*w*n/(2:ℚ)^(j+1) at mid
  have hc := decode_parameters
  have dd : 0<layerDegreeQ.den := layerDegreeQ.den_pos
  have hh : y= ((layerDegreeQ.num*z*n:ℤ):ℚ)/((layerDegreeQ.den*T*2^(j+1):ℕ):ℚ) := by
    rw [mid,hw]
    simp only [Int.cast_mul,Int.cast_natCast,Nat.cast_mul,Nat.cast_pow,Nat.cast_ofNat]
    rw [show (layerDegreeQ.num:ℚ)=layerDegreeQ*(layerDegreeQ.den:ℚ) from
      ((eq_div_iff (by positivity)).mp (Rat.num_div_den _).symm).symm]
    field_simp
  constructor
  · rw [hh]
    exact (fraction_den_bound _ _ (by positivity)).trans
      (Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by decide) hs))
  · intro θ hθ s state
    have θ0 : 0≤θ ∧ θ≤1 := by
      simp only [List.mem_cons,List.not_mem_nil,or_false] at hθ
      rcases hθ with rfl | rfl <;> constructor <;> linarith only [hc.1,hc.2.1,hc.2.2.1]
    have wunit : 0≤w ∧ w≤1 := by
      rw [hw]; exact ⟨by positivity,(div_le_one (by positivity)).mpr (by exact_mod_cast hz)⟩
    have yu : 0≤y ∧ y≤1 := by
      rw [mid]
      have nd : (n:ℚ)≤(2:ℚ)^(j+1) := by exact_mod_cast hn
      constructor
      · exact div_nonneg (mul_nonneg (mul_nonneg hc.2.2.2.1.le wunit.1) (Nat.cast_nonneg n)) (by positivity)
      · apply (div_le_one (by positivity)).mpr
        have dw := (mul_le_of_le_one_right hc.2.2.2.1.le wunit.2).trans hc.2.2.2.2.1.le
        exact (mul_le_of_le_one_left (by positivity) dw).trans nd
    have sm : (a:ℝ)*b*|(s:ℝ)|≤1 := by
      have h : (a:ℚ)*b*|s|≤1 := by
        dsimp only [s]
        rw [abs_of_nonneg (div_nonneg (mul_nonneg yu.1 θ0.1) (by positivity))]
        have id : (a:ℚ)*b*(y*θ/((a:ℚ)*b))=y*θ := by field_simp
        rw [id]; exact (mul_le_of_le_one_right yu.1 θ0.2).trans yu.2
      exact_mod_cast h
    obtain ⟨t,o,he,he',ht,ho⟩ := slotRun_word_bounds a b (decoderBits k q) s sm i
    have hj : (i:ℤ)≤(min a b:ℕ) := by exact_mod_cast hi
    refine ⟨t,o,he,he',ht.trans (by gcongr),ho.trans (by gcongr <;> positivity)⟩

end SubmodularMatching.NonmonotoneLayers
