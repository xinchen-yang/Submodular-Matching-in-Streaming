import SubmodularMatching.UpperBoundVertexGibbsWords
import SubmodularMatching.UpperBoundParametricRoundingGrid

/-! # Indexed Gibbs updates at any fixed family precision -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsMatching GibbsSampler Joint NumericalCertificate TwoStage

noncomputable section

variable {m N : ℕ} {V : Type*} [DecidableEq V]

/-- Read the altered coordinate on the chosen family integer mesh. -/
def parametricAlteredIndex (m K : ℕ) (z : ℝ) : ℕ :=
  Int.toNat ⌊(parametricAlteredDenominator m K : ℝ) * z⌋

private theorem parametricAlteredIndex_decodes {m K : ℕ} (hm : 0 < m) (hK : 0 < K) {z : ℝ}
    (hz : 0 ≤ z) (hgrid : LinearPacking.OnGrid (parametricAlteredDenominator m K) z) :
    z = (parametricAlteredIndex m K z : ℝ) / parametricAlteredDenominator m K := by
  have hD : 0 < parametricAlteredDenominator m K :=
    Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (by decide) hm) hK) (by omega)
  have hD' : (0 : ℝ) < parametricAlteredDenominator m K := by exact_mod_cast hD
  obtain ⟨a, ha⟩ := hgrid
  have ha0 : 0 ≤ a := by
    have h : 0 ≤ (a : ℝ) := ha ▸ mul_nonneg hD'.le hz
    exact_mod_cast h
  unfold parametricAlteredIndex
  rw [ha, Int.floor_intCast, ← Int.cast_natCast (R := ℝ), Int.toNat_of_nonneg ha0]
  exact (eq_div_iff hD'.ne').mpr ((mul_comm _ _).trans ha)

/-- The conditional second stage of the actual compact candidate can be
run from its altered integer grid, using the load table and mate array.
The resulting finite law is the one used by the expectation proof. -/
theorem parametricGibbs_gridWalk_eq (hm : 0 < m) (K : ℕ) (hK : 0 < K)
    (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1) (he1 : (1 : ℝ) / K < 1)
    (hcap : p ≤ (1 / (K : ℝ)) ^ 5 / 163840) (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ)
    (draw : AppendixDraw m N) (T : Finset (Fin m)) :
    let ep := restrictEnds ends
    let t := parametricRoundedPoint K p tau ep w f Q draw
    let z := shearerAltered ep t.1 t.2 ((1 / (K : ℝ)) / 4) T
    let D := 4 * Fintype.card (IncidentVertex ends) * K
    gridGibbsWalkLaw (numberedEnds ends) (8 * K - 1) (8 * K) (parametricAlteredDenominator m K)
        (fun e => parametricAlteredIndex m K (z e)) (List.finRange m) D =
      lowActivityGibbsLaw (pairEnds ep) Finset.univ
        (secondActivity ep t.1 t.2 ((1 / (K : ℝ)) / 4)
          ((1 / (K : ℝ)) / 2) T) D := by
  intro ep t z D
  let c := fun e => parametricAlteredIndex m K (z e)
  let d := parametricAlteredDenominator m K
  let S := (Finset.univ : Finset (Fin m))
  let A := pairEnds (numberedEnds ends)
  have hlo : ∀ e, (ep e).1 ≠ (ep e).2 := restrictEnds_loopless ends hloop
  have hsi : Function.Injective (pairEnds ep) := (restrictEnds_pairEnds_injective_iff ends).mpr hsimple
  have hxy : Feasible p NumericalCertificate.degree ep ep t.1 t.2 :=
    parametricRoundedPoint_feasible hm K hK p tau hp hp1 ep hlo w f Q draw
  have he : (0 : ℝ) < 1 / K := by positivity
  have hgap := (explicit_two_stage_side_conditions p NumericalCertificate.degree (1 / (K : ℝ)) hp
    degree_bounds.1.le degree_bounds.2.le he he1 hcap).2.2.1
  have hz := shearer_alteration_correct ep hlo hsi p NumericalCertificate.degree
    sampler ((1 / (K : ℝ)) / 4) hp
    ((by norm_num : (0 : ℝ) < 1 / 2).trans sampler_bounds.1) sampler_bounds.2.le rfl
    hgap t.1 t.2 hxy
  have hgr (e : Fin m) : LinearPacking.OnGrid d (z e) :=
    parametricShearerAltered_onGrid K hK ep t.1 t.2
      (fun e => (parametricRoundedPoint_xy_grids hm K hK p tau hp hp1 ep hlo w f Q draw e).2.2) T e
  have hdecode : (fun e => (c e : ℝ) / d) = z := by
    funext e
    exact (parametricAlteredIndex_decodes hm hK (hz.1 T e).1 (hgr e)).symm
  have hd : 0 < d := Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (by decide) hm) hK) (by omega)
  have hd' : (0 : ℝ) < d := by exact_mod_cast hd
  have hLoad (v : Fin (incidentVertexList ends).length) : gridLoadNumerator A S c v ≤ d := by
    have hEq : (gridLoadNumerator A S c v : ℝ) / d = vertexLoad A S z v := by
      unfold gridLoadNumerator vertexLoad
      rw [Nat.cast_sum, Finset.sum_div]
      exact Finset.sum_congr rfl (fun e _ => congrFun hdecode e)
    have hdeg : vertexLoad A S z v ≤ 1 := by
      let u := (incidentVertexNumbering ends).symm v
      have h := (numberedIncident ends S u)
      rw [(incidentVertexNumbering ends).apply_symm_apply] at h
      unfold vertexLoad
      rw [h]
      exact (vertexDegree_pairEnds ep z u).le.trans (hz.2.1 T u)
    exact_mod_cast (div_le_one hd').mp (hEq.le.trans hdeg)
  have hList : (List.finRange m).toFinset = S := by ext e; simp [S]
  have hγ : ((8 * K - 1 : ℕ) : ℝ) / ((8 * K : ℕ) : ℝ) =
      1 - ((1 / (K : ℝ)) / 2) / 4 := by
    have h₁ : 1 ≤ 8 * K := by omega
    have hK' : (K : ℝ) ≠ 0 := by exact_mod_cast hK.ne'
    rw [Nat.cast_sub h₁]
    push_cast
    field_simp [hK']
    <;> ring
  have hlaw := gridGibbsWalkLaw_eq A (numberedEnds ends) (fun _ => rfl) S
    (8 * K - 1) (8 * K) d (by omega) hd c (List.finRange m) hList (List.nodup_finRange m)
    (fun e _ => numberedEnds_loopless ends hloop e) hLoad D
  rw [hdecode, hγ, numberedCalibratedActivity ends,
    numberedLowActivityLaw ends] at hlaw
  exact hlaw


end

end SubmodularMatching.UpperBoundAssembly
