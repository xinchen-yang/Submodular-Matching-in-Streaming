import SubmodularMatching.ProjectedShearerTimeReject

/-! Compute the bounded-rejection word length using small limbs. -/
namespace SubmodularMatching.Shearer
open ShearerSampler

def oneBitLimbs (width j : ℕ) := List.replicate (j/width) 0 ++ [2^(j%width)]

private theorem zero_prefix (B l : ℕ) (ds : List ℕ) :
    limbValue B (List.replicate l 0 ++ ds) = B^l * limbValue B ds := by
  induction l with
  | zero => simp
  | succ l ih => simp [List.replicate_succ,limbValue,ih,pow_succ',Nat.mul_assoc]

theorem oneBitLimbs_value (width j : ℕ) : limbValue (2^width) (oneBitLimbs width j) = 2^j := by
  unfold oneBitLimbs
  rw [zero_prefix]
  simp only [limbValue,Nat.mul_zero,Nat.add_zero,←Nat.pow_mul,←Nat.pow_add]
  rw [Nat.mul_comm width (j / width), Nat.div_add_mod' j width]

theorem oneBitLimbs_bounds {width j r : ℕ} (hc : 0<width) (hj : j≤r*width) :
    (oneBitLimbs width j).length ≤ r+1 ∧ ∀ x∈oneBitLimbs width j,x<2^width := by
  constructor
  · simp only [oneBitLimbs,List.length_append,List.length_replicate,List.length_singleton,Nat.add_le_add_iff_right]
    exact (Nat.div_le_div_right hj).trans_eq (Nat.mul_div_cancel _ hc)
  · intro x hx
    simp only [oneBitLimbs,List.mem_append,List.mem_replicate,List.mem_singleton] at hx
    rcases hx with ⟨_,rfl⟩|rfl
    · positivity
    · exact Nat.pow_lt_pow_right (by decide : 1<2) (Nat.mod_lt _ hc)

/-- Checking whether a power of two is large enough for a k^r-cell grid
uses the same bounded word-array division as actual rejection. -/
def searchTimeWidth (width k r start : ℕ) : ℕ → ℕ×ℕ
  | 0 => (start,0)
  | n+1 => if (limbAttempt (2^width) k r (oneBitLimbs width start) []).isNone then (start,1) else
    let next := searchTimeWidth width k r (start+1) n
    (next.1,next.2+1)

theorem searchTimeWidth_spec (width k r start n : ℕ) (hc : 0<width) (hk : 0<k) (hk' : k≤2^width)
    (hl : start ≤ Nat.clog 2 (k^r)) (hu : Nat.clog 2 (k^r) ≤ start+n) :
    (searchTimeWidth width k r start n).1=Nat.clog 2 (k^r) ∧
    (searchTimeWidth width k r start n).2≤n := by
  induction n generalizing start with
  | zero => simp [searchTimeWidth]; omega
  | succ n ih =>
    let q := Nat.clog 2 (k^r)
    have hmax : q≤r*width := (Nat.clog_le_iff_le_pow (by decide : 1<2)).2 (by
      rw [Nat.mul_comm r,Nat.pow_mul]; exact Nat.pow_le_pow_left hk' _)
    have bound := (oneBitLimbs_bounds hc (hl.trans hmax)).2
    have a := limbAttempt_spec (B:=2^width) (by positivity) hk r (oneBitLimbs width start) [] bound
    rw [oneBitLimbs_value] at a
    by_cases enough : k^r≤2^start
    · have g := (Nat.clog_le_iff_le_pow (by decide : 1<2)).2 enough
      simp [searchTimeWidth,a,not_lt.mpr enough]
      omega
    · have small := Nat.lt_of_not_ge enough
      have inc : start+1≤q := by
        by_contra! h
        exact enough ((Nat.clog_le_iff_le_pow (by decide : 1<2)).1 (show q≤start by omega))
      have tail := ih (start+1) inc (by omega)
      simpa only [searchTimeWidth,a,if_pos small,Option.isNone_some,Bool.false_eq_true,if_false,
        Nat.add_le_add_iff_right] using tail

/-- The exact width used in timeWordDraw can be found by a sequential
search of at most r*width candidates. A quotient sweep never needs an
operand wider than r+1 limbs, even at the endpoint 2^(r*width). -/
theorem actual_time_width {E : Type*} [LinearOrder E] (M : Finset E) (k : ℕ) (hk : 0<k) :
    let width := max 1 (Nat.clog 2 k)
    let out := searchTimeWidth width k M.card 0 (M.card*width)
    out.1=(timeGrid M k hk).bits ∧ out.2≤M.card*width := by
  intro width out
  have hc : 0<width := (by apply Nat.lt_of_lt_of_le (by decide : 0<1); exact le_max_left _ _)
  have hb : k≤2^width := (Nat.le_pow_clog (by decide : 1<2) k).trans (Nat.pow_le_pow_right (by decide) (le_max_right _ _))
  exact searchTimeWidth_spec width k M.card 0 _ hc hk hb (Nat.zero_le _) (by
    rw [Nat.zero_add]
    exact (time_word_width M k hk).trans (Nat.mul_le_mul_left _ (le_max_right _ _)))

end SubmodularMatching.Shearer
