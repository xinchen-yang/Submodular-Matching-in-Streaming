import SubmodularMatching.IndependentSampling
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Tactic.Positivity

/-!
# Derivatives of the actual finite independent-sampling expectation

These derivatives are computed from the finite Bernoulli recursion. The bounds
use the range of the original set-function marginals, rather than smoothness
assumptions about an otherwise unspecified objective.
-/

open scoped BigOperators

namespace SubmodularMatching.Multilinear

noncomputable section

variable {E : Type*} [DecidableEq E]

def along (q d : ℕ → ℝ) (t : ℝ) (i : ℕ) : ℝ := q i + t * d i

@[simp] theorem along_zero (q d : ℕ → ℝ) : along q d 0 = q := by
  funext i
  simp [along]

def first (edges : ℕ → E) (q d : ℕ → ℝ) (F : Finset E → ℝ) : ℕ → ℝ
  | 0 => 0
  | n + 1 =>
    (1 - q n) * first edges q d F n +
      q n * first edges q d (fun A => F (A ∪ {edges n})) n +
      d n * (bernoulliExpectation edges q (fun A => F (A ∪ {edges n})) n -
        bernoulliExpectation edges q F n)

def second (edges : ℕ → E) (q d : ℕ → ℝ) (F : Finset E → ℝ) : ℕ → ℝ
  | 0 => 0
  | n + 1 =>
    (1 - q n) * second edges q d F n +
      q n * second edges q d (fun A => F (A ∪ {edges n})) n +
      2 * d n * (first edges q d (fun A => F (A ∪ {edges n})) n -
        first edges q d F n)

theorem along_hasDerivAt (q d : ℕ → ℝ) (t : ℝ) (i : ℕ) :
    HasDerivAt (fun s => along q d s i) (d i) t := by
  simpa only [along, Pi.add_apply, zero_add, one_mul] using
    (hasDerivAt_const t (q i)).add ((hasDerivAt_id t).mul_const (d i))

theorem expectation_hasDerivAt (edges : ℕ → E) (q d : ℕ → ℝ)
    (F : Finset E → ℝ) (n : ℕ) (t : ℝ) :
    HasDerivAt (fun s => bernoulliExpectation edges (along q d s) F n)
      (first edges (along q d t) d F n) t := by
  induction n generalizing F with
  | zero => exact hasDerivAt_const t (F ∅)
  | succ n ih =>
    have hq := along_hasDerivAt q d t n
    have h := (((hasDerivAt_const t 1).sub hq).mul (ih F)).add
      (hq.mul (ih (fun A => F (A ∪ {edges n}))))
    convert h using 1
    simp only [first, Pi.sub_apply]
    ring

theorem first_hasDerivAt (edges : ℕ → E) (q d : ℕ → ℝ)
    (F : Finset E → ℝ) (n : ℕ) (t : ℝ) :
    HasDerivAt (fun s => first edges (along q d s) d F n)
      (second edges (along q d t) d F n) t := by
  induction n generalizing F with
  | zero => exact hasDerivAt_const t 0
  | succ n ih =>
    have hq := along_hasDerivAt q d t n
    have h := ((((hasDerivAt_const t 1).sub hq).mul (ih F)).add
      (hq.mul (ih (fun A => F (A ∪ {edges n}))))).add
      (((expectation_hasDerivAt edges q d (fun A => F (A ∪ {edges n})) n t).sub
        (expectation_hasDerivAt edges q d F n t)).const_mul (d n))
    convert h using 1
    simp only [second, Pi.sub_apply]
    ring

theorem first_sub (edges : ℕ → E) (q d : ℕ → ℝ)
    (F H : Finset E → ℝ) (n : ℕ) :
    first edges q d (fun A => F A - H A) n = first edges q d F n - first edges q d H n := by
  induction n generalizing F H with
  | zero => simp [first]
  | succ n ih => simp only [first, ih, bernoulliExpectation_sub]; ring

theorem expectation_bounds (edges : ℕ → E) (q : ℕ → ℝ) (F : Finset E → ℝ)
    (n : ℕ) {tau : ℝ} (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1)
    (hF : ∀ A, 0 ≤ F A ∧ F A ≤ tau) :
    0 ≤ bernoulliExpectation edges q F n ∧ bernoulliExpectation edges q F n ≤ tau := by
  constructor
  · exact bernoulliExpectation_nonnegative edges q F n hq (fun A => (hF A).1)
  · simpa only [bernoulliExpectation_const] using
      bernoulliExpectation_mono edges q F (fun _ => tau) n hq (fun A => (hF A).2)

/-- Every bounded set function has this directional derivative bound. -/
theorem first_bounds (edges : ℕ → E) (q d : ℕ → ℝ) (F : Finset E → ℝ)
    (n : ℕ) {tau : ℝ} (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1)
    (hd : ∀ i < n, 0 ≤ d i) (hF : ∀ A, 0 ≤ F A ∧ F A ≤ tau) :
    -(tau * ∑ i ∈ Finset.range n, d i) ≤ first edges q d F n ∧
      first edges q d F n ≤ tau * ∑ i ∈ Finset.range n, d i := by
  induction n generalizing F with
  | zero => simp [first]
  | succ n ih =>
    have hq' : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1 := fun i hi => hq i (Nat.lt_succ_of_lt hi)
    have hd' : ∀ i < n, 0 ≤ d i := fun i hi => hd i (Nat.lt_succ_of_lt hi)
    have hn := hq n (Nat.lt_succ_self n)
    have hdn := hd n (Nat.lt_succ_self n)
    have hf := ih F hq' hd' hF
    have hg := ih (fun A => F (A ∪ {edges n})) hq' hd' (fun A => hF _)
    have hvf := expectation_bounds edges q F n hq' hF
    have hvg := expectation_bounds edges q (fun A => F (A ∪ {edges n})) n hq' (fun A => hF _)
    have hl0 := mul_le_mul_of_nonneg_left hf.1 (sub_nonneg.mpr hn.2)
    have hl1 := mul_le_mul_of_nonneg_left hg.1 hn.1
    have hu0 := mul_le_mul_of_nonneg_left hf.2 (sub_nonneg.mpr hn.2)
    have hu1 := mul_le_mul_of_nonneg_left hg.2 hn.1
    have hlo : -tau ≤ bernoulliExpectation edges q (fun A => F (A ∪ {edges n})) n -
        bernoulliExpectation edges q F n := by linarith
    have hhi : bernoulliExpectation edges q (fun A => F (A ∪ {edges n})) n -
        bernoulliExpectation edges q F n ≤ tau := by linarith
    have hml := mul_le_mul_of_nonneg_left hlo hdn
    have hmu := mul_le_mul_of_nonneg_left hhi hdn
    rw [first, Finset.sum_range_succ]
    constructor <;> nlinarith [hl0, hl1, hu0, hu1, hml, hmu]

theorem marginal_shift (F : Finset E → ℝ) (e a : E) (A : Finset E) :
    marginal (fun B => F (B ∪ {a})) e A = marginal F e (A ∪ {a}) := by
  simp only [marginal, Finset.union_left_comm, Finset.union_comm]

/-- The directional second derivative of the actual multilinear extension has
the curvature bound used by the Euler construction. -/
theorem second_lower_bound (edges : ℕ → E) (q d : ℕ → ℝ) (F : Finset E → ℝ)
    (n : ℕ) {tau : ℝ} (htau : 0 ≤ tau)
    (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1) (hd : ∀ i < n, 0 ≤ d i)
    (hmarg : ∀ e A, 0 ≤ marginal F e A ∧ marginal F e A ≤ tau) :
    -tau * (∑ i ∈ Finset.range n, d i) ^ 2 ≤ second edges q d F n := by
  induction n generalizing F with
  | zero => simp [second]
  | succ n ih =>
    have hq' : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1 := fun i hi => hq i (Nat.lt_succ_of_lt hi)
    have hd' : ∀ i < n, 0 ≤ d i := fun i hi => hd i (Nat.lt_succ_of_lt hi)
    have hn := hq n (Nat.lt_succ_self n)
    have hdn := hd n (Nat.lt_succ_self n)
    have hf := ih F hq' hd' hmarg
    have hg := ih (fun A => F (A ∪ {edges n})) hq' hd'
      (fun e A => by simpa only [marginal_shift] using hmarg e (A ∪ {edges n}))
    have hdifference := (first_bounds edges q d (fun A => marginal F (edges n) A) n
      hq' hd' (hmarg (edges n))).1
    simp only [marginal, first_sub] at hdifference
    have hl0 := mul_le_mul_of_nonneg_left hf (sub_nonneg.mpr hn.2)
    have hl1 := mul_le_mul_of_nonneg_left hg hn.1
    have hl2 := mul_le_mul_of_nonneg_left hdifference (by positivity : 0 ≤ 2 * d n)
    have hsquare := mul_nonneg htau (sq_nonneg (d n))
    rw [second, Finset.sum_range_succ]
    nlinarith [hl0, hl1, hl2, hsquare]

theorem monotoneOn_of_explicit_derivative (P Q : ℝ → ℝ) (h : ℝ)
    (hder : ∀ t ∈ Set.Icc 0 h, HasDerivAt P (Q t) t)
    (hpos : ∀ t ∈ Set.Icc 0 h, 0 ≤ Q t) : MonotoneOn P (Set.Icc 0 h) := by
  apply monotoneOn_of_hasDerivWithinAt_nonneg (convex_Icc (𝕜 := ℝ) 0 h)
    (fun t ht => (hder t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hder t (interior_subset ht)).hasDerivWithinAt)
    (fun t ht => hpos t (interior_subset ht))

/-- A scalar Taylor lower bound proved by two derivative monotonicity arguments. -/
theorem taylor_lower (P Q S : ℝ → ℝ) (h C : ℝ) (hh : 0 ≤ h)
    (hP : ∀ t ∈ Set.Icc 0 h, HasDerivAt P (Q t) t)
    (hQ : ∀ t ∈ Set.Icc 0 h, HasDerivAt Q (S t) t)
    (hS : ∀ t ∈ Set.Icc 0 h, -C ≤ S t) :
    P 0 + h * Q 0 - C * h ^ 2 / 2 ≤ P h := by
  have hRder : ∀ t ∈ Set.Icc 0 h,
      HasDerivAt (fun s => Q s + C * s) (S t + C) t := by
    intro t ht
    simpa only [Pi.add_apply, mul_one] using (hQ t ht).add ((hasDerivAt_id t).const_mul C)
  have hRmono := monotoneOn_of_explicit_derivative (fun s => Q s + C * s)
    (fun s => S s + C) h hRder (by intro t ht; linarith [hS t ht])
  have hQbound : ∀ t ∈ Set.Icc 0 h, Q 0 - C * t ≤ Q t := by
    intro t ht
    have hm := hRmono ⟨le_rfl, hh⟩ ht ht.1
    dsimp at hm
    linarith
  have hZder : ∀ t ∈ Set.Icc 0 h,
      HasDerivAt (fun s => P s - Q 0 * s + (C / 2) * (s * s))
        (Q t - Q 0 + C * t) t := by
    intro t ht
    have hd := ((hP t ht).sub ((hasDerivAt_id t).const_mul (Q 0))).add
      (((hasDerivAt_id t).mul (hasDerivAt_id t)).const_mul (C / 2))
    convert hd using 1
    simp only [id_eq, mul_one, one_mul]
    ring
  have hZmono := monotoneOn_of_explicit_derivative
    (fun s => P s - Q 0 * s + (C / 2) * (s * s))
    (fun s => Q s - Q 0 + C * s) h hZder (by intro t ht; linarith [hQbound t ht])
  have hz := hZmono ⟨le_rfl, hh⟩ ⟨hh, le_rfl⟩ hh
  dsimp at hz
  nlinarith

/-- The Euler-step Taylor inequality for the actual multilinear extension,
with curvature derived from bounded set-function marginal values. -/
theorem expectation_taylor_lower (edges : ℕ → E) (q d : ℕ → ℝ)
    (F : Finset E → ℝ) (n : ℕ) (h tau : ℝ) (hh : 0 ≤ h) (htau : 0 ≤ tau)
    (hq : ∀ i < n, 0 ≤ q i) (hend : ∀ i < n, along q d h i ≤ 1)
    (hd : ∀ i < n, 0 ≤ d i)
    (hmarg : ∀ e A, 0 ≤ marginal F e A ∧ marginal F e A ≤ tau) :
    bernoulliExpectation edges q F n + h * first edges q d F n -
        tau * (∑ i ∈ Finset.range n, d i) ^ 2 * h ^ 2 / 2 ≤
      bernoulliExpectation edges (along q d h) F n := by
  have hpath : ∀ t ∈ Set.Icc 0 h, ∀ i < n, 0 ≤ along q d t i ∧ along q d t i ≤ 1 := by
    intro t ht i hi
    have hp := mul_nonneg ht.1 (hd i hi)
    have hm := mul_le_mul_of_nonneg_right ht.2 (hd i hi)
    have hb := hend i hi
    dsimp [along] at hb ⊢
    constructor <;> linarith [hq i hi]
  have ht := taylor_lower
    (fun t => bernoulliExpectation edges (along q d t) F n)
    (fun t => first edges (along q d t) d F n)
    (fun t => second edges (along q d t) d F n)
    h (tau * (∑ i ∈ Finset.range n, d i) ^ 2) hh
    (fun t _ => expectation_hasDerivAt edges q d F n t)
    (fun t _ => first_hasDerivAt edges q d F n t)
    (fun t ht => by simpa only [neg_mul] using
      second_lower_bound edges (along q d t) d F n htau (hpath t ht) hd hmarg)
  simpa only [along_zero] using ht

end

end SubmodularMatching.Multilinear
