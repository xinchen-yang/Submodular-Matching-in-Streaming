import SubmodularMatching.IndependentSampling

/-!
# Monotonicity and ray scaling of finite Bernoulli expectation

Ray concavity from the origin follows directly by telescoping expected
marginals: thinning decreases every preceding prefix and hence increases
the next expected marginal of a submodular function.
-/

namespace SubmodularMatching

open scoped BigOperators

variable {E : Type*} [DecidableEq E]

theorem bernoulliExpectation_monotone_probabilities
    (edges : ℕ → E) (q r : ℕ → ℝ) (F : Finset E → ℝ) (n : ℕ)
    (hqr : ∀ i < n, 0 ≤ q i ∧ q i ≤ r i ∧ r i ≤ 1)
    (hF : IsMonotone F) :
    bernoulliExpectation edges q F n ≤ bernoulliExpectation edges r F n := by
  induction n generalizing F with
  | zero => exact le_rfl
  | succ n ih =>
    have hqr' : ∀ i < n, 0 ≤ q i ∧ q i ≤ r i ∧ r i ≤ 1 :=
      fun i hi => hqr i (Nat.lt_succ_of_lt hi)
    have hn := hqr n (Nat.lt_succ_self n)
    have hr : ∀ i < n, 0 ≤ r i ∧ r i ≤ 1 :=
      fun i hi => ⟨(hqr' i hi).1.trans (hqr' i hi).2.1, (hqr' i hi).2.2⟩
    have hshift : IsMonotone (fun A => F (A ∪ {edges n})) := by
      intro A B hAB
      exact hF _ _ (Finset.union_subset_union hAB (Finset.Subset.refl _))
    have hleft := ih F hqr' hF
    have hright := ih (fun A => F (A ∪ {edges n})) hqr' hshift
    have hinc : bernoulliExpectation edges r F n ≤
        bernoulliExpectation edges r (fun A => F (A ∪ {edges n})) n := by
      apply bernoulliExpectation_mono edges r _ _ n hr
      intro A
      exact hF _ _ Finset.subset_union_left
    have hqone : 0 ≤ 1 - q n := sub_nonneg.mpr (hn.2.1.trans hn.2.2)
    have h1 := mul_le_mul_of_nonneg_left hleft hqone
    have h2 := mul_le_mul_of_nonneg_left hright hn.1
    have h3 := mul_nonneg (sub_nonneg.mpr hn.2.1) (sub_nonneg.mpr hinc)
    simp only [bernoulliExpectation_succ]
    nlinarith

/-- Along any nonnegative ray from the origin, independent expectation of
a normalized monotone submodular objective lies above its endpoint chord. -/
theorem bernoulliExpectation_scale_lower_bound
    (edges : ℕ → E) (q : ℕ → ℝ) (f : Finset E → ℝ) (n : ℕ)
    (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1)
    (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0)
    (t : ℝ) (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    t * bernoulliExpectation edges q f n ≤
      bernoulliExpectation edges (fun i => t * q i) f n := by
  rw [bernoulliExpectation_telescoping edges q f n,
    bernoulliExpectation_telescoping edges (fun i => t * q i) f n,
    hzero, zero_add, zero_add, Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i hi
  have hin := Finset.mem_range.mp hi
  have hprefix : ∀ j < i, 0 ≤ t * q j ∧ t * q j ≤ q j ∧ q j ≤ 1 := by
    intro j hji
    have hj := hq j (Nat.lt_trans hji hin)
    exact ⟨mul_nonneg ht0 hj.1, by nlinarith only [mul_nonneg hj.1 (sub_nonneg.mpr ht1)], hj.2⟩
  have hcmp := bernoulliExpectation_antitone_probabilities edges (fun j => t * q j) q
    (fun A => marginal f (edges i) A) i hprefix
    (fun A B hAB => marginal_antitone f hf hm A B (edges i) hAB)
  have hscaled := mul_le_mul_of_nonneg_left hcmp (mul_nonneg ht0 (hq i hin).1)
  simpa only [mul_assoc] using hscaled

/-- Coordinatewise lower bounds on a second probability vector transfer
the ray-scaling guarantee to that vector. -/
theorem bernoulliExpectation_scaled_coordinate_lower_bound
    (edges : ℕ → E) (q r : ℕ → ℝ) (f : Finset E → ℝ) (n : ℕ)
    (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1)
    (hr : ∀ i < n, r i ≤ 1)
    (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0)
    (t : ℝ) (ht0 : 0 ≤ t) (ht1 : t ≤ 1)
    (hcoord : ∀ i < n, t * q i ≤ r i) :
    t * bernoulliExpectation edges q f n ≤ bernoulliExpectation edges r f n := by
  exact (bernoulliExpectation_scale_lower_bound edges q f n hq hf hm hzero t ht0 ht1).trans
    (bernoulliExpectation_monotone_probabilities edges (fun i => t * q i) r f n
      (fun i hi => ⟨mul_nonneg ht0 (hq i hi).1, hcoord i hi, hr i hi⟩) hm)

end SubmodularMatching
