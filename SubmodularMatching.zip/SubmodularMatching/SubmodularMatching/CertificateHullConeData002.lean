import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull002_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 265, 283, 4, 0x11b23446488109⟩ (by decide +kernel)

private def hull002_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 61, 70, 9, 0x2304508810c210410800fc1f03d⟩ (by decide +kernel)

private def hull002_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 567, 119, 0x46e1fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull002_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 274, 276, 1, 0x8a112⟩ (by decide +kernel)

private def hull002_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 274, 275, 1, 0x89912⟩ (by decide +kernel)

private def hull002_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 275, 276, 1, 0x8a113⟩ (by decide +kernel)

private def hull002_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 141, 212, 52, 0xd41a4344680cf19c330658ca18e314618c21802fc5e8bc1742dc5b0b51682cc590b11602b8560aa1522a0530a51462885009f13a2704d89913025c4b09512824c4909112023c4708d⟩ (by decide +kernel)

private def hull002_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 265, 274, 3, 0x22444488109⟩ (by decide +kernel)

private def hull002_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 247, 283, 4, 0x11b234464880f7⟩ (by decide +kernel)

private def hull002_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 52, 70, 18, 0x118228440861082084007e0f81e83c0760e81c83806e0d81a834⟩ (by decide +kernel)

private def hull002_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 265, 269, 1, 0x86909⟩ (by decide +kernel)

private def hull002_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 269, 274, 3, 0x2244448810d⟩ (by decide +kernel)

private def hull002_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 269, 271, 2, 0x43c8710d⟩ (by decide +kernel)

private def hull002_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 271, 274, 3, 0x2244448810f⟩ (by decide +kernel)

private def hull002_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 52, 56, 4, 0x3806e0d81a834⟩ (by decide +kernel)

private def hull002_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 56, 61, 5, 0x1e83c0760e81c838⟩ (by decide +kernel)

private def hull002_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 56, 58, 2, 0xe81c838⟩ (by decide +kernel)

private def hull002_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 58, 61, 3, 0x7a0f01d83a⟩ (by decide +kernel)

private def hull002_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 52, 61, 9, 0x1e83c0760e81c83806e0d81a834⟩ (by decide +kernel)

private def hull002_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 265, 267, 2, 0x42c85109⟩ (by decide +kernel)

private def hull002_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 267, 269, 1, 0x8690b⟩ (by decide +kernel)

private def hull002_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 267, 268, 1, 0x8610b⟩ (by decide +kernel)

private def hull002_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 268, 269, 1, 0x8690c⟩ (by decide +kernel)

private def hull002_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 247, 265, 3, 0x212420838f7⟩ (by decide +kernel)

private def hull002_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 247, 256, 2, 0x4007e0f7⟩ (by decide +kernel)

private def hull002_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 256, 265, 3, 0x21242083900⟩ (by decide +kernel)

private def hull002_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 256, 260, 4, 0x10420640880900⟩ (by decide +kernel)

private def hull002_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 260, 265, 3, 0x21242083904⟩ (by decide +kernel)

private def hull002_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 260, 262, 2, 0x41882904⟩ (by decide +kernel)

private def hull002_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 262, 265, 3, 0x21242083906⟩ (by decide +kernel)

private def hull002_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 70, 35, 0x8c114220430841042003f07c0f41e03b0740e41c03706c0d41a0330640c41802f05c0b41602b0540a41402704c09412023⟩ (by decide +kernel)

private def hull002_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 212, 283, 1, 0x8d8d4⟩ (by decide +kernel)

private def hull002_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 247, 251, 2, 0x3ec7d0f7⟩ (by decide +kernel)

private def hull002_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 251, 256, 2, 0x4007e0fb⟩ (by decide +kernel)

private def hull002_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 43, 8, 0x2b0540a41402704c09412023⟩ (by decide +kernel)

private def hull002_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 251, 253, 2, 0x3f47e0fb⟩ (by decide +kernel)

private def hull002_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 43, 52, 9, 0x1a0330640c41802f05c0b41602b⟩ (by decide +kernel)

private def hull002_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 253, 256, 1, 0x800fd⟩ (by decide +kernel)

private def hull002_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 253, 254, 1, 0x7f0fd⟩ (by decide +kernel)

private def hull002_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 254, 256, 1, 0x800fe⟩ (by decide +kernel)

private def hull002_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 254, 255, 1, 0x7f8fe⟩ (by decide +kernel)

private def hull002_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 255, 256, 1, 0x800ff⟩ (by decide +kernel)

private def hull002_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 43, 47, 4, 0x2f05c0b41602b⟩ (by decide +kernel)

private def hull002_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 47, 52, 5, 0x1a0330640c41802f⟩ (by decide +kernel)

private def hull002_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 52, 17, 0x1a0330640c41802f05c0b41602b0540a41402704c09412023⟩ (by decide +kernel)

private def supportedCone0256 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨265, 283, 272, 265, 281⟩, ⟨12541327706, 10661000385, 11035550394, 9382182267, 1061360807809, 570444056821⟩⟩
    hull002_000 1 (by decide +kernel)

private def supportedCone0257 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨61, 70, 65, 64, 66⟩, ⟨1000000000, 115603912, 530387237, 62004387, 296000000000, 3597201587⟩⟩
    hull002_001 4 (by decide +kernel)

private def supportedCone0258 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 66, 65, 67⟩, ⟨530387237, 62004387, 1435880651, 168084187, 296530387237, 3659205974⟩⟩
    hull002_002 57 (by decide +kernel)

private def supportedCone0259 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨61, 70, 66, 65, 67⟩, ⟨530387237, 62004387, 1435880651, 168084187, 296530387237, 3659205974⟩⟩
    hull002_001 5 (by decide +kernel)

private def supportedCone0260 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 65, 64, 66⟩, ⟨1000000000, 115603912, 530387237, 62004387, 296000000000, 3597201587⟩⟩
    hull002_002 56 (by decide +kernel)

private def supportedCone0261 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨274, 276, 274, 274, 276⟩, ⟨0, 0, 2258965206, 1920926778, 1063882586526, 572588465916⟩⟩
    hull002_003 0 (by decide +kernel)

private def supportedCone0262 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨274, 275, 274, 274, 275⟩, ⟨0, 0, 1117413474, 950223455, 1063882586526, 572588465916⟩⟩
    hull002_004 0 (by decide +kernel)

private def supportedCone0263 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨275, 276, 275, 275, 276⟩, ⟨0, 0, 1141551732, 970703323, 1065000000000, 573538689371⟩⟩
    hull002_005 0 (by decide +kernel)

private def supportedCone0264 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨141, 212, 181, 180, 182⟩, ⟨5000000000, 4251886373, 5000000000, 4251886658, 680000000000, 246147417144⟩⟩
    hull002_006 32 (by decide +kernel)

private def supportedCone0265 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 39, 38, 40⟩, ⟨1225499220, 67598571, 912885189, 53518492, 265000000000, 910048585⟩⟩
    hull002_002 30 (by decide +kernel)

private def supportedCone0266 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 60, 59, 61⟩, ⟨1135985046, 115441792, 1317712249, 141660608, 290000000000, 2937838851⟩⟩
    hull002_002 51 (by decide +kernel)

private def supportedCone0267 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 58, 57, 59⟩, ⟨1502580336, 149488808, 1644287278, 166844631, 287219727676, 2655552428⟩⟩
    hull002_002 49 (by decide +kernel)

private def supportedCone0268 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 52, 51, 53⟩, ⟨2329787335, 195916729, 501910433, 43066537, 279498089567, 1941795930⟩⟩
    hull002_002 43 (by decide +kernel)

private def supportedCone0269 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨265, 274, 272, 265, 273⟩, ⟨12541327706, 10661000385, 1258818232, 1070420649, 1061360807809, 570444056821⟩⟩
    hull002_007 1 (by decide +kernel)

private def supportedCone0270 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 283, 247, 247, 272⟩, ⟨0, 0, 34967666629, 29728344576, 1026393141180, 540715712245⟩⟩
    hull002_008 0 (by decide +kernel)

private def supportedCone0271 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 63, 62, 64⟩, ⟨489108223, 53454047, 1700024979, 186483787, 293299975021, 3295113888⟩⟩
    hull002_002 54 (by decide +kernel)

private def supportedCone0272 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 70, 63, 62, 64⟩, ⟨489108223, 53454047, 1700024979, 186483787, 293299975021, 3295113888⟩⟩
    hull002_009 11 (by decide +kernel)

private def supportedCone0273 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨265, 269, 269, 265, 269⟩, ⟨4852771297, 4125512704, 0, 0, 1053672251400, 563908569140⟩⟩
    hull002_010 1 (by decide +kernel)

private def supportedCone0274 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨269, 274, 272, 269, 273⟩, ⟨7688556409, 6535487681, 1258818232, 1070420649, 1061360807809, 570444056821⟩⟩
    hull002_011 1 (by decide +kernel)

private def supportedCone0275 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 70, 52, 52, 53⟩, ⟨0, 0, 501910433, 43066537, 279498089567, 1941795930⟩⟩
    hull002_009 0 (by decide +kernel)

private def supportedCone0276 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 70, 62, 61, 63⟩, ⟨1493154549, 162160382, 489108223, 53454047, 292810866798, 3241659841⟩⟩
    hull002_009 10 (by decide +kernel)

private def supportedCone0277 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 62, 61, 63⟩, ⟨1493154549, 162160382, 489108223, 53454047, 292810866798, 3241659841⟩⟩
    hull002_002 53 (by decide +kernel)

private def supportedCone0278 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨269, 271, 269, 269, 270⟩, ⟨0, 0, 1327748600, 1129105003, 1053672251400, 563908569140⟩⟩
    hull002_012 0 (by decide +kernel)

private def supportedCone0279 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨271, 274, 271, 271, 272⟩, ⟨0, 0, 1360807809, 1154429394, 1060000000000, 569289627427⟩⟩
    hull002_013 0 (by decide +kernel)

private def supportedCone0280 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 61, 60, 62⟩, ⟨1317712249, 141660608, 1493154549, 162160382, 291317712249, 3079499459⟩⟩
    hull002_002 52 (by decide +kernel)

private def supportedCone0281 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 70, 61, 60, 62⟩, ⟨1317712249, 141660608, 1493154549, 162160382, 291317712249, 3079499459⟩⟩
    hull002_009 9 (by decide +kernel)

private def supportedCone0282 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 70, 60, 59, 61⟩, ⟨1135985046, 115441792, 1317712249, 141660608, 290000000000, 2937838851⟩⟩
    hull002_009 8 (by decide +kernel)

private def supportedCone0283 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨265, 274, 265, 265, 272⟩, ⟨0, 0, 12541327706, 10661000385, 1048819480103, 559783056436⟩⟩
    hull002_007 0 (by decide +kernel)

private def supportedCone0284 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 70, 59, 58, 60⟩, ⟨1644287278, 166844631, 1135985046, 115441792, 288864014954, 2822397059⟩⟩
    hull002_009 7 (by decide +kernel)

private def supportedCone0285 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 70, 56, 55, 57⟩, ⟨1000000000, 94363393, 717147340, 69057165, 285000000000, 2437006455⟩⟩
    hull002_009 4 (by decide +kernel)

private def supportedCone0286 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨269, 271, 270, 269, 271⟩, ⟨1327748600, 1129105003, 5000000000, 4251953284, 1055000000000, 565037674143⟩⟩
    hull002_012 1 (by decide +kernel)

private def supportedCone0287 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨269, 271, 271, 270, 271⟩, ⟨5000000000, 4251953284, 0, 0, 1060000000000, 569289627427⟩⟩
    hull002_012 2 (by decide +kernel)

def appendixHullConeBlock0008 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0256,
    supportedCone0257,
    supportedCone0258,
    supportedCone0259,
    supportedCone0260,
    supportedCone0261,
    supportedCone0262,
    supportedCone0263,
    supportedCone0264,
    supportedCone0265,
    supportedCone0266,
    supportedCone0267,
    supportedCone0268,
    supportedCone0269,
    supportedCone0270,
    supportedCone0271,
    supportedCone0272,
    supportedCone0273,
    supportedCone0274,
    supportedCone0275,
    supportedCone0276,
    supportedCone0277,
    supportedCone0278,
    supportedCone0279,
    supportedCone0280,
    supportedCone0281,
    supportedCone0282,
    supportedCone0283,
    supportedCone0284,
    supportedCone0285,
    supportedCone0286,
    supportedCone0287,
  ], rfl⟩

private def supportedCone0288 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 51, 50, 52⟩, ⟨1280097444, 102309752, 2329787335, 195916729, 277168302232, 1745879201⟩⟩
    hull002_002 42 (by decide +kernel)

private def supportedCone0289 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 38, 37, 39⟩, ⟨1099837485, 58486581, 1225499220, 67598571, 263774500780, 842450014⟩⟩
    hull002_002 29 (by decide +kernel)

private def supportedCone0290 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 37, 36, 38⟩, ⟨1418082341, 71124003, 1099837485, 58486581, 262674663295, 783963433⟩⟩
    hull002_002 28 (by decide +kernel)

private def supportedCone0291 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 56, 56, 55, 56⟩, ⟨1000000000, 94363393, 0, 0, 285000000000, 2437006455⟩⟩
    hull002_014 4 (by decide +kernel)

private def supportedCone0292 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨56, 61, 60, 59, 61⟩, ⟨1135985046, 115441792, 1317712249, 141660608, 290000000000, 2937838851⟩⟩
    hull002_015 4 (by decide +kernel)

private def supportedCone0293 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨56, 61, 56, 56, 57⟩, ⟨0, 0, 717147340, 69057165, 285000000000, 2437006455⟩⟩
    hull002_015 0 (by decide +kernel)

private def supportedCone0294 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨56, 58, 58, 57, 58⟩, ⟨1502580336, 149488808, 0, 0, 287219727676, 2655552428⟩⟩
    hull002_016 2 (by decide +kernel)

private def supportedCone0295 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨58, 61, 60, 59, 61⟩, ⟨1135985046, 115441792, 1317712249, 141660608, 290000000000, 2937838851⟩⟩
    hull002_017 2 (by decide +kernel)

private def supportedCone0296 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨58, 61, 58, 58, 59⟩, ⟨0, 0, 1644287278, 166844631, 287219727676, 2655552428⟩⟩
    hull002_017 0 (by decide +kernel)

private def supportedCone0297 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨141, 212, 191, 189, 192⟩, ⟨10000000000, 8503850270, 5000000000, 4251925562, 740000000000, 297170334275⟩⟩
    hull002_006 38 (by decide +kernel)

private def supportedCone0298 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨141, 212, 178, 177, 179⟩, ⟨10000000000, 8503730530, 5000000000, 4251865436, 660000000000, 229139900366⟩⟩
    hull002_006 29 (by decide +kernel)

private def supportedCone0299 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 59, 58, 60⟩, ⟨1644287278, 166844631, 1135985046, 115441792, 288864014954, 2822397059⟩⟩
    hull002_002 50 (by decide +kernel)

private def supportedCone0300 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨141, 212, 177, 176, 178⟩, ⟨10000000000, 8503730458, 10000000000, 8503730530, 650000000000, 220636169836⟩⟩
    hull002_006 28 (by decide +kernel)

private def supportedCone0301 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨269, 274, 269, 269, 272⟩, ⟨0, 0, 7688556409, 6535487681, 1053672251400, 563908569140⟩⟩
    hull002_011 0 (by decide +kernel)

private def supportedCone0302 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨56, 61, 58, 57, 59⟩, ⟨1502580336, 149488808, 1644287278, 166844631, 287219727676, 2655552428⟩⟩
    hull002_015 2 (by decide +kernel)

private def supportedCone0303 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 61, 58, 57, 59⟩, ⟨1502580336, 149488808, 1644287278, 166844631, 287219727676, 2655552428⟩⟩
    hull002_018 6 (by decide +kernel)

private def supportedCone0304 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨56, 61, 57, 56, 58⟩, ⟨717147340, 69057165, 1502580336, 149488808, 285717147340, 2506063620⟩⟩
    hull002_015 1 (by decide +kernel)

private def supportedCone0305 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 61, 57, 56, 58⟩, ⟨717147340, 69057165, 1502580336, 149488808, 285717147340, 2506063620⟩⟩
    hull002_018 5 (by decide +kernel)

private def supportedCone0306 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 61, 56, 55, 57⟩, ⟨1000000000, 94363393, 717147340, 69057165, 285000000000, 2437006455⟩⟩
    hull002_018 4 (by decide +kernel)

private def supportedCone0307 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 56, 55, 57⟩, ⟨1000000000, 94363393, 717147340, 69057165, 285000000000, 2437006455⟩⟩
    hull002_002 47 (by decide +kernel)

private def supportedCone0308 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 55, 54, 56⟩, ⟨1998814794, 184328284, 1000000000, 94363393, 284000000000, 2342643062⟩⟩
    hull002_002 46 (by decide +kernel)

private def supportedCone0309 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 53, 52, 54⟩, ⟨501910433, 43066537, 2001185206, 173452311, 280000000000, 1984862467⟩⟩
    hull002_002 44 (by decide +kernel)

private def supportedCone0310 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨265, 269, 265, 265, 269⟩, ⟨0, 0, 4852771297, 4125512704, 1048819480103, 559783056436⟩⟩
    hull002_010 0 (by decide +kernel)

private def supportedCone0311 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 36, 35, 37⟩, ⟨1256580954, 61153129, 1418082341, 71124003, 261256580954, 712839430⟩⟩
    hull002_002 27 (by decide +kernel)

private def supportedCone0312 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨265, 267, 267, 266, 267⟩, ⟨1206662485, 1026072428, 0, 0, 1051206662485, 561812793134⟩⟩
    hull002_019 2 (by decide +kernel)

private def supportedCone0313 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨267, 269, 269, 267, 269⟩, ⟨2465588915, 2095776006, 0, 0, 1053672251400, 563908569140⟩⟩
    hull002_020 1 (by decide +kernel)

private def supportedCone0314 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨267, 269, 267, 267, 269⟩, ⟨0, 0, 2465588915, 2095776006, 1051206662485, 561812793134⟩⟩
    hull002_020 0 (by decide +kernel)

private def supportedCone0315 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨267, 268, 268, 267, 268⟩, ⟨1183586988, 1006642530, 0, 0, 1052390249473, 562819435664⟩⟩
    hull002_021 1 (by decide +kernel)

private def supportedCone0316 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨268, 269, 268, 268, 269⟩, ⟨0, 0, 1282001927, 1089133476, 1052390249473, 562819435664⟩⟩
    hull002_022 0 (by decide +kernel)

private def supportedCone0317 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 35, 34, 36⟩, ⟨1503327172, 68709630, 1256580954, 61153129, 260000000000, 651686301⟩⟩
    hull002_002 26 (by decide +kernel)

private def supportedCone0318 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 61, 55, 54, 56⟩, ⟨1998814794, 184328284, 1000000000, 94363393, 284000000000, 2342643062⟩⟩
    hull002_018 3 (by decide +kernel)

private def supportedCone0319 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨267, 268, 267, 267, 268⟩, ⟨0, 0, 1183586988, 1006642530, 1051206662485, 561812793134⟩⟩
    hull002_021 0 (by decide +kernel)

def appendixHullConeBlock0009 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0288,
    supportedCone0289,
    supportedCone0290,
    supportedCone0291,
    supportedCone0292,
    supportedCone0293,
    supportedCone0294,
    supportedCone0295,
    supportedCone0296,
    supportedCone0297,
    supportedCone0298,
    supportedCone0299,
    supportedCone0300,
    supportedCone0301,
    supportedCone0302,
    supportedCone0303,
    supportedCone0304,
    supportedCone0305,
    supportedCone0306,
    supportedCone0307,
    supportedCone0308,
    supportedCone0309,
    supportedCone0310,
    supportedCone0311,
    supportedCone0312,
    supportedCone0313,
    supportedCone0314,
    supportedCone0315,
    supportedCone0316,
    supportedCone0317,
    supportedCone0318,
    supportedCone0319,
  ], rfl⟩

private def supportedCone0320 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 61, 54, 53, 55⟩, ⟨2001185206, 173452311, 1998814794, 184328284, 282001185206, 2158314778⟩⟩
    hull002_018 2 (by decide +kernel)

private def supportedCone0321 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 61, 52, 52, 53⟩, ⟨0, 0, 501910433, 43066537, 279498089567, 1941795930⟩⟩
    hull002_018 0 (by decide +kernel)

private def supportedCone0322 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨265, 267, 266, 265, 267⟩, ⟨1180519897, 1003664270, 1206662485, 1026072428, 1050000000000, 560786720706⟩⟩
    hull002_019 1 (by decide +kernel)

private def supportedCone0323 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨265, 267, 265, 265, 266⟩, ⟨0, 0, 1180519897, 1003664270, 1048819480103, 559783056436⟩⟩
    hull002_019 0 (by decide +kernel)

private def supportedCone0324 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 43, 42, 44⟩, ⟨1798390801, 116302336, 1265352162, 86554930, 270000000000, 1218562464⟩⟩
    hull002_002 34 (by decide +kernel)

private def supportedCone0325 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 265, 263, 247, 264⟩, ⟨19841927031, 16869669914, 1274884946, 1084107191, 1046235068211, 557585382159⟩⟩
    hull002_023 1 (by decide +kernel)

private def supportedCone0326 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 265, 264, 263, 265⟩, ⟨1274884946, 1084107191, 1309526946, 1113567086, 1047509953157, 558669489350⟩⟩
    hull002_023 2 (by decide +kernel)

private def supportedCone0327 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 34, 33, 35⟩, ⟨827221629, 34669607, 1503327172, 68709630, 258496672828, 582976671⟩⟩
    hull002_002 25 (by decide +kernel)

private def supportedCone0328 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 256, 256, 252, 256⟩, ⟨4957093636, 4215242861, 0, 0, 1037493885956, 550154605988⟩⟩
    hull002_024 2 (by decide +kernel)

private def supportedCone0329 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨256, 265, 263, 256, 264⟩, ⟨8741182255, 7430776171, 1274884946, 1084107191, 1046235068211, 557585382159⟩⟩
    hull002_025 1 (by decide +kernel)

private def supportedCone0330 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨256, 260, 258, 257, 259⟩, ⟨1333246500, 1133753155, 1266043400, 1076652080, 1040000000000, 552285726522⟩⟩
    hull002_026 2 (by decide +kernel)

private def supportedCone0331 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨260, 265, 263, 260, 264⟩, ⟨3771291070, 3204442281, 1274884946, 1084107191, 1046235068211, 557585382159⟩⟩
    hull002_027 1 (by decide +kernel)

private def supportedCone0332 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨260, 262, 260, 260, 261⟩, ⟨0, 0, 1308019350, 1112349191, 1042463777141, 554380939878⟩⟩
    hull002_028 0 (by decide +kernel)

private def supportedCone0333 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨262, 265, 262, 262, 263⟩, ⟨0, 0, 1235068211, 1047262567, 1045000000000, 556538119592⟩⟩
    hull002_029 0 (by decide +kernel)

private def supportedCone0334 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 53, 52, 54⟩, ⟨501910433, 43066537, 2001185206, 173452311, 280000000000, 1984862467⟩⟩
    hull002_030 18 (by decide +kernel)

private def supportedCone0335 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 265, 247, 247, 263⟩, ⟨0, 0, 19841927031, 16869669914, 1026393141180, 540715712245⟩⟩
    hull002_023 0 (by decide +kernel)

private def supportedCone0336 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 52, 51, 53⟩, ⟨2329787335, 195916729, 501910433, 43066537, 279498089567, 1941795930⟩⟩
    hull002_030 17 (by decide +kernel)

private def supportedCone0337 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 51, 50, 52⟩, ⟨1280097444, 102309752, 2329787335, 195916729, 277168302232, 1745879201⟩⟩
    hull002_030 16 (by decide +kernel)

private def supportedCone0338 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 49, 48, 50⟩, ⟨1183935478, 87538993, 888204788, 69012269, 275000000000, 1574557180⟩⟩
    hull002_030 14 (by decide +kernel)

private def supportedCone0339 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨256, 260, 259, 258, 260⟩, ⟨1266043400, 1076652080, 1197733741, 1018561276, 1041266043400, 553362378602⟩⟩
    hull002_026 3 (by decide +kernel)

private def supportedCone0340 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨256, 260, 260, 259, 260⟩, ⟨1197733741, 1018561276, 0, 0, 1042463777141, 554380939878⟩⟩
    hull002_026 4 (by decide +kernel)

private def supportedCone0341 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨260, 262, 261, 260, 262⟩, ⟨1308019350, 1112349191, 1228203509, 1044830523, 1043771796491, 555493289069⟩⟩
    hull002_028 1 (by decide +kernel)

private def supportedCone0342 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 42, 41, 43⟩, ⟨821856399, 51327005, 1798390801, 116302336, 268201609199, 1102260128⟩⟩
    hull002_030 7 (by decide +kernel)

private def supportedCone0343 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 42, 41, 43⟩, ⟨821856399, 51327005, 1798390801, 116302336, 268201609199, 1102260128⟩⟩
    hull002_002 33 (by decide +kernel)

private def supportedCone0344 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨260, 265, 260, 260, 263⟩, ⟨0, 0, 3771291070, 3204442281, 1042463777141, 554380939878⟩⟩
    hull002_027 0 (by decide +kernel)

private def supportedCone0345 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 46, 45, 47⟩, ⟨412549723, 29103357, 1084869137, 78356954, 272412549723, 1385121505⟩⟩
    hull002_002 37 (by decide +kernel)

private def supportedCone0346 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 41, 40, 42⟩, ⟨1466867611, 87366046, 821856399, 51327005, 267379752800, 1050933123⟩⟩
    hull002_002 32 (by decide +kernel)

private def supportedCone0347 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 33, 32, 34⟩, ⟨1263823080, 49116029, 827221629, 34669607, 257669451199, 548307064⟩⟩
    hull002_002 24 (by decide +kernel)

private def supportedCone0348 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨256, 265, 256, 256, 263⟩, ⟨0, 0, 8741182255, 7430776171, 1037493885956, 550154605988⟩⟩
    hull002_025 0 (by decide +kernel)

private def supportedCone0349 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 283, 212, 212, 283⟩, ⟨0, 0, 210000000000, 178570837063, 865000000000, 403469201014⟩⟩
    hull002_031 0 (by decide +kernel)

private def supportedCone0350 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨256, 260, 256, 256, 257⟩, ⟨0, 0, 1172867544, 997367379, 1037493885956, 550154605988⟩⟩
    hull002_026 0 (by decide +kernel)

private def supportedCone0351 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 48, 47, 49⟩, ⟨318645662, 23539728, 1183935478, 87538993, 273816064522, 1487018187⟩⟩
    hull002_002 39 (by decide +kernel)

def appendixHullConeBlock0010 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0320,
    supportedCone0321,
    supportedCone0322,
    supportedCone0323,
    supportedCone0324,
    supportedCone0325,
    supportedCone0326,
    supportedCone0327,
    supportedCone0328,
    supportedCone0329,
    supportedCone0330,
    supportedCone0331,
    supportedCone0332,
    supportedCone0333,
    supportedCone0334,
    supportedCone0335,
    supportedCone0336,
    supportedCone0337,
    supportedCone0338,
    supportedCone0339,
    supportedCone0340,
    supportedCone0341,
    supportedCone0342,
    supportedCone0343,
    supportedCone0344,
    supportedCone0345,
    supportedCone0346,
    supportedCone0347,
    supportedCone0348,
    supportedCone0349,
    supportedCone0350,
    supportedCone0351,
  ], rfl⟩

private def supportedCone0352 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 47, 46, 48⟩, ⟨1084869137, 78356954, 318645662, 23539728, 273497418860, 1463478459⟩⟩
    hull002_002 38 (by decide +kernel)

private def supportedCone0353 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 44, 43, 45⟩, ⟨1265352162, 86554930, 734647838, 50900754, 271265352162, 1305117394⟩⟩
    hull002_002 35 (by decide +kernel)

private def supportedCone0354 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 31, 30, 32⟩, ⟨1605927162, 55162689, 1405628119, 52888125, 255000000000, 446302910⟩⟩
    hull002_002 22 (by decide +kernel)

private def supportedCone0355 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 251, 250, 247, 251⟩, ⟨3606858820, 3067192395, 1347230572, 1145904720, 1030000000000, 543782904640⟩⟩
    hull002_032 1 (by decide +kernel)

private def supportedCone0356 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨251, 256, 256, 252, 256⟩, ⟨4957093636, 4215242861, 0, 0, 1037493885956, 550154605988⟩⟩
    hull002_033 2 (by decide +kernel)

private def supportedCone0357 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 43, 43, 42, 43⟩, ⟨1798390801, 116302336, 0, 0, 270000000000, 1218562464⟩⟩
    hull002_034 8 (by decide +kernel)

private def supportedCone0358 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨251, 253, 253, 252, 253⟩, ⟨1313582947, 1117032827, 0, 0, 1033850375267, 547056395954⟩⟩
    hull002_035 2 (by decide +kernel)

private def supportedCone0359 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨43, 52, 46, 45, 47⟩, ⟨412549723, 29103357, 1084869137, 78356954, 272412549723, 1385121505⟩⟩
    hull002_036 3 (by decide +kernel)

private def supportedCone0360 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨253, 256, 256, 253, 256⟩, ⟨3643510689, 3098210034, 0, 0, 1037493885956, 550154605988⟩⟩
    hull002_037 1 (by decide +kernel)

private def supportedCone0361 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨251, 256, 251, 251, 252⟩, ⟨0, 0, 1189561748, 1010553767, 1031347230572, 544928809360⟩⟩
    hull002_033 0 (by decide +kernel)

private def supportedCone0362 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨253, 254, 254, 253, 254⟩, ⟨1149624733, 977657410, 0, 0, 1035000000000, 548034053364⟩⟩
    hull002_038 1 (by decide +kernel)

private def supportedCone0363 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨254, 256, 256, 254, 256⟩, ⟨2493885956, 2120552624, 0, 0, 1037493885956, 550154605988⟩⟩
    hull002_039 1 (by decide +kernel)

private def supportedCone0364 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨254, 256, 254, 254, 256⟩, ⟨0, 0, 2493885956, 2120552624, 1035000000000, 548034053364⟩⟩
    hull002_039 0 (by decide +kernel)

private def supportedCone0365 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨254, 255, 254, 254, 255⟩, ⟨0, 0, 1171031150, 995948457, 1035000000000, 548034053364⟩⟩
    hull002_040 0 (by decide +kernel)

private def supportedCone0366 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨255, 256, 255, 255, 256⟩, ⟨0, 0, 1322854806, 1124604167, 1036171031150, 549030001821⟩⟩
    hull002_041 0 (by decide +kernel)

private def supportedCone0367 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨43, 47, 46, 45, 47⟩, ⟨412549723, 29103357, 1084869137, 78356954, 272412549723, 1385121505⟩⟩
    hull002_042 3 (by decide +kernel)

private def supportedCone0368 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨47, 52, 47, 47, 48⟩, ⟨0, 0, 318645662, 23539728, 273497418860, 1463478459⟩⟩
    hull002_043 0 (by decide +kernel)

private def supportedCone0369 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨253, 254, 253, 253, 254⟩, ⟨0, 0, 1149624733, 977657410, 1033850375267, 547056395954⟩⟩
    hull002_038 0 (by decide +kernel)

private def supportedCone0370 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨43, 47, 45, 44, 46⟩, ⟨734647838, 50900754, 412549723, 29103357, 272000000000, 1356018148⟩⟩
    hull002_042 2 (by decide +kernel)

private def supportedCone0371 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨43, 47, 44, 43, 45⟩, ⟨1265352162, 86554930, 734647838, 50900754, 271265352162, 1305117394⟩⟩
    hull002_042 1 (by decide +kernel)

private def supportedCone0372 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨43, 47, 43, 43, 44⟩, ⟨0, 0, 1265352162, 86554930, 270000000000, 1218562464⟩⟩
    hull002_042 0 (by decide +kernel)

private def supportedCone0373 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨253, 256, 253, 253, 256⟩, ⟨0, 0, 3643510689, 3098210034, 1033850375267, 547056395954⟩⟩
    hull002_037 0 (by decide +kernel)

private def supportedCone0374 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 45, 44, 46⟩, ⟨734647838, 50900754, 412549723, 29103357, 272000000000, 1356018148⟩⟩
    hull002_002 36 (by decide +kernel)

private def supportedCone0375 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 256, 252, 247, 256⟩, ⟨6143651140, 5223650882, 4957093636, 4215242861, 1032536792320, 545939363127⟩⟩
    hull002_024 1 (by decide +kernel)

private def supportedCone0376 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 43, 42, 44⟩, ⟨1798390801, 116302336, 1265352162, 86554930, 270000000000, 1218562464⟩⟩
    hull002_044 8 (by decide +kernel)

private def supportedCone0377 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 256, 247, 247, 252⟩, ⟨0, 0, 6143651140, 5223650882, 1026393141180, 540715712245⟩⟩
    hull002_024 0 (by decide +kernel)

private def supportedCone0378 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 35, 35, 36⟩, ⟨0, 0, 1256580954, 61153129, 260000000000, 651686301⟩⟩
    hull002_044 0 (by decide +kernel)

private def supportedCone0379 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 42, 41, 43⟩, ⟨821856399, 51327005, 1798390801, 116302336, 268201609199, 1102260128⟩⟩
    hull002_044 7 (by decide +kernel)

private def supportedCone0380 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 39, 38, 40⟩, ⟨1225499220, 67598571, 912885189, 53518492, 265000000000, 910048585⟩⟩
    hull002_044 4 (by decide +kernel)

private def supportedCone0381 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 36, 35, 37⟩, ⟨1256580954, 61153129, 1418082341, 71124003, 261256580954, 712839430⟩⟩
    hull002_044 1 (by decide +kernel)

private def supportedCone0382 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 43, 42, 44⟩, ⟨1798390801, 116302336, 1265352162, 86554930, 270000000000, 1218562464⟩⟩
    hull002_030 8 (by decide +kernel)

private def supportedCone0383 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 35, 35, 36⟩, ⟨0, 0, 1256580954, 61153129, 260000000000, 651686301⟩⟩
    hull002_030 0 (by decide +kernel)

def appendixHullConeBlock0011 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0352,
    supportedCone0353,
    supportedCone0354,
    supportedCone0355,
    supportedCone0356,
    supportedCone0357,
    supportedCone0358,
    supportedCone0359,
    supportedCone0360,
    supportedCone0361,
    supportedCone0362,
    supportedCone0363,
    supportedCone0364,
    supportedCone0365,
    supportedCone0366,
    supportedCone0367,
    supportedCone0368,
    supportedCone0369,
    supportedCone0370,
    supportedCone0371,
    supportedCone0372,
    supportedCone0373,
    supportedCone0374,
    supportedCone0375,
    supportedCone0376,
    supportedCone0377,
    supportedCone0378,
    supportedCone0379,
    supportedCone0380,
    supportedCone0381,
    supportedCone0382,
    supportedCone0383,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
