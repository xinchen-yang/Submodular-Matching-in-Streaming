import SubmodularMatching.ProjectedShearerScores

/-! # Finite-precision score decisions in the chronological priority scan -/

namespace SubmodularMatching.Shearer

variable {E V L : Type*} [DecidableEq E] [DecidableEq V] [DecidableEq L]
variable (ends : E → Finset V) (label : E → L) (h : Finset L → ℝ)

/-- Feasibility and the true score of every conflict-free arrival are
recorded even when its inclusion decision uses an approximate signed
marginal. A repeated label in the current context has zero marginal. -/
noncomputable def noisyPriorityStep (estimate : Finset E → E → ℝ)
    (st : PriorityScanState E) (e : E) : PriorityScanState E := by
  classical
  let clear := ∀ a ∈ st.earlier, Disjoint (ends a) (ends e)
  let keep := clear ∧ label e ∉ st.earlier.image label ∧ 0 < estimate st.earlier e
  let s := priorityScore ends label h st.earlier e
  exact ⟨insert e st.earlier, if keep then insert e st.kept else st.kept,
    st.scores + s, st.survivingScores + if clear then s else 0⟩

private theorem noisyStep_bound (hf : IsSubmodular h) (ε : ℝ) (hε : 0 ≤ ε)
    (estimate : Finset E → E → ℝ) (acc : ∀ A e, (∀ a ∈ A, Disjoint (ends a) (ends e)) →
      |estimate A e - marginal h (label e) (A.image label)| ≤ ε)
    (st : PriorityScanState E) (e : E) (loss : ℝ) (hsub : st.kept ⊆ st.earlier)
    (hmat : Streaming.IsMatchingOn ends st.kept)
    (hprev : st.survivingScores ≤ h (st.kept.image label) - h ∅ + loss) :
    let next := noisyPriorityStep ends label h estimate st e
    next.kept ⊆ next.earlier ∧ Streaming.IsMatchingOn ends next.kept ∧
      next.survivingScores ≤ h (next.kept.image label) - h ∅ + (loss+ε) := by
  classical
  intro next
  by_cases hc : ∀ a ∈ st.earlier, Disjoint (ends a) (ends e)
  · let m := marginal h (label e) (st.earlier.image label)
    have hscore : priorityScore ends label h st.earlier e = max 0 m := by
      simp only [priorityScore,Finset.filter_eq_self.mpr hc,m]
    obtain ⟨hl,hu⟩ := abs_le.mp (acc st.earlier e hc)
    change -ε ≤ estimate st.earlier e - m at hl
    change estimate st.earlier e - m ≤ ε at hu
    by_cases hk : label e ∉ st.earlier.image label ∧ 0 < estimate st.earlier e
    · have hg : m ≤ marginal h (label e) (st.kept.image label) :=
        diminishing_returns h hf _ _ _ (Finset.image_mono label hsub) hk.1
      have hm : max 0 m ≤ marginal h (label e) (st.kept.image label) + ε := by
        apply max_le
        · linarith only [hu,hk.2,hg]
        · linarith only [hε,hg]
      simp only [next,noisyPriorityStep,if_pos hc,if_pos (And.intro hc hk),hscore]
      refine ⟨Finset.insert_subset_insert _ hsub, ?_, ?_⟩
      · intro a ha b hb hab
        rcases Finset.mem_insert.mp ha with hae | hak
        · subst a
          exact (hc _ (hsub (Finset.mem_of_mem_insert_of_ne hb (Ne.symm hab)))).symm
        · rcases Finset.mem_insert.mp hb with hbe | hbk
          · subst b
            exact hc _ (hsub hak)
          · exact hmat hak hbk hab
      · simp only [Finset.image_insert]
        simp only [marginal,Finset.union_singleton] at hm
        linarith only [hprev,hm]
    · have hm : max 0 m ≤ ε := by
        apply max_le hε
        by_cases hin : label e ∈ st.earlier.image label
        · simpa [m,marginal_eq_zero_of_mem h _ _ hin] using hε
        · have hn : estimate st.earlier e ≤ 0 := le_of_not_gt (fun h => hk ⟨hin,h⟩)
          linarith only [hl,hn]
      have hno : ¬((∀ a ∈ st.earlier, Disjoint (ends a) (ends e)) ∧
          label e ∉ st.earlier.image label ∧ 0 < estimate st.earlier e) := fun h => hk h.2
      simp only [next,noisyPriorityStep,if_pos hc,if_neg hno,hscore]
      exact ⟨hsub.trans (Finset.subset_insert _ _), hmat, by linarith only [hprev,hm]⟩
  · have hno : ¬((∀ a ∈ st.earlier, Disjoint (ends a) (ends e)) ∧
          label e ∉ st.earlier.image label ∧ 0 < estimate st.earlier e) := fun h => hc h.1
    simp only [next,noisyPriorityStep,if_neg hc,if_neg hno,add_zero]
    exact ⟨hsub.trans (Finset.subset_insert _ _), hmat, by linarith only [hprev,hε]⟩

/-- For every realized priority order, additive score-estimation error
costs at most one tolerance per sampled copy in the final objective. -/
theorem noisyPriorityScan_loss (hf : IsSubmodular h) (ε : ℝ) (hε : 0 ≤ ε)
    (estimate : Finset E → E → ℝ) (acc : ∀ A e, (∀ a ∈ A, Disjoint (ends a) (ends e)) →
      |estimate A e - marginal h (label e) (A.image label)| ≤ ε) (order : List E) :
    let st := order.foldl (noisyPriorityStep ends label h estimate) ⟨∅,∅,0,0⟩
    Streaming.IsMatchingOn ends st.kept ∧
      st.survivingScores ≤ h (st.kept.image label) - h ∅ + order.length * ε := by
  let step := noisyPriorityStep ends label h estimate
  have aux (es : List E) (st : PriorityScanState E) (loss : ℝ) (hs : st.kept ⊆ st.earlier)
      (hm : Streaming.IsMatchingOn ends st.kept) (hb : st.survivingScores ≤ h (st.kept.image label)-h ∅ + loss) :
      let out := es.foldl step st
      Streaming.IsMatchingOn ends out.kept ∧
        out.survivingScores ≤ h (out.kept.image label)-h ∅ + (loss+es.length*ε) := by
    induction es generalizing st loss with
    | nil => simpa using And.intro hm hb
    | cons e es ih =>
      obtain ⟨hs',hm',hb'⟩ := noisyStep_bound ends label h hf ε hε estimate acc st e loss hs hm hb
      obtain ⟨hm'',hb''⟩ := ih (step st e) (loss+ε) hs' hm' hb'
      refine ⟨hm'', ?_⟩
      simp only [List.foldl_cons,List.length_cons,Nat.cast_add,Nat.cast_one]
      linarith only [hb'']
  simpa only [zero_add] using aux order ⟨∅,∅,0,0⟩ 0 (by simp) (by simp [Streaming.IsMatchingOn]) (by simp)

end SubmodularMatching.Shearer
