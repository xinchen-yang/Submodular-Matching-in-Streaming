import SubmodularMatching.LowerBoundGlobalPhase
import SubmodularMatching.LowerBoundGlobalStage

/-! # Integrating conditional phase and stage estimates -/

namespace SubmodularMatching.LowerBoundGlobal

open Information
open scoped BigOperators

noncomputable section

/-- Average over external data first, then over the two independent laws
at the current cut. The law of the continuation data can depend on the fixed
past (and can include the current hidden label). -/
theorem average_conditional_bound
    {Past Sample Future : Type*} [Fintype Past] [Fintype Sample] [Fintype Future]
    (pastLaw : Past → ℝ) (sampleLaw : Past → Sample → ℝ)
    (futureLaw : Past → Future → ℝ)
    (hPast : ∀ p, 0 ≤ pastLaw p) (hPastSum : ∑ p, pastLaw p = 1)
    (f : Past → Sample → Future → ℝ) (bound : ℝ)
    (hcond : ∀ p, 0 < pastLaw p →
      (∑ x, sampleLaw p x * (∑ z, futureLaw p z * f p x z)) ≤ bound) :
    (∑ input : Past × (Sample × Future),
      (pastLaw input.1 * sampleLaw input.1 input.2.1 * futureLaw input.1 input.2.2) *
        f input.1 input.2.1 input.2.2) ≤ bound := by
  rw [Fintype.sum_prod_type]
  calc
    _ = ∑ p, pastLaw p * (∑ x, sampleLaw p x * (∑ z, futureLaw p z * f p x z)) := by
      apply Finset.sum_congr rfl
      intro p _
      simp only [Fintype.sum_prod_type, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro x _
      apply Finset.sum_congr rfl
      intro z _
      ring
    _ ≤ ∑ p, pastLaw p * bound := by
      apply Finset.sum_le_sum
      intro p _
      by_cases hp : 0 < pastLaw p
      · exact mul_le_mul_of_nonneg_left (hcond p hp) hp.le
      · simp [le_antisymm (le_of_not_gt hp) (hPast p)]
    _ = _ := by rw [← Finset.sum_mul, hPastSum, one_mul]

/-- The same bound for an already defined joint law, once the experiment
has been reorganized into its past, current sample, and future stages. -/
theorem average_conditional_bound_reindex
    {Ω Past Sample Future : Type*}
    [Fintype Ω] [Fintype Past] [Fintype Sample] [Fintype Future]
    (reindex : Ω ≃ Past × (Sample × Future))
    (law : Ω → ℝ) (count : Ω → ℝ)
    (pastLaw : Past → ℝ) (sampleLaw : Past → Sample → ℝ)
    (futureLaw : Past → Future → ℝ)
    (hlaw : ∀ p x z, law (reindex.symm (p, x, z)) =
      pastLaw p * sampleLaw p x * futureLaw p z)
    (hPast : ∀ p, 0 ≤ pastLaw p) (hPastSum : ∑ p, pastLaw p = 1)
    (bound : ℝ)
    (hcond : ∀ p, 0 < pastLaw p →
      (∑ x, sampleLaw p x * (∑ z, futureLaw p z * count (reindex.symm (p, x, z)))) ≤ bound) :
    (∑ ω, law ω * count ω) ≤ bound := by
  rw [← reindex.symm.sum_comp (fun ω => law ω * count ω)]
  have h := average_conditional_bound pastLaw sampleLaw futureLaw hPast hPastSum
    (fun p x z => count (reindex.symm (p, x, z))) bound hcond
  simpa only [← hlaw, Prod.mk.eta] using h

/-- Marginalizing auxiliary later randomness before occupancy of the
memory state is analyzed. Fixing the tuple or label may change the
distribution of later samples. -/
theorem sum_future_kernel {Unseen Future : Type*} [Fintype Unseen] [Fintype Future]
    (unseenLaw : Unseen → ℝ) (futureLaw : Unseen → Future → ℝ)
    (hfuture : ∀ j, ∑ f, futureLaw j f = 1) (weight : Unseen → ℝ) :
    (∑ outcome : Unseen × Future,
      (unseenLaw outcome.1 * futureLaw outcome.1 outcome.2) * weight outcome.1) =
        ∑ j, unseenLaw j * weight j := by
  rw [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro j _
  simp only [mul_assoc, ← Finset.mul_sum, ← Finset.sum_mul, hfuture, one_mul]

/-- Per-phase rare-output estimates sum over the disjoint expansion phases.
Assign each special output edge the phase of its base edge. Private leaves
never enter the input finite sets to which this theorem is applied. -/
theorem sum_phase_output_bounds
    {Ω E P : Type*} [Fintype Ω] [Fintype P] [DecidableEq P]
    (law : Ω → ℝ) (specialOutput : Ω → Finset E) (phase : Ω → E → P)
    (perPhase : ℝ)
    (hphase : ∀ j,
      (∑ ω, law ω * (((specialOutput ω).filter (fun e => phase ω e = j)).card : ℝ)) ≤ perPhase) :
    (∑ ω, law ω * ((specialOutput ω).card : ℝ)) ≤ (Fintype.card P : ℝ) * perPhase := by
  calc
    _ = ∑ ω, law ω * (∑ j, (((specialOutput ω).filter
        (fun e => phase ω e = j)).card : ℝ)) := by
      apply Finset.sum_congr rfl
      intro ω _
      rw [Information.sum_label_card]
    _ = ∑ j, ∑ ω, law ω * (((specialOutput ω).filter
        (fun e => phase ω e = j)).card : ℝ) := by
      simp only [Finset.mul_sum]
      rw [Finset.sum_comm]
    _ ≤ ∑ _j : P, perPhase := Finset.sum_le_sum (fun j _ => hphase j)
    _ = _ := by simp

/-- Turn the phase constants in Lemma 4.5 into its stage constant. -/
theorem stage_special_count_bound
    {Ω E P : Type*} [Fintype Ω] [Fintype P] [DecidableEq P]
    (law : Ω → ℝ) (specialOutput : Ω → Finset E) (phase : Ω → E → P)
    (K s t d : ℝ)
    (hphase : ∀ j,
      (∑ ω, law ω * (((specialOutput ω).filter (fun e => phase ω e = j)).card : ℝ)) ≤
        K * ((Fintype.card P : ℝ) / t * (s / d))) :
    (∑ ω, law ω * ((specialOutput ω).card : ℝ)) ≤
      K * s * (Fintype.card P : ℝ) ^ 2 / (t * d) := by
  apply (sum_phase_output_bounds law specialOutput phase _ hphase).trans_eq
  simp only [div_eq_mul_inv, mul_inv, pow_two]
  ring

end

end SubmodularMatching.LowerBoundGlobal
