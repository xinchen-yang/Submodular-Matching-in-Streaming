import SubmodularMatching.CapacityLabelTable
import SubmodularMatching.UpperBoundGraphInput
import SubmodularMatching.NonmonotoneStoredSlotAlteration

/-! # Retained-slot alteration directly from the optimizer's physical state -/

namespace SubmodularMatching.Capacity
open Finset TwoLayerDiffuse UpperBoundAssembly
open scoped BigOperators
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

/-- For each retained label there is one diffuse copy and all slot pairs for
the two independent layers. The layer mass is stored on original labels. -/
theorem physical_retained_alteration (S : SimpleEdgeStream E V) (b : V → ℕ)
    (hb : ∀ v, 0 < b v) (rank : BSlot b ↪ ℕ)
    (left : (e : E) → Fin (b (S.ends e).1)) (right : (e : E) → Fin (b (S.ends e).2))
    (d p ξ θ₁ θ₂ tv te : ℝ) (hd : 0 ≤ d) (hd' : d ≤ 1/3) (hξ : 0 < ξ) (hp : 0 < p)
    (hpc : p ≤ coordinateCap ξ) (hθ₁ : 0 ≤ θ₁) (hθ₂ : 0 ≤ θ₂) (hsum : θ₁+θ₂=1)
    (ht₁ : θ₁*d ≤ 1/4) (ht₂ : θ₂*d ≤ 1/4) (x Y : E → ℝ)
    (h : PhysicalAction S.ends b (slotPair S.ends b left right) p d
      (1-θ₁*θ₂*tv^2) (1-2*θ₁*θ₂*tv) (1-θ₁*θ₂*te^2) (1-2*θ₁*θ₂*te) x Y) :
    let pair := slotPair S.ends b left right
    let R := univ.image S.ends
    let table := labelTable S.ends Y
    let hload : ∀ v, TwoLayerDiffuse.slotLoad b table v ≤ d := fun v =>
      (labelTable_load S.ends S.loopless b Y v).le.trans (h.degree v)
    let layer := fun θ (hθ : 0 ≤ θ) (ht : θ*d ≤ 1/4) =>
      retainedSlotLayer b hb rank R table (labelTable_symm S.ends Y) (labelTable_diag S.ends S.loopless Y)
        (labelTable_support S.ends Y) (labelTable_nonneg S.ends Y (fun e => (h.y_bounded e).1)) θ d hθ ht hload
    let A := layer θ₁ hθ₁ ht₁
    let B := layer θ₂ hθ₂ ht₂
    let z := alteredSparse TwoLayerDiffuse.pairVertices (storedSlotPairs b rank R) pair A B x ξ
    (∀ ω e, 0 ≤ z ω e ∧ z ω e ≤ p) ∧ (∀ ω i, Joint.degree pair (z ω) i ≤ 1) ∧
    (∀ ω e, z ω e ≠ 0 → vacant TwoLayerDiffuse.pairVertices (storedSlotPairs b rank R) (pair e).1 ω = 1 ∧
      vacant TwoLayerDiffuse.pairVertices (storedSlotPairs b rank R) (pair e).2 ω = 1) ∧
    ∀ e, (1-ξ)*x e ≤ VarianceBound.finiteMean (joint A B) (fun ω => z ω e) := by
  intro pair R table hload layer A B z
  have hloop (e : E) : (pair e).1 ≠ (pair e).2 := fun he => S.loopless e (congrArg Sigma.fst he)
  apply retained_slot_alteration b hb rank R table (labelTable_symm S.ends Y) (labelTable_diag S.ends S.loopless Y)
    (labelTable_support S.ends Y) (labelTable_nonneg S.ends Y (fun e => (h.y_bounded e).1))
    pair hloop (assigned_pair_simple S.ends S.simple b left right) x h.x_nonnegative d p ξ θ₁ θ₂ tv te
    hd hd' hξ hp hpc hθ₁ hθ₂ hsum ht₁ ht₂ hload
  · intro i
    rw [show table = labelTable S.ends Y from rfl,labelTable_load S.ends S.loopless b Y]
    exact h.shared i
  · intro e
    simp only [table,labelTable_load S.ends S.loopless b Y]
    exact h.edge e

end
end SubmodularMatching.Capacity
