import SubmodularMatching.CapacitySelectedLaw

/-! High-probability physical signed estimates for a selected guess. -/
namespace SubmodularMatching.Capacity.WordWindow
open Streaming Streaming.OracleQuery UpperBoundAssembly AppendixM Finset
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem selected_source_confidence (P : WordWindow E V) (J : ℕ) (hJ : 0 < J)
    (hv : 2≤P.v) (hk : P.k≤P.v^2) (hf : IsSubmodular P.f) (hn : ∀ A, 0≤P.f A)
    (ha : guessActive (guessWidth P.v) (guessAnchor (guessWidth P.v) (RealOracle.edgeClock P.edges P.f) (P.k+1))
      (singletonMaximum (RealOracle.edgeClock P.edges P.f) (P.k+1)) P.j) (initial : SourceWordTape) :
    let K := sourceWordScale P.v (P.v^2)
    let N := batchCount K J
    let bits := batchBits K
    let p := P.law N bits P.gap initial
    (∑ z ∈ p.outcomes, if z.2 then 0 else p.mass z) ≤ 1/(J:ℝ) ∧
      ∀ z ∈ p.outcomes, z.2=true → P.Good N bits P.calls z.1 := by
  intro K N bits p
  have hp := sourceWordScale_bounds P.v (P.v^2) P.k hv hk
  have hkp : 0<K := by unfold K sourceWordScale; positivity
  have he : P.scale = guessAnchor (guessWidth P.v) (RealOracle.edgeClock P.edges P.f)
      (P.k+1)*2^P.j := by simp only [scale,RealSource.OnlineEpoch.scale,(RealSource.runOnlineEpoch_real _ _ _ _).2]
  have ht : 0 < P.scale := (ha.1.trans_le ha.2.1).trans_eq he.symm
  let lo := -((P.k:ℝ)+1)*P.scale
  let hi := P.scale
  have hlo : lo ≤ 0 := by exact mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr (by positivity)) ht.le
  have hw : 0 < hi-lo := by dsimp [hi]; linarith
  have hg : 0 < P.gap := by
    dsimp [gap]
    positivity [show (0:ℝ)<P.v by exact_mod_cast (show 0<P.v by omega),
      show (0:ℝ)<streamTolerance by norm_num [streamTolerance]]
  have hratio : hi-lo ≤ K*P.gap := by
    have h1 : (P.k:ℝ)+2 ≤ (P.v:ℝ)^2+2 := by exact_mod_cast Nat.add_le_add_right hk 2
    have h2 := hp.2.2
    push_cast at h2
    change _ ≤ (K:ℝ)*_ at h2
    have hm := mul_le_mul_of_nonneg_right (h1.trans h2) ht.le
    calc hi-lo = ((P.k:ℝ)+2)*P.scale := by dsimp [hi,lo]; ring
         _ ≤ ((K:ℝ)*((streamTolerance:ℝ)/(P.v:ℝ)^2))*P.scale := hm
         _ = (K:ℝ)*P.gap := by dsimp only [gap]; ring
  have hbounds (i : ℕ) (t : SourceWordTape) : (P.choose N bits i t).size ≤ K ∧
      ∀ A ⊆ (range (P.choose N bits i t).size).image (P.choose N bits i t).edges,
        lo ≤ (P.choose N bits i t).evaluate A ∧ (P.choose N bits i t).evaluate A ≤ hi := by
    by_cases h : i<P.calls
    · simp only [choose,if_pos h]
      have hh := RealOracle.active_bank_query_range P.ends P.cap P.positive P.v N bits P.f P.edges
        (tapeDraw t P.b P.j P.other) P.k P.j P.b i h hf hn ha
      exact ⟨hh.1.trans hp.1,hh.2⟩
    · simp only [choose,if_neg h]
      exact ⟨Nat.zero_le _,fun _ _ => ⟨hlo,ht.le⟩⟩
  exact ⟨preparation_confidence (P.choose N bits) K J P.calls hkp hJ ((Nat.sub_le P.k P.b).trans hp.1) lo hi P.gap
    hg hw hratio (fun i t => (hbounds i t).1) (P.advance N bits) (fun i t => (hbounds i t).2)
    initial,P.supported_good N bits initial⟩

end
end SubmodularMatching.Capacity.WordWindow
