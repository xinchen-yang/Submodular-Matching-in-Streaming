import SubmodularMatching.UpperBoundParametricSpace
import SubmodularMatching.StreamingOnlineAppendixWorkspace

/-! # Exact rational-grid forward stream for the approximation family -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming SourceCertificate NumericalCertificate

variable {slack : ℝ} (a : FamilyParameters slack)

/-- Fixed positive rational tolerance for the executable source. -/
def familyRationalError : ℚ := 1 / (a.K : ℚ)

theorem familyRationalError_pos : 0 < familyRationalError a :=
  div_pos one_pos (by exact_mod_cast a.K_pos)

@[simp] theorem familyRationalError_cast : (familyRationalError a : ℝ) = a.error := by
  unfold familyRationalError FamilyParameters.error
  push_cast
  rfl

def parametricOnlineGrid (vertices : ℕ) : GridUpdateParameters :=
  GridUpdateParameters.paper (rationalStageOf appendixRateTable 0)
    (rationalStagesLoop appendixRateTable (appendixRateTable.count - 1) []).reverse
    a.p (familyRationalError a) vertices

theorem parametricOnlineGrid_matches (vertices : ℕ) (hn : 2 ≤ vertices) (tau : ℝ) (ht : 0 < tau) :
    (parametricOnlineGrid a vertices).Matches (parametricGuessConfig vertices hn a.K a.K_pos a.p a.p_pos a.p_source tau) := by
  have hs := parametricGuessConfig_spec vertices hn a.K a.K_pos a.p a.p_pos a.p_source tau ht
  dsimp only at hs
  apply GridUpdateParameters.paper_matches
  · exact familyRationalError_pos a
  · omega
  · simp only [parametricGuessConfig, SourceRateTable.makeConfig,
      rationalStageOf, RationalStage.real, SourceRateTable.stage]
  · simp only [parametricGuessConfig, SourceRateTable.makeConfig,
      SourceRateTable.stages, rationalStagesLoop_eq, List.append_nil, List.reverse_reverse]
    exact rationalStagesThrough_real appendixRateTable _
  · rw [parametricGuessConfig_p]
  · rw [hs.1, hs.2.1]
    rw [familyRationalError_cast]
  · rw [hs.1, hs.2.2.1]
    rw [familyRationalError_cast]
  · rw [hs.1, hs.2.2.2, parametricGuessConfig_p]
    rw [familyRationalError_cast]


variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- With the exact appendix values, each tape in the finite source law is
realized by the forward-only executable stream, at every stopping prefix. -/
theorem parametricSourceTape_online
    (edges : ℕ → E) (ends : E → V × V) (oracle : Finset E → ℚ)
    (vertices arrivals : ℕ) (hn : 2 ≤ vertices) (ha : arrivals ≤ vertices ^ 2)
    (hf : IsSubmodular (fun A => (oracle A : ℝ))) (hm : IsMonotone (fun A => (oracle A : ℝ)))
    (hzero : (oracle ∅ : ℝ) = 0) {N : ℕ} (batches : ℕ → Fin N → ℝ) :
    let P := parametricScheduledSource edges ends (fun A => (oracle A : ℝ)) vertices arrivals hn ha a.K a.K_pos a.p a.p_pos a.p_source hf hm hzero
    let R := parametricOnlineGrid a vertices
    let W := (vertices : ℚ) / (familyRationalError a)
    batches ∈ (sourceWordTape P N oracle a.p).outcomes →
    ∃ coins : ℕ → ℕ → ℕ → ℕ → ℕ, ∀ stop ≤ arrivals,
      runOnlineStreamForward R ends W (familyRationalError a) P.span vertices oracle
          (dyadicThreshold a.p P.bits) N edges coins stop =
        runOnlineIndexed R ends W P.span (fun i => oracle {edges i}) edges (P.tapeIndex batches) stop := by
  intro P R W hb
  have he : (familyRationalError a : ℝ) = P.epsilon := familyRationalError_cast a
  have hw : (W : ℝ) = P.width := by
    change (((vertices : ℚ) / (familyRationalError a) : ℚ) : ℝ) = _
    push_cast
    rw [he]
    rfl
  have hwspan : W ≤ 2 ^ P.span := by
    have h := P.width_bound
    have hr : (W : ℝ) ≤ 2 ^ P.span := hw.symm ▸ h
    exact_mod_cast hr
  have hone : 1 ≤ W := by
    have hv : (1 : ℚ) ≤ vertices := by exact_mod_cast (show 1 ≤ vertices by omega)
    change 1 ≤ (vertices : ℚ) / (familyRationalError a)
    apply (le_div_iff₀ (familyRationalError_pos a)).2
    rw [one_mul]
    have hK : (1 : ℚ) ≤ a.K := by exact_mod_cast a.K_pos
    exact ((div_le_one (zero_lt_one.trans_le hK)).2 hK).trans hv
  have hR (τ : ℝ) (hτ : 0 < τ) : R.Matches (P.config τ) := parametricOnlineGrid_matches a vertices hn τ hτ
  obtain ⟨coins, h⟩ := P.exists_runOnlineStream_eq_wordTape R W (familyRationalError a) a.p
    oracle rfl hone hwspan hw he hR batches (sourceWordTape_has_wordBatch P N oracle _ batches hb)
  refine ⟨coins, ?_⟩
  intro stop hna
  rw [runOnlineStreamForward_eq]
  exact h stop hna


/-- The forward streaming program uses one header per active guess and at
most a quadratic logarithmic number of sparse archive rows. The claim is
pointwise on all actual generated words, independent of accuracy. -/
theorem parametricSourceExecution_rows_le (edges : ℕ → E) (ends : E → V × V)
    (oracle : Finset E → ℚ) (n arrivals : ℕ) (hn : 2 ≤ n) (ha : arrivals ≤ n ^ 2)
    (hf : IsSubmodular (fun A => (oracle A : ℝ))) (hm : IsMonotone (fun A => (oracle A : ℝ)))
    (hzero : (oracle ∅ : ℝ) = 0) {N : ℕ} (hN : 0 < N) (ρ : SourceWordExecution N)
    (k : ℕ) (hk : k ≤ arrivals) (allEdges M : Finset E)
    (hunique : ∀ i < k, ∀ j < k, edges i = edges j → i = j)
    (hin : ∀ i < k, edges i ∈ allEdges) (hloop : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet ends) A → A.card ≤ M.card) :
    let P := parametricScheduledSource edges ends (fun A => (oracle A : ℝ)) n arrivals hn ha a.K a.K_pos a.p a.p_pos a.p_source hf hm hzero
    let R := parametricOnlineGrid a n
    let W := (n : ℚ) / (familyRationalError a)
    let w := (n + 1).log2 + 1
    let st := runOnlineStreamForward R ends W (familyRationalError a) P.span n oracle
      (dyadicThreshold a.p P.bits) N edges (P.wordStream ρ.words) k
    ρ ∈ (sourceExecution P N oracle a.p).outcomes →
    st.archiveRows + st.instances.length ≤
      (6 * M.card * (parametricIncidenceConstant a) * w + 1) * ((parametricGuessCountConstant a) * w) := by
  intro P R W w st hρ
  have he : (familyRationalError a : ℝ) = P.epsilon := familyRationalError_cast a
  have hw : (W : ℝ) = P.width := by
    change (((n : ℚ) / (familyRationalError a) : ℚ) : ℝ) = _
    push_cast
    rw [he]
    rfl
  have hwspan : W ≤ 2 ^ P.span := by
    have hr : (W : ℝ) ≤ 2 ^ P.span := hw.symm ▸ P.width_bound
    exact_mod_cast hr
  have hone : 1 ≤ W := by
    have hv : (1 : ℚ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
    change 1 ≤ (n : ℚ) / (familyRationalError a)
    apply (le_div_iff₀ (familyRationalError_pos a)).2
    rw [one_mul]
    have hK : (1 : ℚ) ≤ a.K := by exact_mod_cast a.K_pos
    exact ((div_le_one (zero_lt_one.trans_le hK)).2 hK).trans hv
  have hR (τ : ℝ) (hτ : 0 < τ) : R.Matches (P.config τ) := parametricOnlineGrid_matches a n hn τ hτ
  have hlegal := sourceExecution_legal P N oracle a.p ρ hρ
  have hread : ∀ t < P.calls.length, P.HasWordBatch oracle a.p ρ.batches t := by
    intro t ht
    obtain ⟨draw, _, htrue⟩ := hlegal t ht
    exact ⟨draw, htrue⟩
  have hc := P.runOnlineStream_eq_wordTape_of_read R W (familyRationalError a) a.p oracle rfl
    hone hwspan hw he hR ρ.batches ρ.words hlegal k hk
  have hc' : st = runOnlineIndexed R P.ends W P.span (fun i => oracle {P.edges i}) P.edges (P.tapeIndex ρ.batches) k := by
    unfold st
    rw [runOnlineStreamForward_eq]
    exact hc
  have hrows := P.online_snapshot_archiveRows_bound R W a.p oracle rfl hone hwspan hw hR
    ρ.batches k hk hN hread hunique ((parametricIncidenceConstant a) * w) allEdges M hin hloop hMsub hM hmax
    (parametricGuessConfig_incidenceLimit_le a n hn)
  have hheaders : st.instances.length ≤ P.span + 1 := runOnlineStreamForward_instance_count_le
    R ends W (familyRationalError a) P.span n oracle (dyadicThreshold a.p P.bits)
    N edges (P.wordStream ρ.words) k
  have hspan : P.span + 1 ≤ (parametricGuessCountConstant a) * w := parametricGuessCount_le a n
  calc
    _ ≤ 3 * (2 * M.card * ((parametricIncidenceConstant a) * w) * (P.span + 1)) + (P.span + 1) :=
      Nat.add_le_add (hc'.symm ▸ hrows) hheaders
    _ = (6 * M.card * (parametricIncidenceConstant a) * w + 1) * (P.span + 1) := by ring
    _ ≤ _ := Nat.mul_le_mul_left _ hspan


end SubmodularMatching.UpperBoundAssembly
