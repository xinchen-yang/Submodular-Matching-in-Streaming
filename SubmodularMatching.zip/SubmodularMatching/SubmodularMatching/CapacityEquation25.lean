import SubmodularMatching.CapacityRecordedComparator
import SubmodularMatching.NonmonotoneSourceVerified

/-! # Verified numerical source bounds for the capacitated program -/

namespace SubmodularMatching.AppendixM
open Capacity Streaming SourceCertificate
open scoped BigOperators
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Nonempty E] [Fintype V] [DecidableEq V]

/-- On every bounded transcript this supplies the normalized feasible source
comparator with the original run's recorded G and exactly the ideal P_b term. -/
theorem capacity_equation25 (C : PotentialConfig) (hb : C.base = rescaledRateTable.stage 0)
    (hs : C.stages = rescaledRateTable.stages) (hp : C.p ≤ 1/1000000)
    (ends : E → V × V) (hn : ∀ e, (ends e).1 ≠ (ends e).2) (cap : V → ℕ)
    (left : (e : E) → Fin (cap (ends e).1)) (right : (e : E) → Fin (cap (ends e).2))
    (input : ℕ → E × ℝ) (n : ℕ)
    (hinj : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j)
    (hw : ∀ i < n, 0 ≤ (input i).2 ∧ (input i).2 ≤ C.tau)
    (O : Finset E) (hO : feasible ends cap O) :
    let pair := slotPair ends cap left right
    let kept := (runPotential C pair input n).stored
    ∃ z : E → ℝ, let t := Sum.elim (fun e => z e/(C.p*edgeIntercept)) (Joint.edgeIndicator O)
      (∀ i, 0 ≤ t i ∧ t i ≤ 1) ∧
      (∀ r, LinearPacking.load (capacityMatrix ends cap pair C.p degree vertexIntercept vertexSlope
        edgeIntercept edgeSlope) t r ≤ 1) ∧ (∀ e, e ∉ kept → z e = 0) ∧
      (alpha+1/1000000)*traceRecordedValue C pair input n + beta*unoccupiedCharge ends cap O
        (fun v j => idealPotential C pair input n ⟨v,j⟩) ≤ ∑ e, frozenInput input n e*z e :=
  capacity_recorded_comparator C hp (rescaled_source_conditions C hb hs hp) ends hn cap left right
    input n hinj hw O hO

end
end SubmodularMatching.AppendixM
