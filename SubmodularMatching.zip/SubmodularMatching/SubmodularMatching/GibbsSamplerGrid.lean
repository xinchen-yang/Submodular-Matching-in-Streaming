import SubmodularMatching.GibbsSamplerMixing
import Mathlib.Algebra.Order.Floor.Semiring

/-!
# A finite-bit Gibbs transition row

Round each moving transition down to a multiple of `2⁻ᵇ` and place
the leftover mass on the current matching. Every moving destination is
identified by one proposed edge. This gives a one-draw alternative to
separately rounding the edge proposal and its acceptance probability.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Number of equal dyadic cells assigned to an off-diagonal transition. -/
noncomputable def moveCells (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (b : ℕ) (M N : Finset E) : ℕ :=
  ⌊offDiagonal ends edges activity M N * (2 : ℝ)^b⌋₊

noncomputable def roundedMove (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (b : ℕ) (M N : Finset E) : ℝ :=
  (moveCells ends edges activity b M N : ℝ) / (2 : ℝ)^b

omit [DecidableEq V] in
theorem roundedMove_bounds (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (b : ℕ) (M N : Finset E)
    (hn : 0 ≤ offDiagonal ends edges activity M N) :
    0 ≤ roundedMove ends edges activity b M N ∧
    roundedMove ends edges activity b M N ≤ offDiagonal ends edges activity M N ∧
    offDiagonal ends edges activity M N - roundedMove ends edges activity b M N < ((2 : ℝ)^b)⁻¹ := by
  let q : ℝ := (2 : ℝ)^b
  have hq : 0 < q := by dsimp [q]; positivity
  have hlo := Nat.floor_le (mul_nonneg hn hq.le)
  have hhi := Nat.lt_floor_add_one (offDiagonal ends edges activity M N * q)
  refine ⟨by unfold roundedMove; positivity, (div_le_iff₀ hq).mpr hlo, ?_⟩
  change offDiagonal ends edges activity M N -
    (⌊offDiagonal ends edges activity M N * q⌋₊ : ℝ) / q < q⁻¹
  rw [sub_lt_iff_lt_add, ← one_div, ← add_div]
  exact (lt_div_iff₀ hq).mpr (by linarith only [hhi])

omit [DecidableEq V] in
theorem roundedMove_zero (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (b : ℕ) (M N : Finset E)
    (h : offDiagonal ends edges activity M N = 0) :
    roundedMove ends edges activity b M N = 0 := by
  simp [roundedMove, moveCells, h]

noncomputable def roundedTransition (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (b : ℕ) (M N : Finset E) : ℝ := by
  classical
  exact if M = N then 1 - ∑ P ∈ matchings ends edges, roundedMove ends edges activity b M P
  else roundedMove ends edges activity b M N

theorem roundedTransition_isKernel (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (b : ℕ) (ha : ∀ e ∈ edges, 0 ≤ activity e) :
    IsKernel (matchings ends edges) (roundedTransition ends edges activity b) := by
  classical
  constructor
  intro M hM
  constructor
  · intro N hN
    rw [roundedTransition]
    split_ifs
    · have hle := Finset.sum_le_sum fun B hB => (roundedMove_bounds ends edges activity b M B
          (offDiagonal_bounds ends edges activity ha M B hM hB).1).2.1
      linarith only [hle, offDiagonal_outgoing_le_half ends edges activity ha M hM]
    · exact (roundedMove_bounds ends edges activity b M N
        (offDiagonal_bounds ends edges activity ha M N hM hN).1).1
  · rw [← Finset.sum_erase_add _ _ hM]
    have hOff := Finset.sum_erase_add (matchings ends edges) (roundedMove ends edges activity b M) hM
    rw [roundedMove_zero ends edges activity b M M (offDiagonal_self ends edges activity M),
      add_zero] at hOff
    have hSum :
        (∑ N ∈ (matchings ends edges).erase M, roundedTransition ends edges activity b M N) =
          ∑ N ∈ (matchings ends edges).erase M, roundedMove ends edges activity b M N := by
      exact Finset.sum_congr rfl fun N hN => by
        have hNe : M ≠ N := (Finset.mem_erase.mp hN).1.symm
        simp [roundedTransition, hNe]
    rw [hSum, roundedTransition, if_pos rfl, ← hOff]
    ring

theorem roundedTransition_rowError (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (b : ℕ) (ha : ∀ e ∈ edges, 0 ≤ activity e)
    (M : Finset E) (hM : M ∈ matchings ends edges) :
    variation (matchings ends edges) (roundedTransition ends edges activity b M)
      (transition ends edges activity M) ≤ (edges.card : ℝ) * ((2 : ℝ)^b)⁻¹ := by
  classical
  let off := offDiagonal ends edges activity M
  let approx := roundedMove ends edges activity b M
  let states := matchings ends edges
  have hnonneg : ∀ N ∈ states, 0 ≤ off N - approx N := by
    intro N hN
    exact sub_nonneg.mpr (roundedMove_bounds ends edges activity b M N
      (offDiagonal_bounds ends edges activity ha M N hM hN).1).2.1
  have hOff : off M - approx M = 0 := by
    dsimp only [off, approx]
    rw [offDiagonal_self, roundedMove_zero ends edges activity b M M
      (offDiagonal_self ends edges activity M), sub_zero]
  let targets := states.filter (Adjacent ends M)
  have hsubset : targets ⊆ edges.image (proposal ends M) := by
    intro N hN
    have hn := Finset.mem_filter.mp hN
    obtain ⟨e, he, h⟩ := adjacent_has_proposal ends edges M N hM hn.1 hn.2
    exact Finset.mem_image.mpr ⟨e, he, h⟩
  have hcard : targets.card ≤ edges.card :=
    (Finset.card_le_card hsubset).trans Finset.card_image_le
  have hzero (N : Finset E) (hn : ¬ Adjacent ends M N) : off N - approx N = 0 := by
    have hOff : off N = 0 := by simp [off, offDiagonal, hn]
    rw [hOff, show approx N = 0 from roundedMove_zero ends edges activity b M N hOff, sub_zero]
  have hsumTarget : (∑ N ∈ states, (off N - approx N)) ≤
      (edges.card : ℝ) * ((2 : ℝ)^b)⁻¹ := by
    calc
      _ = ∑ N ∈ targets, (off N - approx N) := by
        exact (Finset.sum_filter_of_ne (fun N _ hne => by
          by_contra hn
          exact hne (hzero N hn))).symm
      _ ≤ (targets.card : ℝ) * ((2 : ℝ)^b)⁻¹ := by
        rw [← nsmul_eq_mul, ← Finset.sum_const]
        exact Finset.sum_le_sum fun N hN => (roundedMove_bounds ends edges activity b M N
          (offDiagonal_bounds ends edges activity ha M N hM (Finset.mem_filter.mp hN).1).1).2.2.le
      _ ≤ _ := mul_le_mul_of_nonneg_right (by exact_mod_cast hcard) (by positivity)
  have hErase := Finset.sum_erase_add states (fun N => off N - approx N) hM
  change (∑ N ∈ states.erase M, (off N - approx N)) + (off M - approx M) =
    ∑ N ∈ states, (off N - approx N) at hErase
  rw [hOff, add_zero] at hErase
  have htotal : 0 ≤ ∑ N ∈ states, (off N - approx N) := Finset.sum_nonneg hnonneg
  unfold variation
  rw [← Finset.sum_erase_add _ _ hM]
  have hmoving :
      (∑ N ∈ states.erase M, |roundedTransition ends edges activity b M N -
          transition ends edges activity M N|) = ∑ N ∈ states.erase M, (off N - approx N) := by
    apply Finset.sum_congr rfl
    intro N hN
    have hne : M ≠ N := (Finset.mem_erase.mp hN).1.symm
    have hm := hnonneg N (Finset.mem_erase.mp hN).2
    dsimp only [off, approx] at hm ⊢
    rw [roundedTransition, transition, if_neg hne, if_neg hne, abs_sub_comm, abs_of_nonneg hm]
  have hholding : roundedTransition ends edges activity b M M - transition ends edges activity M M
      = ∑ N ∈ states, (off N - approx N) := by
    rw [roundedTransition, transition, if_pos rfl, if_pos rfl, Finset.sum_sub_distrib]
    dsimp only [off, approx, states]
    ring
  change ((∑ N ∈ states.erase M, _) + |roundedTransition ends edges activity b M M -
    transition ends edges activity M M|) / 2 ≤ _
  rw [hmoving, hholding, abs_of_nonneg htotal, hErase]
  linarith

/-- To compute the count of moving cells, scan stored edges. Each admissible
proposal finds a distinct feasible target; all others have weight zero. -/
theorem moveCells_sum_proposals (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (b : ℕ) (M : Finset E) (hM : M ∈ matchings ends edges) :
    (∑ N ∈ matchings ends edges, moveCells ends edges activity b M N) =
      ∑ e ∈ edges, moveCells ends edges activity b M (proposal ends M e) := by
  classical
  have hzero (N : Finset E) (h : ¬ Adjacent ends M N) :
      moveCells ends edges activity b M N = 0 := by
    simp [moveCells, offDiagonal, h]
  let valid := edges.filter (fun e => proposal ends M e ≠ M)
  let targets := (matchings ends edges).filter (Adjacent ends M)
  have hleft :
      (∑ N ∈ matchings ends edges, moveCells ends edges activity b M N) =
        ∑ N ∈ targets, moveCells ends edges activity b M N := by
    exact (Finset.sum_filter_of_ne fun N _ h => by
      by_contra hAdj
      exact h (hzero N hAdj)).symm
  have hright :
      (∑ e ∈ edges, moveCells ends edges activity b M (proposal ends M e)) =
        ∑ e ∈ valid, moveCells ends edges activity b M (proposal ends M e) := by
    exact (Finset.sum_filter_of_ne fun e _ h => by
      intro hp
      exact h (by simp [hp, moveCells, offDiagonal_self])).symm
  rw [hleft, hright]
  symm
  apply Finset.sum_bij (fun e _ => proposal ends M e)
  · intro e he
    obtain ⟨heEdge, hne⟩ := Finset.mem_filter.mp he
    exact Finset.mem_filter.mpr ⟨proposal_mem_matchings ends edges M hM e heEdge,
      proposal_adjacent ends M _ e rfl (Ne.symm hne)⟩
  · intro e he d _ heq
    exact proposal_unique ends M _ e d rfl heq.symm (Ne.symm (Finset.mem_filter.mp he).2)
  · intro N hN
    obtain ⟨e, he, hp⟩ := adjacent_has_proposal ends edges M N hM
      (Finset.mem_filter.mp hN).1 (Finset.mem_filter.mp hN).2
    have hne := (Finset.mem_filter.mp hN).2.1
    exact ⟨e, Finset.mem_filter.mpr ⟨he, fun heq => hne (heq.symm.trans hp)⟩, hp⟩
  · intro _ _
    rfl

/-- Exact dyadic holding count complements the moving cells to the full word.
All off-diagonal cells are therefore obtained from one uniform b-bit word. -/
theorem roundedTransition_cell_counts (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (b : ℕ) (ha : ∀ e ∈ edges, 0 ≤ activity e)
    (M : Finset E) (hM : M ∈ matchings ends edges) :
    ∃ count : Finset E → ℕ,
      (∑ N ∈ matchings ends edges, count N) = 2^b ∧
      ∀ N ∈ matchings ends edges,
        roundedTransition ends edges activity b M N = (count N : ℝ) / (2 : ℝ)^b := by
  classical
  let states := matchings ends edges
  let moves := moveCells ends edges activity b M
  let q : ℕ := 2^b
  have hq : (0 : ℝ) < q := by dsimp [q]; positivity
  have hfloor :
      (∑ N ∈ states, roundedMove ends edges activity b M N) =
        ((∑ N ∈ states, moves N : ℕ) : ℝ) / (q : ℝ) := by
    simp only [Nat.cast_sum, Nat.cast_pow, Nat.cast_ofNat, ← Finset.sum_div, roundedMove, q, moves]
  have hle := Finset.sum_le_sum fun N hN => (roundedMove_bounds ends edges activity b M N
          (offDiagonal_bounds ends edges activity ha M N hM hN).1).2.1
  rw [hfloor] at hle
  have hsum : (∑ N ∈ states, moves N) ≤ q := by
    apply_mod_cast (div_le_one hq).mp (hle.trans
      ((offDiagonal_outgoing_le_half ends edges activity ha M hM).trans (by norm_num)))
  let count := fun N => if M = N then q - ∑ P ∈ states, moves P else moves N
  have hcount (N : Finset E) :
      roundedTransition ends edges activity b M N = (count N : ℝ) / (q : ℝ) := by
    by_cases h : M = N
    · rw [roundedTransition, if_pos h, hfloor]
      simp only [count, if_pos h, Nat.cast_sub hsum]
      rw [sub_div, div_self hq.ne']
    · simp [roundedTransition, h, roundedMove, count, moves, q]
  refine ⟨count, ?_, ?_⟩
  · have ht := ((roundedTransition_isKernel ends edges activity b ha).rows M hM).total
    simp_rw [hcount] at ht
    rw [← Finset.sum_div, div_eq_iff hq.ne', one_mul, ← Nat.cast_sum] at ht
    exact_mod_cast ht
  · intro N _
    simpa [q] using hcount N

/-- Approximate sampler using the actual compensated grid kernel, with
the external spectral estimate exposed as the only mixing premise. -/
theorem rounded_gibbs_mixing (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (hActivity : ∀ e ∈ edges, 0 < activity e)
    (γ : ℝ) (hγ : γ ≤ 1)
    (hcontract : ∀ f : Finset E → ℝ,
      (∑ M ∈ matchings ends edges, probability ends edges activity M * f M) = 0 →
      squareEnergy (matchings ends edges) (probability ends edges activity)
        (actOnFunctions (matchings ends edges) (transition ends edges activity) f) ≤
      (1-γ)^2 * squareEnergy (matchings ends edges) (probability ends edges activity) f)
    (t k b : ℕ) (δ : ℝ)
    (ht : (∑ e ∈ edges, activity e) / 2 + k ≤ γ * t)
    (hδ : 1 ≤ δ * (2 : ℝ)^k)
    (hbudget : t * ((edges.card : ℝ) * ((2 : ℝ)^b)⁻¹) ≤ δ / 2) :
    variation (matchings ends edges)
      (iterateKernel (matchings ends edges)
        (roundedTransition ends edges activity b) (pointMass ∅) t)
      (probability ends edges activity) ≤ δ := by
  have ha : ∀ e ∈ edges, 0 ≤ activity e := fun e he => (hActivity e he).le
  exact gibbs_approximate_mixing_budget ends edges activity hActivity γ hγ hcontract t k δ ht hδ
    _ (roundedTransition_isKernel ends edges activity b ha) _
    (fun M hM => roundedTransition_rowError ends edges activity b ha M hM) hbudget

end SubmodularMatching.GibbsSampler
