import SubmodularMatching.CapacityGuessScheduler
import SubmodularMatching.StreamingK1RealProgram

/-! Generic forward epoch scheduler and the physical minimum-slot source. -/
namespace SubmodularMatching.Capacity.RealOracle

noncomputable section
open Streaming
variable {X : Type*}

/-- All persistent payloads belong to currently active guesses. -/
structure GuessBank (X : Type*) where
  epoch : RealSource.OnlineEpoch
  states : List (ℕ × X)

def GuessBank.empty : GuessBank X := ⟨RealSource.OnlineEpoch.empty,[]⟩

def GuessBank.lookup (st : GuessBank X) (j : ℕ) := st.states.lookup j

def GuessBank.advance (st : GuessBank X) (fresh : X) (W : ℝ) (span : ℕ)
    (value : ℝ) (action : ℕ → ℝ → X → X) : GuessBank X :=
  let ep := st.epoch.step W span value
  let reset := st.epoch.resets W value
  ⟨ep,(ep.active W span).map fun j =>
    (j,action j (ep.scale j) (if reset then fresh else (st.lookup j).getD fresh))⟩

def GuessBank.run (fresh : X) (W : ℝ) (span : ℕ) (value : ℕ → ℝ)
    (action : ℕ → ℕ → ℝ → X → X) : ℕ → GuessBank X
  | 0 => .empty
  | k+1 => (run fresh W span value action k).advance fresh W span (value k) (action k)

theorem GuessBank.clock (fresh : X) (W : ℝ) (span : ℕ) (value : ℕ → ℝ)
    (act : ℕ → ℕ → ℝ → X → X) (k : ℕ) :
    (GuessBank.run fresh W span value act k).epoch = RealSource.runOnlineEpoch W span value k := by
  induction k with
  | zero => rfl
  | succ n ih => simp only [GuessBank.run,GuessBank.advance,RealSource.runOnlineEpoch,ih]

private theorem lookup_map (j : ℕ) (L : List ℕ) (f : ℕ → X) :
    (L.map (fun k => (k,f k))).lookup j = if j ∈ L then some (f j) else none := by
  induction L with
  | nil => simp
  | cons i is ih =>
    by_cases h : i=j
    · subst i; simp [List.lookup]
    · have hb : (j == i) = false := beq_eq_false_iff_ne.mpr (Ne.symm h)
      simp [List.lookup,hb,Ne.symm h,ih]

open scoped Classical in
theorem GuessBank.active_suffix (fresh : X) (W : ℝ) (span : ℕ) (value : ℕ → ℝ)
    (act : ℕ → ℕ → ℝ → X → X) (hW : 1 ≤ W) (hspan : W ≤ 2^span) (k j : ℕ) :
    let v := fun i => (value i : ℝ)
    let F := fun i => act i j ((RealSource.runOnlineEpoch W span value (i+1)).scale j)
    let birth := guessBirth W v j k
    (GuessBank.run fresh W span value act k).lookup j =
      if guessActive W (guessAnchor W v k) (singletonMaximum v k) j then
        some (suffixRun fresh F birth (k-birth)) else none := by
  classical
  let v := fun i => (value i : ℝ)
  let F := fun i => act i j ((RealSource.runOnlineEpoch W span value (i+1)).scale j)
  induction k with
  | zero => simp [GuessBank.run,GuessBank.lookup,GuessBank.empty,guessActive,singletonMaximum]
  | succ k ih =>
    dsimp only at ih ⊢
    let ep := RealSource.runOnlineEpoch W span value k
    let ep' := RealSource.runOnlineEpoch W span value (k+1)
    let old := GuessBank.run fresh W span value act k
    let prior := guessActive (W:ℝ) (guessAnchor W v k) (singletonMaximum v k) j
    let reset := ep.resets W (value k)
    have ha := RealSource.runOnlineEpoch_active_iff W span value hW hspan (k+1) j
    have hr := RealSource.runOnlineEpoch_resets_iff W span value k
    have hb : guessBirth W v j (k+1) =
        if reset=true ∨ ¬prior then k else guessBirth W v j k := by
      rw [guessBirth]
      exact if_congr (or_congr hr.symm Iff.rfl) rfl rfl
    have heq : old.epoch = ep := GuessBank.clock _ _ _ _ _ _
    let born := guessBirth W v j k
    have hold : old.lookup j = if prior then some (suffixRun fresh F born (k-born)) else none := ih
    change (old.advance fresh W span (value k) (act k)).lookup j = _
    simp only [GuessBank.lookup,GuessBank.advance,lookup_map]
    rw [heq]
    change (if j ∈ ep'.active W span then some (F k (if reset then fresh else
      (old.lookup j).getD fresh)) else none) = _
    rw [if_congr ha rfl rfl]
    by_cases hactive : guessActive (W:ℝ) (guessAnchor W v (k+1)) (singletonMaximum v (k+1)) j
    · rw [if_pos hactive,if_pos hactive]
      change some (F k (if reset then fresh else (old.lookup j).getD fresh)) =
        some (suffixRun fresh F (guessBirth W v j (k+1)) (k+1-guessBirth W v j (k+1)))
      rw [hb,hold]
      by_cases h : reset=true ∨ ¬prior
      · rw [if_pos h]
        simp only [Nat.add_sub_cancel_left,suffixRun,Nat.add_zero]
        rcases h with hr|hn
        · simp [hr]
        · simp [hn]
      · have hn := (not_or.mp h).1
        have hp := Classical.not_not.mp (not_or.mp h).2
        have hbirth : born ≤ k := by
          cases k with
          | zero => simp [born,guessBirth]
          | succ l => exact (guessBirth_lt W v j l).le
        rw [if_neg h,if_neg hn, if_pos hp]
        change some (F k (suffixRun fresh F born (k-born))) =
          some (suffixRun fresh F born (k+1-born))
        rw [show k+1-born = (k-born)+1 by omega,suffixRun,Nat.add_sub_of_le hbirth]
    · rw [if_neg hactive,if_neg hactive]

theorem GuessBank.state_count (st : GuessBank X) (fresh : X) (W : ℝ) (span : ℕ)
    (value : ℝ) (action : ℕ → ℝ → X → X) :
    (st.advance fresh W span value action).states.length ≤ span+1 := by
  simp only [GuessBank.advance,List.length_map,RealSource.OnlineEpoch.active]
  split_ifs
  · exact (List.length_filter_le _ _).trans (by simp)
  · simp

end

end SubmodularMatching.Capacity.RealOracle
