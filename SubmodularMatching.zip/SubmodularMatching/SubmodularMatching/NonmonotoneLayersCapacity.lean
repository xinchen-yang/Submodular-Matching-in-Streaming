import SubmodularMatching.NonmonotoneLayersFiber
import SubmodularMatching.NonmonotoneLayersDecoder

/-! Action decoding on the projected labels of the two capacitated layers. -/

namespace SubmodularMatching.NonmonotoneLayers

open NonmonotoneOptimizer Set Shearer

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The two independent layers have product avoidance probability on a fiber. -/
def unionMass (ends : E → Finset V) (F : Finset E) (a b : E → ℝ) (t : ℝ) : ℝ :=
  1-fiberZ ends F a t * fiberZ ends F b t

/-- An arbitrary finite fiber, including all slot pairs of an original edge.
Only positivity of the actual Shearer laws and their normalized marginal
rates are needed. This directly applies also to nonuniform copy proportions. -/
theorem decode_fiber (ends : E → Finset V) (F : Finset E) (a b : E → ℝ)
    (ha : ∀ e ∈ F, 0 ≤ a e) (hb : ∀ e ∈ F, 0 ≤ b e)
    (hnorm : (∑ e ∈ F, a e) + (∑ e ∈ F, b e) = 1)
    (d u : ℝ) (hd : 0 < d) (hd1 : d < 1) (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (hpos₁ : ∀ t ∈ Icc 0 d, InteriorLaw ends F (fun e => t*a e))
    (hpos₂ : ∀ t ∈ Icc 0 d, InteriorLaw ends F (fun e => t*b e)) :
    ∃! y : ℝ, y ∈ Icc 0 (d*u) ∧ unionMass ends F a b y = action (1/d) u := by
  let Z := fiberZ ends F
  let D := fiberSlope ends F
  let m := unionMass ends F a b
  let m' := fun t => D a t * Z b t + Z a t * D b t
  have hdv (t : ℝ) : HasDerivAt m (m' t) t := by
    convert (hasDerivAt_const t (1:ℝ)).sub
      ((fiberZ_hasDerivAt ends F a t).mul (fiberZ_hasDerivAt ends F b t)) using 1
    dsimp [m', D, Z]; ring
  have hz : m 0 = 0 := by simp [m,unionMass,fiberZ_zero]
  have hupp (t : ℝ) (ht : t ∈ Icc 0 d) : m' t ≤ 1 := by
    obtain ⟨_,h1,_,h2⟩ := fiber_bounds ends F a t (hpos₁ t ht) ha
    obtain ⟨h3,h4,_,h5⟩ := fiber_bounds ends F b t (hpos₂ t ht) hb
    have hza := (fiber_bounds ends F a t (hpos₁ t ht) ha).1
    have hs₁ : 0 ≤ ∑ e ∈ F, a e := Finset.sum_nonneg ha
    have hs₂ : 0 ≤ ∑ e ∈ F, b e := Finset.sum_nonneg hb
    change fiberSlope ends F a t * fiberZ ends F b t + fiberZ ends F a t * fiberSlope ends F b t ≤ 1
    calc
      _ ≤ (∑ e ∈ F, a e) * fiberZ ends F b t + fiberZ ends F a t * (∑ e ∈ F, b e) :=
        add_le_add (mul_le_mul_of_nonneg_right h2 h3) (mul_le_mul_of_nonneg_left h5 hza)
      _ ≤ (∑ e ∈ F, a e)*1 + 1*(∑ e ∈ F, b e) := add_le_add
        (mul_le_mul_of_nonneg_left h4 hs₁) (mul_le_mul_of_nonneg_right h1 hs₂)
      _ = 1 := by simpa only [mul_one,one_mul] using hnorm
  apply decode_action m m' d u hd hd1 hu hu1 hz (fun t _ => hdv t)
  · intro t ht
    obtain ⟨h1,_,h2,_⟩ := fiber_bounds ends F a t (hpos₁ t ht) ha
    obtain ⟨h3,_,h4,_⟩ := fiber_bounds ends F b t (hpos₂ t ht) hb
    have H := add_le_add (mul_le_mul_of_nonneg_right h2 h3) (mul_le_mul_of_nonneg_left h4 h1)
    dsimp [m,unionMass,m',Z,D]
    nlinarith only [H, congrArg (fun z : ℝ => z * fiberZ ends F a t * fiberZ ends F b t) hnorm]
  · intro t ht
    have hf := (convex_Icc (0:ℝ) d).image_sub_le_mul_sub_of_deriv_le
      (fun x _ => (hdv x).continuousAt.continuousWithinAt)
      (fun x _ => (hdv x).differentiableAt.differentiableWithinAt)
      (fun x hx => (hdv x).deriv ▸ hupp x (interior_subset hx))
      0 (left_mem_Icc.mpr hd.le) t ht ht.1
    rw [hz] at hf
    linarith only [hf,ht.2]

/-- The marginal degree condition for each isolated fiber follows from its
entire mass, so the decoder needs no separate Shearer-law assumption. -/
theorem decode_uniform_fiber (ends : E → Finset V) (F : Finset E) (hF : F.Nonempty)
    (hends : ∀ e ∈ F, (ends e).card = 2) (θ₁ θ₂ d u : ℝ)
    (h₁ : 0 ≤ θ₁) (h₂ : 0 ≤ θ₂) (hs : θ₁+θ₂=1)
    (hd : 0 < d) (hd1 : d < 1) (hc₁ : d*θ₁ ≤ 1/4) (hc₂ : d*θ₂ ≤ 1/4)
    (hu : 0 ≤ u) (hu1 : u ≤ 1) :
    ∃! y : ℝ, y ∈ Icc 0 (d*u) ∧ unionMass ends F
      (fun _ => θ₁/F.card) (fun _ => θ₂/F.card) y = action (1/d) u := by
  have hcard : 0 < (F.card : ℝ) := by exact_mod_cast Finset.card_pos.mpr hF
  have hsumm (θ : ℝ) : (∑ _e ∈ F, θ/(F.card : ℝ)) = θ := by
    simp only [Finset.sum_const,nsmul_eq_mul]
    field_simp [hcard.ne']
  have hlaw (θ : ℝ) (hθ : 0 ≤ θ) (hcap : d*θ ≤ 1/4) (t : ℝ) (ht : t ∈ Icc 0 d) :
      InteriorLaw ends F (fun _ => t*(θ/F.card)) := by
    have hrate := div_nonneg hθ hcard.le
    apply interiorLaw_of_degree (1/2) (by norm_num) (by norm_num) (fun _ _ => mul_nonneg ht.1 hrate) hends
    intro v
    have hI : GibbsMatching.incident ends F v ⊆ F := Finset.filter_subset _ _
    have hle := Finset.sum_le_sum_of_subset_of_nonneg (f := fun _ : E => t*(θ/F.card)) hI
      (fun _ _ _ => mul_nonneg ht.1 hrate)
    have hsum' : (∑ _e ∈ F, t*(θ/F.card)) = t*θ := by rw [← Finset.mul_sum,hsumm]
    change (∑ _e ∈ GibbsMatching.incident ends F v, t*(θ/F.card)) ≤ ∑ _e ∈ F, t*(θ/F.card) at hle
    rw [hsum'] at hle
    nlinarith only [hle,hcap,mul_le_mul_of_nonneg_right ht.2 hθ]
  exact decode_fiber ends F _ _ (fun _ _ => div_nonneg h₁ hcard.le)
    (fun _ _ => div_nonneg h₂ hcard.le) (by rw [hsumm,hsumm,hs])
    d u hd hd1 hu hu1 (hlaw θ₁ h₁ hc₁) (hlaw θ₂ h₂ hc₂)

end

end SubmodularMatching.NonmonotoneLayers
