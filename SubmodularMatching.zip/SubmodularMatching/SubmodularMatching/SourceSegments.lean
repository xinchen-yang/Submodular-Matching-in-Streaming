import SubmodularMatching.SourcePotential
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-!
# Integrating source inequalities along actual affine update segments

Each segment has positive endpoint rates and a nonnegative duration. Ratio
membership is checked at its two endpoints; an elementary affine argument
propagates it throughout. The auxiliary potential is the integral from
`SourcePotential`, and the mean value theorem converts its proved derivative
bound to a finite increment inequality, including zero initial potentials.
-/

namespace SubmodularMatching.SourceCertificate

open MeasureTheory Set

noncomputable section

/-- Analytic data needed from either source function. These conditions hold for
the paper's continuous piecewise-affine, bounded, nonnegative functions that
vanish near zero; the weighted integral budget is supplied separately. -/
structure SourceFunction where
  value : ℝ → ℝ
  continuous : Continuous value
  at_zero : value 0 = 0
  nonnegative : ∀ a, 0 ≤ a → 0 ≤ value a
  integrable : IntegrableOn (fun a => value a / a ^ 2) (Ioi 0)

theorem affine_nonnegative_between (a b T x : ℝ)
    (hstart : 0 ≤ a) (hfinish : 0 ≤ a + b * T) (hx : 0 ≤ x) (hxT : x ≤ T) :
    0 ≤ a + b * x := by
  by_cases hb : 0 ≤ b
  · exact add_nonneg hstart (mul_nonneg hb hx)
  · have h := mul_nonpos_of_nonpos_of_nonneg (le_of_not_ge hb) (sub_nonneg.mpr hxT)
    nlinarith

/-- Four linear endpoint checks certify ratio membership over an entire
constant-rate segment, even when its two initial potentials are both zero. -/
theorem segment_ratio_bounds (u v A B lo hi T x : ℝ)
    (hu : 0 ≤ u) (hv : 0 ≤ v) (hA : 0 < A) (hB : 0 < B)
    (hx : 0 < x) (hxT : x ≤ T)
    (hstart : lo * (u + v) ≤ u ∧ u ≤ hi * (u + v))
    (hfinish : lo * ((u + A * T) + (v + B * T)) ≤ u + A * T ∧
      u + A * T ≤ hi * ((u + A * T) + (v + B * T))) :
    lo ≤ (u + A * x) / ((u + A * x) + (v + B * x)) ∧
      (u + A * x) / ((u + A * x) + (v + B * x)) ≤ hi := by
  have hpos : 0 < (u + A * x) + (v + B * x) := by
    nlinarith [mul_pos hA hx, mul_pos hB hx]
  have hlo := affine_nonnegative_between (u - lo * (u + v)) (A - lo * (A + B)) T x
    (by linarith [hstart.1]) (by nlinarith [hfinish.1]) hx.le hxT
  have hhi := affine_nonnegative_between (hi * (u + v) - u) (hi * (A + B) - A) T x
    (by linarith [hstart.2]) (by nlinarith [hfinish.2]) hx.le hxT
  constructor
  · apply (le_div_iff₀ hpos).2
    nlinarith
  · apply (div_le_iff₀ hpos).2
    nlinarith

/-- Combined auxiliary potential during one fixed pair of update rates. -/
def segmentValue (H J : SourceFunction) (sH sL t priceH priceL u v A B x : ℝ) : ℝ :=
  auxiliary H.value sH t priceH (u + A * x) +
    auxiliary J.value sL t priceL (v + B * x)

theorem segmentValue_continuous (H J : SourceFunction)
    (sH sL t priceH priceL u v A B : ℝ)
    (ht : 0 < t) (hpriceH : 0 ≤ priceH) (hpriceL : 0 ≤ priceL) :
    Continuous (segmentValue H J sH sL t priceH priceL u v A B) := by
  exact ((auxiliary_continuous H.value sH t priceH ht hpriceH H.at_zero H.integrable).comp
    (continuous_const.add (continuous_const.mul continuous_id))).add
    ((auxiliary_continuous J.value sL t priceL ht hpriceL J.at_zero J.integrable).comp
      (continuous_const.add (continuous_const.mul continuous_id)))

theorem segmentValue_hasDerivAt (H J : SourceFunction)
    (sH sL t priceH priceL u v A B x : ℝ)
    (ht : 0 < t) (hpriceH : 0 ≤ priceH) (hpriceL : 0 ≤ priceL)
    (hu : 0 < u + A * x) (hv : 0 < v + B * x) :
    HasDerivAt (segmentValue H J sH sL t priceH priceL u v A B)
      (sH * A * H.value (priceH / (t * (u + A * x))) +
        sL * B * J.value (priceL / (t * (v + B * x)))) x := by
  have hlineH : HasDerivAt (fun z : ℝ => u + A * z) A x := by
    convert (hasDerivAt_const x u).add ((hasDerivAt_id x).const_mul A) using 1
    ring
  have hlineL : HasDerivAt (fun z : ℝ => v + B * z) B x := by
    convert (hasDerivAt_const x v).add ((hasDerivAt_id x).const_mul B) using 1
    ring
  have hdH := (auxiliary_hasDerivAt H.value sH t priceH (u + A * x)
    ht hpriceH hu H.at_zero H.integrable H.continuous).comp x hlineH
  have hdL := (auxiliary_hasDerivAt J.value sL t priceL (v + B * x)
    ht hpriceL hv J.at_zero J.integrable J.continuous).comp x hlineL
  convert hdH.add hdL using 1
  ring

/-- The main local-to-finite-increment implication of Lemma 3.4.
The two endpoint-ratio inequalities are universal only in the dual arguments;
all path scaling and differentiation steps are proved in this theorem. -/
theorem segment_increment (H J : SourceFunction)
    (sH sL t priceH priceL u v A B k lo hi target w T : ℝ)
    (ht : 0 < t) (hpriceH : 0 ≤ priceH) (hpriceL : 0 ≤ priceL)
    (hu : 0 ≤ u) (hv : 0 ≤ v) (hA : 0 < A) (hB : 0 < B)
    (hk : 0 ≤ k) (hT : 0 ≤ T)
    (hstart : lo * (u + v) ≤ u ∧ u ≤ hi * (u + v))
    (hfinish : lo * ((u + A * T) + (v + B * T)) ≤ u + A * T ∧
      u + A * T ≤ hi * ((u + A * T) + (v + B * T)))
    (hscale : t * ((u + A * T) + (v + B * T)) ≤ w)
    (hlocal : ∀ a d, 0 ≤ a → 0 ≤ d →
      target ≤ localValue H.value J.value sH sL A B k lo a d ∧
        target ≤ localValue H.value J.value sH sL A B k hi a d) :
    target * T ≤
      (auxiliary H.value sH t priceH (u + A * T) - auxiliary H.value sH t priceH u) +
      (auxiliary J.value sL t priceL (v + B * T) - auxiliary J.value sL t priceL v) +
        T * k * max (1 - (priceH + priceL) / w) 0 := by
  have hc := segmentValue_continuous H J sH sL t priceH priceL u v A B ht hpriceH hpriceL
  have hd (x : ℝ) (hx : x ∈ Ioo 0 T) := segmentValue_hasDerivAt H J
    sH sL t priceH priceL u v A B x ht hpriceH hpriceL
    (by nlinarith [mul_pos hA hx.1]) (by nlinarith [mul_pos hB hx.1])
  have hdiff : DifferentiableOn ℝ (segmentValue H J sH sL t priceH priceL u v A B)
      (interior (Icc 0 T)) := by
    intro x hx
    exact (hd x (by simpa only [interior_Icc] using hx)).differentiableAt.differentiableWithinAt
  have hrate : ∀ x ∈ interior (Icc 0 T),
      target - k * max (1 - (priceH + priceL) / w) 0 ≤
        deriv (segmentValue H J sH sL t priceH priceL u v A B) x := by
    intro x hx
    have hx' : x ∈ Ioo 0 T := by simpa only [interior_Icc] using hx
    rw [(hd x hx').deriv]
    have hpot : (u + A * x) + (v + B * x) ≤ (u + A * T) + (v + B * T) := by
      nlinarith [mul_nonneg hA.le (sub_nonneg.mpr hx'.2.le),
        mul_nonneg hB.le (sub_nonneg.mpr hx'.2.le)]
    have hscale' := (mul_le_mul_of_nonneg_left hpot ht.le).trans hscale
    have h := local_to_scaled_slack H.value J.value sH sL A B k lo hi target
      (u + A * x) (v + B * x) t w priceH priceL hk
      (by nlinarith [mul_pos hA hx'.1]) (by nlinarith [mul_pos hB hx'.1]) ht hpriceH hpriceL
      (segment_ratio_bounds u v A B lo hi T x hu hv hA hB hx'.1 hx'.2.le hstart hfinish)
      hscale' hlocal
    linarith
  have hstep := (convex_Icc (0 : ℝ) T).mul_sub_le_image_sub_of_le_deriv
    hc.continuousOn hdiff hrate 0 ⟨le_rfl, hT⟩ T ⟨hT, le_rfl⟩ hT
  simp only [segmentValue, mul_zero, add_zero, sub_zero] at hstep
  nlinarith

end

end SubmodularMatching.SourceCertificate
