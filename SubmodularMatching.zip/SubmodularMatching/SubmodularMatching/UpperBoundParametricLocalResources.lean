import SubmodularMatching.UpperBoundParametricRoundingGrid
import SubmodularMatching.UpperBoundParametricSchedule
import SubmodularMatching.UpperBoundVertexSamplerBudget

/-! # Uniform local polynomial bounds for every fixed family parameter -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint NumericalCertificate GibbsSampler
open scoped BigOperators

noncomputable section

variable {m : ℕ} {V : Type*} [DecidableEq V]

/-- A uniform squared bound for the actual Euler stage count. -/
theorem parametricOptimizer_stages_le (K : ℕ) (hK : 0 < K) (m : ℕ) :
    FiniteGreedy.stages NumericalCertificate.degree m (1 / (K : ℝ)) ≤ (2 * K + 1) * (m + 1) ^ 2 := by
  have h := stages_polynomial NumericalCertificate.degree (1 / (K : ℝ)) m degree_bounds.1.le
    (by linarith [degree_bounds.2]) (by positivity : (0 : ℝ) < 1 / K)
  have hcast : (FiniteGreedy.stages NumericalCertificate.degree m (1 / (K : ℝ)) : ℝ) ≤
      (2 * K) * (m : ℝ) ^ 2 + 1 := by
    convert h using 1
    rw [div_div_eq_mul_div, div_one]; ring
  have hnat : FiniteGreedy.stages NumericalCertificate.degree m (1 / (K : ℝ)) ≤
      (2 * K) * m ^ 2 + 1 := by exact_mod_cast hcast
  apply hnat.trans
  calc
    _ ≤ (2 * K) * (m + 1) ^ 2 + (m + 1) ^ 2 := by
      apply Nat.add_le_add
      · exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (Nat.le_succ m) _)
      · exact one_le_pow₀ (by omega)
    _ = _ := by ring

/-- The corresponding bounded loop length and radius for every direction. -/
theorem parametricPacking_loop_bounds (K : ℕ) (hK : 0 < K) (hm : 0 < m) (ends : Fin m → V × V) :
    let M := Fintype.card (IncidentVertex ends ⊕ IncidentVertex ends ⊕ Fin m)
    let L := Fintype.card (Fin m ⊕ Fin m)
    let b := (8 * K)
    Nat.ceil (4 * (L : ℝ) ^ 2 / ((1 / (K : ℝ)) / 8)) ≤ (20 * b) * (m + 1) ^ 2 ∧
      LinearPacking.iterationCount M L ((1 / (K : ℝ)) / 8) ≤
        (160000 * b ^ 4 + 1) * (m + 1) ^ 8 ∧
      LinearPacking.rationalOutputDenominator M L 1 b ≤
        ((160000 * b ^ 4 + 1) * (5 * b)) * (m + 1) ^ 9 := by
  intro M L b
  have hM : 0 < M := by
    dsimp [M]
    simp only [Fintype.card_sum, Fintype.card_fin]
    omega
  have hdim := compactPacking_dimensions ends
  have hL : L = 2 * m := hdim.2
  have hp : 0 < L := by omega
  have hm' : 1 ≤ m + 1 := by omega
  have hb : 0 < b := by dsimp [b]; omega
  have he : (1 / (K : ℝ)) / 8 = ((1 : ℕ) : ℝ) / (b : ℝ) := by
    dsimp only [b]
    rw [div_div, Nat.cast_mul, Nat.cast_one, Nat.cast_ofNat, mul_comm (K : ℝ)]
  have hr := LinearPacking.rational_iteration_resources M L 1 b hM hp (by decide) hb (by omega)
  dsimp only at hr
  rw [he]
  have hJ0 : 100 * M ^ 2 * L ^ 6 * b ^ 4 + 1 ≤
      (160000 * b ^ 4 + 1) * (m + 1) ^ 8 := by
    have hM' : M ≤ 5 * (m + 1) := hdim.1.trans (by omega)
    have hL' : L ≤ 2 * (m + 1) := by omega
    calc
      _ ≤ 100 * (5 * (m + 1)) ^ 2 * (2 * (m + 1)) ^ 6 * b ^ 4 + (m + 1) ^ 8 := by
        gcongr
        exact one_le_pow₀ hm'
      _ = _ := by ring
  refine ⟨hr.1.trans ?_, hr.2.1.trans hJ0, hr.2.2.trans ?_⟩
  · rw [hL]
    calc
      _ ≤ 5 * (2 * (m + 1)) ^ 2 * b := by gcongr; omega
      _ = _ := by ring
  · have hL0 : 2 * L * b + b ≤ (5 * b) * (m + 1) := by
      rw [hL]
      calc
        _ ≤ 2 * (2 * (m + 1)) * b + b * (m + 1) := by
          apply Nat.add_le_add
          · exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ (Nat.le_succ m)))
          · exact Nat.le_mul_of_pos_right _ (by omega)
        _ = _ := by ring
    calc
      _ ≤ ((160000 * b ^ 4 + 1) * (m + 1) ^ 8) * ((5 * b) * (m + 1)) :=
        Nat.mul_le_mul hJ0 hL0
      _ = _ := by ring

/-- The common first-stage coordinate denominator has a fixed polynomial
bound in the stored graph size. -/
theorem parametricShearerDenominator_le (K : ℕ) (hK : 0 < K) (hm : 0 < m) (ends : Fin m → V × V) :
    let b := (8 * K)
    let C := 62500000000000000000000 * (2 * K + 1) * ((160000 * b ^ 4 + 1) * (5 * b))
    parametricShearerDenominator (Fintype.card (IncidentVertex ends)) m K ≤ C * (m + 1) ^ 11 := by
  intro b C
  have h := (parametricPacking_loop_bounds K hK hm ends).2.2
  simp only [Fintype.card_sum, Fintype.card_fin] at h
  unfold parametricShearerDenominator
  calc
    _ ≤ 62500000000000000000000 * (((2 * K + 1) * (m + 1) ^ 2) *
        (((160000 * b ^ 4 + 1) * (5 * b)) * (m + 1) ^ 9)) := by
      exact Nat.mul_le_mul_left _ (Nat.mul_le_mul (parametricOptimizer_stages_le K hK m) h)
    _ = _ := by dsimp only [C]; ring



theorem parametricAccuracy_inv_le {m : ℕ} (K : ℕ) (hK : 0 < K) (hm : 0 < m) :
    (FiniteGreedy.accuracy NumericalCertificate.degree m (1 / (K : ℝ)))⁻¹ ≤
      (16 * (K : ℝ)) * (m + 1 : ℕ) := by
  have hm' : (0 : ℝ) < m := by exact_mod_cast hm
  have hD : NumericalCertificate.degree ≤ 1 := by linarith [degree_bounds.2]
  have hcap : (0 : ℝ) < (16 * (K : ℝ)) * (m + 1 : ℕ) := by positivity
  have he : (0 : ℝ) < 1 / K := by positivity
  have h := parametricAccuracy_pos _ he hm
  rw [← one_div, div_le_iff₀ h]
  have h' : (1 : ℝ) / ((16 * (K : ℝ)) * (m + 1 : ℕ)) ≤
      FiniteGreedy.accuracy NumericalCertificate.degree m (1 / (K : ℝ)) := by
    unfold FiniteGreedy.accuracy
    apply le_min
    · rw [div_le_iff₀ hcap]
      push_cast
      have hKr : (1 : ℝ) ≤ K := by exact_mod_cast hK
      have hm0 : (0 : ℝ) ≤ m := Nat.cast_nonneg m
      nlinarith only [hKr, hm0, mul_nonneg (sub_nonneg.mpr hKr) hm0]
    · have hden : 0 < 16 * NumericalCertificate.degree * (m : ℝ) :=
        mul_pos (mul_pos (by norm_num) degree_bounds.1) hm'
      rw [div_le_div_iff₀ hcap hden]
      have hDm := mul_le_mul_of_nonneg_right hD hm'.le
      have hcoeff : (1 / (K : ℝ)) * (16 * (K : ℝ)) = 16 := by
        have hk0 : (K : ℝ) ≠ 0 := by exact_mod_cast hK.ne'
        field_simp [hk0]
      push_cast
      rw [← mul_assoc (1 / (K : ℝ)) ((16 * (K : ℝ)) : ℝ) ((m : ℝ) + 1), hcoeff]
      nlinarith only [hDm]
  simpa only [mul_comm] using (div_le_iff₀ hcap).mp h'



/-- The low-activity schedule uses an integer denominator for the total
variation budget. Its step count is polynomial and the dyadic word width
logarithmic in stored size. -/
theorem parametricGibbs_budget (K vertices m active : ℕ) (hv : vertices ≤ 2 * m)
    (ha : active ≤ m) :
    let D := 4 * vertices * K
    let k := lowActivityPrecision D
    let T := lowActivitySteps vertices active k
    let C := 40 * (1 + 2 * (8 * K + 1))
    let B := 2 * (C + 1) * (8 * K)
    T ≤ C * (m + 1) ^ 7 ∧
      lowActivityBits T active D ≤ (9 + B.log2 + 1) * ((m + 1).log2 + 1) := by
  intro D k T C B
  let s := m + 1
  have hs : 1 ≤ s := by dsimp [s]; omega
  have hv' : vertices ≤ 2 * s := hv.trans (Nat.mul_le_mul_left _ (Nat.le_succ _))
  have hD : D ≤ (8 * K) * s := by
    have hD' : D = (4 * K) * vertices := by dsimp [D]; ring
    rw [hD']
    calc
      _ ≤ (4 * K) * (2 * s) := Nat.mul_le_mul_left _ hv'
      _ = _ := by ring
  have hk : k ≤ (8 * K + 1) * s := by
    dsimp only [k, lowActivityPrecision]
    calc
      _ ≤ (8 * K) * s + 1 := Nat.add_le_add_right ((Nat.log2_le_self _).trans hD) _
      _ ≤ (8 * K) * s + s := Nat.add_le_add_left hs _
      _ = _ := by ring
  have ha' : active ≤ s := ha.trans (Nat.le_succ _)
  have ha1 : active + 1 ≤ s := Nat.add_le_add_right ha _
  have hmul : active + 2 * k ≤ (1 + 2 * (8 * K + 1)) * s := by
    calc
      _ ≤ s + 2 * ((8 * K + 1) * s) := Nat.add_le_add ha' (Nat.mul_le_mul_left _ hk)
      _ = _ := by ring
  have hT : T ≤ C * s ^ 7 := by
    dsimp [T, lowActivitySteps]
    calc
      _ ≤ 20 * (2 * s) * s * s ^ 4 * ((1 + 2 * (8 * K + 1)) * s) := by
        exact Nat.mul_le_mul (Nat.mul_le_mul
          (Nat.mul_le_mul (Nat.mul_le_mul_left _ hv') ha') (Nat.pow_le_pow_left ha1 _)) hmul
      _ = _ := by dsimp only [C]; ring
  have hT' : T + 1 ≤ (C + 1) * s ^ 7 := by
    have hp : 1 ≤ s ^ 7 := one_le_pow₀ hs
    calc
      _ ≤ C * s ^ 7 + s ^ 7 := Nat.add_le_add hT hp
      _ = _ := by ring
  refine ⟨hT, ?_⟩
  unfold lowActivityBits
  apply log2_width_of_polynomial
  calc
    _ ≤ 2 * ((C + 1) * s ^ 7) * s * ((8 * K) * s) :=
      Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul_left _ hT') ha1) hD
    _ = _ := by dsimp only [B, s]; ring

/-- Fixed constant controlling the integer recursive sampler fuel. -/
def parametricShearerFuelConstant (K : ℕ) : ℕ := 2048 * (2 + (32 * K).log2 + 1)

/-- Fixed constant controlling the integer rejection-attempt cutoff. -/
def parametricShearerAttemptsConstant (K : ℕ) : ℕ :=
  3 + (16 * K * (16 * (parametricShearerFuelConstant K) + 1) : ℕ).log2 + 1

/-- The actual integer Shearer recursion threshold and capped rejection
count are both logarithmic in the compact graph size. -/
theorem parametricShearer_budget (K vertices m : ℕ) (hK : 0 < K) (hpos : 0 < vertices) (hv : vertices ≤ 2 * m) :
    let δ := (1 / (K : ℝ)) / (4 * (vertices : ℝ))
    let L := appendixShearerFuel m δ
    let B := appendixShearerAttempts m L δ
    let w := (m + 1).log2 + 1
    L ≤ (parametricShearerFuelConstant K) * w ∧ B ≤ (parametricShearerAttemptsConstant K) * w := by
  intro δ L B w
  let s : ℝ := (m : ℝ) + 1
  have hsr : 1 ≤ s := by dsimp [s]; linarith only [show (0 : ℝ) ≤ m from Nat.cast_nonneg m]
  have hv0 : (vertices : ℝ) ≠ 0 := by exact_mod_cast hpos.ne'
  have hinv : δ⁻¹ = ((4 * K) : ℝ) * vertices := by
    have hk0 : (K : ℝ) ≠ 0 := by exact_mod_cast hK.ne'
    dsimp [δ]
    field_simp [hv0, hk0]
    <;> ring
  have hv' : (vertices : ℝ) ≤ 2 * s := by
    have hc : (vertices : ℝ) ≤ 2 * (m : ℝ) := by exact_mod_cast hv
    dsimp [s]
    linarith
  have hL : L ≤ (parametricShearerFuelConstant K) * w := by
    dsimp only [L, appendixShearerFuel, parametricShearerFuelConstant]
    rw [Nat.mul_assoc]
    apply Nat.mul_le_mul_left
    apply binaryBudget_polynomial
    push_cast
    rw [div_eq_mul_inv, hinv]
    change 4 * s * ((4 * K) * (vertices : ℝ)) ≤ (32 * K) * s ^ 2
    calc
      _ ≤ 4 * s * ((4 * K) * (2 * s)) := by
        exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hv' (by positivity)) (by positivity)
      _ = _ := by ring
  refine ⟨hL, ?_⟩
  have hw' : (w : ℝ) ≤ 2 * s := by
    have hh : w ≤ 2 * (m + 1) := by
      have h := Nat.log2_le_self (m + 1)
      dsimp [w]
      omega
    dsimp [s]
    exact_mod_cast hh
  let A := (parametricShearerFuelConstant K)
  have hA : (L : ℝ) ≤ (A : ℝ) * w := by exact_mod_cast hL
  have hL' : (L : ℝ) ≤ (A : ℝ) * (2 * s) := hA.trans
    (mul_le_mul_of_nonneg_left hw' (Nat.cast_nonneg A))
  have htt : 8 * (L : ℝ) + 1 ≤ (16 * (A : ℝ) + 1) * s := by
    nlinarith only [hL', hsr]
  dsimp only [B, appendixShearerAttempts, parametricShearerAttemptsConstant]
  apply binaryBudget_polynomial
  push_cast
  rw [div_eq_mul_inv, hinv]
  change 2 * s * (8 * (L : ℝ) + 1) * ((4 * K) * vertices) ≤
    (16 * K) * (16 * (A : ℝ) + 1) * s ^ 3
  calc
    _ ≤ 2 * s * ((16 * (A : ℝ) + 1) * s) * ((4 * K) * (2 * s)) := by
      have hK' : (0 : ℝ) ≤ 4 * (K : ℝ) := mul_nonneg (by norm_num) (Nat.cast_nonneg K)
      have h₂ := mul_le_mul_of_nonneg_left hv' hK'
      have h₁ := mul_le_mul_of_nonneg_left htt (show 0 ≤ 2 * s by positivity)
      have hn : 0 ≤ (4 * (K : ℝ)) * vertices := mul_nonneg hK' (Nat.cast_nonneg vertices)
      have hs0 : 0 ≤ s := zero_le_one.trans hsr
      have hA0 : (0 : ℝ) ≤ A := Nat.cast_nonneg A
      have hA1 : 0 ≤ 16 * (A : ℝ) + 1 := add_nonneg (mul_nonneg (by norm_num) hA0) zero_le_one
      have hs' : 0 ≤ 2 * s * ((16 * (A : ℝ) + 1) * s) :=
        mul_nonneg (mul_nonneg (by norm_num) hs0) (mul_nonneg hA1 hs0)
      exact mul_le_mul h₁ h₂ hn hs'
    _ = _ := by ring



/-- Scalar visits for one compact rounding trial, including bounded
recursion, rejection and the transition scans. The additional cubic term
covers the exact pair computations and the compact index and load scans. -/
def parametricRoundVisitBudget (K vertices m active : ℕ) : ℕ :=
  let δ := (1 / (K : ℝ)) / (4 * (vertices : ℝ))
  let L := appendixShearerFuel m δ
  let B := appendixShearerAttempts m L δ
  let D := 4 * vertices * K
  let T := lowActivitySteps vertices active (lowActivityPrecision D)
  m * (8 * L + 1) * B * (m + 1) + T * active + 6 * (m + 1) ^ 3

def parametricRoundVisitConstant (K : ℕ) : ℕ :=
  (16 * (parametricShearerFuelConstant K) + 1) * (2 * (parametricShearerAttemptsConstant K)) +
    40 * (1 + 2 * (8 * K + 1)) + 6

theorem parametricRoundVisitBudget_le (K vertices m active : ℕ) (hK : 0 < K) (hv0 : 0 < vertices)
    (hv : vertices ≤ 2 * m) (ha : active ≤ m) :
    parametricRoundVisitBudget K vertices m active ≤ parametricRoundVisitConstant K * (m + 1) ^ 8 := by
  unfold parametricRoundVisitBudget
  have hp4 : (m + 1) ^ 4 ≤ (m + 1) ^ 8 := Nat.pow_le_pow_right (by omega) (by decide)
  have hp3 : (m + 1) ^ 3 ≤ (m + 1) ^ 8 := Nat.pow_le_pow_right (by omega) (by decide)
  let δ := (1 / (K : ℝ)) / (4 * (vertices : ℝ))
  let L := appendixShearerFuel m δ
  let B := appendixShearerAttempts m L δ
  let w := (m + 1).log2 + 1
  let A := parametricShearerFuelConstant K
  let C := parametricShearerAttemptsConstant K
  have hw : w ≤ 2 * (m + 1) := by
    have h := Nat.log2_le_self (m + 1)
    dsimp [w]
    omega
  obtain ⟨hL, hB⟩ := parametricShearer_budget K vertices m hK hv0 hv
  have hl' : 8 * L + 1 ≤ (16 * A + 1) * (m + 1) := by
    have hLL := hL.trans (Nat.mul_le_mul_left A hw)
    nlinarith only [hLL, Nat.zero_le m]
  have hB' : B ≤ (2 * C) * (m + 1) := by
    exact hB.trans ((Nat.mul_le_mul_left C hw).trans_eq (by ring))
  have hl : m * (8 * L + 1) * B * (m + 1) ≤
      ((16 * A + 1) * (2 * C)) * (m + 1) ^ 4 := by
    calc
      _ ≤ (m+1) * ((16*A+1)*(m+1)) * ((2*C)*(m+1)) * (m+1) := by gcongr; omega
      _ = _ := by ring
  let T := lowActivitySteps vertices active (lowActivityPrecision (4 * vertices * K))
  have ht := (parametricGibbs_budget K vertices m active hv ha).1
  have hg : T * active ≤ (40 * (1 + 2 * (8 * K + 1))) * (m + 1) ^ 8 := by
    calc
      _ ≤ ((40 * (1+2*(8*K+1))) * (m+1)^7) * (m+1) :=
        Nat.mul_le_mul ht (ha.trans (Nat.le_succ _))
      _ = _ := by ring
  calc
    _ ≤ ((16 * (parametricShearerFuelConstant K) + 1) * (2 * (parametricShearerAttemptsConstant K))) *
        (m + 1) ^ 8 + (40 * (1 + 2 * (8 * K + 1))) * (m + 1) ^ 8 + 6 * (m + 1) ^ 8 := by
      exact Nat.add_le_add (Nat.add_le_add (hl.trans (Nat.mul_le_mul_left _ hp4)) hg)
        (Nat.mul_le_mul_left _ hp3)
    _ = _ := by unfold parametricRoundVisitConstant; ring



end

end SubmodularMatching.UpperBoundAssembly
