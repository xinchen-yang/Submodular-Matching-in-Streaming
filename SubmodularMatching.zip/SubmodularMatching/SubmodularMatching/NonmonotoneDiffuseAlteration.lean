import SubmodularMatching.NonmonotoneSparseDiffuse

/-! # Diffuse alteration on the vertices left vacant by two Shearer layers -/

open scoped BigOperators

namespace SubmodularMatching.TwoLayerDiffuse

open GibbsMatching VarianceBound TwoStage
noncomputable section

variable {E V : Type*} [Fintype E] [Fintype V] [DecidableEq E] [DecidableEq V]

def alteredDiffuse (ends : E → V × V) (A B : Layer (pairEnds ends) Finset.univ)
    (x : E → ℝ) (ξ : ℝ) (ω : DualOutcome (pairEnds ends) Finset.univ) (e : E) : ℝ :=
  altered ends (fun d => x d / (A.pair (ends d).1 (ends d).2 * B.pair (ends d).1 (ends d).2))
    (vacant (pairEnds ends) Finset.univ) (tolerance ξ) ω e

/-- Equation (23)'s two vacancy budgets give an altered vector of degree at most one
on the actually free vertices. Its expected coordinate retention approaches one
with an explicit cap independent of the graph size. -/
theorem alteration_verified (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (A B : Layer (pairEnds ends) Finset.univ)
    (d p ξ : ℝ) (hd : 0 ≤ d) (hd' : d ≤ 1/3) (hξ : 0 < ξ) (hp : 0 ≤ p)
    (hpc : p ≤ coordinateCap ξ) (degree : ∀ v, A.deg v + B.deg v ≤ d)
    (x : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (vertexBudget : ∀ v, Joint.degree ends x v ≤ A.free v * B.free v)
    (edgeBudget : ∀ e, x e ≤ p*((1 - A.deg (ends e).1 - A.deg (ends e).2)*
      (1 - B.deg (ends e).1 - B.deg (ends e).2))) :
    (∀ ω e, 0 ≤ alteredDiffuse ends A B x ξ ω e ∧ alteredDiffuse ends A B x ξ ω e ≤ p) ∧
    (∀ ω v, Joint.degree ends (alteredDiffuse ends A B x ξ ω) v ≤ 1) ∧
    (∀ ω e, alteredDiffuse ends A B x ξ ω e ≠ 0 →
      vacant (pairEnds ends) Finset.univ (ends e).1 ω = 1 ∧
      vacant (pairEnds ends) Finset.univ (ends e).2 ω = 1) ∧
    ∀ e, (1-ξ)*x e ≤ finiteMean (joint A B) (fun ω => alteredDiffuse ends A B x ξ ω e) := by
  exact sparse_alteration_verified (pairEnds ends) Finset.univ
    (fun e _ => pairEnds_card_two ends hloop e) ends hloop hsimple A B d p ξ
    hd hd' hξ hp hpc degree x hx vertexBudget edgeBudget

end
end SubmodularMatching.TwoLayerDiffuse
