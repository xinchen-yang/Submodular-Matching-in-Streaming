import SubmodularMatching.Submodularity

namespace SubmodularMatching

def marginal
    {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ)
    (e : E) (A : Finset E) : ℝ :=
  f (A ∪ {e}) - f A

theorem marginal_loss_identity
    {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ)
    (e : E) (A T : Finset E) :
    marginal f e A -
      marginal f e (T ∪ A) =
    (f (A ∪ {e}) - f A) -
      (f ((T ∪ A) ∪ {e}) - f (T ∪ A)) := by
  rfl

theorem marginal_loss_nonnegative
    {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ)
    (hf : IsSubmodular f)
    (A B : Finset E)
    (e : E)
    (hAB : A ⊆ B)
    (he : e ∉ B) :
    0 ≤ marginal f e A - marginal f e B := by
  have h := diminishing_returns f hf A B e hAB he
  dsimp [marginal]
  linarith

theorem marginal_loss_accounting
    (base shifted original : ℝ)
    (_hbase : 0 ≤ base - shifted)
    (_hweight : 0 ≤ original)
    (hbound : original ≤ base - shifted) :
    shifted + original ≤ base := by
  linarith

end SubmodularMatching
