import SubmodularMatching.IndependentSampling

/-!
# A finite probability distribution underlying Bernoulli expectation

`bernoulliOutcomes` explicitly lists the outcomes of the binary decision tree.
Repeated sets are intentionally kept as separate outcomes (their masses add).
Theorems below prove nonnegative masses, total mass one, and equality between
the finite weighted sum and `bernoulliExpectation`.
-/

namespace SubmodularMatching

variable {E : Type*}

/-- Evaluate a set function against a finite list of weighted outcomes. -/
noncomputable def weightedOutcomeSum (F : Finset E → ℝ)
    (outcomes : List (Finset E × ℝ)) : ℝ :=
  (outcomes.map (fun outcome => outcome.2 * F outcome.1)).sum

@[simp] theorem weightedOutcomeSum_nil (F : Finset E → ℝ) :
    weightedOutcomeSum F [] = 0 := rfl

@[simp] theorem weightedOutcomeSum_cons (F : Finset E → ℝ)
    (outcome : Finset E × ℝ) (outcomes : List (Finset E × ℝ)) :
    weightedOutcomeSum F (outcome :: outcomes) =
      outcome.2 * F outcome.1 + weightedOutcomeSum F outcomes := rfl

theorem weightedOutcomeSum_append (F : Finset E → ℝ)
    (xs ys : List (Finset E × ℝ)) :
    weightedOutcomeSum F (xs ++ ys) =
      weightedOutcomeSum F xs + weightedOutcomeSum F ys := by
  simp [weightedOutcomeSum]

theorem weightedOutcomeSum_scaled (F : Finset E → ℝ)
    (transform : Finset E → Finset E) (c : ℝ)
    (outcomes : List (Finset E × ℝ)) :
    weightedOutcomeSum F (outcomes.map (fun outcome =>
      (transform outcome.1, c * outcome.2))) =
      c * weightedOutcomeSum (fun A => F (transform A)) outcomes := by
  induction outcomes with
  | nil => simp
  | cons outcome outcomes ih =>
    simp only [List.map_cons, weightedOutcomeSum_cons, ih]
    ring

variable [DecidableEq E]

/-- The explicit finite sample distribution. Every step multiplies every
previous outcome's mass by the new independent decision's probability. -/
noncomputable def bernoulliOutcomes (edges : ℕ → E) (q : ℕ → ℝ) :
    ℕ → List (Finset E × ℝ)
  | 0 => [(∅, 1)]
  | n + 1 =>
      ((bernoulliOutcomes edges q n).map (fun outcome =>
        (outcome.1, (1 - q n) * outcome.2))) ++
      ((bernoulliOutcomes edges q n).map (fun outcome =>
        (outcome.1 ∪ {edges n}, q n * outcome.2)))

/-- The expectation used throughout the formalization is the finite weighted
sum over the complete independent sampling distribution. -/
theorem bernoulliExpectation_eq_weighted_sum
    (edges : ℕ → E) (q : ℕ → ℝ) (F : Finset E → ℝ) (n : ℕ) :
    bernoulliExpectation edges q F n =
      weightedOutcomeSum F (bernoulliOutcomes edges q n) := by
  induction n generalizing F with
  | zero => simp [bernoulliOutcomes]
  | succ n ih =>
    rw [bernoulliExpectation_succ, bernoulliOutcomes, weightedOutcomeSum_append]
    rw [weightedOutcomeSum_scaled F (fun A => A) (1 - q n),
      weightedOutcomeSum_scaled F (fun A => A ∪ {edges n}) (q n)]
    rw [← ih, ← ih]

/-- The sample distribution has total probability one. -/
theorem bernoulliOutcomes_total_mass
    (edges : ℕ → E) (q : ℕ → ℝ) (n : ℕ) :
    weightedOutcomeSum (fun _ => 1) (bernoulliOutcomes edges q n) = 1 := by
  rw [← bernoulliExpectation_eq_weighted_sum, bernoulliExpectation_const]

/-- Every listed outcome has a nonnegative probability when the coordinates
are valid inclusion probabilities. -/
theorem bernoulliOutcomes_nonnegative
    (edges : ℕ → E) (q : ℕ → ℝ) (n : ℕ)
    (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1) :
    ∀ outcome ∈ bernoulliOutcomes edges q n, 0 ≤ outcome.2 := by
  induction n with
  | zero =>
    intro outcome houtcome
    simp only [bernoulliOutcomes, List.mem_singleton] at houtcome
    subst outcome
    norm_num
  | succ n ih =>
    have hq' : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1 :=
      fun i hi => hq i (Nat.lt_succ_of_lt hi)
    have hn := hq n (Nat.lt_succ_self n)
    intro outcome houtcome
    simp only [bernoulliOutcomes, List.mem_append, List.mem_map] at houtcome
    rcases houtcome with ⟨previous, hprevious, rfl⟩ | ⟨previous, hprevious, rfl⟩
    · exact mul_nonneg (sub_nonneg.mpr hn.2) (ih hq' previous hprevious)
    · exact mul_nonneg hn.1 (ih hq' previous hprevious)

end SubmodularMatching
