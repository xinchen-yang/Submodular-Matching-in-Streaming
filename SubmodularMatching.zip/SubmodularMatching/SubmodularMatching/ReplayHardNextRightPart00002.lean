import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step27 : ProjectedGoal ⟨54918, 54931, 141, 212, 0, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd693d686e8d4a510002050a6) (by decide +kernel)

private theorem step28 : ProjectedGoal ⟨54918, 54924, 212, 247, 0, 70⟩ :=
  projectedGoal_chunk _ (.x (.m (.leaf 0xd689d686e8d4a51000203204) (.leaf 0xd68cd68ae8d4a51000203204)) (.x (.x (.x (.m (.m (.x (.leaf 0xd687d686e8d4a51000203208) (.leaf 0xd687d686cbba106e00203209)) (.x (.leaf 0xd689d688e8d4a51000203208) (.leaf 0xd689d688cbba106e00203209))) (.m (.x (.leaf 0xd68bd68ae8d4a51000203208) (.leaf 0xd68bd68acbba106e00203209)) (.leaf 0xd68cd68ce8d4a51000203202))) (.m (.m (.leaf 0xd687d68600000000001911fb) (.leaf 0xd689d68800000000001911fb)) (.m (.leaf 0xd68bd68a00000000001911fb) (.leaf 0xd68cd68c00000000001911fb)))) (.leaf 0xd68cd68600000000001911e2)) (.leaf 0xd68cd68600000000001911d0))) (by decide +kernel)

private theorem step29 : ProjectedGoal ⟨54925, 54931, 212, 247, 0, 70⟩ :=
  projectedGoal_chunk _ (.x (.leaf 0xd693d68de8d4a51000203204) (.x (.x (.x (.m (.m (.m (.leaf 0xd68dd68de8d4a51000203202) (.leaf 0xd68ed68ee8d4a51000203202)) (.m (.leaf 0xd68fd68fe7ebd06af0203202) (.leaf 0xd690d690e8d4a51000203202))) (.x (.leaf 0xd693d691e8d4a51000203208) (.m (.m (.leaf 0xd691d691cbba106e00203209) (.leaf 0xd692d692e8d4a51000203209)) (.leaf 0xd693d693cbba106e00203209)))) (.m (.m (.m (.leaf 0xd68dd68d00000000001911fb) (.leaf 0xd68ed68e00000000001911fb)) (.m (.leaf 0xd68fd68f00000000001911fb) (.leaf 0xd690d69000000000001911fb))) (.leaf 0xd693d69100000000001911fb))) (.leaf 0xd693d68d00000000001911e2)) (.leaf 0xd693d68d00000000001911d0))) (by decide +kernel)

private theorem step30 : ProjectedGoal ⟨54918, 54931, 212, 247, 0, 70⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54924 (by decide) (by decide) (step28 rates cones) (step29 rates cones)

private theorem step31 : ProjectedGoal ⟨54918, 54931, 212, 247, 70, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd693d686e8d4a510000e80a8) (by decide +kernel)

private theorem step32 : ProjectedGoal ⟨54918, 54931, 212, 247, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 70 (by decide) (by decide) (step30 rates cones) (step31 rates cones)

private theorem step33 : ProjectedGoal ⟨54918, 54931, 247, 283, 0, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd693d686000000000020610e) (by decide +kernel)

private theorem step34 : ProjectedGoal ⟨54918, 54931, 212, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 247 (by decide) (by decide) (step32 rates cones) (step33 rates cones)

private theorem step35 : ProjectedGoal ⟨54918, 54931, 141, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 212 (by decide) (by decide) (step27 rates cones) (step34 rates cones)

private theorem step36 : ProjectedGoal ⟨54932, 54944, 141, 283, 0, 141⟩ :=
  projectedGoal_chunk _ (.x (.leaf 0xd6a0d694e8d4a510002050a6) (.x (.y (.x (.m (.leaf 0xd69ad694e8d4a51000203204) (.leaf 0xd6a0d69be8d4a51000203204)) (.x (.x (.x (.m (.m (.m (.x (.leaf 0xd695d694e8d4a51000203208) (.leaf 0xd695d694cbba106e00203209)) (.x (.leaf 0xd697d696e8d4a51000203208) (.leaf 0xd697d696cbba106e00203209))) (.m (.x (.leaf 0xd699d698e8d4a51000203208) (.leaf 0xd699d698cbba106e00203209)) (.leaf 0xd69ad69ae8d4a51000203202))) (.m (.x (.leaf 0xd69dd69be8d4a51000203208) (.m (.m (.leaf 0xd69bd69bcbba106e00203209) (.leaf 0xd69cd69ce8d4a51000203209)) (.leaf 0xd69dd69dcbba106e00203209))) (.m (.x (.leaf 0xd69fd69ee8d4a51000203208) (.leaf 0xd69fd69ecbba106e00203209)) (.leaf 0xd6a0d6a0e8d4a51000203202)))) (.m (.m (.leaf 0xd697d69400000000001911fb) (.leaf 0xd69ad69800000000001911fb)) (.m (.leaf 0xd69dd69b00000000001911fb) (.leaf 0xd6a0d69e00000000001911fb)))) (.leaf 0xd6a0d69400000000001911e2)) (.leaf 0xd6a0d69400000000001911d0))) (.leaf 0xd6a0d694e8d4a510000e80a8)) (.leaf 0xd6a0d694000000000020610e))) (by decide +kernel)

private theorem step37 : ProjectedGoal ⟨54918, 54944, 141, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54931 (by decide) (by decide) (step35 rates cones) (step36 rates cones)

private theorem step38 : ProjectedGoal ⟨54945, 54971, 141, 212, 0, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd6bbd6a1e8d4a510002050a6) (by decide +kernel)

private theorem step39 : ProjectedGoal ⟨54945, 54971, 212, 229, 0, 70⟩ :=
  projectedGoal_chunk _ (.m (.leaf 0xd6aed6a1e8d4a51000203204) (.leaf 0xd6bbd6afe8d4a51000203204)) (by decide +kernel)

private theorem step40 : ProjectedGoal ⟨54945, 54971, 229, 247, 0, 70⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.m (.m (.m (.m (.m (.x (.leaf 0xd6a1d6a1e8d4a51000203208) (.leaf 0xd6a1d6a1cbba106e00203209)) (.leaf 0xd6a2d6a2e8d4a51000203202)) (.m (.x (.leaf 0xd6a3d6a3e8d4a51000203208) (.leaf 0xd6a3d6a3cbba106e00203209)) (.leaf 0xd6a4d6a4e8d4a51000203202))) (.x (.leaf 0xd6a7d6a5e8d4a51000203208) (.m (.m (.leaf 0xd6a5d6a5cbba106e00203209) (.leaf 0xd6a6d6a6e8d4a51000203209)) (.leaf 0xd6a7d6a7cbba106e00203209)))) (.m (.m (.x (.leaf 0xd6a9d6a8e8d4a51000203208) (.leaf 0xd6a9d6a8cbba106e00203209)) (.x (.leaf 0xd6abd6aae8d4a51000203208) (.leaf 0xd6abd6aacbba106e00203209))) (.x (.leaf 0xd6aed6ace8d4a51000203208) (.m (.leaf 0xd6add6accbba106e00203209) (.leaf 0xd6aed6aecbba106e00203209))))) (.x (.leaf 0xd6bbd6afe8d4a51000203208) (.m (.m (.m (.leaf 0xd6b0d6afcbba106e00203209) (.leaf 0xd6b2d6b1cbba106e00203209)) (.leaf 0xd6b5d6b3cbba106e00203209)) (.m (.leaf 0xd6b8d6b6cbba106e00207209) (.leaf 0xd6bbd6b9cbba106e00207209))))) (.m (.m (.leaf 0xd6a7d6a100000000001911fb) (.leaf 0xd6aed6a800000000001911fb)) (.leaf 0xd6bbd6af00000000001911fb))) (.leaf 0xd6bbd6a100000000001911e2)) (.leaf 0xd6bbd6a100000000001911d0)) (by decide +kernel)

private theorem step41 : ProjectedGoal ⟨54945, 54971, 212, 247, 0, 70⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 229 (by decide) (by decide) (step39 rates cones) (step40 rates cones)

private theorem step42 : ProjectedGoal ⟨54945, 54971, 212, 247, 70, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd6bbd6a1e8d4a510000e80a8) (by decide +kernel)

private theorem step43 : ProjectedGoal ⟨54945, 54971, 212, 247, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 70 (by decide) (by decide) (step41 rates cones) (step42 rates cones)

private theorem step44 : ProjectedGoal ⟨54945, 54971, 247, 283, 0, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd6bbd6a1000000000020610e) (by decide +kernel)

private theorem step45 : ProjectedGoal ⟨54945, 54971, 212, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 247 (by decide) (by decide) (step43 rates cones) (step44 rates cones)

private theorem step46 : ProjectedGoal ⟨54945, 54971, 141, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 212 (by decide) (by decide) (step38 rates cones) (step45 rates cones)

private theorem step47 : ProjectedGoal ⟨54918, 54971, 141, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54944 (by decide) (by decide) (step37 rates cones) (step46 rates cones)

theorem Part00002 : ProjectedGoal ⟨54918, 54971, 141, 283, 0, 141⟩ := step47

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
