import SubmodularMatching.UpperBoundFinalGuess
import SubmodularMatching.SourceDataActual

/-! # Exact streaming parameters for the certified constants -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming NumericalCertificate SourceCertificate

noncomputable section

variable {E V : Type*} [DecidableEq E]

/-- The fixed per-guess scales of Appendix K. The dummy value at a
nonpositive scale is unreachable by an active guess. -/
def appendixGuessConfig (vertices : ℕ) (hn : 2 ≤ vertices) (tau : ℝ) : PotentialConfig := by
  let t := if 0 < tau then tau else 1
  have ht : 0 < t := by dsimp only [t]; split_ifs <;> positivity
  have hn' : (2 : ℝ) ≤ vertices := by exact_mod_cast hn
  have hpos : (0 : ℝ) < vertices := by linarith
  have he := error_bounds.2.2.1
  let θ := finiteError * t / (vertices : ℝ)
  let d := finiteError * t / (vertices : ℝ) ^ 2
  let q := coordinateCap * finiteError ^ 2 * t / (vertices : ℝ) ^ 4
  have hel : finiteError ≤ (vertices : ℝ) := by linarith [error_bounds.2.2.2]
  have hq : q ≤ coordinateCap * t := by
    have hpower : finiteError ^ 2 ≤ (vertices : ℝ) ^ 4 := by
      have h1 : finiteError ^ 2 ≤ 1 := pow_le_one₀ he.le (by linarith [error_bounds.2.2.2])
      exact h1.trans (one_le_pow₀ (by linarith : (1 : ℝ) ≤ vertices))
    apply (div_le_iff₀ (pow_pos hpos 4)).2
    convert mul_le_mul_of_nonneg_left hpower (mul_nonneg coordinate_condition.1.le ht.le) using 1 <;>
      dsimp [q] <;> ring
  exact appendixPotentialConfig t θ d q (by dsimp [θ]; positivity)
    ((div_le_iff₀ hpos).2 (by simpa only [mul_comm] using mul_le_mul_of_nonneg_right hel ht.le))
    (by dsimp [d]; positivity) (by dsimp [q]; positivity [coordinate_condition.1]) hq

theorem appendixGuessConfig_p (vertices : ℕ) (hn : 2 ≤ vertices) (tau : ℝ) :
    (appendixGuessConfig vertices hn tau).p = coordinateCap := rfl

theorem appendixGuessConfig_spec (vertices : ℕ) (hn : 2 ≤ vertices) (tau : ℝ) (ht : 0 < tau) :
    let C := appendixGuessConfig vertices hn tau
    C.tau = tau ∧ C.theta = finiteError * tau / (vertices : ℝ) ∧
      C.gap = finiteError * tau / (vertices : ℝ) ^ 2 ∧
      C.grid = coordinateCap * finiteError ^ 2 * tau / (vertices : ℝ) ^ 4 := by
  dsimp [appendixGuessConfig, appendixPotentialConfig, SourceRateTable.makeConfig]
  rw [if_pos ht]
  exact ⟨rfl, rfl, rfl, rfl⟩

/-- Construct the actual reference schedule with integer bit and span
counts derived from the vertex count. -/
def appendixScheduledSource (edges : ℕ → E) (ends : E → V × V) (f : Finset E → ℝ)
    (vertices arrivals : ℕ) (hn : 2 ≤ vertices) (ha : arrivals ≤ vertices ^ 2)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (hzero : f ∅ = 0) : ScheduledSource E V where
  edges := edges
  ends := ends
  objective := f
  config := appendixGuessConfig vertices hn
  bits := Nat.clog 2 (64 * vertices ^ 4 * 10000000000)
  span := Nat.clog 2 (vertices * 10000000000)
  arrivals := arrivals
  vertices := vertices
  epsilon := finiteError
  epsilon_pos := error_bounds.2.2.1
  vertices_pos := Nat.lt_of_lt_of_le (by decide) hn
  arrivals_bound := ha
  width_bound := by
    have h := Nat.le_pow_clog (by decide : 1 < 2) (vertices * 10000000000)
    have hr : (↑(vertices * 10000000000) : ℝ) ≤ ↑(2 ^ Nat.clog 2 (vertices * 10000000000)) := by
      exact_mod_cast h
    norm_num [finiteError, div_eq_mul_inv] at hr ⊢
    exact hr
  probability_le_one tau := by
    rw [appendixGuessConfig_p]
    exact coordinate_condition.2.trans (min_le_left _ _)
  config_tau tau ht := (appendixGuessConfig_spec vertices hn tau ht).1
  config_gap tau ht := by
    rw [(appendixGuessConfig_spec vertices hn tau ht).1]
    exact (appendixGuessConfig_spec vertices hn tau ht).2.2.1
  bits_bound := by
    have h := Nat.le_pow_clog (by decide : 1 < 2) (64 * vertices ^ 4 * 10000000000)
    have hr : ((64 * vertices ^ 4 * 10000000000 : ℕ) : ℝ) ≤
        ((2 ^ Nat.clog 2 (64 * vertices ^ 4 * 10000000000) : ℕ) : ℝ) := by exact_mod_cast h
    norm_num [finiteError, div_eq_mul_inv] at hr ⊢
    exact hr
  submodular := hf
  monotone := hmono
  normalized := hzero

/-- Construct static conditions for the exact scheduled configuration,
with the remaining endpoint checker results explicit. -/
theorem appendixGuessConfig_source (vertices : ℕ) (hn : 2 ≤ vertices) (tau : ℝ)
    (hchecks : ∀ mode < 27648, ∀ hi i j,
      appendixRateTable.checkMode appendixPotentialTable SourceRateTable.appendixDegree
        SourceRateTable.appendixSigma mode hi i j = true) :
    RunSourceConditions appendixPotentialTable.sourceFunction (appendixGuessConfig vertices hn tau)
      degree sigma (SourceRateTable.appendixCmax : ℝ) := by
  unfold appendixGuessConfig
  apply actualSourceConditions
  exact hchecks

end

end SubmodularMatching.UpperBoundAssembly
