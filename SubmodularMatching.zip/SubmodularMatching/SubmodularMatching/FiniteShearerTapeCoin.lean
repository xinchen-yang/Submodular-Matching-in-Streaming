import SubmodularMatching.FiniteShearerTapeScan

/-!
# Executable bounded Shearer coins

The interpreter keeps vertex identifiers on the stack. It uses one
bounded stop draw and at most one bounded neighbor draw per trial.
-/

namespace SubmodularMatching.ShearerSampler

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

abbrev StopWordTape (c : RationalShearerInput E) (B : ℕ) := Fin B → Fin (2^c.stopGrid.bits)

abbrev NeighborWordTape (c : RationalShearerInput E) (B : ℕ) := Fin B → Fin (2^c.neighborGrid.bits)

abbrev CoinWordBlock (c : RationalShearerInput E) (B : ℕ) :=
  StopWordTape c B × NeighborWordTape c B

def endpointFromPair (ep : E → V × V) (e : E) (v : V) : V :=
  if v = (ep e).1 then (ep e).2 else (ep e).1

omit [DecidableEq E] in
theorem endpointFromPair_eq (ends : E → Finset V) (ep : E → V × V) (e : E)
    (hEnds : ends e = {(ep e).1,(ep e).2}) (hDistinct : (ep e).1 ≠ (ep e).2)
    (v : V) (hv : v ∈ ends e) :
    endpointFromPair ep e v = otherEndpoint ends e v := by
  rw [hEnds,Finset.mem_insert,Finset.mem_singleton] at hv
  rcases hv with rfl | rfl
  · rw [endpointFromPair,if_pos rfl,otherEndpoint_eq ends e _ _ hDistinct.symm hEnds]
  · have hSwap : ends e = {(ep e).2,(ep e).1} := by rw [hEnds,Finset.pair_comm]
    rw [endpointFromPair,if_neg hDistinct.symm,otherEndpoint_eq ends e _ _ hDistinct hSwap]

def compactCoinNext (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (base : Finset E) (stored : List E) (B : ℕ)
    (v : V) (ancestors : List V) (trial : CoinWordBlock c B) : Option (List V) :=
  match c.stopGrid.wordDraw B trial.1 with
  | none => none
  | some w =>
    if w.val < c.a then some ancestors else
      (compactNeighborDraw c ends base stored v ancestors B trial.2).map
        (fun e => endpointFromPair ep e v :: v :: ancestors)

private def compactCoinLoop (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (base : Finset E) (stored : List E) (B : ℕ)
    (wordAt : ℕ → Option (CoinWordBlock c B)) : ℕ → ℕ → List V → Bool
  | _, _, [] => true
  | 0, _, _ :: _ => false
  | fuel+1, cursor, v :: ancestors =>
    let next := (wordAt cursor).bind (compactCoinNext c ends ep base stored B v ancestors)
    match next with
    | none => false
    | some stack => compactCoinLoop c ends ep base stored B wordAt fuel (cursor+1) stack

private theorem compactCoinLoop_tape_congr (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (base : Finset E) (stored : List E) (B : ℕ)
    (a b : ℕ → Option (CoinWordBlock c B)) (fuel u v : ℕ) (stack : List V)
    (h : ∀ i < fuel, a (u+i) = b (v+i)) :
    compactCoinLoop c ends ep base stored B a fuel u stack =
      compactCoinLoop c ends ep base stored B b fuel v stack := by
  induction fuel generalizing u v stack with
  | zero => cases stack <;> rfl
  | succ fuel ih =>
    cases stack with
    | nil => rfl
    | cons w prior =>
      have hFirst : a u = b v := by simpa only [Nat.add_zero] using h 0 (Nat.zero_lt_succ _)
      simp only [compactCoinLoop,hFirst]
      cases hNext : (b v).bind (compactCoinNext c ends ep base stored B w prior) with
      | none => rfl
      | some stack =>
        apply ih
        intro i hi
        simpa only [Nat.add_assoc,Nat.add_comm 1 i] using h (i+1) (Nat.succ_lt_succ hi)

/-- Consume trials with a fixed tape and an increasing cursor. A running
coin stores the current vertex stack and the remaining trial count. -/
def compactCoinRun (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (base : Finset E) (stored : List E) (B fuel : ℕ)
    (stack : List V) (tape : Fin fuel → CoinWordBlock c B) : Bool :=
  compactCoinLoop c ends ep base stored B
    (fun i => if h : i < fuel then some (tape ⟨i,h⟩) else none) fuel 0 stack

@[simp] theorem compactCoinRun_empty (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (base : Finset E) (stored : List E) (B fuel : ℕ)
    (tape : Fin fuel → CoinWordBlock c B) :
    compactCoinRun c ends ep base stored B fuel [] tape = true := by
  cases fuel <;> rfl

@[simp] theorem compactCoinRun_zero (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (base : Finset E) (stored : List E) (B : ℕ) (v : V) (prior : List V)
    (tape : Fin 0 → CoinWordBlock c B) :
    compactCoinRun c ends ep base stored B 0 (v::prior) tape = false := rfl

@[simp] theorem compactCoinRun_succ (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (base : Finset E) (stored : List E) (B fuel : ℕ) (v : V) (prior : List V)
    (tape : Fin (fuel+1) → CoinWordBlock c B) :
    compactCoinRun c ends ep base stored B (fuel+1) (v::prior) tape =
      (compactCoinNext c ends ep base stored B v prior (tape 0)).elim false
        (fun stack => compactCoinRun c ends ep base stored B fuel stack (Fin.tail tape)) := by
  simp only [compactCoinRun,compactCoinLoop,dif_pos (Nat.zero_lt_succ fuel),Option.bind_some]
  have hZero : (⟨0,Nat.zero_lt_succ fuel⟩ : Fin (fuel+1)) = 0 := Fin.ext (by simp)
  simp only [hZero,Nat.zero_add]
  cases hNext : compactCoinNext c ends ep base stored B v prior (tape 0) with
  | none => rfl
  | some stack =>
    apply compactCoinLoop_tape_congr
    intro i hi
    have h' : 1+i < fuel+1 := by omega
    simp only [Nat.zero_add,dif_pos h',dif_pos hi,Fin.tail]
    have hIndex : (⟨1+i,h'⟩ : Fin (fuel+1)) = (⟨i,hi⟩ : Fin fuel).succ := Fin.ext (by simp [Nat.add_comm])
    rw [hIndex]

noncomputable def boolPayoff (b : Bool) : ℝ := if b then 1 else 0

noncomputable def compactCoinSuccess (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (base : Finset E) (stored : List E) (B fuel : ℕ) (stack : List V) : ℝ :=
  wordAverage (fun tape : Fin fuel → CoinWordBlock c B =>
    boolPayoff (compactCoinRun c ends ep base stored B fuel stack tape))

set_option maxHeartbeats 1000000 in
/-- Compact integer execution has the exact binary-coin recurrence,
including both bounded-rejection aborts and the capped stack. -/
theorem compactCoinSuccess_eq (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (edges base : Finset E) (hbase : base ⊆ edges)
    (stored : List E) (hs : stored.toFinset = edges) (hd : stored.Nodup)
    (hEnds : ∀ e ∈ edges, ends e = {(ep e).1,(ep e).2})
    (hDistinct : ∀ e ∈ edges, (ep e).1 ≠ (ep e).2)
    (hDegree : ∀ v, ∑ e ∈ incident ends edges v, c.x e ≤ c.stop*(1-c.stop))
    (B fuel : ℕ) (frames : List (CoinFrame edges V))
    (hFrames : stackInvariant ends base frames) :
    compactCoinSuccess c ends ep base stored B fuel (frames.map Prod.snd) =
      coinWithAbort c.stop (frameChoices ends edges) (fun _ e => c.x e/(c.stop*(1-c.stop)))
        (childFrame ends edges) (fun _ => c.stopGrid.alive B) (fun _ => c.neighborGrid.alive B)
        fuel frames := by
  classical
  let val := fun t stack =>
    coinWithAbort c.stop (frameChoices ends edges) (fun _ e => c.x e/(c.stop*(1-c.stop)))
      (childFrame ends edges) (fun _ => c.stopGrid.alive B) (fun _ => c.neighborGrid.alive B) t stack
  have hCard (e : E) (he : e ∈ edges) : (ends e).card = 2 := by
    rw [hEnds e he, Finset.card_pair (hDistinct e he)]
  haveI : Nonempty (StopWordTape c B) := ⟨fun _ => ⟨0,by positivity⟩⟩
  haveI : Nonempty (NeighborWordTape c B) := ⟨fun _ => ⟨0,by positivity⟩⟩
  have tapeNonempty (t : ℕ) : Nonempty (Fin t → CoinWordBlock c B) :=
    ⟨fun _ => (Classical.choice inferInstance,Classical.choice inferInstance)⟩
  change compactCoinSuccess c ends ep base stored B fuel (frames.map Prod.snd) = val fuel frames
  induction fuel generalizing frames with
  | zero =>
    haveI := tapeNonempty 0
    cases frames <;> simp [compactCoinSuccess,val,coinWithAbort,boolPayoff]
  | succ fuel ih =>
    haveI := tapeNonempty (fuel+1)
    cases frames with
    | nil => simp [compactCoinSuccess,val,coinWithAbort,boolPayoff]
    | cons frame rest =>
      haveI := tapeNonempty fuel
      let v := frame.2
      let ancestors := rest.map Prod.snd
      let run := compactCoinRun c ends ep base stored B
      let neighbor := compactNeighborDraw c ends base stored v ancestors B
      let pay := fun e => val fuel (childFrame ends edges frame e :: frame :: rest)
      let cont := val fuel rest
      have hAvailable (e : E) (neighborTape : NeighborWordTape c B)
          (he : neighbor neighborTape = some e) : e ∈ frameChoices ends edges frame := by
        have h := compactNeighborDraw_available c ends base stored v ancestors B neighborTape e he
        simpa only [frameChoices,hFrames.1] using h
      have hPayoff :
          (fun word : CoinWordBlock c B => wordAverage (fun tail : Fin fuel → CoinWordBlock c B =>
            boolPayoff (run (fuel+1) (v::ancestors) (Fin.cons word tail)))) =
          fun word : CoinWordBlock c B =>
            (c.stopGrid.wordDraw B word.1).elim 0 (fun w => if w.val < c.a then cont
              else (neighbor word.2).elim 0 pay) := by
        funext word
        cases hTop : c.stopGrid.wordDraw B word.1 with
        | none => simp [run,compactCoinNext,hTop,boolPayoff]
        | some w =>
          by_cases hStop : w.val < c.a
          · simpa only [run,compactCoinRun_succ,compactCoinNext,Fin.cons_zero,Fin.tail_cons,hTop,Option.elim_some,if_pos hStop]
              using ih rest hFrames.2.2
          · cases hNeighbor : neighbor word.2 with
            | none =>
              have hNone : compactNeighborDraw c ends base stored v ancestors B word.2 = none := hNeighbor
              simp [run,compactCoinNext,hTop,hStop,hNone,boolPayoff]
            | some e =>
              have he := hAvailable e word.2 hNeighbor
              have he' := Finset.mem_filter.mp he
              have heEdge := frame.1.property he'.1
              have heEnd := endpointFromPair_eq ends ep e (hEnds e heEdge) (hDistinct e heEdge) v he'.2
              have hPush := stackInvariant_push ends base edges hCard frame rest hFrames e he
              have hIH := ih _ hPush
              change (wordAverage (fun tail =>
                boolPayoff (run fuel (otherEndpoint ends e v::v::ancestors) tail))) = pay e at hIH
              simpa only [run,compactCoinRun_succ,compactCoinNext,Fin.cons_zero,Fin.tail_cons,hTop,Option.elim_some,if_neg hStop,
                show compactNeighborDraw c ends base stored v ancestors B = neighbor from rfl,hNeighbor,Option.map_some,heEnd]
                using hIH
      change (wordAverage (fun tape : Fin (fuel+1) → CoinWordBlock c B =>
        boolPayoff (run (fuel+1) (v::ancestors) tape))) = _
      rw [wordAverage_tape fuel,hPayoff,wordAverage_prod]
      have hNeighborAvg :=
        compactNeighborDraw_payoff c ends edges base hbase stored hs hd v ancestors (hDegree v) B pay
      change wordAverage (fun w => (neighbor w).elim 0 pay) =
        c.neighborGrid.alive B * ∑ e ∈ incident ends (removeAncestors ends base ancestors) v,
          (c.x e/(c.stop*(1-c.stop)))*pay e at hNeighborAvg
      let tailValue := c.neighborGrid.alive B * ∑ e ∈ frameChoices ends edges frame,
        (c.x e/(c.stop*(1-c.stop)))*pay e
      have hNeighborEq : wordAverage (fun w => (neighbor w).elim 0 pay) = tailValue := by
        simpa only [tailValue,frameChoices,hFrames.1] using hNeighborAvg
      have hProd :
          (fun stopTape : StopWordTape c B => wordAverage (fun neighborTape : NeighborWordTape c B =>
            (c.stopGrid.wordDraw B stopTape).elim 0 (fun w => if w.val < c.a then cont
              else (neighbor neighborTape).elim 0 pay))) =
          fun stopTape : StopWordTape c B => (c.stopGrid.wordDraw B stopTape).elim 0
            (fun w => if w.val < c.a then cont else tailValue) := by
        funext stopTape
        cases hDraw : c.stopGrid.wordDraw B stopTape with
        | none => simp
        | some cell =>
          by_cases hh : cell.val < c.a <;> simp [hh,hNeighborEq]
      rw [hProd,c.stopGrid.wordDraw_threshold B c.a c.a_lt_b.le cont tailValue, ← c.stop_grid_value]
      dsimp only [val,coinWithAbort,cont,tailValue]
      ring

/-- The stack machine agrees with the checkpoint binary coin on its
initial one-vertex frame. -/
theorem compactCoinSuccess_binary (c : RationalShearerInput E) (ends : E → Finset V)
    (ep : E → V × V) (edges base : Finset E) (hbase : base ⊆ edges) (v : V)
    (stored : List E) (hs : stored.toFinset = edges) (hd : stored.Nodup)
    (hEnds : ∀ e ∈ edges, ends e = {(ep e).1,(ep e).2})
    (hDistinct : ∀ e ∈ edges, (ep e).1 ≠ (ep e).2)
    (hDegree : ∀ v, ∑ e ∈ incident ends edges v, c.x e ≤ c.stop*(1-c.stop))
    (B fuel : ℕ) :
    compactCoinSuccess c ends ep base stored B fuel [v] =
      binaryCoin ends edges c.x c.stop fuel B (fun _ => c.stopGrid) (fun _ => c.neighborGrid)
        (⟨base,hbase⟩,v) :=
  compactCoinSuccess_eq c ends ep edges base hbase stored hs hd hEnds hDistinct hDegree
    B fuel [(⟨base,hbase⟩,v)] (stackInvariant_initial ends base edges hbase v)

end SubmodularMatching.ShearerSampler
