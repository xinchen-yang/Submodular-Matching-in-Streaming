import SubmodularMatching.ReplayQuickRate

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 16000
set_option maxHeartbeats 5000000

theorem quick21504 : allIndexed compareQuick 21504 sourceRates21504 = true := by decide +kernel

end SubmodularMatching.SourceCertificate.Replay
