import SubmodularMatching.ReplayQuickRate

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 16000
set_option maxHeartbeats 5000000

theorem quick26624 : allIndexed compareQuick 26624 sourceRates26624 = true := by decide +kernel

end SubmodularMatching.SourceCertificate.Replay
