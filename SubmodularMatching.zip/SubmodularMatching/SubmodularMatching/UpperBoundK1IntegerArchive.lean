import SubmodularMatching.UpperBoundK1IntegerAdvance
import SubmodularMatching.UpperBoundK1Stored

/-! # Compact integer optimizer from retained source records -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint LinearPacking GibbsSampler Streaming

noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def k1ArchivedWeight (a : K1Parameters) (n : ℕ) (tau : ℝ) (index : ℕ) : ℝ :=
  a.error * tau / (n : ℝ) ^ 2 * index

theorem k1ArchivedWeight_grid (a : K1Parameters) (n : ℕ) (hn : 0 < n)
    (tau : ℝ) (htau : 0 < tau) (index : ℕ) :
    OnGrid (a.k * n ^ 2) (k1ArchivedWeight a n tau index / tau) := by
  have hk : (0 : ℝ) < a.k := by exact_mod_cast (show 0 < a.k by have := a.k_large; omega)
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  refine ⟨(2 * (index : ℤ)), ?_⟩
  unfold k1ArchivedWeight K1Parameters.error k1Epsilon
  push_cast
  field_simp [htau.ne', hk.ne', hn'.ne']

/-- Optimize one archive in its actual row order. The only objective
access is through reindexing the selected subsets of these rows. -/
def optimizerFromArchiveCompiled (a : K1Parameters) (ends : E → V × V)
    (objective : Finset E → ℝ) (rows : List (E × ℕ)) (n : ℕ) (tau : ℝ) (Ng : ℕ) :
    CandidateLaw (CurrentOptimizerPoint rows.length) := by
  classical
  let cfg := a.optimizerSettings
  let m := rows.length
  let ep := ends ∘ fun i : Fin m => (rows.get i).1
  let w := fun i : Fin m => min tau (k1ArchivedWeight a n tau (rows.get i).2)
  let f := fun S : Finset (Fin m) => objective (S.image (fun i => (rows.get i).1))
  exact if hm : 0 < m then
    (k1IntegerOptimizerLaw cfg a.p a.rationalDegree a.k Ng hm ep tau w (a.k * n ^ 2) f
      (k1GradientDiscountGrid cfg.degree cfg.error m) (k1GradientCoordinateBits cfg.degree cfg.error m)).map
        (fun z i => (z i : ℝ) / k1NormalizedDenominator cfg a.k ep)
  else CandidateLaw.pure (fun _ => 0)

/-- Every observable of the live archived solver is preserved by integer
compilation. The archive weight bound is deterministic on legal source runs. -/
theorem optimizerFromArchiveCompiled_value (a : K1Parameters) (ends : E → V × V)
    (objective : Finset E → ℝ) (rows : List (E × ℕ)) (n : ℕ) (hn : 0 < n)
    (tau : ℝ) (htau : 0 < tau) (Ng : ℕ) (hN : 0 < Ng)
    (hweight : ∀ i : Fin rows.length, k1ArchivedWeight a n tau (rows.get i).2 ≤ tau)
    (test : CurrentOptimizerPoint rows.length → ℝ) :
    let p := optimizerFromArchiveCompiled a ends objective rows n tau Ng
    let m := rows.length
    let ep := ends ∘ fun i : Fin m => (rows.get i).1
    let w := fun i : Fin m => k1ArchivedWeight a n tau (rows.get i).2
    let f := fun S : Finset (Fin m) => objective (S.image (fun i => (rows.get i).1))
    let cfg := a.optimizerSettings
    let q := if hm : 0 < m then
      k1LiveOptimizerLaw cfg Ng hm (restrictEnds ep) tau w f
        (k1GradientDiscountGrid cfg.degree cfg.error m) (k1GradientCoordinateBits cfg.degree cfg.error m)
      else CandidateLaw.pure (fun _ => 0)
    expected p.outcomes p.mass test = expected q.outcomes q.mass test := by
  classical
  intro p m ep w f cfg q
  have hclip : (fun i : Fin m => min tau (k1ArchivedWeight a n tau (rows.get i).2)) = w := by
    funext i
    exact min_eq_right (hweight i)
  by_cases hm : 0 < m
  · dsimp only [p, q, optimizerFromArchiveCompiled]
    rw [dif_pos hm, dif_pos hm, hclip, CandidateLaw.map_expected]
    have hW : 0 < a.k * n ^ 2 := Nat.mul_pos (by have := a.k_large; omega) (pow_pos hn 2)
    have hw (i : Fin m) : 0 ≤ w i ∧ w i ≤ tau := by
      refine ⟨?_, hweight i⟩
      dsimp [w, k1ArchivedWeight]
      positivity [a.error_pos]
    have hgrid (i : Fin m) : OnGrid (a.k * n ^ 2) (w i / tau) :=
      k1ArchivedWeight_grid a n hn tau htau (rows.get i).2
    have hQ := (k1GradientDiscountGrid_spec cfg.degree cfg.error cfg.degree_pos cfg.error_pos m hm).1
    exact k1IntegerOptimizerLaw_value cfg a.p a.rationalDegree a.k rfl a.rationalDegree_cast.symm rfl
      a.k_large hm ep tau htau w (a.k * n ^ 2) hW hw hgrid hN f _ hQ _ test
  · dsimp only [p, q, optimizerFromArchiveCompiled]
    rw [dif_neg hm, dif_neg hm]

end

end SubmodularMatching.UpperBoundAssembly
