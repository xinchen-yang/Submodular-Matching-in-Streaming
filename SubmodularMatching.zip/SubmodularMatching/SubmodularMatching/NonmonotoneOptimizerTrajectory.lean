import SubmodularMatching.NonmonotoneOptimizerGuarantee
import SubmodularMatching.GibbsHybrid

/-! Projected-gradient realization of equation (28). -/

namespace SubmodularMatching.NonmonotoneOptimizer

open GibbsMatching

noncomputable section

variable {E ι : Type*} [DecidableEq E] [Fintype ι]

/-- Sampling at the incidence vector selects a retained comparator exactly. -/
theorem expectation_indicator (edges : ℕ → E) (O : Finset E) (n : ℕ)
    (f : Finset E → ℝ) :
    bernoulliExpectation edges (fun i => if edges i ∈ O then 1 else 0) f n =
      f (replacementPrefix edges n ∩ O) := by
  induction n generalizing f with
  | zero => simp
  | succ n ih =>
    rw [bernoulliExpectation_succ,replacementPrefix_succ]
    by_cases he : edges n ∈ O
    · rw [if_pos he]; simp only [sub_self,zero_mul,one_mul,zero_add,ih]
      congr 1
      ext e
      simp only [Finset.mem_union,Finset.mem_inter,Finset.mem_insert,Finset.mem_singleton]
      constructor
      · rintro (⟨h1,h2⟩ | rfl)
        · exact ⟨Or.inr h1,h2⟩
        · exact ⟨Or.inl rfl,he⟩
      · rintro ⟨heq | hp, hO⟩
        · exact Or.inr heq
        · exact Or.inl ⟨hp,hO⟩
    · rw [if_neg he]; simp only [sub_zero,one_mul,zero_mul,add_zero,ih]
      congr 1
      ext e
      simp only [Finset.mem_inter,Finset.mem_insert]
      constructor
      · rintro ⟨h1,h2⟩; exact ⟨Or.inr h1,h2⟩
      · rintro ⟨rfl | hp,hO⟩
        · exact (he hO).elim
        · exact ⟨hp,hO⟩

/-- Computed chain payoff, in the order chosen at a given iteration. -/
def queriedPayoff (e : ℕ → E) (n : ℕ) (f : Finset E → ℝ) (c : ℝ) (u : ℕ → ℝ) : ℕ → ℝ :=
  fun i => payoff (action c (u i))
    (slope e (chain (fun j => action c (u j)) (fun _ => 0) i) f n i)
    (slope e (chain (fun j => action c (u j)) (fun _ => 1) i) f n i)

/-- The actual three-chain query at each sorted iterate gives (28) for the
projected trajectory. The linearization can include a bounded query error. -/
theorem projected_action (edges : ℕ → ℕ → E) (n T : ℕ) (hT : 0 < T)
    (O : Finset E) (f : Finset E → ℝ) (hf : IsSubmodular f) (hpos : ∀ B, 0 ≤ f B)
    (u : ℕ → ℕ → ℝ) (L : ℕ → ℝ) (W α β γ c : ℝ) (hc : 0 < c) (hβ : 0 ≤ β)
    (hγ : β*(1+c+1/(4*c))=γ) (hα : γ-β*c=α)
    (hcover : ∀ t < T, O ⊆ replacementPrefix (edges t) n)
    (hinj : ∀ t < T, ∀ i < n, ∀ j < n, edges t i = edges t j → i = j)
    (hu : ∀ t < T, ∀ i < n, 0 ≤ u t i ∧ u t i ≤ 1)
    (hsort : ∀ t < T, ∀ i < n, ∀ j < n, i ≤ j → weight c (u t i) ≤ weight c (u t j))
    (state grad : ℕ → ι → ℝ) (o : ι → ℝ) (η projErr normSq estimationErr tol : ℝ) (hη : 0 < η)
    (hnorm : ∀ t < T, dot (grad t) (grad t) ≤ normSq)
    (hproj : ∀ t < T, dot (fun i => state t i + η*grad t i - state (t+1) i)
      (fun i => o i - state (t+1) i) ≤ projErr)
    (hlinear : ∀ t < T, W - L t + β*(∑ i ∈ Finset.range n,
      queriedPayoff (edges t) n f c (u t) i * ((if edges t i ∈ O then 1 else 0)-u t i)) ≤
      dot (grad t) (fun i => o i - state t i) + estimationErr)
    (hsteps : distSq (state 0) o + T*(η^2*normSq + 2*projErr) ≤ 2*η*(T*tol)) :
    ∃ t < T, W + β*(f O-f ∅) - (α-β)*f ∅ - (tol+estimationErr) ≤
      L t + γ*(bernoulliExpectation (edges t) (fun i => action c (u t i)) f n-f ∅) := by
  let Q := fun t => ∑ i ∈ Finset.range n, queriedPayoff (edges t) n f c (u t) i *
    ((if edges t i ∈ O then 1 else 0)-u t i)
  apply action_of_regret T hT _ L Q W (f O) (f ∅) α β γ c (tol+estimationErr) hβ hγ hα
  · intro t ht
    have h := multilinear_chain_comparison (edges t) n (hinj t ht) f hf hpos c hc (u t)
      (fun i => if edges t i ∈ O then 1 else 0) (hu t ht)
      (fun i _ => by dsimp only; split_ifs <;> norm_num) (hsort t ht)
    rw [expectation_indicator, Finset.inter_eq_right.mpr (hcover t ht)] at h
    exact h
  · have h := (ascent_regret state grad o η projErr normSq T hnorm hproj).trans hsteps
    have hsum := (mul_le_mul_iff_right₀ (show 0 < 2*η by linarith)).mp h
    have hlin := Finset.sum_le_sum (s := Finset.range T)
      (fun t ht => hlinear t (Finset.mem_range.mp ht))
    rw [Finset.sum_add_distrib (f := fun t => dot (grad t) (fun i => o i-state t i))] at hlin
    simp only [Finset.sum_const,Finset.card_range,nsmul_eq_mul] at hlin
    change ∑ t ∈ Finset.range T, (W-L t+β*Q t) ≤ _ at hlin
    linarith only [hsum,hlin]

end

end SubmodularMatching.NonmonotoneOptimizer
