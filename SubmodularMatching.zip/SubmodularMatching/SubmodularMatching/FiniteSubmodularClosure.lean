import SubmodularMatching.GeneralMarginals

/-! Elementary finite-set closure lemmas used by the lower-bound objective. -/

namespace SubmodularMatching

/-- Unrestricted insertion diminishing returns, including already present elements. -/
def HasDiminishingReturns {E : Type*} [DecidableEq E] (f : Finset E → ℝ) : Prop :=
  ∀ A B : Finset E, ∀ e : E, A ⊆ B →
    f (insert e B) - f B ≤ f (insert e A) - f A

theorem extension_diminishing_returns {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ) (hd : HasDiminishingReturns f)
    (A B : Finset E) (hAB : A ⊆ B) (C : Finset E) :
    f (B ∪ C) - f B ≤ f (A ∪ C) - f A := by
  induction C using Finset.induction_on with
  | empty => simp
  | @insert e C he ih =>
    have hstep := hd (A ∪ C) (B ∪ C) e (Finset.union_subset_union hAB (Finset.Subset.refl C))
    simp only [Finset.union_insert]
    linarith

/-- Insertion diminishing returns imply the usual union/intersection inequality. -/
theorem submodular_of_diminishing_returns {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ) (hd : HasDiminishingReturns f) : IsSubmodular f := by
  intro A B
  have h := extension_diminishing_returns f hd (A ∩ B) B Finset.inter_subset_right A
  have hsmall : (A ∩ B) ∪ A = A := Finset.union_eq_right.mpr Finset.inter_subset_left
  rw [hsmall, Finset.union_comm B A] at h
  linarith

/-- Clipping a nonnegative increment leaves the smaller of the increment and
the remaining capacity. -/
theorem min_increment (C x d : ℝ) (hd : 0 ≤ d) :
    min C (x + d) - min C x = min d (max (C - x) 0) := by
  by_cases hx : x ≤ C
  · rw [min_eq_right hx, max_eq_left (sub_nonneg.mpr hx)]
    by_cases hxd : x + d ≤ C
    · rw [min_eq_right hxd, min_eq_left (by linarith)]
      ring
    · rw [min_eq_left (le_of_not_ge hxd), min_eq_right (by linarith)]
  · rw [min_eq_left (le_of_not_ge hx), min_eq_left (by linarith),
      max_eq_right (by linarith), min_eq_right hd]
    ring

theorem truncate_monotone {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ) (hm : IsMonotone f) (C : ℝ) :
    IsMonotone (fun A => min C (f A)) := by
  intro A B hAB
  exact min_le_min_left C (hm A B hAB)

theorem truncate_diminishing_returns {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ) (hm : IsMonotone f) (hd : HasDiminishingReturns f) (C : ℝ) :
    HasDiminishingReturns (fun A => min C (f A)) := by
  intro A B e hAB
  have hA := min_increment C (f A) (f (insert e A) - f A)
    (sub_nonneg.mpr (hm A (insert e A) (Finset.subset_insert e A)))
  have hB := min_increment C (f B) (f (insert e B) - f B)
    (sub_nonneg.mpr (hm B (insert e B) (Finset.subset_insert e B)))
  have ha : f A + (f (insert e A) - f A) = f (insert e A) := by ring
  have hb : f B + (f (insert e B) - f B) = f (insert e B) := by ring
  rw [ha] at hA
  rw [hb] at hB
  rw [hA, hB]
  apply min_le_min (hd A B e hAB)
  apply max_le_max_right 0
  linarith [hm A B hAB]

theorem truncate_submodular {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ) (hm : IsMonotone f) (hd : HasDiminishingReturns f) (C : ℝ) :
    IsSubmodular (fun A => min C (f A)) :=
  submodular_of_diminishing_returns _ (truncate_diminishing_returns f hm hd C)

end SubmodularMatching
