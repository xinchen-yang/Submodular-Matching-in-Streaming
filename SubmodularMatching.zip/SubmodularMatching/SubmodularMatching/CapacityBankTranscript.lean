import SubmodularMatching.CapacityWordStorage
import SubmodularMatching.CapacityStoredWordQuery

/-! Exact oracle-word transcript of a surviving capacitated guess. -/

namespace SubmodularMatching.Capacity
open Streaming AppendixM
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def bankPrefix (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0 < cap (ends e).1 ∧ 0 < cap (ends e).2)
    (v N bits : ℕ) (oracle : Finset E → ℚ) (edges : ℕ → E)
    (draw : ℕ → ℕ → ℕ → ℕ → ℕ) (b j : ℕ) : ℕ → SparseSlots E cap :=
  let ep := runOnlineEpoch (guessWidth v) (guessSpan v) (edgeClock edges oracle)
  suffixRun (sparseEmpty cap) (fun i st => sparseStep ends cap hpos (wordGrid v) st (edges i)
    (slotWeight v N bits oracle ((ep (i+2)).scale j) (edges i) st (draw i j))) b

def bankRaw {cap : V → ℕ} (st : SparseSlots E cap) (oracle : Finset E → ℚ) (e : E)
    (bits : ℕ) (draw : ℕ → ℕ → ℕ) (r : ℕ) : ℚ :=
  sampleIndexedMarginal oracle (fun i => (st.machine.edges.getD i (e,0)).1) e (draw r)
    (dyadicThreshold sourceProbability bits) st.machine.edges.length

theorem slotWeight_sourceIndex {cap : V → ℕ} (st : SparseSlots E cap)
    (v N bits : ℕ) (oracle : Finset E → ℚ) (e : E) (τ : ℚ) (draw : ℕ → ℕ → ℕ) :
    slotWeight v N bits oracle τ e st draw =
      sourceWeightIndex N (sourceIndex ((streamTolerance*τ/(v:ℚ)^2:ℚ):ℝ)
        (fun r : Fin N => (bankRaw st oracle e bits draw r:ℝ))) := by
  simp only [slotWeight, OnlineInstance.weightIndex, accumulateMarginalLoop_eq, zero_add,
    accumulateMarginal_eq_sourceIndex,bankRaw]

theorem bankRaw_marginal {cap : V → ℕ} (st : SparseSlots E cap)
    (oracle : Finset E → ℚ) (e : E) (bits : ℕ) (draw : ℕ → ℕ → ℕ) (r : ℕ) :
    ∃ A, (bankRaw st oracle e bits draw r:ℝ) = marginal (fun X => (oracle X:ℝ)) e A := by
  unfold bankRaw sampleIndexedMarginal
  refine ⟨selectDyadic (fun i => (st.machine.edges.getD i (e,0)).1) (draw r)
    (dyadicThreshold sourceProbability bits) st.machine.edges.length,?_⟩
  rw [Rat.cast_sub, marginal, Finset.union_singleton]

theorem active_bank_replay (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0 < cap (ends e).1 ∧ 0 < cap (ends e).2)
    (v N bits : ℕ) (hv : 2 ≤ v) (oracle : Finset E → ℚ) (edges : ℕ → E)
    (draw : ℕ → ℕ → ℕ → ℕ → ℕ) (k j : ℕ) :
    let W := (guessWidth v:ℝ)
    let q := seededScale (oracle ∅:ℝ) (fun i => (oracle {edges i}:ℝ))
    let ep := runOnlineEpoch (guessWidth v) (guessSpan v) (edgeClock edges oracle)
    let τ := (ep (k+1)).scale j
    let b := signedBirth W (oracle ∅) (fun i => (oracle {edges i}:ℝ)) j k
    let run := bankPrefix ends cap hpos v N bits oracle edges draw b j
    let samples := fun i (r : Fin N) => (bankRaw (run i) oracle (edges (b+i)) bits (draw (b+i) j) r:ℝ)
    let gap := ((streamTolerance*τ/(v:ℚ)^2:ℚ):ℝ)
    let idx := fun i => (edges (b+i), sourceWeightIndex N (sourceIndex gap (samples i)))
    guessActive W (guessAnchor W q (k+1)) (singletonMaximum q (k+1)) j →
    (forwardBank ends cap hpos v N bits oracle edges draw k).lookup j = some (run (k-b)) ∧
      ∀ i ≤ k-b, run i = sparseRun ends cap hpos (wordGrid v) idx i := by
  intro W q ep τ b run samples gap idx ha
  refine ⟨forwardBank_suffix ends cap hpos v N bits hv oracle edges draw k j ha,?_⟩
  have hq : (fun i => (edgeClock edges oracle i:ℝ)) = q := by funext i; cases i <;> rfl
  intro i
  induction i with
  | zero => exact fun _ => rfl
  | succ i ih =>
    intro hi
    have hba : guessBirth W q j (k+1) < b+i+2 := by
      change guessBirth W q j (k+1) < guessBirth W q j (k+1)-1+i+2
      omega
    have hsc := active_tick_scale (guessWidth v) (guessSpan v) (edgeClock edges oracle) j
      (k+1) (b+i+2) (by rw [hq]; exact ha) (by rw [hq]; exact hba) (by omega)
    change sparseStep ends cap hpos (wordGrid v) (run i) (edges (b+i))
      (slotWeight v N bits oracle ((ep (b+i+2)).scale j) (edges (b+i)) (run i) (draw (b+i) j))
      = sparseStep ends cap hpos (wordGrid v) (sparseRun ends cap hpos (wordGrid v) idx i)
        (edges (b+i)) (idx i).2
    rw [show (ep (b+i+2)).scale j = τ from hsc, slotWeight_sourceIndex]
    change sparseStep ends cap hpos (wordGrid v) (run i) (edges (b+i)) (idx i).2 = _
    rw [ih (by omega)]

end SubmodularMatching.Capacity
