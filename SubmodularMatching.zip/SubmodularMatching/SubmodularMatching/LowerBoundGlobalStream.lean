import SubmodularMatching.LowerBoundGlobalFactorization
import Mathlib.Data.Finset.Dedup

/-! # Ordered, stage-tagged streams from finite base and clone samples -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

/-- Edge endpoints and clone-index pairs are encoded within a stage tag. -/
abbrev StagedEdge (p : ℕ) (Pair Slot : Type*) := Fin p × (Pair × Slot)

def inStage {p : ℕ} {Pair Slot : Type*} (stage : Fin p) :
    Pair × Slot ↪ StagedEdge p Pair Slot where
  toFun e := (stage, e)
  inj' := by intro e f h; exact congrArg Prod.snd h

/-- Stream exactly the sampled slots above each base edge in the specified
base order. This order includes any expansion phases and private leaves. -/
def stageStream {p : ℕ} {Pair Slot : Type*} (stage : Fin p)
    (baseOrder : List Pair) (cloneSamples : Pair → Finset Slot) :
    List (StagedEdge p Pair Slot) :=
  baseOrder.flatMap fun e => (cloneSamples e).toList.map (fun c => (stage, e, c))

theorem mem_stageStream {p : ℕ} {Pair Slot : Type*} (stage : Fin p)
    (baseOrder : List Pair) (cloneSamples : Pair → Finset Slot) (e : StagedEdge p Pair Slot) :
    e ∈ stageStream stage baseOrder cloneSamples ↔
      e.1 = stage ∧ e.2.1 ∈ baseOrder ∧ e.2.2 ∈ cloneSamples e.2.1 := by
  rcases e with ⟨j, b, c⟩
  simp only [stageStream, List.mem_flatMap, List.mem_map, Finset.mem_toList]
  constructor
  · rintro ⟨pair, hp, d, hd, he⟩
    cases he
    exact ⟨rfl, hp, hd⟩
  · rintro ⟨rfl, hb, hc⟩
    exact ⟨b, hb, c, hc, rfl⟩

theorem stageStream_append {p : ℕ} {Pair Slot : Type*} (stage : Fin p)
    (before after : List Pair) (samples : Pair → Finset Slot) :
    stageStream stage (before ++ after) samples =
      stageStream stage before samples ++ stageStream stage after samples := by
  simp [stageStream]

/-- Vertices of different stages have different tags, and the stage blocks
arrive in increasing order. -/
def sequentialStream {p : ℕ} {Pair Slot : Type*}
    (baseOrder : Fin p → List Pair) (cloneSamples : Fin p → Pair → Finset Slot) :
    List (StagedEdge p Pair Slot) :=
  (List.finRange p).flatMap fun j => stageStream j (baseOrder j) (cloneSamples j)

theorem finRange_increasing (p : ℕ) :
    (List.finRange p).Pairwise (fun a b => a < b) := by
  induction p with
  | zero => simp
  | succ p ih =>
    rw [List.finRange_succ, List.pairwise_cons, List.pairwise_map]
    refine ⟨?_, ih.imp ?_⟩
    · intro a ha
      obtain ⟨b, _, rfl⟩ := List.mem_map.mp ha
      change 0 < b.val + 1
      omega
    · intro a b h
      exact Fin.succ_lt_succ_iff.mpr h

private theorem cut_ordered_list {α : Type*} [LT α] {order : List α} {i : α}
    (hin : i ∈ order) (hord : order.Pairwise (fun a b => a < b)) :
    ∃ before after, order = before ++ i :: after ∧
      (∀ j ∈ before, j < i) ∧ (∀ j ∈ after, i < j) := by
  induction order with
  | nil => simp at hin
  | cons h t ih =>
    have hstep := List.pairwise_cons.mp hord
    rcases List.mem_cons.mp hin with he | ht
    · subst h
      exact ⟨[], t, rfl, by simp, hstep.1⟩
    · obtain ⟨before, after, he, hb, ha⟩ := ih ht hstep.2
      refine ⟨h :: before, after, by simp [he], ?_, ha⟩
      intro j hj
      rcases List.mem_cons.mp hj with rfl | hj
      · exact hstep.1 _ ht
      · exact hb j hj

theorem finRange_cut {p : ℕ} (i : Fin p) :
    ∃ before after, List.finRange p = before ++ i :: after ∧
      (∀ j ∈ before, j < i) ∧ (∀ j ∈ after, i < j) :=
  cut_ordered_list (List.mem_finRange i) (finRange_increasing p)

theorem sequentialStream_cut {p : ℕ} {Pair Slot : Type*}
    (baseOrder : Fin p → List Pair) (cloneSamples : Fin p → Pair → Finset Slot) (i : Fin p)
    (before after : List (Fin p)) (h : List.finRange p = before ++ i :: after) :
    sequentialStream baseOrder cloneSamples =
      (before.flatMap fun j => stageStream j (baseOrder j) (cloneSamples j)) ++
      stageStream i (baseOrder i) (cloneSamples i) ++
      (after.flatMap fun j => stageStream j (baseOrder j) (cloneSamples j)) := by
  unfold sequentialStream
  rw [h]
  simp [List.append_assoc]

end

end SubmodularMatching.LowerBoundGlobal
