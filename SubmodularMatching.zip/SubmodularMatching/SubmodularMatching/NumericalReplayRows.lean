import SubmodularMatching.CertificateDataKnots

/-!
# Integer replay of the Appendix L integration witnesses

For each interval the two weighted-log witnesses are checked by multiplying
out nonnegative integer denominators. A balanced subdivision keeps the
closed computations and their proofs small.
-/

namespace SubmodularMatching.SourceCertificate.Replay

def WeightValid (a b dh e w : ℕ) : Prop :=
  if e = 0 then
    weightScale * dh * (12*a*b + (b-a)^2) ≤ w * (6*a*b*(a+b))
  else
    b ≤ 2^e*a ∧ weightScale*dh*7*e ≤ w * (10*(b-a))

instance (a b dh e w : ℕ) : Decidable (WeightValid a b dh e w) := by
  unfold WeightValid
  infer_instance

def ValidRow (r s : Point) : Prop :=
  r.x < s.x ∧ r.h₀ ≤ s.h₀ ∧ r.h₁ ≤ s.h₁ ∧
  WeightValid r.x s.x (s.h₀-r.h₀) r.exponent r.w₀ ∧
  WeightValid r.x s.x (s.h₁-r.h₁) r.exponent r.w₁

instance (r s : Point) : Decidable (ValidRow r s) := by
  unfold ValidRow
  infer_instance

def rowCheck (i : ℕ) : Bool := decide (ValidRow (point i) (point (i+1)))

def allRows (f : ℕ → Bool) (start : ℕ) : ℕ → Bool
  | 0 => true
  | n+1 => f (start+n) && allRows f start n

theorem allRows_sound {f : ℕ → Bool} {start n : ℕ} (h : allRows f start n = true)
    {i : ℕ} (hi : start ≤ i) (hi' : i < start+n) : f i = true := by
  induction n with
  | zero => omega
  | succ n ih =>
    obtain ⟨hl, hr⟩ := Bool.and_eq_true_iff.mp h
    by_cases he : i = start+n
    · exact he ▸ hl
    · exact ih hr (by omega)

def summedWeight (b : Bool) (start : ℕ) : ℕ → ℕ
  | 0 => 0
  | n+1 => summedWeight b start n + (point (start+n)).weight b

set_option maxRecDepth 12000
set_option maxHeartbeats 3000000

private theorem rows0 : allRows rowCheck 0 64 = true := by decide +kernel
private theorem rows64 : allRows rowCheck 64 64 = true := by decide +kernel
private theorem rows128 : allRows rowCheck 128 64 = true := by decide +kernel
private theorem rows192 : allRows rowCheck 192 64 = true := by decide +kernel
private theorem rows256 : allRows rowCheck 256 64 = true := by decide +kernel
private theorem rows320 : allRows rowCheck 320 64 = true := by decide +kernel
private theorem rows384 : allRows rowCheck 384 64 = true := by decide +kernel
private theorem rows448 : allRows rowCheck 448 64 = true := by decide +kernel
private theorem rows512 : allRows rowCheck 512 64 = true := by decide +kernel
private theorem rows576 : allRows rowCheck 576 64 = true := by decide +kernel
private theorem rows640 : allRows rowCheck 640 64 = true := by decide +kernel
private theorem rows704 : allRows rowCheck 704 64 = true := by decide +kernel
private theorem rows768 : allRows rowCheck 768 64 = true := by decide +kernel
private theorem rows832 : allRows rowCheck 832 64 = true := by decide +kernel
private theorem rows896 : allRows rowCheck 896 64 = true := by decide +kernel
private theorem rows960 : allRows rowCheck 960 64 = true := by decide +kernel
private theorem rows1024 : allRows rowCheck 1024 64 = true := by decide +kernel
private theorem rows1088 : allRows rowCheck 1088 47 = true := by decide +kernel

theorem checked_rows (i : ℕ) (hi : i < 1135) : ValidRow (point i) (point (i+1)) := by
  apply of_decide_eq_true
  change rowCheck i = true
  by_cases h0 : i < 64
  · exact allRows_sound rows0 (by omega) (by omega)
  by_cases h64 : i < 128
  · exact allRows_sound rows64 (by omega) (by omega)
  by_cases h128 : i < 192
  · exact allRows_sound rows128 (by omega) (by omega)
  by_cases h192 : i < 256
  · exact allRows_sound rows192 (by omega) (by omega)
  by_cases h256 : i < 320
  · exact allRows_sound rows256 (by omega) (by omega)
  by_cases h320 : i < 384
  · exact allRows_sound rows320 (by omega) (by omega)
  by_cases h384 : i < 448
  · exact allRows_sound rows384 (by omega) (by omega)
  by_cases h448 : i < 512
  · exact allRows_sound rows448 (by omega) (by omega)
  by_cases h512 : i < 576
  · exact allRows_sound rows512 (by omega) (by omega)
  by_cases h576 : i < 640
  · exact allRows_sound rows576 (by omega) (by omega)
  by_cases h640 : i < 704
  · exact allRows_sound rows640 (by omega) (by omega)
  by_cases h704 : i < 768
  · exact allRows_sound rows704 (by omega) (by omega)
  by_cases h768 : i < 832
  · exact allRows_sound rows768 (by omega) (by omega)
  by_cases h832 : i < 896
  · exact allRows_sound rows832 (by omega) (by omega)
  by_cases h896 : i < 960
  · exact allRows_sound rows896 (by omega) (by omega)
  by_cases h960 : i < 1024
  · exact allRows_sound rows960 (by omega) (by omega)
  by_cases h1024 : i < 1088
  · exact allRows_sound rows1024 (by omega) (by omega)
  exact allRows_sound rows1088 (by omega) (by omega)

theorem weight_sum_false : summedWeight false 1 1134 = 999999952548740 := by decide +kernel
theorem weight_sum_true : summedWeight true 1 1134 = 996493758737123 := by decide +kernel

end SubmodularMatching.SourceCertificate.Replay
