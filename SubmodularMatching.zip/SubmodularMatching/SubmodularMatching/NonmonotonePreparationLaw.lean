import SubmodularMatching.NonmonotoneWordBudget
import SubmodularMatching.UpperBoundFiniteExecution

/-! The marked finite preparation law for histories of actual word queries.
Its Boolean coordinate records accuracy only for the analysis. -/
namespace SubmodularMatching.Streaming.OracleQuery
open MeasureTheory UpperBoundAssembly GibbsSampler
noncomputable section
variable {E State : Type*} [DecidableEq E]
variable (choose : ℕ → State → OracleQuery E) (N bits : ℕ)
variable (step : (i : ℕ) → (st : State) → WordBatch N (choose i st).size bits → State)

def WordAccurate (d : ℝ) (i : ℕ) (st : State)
    (ω : WordBatch N (choose i st).size bits) : Prop :=
  let Q := choose i st
  Q.target-d ≤ sourceAverage d (fun j => Q.wordValue bits (ω j)) ∧
    sourceAverage d (fun j => Q.wordValue bits (ω j)) ≤ Q.target+d

def preparationLaw (d : ℝ) : ℕ → ℕ → State → Bool → CandidateLaw (State × Bool)
  | 0,_,st,flag => CandidateLaw.pure (st,flag)
  | n+1,i,st,flag => by
    classical
    exact (CandidateLaw.ofMeasure (wordBatchLaw N (choose i st).size bits)).bind
      (fun ω => preparationLaw d n (i+1) (step i st ω)
        (flag && decide (WordAccurate choose N bits d i st ω)))

def unmarkedLaw : ℕ → ℕ → State → CandidateLaw State
  | 0,_,st => CandidateLaw.pure st
  | n+1,i,st => by
    classical
    exact (CandidateLaw.ofMeasure (wordBatchLaw N (choose i st).size bits)).bind
      (fun ω => unmarkedLaw n (i+1) (step i st ω))

theorem preparation_observable (d : ℝ) (test : State → ℝ) (n i : ℕ) (st : State) (flag : Bool) :
    let p := preparationLaw choose N bits step d n i st flag
    let q := unmarkedLaw choose N bits step n i st
    expected p.outcomes p.mass (fun a => test a.1) = expected q.outcomes q.mass test := by
  classical
  induction n generalizing i st flag with
  | zero => simp only [preparationLaw,unmarkedLaw,CandidateLaw.pure_expected]
  | succ n ih =>
    dsimp only [preparationLaw,unmarkedLaw]
    rw [CandidateLaw.bind_expected,CandidateLaw.bind_expected]
    apply Finset.sum_congr rfl
    intro x _
    apply congrArg (_ * ·)
    exact ih _ _ _

private theorem bad_persists (d : ℝ) (n i : ℕ) (st : State) :
    let p := preparationLaw choose N bits step d n i st false
    expected p.outcomes p.mass (fun a => if a.2 then 0 else 1) = 1 := by
  classical
  induction n generalizing i st with
  | zero => simp [preparationLaw,CandidateLaw.pure_expected]
  | succ n ih =>
    dsimp only [preparationLaw,Bool.false_and]
    rw [CandidateLaw.bind_expected]
    let q := CandidateLaw.ofMeasure (wordBatchLaw N (choose i st).size bits)
    apply Eq.trans _ q.probability.total
    apply Finset.sum_congr rfl
    intro ω _
    dsimp only
    rw [Bool.false_and,ih,mul_one]

theorem marked_bad_mass (d : ℝ) (n i : ℕ) (st : State) :
    let p := preparationLaw choose N bits step d n i st true
    expected p.outcomes p.mass (fun a => if a.2 then 0 else 1) =
      adaptiveEstimateFailure (fun i st => wordBatchLaw N (choose i st).size bits) step
        (WordAccurate choose N bits d) n i st := by
  classical
  induction n generalizing i st with
  | zero => simp [preparationLaw,CandidateLaw.pure_expected,adaptiveEstimateFailure]
  | succ n ih =>
    dsimp only [preparationLaw,Bool.true_and]
    rw [CandidateLaw.bind_expected,CandidateLaw.ofMeasure_expected,adaptiveEstimateFailure]
    congr 1
    funext ω
    by_cases h : WordAccurate choose N bits d i st ω
    · simpa [h] using ih (i+1) (step i st ω)
    · simpa [h] using bad_persists choose N bits step d n (i+1) (step i st ω)

theorem preparation_confidence (K J calls : ℕ) (hK : 0<K) (hJ : 0<J) (hc : calls≤K)
    (lo hi d : ℝ) (hd : 0<d) (hwidth : 0<hi-lo) (hratio : hi-lo ≤ (K:ℝ)*d)
    (sizeBound : ∀ i st, (choose i st).size ≤ K)
    (advance : (i : ℕ) → (st : State) →
      WordBatch (batchCount K J) (choose i st).size (batchBits K) → State)
    (hrange : ∀ i st A, A ⊆ (Finset.range (choose i st).size).image (choose i st).edges →
      lo ≤ (choose i st).evaluate A ∧ (choose i st).evaluate A ≤ hi) (initial : State) :
    let p := preparationLaw choose (batchCount K J) (batchBits K) advance d calls 0 initial true
    (∑ a ∈ p.outcomes, if a.2 then 0 else p.mass a) ≤ 1/(J:ℝ) := by
  intro p
  have h := (marked_bad_mass choose (batchCount K J) (batchBits K) advance d calls 0 initial).trans_le
    (adaptive_word_budget choose K J calls hK hJ hc lo hi d hd hwidth hratio sizeBound advance hrange initial)
  convert h using 1
  apply Finset.sum_congr rfl
  intro a _
  rcases a with ⟨s,b⟩
  cases b <;> simp [p]

end
end SubmodularMatching.Streaming.OracleQuery
