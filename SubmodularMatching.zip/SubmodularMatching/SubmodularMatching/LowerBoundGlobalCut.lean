import SubmodularMatching.LowerBoundGlobalExecution
import SubmodularMatching.LowerBoundInformation

/-! # Recoverable edges across a cut of a legal execution -/

namespace SubmodularMatching.LowerBoundGlobal

open scoped BigOperators

noncomputable section

variable {E State Sample Side : Type*} [DecidableEq E]

/-- Fix all side information except the sample retained before a boundary.
The suffix and the oracle may depend on subsequently revealed information.
Neither may depend on the retained sample. The state function is extracted
from a legal prefix, and its factorization through the sample records the
independence available at that particular cut. -/
structure Cut (m : Machine E State) (μ : Sample → ℝ) where
  oldEdges : Finset E
  sampled : Sample → Finset E
  before : Sample → List E
  after : Side → List E
  oracle : Side → Finset E → ℝ
  state : Sample → State
  cut_state : ∀ sample side, 0 < μ sample →
    m.boundary (oracle side) m.initial (before sample) = state sample
  before_mem : ∀ sample e, 0 < μ sample → e ∈ before sample →
    e ∈ oldEdges → e ∈ sampled sample
  after_fresh : ∀ side e, e ∈ after side → e ∉ oldEdges
  legal : ∀ sample side, 0 < μ sample →
    m.legal (oracle side) (before sample ++ after side)

namespace Cut

variable {m : Machine E State} {μ : Sample → ℝ}

def continuation (cut : Cut (Side := Side) m μ) (state : State) (side : Side) : Finset E :=
  m.outputFrom (cut.oracle side) state (cut.after side) ∩ cut.oldEdges

theorem continuation_eq_output (cut : Cut (Side := Side) m μ)
    (sample : Sample) (side : Side) (hsample : 0 < μ sample) :
    cut.continuation (cut.state sample) side =
      m.output (cut.oracle side) (cut.before sample ++ cut.after side) ∩ cut.oldEdges := by
  rw [continuation, m.output_append, cut.cut_state sample side hsample]

/-- Every old edge the actual continuation outputs was retained in the
sample. This follows from legality, even when the state contains an encoded
summary and the continuation makes arbitrary adaptive queries. -/
theorem continuation_subset_sampled (cut : Cut (Side := Side) m μ)
    (sample : Sample) (hsample : 0 < μ sample) (side : Side) :
    cut.continuation (cut.state sample) side ⊆ cut.sampled sample := by
  rw [cut.continuation_eq_output sample side hsample]
  intro e he
  obtain ⟨hout, hu⟩ := Finset.mem_inter.mp he
  have hinput := (cut.legal sample side hsample).2.2 hout
  rcases List.mem_append.mp (List.mem_toFinset.mp hinput) with hp | hs
  · exact cut.before_mem sample e hsample hp hu
  · exact (cut.after_fresh side e hs hu).elim

theorem continuation_subset_certainty [Fintype E] (cut : Cut (Side := Side) m μ)
    (state : State) (side : Side) :
    cut.continuation state side ⊆ Information.certainty μ cut.sampled cut.state state :=
  Information.continuation_subset_certainty μ cut.sampled cut.state cut.continuation
    cut.continuation_subset_sampled state side

/-- When the oracle is already fixed (conditioning on every label), the
prefix state is shared simply because its observed arrivals are shared. -/
def fixedOracleCut
    (m : Machine E State) (μ : Sample → ℝ) (oldEdges : Finset E)
    (sampled : Sample → Finset E) (before : Sample → List E) (after : Side → List E)
    (oracle : Finset E → ℝ)
    (hbefore : ∀ sample e, 0 < μ sample → e ∈ before sample →
      e ∈ oldEdges → e ∈ sampled sample)
    (hafter : ∀ side e, e ∈ after side → e ∉ oldEdges)
    (hlegal : ∀ sample side, 0 < μ sample → m.legal oracle (before sample ++ after side)) :
    Cut (Side := Side) m μ where
  oldEdges := oldEdges
  sampled := sampled
  before := before
  after := after
  oracle := fun _ => oracle
  state := fun sample => m.boundary oracle m.initial (before sample)
  cut_state := fun _ _ _ => rfl
  before_mem := hbefore
  after_fresh := hafter
  legal := hlegal

/-- Construct the stage cut directly from legality and oracle prefix
invisibility. The current and later labels may differ in the continuation. -/
def stageCut
    (m : Machine E State) (μ : Sample → ℝ) (oldEdges : Finset E)
    (sampled : Sample → Finset E) (before : Sample → List E) (after : Side → List E)
    (unit : ℝ) (hunit : 0 ≤ unit) (stage : E → ℕ) (labels : Side → E → Bool)
    (reference : Side) (start count cutoff : ℕ)
    (harrival : ∀ sample, 0 < μ sample → ∀ e ∈ before sample, stage e ≤ cutoff)
    (hearlier : ∀ side e, stage e < cutoff → labels side e = labels reference e)
    (hbefore : ∀ sample e, 0 < μ sample → e ∈ before sample →
      e ∈ oldEdges → e ∈ sampled sample)
    (hafter : ∀ side e, e ∈ after side → e ∉ oldEdges)
    (hlegal : ∀ sample side, 0 < μ sample →
      m.legal (RecursiveObjective.objective unit stage (labels side) start count)
        (before sample ++ after side)) :
    Cut (Side := Side) m μ :=
  { oldEdges := oldEdges
    sampled := sampled
    before := before
    after := after
    oracle := fun side => RecursiveObjective.objective unit stage (labels side) start count
    state := fun sample => m.boundary
      (RecursiveObjective.objective unit stage (labels reference) start count)
      m.initial (before sample)
    cut_state := fun sample side hs =>
      m.boundary_hidden_label_invariant unit hunit stage (labels side) (labels reference)
        start count cutoff (before sample) (harrival sample hs) (hearlier side)
        (m.legalPrefix_of_append _ (hlegal sample side hs).1)
    before_mem := hbefore
    after_fresh := hafter
    legal := hlegal }

/-- Every actual matching output has at most the distinguished recovery
count bound at the stage cut. Independent fixing of the side information
preserves this inequality before averaging. -/
theorem expected_distinguished_le [Fintype Sample] [Finite E] [Fintype Side] [Nonempty Side]
    [DecidableEq Side] [Fintype State] [Nonempty State]
    (cut : Cut (Side := Side) m μ) (publicLabel : E → Side)
    (q : ℝ) (s : ℕ) (hμ : ∀ sample, 0 ≤ μ sample) (hμsum : ∑ sample, μ sample = 1)
    (hq0 : 0 < q) (hq1 : q < 1)
    (hinclusion : ∀ A : Finset E,
      (∑ sample, if A ⊆ cut.sampled sample then μ sample else 0) ≤ q ^ A.card)
    (hstates : Fintype.card State ≤ 2 ^ s) :
    (∑ sample, μ sample * ((∑ label,
      (((m.output (cut.oracle label) (cut.before sample ++ cut.after label) ∩ cut.oldEdges).filter
        (fun e => publicLabel e = label)).card : ℝ)) / (Fintype.card Side : ℝ))) ≤
      s / ((Fintype.card Side : ℝ) * Real.logb 2 (1 / q)) := by
  have heq : (∑ sample, μ sample * ((∑ label,
      (((m.output (cut.oracle label) (cut.before sample ++ cut.after label) ∩ cut.oldEdges).filter
        (fun e => publicLabel e = label)).card : ℝ)) / (Fintype.card Side : ℝ))) =
      ∑ sample, μ sample * ((∑ label,
        (((cut.continuation (cut.state sample) label).filter
          (fun e => publicLabel e = label)).card : ℝ)) / (Fintype.card Side : ℝ)) := by
    apply Finset.sum_congr rfl
    intro sample _
    by_cases hs : 0 < μ sample
    · simp only [cut.continuation_eq_output sample _ hs]
    · simp [le_antisymm (not_lt.mp hs) (hμ sample)]
  rw [heq]
  exact Information.expected_distinguished_recovery_le μ cut.sampled cut.state publicLabel
    cut.continuation q s hμ hμsum hq0 hq1 hinclusion hstates cut.continuation_subset_sampled

end Cut

end

end SubmodularMatching.LowerBoundGlobal
