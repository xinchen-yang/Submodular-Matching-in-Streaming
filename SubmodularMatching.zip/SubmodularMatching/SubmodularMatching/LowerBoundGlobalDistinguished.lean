import SubmodularMatching.LowerBoundGlobalLabelLaw

/-! # The distinguished-edge count for the full experiment -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

variable {p : ℕ} {Pair Slot Label State Base : Type*}
variable [Fintype Pair] [Fintype Slot] [Fintype Label] [Nonempty Label]
variable [DecidableEq Pair] [DecidableEq Slot] [DecidableEq Label]
variable [Fintype State] [Nonempty State]

def stageLabel (publicLabel : Pair × Slot → Label)
    (draw : Fin p → StageDraw Pair Slot Label) (e : StagedEdge p Pair Slot) : Bool :=
  decide (publicLabel e.2 = (draw e.1).2)

def mixedOracle (unit : ℝ) (publicLabel : Pair × Slot → Label)
    (draw : Fin p → StageDraw Pair Slot Label) : Finset (StagedEdge p Pair Slot) → ℝ :=
  RecursiveObjective.objective unit (fun e => e.1.val) (stageLabel publicLabel draw) 0 p

/-- The filtered output counts actual physical edges, each with one
canonical tag and one publicLabel clone label. -/
def distinguishedCount (m : Machine (StagedEdge p Pair Slot) State) (unit : ℝ)
    (publicLabel : Pair × Slot → Label) (orders : Fin p → List Pair) (i : Fin p)
    (draw : Fin p → StageDraw Pair Slot Label) : ℝ :=
  (((m.output (mixedOracle unit publicLabel draw) (sequentialStream orders (fun j => (draw j).1))).filter
    (fun e => e.1 = i ∧ publicLabel e.2 = (draw i).2)).card : ℝ)

omit [Fintype Pair] [Fintype Slot] [Fintype Label] [Nonempty Label]
  [DecidableEq Pair] [DecidableEq Slot] [DecidableEq Label] [Fintype State] [Nonempty State] in
private theorem draw_stream_cut
    (orders : Fin p → List Pair) (i : Fin p)
    (earlier later : List (Fin p)) (hcut : List.finRange p = earlier ++ i :: later)
    (hearlier : ∀ j ∈ earlier, j < i) (hlater : ∀ j ∈ later, i < j)
    (other : {j : Fin p // j ≠ i} → StageDraw Pair Slot Label)
    (reference : StageDraw Pair Slot Label) (S : Pair → Finset Slot) (o : Label) :
    let fixed := replaceStage i reference other
    sequentialStream orders (fun j => (replaceStage i (S, o) other j).1) =
      ((earlier.flatMap fun j => stageStream j (orders j) (fixed j).1) ++
        stageStream i (orders i) S) ++
      (later.flatMap fun j => stageStream j (orders j) (fixed j).1) := by
  intro fixed
  rw [sequentialStream_cut _ _ _ _ _ hcut, replaceStage_self]
  have hbefore :
      (earlier.flatMap fun j => stageStream j (orders j) (replaceStage i (S, o) other j).1) =
      (earlier.flatMap fun j => stageStream j (orders j) (fixed j).1) := by
    apply List.flatMap_congr
    intro j hj
    rw [replaceStage_other _ _ _ _ (ne_of_lt (hearlier _ hj))]
    unfold fixed
    rw [replaceStage_other _ _ _ _ (ne_of_lt (hearlier _ hj))]
  have hafter :
      (later.flatMap fun j => stageStream j (orders j) (replaceStage i (S, o) other j).1) =
      (later.flatMap fun j => stageStream j (orders j) (fixed j).1) := by
    apply List.flatMap_congr
    intro j hj
    rw [replaceStage_other _ _ _ _ (ne_of_gt (hlater _ hj))]
    unfold fixed
    rw [replaceStage_other _ _ _ _ (ne_of_gt (hlater _ hj))]
  rw [hbefore, hafter]

/-- Fix all other stage samples and labels and bound one coordinate. The
stream cut and the availability of its edges follow from the constructed
stream, so the only program premise is legality on the supported draws. -/
theorem distinguished_conditioned_on_other_stages
    (m : Machine (StagedEdge p Pair Slot) State) (unit : ℝ) (hunit : 0 ≤ unit)
    (publicLabel : Pair × Slot → Label) (orders : Fin p → List Pair) (i : Fin p)
    (U : Pair → Finset Slot) (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (hU : ∀ b, 0 < (U b).card) (s : ℕ) (hstates : Fintype.card State ≤ 2 ^ s)
    (other : {j : Fin p // j ≠ i} → StageDraw Pair Slot Label)
    (hlegal : ∀ x, 0 < stageDrawMass U q x →
      let draw := replaceStage i x other
      m.legal (mixedOracle unit publicLabel draw) (sequentialStream orders (fun j => (draw j).1))) :
    (∑ x, stageDrawMass U q x * distinguishedCount m unit publicLabel orders i (replaceStage i x other)) ≤
      s / ((Fintype.card Label : ℝ) * Real.logb 2 (1 / q)) := by
  classical
  obtain ⟨earlier, later, horder, hlt, hgt⟩ := finRange_cut i
  let reference : Label := Classical.choice inferInstance
  let dummy : Pair → Finset Slot := fun _ => ∅
  let fixed : Fin p → StageDraw Pair Slot Label := replaceStage i (dummy, reference) other
  let history := earlier.flatMap (fun j => stageStream j (orders j) (fixed j).1)
  let tail := later.flatMap (fun j => stageStream j (orders j) (fixed j).1)
  let before := fun S => history ++ stageStream i (orders i) S
  let labels := fun o => stageLabel publicLabel (replaceStage i (dummy, o) other)
  let oldEdges := Finset.univ.filter (fun e : StagedEdge p Pair Slot => e.1 = i)
  have hh : ∀ S o, sequentialStream orders (fun j => (replaceStage i (S, o) other j).1) =
      before S ++ tail := by
    intro S o
    exact draw_stream_cut orders i earlier later horder hlt hgt other (dummy, reference) S o
  have hlabel : ∀ S o, stageLabel publicLabel (replaceStage i (S, o) other) = labels o := by
    intro S o
    funext e
    by_cases he : e.1 = i
    · simp [labels, stageLabel, he]
    · simp only [labels, stageLabel, replaceStage_other _ _ _ _ he]
  have hbeforeStage : ∀ S e, e ∈ before S → e.1 ≤ i := by
    intro S e he
    rcases List.mem_append.mp he with h | h
    · obtain ⟨j, hj, h⟩ := List.mem_flatMap.mp h
      exact ((mem_stageStream _ _ _ _).mp h).1.le.trans (hlt j hj).le
    · exact ((mem_stageStream _ _ _ _).mp h).1.le
  have hearlier : ∀ o e, e.1.val < i.val → labels o e = labels reference e := by
    intro o e he
    have hn : e.1 ≠ i := ne_of_lt he
    simp only [labels, stageLabel, replaceStage_other _ _ _ _ hn]
  have hbefore : ∀ S e, e ∈ before S → e ∈ oldEdges →
      e ∈ (taggedSample S).map (inStage i) := by
    intro S e h he
    have hei : e.1 = i := (Finset.mem_filter.mp he).2
    rcases List.mem_append.mp h with h | h
    · obtain ⟨j, hj, hm⟩ := List.mem_flatMap.mp h
      have hstage := ((mem_stageStream _ _ _ _).mp hm).1
      exact (ne_of_lt (hlt j hj) (hstage.symm.trans hei)).elim
    · have hslot := ((mem_stageStream _ _ _ _).mp h).2.2
      exact Finset.mem_map.mpr ⟨e.2, by simp [taggedSample, hslot],
        Prod.ext hei.symm rfl⟩
  have hafter : ∀ e, e ∈ tail → e ∉ oldEdges := by
    intro e he hit
    obtain ⟨j, hj, hm⟩ := List.mem_flatMap.mp he
    have hej := ((mem_stageStream _ _ _ _).mp hm).1
    have hei := (Finset.mem_filter.mp hit).2
    exact ne_of_gt (hgt j hj) (hej.symm.trans hei)
  have hlegal' (S : Pair → Finset Slot) (o : Label)
      (hS : 0 < independentSubsetMass U (fun b => retainedSize q (U b).card) S) :
      m.legal (RecursiveObjective.objective unit (fun e : StagedEdge p Pair Slot => e.1)
          (labels o) 0 p) (before S ++ tail) := by
    have hpos : 0 < stageDrawMass U q (S, o) :=
      (stageDrawMass_pos_iff U q _).2 hS
    have h := hlegal (S, o) hpos
    simpa only [mixedOracle, hh, hlabel] using h
  have hb := distinguished_stage_recovery m (inStage i) U q hq0 hq1 hU oldEdges
    before (fun _ => tail) unit hunit
    (fun e : StagedEdge p Pair Slot => e.1.val) labels reference 0 p i.val
    (fun S _ e he => hbeforeStage S e he) hearlier (fun S e _ => hbefore S e)
    (fun _ => hafter) hlegal' (fun e => publicLabel e.2) s hstates
  rw [expectation_stageDraw]
  convert hb using 1
  apply Finset.sum_congr rfl
  intro S _
  congr 1
  congr 1
  apply Finset.sum_congr rfl
  intro o _
  unfold distinguishedCount mixedOracle
  rw [hh, hlabel, replaceStage_self]
  norm_cast
  congr 1
  ext e
  simp [oldEdges, and_assoc]

/-- Global distinguished-edge estimate for the actual joint law, after
averaging over all base outcomes, other stage draws, and fixed coins (which
may be included in the base outcome). -/
theorem global_distinguished_count_le [Fintype Base]
    (m : Base → Machine (StagedEdge p Pair Slot) State) (unit : ℝ) (hunit : 0 ≤ unit)
    (publicLabel : Pair × Slot → Label) (orders : Base → Fin p → List Pair) (i : Fin p)
    (baseLaw : Base → ℝ) (hbase0 : ∀ z, 0 ≤ baseLaw z) (hbase : ∑ z, baseLaw z = 1)
    (U : Pair → Finset Slot) (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (hU : ∀ b, 0 < (U b).card) (s : ℕ) (hstates : Fintype.card State ≤ 2 ^ s)
    (hlegal : ∀ z (draw : Fin p → StageDraw Pair Slot Label), 0 < baseLaw z →
      (∀ j, 0 < stageDrawMass U q (draw j)) →
      (m z).legal (mixedOracle unit publicLabel draw) (sequentialStream (orders z) (fun j => (draw j).1))) :
    (∑ input : Base × (Fin p → StageDraw Pair Slot Label),
      baseLaw input.1 * (∏ j, stageDrawMass U q (input.2 j)) *
        distinguishedCount (m input.1) unit publicLabel (orders input.1) i input.2) ≤
      s / ((Fintype.card Label : ℝ) * Real.logb 2 (1 / q)) := by
  apply average_independent_coordinate (I := Fin p) (A := StageDraw Pair Slot Label)
    baseLaw hbase0 hbase (fun _ _ => stageDrawMass U q)
    (fun _ _ => stageDrawMass_nonneg U q) (fun _ _ => stageDrawMass_total U q hq0.le hq1.le)
    (fun z draw => distinguishedCount (m z) unit publicLabel (orders z) i draw) i
  intro z other hz ho
  apply distinguished_conditioned_on_other_stages (m z) unit hunit publicLabel (orders z) i U q
    hq0 hq1 hU s hstates other
  intro x hx
  apply hlegal z _ hz
  intro j
  by_cases hj : j = i
  · subst j
    simpa using hx
  · rw [replaceStage_other _ _ _ _ hj]
    have hne := Finset.prod_ne_zero_iff.mp (ne_of_gt ho) ⟨j, hj⟩ (Finset.mem_univ _)
    exact lt_of_le_of_ne (stageDrawMass_nonneg U q _) hne.symm

end

end SubmodularMatching.LowerBoundGlobal
