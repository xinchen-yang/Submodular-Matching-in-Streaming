import SubmodularMatching.PackingResourcesScan

/-! # Integer incidence products on compact vertex arrays -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint
open scoped BigOperators

noncomputable section

variable {m n : ℕ}

private def addIntegerEndpoints (endpoints : Fin n × Fin n) (value : ℤ)
    (state : Vector ℤ n) : Vector ℤ n :=
  let u := endpoints.1
  let v := endpoints.2
  let newer := state.set u.val (state[u.val] + value)
  newer.set v.val (newer[v.val] + value)

private theorem addIntegerEndpoints_get (endpoints : Fin n × Fin n) (value : ℤ)
    (state : Vector ℤ n) (hloop : endpoints.1 ≠ endpoints.2) (i : Fin n) :
    (addIntegerEndpoints endpoints value state)[i.val] =
      state[i.val] + if i = endpoints.1 ∨ i = endpoints.2 then value else 0 := by
  have hneq : endpoints.1.val ≠ endpoints.2.val := fun h => hloop (Fin.ext h)
  unfold addIntegerEndpoints
  by_cases hv : i = endpoints.2
  · subst i
    simp [hneq]
  · have hv' : endpoints.2.val ≠ i.val := fun h => hv (Fin.ext h.symm)
    rw [Vector.getElem_set_ne _ _ hv']
    by_cases hu : i = endpoints.1
    · subst i
      simp
    · have hu' : endpoints.1.val ≠ i.val := fun h => hu (Fin.ext h.symm)
      rw [Vector.getElem_set_ne _ _ hu']
      simp [hu, hv]

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- One edge scan builds all vertex loads. It holds one integer per
compressed vertex and performs two additions per edge. -/
def scanIntegerIncidences (ends : Fin m → V × V) (weight : Fin m → ℤ) : V → ℤ :=
  let index := Fintype.equivFin V
  let step := fun state e =>
    addIntegerEndpoints (index (ends e).1, index (ends e).2) (weight e) state
  let loads := Fin.foldl m step (Vector.replicate (Fintype.card V) 0)
  fun v => loads[(index v).val]

/-- The integer vertex loads coincide with the ideal matrix degree products. -/
theorem scanIntegerIncidences_cast (ends : Fin m → V × V) (weight : Fin m → ℤ)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (v : V) :
    (scanIntegerIncidences ends weight v : ℝ) = degree ends (fun e => (weight e : ℝ)) v := by
  let index := Fintype.equivFin V
  let step := fun state e =>
    addIntegerEndpoints (index (ends e).1, index (ends e).2) (weight e) state
  let oneEdge (e : Fin m) : ℤ := if v = (ends e).1 ∨ v = (ends e).2 then weight e else 0
  have hstep (state : Vector ℤ (Fintype.card V)) (e : Fin m) :
      (step state e)[(index v).val] = state[(index v).val] + oneEdge e := by
    simpa only [step, oneEdge, Equiv.apply_eq_iff_eq] using
      addIntegerEndpoints_get (index (ends e).1, index (ends e).2) (weight e) state
        (fun he => hloop e (index.injective he)) (index v)
  have hfold (edges : List (Fin m)) (state : Vector ℤ (Fintype.card V)) :
      (edges.foldl step state)[(index v).val] = state[(index v).val] + (edges.map oneEdge).sum := by
    induction edges generalizing state with
    | nil => simp
    | cons e edges ih =>
      rw [List.foldl_cons, ih, hstep, List.map_cons, List.sum_cons, add_assoc]
  have huniv : (List.finRange m).toFinset = Finset.univ := by ext e; simp
  change ((Fin.foldl m step (Vector.replicate (Fintype.card V) 0))[(index v).val] : ℝ) = _
  rw [Fin.foldl_eq_finRange_foldl, hfold, Vector.getElem_replicate, zero_add]
  rw [← List.sum_toFinset oneEdge (List.nodup_finRange m), huniv]
  push_cast
  unfold degree
  apply Finset.sum_congr rfl
  intro e _
  by_cases h : v = (ends e).1 ∨ v = (ends e).2 <;> simp [oneEdge, incidence, h]

end

end SubmodularMatching.UpperBoundAssembly
