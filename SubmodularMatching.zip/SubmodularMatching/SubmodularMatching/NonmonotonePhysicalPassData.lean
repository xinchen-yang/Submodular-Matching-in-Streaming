import SubmodularMatching.NonmonotoneRetainedPassAction

/-! Data supplied to the signed optimizer by the actual singleton-seeded stream. -/
namespace SubmodularMatching.AppendixM
open Capacity Finset Streaming NonmonotoneOptimizer UpperBoundAssembly
open scoped BigOperators
attribute [local irreducible] rescaledRateTable
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Nonempty E] [Fintype V] [DecidableEq V]

theorem sparse_index_origin (ends : E → V × V) (b : V → ℕ)
    (hpos : ∀ e, 0 < b (ends e).1 ∧ 0 < b (ends e).2) (R : GridUpdateParameters)
    (idx : ℕ → E × ℕ) (k : ℕ) (z : E × ℕ)
    (hz : z ∈ (sparseRun ends b hpos R idx k).machine.edges) :
    ∃ i < k, idx i = z := by
  induction k with
  | zero => cases hz
  | succ k ih =>
    dsimp only [sparseRun,sparseStep,OnlineInstance.step] at hz
    split_ifs at hz with ha
    · rw [List.mem_append] at hz
      rcases hz with h | h
      · obtain ⟨i,hi,he⟩ := ih h
        exact ⟨i,by omega,he⟩
      · exact ⟨k,by omega,by simpa using (List.mem_singleton.mp h).symm⟩
    · obtain ⟨i,hi,he⟩ := ih hz
      exact ⟨i,by omega,he⟩

theorem stored_index_correct (ends : E → V × V) (b : V → ℕ)
    (hpos : ∀ e, 0 < b (ends e).1 ∧ 0 < b (ends e).2) (R : GridUpdateParameters)
    (edge : ℕ → E) (idx : ℕ → ℕ) (k : ℕ)
    (hinj : ∀ i<k, ∀ j<k, edge i=edge j → i=j) (z : E × ℕ)
    (hz : z ∈ (sparseRun ends b hpos R (fun i => (edge i,idx i)) k).machine.edges) :
    frozenIndex edge idx k z.1 = z.2 := by
  obtain ⟨i,hi,he⟩ := sparse_index_origin ends b hpos R (fun i => (edge i,idx i)) k z hz
  obtain ⟨e,w⟩ := z
  have h₁ := congrArg Prod.fst he
  have h₂ := congrArg Prod.snd he
  have h : ∃ j<k, edge j = e := ⟨i,hi,h₁⟩
  rw [frozenIndex,dif_pos h,hinj _ h.choose_spec.1 i hi (h.choose_spec.2.trans h₁.symm)]
  exact h₂

structure RetainedPassData (C : PotentialConfig) (ends : E → V × V) (b : V → ℕ)
    (pair : E → BSlot b × BSlot b) (v k : ℕ) (edge : ℕ → E) (idx : ℕ → ℕ)
    (f : Finset E → ℝ) (M : Finset E) (τ : ℝ) (L : List (E×ℕ)) : Prop where
  ordered : L.map Prod.fst = acceptedOrder C pair (fun i => (edge i,(streamTolerance:ℝ)*τ/(v:ℝ)^2*idx i)) k
  nodup : (L.map Prod.fst).Nodup
  index : ∀ z ∈ L, frozenIndex edge idx k z.1 = z.2
  weights : ∀ i<k, (streamTolerance:ℝ)*τ/(v:ℝ)^2*idx i ≤ τ
  base : f ∅ ≤ τ
  singleton : ∀ e ∈ L.map Prod.fst, f {e} ≤ τ
  pass : CapacityPassWitness C ends b pair (fun i => (edge i,(streamTolerance:ℝ)*τ/(v:ℝ)^2*idx i)) k
    (L.map Prod.fst).toFinset M f streamTolerance
  mean_base : ∀ fallback, historyMean (fun i => (L.map Prod.fst).getD i fallback) (fun _ => C.p)
      L.length f ∅ ≤ f ∅ + traceRecordedValue C pair (fun i => (edge i,(streamTolerance:ℝ)*τ/(v:ℝ)^2*idx i)) k +
      3*(streamTolerance:ℝ)*τ

  conservative : ∀ fallback (i : ℕ), i < L.length →
    let input := fun j => (edge j,(streamTolerance:ℝ)*τ/(v:ℝ)^2*idx j)
    let ordered := fun j => (L.map Prod.fst).getD j fallback
    0 ≤ frozenInput input k (ordered i) ∧
      frozenInput input k (ordered i) ≤ arrivalWeight ordered C.p f i
  recorded : let input := fun i => (edge i,(streamTolerance:ℝ)*τ/(v:ℝ)^2*idx i)
    C.p*(L.map Prod.fst).toFinset.sum (frozenInput input k) = traceRecordedValue C pair input k

theorem verified_retained_pass_data_ordered (S : SimpleEdgeStream E V) (b : V → ℕ)
    (hpos : ∀ e, 0 < b (S.ends e).1 ∧ 0 < b (S.ends e).2)
    (τ : ℝ) (ht : 0 < τ) {N : ℕ} (hN : 0 < N)
    (edges : ℕ → E) (samples : ℕ → Fin N → ℝ) (f : Finset E → ℝ) (k j : ℕ) (M : Finset E)
    (hk : k ≤ (Fintype.card V)^2) (hf : IsSubmodular f) (hn : ∀ A, 0 ≤ f A)
    (hinj : ∀ i < k, ∀ l < k, edges i = edges l → i=l)
    (hM : Capacity.feasible S.ends b M) (hMsub : M ⊆ (range k).image edges) :
    let v := (Fintype.card V)^2
    let C := signedConfig v (capacityScheduleVertices S) τ ht
    let width := (v:ℝ)/(streamTolerance:ℝ)
    let q := seededScale (f ∅) (fun i => f {edges i})
    let birth := signedBirth width (f ∅) (fun i => f {edges i}) j k
    let edge := fun i => edges (birth+i)
    let idx := fun i => sourceWeightIndex N (sourceIndex C.gap (samples i))
    let st := sparseRun S.ends b hpos (wordGrid v) (fun i => (edge i,idx i)) (k-birth)
    ∃ (left : (e : E) → Fin (b (S.ends e).1)) (right : (e : E) → Fin (b (S.ends e).2)),
      let pair := slotPair S.ends b left right
      let input := sampledInput C.gap edge samples
      (∀ i ≤ k-birth, (sparseRun S.ends b hpos (wordGrid v) (fun j => (edge j,idx j)) i).machine.edges.map Prod.fst =
        acceptedOrder C pair input i) ∧
      (∀ entry ∈ st.assigned, entry.2 = pair entry.1) ∧
      (guessActive width (guessAnchor width q (k+1)) (singletonMaximum q (k+1)) j →
       τ = guessAnchor width q (k+1)*2^j →
       (∀ i<k-birth, ∀ r, ∃ A, samples i r = marginal f (edge i) A) →
       (∀ i<k-birth, traceWeight C pair input f i-C.gap ≤ sourceAverage C.gap (samples i) ∧
         sourceAverage C.gap (samples i) ≤ traceWeight C pair input f i+C.gap) →
       RetainedPassData C S.ends b pair v (k-birth) edge idx f M τ st.machine.edges) := by
  intro v C width q birth edge idx st
  obtain ⟨left,right,horder,hpair,pass⟩ := capacity_physical_pass_verified_ordered S b hpos τ ht hN
    edges samples f k j M hk hf hn hinj hM hMsub
  refine ⟨left,right,horder,hpair,?_⟩
  intro active hτ sample good
  let pair := slotPair S.ends b left right
  let input := sampledInput C.gap edge samples
  have hg : C.gap = (streamTolerance:ℝ)*τ/(v:ℝ)^2 := rfl
  have rewrite_input : input = fun i => (edge i,(streamTolerance:ℝ)*τ/(v:ℝ)^2*idx i) := by
    funext i
    simp only [input,sampledInput,sourceWeight_eq_index,hg,idx]
  have ordr : st.machine.edges.map Prod.fst = acceptedOrder C pair input (k-birth) := horder _ le_rfl
  have inj : ∀ i<k-birth, ∀ a<k-birth, edge i=edge a → i=a := by
    intro i hi a ha h
    have eq := hinj (birth+i) (by omega) (birth+a) (by omega) h
    omega
  have sing (i : ℕ) (hi : i<k-birth) : f {edge i} ≤ τ := by
    rw [hτ]
    exact (singleton_le_maximum q (i:=birth+i+1) (k:=k+1) (by omega)).trans active.2.1
  have hv : 2 ≤ v := capacityScheduleVertices S
  have hv' : (0:ℝ)<v := by exact_mod_cast (show 0<v by omega)
  have hd : 0 < C.gap := by rw [hg]; positivity [show (0:ℝ)<streamTolerance by norm_num [streamTolerance]]
  have hp : C.p ≤ 1 := by change (sourceProbability:ℝ) ≤ 1; norm_num [sourceProbability]
  have weighted (i : ℕ) (hi : i<k-birth) : sourceWeight C.gap (samples i) ≤ τ := by
    apply (sourceWeight_signed_bounds C.gap τ (samples i) hd hN ht.le ?_).2
    intro r
    obtain ⟨A,hA⟩ := sample i hi r
    rw [hA]
    by_cases he : edge i ∈ A
    · simp [marginal,union_eq_left.mpr (singleton_subset_iff.mpr he),ht.le]
    · have hx := diminishing_returns f hf ∅ A (edge i) (empty_subset _) he
      simp only [empty_union] at hx
      unfold marginal
      linarith only [hx,hn ∅,sing i hi]
  have hwitness : CapacityPassWitness C S.ends b pair input (k-birth)
      (st.machine.edges.map Prod.fst).toFinset M f streamTolerance := pass active hτ sample good
  refine ⟨ordr.trans (by rw [rewrite_input]),?_,stored_index_correct S.ends b hpos _ edge idx _ inj,?_,?_,?_,rewrite_input ▸ hwitness,?_,?_,?_⟩
  · rw [ordr]; exact acceptedOrder_nodup C pair input _ inj
  · intro i hi
    simpa only [sourceWeight_eq_index,hg,idx] using weighted i hi
  · rw [hτ]
    exact (singleton_le_maximum q (i:=0) (k:=k+1) (by omega)).trans active.2.1
  · intro e he
    obtain ⟨i,hi,heq⟩ := (sparseRun_records S.ends b hpos (wordGrid v) (fun i => (edge i,idx i)) (k-birth)).2.2 e he
    change edge i=e at heq
    exact heq ▸ sing i hi
  · intro fallback
    have ha (i : ℕ) (hi : i<k-birth) := sourceWeight_signed_accuracy C.gap
      (traceWeight C pair input f i) (samples i) hd (good i hi).1 (good i hi).2
    have he := (signed_trace_base_error C pair input f (k-birth) hp (fun i hi => (ha i hi).2.1)
      (fun i hi hacc => (ha i hi).2.2 (C.theta_pos.trans_le hacc.1))).2
    have ha' := expectation_acceptedOrder C pair input fallback (k-birth) f
    have hh : (st.machine.edges.map Prod.fst).length = st.machine.edges.length := by simp
    have hv2 : (k-birth:ℕ) ≤ v^2 := (Nat.sub_le _ _).trans (hk.trans (by change v ≤ v^2; nlinarith))
    have err : 3*C.p*C.gap*(k-birth:ℕ) ≤ 3*(streamTolerance:ℝ)*τ := by
      have ss := mul_le_mul_of_nonneg_left (show ((k-birth:ℕ):ℝ) ≤ (v:ℝ)^2 by exact_mod_cast hv2)
        (show 0 ≤ 3*C.p*C.gap by positivity [C.p_pos])
      have eq : 3*C.p*C.gap*(v:ℝ)^2 = 3*C.p*((streamTolerance:ℝ)*τ) := by rw [hg]; field_simp
      have pos : 0 ≤ (streamTolerance:ℝ)*τ := mul_nonneg (by norm_num [streamTolerance]) ht.le
      have hpp := mul_le_mul_of_nonneg_right hp pos
      exact ss.trans (eq.le.trans (by linarith only [hpp]))
    rw [←rewrite_input,←hh,ordr]
    simp only [historyMean,empty_union,←ha']
    linarith only [he,err]

  · intro fallback a ha
    rw [← rewrite_input,ordr]
    have hlen : a < (acceptedOrder C pair input (k-birth)).length := by
      rw [←ordr,List.length_map]; exact ha
    obtain ⟨i,hi,hacc,hpos⟩ := accepted_at_compact_index C pair input (k-birth) a hlen
    subst a
    have ht' := traceWeight_eq_final_arrivalWeight C pair input fallback f i (k-birth) hi hacc
    dsimp only at ht' ⊢
    rw [ht'.1,← ht'.2.2,← frozenInput_spec input (k-birth) inj i hi]
    have h := sourceWeight_signed_accuracy C.gap (traceWeight C pair input f i) (samples i)
      hd (good i hi).1 (good i hi).2
    exact ⟨h.1,h.2.2 (C.theta_pos.trans_le hacc.1)⟩
  · rw [←rewrite_input,ordr,acceptedOrder_toFinset]
    exact frozenInput_gain C pair input (k-birth) inj


theorem verified_retained_pass_data (S : SimpleEdgeStream E V) (b : V → ℕ)
    (hpos : ∀ e, 0 < b (S.ends e).1 ∧ 0 < b (S.ends e).2)
    (τ : ℝ) (ht : 0 < τ) {N : ℕ} (hN : 0 < N)
    (edges : ℕ → E) (samples : ℕ → Fin N → ℝ) (f : Finset E → ℝ) (k j : ℕ) (M : Finset E)
    (hk : k ≤ (Fintype.card V)^2) (hf : IsSubmodular f) (hn : ∀ A, 0 ≤ f A)
    (hinj : ∀ i < k, ∀ l < k, edges i = edges l → i=l)
    (hM : Capacity.feasible S.ends b M) (hMsub : M ⊆ (range k).image edges) :
    let v := (Fintype.card V)^2
    let C := signedConfig v (capacityScheduleVertices S) τ ht
    let width := (v:ℝ)/(streamTolerance:ℝ)
    let q := seededScale (f ∅) (fun i => f {edges i})
    let birth := signedBirth width (f ∅) (fun i => f {edges i}) j k
    let edge := fun i => edges (birth+i)
    let idx := fun i => sourceWeightIndex N (sourceIndex C.gap (samples i))
    let st := sparseRun S.ends b hpos (wordGrid v) (fun i => (edge i,idx i)) (k-birth)
    ∃ (left : (e : E) → Fin (b (S.ends e).1)) (right : (e : E) → Fin (b (S.ends e).2)),
      let pair := slotPair S.ends b left right
      let input := sampledInput C.gap edge samples
      (∀ entry ∈ st.assigned, entry.2 = pair entry.1) ∧
      (guessActive width (guessAnchor width q (k+1)) (singletonMaximum q (k+1)) j →
       τ = guessAnchor width q (k+1)*2^j →
       (∀ i<k-birth, ∀ r, ∃ A, samples i r = marginal f (edge i) A) →
       (∀ i<k-birth, traceWeight C pair input f i-C.gap ≤ sourceAverage C.gap (samples i) ∧
         sourceAverage C.gap (samples i) ≤ traceWeight C pair input f i+C.gap) →
       RetainedPassData C S.ends b pair v (k-birth) edge idx f M τ st.machine.edges) := by
  obtain ⟨left,right,_,ha,hh⟩ := verified_retained_pass_data_ordered S b hpos τ ht hN edges samples f k j M hk hf hn hinj hM hMsub
  exact ⟨left,right,ha,hh⟩

end
end SubmodularMatching.AppendixM
