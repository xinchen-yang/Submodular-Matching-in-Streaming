import SubmodularMatching.NonmonotonePhysicalScales
import SubmodularMatching.NonmonotoneParameters
import Mathlib.Data.Nat.Log

/-! Polynomial grid widths and trial sample counts using the current guess scale. -/
namespace SubmodularMatching.AppendixM
open Shearer
noncomputable section

def trialScale (slots labels vertices : ℕ) : ℕ := 4294967296*(slots+labels+vertices+2)
def oracleReads (K : ℕ) : ℕ := 512*K^9
def oracleWidth (K : ℕ) : ℕ := Nat.clog 2 (1024*K^4)
def oracleTolerance (K : ℕ) (τ : ℝ) := τ/(4*(K:ℝ)^2)
def layerTolerance (K : ℕ) : ℝ := 1/(4*(K:ℝ)^2)
def layerTapeLength (K : ℕ) : ℕ := Nat.clog 2 (K^2)
def layerSampleCap (labels K : ℕ) : ℕ := 2*labels+4*Nat.clog 2 K+4
def trialGibbsDivisor (K : ℕ) : ℕ := K^2
def assignedGrid (K : ℕ) : ℕ := 16*K^2
def pairScanGrid (K : ℕ) : ℕ := 16*K^3
def layerGrid (K : ℕ) : ℕ := 4*K^3
def trialTimeGrid (K : ℕ) : ℕ := 62500000000000000000000*(K^5+1)
def firstBins (K : ℕ) : ℕ := 15609923359958673284671*(K^5+1)
def secondBins (K : ℕ) : ℕ := 4702576640041326715329*(K^5+1)

theorem trialScale_bounds (slots labels vertices : ℕ) :
    let K := trialScale slots labels vertices
    2000000000≤K ∧ slots≤K ∧ 2*(labels+1)≤K ∧ vertices≤K := by
  dsimp [trialScale]; omega

theorem trial_time_widths (K : ℕ) :
    K^5≤trialTimeGrid K ∧ 0<trialTimeGrid K ∧ 0<firstBins K ∧ 0<secondBins K ∧
    (firstBins K:ℝ)/trialTimeGrid K=layerOne ∧ (secondBins K:ℝ)/trialTimeGrid K=layerTwo := by
  have h := physical_time_grid K
  exact ⟨h.1,h.2.2⟩

theorem trial_grid_widths (K slots vertices : ℕ) (hk : 1≤K) (hs : slots≤K) (hv : vertices≤K)
    (p : ℝ) (hp : 0≤p) (hp1 : p≤1) :
    3*p*(2*((vertices:ℝ)/pairScanGrid K))+2/assignedGrid K ≤ 1/(K:ℝ)^2 ∧
    (slots:ℝ)/layerGrid K + layerTolerance K + layerTolerance K ≤ 1/(K:ℝ)^2 ∧
    ((2:ℝ)^layerTapeLength K)⁻¹ ≤ 1/(K:ℝ)^2 := by
  have hh := physical_grid_precisions K p vertices slots (pairScanGrid K) (assignedGrid K) (layerGrid K)
    (by exact_mod_cast hk) (by exact_mod_cast hv) (by exact_mod_cast hs) hp hp1
    (by simp [pairScanGrid]) (by simp [assignedGrid]) (by simp [layerGrid])
  refine ⟨hh.1,hh.2,?_⟩
  have hpow : (K:ℝ)^2 ≤ (2:ℝ)^layerTapeLength K := by exact_mod_cast Nat.le_pow_clog (by decide : 1<2) (K^2)
  rw [← one_div]
  have hk0 : (0:ℝ)<K := by exact_mod_cast hk
  exact one_div_le_one_div_of_le (by positivity) hpow

theorem trial_cap (labels K : ℕ) (hk : 0<K) (mass : ℝ) (hm : mass≤labels) :
    mass+Real.log (1/layerTolerance K) ≤ (layerSampleCap labels K:ℝ)*Real.log 2 := by
  have hk' : 0<(K:ℝ) := by exact_mod_cast hk
  have h₂ : (1:ℝ)/2≤Real.log 2 := by
    have h := Real.one_sub_inv_le_log_of_pos (by norm_num : (0:ℝ)<2)
    norm_num at h
    exact h
  have hl : Real.log (K:ℝ) ≤ (Nat.clog 2 K:ℝ)*Real.log 2 := by
    rw [←Real.log_pow]
    exact Real.log_le_log hk' (by exact_mod_cast Nat.le_pow_clog (by decide : 1<2) K)
  have he : Real.log (1/layerTolerance K) = 2*Real.log 2+2*Real.log K := by
    unfold layerTolerance
    rw [one_div_one_div,show (4:ℝ)=2^2 by norm_num,Real.log_mul (by positivity) (by positivity),Real.log_pow,Real.log_pow]
    norm_num
  rw [he]
  simp only [layerSampleCap,Nat.cast_add,Nat.cast_mul,Nat.cast_ofNat]
  nlinarith only [hm,hl,mul_le_mul_of_nonneg_left h₂ (Nat.cast_nonneg labels),
    mul_nonneg (Nat.cast_nonneg (Nat.clog 2 K)) (le_trans (by norm_num) h₂),h₂]

/-- The relative accuracy of the noisy signed score oracle uses only τ as its
value scale. Its concrete polynomial sample count leaves a full unit of slack. -/
theorem trial_score_precision (K slots labels : ℕ) (hk : 2000000000≤K) (hs : slots≤K)
    (hl : labels≤K) (τ opt H : ℝ) (ht : 0<τ) (htopt : τ≤2*opt)
    (hH : 0<H) (hHt : H≤(K:ℝ)*τ) (hHo : H≤(K:ℝ)*opt) :
    let ε := oracleTolerance K τ
    0<ε ∧ 0<oracleReads K ∧ ε≤opt/(K:ℝ)^2 ∧
    labels*(1/(2:ℝ)^oracleWidth K)*(H-(-H))≤ε/64 ∧
    (2*slots)*(2*Real.exp (-(2*oracleReads K*(ε/2)^2)/(H-(-H))^2))*H ≤ implementationUnit*opt := by
  intro ε
  have hk0 : 0<(K:ℝ) := by exact_mod_cast (show 0<K by omega)
  have hk' : (2000000000:ℝ)≤K := by exact_mod_cast hk
  have he : 0<ε := by dsimp [ε,oracleTolerance]; positivity
  have ho : 0≤opt := by linarith only [ht,htopt]
  have hs' : (slots:ℝ)≤K := by exact_mod_cast hs
  have hl' : (labels:ℝ)≤K := by exact_mod_cast hl
  have hre : (oracleReads K:ℝ)=512*(K:ℝ)^9 := by simp [oracleReads]
  have hw : 1024*(K:ℝ)^4≤(2:ℝ)^oracleWidth K := by exact_mod_cast Nat.le_pow_clog (by decide : 1<2) (1024*K^4)
  refine ⟨he,by dsimp [oracleReads]; positivity,?_,?_,?_⟩
  · unfold ε oracleTolerance
    rw [div_le_div_iff₀ (by positivity) (by positivity)]
    nlinarith only [mul_le_mul_of_nonneg_right htopt (sq_nonneg (K:ℝ)),
      mul_nonneg ho (sq_nonneg (K:ℝ))]
  · dsimp only [ε,oracleTolerance]
    have hterm : (labels:ℝ)*(1/(2:ℝ)^oracleWidth K)*(H-(-H)) ≤
        (K:ℝ)*(1/(1024*(K:ℝ)^4))*((K:ℝ)*τ*2) := by
      apply mul_le_mul _ (by linarith only [hHt]) (by linarith only [hH]) (by positivity)
      exact mul_le_mul hl' (one_div_le_one_div_of_le (by positivity) hw) (by positivity) hk0.le
    apply hterm.trans
    field_simp
    nlinarith only [mul_nonneg ht.le (sq_nonneg (K:ℝ))]
  · let u := (2*(oracleReads K:ℝ)*(ε/2)^2)/(H-(-H))^2
    have hbound : 4*(K:ℝ)^3 ≤ u := by
      apply (le_div_iff₀ (sq_pos_of_pos (by linarith only [hH]))).2
      have hwidth : (H-(-H))^2 ≤ (2*(K:ℝ)*τ)^2 :=
        pow_le_pow_left₀ (by linarith only [hH]) (by linarith only [hHt]) 2
      apply (mul_le_mul_of_nonneg_left hwidth (by positivity : 0≤4*(K:ℝ)^3)).trans
      dsimp only [ε,oracleTolerance]
      rw [hre]
      field_simp <;> ring_nf <;> first | rfl | positivity | nlinarith only [sq_nonneg τ,pow_nonneg hk0.le 7]
    have hpow : 4*(K:ℝ)^3 ≤ Real.exp u := hbound.trans ((le_add_of_nonneg_right zero_le_one).trans (Real.add_one_le_exp u))
    have hrate : Real.exp (-u) ≤ 1/(4*(K:ℝ)^3) := by
      rw [Real.exp_neg,←one_div]
      exact one_div_le_one_div_of_le (by positivity) hpow
    have hunit : 1/(K:ℝ) ≤ implementationUnit := by
      rw [div_le_iff₀ hk0]
      norm_num [implementationUnit]
      linarith only [hk']
    rw [neg_div]
    change 2*(slots:ℝ)*(2*Real.exp (-u))*H ≤ _
    calc
      _ ≤ (2*(K:ℝ))*(2*(1/(4*(K:ℝ)^3)))*((K:ℝ)*opt) := by gcongr
      _ = (1/(K:ℝ))*opt := by field_simp <;> ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hunit ho

end
end SubmodularMatching.AppendixM
