import SubmodularMatching.SourceTrace

/-! Regroup segment slack to obtain the exact coordinate-eliminated LP dual. -/

namespace SubmodularMatching.SourceCertificate

open scoped BigOperators

noncomputable section

theorem weighted_fiber_sum {E : Type*} [Fintype E] [DecidableEq E]
    (edge : ℕ → E) (duration : ℕ → ℝ) (value : E → ℝ) (n : ℕ) :
    (Finset.range n).sum (fun j => duration j * value (edge j)) =
      ∑ e, ((Finset.range n).sum (fun j => if edge j = e then duration j else 0)) * value e := by
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  simp [ite_mul]

theorem scale_positive_part (w a : ℝ) (hw : 0 < w) :
    w * max (1 - a / w) 0 = max (w - a) 0 := by
  rw [mul_max_of_nonneg _ _ hw.le, mul_zero, mul_sub, mul_one, mul_div_cancel₀ _ hw.ne']

/-- The dual objective after eliminating coordinate-bound dual variables. -/
def sourceDual {V E : Type*} [Fintype V] [Fintype E]
    (I : V → Bool) (D p : ℝ) (ends : E → V × V) (weight : E → ℝ) (price : V → ℝ) : ℝ :=
  (∑ v, vertexCapacity D (I v) * price v) +
    p * ∑ e, edgeCapacity D (I (ends e).1) (I (ends e).2) *
      max (weight e - price (ends e).1 - price (ends e).2) 0

/-- Splitting an edge's update into arbitrary affine pieces does not change
its total coordinate-slack payment. -/
theorem segment_slack_grouping {V E : Type*} [Fintype E] [DecidableEq E]
    (I : V → Bool) (D p : ℝ) (ends : E → V × V) (weight : E → ℝ)
    (hweight : ∀ e, 0 < weight e) (price : V → ℝ)
    (steps : ℕ → UpdateSegment V) (edge : ℕ → E) (n : ℕ)
    (hhigh : ∀ j < n, (steps j).high = (ends (edge j)).1)
    (hlow : ∀ j < n, (steps j).low = (ends (edge j)).2)
    (hweights : ∀ j < n, (steps j).weight = weight (edge j))
    (hdurations : ∀ e,
      (Finset.range n).sum (fun j => if edge j = e then (steps j).duration else 0) =
        p * weight e) :
    (Finset.range n).sum (fun j => (steps j).duration *
      edgeCapacity D (I (steps j).high) (I (steps j).low) *
        max (1 - (price (steps j).high + price (steps j).low) / (steps j).weight) 0) =
      p * ∑ e, edgeCapacity D (I (ends e).1) (I (ends e).2) *
        max (weight e - price (ends e).1 - price (ends e).2) 0 := by
  calc
    _ = (Finset.range n).sum (fun j => (steps j).duration *
      (edgeCapacity D (I (ends (edge j)).1) (I (ends (edge j)).2) *
        max (1 - (price (ends (edge j)).1 + price (ends (edge j)).2) / weight (edge j)) 0)) := by
      apply Finset.sum_congr rfl
      intro j hj
      rw [hhigh j (Finset.mem_range.mp hj), hlow j (Finset.mem_range.mp hj),
        hweights j (Finset.mem_range.mp hj), mul_assoc]
    _ = ∑ e, (p * weight e) *
      (edgeCapacity D (I (ends e).1) (I (ends e).2) *
        max (1 - (price (ends e).1 + price (ends e).2) / weight e) 0) := by
      rw [weighted_fiber_sum edge (fun j => (steps j).duration)
        (fun e => edgeCapacity D (I (ends e).1) (I (ends e).2) *
          max (1 - (price (ends e).1 + price (ends e).2) / weight e) 0) n]
      simp only [hdurations]
    _ = _ := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro e _
      have h := scale_positive_part (weight e) (price (ends e).1 + price (ends e).2)
        (hweight e)
      have hm := congrArg (fun z => p * edgeCapacity D (I (ends e).1) (I (ends e).2) * z) h
      simp only [sub_sub]
      convert hm using 1 <;> ring

end

end SubmodularMatching.SourceCertificate
