import SubmodularMatching.FiniteShearerAcceptance

/-!
# Accumulated error of finite Shearer decisions

Each edge has two possible outcomes, retaining the current matching or
inserting it. A sequence of such decisions stays in the fixed state set.
The total variation errors add uniformly over all conditional states.
-/

namespace SubmodularMatching.ShearerSampler

open GibbsMatching Shearer GibbsSampler
open scoped BigOperators

variable {S : Type*} [DecidableEq S]

noncomputable def binaryRow (old new : S) (a : ℝ) (outcome : S) : ℝ :=
  (if old = outcome then 1-a else 0) + (if new = outcome then a else 0)

theorem binaryRow_probability (states : Finset S) (s t : S) (a : ℝ)
    (hs : s ∈ states) (ht : t ∈ states) (ha : 0 ≤ a ∧ a ≤ 1) :
    IsProbability states (binaryRow s t a) := by
  constructor
  · intro u _
    unfold binaryRow
    split_ifs <;> linarith only [ha.1,ha.2]
  · simp [binaryRow, Finset.sum_add_distrib, hs, ht]

theorem binaryRow_variation_le (states : Finset S) (s t : S) (a b : ℝ)
    (hs : s ∈ states) (ht : t ∈ states) :
    variation states (binaryRow s t a) (binaryRow s t b) ≤ |a-b| := by
  unfold variation
  apply (div_le_iff₀ (by norm_num : (0:ℝ) < 2)).2
  have hrow (u : S) :
      |binaryRow s t a u - binaryRow s t b u| ≤
        (if s = u then |a-b| else 0) + (if t = u then |a-b| else 0) := by
    by_cases he : s = u <;> by_cases hte : t = u
    · simp only [binaryRow, if_pos he, if_pos hte]
      simp [add_nonneg (abs_nonneg (a-b)) (abs_nonneg (a-b))]
    · simp only [binaryRow, if_pos he, if_neg hte, add_zero]
      rw [show 1 - a - (1 - b) = -(a-b) by ring, abs_neg]
    · simp [binaryRow, he, hte]
    · simp [binaryRow, he, hte]
  calc
    _ ≤ ∑ u ∈ states, ((if s = u then |a-b| else 0) + (if t = u then |a-b| else 0)) :=
      Finset.sum_le_sum fun u _ => hrow u
    _ = _ := by
      simp [Finset.sum_add_distrib, hs, ht]
      ring

/-- Start from `initial` and apply the kernels in reverse list order, so
the head represents the final step, as in the paper's prefix recursion. -/
noncomputable def applySchedule (states : Finset S) (initial : S → ℝ) :
    List (S → S → ℝ) → S → ℝ
  | [] => initial
  | step :: previous => applyKernel states step (applySchedule states initial previous)

omit [DecidableEq S] in
theorem applySchedule_probability (states : Finset S) (initial : S → ℝ)
    (hinit : IsProbability states initial) (steps : List (S → S → ℝ))
    (hsteps : ∀ k ∈ steps, IsKernel states k) :
    IsProbability states (applySchedule states initial steps) := by
  induction steps with
  | nil => exact hinit
  | cons k steps ih =>
    exact applyKernel_probability states _ k (ih fun l hl => hsteps l (List.mem_cons_of_mem _ hl))
      (hsteps k (List.mem_cons_self ..))

omit [DecidableEq S] in
theorem variation_applySchedule (states : Finset S) (initial : S → ℝ)
    (hinit : IsProbability states initial) (steps : List ((S → S → ℝ) × (S → S → ℝ)))
    (δ : ℝ) (hsteps : ∀ k ∈ steps, IsKernel states k.1 ∧ IsKernel states k.2 ∧
      ∀ s ∈ states, variation states (k.1 s) (k.2 s) ≤ δ) :
    variation states (applySchedule states initial (steps.map Prod.fst))
      (applySchedule states initial (steps.map Prod.snd)) ≤ steps.length * δ := by
  induction steps with
  | nil => simp [applySchedule, variation]
  | cons pair steps ih =>
    have htail : ∀ k ∈ steps, IsKernel states k.1 ∧ IsKernel states k.2 ∧
        ∀ s ∈ states, variation states (k.1 s) (k.2 s) ≤ δ :=
      fun k hk => hsteps k (List.mem_cons_of_mem _ hk)
    have hh := hsteps pair (List.mem_cons_self ..)
    let p := applySchedule states initial (steps.map Prod.fst)
    let q := applySchedule states initial (steps.map Prod.snd)
    have hq : IsProbability states q := by
      apply applySchedule_probability states initial hinit (steps.map Prod.snd)
      intro k hk
      obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hk
      exact (htail j hj).2.1
    have htri := variation_triangle states (applyKernel states pair.1 p)
      (applyKernel states pair.1 q) (applyKernel states pair.2 q)
    have hcont := variation_contract states p q pair.1 hh.1
    have herr := variation_row_error states q pair.1 pair.2 hq δ hh.2.2
    have hi := ih htail
    change variation states (applyKernel states pair.1 p) (applyKernel states pair.2 q)
      ≤ (↑(steps.length+1) : ℝ)*δ
    push_cast
    linarith only [htri,hcont,herr,hi]

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- A transition on the common finite state set of all matchings. If the
accepted edge cannot be added, both branches retain the existing matching. -/
noncomputable def matchingRow (ends : E → Finset V) (edges : Finset E)
    (e : E) (accept : Finset E → ℝ) (A : Finset E) : Finset E → ℝ := by
  classical
  let B := if insert e A ∈ matchings ends edges then insert e A else A
  exact binaryRow A B (accept A)

theorem matchingRow_isKernel (ends : E → Finset V) (edges : Finset E)
    (e : E) (accept : Finset E → ℝ)
    (ha : ∀ A ∈ matchings ends edges, 0 ≤ accept A ∧ accept A ≤ 1) :
    IsKernel (matchings ends edges) (matchingRow ends edges e accept) := by
  classical
  constructor
  intro A hA
  unfold matchingRow
  apply binaryRow_probability _ _ _ _ hA _ (ha A hA)
  dsimp only
  split_ifs with hb
  · exact hb
  · exact hA

theorem matchingRow_variation (ends : E → Finset V) (edges : Finset E)
    (e : E) (a b : Finset E → ℝ) (A : Finset E) (hA : A ∈ matchings ends edges) :
    variation (matchings ends edges) (matchingRow ends edges e a A) (matchingRow ends edges e b A)
      ≤ |a A - b A| := by
  classical
  unfold matchingRow
  apply binaryRow_variation_le _ _ _ _ _ hA
  dsimp only
  split_ifs with hb
  · exact hb
  · exact hA

theorem boundedMatchingRow_refinement (ends : E → Finset V) (edges P : Finset E)
    (x : E → ℝ) (r : ℝ) (hr : 1/2 ≤ r) (hr1 : r < 1)
    (hx : ∀ e ∈ edges, 0 ≤ x e) (hends : ∀ e ∈ edges, (ends e).card = 2)
    (hdegree : ∀ v, (∑ e ∈ incident ends edges v, x e) ≤ r*(1-r))
    (L : ℕ) (e : E) (he : e ∈ edges) (u v : V) (huv : ends e = {u,v}) (hP : P ⊆ edges) :
    IsKernel (matchings ends edges) (matchingRow ends edges e (fun A => prefixAcceptance ends P A x e)) ∧
    IsKernel (matchings ends edges) (matchingRow ends edges e
      (fun A => boundedAcceptance ends edges P A x r (2*L) e u v hP)) ∧
    ∀ A ∈ matchings ends edges,
      variation (matchings ends edges) (matchingRow ends edges e (fun A => prefixAcceptance ends P A x e) A)
        (matchingRow ends edges e (fun A => boundedAcceptance ends edges P A x r (2*L) e u v hP) A)
      ≤ 2*(4*r*(1-r))^L := by
  have h (A : Finset E) := boundedAcceptance_error ends edges P A x r hr hr1 hx hends hdegree L e he u v huv hP
  refine ⟨matchingRow_isKernel ends edges e _ (fun A _ => ⟨(h A).1.trans (h A).2.1, (h A).2.2.1⟩),
    matchingRow_isKernel ends edges e _ (fun A _ => ⟨(h A).1, (h A).2.1.trans (h A).2.2.1⟩), ?_⟩
  intro A hA
  apply (matchingRow_variation ends edges e _ _ A hA).trans
  rw [abs_of_nonneg (sub_nonneg.mpr (h A).2.1)]
  exact (h A).2.2.2

end SubmodularMatching.ShearerSampler
