import SubmodularMatching.NonmonotoneSparsePacking
import SubmodularMatching.NonmonotoneSlotGraph

open scoped BigOperators

namespace SubmodularMatching.TwoLayerDiffuse

open GibbsMatching VarianceBound TwoStage
noncomputable section

variable {V I : Type*} [Fintype V] [DecidableEq V] [Fintype I] [DecidableEq I]

def slotLoad (b : V → ℕ) (Y : V → V → ℝ) (u : V) : ℝ := (∑ v, Y u v) / b u

theorem expanded_slot_degree (b : V → ℕ) (hb : ∀ v, 0 < b v) (rank : Slots b ↪ ℕ)
    (Y : V → V → ℝ) (symm : ∀ u v, Y u v = Y v u) (diag : ∀ v, Y v v = 0)
    (θ : ℝ) (i : Slots b) :
    Shearer.vertexDegree pairVertices (orderedPairs rank) (fun z => slotWeight b Y θ z.1 z.2) i =
      θ * slotLoad b Y i.1 := by
  have h := neighborActivity_row_sum pairVertices (orderedPairs rank) (fun z => slotWeight b Y θ z.1 z.2)
    (orderedPairs_card_two rank) i
  have hs (u v : Slots b) : slotWeight b Y θ u v = slotWeight b Y θ v u := by
    simp only [slotWeight,symm u.1 v.1,mul_comm (b u.1 : ℝ)]
  have hd (u : Slots b) : slotWeight b Y θ u u = 0 := by simp [slotWeight,diag]
  simp_rw [ordered_neighbor_matrix rank (slotWeight b Y θ) hs hd] at h
  rw [slot_degree_scan b hb Y θ i] at h
  rw [← show _ = Shearer.vertexDegree _ _ _ i from h]
  dsimp [slotLoad]
  ring

def expandedLayer (b : V → ℕ) (hb : ∀ v, 0 < b v) (rank : Slots b ↪ ℕ)
    (Y : V → V → ℝ) (symm : ∀ u v, Y u v = Y v u) (diag : ∀ v, Y v v = 0)
    (hn : ∀ u v, 0 ≤ Y u v) (θ d : ℝ) (hθ : 0 ≤ θ) (hθd : θ*d ≤ 1/4)
    (hload : ∀ v, slotLoad b Y v ≤ d) : Layer pairVertices (orderedPairs rank) where
  y z := slotWeight b Y θ z.1 z.2
  nonneg z _ := by unfold slotWeight; exact div_nonneg (mul_nonneg hθ (hn _ _)) (by positivity)
  small i := (expanded_slot_degree b hb rank Y symm diag θ i).trans_le
    ((mul_le_mul_of_nonneg_left (hload i.1) hθ).trans hθd)

/-- M.4's assigned-copy alteration with concrete full Shearer layers. The
nonlinear vector is stored by original vertex pair and x only by assigned
copy; the sampler reserves the actual slots of the independent draws. -/
theorem assigned_slot_alteration (b : V → ℕ) (hb : ∀ v, 0 < b v) (rank : Slots b ↪ ℕ)
    (Y : V → V → ℝ) (symm : ∀ u v, Y u v = Y v u) (diag : ∀ v, Y v v = 0)
    (hn : ∀ u v, 0 ≤ Y u v)
    (ends : I → Slots b × Slots b) (loopless : ∀ e, (ends e).1 ≠ (ends e).2)
    (simple : Function.Injective (pairEnds ends)) (x : I → ℝ) (hx : ∀ e, 0 ≤ x e)
    (d p ξ θ₁ θ₂ tv te : ℝ) (hd : 0 ≤ d) (hd' : d ≤ 1/3) (hξ : 0 < ξ) (hp : 0 < p)
    (hpc : p ≤ coordinateCap ξ) (hθ₁ : 0 ≤ θ₁) (hθ₂ : 0 ≤ θ₂) (hsum : θ₁+θ₂=1)
    (ht₁ : θ₁*d ≤ 1/4) (ht₂ : θ₂*d ≤ 1/4) (hload : ∀ u, slotLoad b Y u ≤ d)
    (hv : ∀ i : Slots b, Joint.degree ends x i + (1-2*θ₁*θ₂*tv)*slotLoad b Y i.1
      ≤ 1 - θ₁*θ₂*tv^2)
    (hedge : ∀ e, x e / p + (1-2*θ₁*θ₂*te)*(slotLoad b Y (ends e).1.1 + slotLoad b Y (ends e).2.1)
      ≤ 1 - θ₁*θ₂*te^2) :
    let A := expandedLayer b hb rank Y symm diag hn θ₁ d hθ₁ ht₁ hload
    let B := expandedLayer b hb rank Y symm diag hn θ₂ d hθ₂ ht₂ hload
    let z := alteredSparse pairVertices (orderedPairs rank) ends A B x ξ
    (∀ ω e, 0 ≤ z ω e ∧ z ω e ≤ p) ∧ (∀ ω i, Joint.degree ends (z ω) i ≤ 1) ∧
    (∀ ω e, z ω e ≠ 0 → vacant pairVertices (orderedPairs rank) (ends e).1 ω = 1 ∧
      vacant pairVertices (orderedPairs rank) (ends e).2 ω = 1) ∧
    ∀ e, (1-ξ)*x e ≤ finiteMean (joint A B) (fun ω => z ω e) := by
  intro A B z
  let ℓ := fun i : Slots b => slotLoad b Y i.1
  have hA (i) : A.deg i = θ₁*ℓ i := expanded_slot_degree b hb rank Y symm diag θ₁ i
  have hB (i) : B.deg i = θ₂*ℓ i := expanded_slot_degree b hb rank Y symm diag θ₂ i
  exact packed_sparse_alteration pairVertices (orderedPairs rank) (orderedPairs_card_two rank)
    ends loopless simple A B x hx d p ξ θ₁ θ₂ tv te hd hd' hξ hp hpc hθ₁ hθ₂ hsum ℓ
    (fun i => hload i.1) hA hB hv hedge

end
end SubmodularMatching.TwoLayerDiffuse
