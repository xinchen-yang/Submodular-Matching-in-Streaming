import SubmodularMatching.NonmonotoneWordBudget
import SubmodularMatching.CapacityPhysicalPass

/-! Actual signed marginal words in the compact streaming state. -/
namespace SubmodularMatching.Streaming
open MeasureTheory
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def storedMarginalQuery (L : List E) (e : E) (f : Finset E → ℝ) (p : ℚ)
    (hp : 0 ≤ p ∧ p ≤ 1) : OracleQuery E where
  edges i := L.getD i e
  size := L.length
  prob _ := p
  unitProb _ _ := by exact_mod_cast hp
  evaluate := marginal f e

theorem storedMarginalQuery_target (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (f : Finset E → ℝ) (p : ℚ) (h : 0 ≤ p ∧ p ≤ 1)
    (hp : (p:ℝ)=C.p) (i : ℕ) :
    (storedMarginalQuery (acceptedOrder C ends input i) (input i).1 f p h).target =
      traceWeight C ends input f i := by
  rw [traceWeight_acceptedOrder C ends input (input i).1 f i]
  unfold OracleQuery.target storedMarginalQuery
  simp only [hp]

private theorem constant_selector (edges : ℕ → E) (draw : ℕ → ℕ) (threshold : ℕ)
    (t : ℕ → ℕ) (n : ℕ) (heq : ∀ i < n, t i = threshold) :
    selectThresholdWords edges draw t n = selectDyadic edges draw threshold n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [selectThresholdWords,selectDyadic,heq n (Nat.lt_succ_self n)]
    rw [ih (fun i hi => heq i (hi.trans (Nat.lt_succ_self n)))]

theorem storedMarginalQuery_word (L : List E) (e : E) (oracle : Finset E → ℚ) (p : ℚ)
    (hp : 0 ≤ p ∧ p ≤ 1) (bits : ℕ) (w : Fin L.length → Fin (2^bits)) :
    (storedMarginalQuery L e (fun A => (oracle A:ℝ)) p hp).wordValue bits w =
      wordRawMarginal oracle (fun i => L.getD i e) e L.length bits p w := by
  rw [wordRawMarginal_eq]
  unfold OracleQuery.wordValue selectWordVector
  apply congrArg (marginal (fun A => (oracle A:ℝ)) e)
  apply constant_selector
  intro i hi
  simp only [OracleQuery.extendedProb,storedMarginalQuery] at *
  simp [hi,rational_threshold_exact]

theorem storedMarginalQuery_range (L : List E) (e : E) (f : Finset E → ℝ) (p : ℚ)
    (hp : 0 ≤ p ∧ p ≤ 1) (tau : ℝ) (ht : 0 ≤ tau) (hf : IsSubmodular f)
    (hn : ∀ A, 0 ≤ f A) (h0 : f ∅ ≤ tau) (he : f {e} ≤ tau) (hs : ∀ a ∈ L, f {a} ≤ tau) :
    let Q := storedMarginalQuery L e f p hp
    ∀ A ⊆ (Finset.range Q.size).image Q.edges,
      -((L.length:ℝ)+1)*tau ≤ Q.evaluate A ∧ Q.evaluate A ≤ tau := by
  intro Q A hA
  have hcard : (A.card:ℝ) ≤ L.length := by
    exact_mod_cast (Finset.card_le_card hA).trans (Finset.card_image_le.trans
      (Finset.card_range _).le)
  have hr := signed_sample_range f hf hn A e tau ht h0 (fun a ha => by
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp (hA ha)
    apply hs
    have hi' : i<L.length := Finset.mem_range.mp hi
    change L.getD i e ∈ L
    simpa [List.getD,hi'] using (List.getElem_mem hi' : L[i] ∈ L)) he
  change -((L.length:ℝ)+1)*tau ≤ marginal f e A ∧ marginal f e A ≤ tau
  exact ⟨by nlinarith only [hr.1,mul_le_mul_of_nonneg_right hcard ht],hr.2⟩

end
end SubmodularMatching.Streaming
