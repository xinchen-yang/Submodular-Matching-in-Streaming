import SubmodularMatching.StreamingK1RealProgram
import SubmodularMatching.StreamingOnlineLegality

/-! # Oracle legality of the sparse real-oracle source transition -/

namespace SubmodularMatching.Streaming.RealSource

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- All the archived edges have already appeared. -/
def OnlineStreamState.ArchivesArrived (st : OnlineStreamState E V) (arrived : Finset E) : Prop :=
  ∀ row ∈ st.instances, (row.2.edges.map Prod.fst).toFinset ⊆ arrived

omit [DecidableEq V] in
theorem OnlineStreamState.initialize_edges_subset (st : OnlineStreamState E V)
    (arrived : Finset E) (hs : st.ArchivesArrived arrived) (reset : Bool) (j : ℕ) :
    ((st.initialize reset j).edges.map Prod.fst).toFinset ⊆ arrived := by
  unfold OnlineStreamState.initialize
  split
  · simp [OnlineInstance.empty]
  · cases he : st.instanceAt j with
    | none => simp [OnlineInstance.empty]
    | some s =>
      exact hs (j, s) (lookupInstance_some_mem st.instances j s he)

theorem OnlineStreamState.step_archivesArrived (st : OnlineStreamState E V)
    (R : GridUpdateParameters) (ends : E → V × V) (W : ℝ) (span : ℕ) (edge : E)
    (singleton : ℝ) (estimate : ℕ → ℝ → OnlineInstance E V → ℕ)
    (arrived : Finset E) (hs : st.ArchivesArrived arrived) :
    (st.step R ends W span edge singleton estimate).ArchivesArrived (insert edge arrived) := by
  intro row hrow
  obtain ⟨j, -, rfl⟩ := List.mem_map.1 hrow
  apply OnlineInstance.step_edges_subset
  · exact (st.initialize_edges_subset arrived hs _ _).trans (Finset.subset_insert _ _)
  · exact Finset.mem_insert_self _ _

theorem runOnlineStream_archivesArrived (R : GridUpdateParameters) (ends : E → V × V)
    (W epsilon : ℝ) (span vertices : ℕ) (oracle : Finset E → ℝ) (threshold count : ℕ)
    (edges : ℕ → E) (coins : ℕ → ℕ → ℕ → ℕ → ℕ) (n : ℕ) :
    (runOnlineStream R ends W epsilon span vertices oracle threshold count edges coins n).ArchivesArrived
      ((Finset.range n).image edges) := by
  induction n with
  | zero => simp [runOnlineStream, OnlineStreamState.empty, OnlineStreamState.ArchivesArrived]
  | succ n ih =>
    rw [runOnlineStream, OnlineStreamState.process, Finset.range_add_one, Finset.image_insert]
    exact OnlineStreamState.step_archivesArrived _ _ _ _ _ _ _ _ _ ih

/-- The stream's singleton query and both calls in every sampled marginal
only contain arrived edges. This holds for any word callback and for any
active guess, including on a failed accuracy event. -/
theorem runOnlineStream_queries_legal (R : GridUpdateParameters) (ends : E → V × V)
    (W epsilon : ℝ) (span vertices : ℕ) (oracle : Finset E → ℝ) (threshold count : ℕ)
    (edges : ℕ → E) (coins : ℕ → ℕ → ℕ → ℕ → ℕ) (n j sample : ℕ) :
    let old := runOnlineStream R ends W epsilon span vertices oracle threshold count edges coins n
    let st := old.initialize (old.epoch.resets W (oracle {edges n})) j
    let hist := selectDyadic (fun i => (st.edges.getD i (edges n, 0)).1)
      (coins n j sample) threshold st.edges.length
    let arrived := (Finset.range (n + 1)).image edges
    {edges n} ⊆ arrived ∧ hist ⊆ arrived ∧ insert (edges n) hist ⊆ arrived := by
  dsimp only
  let old := runOnlineStream R ends W epsilon span vertices oracle threshold count edges coins n
  let st := old.initialize (old.epoch.resets W (oracle {edges n})) j
  let arrived := (Finset.range (n + 1)).image edges
  have he : edges n ∈ arrived := Finset.mem_image_of_mem edges (Finset.mem_range.2 (Nat.lt_succ_self n))
  have hstored := old.initialize_edges_subset _ (runOnlineStream_archivesArrived R ends W epsilon
    span vertices oracle threshold count edges coins n) (old.epoch.resets W (oracle {edges n})) j
  have hsub : (Finset.range n).image edges ⊆ arrived :=
    Finset.image_subset_image (Finset.range_mono (Nat.le_succ n))
  exact ⟨Finset.singleton_subset_iff.2 he,
    st.batch_queries_legal (edges n) (coins n j sample) threshold arrived (hstored.trans hsub) he⟩

end

end SubmodularMatching.Streaming.RealSource
