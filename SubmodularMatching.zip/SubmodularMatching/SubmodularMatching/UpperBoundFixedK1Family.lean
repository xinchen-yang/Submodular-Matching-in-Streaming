import SubmodularMatching.UpperBoundFixedK1Parameters
import SubmodularMatching.UpperBoundK1FactorSpecialization

/-! # Corollary L.1 on the physical archive program -/

namespace SubmodularMatching.UpperBoundAssembly

open SourceCertificate NumericalCertificate GibbsSampler

noncomputable section

namespace FamilyParameters

variable {slack : ℝ} (a : FamilyParameters slack)

private theorem twice_K_large : 8 < 2 * a.K := by
  have hK : (0 : ℝ) < a.K := by exact_mod_cast a.K_pos
  have h : (1 : ℝ) / a.K < 1 / 4 := a.error_small
  have h' : (4 : ℝ) < a.K := by
    have hmul := (div_lt_iff₀ hK).1 h
    linarith only [hmul]
  have hK' : 4 < a.K := by exact_mod_cast h'
  omega

private theorem rationalFamilyError_eq : ((1 / (a.K : ℚ) : ℚ) : ℝ) = a.error := by
  push_cast
  rfl

/-- Compile the fixed family choice into the general rational archive program. -/
def archivedParameters
    (middle : AppendixBoxGoal false false ⟨648, 54863, 0, 1135, 0, 1135⟩) : K1Parameters := by
  have hK : (0 : ℚ) < a.K := by exact_mod_cast a.K_pos
  have he : (1 : ℚ) / a.K < 1 := by
    have h := a.error_lt_one
    rw [← a.rationalFamilyError_eq] at h
    exact_mod_cast h
  refine appendixK1Parameters middle (2 * a.K) a.twice_K_large (1 / (a.K : ℚ)) a.p
    (one_div_pos.mpr hK) he a.p_pos a.p_source ?_
  rw [a.rationalFamilyError_eq]
  exact a.p_round

theorem archivedParameters_error
    (middle : AppendixBoxGoal false false ⟨648, 54863, 0, 1135, 0, 1135⟩) :
    (a.archivedParameters middle).error = a.error := by
  change (2 : ℝ) / ((2 * a.K : ℕ) : ℝ) = 1 / (a.K : ℝ)
  push_cast
  rw [div_mul_eq_div_div]
  norm_num

theorem archivedParameters_theta
    (middle : AppendixBoxGoal false false ⟨648, 54863, 0, 1135, 0, 1135⟩) :
    (a.archivedParameters middle).theta = 1 - a.error := by
  change 1 - ((1 / (a.K : ℚ) : ℚ) : ℝ) = 1 - a.error
  rw [a.rationalFamilyError_eq]

theorem archivedParameters_eta
    (middle : AppendixBoxGoal false false ⟨648, 54863, 0, 1135, 0, 1135⟩) :
    (a.archivedParameters middle).eta = sigma := by
  change min sigma ((110505663541 / 500000000000 : ℚ) : ℝ) = sigma
  exact min_eq_left (by simpa only [Rat.cast_div, Rat.cast_ofNat, beta] using beta_bounds.1.le)

theorem archivedParameters_expectedFactor
    (middle : AppendixBoxGoal false false ⟨648, 54863, 0, 1135, 0, 1135⟩) :
    (a.archivedParameters middle).expectedFactor = familyExpectedFactor a.error := by
  simp only [K1Parameters.expectedFactor, K1Parameters.trialFactor, k1TrialFactor,
    a.archivedParameters_error middle, a.archivedParameters_theta middle, a.archivedParameters_eta middle,
    familyExpectedFactor]
  rw [← div_mul_eq_div_div]
  congr 1
  ring

/-- Use the arbitrary-target confidence proof for the same family choice. -/
def archivedConfidence
    (middle : AppendixBoxGoal false false ⟨648, 54863, 0, 1135, 0, 1135⟩)
    (hslack : 0 < slack) : K1Confidence (a.archivedParameters middle) := by
  refine ⟨a.target, (a.archivedParameters middle).trialFactor_le_expectedFactor.trans_lt ?_⟩
  rw [a.archivedParameters_expectedFactor middle]
  exact a.factor_margin.trans (a.intermediate_lt_target hslack)

end FamilyParameters

namespace SimpleEdgeStream

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- The physical streaming archive achieves the entire limiting family
once the remaining numerical source certificate is supplied. -/
theorem approximationFamily_archived_of_next_band (S : SimpleEdgeStream E V) {slack : ℝ}
    (a : FamilyParameters slack) (hslack : 0 < slack)
    (middle : AppendixBoxGoal false false ⟨648, 54863, 0, 1135, 0, 1135⟩)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (δ : ℝ) (hδ : 0 < δ) :
    let b := a.archivedParameters middle
    let C := a.archivedConfidence middle hslack
    let p := S.k1ArchivedExpectedOutput b f hf hmono
    let q := S.k1ArchivedAmplifiedOutput b f hf hmono C δ
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / a.target ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / a.target ≤ f M then 0 else 1) ≤ δ := by
  intro b C p q
  have hR : b.expectedFactor < C.target := by
    change b.expectedFactor < a.target
    rw [show b.expectedFactor = familyExpectedFactor a.error from a.archivedParameters_expectedFactor middle]
    exact a.factor_margin.trans (a.intermediate_lt_target hslack)
  exact S.k1Archived_guarantees_of_expectedFactor_le b C hR.le f hf hmono h0 O hO hopt δ hδ

end SimpleEdgeStream

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- One fixed collection of parameters and confidence grid works for every
input stream at each factor strictly above the limiting constant. -/
theorem approximationFamily_archived_corollary_of_next_band (ratio : ℝ)
    (hr : (45246551 : ℝ) / 10000000 < ratio)
    (middle : AppendixBoxGoal false false ⟨648, 54863, 0, 1135, 0, 1135⟩) :
    ∃ b : K1Parameters, ∃ C : K1Confidence b, C.target = ratio ∧ b.expectedFactor < ratio ∧
      ∀ (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
        (hf : IsSubmodular f) (hmono : IsMonotone f) (_h0 : 0 ≤ f ∅)
        (O : Finset E) (_hO : O ∈ S.matchings)
        (_hopt : ∀ M ∈ S.matchings, f M ≤ f O) (δ : ℝ) (_hδ : 0 < δ),
        let p := S.k1ArchivedExpectedOutput b f hf hmono
        let q := S.k1ArchivedAmplifiedOutput b f hf hmono C δ
        p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
          f O / ratio ≤ expected p.outcomes p.mass f ∧
          expected q.outcomes q.mass (fun M => if f O / ratio ≤ f M then 0 else 1) ≤ δ := by
  let slack := ratio - 45246551 / 10000000
  have hs : 0 < slack := sub_pos.mpr hr
  obtain ⟨a⟩ := FamilyParameters.exists_parameters slack hs
  have hR : a.target = ratio := by
    rw [SimpleEdgeStream.familyTarget_exact]
    dsimp [slack]
    ring
  refine ⟨a.archivedParameters middle, a.archivedConfidence middle hs, hR, ?_, ?_⟩
  · rw [← hR, a.archivedParameters_expectedFactor middle]
    exact a.factor_margin.trans (a.intermediate_lt_target hs)
  · intro S f hf hmono h0 O hO hopt δ hδ
    simpa only [hR] using S.approximationFamily_archived_of_next_band a hs middle f hf hmono h0 O hO hopt δ hδ

end

end SubmodularMatching.UpperBoundAssembly
