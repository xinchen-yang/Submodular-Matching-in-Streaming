import SubmodularMatching.StreamingOnlineSchedulerStorage

/-! # Record counts for the executable sparse state -/

namespace SubmodularMatching.Streaming

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

omit [DecidableEq E] in
theorem runOnlineIndexed_keys (R : GridUpdateParameters) (ends : E → V × V) (W : ℚ)
    (span : ℕ) (value : ℕ → ℚ) (edges : ℕ → E) (indices : ℕ → ℕ → ℕ) (k : ℕ) :
    (runOnlineIndexed R ends W span value edges indices k).instances.map Prod.fst =
      (runOnlineEpoch W span value k).active W span := by
  cases k with
  | zero => simp [runOnlineIndexed, runOnlineEpoch, OnlineStreamState.empty,
      OnlineEpoch.empty, OnlineEpoch.active]
  | succ k =>
    simp only [runOnlineIndexed, OnlineStreamState.step, List.map_map, Function.comp_def, List.map_id',
      runOnlineEpoch, runOnlineIndexed_epoch]

omit [DecidableEq E] in
theorem runOnlineIndexed_lookup_mem (R : GridUpdateParameters) (ends : E → V × V) (W : ℚ)
    (span : ℕ) (value : ℕ → ℚ) (edges : ℕ → E) (indices : ℕ → ℕ → ℕ) (k j : ℕ)
    (st : OnlineInstance E V)
    (h : (j, st) ∈ (runOnlineIndexed R ends W span value edges indices k).instances) :
    (runOnlineIndexed R ends W span value edges indices k).instanceAt j = some st := by
  cases k with
  | zero => simp [runOnlineIndexed, OnlineStreamState.empty] at h
  | succ k =>
    let old := runOnlineIndexed R ends W span value edges indices k
    let epoch := old.epoch.step W span (value k)
    let update := fun i =>
      (old.initialize (old.epoch.resets W (value k)) i).step R ends (edges k) (indices k i)
    change (j, st) ∈ (epoch.active W span).map (fun i => (i, update i)) at h
    obtain ⟨i, hi, hrow⟩ := List.mem_map.1 h
    obtain ⟨h1, h2⟩ := Prod.mk.inj hrow
    subst i
    rw [runOnlineIndexed, OnlineStreamState.step_instanceAt]
    change (if j ∈ epoch.active W span then some (update j) else none) = _
    rw [if_pos hi, h2]

omit [DecidableEq E] [DecidableEq V] in
theorem OnlineEpoch.active_nodup (st : OnlineEpoch) (W : ℚ) (span : ℕ) :
    (st.active W span).Nodup := by
  unfold OnlineEpoch.active
  split
  · exact (List.nodup_range.map (fun _ _ h => Nat.add_left_cancel h)).filter _
  · exact List.nodup_nil

private theorem list_sum_of_distinct_keys (l : List ℕ) (h : l.Nodup) (g : ℕ → ℕ) :
    (l.map g).sum = ∑ i ∈ l.toFinset, g i := by
  induction l with
  | nil => simp
  | cons a l ih =>
    have ha : a ∉ l.toFinset := fun hm => (List.nodup_cons.1 h).1 (List.mem_toFinset.1 hm)
    rw [List.map_cons, List.sum_cons, List.toFinset_cons, Finset.sum_insert ha,
      ih (List.nodup_cons.1 h).2]

/-- Legal raw tapes assign either a genuine sampled marginal or zero to
any history cell. A missing cell has the value of the marginal on the
edge singleton, so the same range argument covers it as well. -/
theorem ScheduledSource.history_marginal_support (P : ScheduledSource E V) {N : ℕ}
    (oracle : Finset E → ℚ) (p : ℚ) (hobj : P.objective = fun A => (oracle A : ℝ))
    (batches : ℕ → Fin N → ℝ)
    (h : ∀ t < P.calls.length, P.HasWordBatch oracle p batches t)
    (t : ℕ) (ht : t ≤ P.calls.length) (a j : ℕ) (r : Fin N) :
    ∃ S, P.history batches t (a, j) r = marginal P.objective (P.edges a) S := by
  induction t with
  | zero => exact ⟨{P.edges a}, by simp [ScheduledSource.history, marginal]⟩
  | succ t ih =>
    rw [ScheduledSource.history, ScheduledSource.advance]
    by_cases hk : (a, j) = P.call t
    · rw [hk, Function.update_self]
      let ctx := P.context t (P.history batches t)
      obtain ⟨draw, he⟩ := h t (Nat.lt_of_succ_le ht)
      rw [he]
      simp only [EstimateContext.wordObserve, wordRawMarginal_eq, ← hobj, P.context_edge, ← hk]
      exact ⟨_, rfl⟩
    · rw [Function.update_of_ne hk]
      exact ih (Nat.le_of_succ_le ht)


/-- Only the frozen edge rows and endpoint dictionary rows count here;
the scalar state and the at most `span + 1` guess headers are separate. -/
def OnlineStreamState.archiveRows (st : OnlineStreamState E V) : ℕ :=
  (st.instances.map fun row => row.2.edges.length + row.2.vertices.length).sum

/-- At every prefix, the actual sparse row count is at most three times
the exact reference edge-record count. No accuracy event is needed. -/
theorem ScheduledSource.online_snapshot_archiveRows_le
    (P : ScheduledSource E V) (R : GridUpdateParameters) (W : ℚ)
    (oracle : Finset E → ℚ) (hobj : P.objective = fun A => (oracle A : ℝ))
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ P.span) (hwidth : (W : ℝ) = P.width)
    (hR : ∀ tau > 0, R.Matches (P.config tau))
    {N : ℕ} (batches : ℕ → Fin N → ℝ) (k : ℕ) (hk : k ≤ P.arrivals)
    (hunique : ∀ i < k, ∀ j < k, P.edges i = P.edges j → i = j) :
    let old := runOnlineIndexed R P.ends W P.span (fun i => oracle {P.edges i}) P.edges
      (P.tapeIndex batches) k
    old.archiveRows ≤ 3 * ∑ j ∈ activeGuessIndices P.width (guessAnchor P.width P.value k)
      (singletonMaximum P.value k) P.span,
      (P.snapshot (P.history batches P.calls.length) k j).stored.card := by
  intro old
  let value := fun i => oracle {P.edges i}
  let keyList := old.instances.map Prod.fst
  let keySet := activeGuessIndices P.width (guessAnchor P.width P.value k)
    (singletonMaximum P.value k) P.span
  let card := fun j => (P.snapshot (P.history batches P.calls.length) k j).stored.card
  have hv : (fun i => (value i : ℝ)) = P.value := by
    funext i
    change (oracle {P.edges i} : ℝ) = P.objective {P.edges i}
    rw [hobj]
  have hkeys : keyList = (runOnlineEpoch W P.span value k).active W P.span :=
    runOnlineIndexed_keys _ _ _ _ _ _ _ _
  have hd : keyList.Nodup := by rw [hkeys]; exact OnlineEpoch.active_nodup _ _ _
  have hactive (j : ℕ) : j ∈ keyList ↔ guessActive P.width (guessAnchor P.width P.value k)
      (singletonMaximum P.value k) j := by
    rw [hkeys, runOnlineEpoch_active_iff W P.span value hW hspan k j, hwidth, hv]
  have hkeySet : keyList.toFinset = keySet := by
    ext j
    rw [List.mem_toFinset, hactive]
    by_cases hp : 0 < singletonMaximum P.value k
    · exact (mem_activeGuessIndices P.width _ _ _ j (guessAnchor_pos _ _ _ hp)
        (guessAnchor_le _ _ _) P.width_bound).symm
    · have hz := (le_of_not_gt hp).antisymm (singletonMaximum_nonneg P.value k)
      unfold keySet guessActive
      simp only [hz, lt_self_iff_false, false_and, activeGuessIndices_eq_empty_of_zero,
        Finset.notMem_empty]
  have hrow : ∀ row ∈ old.instances,
      row.2.edges.length + row.2.vertices.length ≤ 3 * card row.1 := by
    rintro ⟨j, st⟩ hr
    have hlook : old.instanceAt j = some st := runOnlineIndexed_lookup_mem _ _ _ _ _ _ _ _ _ _ hr
    have hj : j ∈ keyList := List.mem_map.2 ⟨(j, st), hr, rfl⟩
    obtain ⟨other, ho, prep, horder, hsize⟩ :=
      P.online_snapshot_represents R W oracle hobj hW hspan hwidth hR batches k j hk ((hactive j).1 hj)
    have he : st = other := Option.some.inj (hlook.symm.trans ho)
    subst other
    have hdup : (st.edges.map Prod.fst).Nodup := by
      rw [horder]
      apply acceptedOrder_nodup
      intro i hi j' hj' h
      have hhit := hunique _ (by omega) _ (by omega) h
      omega
    have hc : st.edges.length = card j := by
      have hs : (st.edges.map Prod.fst).toFinset =
          (P.snapshot (P.history batches P.calls.length) k j).stored := prep.stored
      unfold card
      rw [← hs, List.toFinset_card_of_nodup hdup, List.length_map]
    change st.edges.length + st.vertices.length ≤ 3 * card j
    omega
  unfold OnlineStreamState.archiveRows
  calc
    _ ≤ (old.instances.map fun row => 3 * card row.1).sum := List.sum_le_sum hrow
    _ = (keyList.map fun j => 3 * card j).sum := by simp only [keyList, List.map_map, Function.comp_def]
    _ = _ := by rw [list_sum_of_distinct_keys _ hd, hkeySet, Finset.mul_sum]

/-- Deterministic archive-space bound for every actual compact-word tape. -/
theorem ScheduledSource.online_snapshot_archiveRows_bound
    (P : ScheduledSource E V) (R : GridUpdateParameters) (W p : ℚ)
    (oracle : Finset E → ℚ) (hobj : P.objective = fun A => (oracle A : ℝ))
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ P.span) (hwidth : (W : ℝ) = P.width)
    (hR : ∀ tau > 0, R.Matches (P.config tau))
    {N : ℕ} (batches : ℕ → Fin N → ℝ) (k : ℕ) (hk : k ≤ P.arrivals) (hN : 0 < N)
    (hraw : ∀ t < P.calls.length, P.HasWordBatch oracle p batches t)
    (hunique : ∀ i < k, ∀ j < k, P.edges i = P.edges j → i = j)
    (bound : ℕ) (allEdges M : Finset E)
    (hin : ∀ i < k, P.edges i ∈ allEdges)
    (hloop : ∀ e ∈ allEdges, (P.ends e).1 ≠ (P.ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet P.ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet P.ends) A → A.card ≤ M.card)
    (hbound : ∀ tau > 0, (P.config tau).incidenceLimit ≤ bound) :
    let old := runOnlineIndexed R P.ends W P.span (fun i => oracle {P.edges i}) P.edges
      (P.tapeIndex batches) k
    old.archiveRows ≤ 3 * (2 * M.card * bound * (P.span + 1)) := by
  dsimp only
  have h1 := P.online_snapshot_archiveRows_le R W oracle hobj hW hspan hwidth hR batches k hk hunique
  have h2 := P.snapshot_edges_card_le (P.history batches P.calls.length) k hN bound allEdges M hin hloop
    hMsub hM hmax hbound (fun a _ j r => P.history_marginal_support oracle p hobj batches hraw _ le_rfl a j r)
  exact h1.trans (Nat.mul_le_mul_left _ h2)

end

end SubmodularMatching.Streaming
