import SubmodularMatching.TwoStageZeroExtension

/-!
# GJ1--GJ4 for distinct first-stage and stored supports

The explicit alteration only uses the first support for unmatched-pair
probabilities and only the stored support for the load scans. The two
supports may overlap.
-/

namespace SubmodularMatching.TwoStage

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- GJ1 with independently specified supports for its two coordinates. -/
structure SeparateFeasible (ends : E → V × V) (A S : Finset E) (x y : E → ℝ) (p D : ℝ) : Prop where
  x_nonneg : ∀ e ∈ S, 0 ≤ x e
  y_nonneg : ∀ e ∈ A, 0 ≤ y e
  y_degree : ∀ v, vertexLoad (pairEnds ends) A y v ≤ D
  shared_degree : ∀ v, vertexLoad (pairEnds ends) S x v + vertexLoad (pairEnds ends) A y v ≤ 1
  edge_bound : ∀ e ∈ S, x e ≤ p*(1-vertexLoad (pairEnds ends) A y (ends e).1-
    vertexLoad (pairEnds ends) A y (ends e).2)

noncomputable def separatePairProbability (ends : E → V × V) (A : Finset E)
    (y : E → ℝ) (u v : V) : ℝ :=
  Shearer.unmatchedPair (pairEnds ends) A y u v

/-- GJ2 on the actual first-stage edge set. -/
theorem separatePairProbability_triangle [Fintype V] (ends : E → V × V) (A : Finset E)
    (hloop : ∀ e ∈ A, (ends e).1 ≠ (ends e).2) (y : E → ℝ) (u v : V) (huv : u ≠ v) :
    separatePairProbability ends A y u v =
      (1 - vertexLoad (pairEnds ends) A y u) * (1 - vertexLoad (pairEnds ends) A y v) +
        neighborActivity (pairEnds ends) A y u v *
          (1 - vertexLoad (pairEnds ends) A y u - vertexLoad (pairEnds ends) A y v +
            neighborActivity (pairEnds ends) A y u v) -
        Shearer.triangleCorrection (pairEnds ends) A y u v :=
  Shearer.unmatched_pair_triangle (pairEnds ends) A y
    (fun e he => by rw [pairEnds,Finset.card_pair (hloop e he)]) u v huv

noncomputable def separateCompensatedEdge (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (e : E) : ℝ :=
  if e ∈ S then x e / separatePairProbability ends A y (ends e).1 (ends e).2 else 0

noncomputable def separateAlterationLoad [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (T : Finset E) (v : V) : ℝ :=
  ∑ e ∈ S, separateCompensatedEdge ends A S x y e *
    opposite ends (fun u M => unmatched (pairEnds ends) u M) v e T

/-- The actual GJ8 vector. Loads are scanned over the stored edges. -/
noncomputable def separateAltered [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (ε : ℝ) (T : Finset E) (e : E) : ℝ := by
  classical
  exact if e ∈ S ∧ unmatched (pairEnds ends) (ends e).1 T = 1 ∧
    unmatched (pairEnds ends) (ends e).2 T = 1 ∧
    separateAlterationLoad ends A S x y T (ends e).1 ≤ 1+ε ∧
    separateAlterationLoad ends A S x y T (ends e).2 ≤ 1+ε then
      separateCompensatedEdge ends A S x y e / (1+ε)
  else 0

@[simp] theorem separateAltered_of_notMem [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (ε : ℝ) (T : Finset E) {e : E} (he : e ∉ S) :
    separateAltered ends A S x y ε T e = 0 := by
  simp [separateAltered,he]

theorem pairProbability_zeroOutside [Fintype E] (ends : E → V × V)
    (A : Finset E) (y : E → ℝ) (u v : V) :
    pairProbability ends (zeroOutside A y) u v = separatePairProbability ends A y u v := by
  unfold pairProbability separatePairProbability Shearer.unmatchedPair
  exact shearer_expectation_zeroOutside _ _ _ (Finset.subset_univ _) _ _

theorem separateCompensatedEdge_eq [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) :
    separateCompensatedEdge ends A S x y =
      compensatedEdge ends (zeroOutside S x) (zeroOutside A y) := by
  funext e
  unfold separateCompensatedEdge compensatedEdge
  rw [pairProbability_zeroOutside]
  by_cases he : e ∈ S <;> simp [he]

theorem separateAltered_eq [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (ε : ℝ) :
    separateAltered ends A S x y ε =
      shearerAltered ends (zeroOutside S x) (zeroOutside A y) ε := by
  classical
  let a := separateCompensatedEdge ends A S x y
  have hComp := separateCompensatedEdge_eq ends A S x y
  have hZero (d : E) (hd : d ∉ S) : separateCompensatedEdge ends A S x y d = 0 := by
    simp [separateCompensatedEdge,hd]
  have hLoad (T : Finset E) (v : V) : separateAlterationLoad ends A S x y T v =
      load ends a (fun u M => unmatched (pairEnds ends) u M) v T := by
    unfold separateAlterationLoad load
    exact Finset.sum_subset (Finset.subset_univ S) (fun d _ hd => by simp [hZero d hd])
  funext T e
  unfold shearerAltered altered
  rw [← hComp]
  by_cases he : e ∈ S
  · simp only [separateAltered,he,true_and,hLoad,a]
  · rw [separateAltered_of_notMem ends A S x y ε T he]
    split_ifs
    · rw [hZero e he,zero_div]
    · rfl

/-- A separate-support feasible point pads to a feasible common point. -/
theorem SeparateFeasible.zeroOutside [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (p D : ℝ) (hp : 0 ≤ p) (hD : 2*D ≤ 1)
    (h : SeparateFeasible ends A S x y p D) :
    Joint.Feasible p D ends ends (zeroOutside S x) (zeroOutside A y) := by
  constructor
  · intro e
    by_cases he : e ∈ S
    · simpa [he] using h.x_nonneg e he
    · simp [he]
  · intro e
    by_cases he : e ∈ A
    · simpa [he] using h.y_nonneg e he
    · simp [he]
  · intro v
    rw [jointDegree_zeroOutside]
    exact h.y_degree v
  · intro v
    rw [jointDegree_zeroOutside,jointDegree_zeroOutside]
    exact h.shared_degree v
  · intro e
    rw [jointDegree_zeroOutside,jointDegree_zeroOutside]
    by_cases he : e ∈ S
    · rw [zeroOutside_of_mem S x he]
      linarith only [h.edge_bound e he]
    · rw [zeroOutside_of_notMem S x he,zero_add]
      have hPair : vertexLoad (pairEnds ends) A y (ends e).1 +
          vertexLoad (pairEnds ends) A y (ends e).2 ≤ 1 := by
        linarith only [h.y_degree (ends e).1,h.y_degree (ends e).2,hD]
      simpa only [mul_one] using mul_le_mul_of_nonneg_left hPair hp

/-- GJ4 and the feasibility of GJ8 on the actual two edge sets. -/
theorem separate_alteration_correct [Fintype E] [Finite V]
    (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends)) (A S : Finset E)
    (x y : E → ℝ) (p D r ε : ℝ) (hp : 0 ≤ p) (hr0 : 0 < r) (hr1 : r ≤ 1)
    (hDr : D = r*(1-r)) (hgap : meanAllowance p D < ε)
    (h : SeparateFeasible ends A S x y p D) :
    (∀ T e, 0 ≤ separateAltered ends A S x y ε T e ∧ separateAltered ends A S x y ε T e ≤ p) ∧
    (∀ T v, vertexLoad (pairEnds ends) S (separateAltered ends A S x y ε T) v ≤ 1) ∧
    (∀ T e, separateAltered ends A S x y ε T e ≠ 0 →
      e ∈ S ∧ Disjoint (pairEnds ends e) (T.biUnion (pairEnds ends))) ∧
    ∀ e ∈ S, retentionCoefficient p D ε * x e ≤
      Shearer.expectation (pairEnds ends) A y (fun T => separateAltered ends A S x y ε T e) := by
  have hD : 2*D ≤ 1 := by rw [hDr]; nlinarith only [sq_nonneg (r-1/2)]
  have hFeas := h.zeroOutside ends A S x y p D hp hD
  have hPad := shearer_alteration_correct ends hloop hsimple p D r ε hp hr0 hr1 hDr hgap
    (zeroOutside S x) (zeroOutside A y) hFeas
  have hz := separateAltered_eq ends A S x y ε
  refine ⟨?_,?_,?_,?_⟩
  · rw [hz]
    exact hPad.1
  · intro T v
    have hKeep : zeroOutside S (separateAltered ends A S x y ε T) =
        separateAltered ends A S x y ε T := by
      funext e
      by_cases he : e ∈ S <;> simp [he]
    rw [← jointDegree_zeroOutside ends S _ v,hKeep,hz]
    exact hPad.2.1 T v
  · intro T e hn
    have he : e ∈ S := by
      by_contra ho
      exact hn (separateAltered_of_notMem ends A S x y ε T ho)
    refine ⟨he,?_⟩
    rw [hz] at hn
    exact altered_avoids_matching ends (fun M : Finset E => M)
      (compensatedEdge ends (zeroOutside S x) (zeroOutside A y)) ε T e hn
  · intro e he
    have hh := hPad.2.2.2 e
    rw [zeroOutside_of_mem S x he,← hz,shearer_expectation_zeroOutside _ _ _
      (Finset.subset_univ A)] at hh
    exact hh

end SubmodularMatching.TwoStage
