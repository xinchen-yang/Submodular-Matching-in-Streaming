import SubmodularMatching.GibbsSpectralLowActivity

/-!
# Vertex bound on the canonical route length

Each route changes an edge of the symmetric difference at most once.
Two matching cardinalities add to at most the number of vertices.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [LinearOrder E] [DecidableEq V] [Fintype V]

private theorem matching_card_twice_le (ends : E → Finset V) (edges M : Finset E)
    (hM : M ∈ matchings ends edges) (hEnds : ∀ e ∈ edges, (ends e).card = 2) :
    2*M.card ≤ Fintype.card V := by
  obtain ⟨hSub,hDis⟩ := (mem_matchings ..).mp hM
  have hPair : (M : Set E).PairwiseDisjoint ends := by
    intro a ha b hb hab
    exact hDis ha hb hab
  have h := Finset.card_le_univ (M.biUnion ends)
  rw [Finset.card_biUnion hPair] at h
  rw [Finset.sum_congr rfl (fun e he => hEnds e (hSub he)),Finset.sum_const,nsmul_eq_mul,Nat.mul_comm] at h
  exact h

omit [Fintype V] in
private theorem route_length_eq_diff (ends : E → Finset V) (edges I F : Finset E)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2)
    (hi : I ∈ matchings ends edges) (hf : F ∈ matchings ends edges) :
    (matchingRoute ends edges hEnds I F).card = (diffEdges I F).card := by
  classical
  have hEq : matchingRoute ends edges hEnds I F =
      (matchingRouteWitness ends edges I F hi hf hEnds).some.moves := dif_pos ⟨hi,hf⟩
  have hEmpty : diffEdges F F = ∅ := by ext e; simp
  rw [hEq]
  simpa only [hEmpty,Finset.card_empty,add_zero] using
    (matchingRouteWitness ends edges I F hi hf hEnds).some.length

theorem matchingRoute_card_le_vertices (ends : E → Finset V) (edges I F : Finset E)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2)
    (hi : I ∈ matchings ends edges) (hf : F ∈ matchings ends edges) :
    (matchingRoute ends edges hEnds I F).card ≤ Fintype.card V := by
  have hiCard := matching_card_twice_le ends edges I hi hEnds
  have hfCard := matching_card_twice_le ends edges F hf hEnds
  rw [route_length_eq_diff ends edges I F hEnds hi hf]
  calc
    (diffEdges I F).card ≤ (I ∪ F).card := by
      apply Finset.card_le_card
      intro e he
      exact Finset.mem_union.mpr ((mem_diffEdges.mp he).elim
        (fun h => Or.inl h.1) (fun h => Or.inr h.1))
    _ ≤ I.card + F.card := Finset.card_union_le _ _
    _ ≤ Fintype.card V := by omega

theorem lowActivityPaths_vertices (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (hAct : ∀ e ∈ edges, 0 ≤ activity e ∧ activity e ≤ 1)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) (m : ℕ) (hm : edges.card ≤ m) :
    HasSinclairPaths ends edges activity (Fintype.card V) (lowActivityC m) :=
  lowActivityPaths_hasSinclairPaths ends edges activity hAct hEnds (Fintype.card V) m
    (fun I hi F hf => matchingRoute_card_le_vertices ends edges I F hEnds hi hf) hm

end SubmodularMatching.GibbsSampler
