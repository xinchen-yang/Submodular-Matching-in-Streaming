import SubmodularMatching.NonmonotoneJointPass

/-! A discarded arrival is handled by a local endpoint test and takes no
space in the retained streams or the incumbent. -/
namespace SubmodularMatching.UpperBoundAssembly.CandidateLaw
open GibbsSampler
noncomputable section
variable {A E R : Type*}

def onArrivals (step : ℕ → A → E → CandidateLaw A) (i : ℕ) (s : A) :
    List E → CandidateLaw A
  | [] => pure s
  | e::es => by
    classical
    exact (step i s e).bind fun t => onArrivals step (i+1) t es

def onFilteredArrivals (keep : R → Option E) (step : ℕ → A → E → CandidateLaw A) (i : ℕ) (s : A) :
    List R → CandidateLaw A
  | [] => pure s
  | e::es => by
    classical
    exact match keep e with
    | none => onFilteredArrivals keep step i s es
    | some x => (step i s x).bind fun t => onFilteredArrivals keep step (i+1) t es

theorem onFilteredArrivals_eq (keep : R → Option E) (step : ℕ → A → E → CandidateLaw A)
    (i : ℕ) (s : A) (xs : List R) :
    onFilteredArrivals keep step i s xs = onArrivals step i s (xs.filterMap keep) := by
  induction xs generalizing i s with
  | nil => rfl
  | cons e es ih =>
    cases hk : keep e with
    | none => simpa [onFilteredArrivals,List.filterMap_cons,hk] using ih i s
    | some e' =>
      simp only [onFilteredArrivals,List.filterMap_cons,hk,onArrivals,ih]

theorem onArrivals_execute (step : ℕ → A → E → CandidateLaw A) (i : ℕ)
    (s : A) (xs : List E) (pad : E) (read : ℕ → E)
    (h : ∀ k < xs.length, read (i+k) = xs.getD k pad) :
    onArrivals step i s xs = execute (fun j a => step j a (read j)) xs.length i s := by
  classical
  induction xs generalizing i s with
  | nil => rfl
  | cons e es ih =>
    have h0 : read i=e := by have hh := h 0 (by simp); simpa using hh
    have htail (k : ℕ) (hk : k<es.length) : read (i+1+k) = es.getD k pad := by
      have hh := h (k+1) (by simpa)
      simpa [Nat.add_comm,Nat.add_left_comm,Nat.add_assoc] using hh
    change (step i s e).bind (fun t => onArrivals step (i+1) t es) =
      (step i s (read i)).bind (fun t => execute (fun j a => step j a (read j)) es.length (i+1) t)
    rw [h0]
    congr 1
    funext t
    exact ih (i+1) t htail

end
end SubmodularMatching.UpperBoundAssembly.CandidateLaw
