import SubmodularMatching.ShearerLaw
import SubmodularMatching.SamplingConcentration

/-!
# The Shearer law as an explicit finite sample space

The sample type contains precisely feasible matchings. The generic finite
expectation, variance and covariance definitions are identified with the
weighted sums used by the matching-law proofs.
-/

namespace SubmodularMatching.Shearer

open scoped BigOperators
open VarianceBound

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

abbrev Outcome (ends : E → Finset V) (S : Finset E) :=
  {M // M ∈ GibbsMatching.matchings ends S}

noncomputable def probability (ends : E → Finset V) (S : Finset E) (y : E → ℝ) :
    Outcome ends S → ℝ := fun M => mass ends S y M.val

theorem finiteMean_eq_expectation (ends : E → Finset V) (S : Finset E) (y : E → ℝ)
    (F : Finset E → ℝ) :
    finiteMean (probability ends S y) (fun M => F M.val) = expectation ends S y F := by
  unfold finiteMean probability expectation
  exact Finset.sum_coe_sort (GibbsMatching.matchings ends S) (fun M => mass ends S y M * F M)

theorem probability_total (ends : E → Finset V) (S : Finset E) (y : E → ℝ) :
    (∑ M, probability ends S y M) = 1 := by
  have h := finiteMean_eq_expectation ends S y (fun _ => 1)
  simpa only [finiteMean, mul_one, expectation_const] using h

theorem probability_nonnegative (ends : E → Finset V) (S : Finset E) (y : E → ℝ)
    (r : ℝ) (hr0 : 0 < r) (hr1 : r ≤ 1)
    (hy : ∀ e ∈ S, 0 ≤ y e) (hends : ∀ e ∈ S, (ends e).card = 2)
    (hdegree : ∀ v, (∑ e ∈ GibbsMatching.incident ends S v, y e) ≤ r * (1 - r))
    (M : Outcome ends S) : 0 ≤ probability ends S y M :=
  mass_nonnegative ends S y r hr0 hr1 hy hends hdegree M.val

theorem finiteVariance_eq_expectation (ends : E → Finset V) (S : Finset E) (y : E → ℝ)
    (F : Finset E → ℝ) :
    finiteVariance (probability ends S y) (fun M => F M.val) =
      expectation ends S y (fun M => (F M - expectation ends S y F) ^ 2) := by
  unfold finiteVariance
  rw [finiteMean_eq_expectation]
  exact finiteMean_eq_expectation ends S y (fun M => (F M - expectation ends S y F) ^ 2)

theorem finiteCovariance_eq_expectation (ends : E → Finset V) (S : Finset E) (y : E → ℝ)
    (F : V → Finset E → ℝ) (u v : V) :
    finiteCovariance (probability ends S y) (fun w M => F w M.val) u v =
      expectation ends S y (fun M => F u M * F v M) -
        expectation ends S y (F u) * expectation ends S y (F v) := by
  rw [Information.finiteCovariance_eq_product_sub _ (probability_total ends S y)]
  rw [finiteMean_eq_expectation ends S y (fun M => F u M * F v M),
    finiteMean_eq_expectation, finiteMean_eq_expectation]

omit [DecidableEq E] in
theorem unmatched_zero_one (ends : E → Finset V) (v : V) (M : Finset E) :
    GibbsMatching.unmatched ends v M = 0 ∨ GibbsMatching.unmatched ends v M = 1 := by
  unfold GibbsMatching.unmatched
  split_ifs <;> simp

end SubmodularMatching.Shearer
