import SubmodularMatching.GibbsMatching
import Mathlib.Data.Nat.Choose.Bounds

/-!
# Edge storage bound on a simple graph

Each stored edge has a distinct unordered pair of vertices.
-/

namespace SubmodularMatching.GibbsSampler

variable {E V : Type*} [DecidableEq V] [Fintype V]

theorem simple_graph_edge_count (ends : E → Finset V) (edges : Finset E)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) (hSimple : Set.InjOn ends (edges : Set E)) :
    edges.card ≤ (Fintype.card V).choose 2 := by
  calc
    edges.card = (edges.image ends).card := (Finset.card_image_of_injOn hSimple).symm
    _ ≤ ((Finset.univ : Finset V).powersetCard 2).card := by
      apply Finset.card_le_card
      intro U hU
      obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp hU
      exact Finset.mem_powersetCard.mpr ⟨Finset.subset_univ _,hEnds e he⟩
    _ = (Fintype.card V).choose 2 := by simp

theorem simple_graph_edge_count_sq (ends : E → Finset V) (edges : Finset E)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) (hSimple : Set.InjOn ends (edges : Set E)) :
    edges.card ≤ Fintype.card V ^ 2 :=
  (simple_graph_edge_count ends edges hEnds hSimple).trans (Nat.choose_le_pow _ _)

end SubmodularMatching.GibbsSampler
