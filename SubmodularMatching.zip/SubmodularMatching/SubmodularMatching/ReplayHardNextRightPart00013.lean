import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step110 : ProjectedGoal ⟨54972, 55079, 0, 141, 1028, 1064⟩ :=
  projectedGoal_chunk _ (.leaf 0xd727d6bc746a528800c9cc9d) (by decide +kernel)

theorem Part00013 : ProjectedGoal ⟨54972, 55079, 0, 141, 1028, 1064⟩ := step110

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
