import SubmodularMatching.CapacitySparseOnline

/-! # The source certificate uses exactly the slot pairs recorded online -/

namespace SubmodularMatching.Capacity
open Streaming
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable (ends : E → V × V) (cap : V → ℕ) (hpos : ∀ e, 0 < cap (ends e).1 ∧ 0 < cap (ends e).2)

theorem sparse_pair_at_acceptance (R : GridUpdateParameters) (input : ℕ → E × ℕ) (n : ℕ)
    (entry : E × (BSlot cap × BSlot cap)) (h : entry ∈ (sparseRun ends cap hpos R input n).assigned) :
    ∃ i < n, entry = ((input i).1, sparsePair ends cap hpos (sparseRun ends cap hpos R input i) (input i).1) := by
  induction n with
  | zero => cases h
  | succ n ih =>
    dsimp only [sparseRun,sparseStep] at h
    split_ifs at h with ha
    · rcases List.mem_append.mp h with h|h
      · obtain ⟨i,hi,he⟩ := ih h
        exact ⟨i,by omega,he⟩
      · exact ⟨n,by omega,List.mem_singleton.mp h⟩
    · obtain ⟨i,hi,he⟩ := ih h
      exact ⟨i,by omega,he⟩

theorem sparse_assigned_trace [Fintype V] (R : GridUpdateParameters) (C : PotentialConfig) (hR : R.Matches C)
    (hd : 0 < C.gap) (input : ℕ → E × ℕ) (n : ℕ)
    (hinj : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i=j) :
    let realInput := fun i => ((input i).1,C.gap*(input i).2)
    ∃ (left : (e : E) → Fin (cap (ends e).1)) (right : (e : E) → Fin (cap (ends e).2)),
      let pair := slotPair ends cap left right
      (∀ i ≤ n, (sparseRun ends cap hpos R input i).machine.Represents C
        (runPotential C pair realInput i)) ∧
      SelectsMin C ends cap left right realInput n ∧
      (∀ entry ∈ (sparseRun ends cap hpos R input n).assigned, entry.2 = pair entry.1) := by
  intro realInput
  obtain ⟨left,right,hr,he,hm⟩ := onlineSlots_trace_at ends cap hpos C realInput n hinj
  refine ⟨left,right,?_,hm,?_⟩
  · intro i hi
    rw [hr i hi]
    exact sparseRun_represents ends cap hpos R C hR hd input i
  · intro entry hentry
    obtain ⟨i,hi,rfl⟩ := sparse_pair_at_acceptance ends cap hpos R input n entry hentry
    have h := sparseRun_represents ends cap hpos R C hR hd input i
    rw [he i hi]
    simp only [slotPair,sparsePair,chooseLeft,chooseRight,sparseMinimum_eq_real cap C _ _ h]
    rfl

end
end SubmodularMatching.Capacity
