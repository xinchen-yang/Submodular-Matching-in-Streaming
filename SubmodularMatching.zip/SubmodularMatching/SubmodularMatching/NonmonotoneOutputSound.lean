import SubmodularMatching.NonmonotoneFreshBank
import SubmodularMatching.NonmonotoneRunningSelection
import SubmodularMatching.NonmonotoneOriginalInput
import SubmodularMatching.UpperBoundConfidence

/-! The output selection uses the physical bank and carries no proof flags. -/
namespace SubmodularMatching.AppendixM
open Streaming Streaming.OracleQuery Capacity Capacity.RealOracle UpperBoundAssembly GibbsSampler Finset
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def failureMass {A : Type*} (p : CandidateLaw A) (f : A → ℝ) (target : ℝ) : ℝ :=
  expected p.outcomes p.mass (fun a => if target ≤ f a then 0 else 1)

def sourceFailureBudget (δ : ℝ) : ℕ := ⌈1/min outerError (δ/2)⌉₊

theorem sourceFailureBudget_valid (δ : ℝ) (hd : 0<δ) :
    0<sourceFailureBudget δ ∧ 1/(sourceFailureBudget δ:ℝ) ≤ min outerError (δ/2) := by
  let e := min outerError (δ/2)
  have he : 0<e := lt_min (by norm_num [outerError,implementationUnit]) (by positivity)
  have hceil : 1/e ≤ (sourceFailureBudget δ:ℝ) := Nat.le_ceil _
  have hj : (0:ℝ)<sourceFailureBudget δ := (by positivity : (0:ℝ)<1/e).trans_le hceil
  refine ⟨by exact_mod_cast hj,?_⟩
  change 1/(sourceFailureBudget δ:ℝ) ≤ e
  rw [div_le_iff₀ hj]
  have hi := mul_le_mul_of_nonneg_right hceil he.le
  rwa [div_mul_cancel₀ _ he.ne',mul_comm] at hi

def confidenceTarget (n : ℕ) (c : ℝ) : ℝ := (((max 1 n:ℕ):ℝ)^⌈c⌉₊)⁻¹

theorem confidenceTarget_pos (n : ℕ) (c : ℝ) : 0<confidenceTarget n c := by
  unfold confidenceTarget
  positivity

theorem confidenceTarget_le (n : ℕ) (hn : 1≤n) (c : ℝ) :
    confidenceTarget n c ≤ (n:ℝ)^(-c) := by
  simpa only [confidenceTarget,max_eq_right hn] using confidence_integer_le n hn c

def bankCandidates {cap : V → ℕ} (trial : ℕ → ℝ → SparseSlots E cap → CandidateLaw (Finset E))
    (bank : RealOracle.GuessBank (SparseSlots E cap)) : List (CandidateLaw (Finset E)) :=
  bank.states.map fun a => trial a.1 (bank.epoch.scale a.1) a.2

theorem mem_bankCandidates {cap : V → ℕ} (trial : ℕ → ℝ → SparseSlots E cap → CandidateLaw (Finset E))
    (bank : RealOracle.GuessBank (SparseSlots E cap)) (j : ℕ) (st : SparseSlots E cap)
    (h : bank.lookup j = some st) : trial j (bank.epoch.scale j) st ∈ bankCandidates trial bank := by
  have key (xs : List (ℕ × SparseSlots E cap)) (hh : xs.lookup j = some st) : (j,st)∈xs := by
    induction xs with
    | nil => simp [List.lookup] at hh
    | cons a rest ih =>
      rcases a with ⟨g,s⟩
      by_cases he : j=g
      · subst g
        have hs : s=st := by simpa [List.lookup] using hh
        subst s
        exact List.mem_cons_self
      · have hh' : rest.lookup j=some st := by
          simpa [List.lookup,beq_eq_false_iff_ne.mpr he] using hh
        exact List.mem_cons_of_mem _ (ih hh')
  exact List.mem_map.mpr ⟨(j,st),key bank.states h,rfl⟩

theorem fresh_output_sound {cap : V → ℕ} (ends : E → V×V)
    (hp : ∀ e, 0<cap (ends e).1 ∧ 0<cap (ends e).2)
    (v N bits k : ℕ) (f : Finset E → ℝ) (edges : ℕ → E)
    (test : ℕ → SourceWordTape → WordBatch (sourceGuessCount v*N) (v^2) bits → Bool)
    (states : Finset (Finset E)) (init : Finset E) (hinit : init∈states)
    (trial : ℕ → ℝ → SparseSlots E cap → CandidateLaw (Finset E))
    (hs : ∀ j τ st, (trial j τ st).outcomes ⊆ states)
    (opt δ : ℝ) (hδ : 0<δ) (h0 : 0<f init) (hopt : f init ≤ opt)
    (hrange : ∀ a∈states, 0≤f a ∧ f a≤opt) :
    let prep := freshBankLaw ends cap hp v N bits f edges k
    let marked := RectangularSource.tapeLaw (sourceGuessCount v*N) (v^2) bits test k 0 (fun _ _ _ => 0) true
    let fromBank := bankCandidates trial
    let keep : ∀ (bank : RealOracle.GuessBank (SparseSlots E cap)), ∀ q∈fromBank bank, q.outcomes⊆states := by
      intro bank q hq
      change q ∈ bank.states.map (fun a => trial a.1 (bank.epoch.scale a.1) a.2) at hq
      obtain ⟨p,_,rfl⟩ := List.mem_map.mp hq
      exact hs p.1 (bank.epoch.scale p.1) p.2
    let p := physicalExpected prep f (outerError*f init/2) fromBank init
    let q := physicalAmplified prep f (outerError*f init/2) (selectorUnit*f init) fromBank init
      (postprocessCount δ)
    (∑ z ∈ marked.outcomes, if z.2 then 0 else marked.mass z) ≤ min outerError (δ/2) →
    (∀ z ∈ marked.outcomes, z.2=true →
      let bank := bankWithTape ends cap hp v N bits f edges z.1 k
      ∃ j st, bank.lookup j=some st ∧
      let law := trial j (bank.epoch.scale j) st
      (1000/4727+2*implementationUnit)*opt ≤ expected law.outcomes law.mass f) →
    p.outcomes ⊆ states ∧ q.outcomes ⊆ states ∧
      (1000/4727)*opt ≤ expected p.outcomes p.mass f ∧ failureMass q f (opt/(4727/1000)) ≤ δ := by
  classical
  intro prep marked fromBank keep p q hbad htrial
  let getBank := fun z : SourceWordTape × Bool => bankWithTape ends cap hp v N bits f edges z.1 k
  let candidates := fun z => fromBank (getBank z)
  have hc : ∀ z d, d∈candidates z → d.outcomes ⊆ states := fun z d h => keep (getBank z) d h
  have hv : ∀ z∈marked.outcomes, z.2=true → ∃ r∈candidates z,
      (1000/4727+2*implementationUnit)*opt ≤ expected r.outcomes r.mass f := by
    intro z hz hgood
    obtain ⟨j,st,hm,hvalue⟩ := htrial z hz hgood
    exact ⟨trial j ((getBank z).epoch.scale j) st,mem_bankCandidates trial (getBank z) j st hm,hvalue⟩
  have ⟨hmean,hprob⟩ := signed_laws_of_decisive_trial marked (fun z => z.2=true)
    states f candidates init opt (f init) δ h0 hopt hδ hinit rfl hc hrange hbad hv
  have hobs (obs : RealOracle.GuessBank (SparseSlots E cap) → ℝ) :
      expected marked.outcomes marked.mass (fun z => obs (getBank z)) =
      expected prep.outcomes prep.mass obs := by
    simpa only [getBank, Nat.zero_add] using
      tape_bank_expectation ends cap hp v N bits f edges test obs k 0 (fun _ _ _ => 0) true
  refine ⟨physicalExpected_invariant prep f _ _ _ states hinit keep,
    physicalAmplified_invariant prep f _ _ _ _ _ states hinit keep,?_,?_⟩
  · dsimp only [p]
    rw [physicalExpected_observe prep f f _ _ _ states hinit keep,expectedOutputLaw_value]
    rw [expectedOutputLaw_value] at hmean
    exact hmean.trans_eq (hobs (fun st => scanExpectation f (outerError*f init/2) f (fromBank st) init))
  · let bad := fun a => if opt/(4727/1000) ≤ f a then (0:ℝ) else 1
    change expected (physicalAmplified prep f _ _ fromBank init _).outcomes _ bad ≤ δ
    rw [physicalAmplified_observe prep f bad _ _ _ _ _ states hinit keep,refinedOutputLaw_value]
    rw [refinedOutputLaw_value] at hprob
    exact (hobs (fun st => selectionExpectation states (scanMass f (outerError*f init/2) (fromBank st) init)
      f (selectorUnit*f init) bad (postprocessCount δ) init)).symm.trans_le hprob

end
end SubmodularMatching.AppendixM
