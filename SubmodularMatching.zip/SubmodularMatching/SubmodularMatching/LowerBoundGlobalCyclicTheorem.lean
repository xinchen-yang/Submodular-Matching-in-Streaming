import SubmodularMatching.LowerBoundGlobalCyclicFamily
import SubmodularMatching.LowerBoundGlobalFullTheorem

/-! # Theorem 1.2 with only the cited near-two-thirds blueprint construction -/

namespace SubmodularMatching.LowerBoundGlobal

open Filter LowerBoundAssembly MeasureTheory

universe u v

noncomputable section

/-- The near-two-thirds proper blueprint theorem of AJX II is the sole
external graph-theoretic input. ERS host existence and the expansion
are both supplied by the formalized cyclic construction. -/
theorem theorem1_2_of_blueprints {R a : ℝ} (hR : 1 ≤ R) (hR3 : R < 3) (ha : 0 ≤ a)
    (bp : AJX.ProperBlueprintsNearTwoThirds) :
    ∃ (params : Parameters R) (family : BlueprintFamily params.densityLoss) (A : ℕ),
      a + 1 < (A : ℝ) ∧
      Tendsto (fun i => (BlueprintVertexCount params family (A : ℝ) i : ℝ)) atTop atTop ∧
      ∀ {State : ℕ → Type u} {Seed : ℕ → Type v}
        [∀ i, Fintype (State i)] [∀ i, Nonempty (State i)] [∀ i, MeasurableSpace (Seed i)]
        (μ : ∀ i, Measure (Seed i)) [∀ i, IsProbabilityMeasure (μ i)]
        (alg : ∀ i, BlueprintRandomProgram params family (A : ℝ) i (State i) (Seed i) (μ i))
        (space : WordSpace (BlueprintVertexCount params family (A : ℝ)) a),
        (∀ i, Fintype.card (State i) ≤ 2 ^ space.bits i) →
        ∀ prob > (0 : ℝ), ∀ᶠ i : ℕ in atTop,
          HasHardCounterexamples params family i (alg i) prob :=
  theorem1_2_of_ajx hR hR3 ha AJX.cyclic_ERSFamilies bp

end

end SubmodularMatching.LowerBoundGlobal
