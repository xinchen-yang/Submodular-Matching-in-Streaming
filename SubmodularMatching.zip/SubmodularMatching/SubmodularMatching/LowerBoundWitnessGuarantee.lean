import SubmodularMatching.LowerBoundWitnessStream
import SubmodularMatching.LowerBoundWitnessWords

/-! # Optimum and matching number of the actual finite hard instances -/

namespace SubmodularMatching.LowerBoundGlobal

open LowerBoundAssembly LowerBoundSoundness
open scoped BigOperators

noncomputable section

variable {p N P t H : ℕ} {C : Type*} [Fintype C] [DecidableEq C]

/-- A feasible solution is an arrived set of edges forming a matching. -/
def HardFeasible (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C)
    (S : Finset (HardEdge p N C)) : Prop :=
  HardMatching S ∧ ∀ e ∈ S, e ∈ hardStream b draw

/-- The finite set of all feasible matchings, including the empty matching. -/
def hardMatchings (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C) :
    Finset (Finset (HardEdge p N C)) := by
  classical
  exact Finset.univ.filter (HardFeasible b draw)

omit [DecidableEq C] in
theorem mem_hardMatchings (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C)
    (S : Finset (HardEdge p N C)) : S ∈ hardMatchings b draw ↔ HardFeasible b draw S := by
  classical
  simp [hardMatchings]

theorem hardMatchings_nonempty (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C) :
    (hardMatchings b draw).Nonempty := by
  refine ⟨∅, (mem_hardMatchings b draw ∅).mpr ?_⟩
  simp [HardFeasible, HardMatching]

/-- Maximum matching cardinality on the arrived graph. -/
def hardMatchingNumber (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C) : ℕ :=
  ((hardMatchings b draw).image Finset.card).max'
    ((hardMatchings_nonempty b draw).image _)

theorem hardMatchingNumber_attained (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) :
    ∃ S : Finset (HardEdge p N C), HardFeasible b draw S ∧ S.card = hardMatchingNumber b draw := by
  have h := Finset.max'_mem ((hardMatchings b draw).image Finset.card)
    ((hardMatchings_nonempty b draw).image _)
  obtain ⟨S, hS, hcard⟩ := Finset.mem_image.mp h
  exact ⟨S, (mem_hardMatchings b draw S).mp hS, hcard⟩

theorem card_le_hardMatchingNumber (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C)
    (S : Finset (HardEdge p N C)) (hS : HardFeasible b draw S) :
    S.card ≤ hardMatchingNumber b draw := by
  apply Finset.le_max'
  exact Finset.mem_image.mpr ⟨S, (mem_hardMatchings b draw S).mpr hS, rfl⟩

theorem hardMatchingNumber_linear [AddCommGroup C] (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) (qb ql : ℝ) (hμ : 0 < hardDrawMass b qb ql draw)
    (hH : 3 * H ≤ 2 * N) (hlarge : 2 ≤ ql * (Fintype.card C : ℝ) ^ 2) :
    ql * (announcedVertices p N C : ℝ) / 12 ≤ (hardMatchingNumber b draw : ℝ) ∧
      hardMatchingNumber b draw ≤ 2 * p * N * Fintype.card C := by
  obtain ⟨S, hS, hmax⟩ := hardMatchingNumber_attained b draw
  refine ⟨?_, hmax ▸ hardMatching_card_upper S hS.1⟩
  have hleaf := hardLeafMatching_linear_size b draw qb ql hμ hH hlarge
  simp only [announcedVertices, Nat.cast_mul, Nat.cast_ofNat]
  apply hleaf.trans
  exact_mod_cast card_le_hardMatchingNumber b draw (hardLeafMatching b draw)
    ⟨hardLeafMatching_matching b draw, fun _ he => hardLeafMatching_arrived b draw he⟩

variable [Sub C]

/-- Maximum objective value over the arrived feasible matchings. -/
def hardOptimum (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C) : ℝ := by
  classical
  let f := hardOracle (1 / (hardNormalizer C N H : ℝ)) draw
  exact ((hardMatchings b draw).image f).max' ((hardMatchings_nonempty b draw).image _)

theorem hardOptimum_attained (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C) :
    ∃ S : Finset (HardEdge p N C), HardFeasible b draw S ∧
      hardOracle (1 / (hardNormalizer C N H : ℝ)) draw S = hardOptimum b draw := by
  classical
  let f := hardOracle (1 / (hardNormalizer C N H : ℝ)) draw
  have h := Finset.max'_mem ((hardMatchings b draw).image f)
    ((hardMatchings_nonempty b draw).image _)
  obtain ⟨S, hS, hval⟩ := Finset.mem_image.mp h
  exact ⟨S, (mem_hardMatchings b draw S).mp hS, hval⟩

theorem value_le_hardOptimum (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C)
    (S : Finset (HardEdge p N C)) (hS : HardFeasible b draw S) :
    hardOracle (1 / (hardNormalizer C N H : ℝ)) draw S ≤ hardOptimum b draw := by
  classical
  unfold hardOptimum
  apply Finset.le_max'
  exact Finset.mem_image.mpr ⟨S, (mem_hardMatchings b draw S).mpr hS, rfl⟩

theorem hardOracle_axioms (draw : HardDraw p N P t C) :
    let f := hardOracle (1 / (hardNormalizer C N H : ℝ)) draw
    f ∅ = 0 ∧ IsMonotone f ∧ IsSubmodular f ∧
      ∀ S e, f (insert e S) - f S ≤ 1 / (hardNormalizer C N H : ℝ) := by
  refine ⟨RecursiveObjective.objective_empty _ _ _ _ _, ?_,
    RecursiveObjective.objective_submodular _ (by positivity) _ _ _ _, ?_⟩
  · intro A B hAB
    exact RecursiveObjective.objective_monotone _ (by positivity) _ _ _ _ A B hAB
  · intro S e
    exact RecursiveObjective.objective_increment_le _ (by positivity) _ _ _ _ S e

end

section

variable {p N P t H : ℕ} {C : Type*} [Fintype C] [DecidableEq C] [AddCommGroup C]

theorem hardComplete_le_hardOptimum (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) (ξ : ℝ) (hscale : 0 < hardNormalizer C N H)
    (hcomplete : hardComplete b ξ draw) : (p : ℝ) * (1 - ξ) ≤ hardOptimum b draw := by
  obtain ⟨S, hM, hS, hval⟩ := hardComplete_feasible_value b draw ξ hscale hcomplete
  exact hval.trans (value_le_hardOptimum b draw S ⟨hM, hS⟩)

/-- The probability that the actual matching optimum misses the completeness
threshold is bounded by the two sampling errors. -/
theorem hardOptimum_failure_le [Nonempty (Fin t)]
    (b : BlueprintExpansion N P t H) (δb δl γ ξ : ℝ)
    (hb : 0 < δb) (hl : 0 ≤ δl) (hγ : 0 < γ)
    (hξ : δb + δl + 3 * γ ≤ ξ) (hξ1 : ξ < 1)
    (hscale : 0 < hardNormalizer C N H)
    (hgap : 0 < γ * (H : ℝ) - P)
    (hlarge : 1 ≤ γ * (Fintype.card C : ℝ) ^ 2) :
    eventMass (hardDrawMass b (1 - δb) (1 - δl)) (fun d : HardDraw p N P t C =>
      hardOptimum b d < (p : ℝ) * (1 - ξ)) ≤ (p : ℝ) *
        ((H : ℝ) / (4 * (γ * (H : ℝ) - P) ^ 2) +
          (hardNormalizer C N H : ℝ) / (4 * (γ * (hardNormalizer C N H : ℝ)) ^ 2)) := by
  classical
  refine le_trans ?_ (hardComplete_failure_le b δb δl γ ξ hb hl hγ hξ hξ1 hgap hlarge)
  unfold eventMass
  apply Finset.sum_le_sum
  intro draw _
  by_cases h : hardOptimum b draw < (p : ℝ) * (1 - ξ)
  · have hbad : ¬hardComplete b ξ draw := fun hd =>
      (not_lt_of_ge (hardComplete_le_hardOptimum b draw ξ hscale hd)) h
    simp [h, hbad]
  · simp only [if_neg h]
    split_ifs
    · exact le_rfl
    · exact hardDrawMass_nonneg b _ _ draw

end

end SubmodularMatching.LowerBoundGlobal
