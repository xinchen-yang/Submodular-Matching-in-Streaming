import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step102 : ProjectedGoal ⟨432, 647, 283, 567, 0, 567⟩ :=
  projectedGoal_chunk _ (.y (.x (.x (.leaf 0x1aff0000e8d4a5100004820d) (.y (.leaf 0x1aff0000e8d4a5100039d39c) (.leaf 0x6bff0000000000000004e4e0))) (.leaf 0x6bf00001d1a94a2004e24e1)) (.leaf 0x6bff0000000000000000f00f)) (by decide +kernel)

theorem Part00009 : ProjectedGoal ⟨432, 647, 283, 567, 0, 567⟩ := step102

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
