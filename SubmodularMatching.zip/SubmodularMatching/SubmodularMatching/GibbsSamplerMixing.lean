import SubmodularMatching.GibbsSamplerApproximation
import Mathlib.Data.Real.Sqrt
import Mathlib.Analysis.SpecialFunctions.Exp

/-!
# Mixing from the reversible-chain spectral estimate

Appendix I invokes an external spectral-gap estimate. This module
derives the finite total-variation mixing bound assuming the corresponding
mean-zero weighted-square contraction, then specializes it to the verified
Gibbs chain started from the empty matching.
-/

namespace SubmodularMatching.GibbsSampler

open scoped BigOperators

variable {S : Type*}

noncomputable def centeredDensity (p stationary : S → ℝ) (s : S) : ℝ :=
  p s / stationary s - 1

noncomputable def squareEnergy (states : Finset S) (stationary f : S → ℝ) : ℝ :=
  ∑ s ∈ states, stationary s * (f s)^2

noncomputable def actOnFunctions (states : Finset S) (kernel : S → S → ℝ) (f : S → ℝ)
    (s : S) : ℝ :=
  ∑ t ∈ states, kernel s t * f t

theorem centeredDensity_zero_mean (states : Finset S) (p stationary : S → ℝ)
    (hp : IsProbability states p) (hstat : IsProbability states stationary)
    (hpos : ∀ s ∈ states, 0 < stationary s) :
    (∑ s ∈ states, stationary s * centeredDensity p stationary s) = 0 := by
  have h (s : S) (hs : s ∈ states) :
      stationary s * centeredDensity p stationary s = p s - stationary s := by
    unfold centeredDensity
    field_simp [(hpos s hs).ne']
  rw [Finset.sum_congr rfl h, Finset.sum_sub_distrib, hp.total, hstat.total, sub_self]

theorem centeredDensity_step (states : Finset S) (p stationary : S → ℝ)
    (kernel : S → S → ℝ) (hk : IsKernel states kernel)
    (hpos : ∀ s ∈ states, 0 < stationary s)
    (hrev : ∀ s ∈ states, ∀ t ∈ states, stationary s * kernel s t = stationary t * kernel t s)
    (t : S) (ht : t ∈ states) :
    centeredDensity (applyKernel states kernel p) stationary t =
      actOnFunctions states kernel (centeredDensity p stationary) t := by
  unfold centeredDensity actOnFunctions applyKernel
  rw [Finset.sum_div]
  have h (s : S) (hs : s ∈ states) :
      p s * kernel s t / stationary t = kernel t s * (p s / stationary s) := by
    field_simp [(hpos s hs).ne', (hpos t ht).ne']
    linear_combination p s * hrev s hs t ht
  rw [Finset.sum_congr rfl h]
  simp_rw [mul_sub, mul_one]
  rw [Finset.sum_sub_distrib, (hk.rows t ht).total]

theorem variation_le_sqrt_energy (states : Finset S) (p stationary : S → ℝ)
    (hstat : IsProbability states stationary) (hpos : ∀ s ∈ states, 0 < stationary s) :
    variation states p stationary ≤
      Real.sqrt (squareEnergy states stationary (centeredDensity p stationary)) / 2 := by
  unfold variation
  apply div_le_div_of_nonneg_right _ (by norm_num)
  let f := fun s => Real.sqrt (stationary s)
  let g := fun s => f s * |centeredDensity p stationary s|
  have hCS := Real.sum_mul_le_sqrt_mul_sqrt states f g
  have hf (s : S) (hs : s ∈ states) : f s ^ 2 = stationary s := Real.sq_sqrt (hpos s hs).le
  have hg (s : S) (hs : s ∈ states) :
      g s ^ 2 = stationary s * centeredDensity p stationary s ^ 2 := by
    dsimp only [g]
    rw [mul_pow, hf s hs, sq_abs]
  have habs (s : S) (hs : s ∈ states) : f s * g s = |p s - stationary s| := by
    dsimp only [g]
    rw [← mul_assoc, ← pow_two, hf s hs, ← abs_of_pos (hpos s hs), ← abs_mul]
    congr 1
    rw [abs_of_pos (hpos s hs)]
    unfold centeredDensity
    field_simp [(hpos s hs).ne']
  rw [Finset.sum_congr rfl habs, Finset.sum_congr rfl hf, Finset.sum_congr rfl hg,
    hstat.total, Real.sqrt_one, one_mul] at hCS
  exact hCS

theorem squareEnergy_iterate (states : Finset S) (p stationary : S → ℝ)
    (kernel : S → S → ℝ) (hp : IsProbability states p)
    (hstat : IsProbability states stationary) (hk : IsKernel states kernel)
    (hpos : ∀ s ∈ states, 0 < stationary s)
    (hrev : ∀ s ∈ states, ∀ t ∈ states, stationary s * kernel s t = stationary t * kernel t s)
    (ρ : ℝ)
    (hcontract : ∀ f : S → ℝ, (∑ s ∈ states, stationary s * f s) = 0 →
      squareEnergy states stationary (actOnFunctions states kernel f) ≤
        ρ ^ 2 * squareEnergy states stationary f)
    (k : ℕ) :
    squareEnergy states stationary (centeredDensity (iterateKernel states kernel p k) stationary)
      ≤ (ρ ^ 2) ^ k * squareEnergy states stationary (centeredDensity p stationary) := by
  induction k with
  | zero => simp [iterateKernel]
  | succ k ih =>
    let q := iterateKernel states kernel p k
    have hq := iterateKernel_probability states p kernel hp hk k
    have hstep :
        squareEnergy states stationary (centeredDensity (applyKernel states kernel q) stationary) =
          squareEnergy states stationary (actOnFunctions states kernel (centeredDensity q stationary)) := by
      unfold squareEnergy
      exact Finset.sum_congr rfl fun t ht => by
        rw [centeredDensity_step states q stationary kernel hk hpos hrev t ht]
    change squareEnergy states stationary (centeredDensity (applyKernel states kernel q) stationary) ≤ _
    rw [hstep]
    calc
      _ ≤ ρ^2 * squareEnergy states stationary (centeredDensity q stationary) :=
        hcontract _ (centeredDensity_zero_mean states q stationary hq hstat hpos)
      _ ≤ ρ^2 * ((ρ^2)^k * squareEnergy states stationary (centeredDensity p stationary)) :=
        mul_le_mul_of_nonneg_left ih (sq_nonneg _)
      _ = _ := by rw [pow_succ]; ring

noncomputable def pointMass [DecidableEq S] (s t : S) : ℝ := if s = t then 1 else 0

theorem pointMass_probability [DecidableEq S] (states : Finset S) (s : S)
    (hs : s ∈ states) : IsProbability states (pointMass s) := by
  constructor
  · intro t _
    unfold pointMass
    split_ifs <;> norm_num
  · simp [pointMass, hs]

theorem pointMass_squareEnergy [DecidableEq S] (states : Finset S) (stationary : S → ℝ)
    (hstat : IsProbability states stationary) (hpos : ∀ s ∈ states, 0 < stationary s)
    (s : S) (hs : s ∈ states) :
    squareEnergy states stationary (centeredDensity (pointMass s) stationary) =
      (stationary s)⁻¹ - 1 := by
  have his := Finset.sum_erase_add states stationary hs
  rw [hstat.total] at his
  have hsum : (∑ t ∈ states.erase s, stationary t *
      (centeredDensity (pointMass s) stationary t)^2) = ∑ t ∈ states.erase s, stationary t := by
    exact Finset.sum_congr rfl fun t ht => by
      have hst : s ≠ t := (Finset.mem_erase.mp ht).1.symm
      simp [centeredDensity, pointMass, hst]
  unfold squareEnergy
  rw [← Finset.sum_erase_add _ _ hs, hsum]
  have hq : (∑ t ∈ states.erase s, stationary t) = 1 - stationary s := by linarith
  rw [hq]
  have hPoint : pointMass s s = 1 := by simp [pointMass]
  rw [centeredDensity, hPoint]
  field_simp [(hpos s hs).ne']
  ring

theorem variation_iterate_pointMass [DecidableEq S] (states : Finset S)
    (stationary : S → ℝ) (kernel : S → S → ℝ)
    (hstat : IsProbability states stationary) (hk : IsKernel states kernel)
    (hpos : ∀ s ∈ states, 0 < stationary s)
    (hrev : ∀ s ∈ states, ∀ t ∈ states, stationary s * kernel s t = stationary t * kernel t s)
    (ρ : ℝ) (hρ : 0 ≤ ρ)
    (hcontract : ∀ f : S → ℝ, (∑ s ∈ states, stationary s * f s) = 0 →
      squareEnergy states stationary (actOnFunctions states kernel f) ≤
        ρ^2 * squareEnergy states stationary f)
    (s : S) (hs : s ∈ states) (k : ℕ) :
    variation states (iterateKernel states kernel (pointMass s) k) stationary ≤
      ρ^k * Real.sqrt ((stationary s)⁻¹ - 1) / 2 := by
  have h := squareEnergy_iterate states (pointMass s) stationary kernel
    (pointMass_probability states s hs) hstat hk hpos hrev ρ hcontract k
  rw [pointMass_squareEnergy states stationary hstat hpos s hs, ← pow_mul, Nat.mul_comm,
    pow_mul] at h
  apply (variation_le_sqrt_energy states _ stationary hstat hpos).trans
  apply div_le_div_of_nonneg_right _ (by norm_num)
  calc
    _ ≤ Real.sqrt ((ρ^k)^2 * ((stationary s)⁻¹ - 1)) := Real.sqrt_le_sqrt h
    _ = _ := by rw [Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq (pow_nonneg hρ k)]

open GibbsMatching

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem gibbs_probability_positive (ends : E → Finset V) (edges M : Finset E)
    (activity : E → ℝ) (hActivity : ∀ e ∈ edges, 0 < activity e)
    (hM : M ∈ matchings ends edges) :
    0 < probability ends edges activity M := by
  classical
  rw [probability, if_pos hM]
  exact div_pos (Finset.prod_pos fun e he => hActivity e ((mem_matchings ends edges M).mp hM |>.1 he))
    (partition_positive ends edges activity (fun e he => (hActivity e he).le))

theorem partition_le_exp_activity (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (hActivity : ∀ e ∈ edges, 0 ≤ activity e) :
    partition ends edges activity ≤ Real.exp (∑ e ∈ edges, activity e) := by
  classical
  calc
    _ ≤ ∑ M ∈ edges.powerset, weight activity M := by
      unfold partition
      apply Finset.sum_le_sum_of_subset_of_nonneg
      · exact Finset.filter_subset _ _
      · exact fun M hM _ => weight_nonnegative activity M (fun e he => hActivity e (Finset.mem_powerset.mp hM he))
    _ = ∏ e ∈ edges, (1 + activity e) := (Finset.prod_one_add edges).symm
    _ ≤ ∏ e ∈ edges, Real.exp (activity e) := by
      exact Finset.prod_le_prod (fun e he => by linarith [hActivity e he])
        (fun e _ => by simpa [add_comm] using Real.add_one_le_exp (activity e))
    _ = _ := (Real.exp_sum _ _).symm

/-- The standard finite-chain mixing bound used in Appendix I. The only
spectral premise is the contraction for mean-zero functions, which the
canonical-path argument for the paper's local chain is meant to supply. -/
theorem gibbs_mixing_from_contraction (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (hActivity : ∀ e ∈ edges, 0 < activity e)
    (γ : ℝ) (hγ : γ ≤ 1)
    (hcontract : ∀ f : Finset E → ℝ,
      (∑ M ∈ matchings ends edges, probability ends edges activity M * f M) = 0 →
      squareEnergy (matchings ends edges) (probability ends edges activity)
        (actOnFunctions (matchings ends edges) (transition ends edges activity) f) ≤
      (1-γ)^2 * squareEnergy (matchings ends edges) (probability ends edges activity) f)
    (t : ℕ) :
    variation (matchings ends edges)
      (iterateKernel (matchings ends edges) (transition ends edges activity) (pointMass ∅) t)
      (probability ends edges activity) ≤
      Real.exp ((∑ e ∈ edges, activity e) / 2 - γ * t) / 2 := by
  have hActivity₀ : ∀ e ∈ edges, 0 ≤ activity e := fun e he => (hActivity e he).le
  have hprob : IsProbability (matchings ends edges) (probability ends edges activity) :=
    ⟨fun M _ => probability_nonnegative ends edges activity hActivity₀ M,
      probability_total ends edges activity hActivity₀⟩
  have hkernel : IsKernel (matchings ends edges) (transition ends edges activity) :=
    ⟨fun M hM => ⟨fun N hN => transition_nonnegative ends edges activity hActivity₀ M N hM hN,
      transition_total ends edges activity M hM⟩⟩
  have h := variation_iterate_pointMass (matchings ends edges) (probability ends edges activity)
    (transition ends edges activity) hprob hkernel
    (fun M hM => gibbs_probability_positive ends edges M activity hActivity hM)
    (fun M hM N hN => detailed_balance ends edges activity M N hM hN)
    (1-γ) (sub_nonneg.mpr hγ) hcontract ∅ (empty_mem_matchings ends edges) t
  have hbase : probability ends edges activity (∅ : Finset E) = (partition ends edges activity)⁻¹ := by
    classical
    rw [probability, if_pos (empty_mem_matchings ends edges), weight_empty, one_div]
  rw [hbase, inv_inv] at h
  apply h.trans
  apply div_le_div_of_nonneg_right _ (by norm_num)
  have hρ : (1-γ)^t ≤ Real.exp (-(γ * t)) := by
    calc
      _ ≤ (Real.exp (-γ))^t := pow_le_pow_left₀ (sub_nonneg.mpr hγ)
        (by simpa [sub_eq_add_neg, add_comm] using Real.add_one_le_exp (-γ)) t
      _ = _ := by rw [← Real.exp_nat_mul]; congr 1; ring
  have hsqrt : Real.sqrt (partition ends edges activity - 1) ≤ Real.exp ((∑ e ∈ edges, activity e) / 2) := by
    apply (Real.sqrt_le_left (Real.exp_nonneg _)).2
    have hexp : Real.exp ((∑ e ∈ edges, activity e) / 2) ^ 2 =
        Real.exp (∑ e ∈ edges, activity e) := by
      rw [← Real.exp_nat_mul]
      norm_num
      ring
    rw [hexp]
    linarith only [partition_le_exp_activity ends edges activity hActivity₀]
  calc
    _ ≤ Real.exp (-(γ * t)) * Real.exp ((∑ e ∈ edges, activity e) / 2) :=
      mul_le_mul hρ hsqrt (Real.sqrt_nonneg _) (Real.exp_nonneg _)
    _ = _ := by rw [← Real.exp_add]; congr 1; ring

/-- The exact chain spends at most half of the total variation budget once
the integer step count meets GS1. The remaining half is for transition errors. -/
theorem gibbs_mixing_budget (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (hActivity : ∀ e ∈ edges, 0 < activity e)
    (γ : ℝ) (hγ : γ ≤ 1)
    (hcontract : ∀ f : Finset E → ℝ,
      (∑ M ∈ matchings ends edges, probability ends edges activity M * f M) = 0 →
      squareEnergy (matchings ends edges) (probability ends edges activity)
        (actOnFunctions (matchings ends edges) (transition ends edges activity) f) ≤
      (1-γ)^2 * squareEnergy (matchings ends edges) (probability ends edges activity) f)
    (t k : ℕ) (δ : ℝ)
    (ht : (∑ e ∈ edges, activity e) / 2 + k ≤ γ * t)
    (hδ : 1 ≤ δ * (2 : ℝ)^k) :
    variation (matchings ends edges)
      (iterateKernel (matchings ends edges) (transition ends edges activity) (pointMass ∅) t)
      (probability ends edges activity) ≤ δ / 2 := by
  apply (gibbs_mixing_from_contraction ends edges activity hActivity γ hγ hcontract t).trans
  apply div_le_div_of_nonneg_right _ (by norm_num)
  have hOne : (2 : ℝ) ≤ Real.exp 1 := by simpa only [one_add_one_eq_two] using Real.add_one_le_exp 1
  have hOneNeg : Real.exp (-1) ≤ (2 : ℝ)⁻¹ := by
    rw [Real.exp_neg]
    exact (inv_le_inv₀ (Real.exp_pos _) (by norm_num : (0 : ℝ) < 2)).2 hOne
  calc
    _ ≤ Real.exp (-(k : ℝ)) := Real.exp_le_exp.mpr (by linarith)
    _ = (Real.exp (-1)) ^ k := by rw [← Real.exp_nat_mul]; simp
    _ ≤ ((2 : ℝ)⁻¹)^k := pow_le_pow_left₀ (Real.exp_nonneg _) hOneNeg _
    _ ≤ δ := by rw [inv_pow, ← one_div]; exact (div_le_iff₀ (by positivity)).mpr hδ

/-- Combining exact mixing with per-transition rounding gives the complete
total variation budget, conditional on the spectral and row-error estimates. -/
theorem gibbs_approximate_mixing_budget (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (hActivity : ∀ e ∈ edges, 0 < activity e)
    (γ : ℝ) (hγ : γ ≤ 1)
    (hcontract : ∀ f : Finset E → ℝ,
      (∑ M ∈ matchings ends edges, probability ends edges activity M * f M) = 0 →
      squareEnergy (matchings ends edges) (probability ends edges activity)
        (actOnFunctions (matchings ends edges) (transition ends edges activity) f) ≤
      (1-γ)^2 * squareEnergy (matchings ends edges) (probability ends edges activity) f)
    (t k : ℕ) (δ : ℝ)
    (ht : (∑ e ∈ edges, activity e) / 2 + k ≤ γ * t)
    (hδ : 1 ≤ δ * (2 : ℝ)^k)
    (approx : Finset E → Finset E → ℝ) (ha : IsKernel (matchings ends edges) approx)
    (ε : ℝ)
    (herr : ∀ M ∈ matchings ends edges,
      variation (matchings ends edges) (approx M) (transition ends edges activity M) ≤ ε)
    (hbudget : t * ε ≤ δ / 2) :
    variation (matchings ends edges)
      (iterateKernel (matchings ends edges) approx (pointMass ∅) t)
      (probability ends edges activity) ≤ δ := by
  have hActivity₀ : ∀ e ∈ edges, 0 ≤ activity e := fun e he => (hActivity e he).le
  have hk : IsKernel (matchings ends edges) (transition ends edges activity) :=
    ⟨fun M hM => ⟨fun N hN => transition_nonnegative ends edges activity hActivity₀ M N hM hN,
      transition_total ends edges activity M hM⟩⟩
  let p := pointMass (∅ : Finset E)
  let source := matchings ends edges
  let exactLaw := iterateKernel source (transition ends edges activity) p t
  let approxLaw := iterateKernel source approx p t
  have h1 := (variation_iterate source p approx (transition ends edges activity)
    (pointMass_probability source ∅ (empty_mem_matchings ends edges)) ha hk ε herr t).trans
    hbudget
  have h2 := gibbs_mixing_budget ends edges activity hActivity γ hγ hcontract t k δ ht hδ
  have htri := variation_triangle source approxLaw exactLaw (probability ends edges activity)
  change variation source approxLaw (probability ends edges activity) ≤ δ
  exact htri.trans ((add_le_add h1 h2).trans_eq (by ring))

end SubmodularMatching.GibbsSampler
