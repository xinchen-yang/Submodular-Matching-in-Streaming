import SubmodularMatching.LowerBoundGlobalBlueprint
import SubmodularMatching.LowerBoundGlobalFactorization

/-! # The mixed law of the base blueprint samples -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

variable {N P t H : ℕ}

abbrev PhaseSample (N : ℕ) := Finset (Fin N × Fin N)

/-- The phase retention law after the blueprint tuple has been fixed. -/
def phaseRetainedMass (b : BlueprintExpansion N P t H) (q : ℝ)
    (J : Fin P → Fin t) (i : Fin P) (S : PhaseSample N) : ℝ :=
  uniformSubsetMass (b.phases J i) (retainedSize q (b.phases J i).card) S

theorem phaseRetainedMass_total (b : BlueprintExpansion N P t H) (q : ℝ)
    (hq0 : 0 ≤ q) (hq1 : q ≤ 1) (J : Fin P → Fin t) (i : Fin P) :
    (∑ S, phaseRetainedMass b q J i S) = 1 :=
  sum_uniformSubsetMass _ _ (retainedSize_le hq0 hq1 _)

theorem prefixTuples_nesting {i j : Fin P} (hji : j ≤ i) (J : Fin P → Fin t)
    (J' : prefixTuples i J) : (J' : Fin P → Fin t) ∈ prefixTuples j J := by
  have h := Finset.mem_filter.mp J'.property
  apply Finset.mem_filter.mpr
  exact ⟨Finset.mem_univ _, fun k hk => h.2 k (hk.trans_le hji)⟩

/-- A prefix of the blueprint tuple determines both the phase's actual
edge universe and the retention law in every earlier and current phase. -/
theorem phaseRetainedMass_prefix (b : BlueprintExpansion N P t H) (q : ℝ)
    (i : Fin P) (J : Fin P → Fin t) (J' : prefixTuples i J)
    (j : Fin P) (hji : j ≤ i) :
    phaseRetainedMass b q (J' : Fin P → Fin t) j = phaseRetainedMass b q J j := by
  unfold phaseRetainedMass
  rw [b.prefix_invariance j J J' (prefixTuples_nesting hji J J')]

theorem phaseSampleLaw_factor_at (b : BlueprintExpansion N P t H) (q : ℝ)
    (J : Fin P → Fin t) (i : Fin P) (samples : Fin P → PhaseSample N) :
    (∏ j, phaseRetainedMass b q J j (samples j)) =
      (∏ j : {j : Fin P // j < i}, phaseRetainedMass b q J j (samples j)) *
        phaseRetainedMass b q J i (samples i) *
      (∏ j : {j : Fin P // i < j}, phaseRetainedMass b q J j (samples j)) := by
  rw [independent_prefix_split (fun j => j ≤ i)]
  rw [← Fintype.prod_subtype_mul_prod_subtype
      (fun j : {j : Fin P // j ≤ i} => j.val < i)]
  have hcast1 : (∏ j : {j : {j : Fin P // j ≤ i} // j.val < i},
      phaseRetainedMass b q J j.val (samples j.val)) =
      (∏ j : {j : Fin P // j < i}, phaseRetainedMass b q J j (samples j)) := by
    let eqv : {j : {j : Fin P // j ≤ i} // j.val < i} ≃ {j : Fin P // j < i} :=
      { toFun := fun j => ⟨j.val.val, j.property⟩
        invFun := fun j => ⟨⟨j.val, j.property.le⟩, j.property⟩
        left_inv := fun _ => rfl
        right_inv := fun _ => rfl }
    exact eqv.prod_comp (fun j => phaseRetainedMass b q J j.val (samples j.val))
  rw [hcast1]
  let I := {j : {j : Fin P // j ≤ i} // ¬j.val < i}
  haveI : Subsingleton I := by
    constructor
    intro a z
    have ha : a.val.val = i := le_antisymm a.val.property (le_of_not_gt a.property)
    have hz : z.val.val = i := le_antisymm z.val.property (le_of_not_gt z.property)
    exact Subtype.ext (Subtype.ext (ha.trans hz.symm))
  let ref : I := ⟨⟨i, le_rfl⟩, lt_irrefl _⟩
  rw [Fintype.prod_subsingleton _ ref]
  have hcast2 : (∏ j : {j : Fin P // ¬j ≤ i}, phaseRetainedMass b q J j (samples j)) =
      (∏ j : {j : Fin P // i < j}, phaseRetainedMass b q J j (samples j)) := by
    let eqv : {j : Fin P // ¬j ≤ i} ≃ {j : Fin P // i < j} :=
      { toFun := fun j => ⟨j, lt_of_not_ge j.property⟩
        invFun := fun j => ⟨j, not_le_of_gt j.property⟩
        left_inv := fun _ => rfl
        right_inv := fun _ => rfl }
    exact eqv.prod_comp (fun j => phaseRetainedMass b q J j.val (samples j.val))
  rw [hcast2]

/-- Once the exposed prefix and all earlier samples are fixed, the
earlier likelihood factor stays the same for every tuple completion.
Only the future kernel may depend on the unexposed coordinates. -/
theorem phaseSampleLaw_fixed_prefix (b : BlueprintExpansion N P t H) (q : ℝ)
    (i : Fin P) (J : Fin P → Fin t) (J' : prefixTuples i J)
    (samples : Fin P → PhaseSample N) :
    (∏ j, phaseRetainedMass b q J' j (samples j)) =
      (∏ j : {j : Fin P // j < i}, phaseRetainedMass b q J j (samples j)) *
        phaseRetainedMass b q J i (samples i) *
      (∏ j : {j : Fin P // i < j}, phaseRetainedMass b q J' j (samples j)) := by
  rw [phaseSampleLaw_factor_at]
  congr 1
  rw [phaseRetainedMass_prefix b q i J J' i le_rfl]
  congr 1
  apply Finset.prod_congr rfl
  intro j _
  rw [phaseRetainedMass_prefix b q i J J' j j.property.le]

/-- The tuple-dependent future probability is a normalized kernel. -/
theorem futurePhaseMass_total (b : BlueprintExpansion N P t H) (q : ℝ)
    (hq0 : 0 ≤ q) (hq1 : q ≤ 1) (J : Fin P → Fin t) (i : Fin P) :
    (∑ S : { j : Fin P // i < j } → PhaseSample N,
      ∏ j : { j : Fin P // i < j }, phaseRetainedMass b q J j (S j)) = 1 := by
  rw [← Fintype.prod_sum]
  simp only [phaseRetainedMass_total b q hq0 hq1, Finset.prod_const_one]

end

end SubmodularMatching.LowerBoundGlobal
