import SubmodularMatching.MatchingCover
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic.FieldSimp

/-!
# The finite, piecewise-linear endpoint-potential update

`idealUpdate` processes rate intervals in decreasing index order. A clipped
boundary time skips intervals above the initial ratio and uses only the
remaining length when a boundary is not reached. The final rate pair is the
paper's first interval. Complete endpoint increments are rounded upward once.
-/

namespace SubmodularMatching.Streaming

/-- Endpoint potentials, with labels fixed during one update. -/
structure PotentialPair where
  high : ℝ
  low : ℝ

/-- One rate interval and its lower ratio boundary. -/
structure PotentialStage where
  highRate : ℝ
  lowRate : ℝ
  boundary : ℝ

/-- Advance at one fixed pair of rates. -/
def advancePotential (P : PotentialPair) (r : PotentialStage) (t : ℝ) : PotentialPair :=
  ⟨P.high + r.highRate * t, P.low + r.lowRate * t⟩

/-- The exact time needed to reach the lower interval boundary. -/
noncomputable def boundaryTime (P : PotentialPair) (r : PotentialStage) : ℝ :=
  (P.high - r.boundary * (P.high + P.low)) /
    (r.boundary * (r.highRate + r.lowRate) - r.highRate)

/-- The nonnegative time spent in this interval, capped by the remaining time. -/
noncomputable def stageTime (P : PotentialPair) (r : PotentialStage) (t : ℝ) : ℝ :=
  min t (max 0 (boundaryTime P r))

/-- Finite descending-interval update. All boundary operations precede rounding. -/
noncomputable def idealUpdate (base : PotentialStage) :
    List PotentialStage → PotentialPair → ℝ → PotentialPair
  | [], P, t => advancePotential P base t
  | r :: rs, P, t =>
      let u := stageTime P r t
      idealUpdate base rs (advancePotential P r u) (t - u)

/-- Clipping keeps every stage duration within its available budget. -/
theorem stageTime_bounds (P : PotentialPair) (r : PotentialStage) (t : ℝ) (ht : 0 ≤ t) :
    0 ≤ stageTime P r t ∧ stageTime P r t ≤ t := by
  exact ⟨le_min ht (le_max_left _ _), min_le_left _ _⟩

/-- The exact boundary time is positive for an interior point under (SP0). -/
theorem boundaryTime_pos (P : PotentialPair) (r : PotentialStage)
    (hinterior : r.boundary * (P.high + P.low) < P.high)
    (hdrift : r.highRate < r.boundary * (r.highRate + r.lowRate)) :
    0 < boundaryTime P r := by
  exact div_pos (sub_pos.mpr hinterior) (sub_pos.mpr hdrift)

/-- The computed time reaches the stated boundary exactly. -/
theorem boundaryTime_hits (P : PotentialPair) (r : PotentialStage)
    (hdrift : r.highRate < r.boundary * (r.highRate + r.lowRate)) :
    (advancePotential P r (boundaryTime P r)).high = r.boundary *
      ((advancePotential P r (boundaryTime P r)).high +
        (advancePotential P r (boundaryTime P r)).low) := by
  have hd : r.boundary * (r.highRate + r.lowRate) - r.highRate ≠ 0 :=
    ne_of_gt (sub_pos.mpr hdrift)
  unfold advancePotential boundaryTime
  dsimp
  field_simp
  ring

/-- If each interval's two rates lie in the stated ranges, the complete
recursive update has the same integrated bounds. -/
theorem idealUpdate_bounds
    (base : PotentialStage) (rs : List PotentialStage)
    (amin bmin amax : ℝ)
    (hb : amin ≤ base.highRate ∧ base.highRate ≤ amax ∧
      bmin ≤ base.lowRate ∧ base.lowRate ≤ amax)
    (hrs : ∀ r ∈ rs, amin ≤ r.highRate ∧ r.highRate ≤ amax ∧
      bmin ≤ r.lowRate ∧ r.lowRate ≤ amax)
    (P : PotentialPair) (t : ℝ) (ht : 0 ≤ t) :
    P.high + amin * t ≤ (idealUpdate base rs P t).high ∧
    (idealUpdate base rs P t).high ≤ P.high + amax * t ∧
    P.low + bmin * t ≤ (idealUpdate base rs P t).low ∧
    (idealUpdate base rs P t).low ≤ P.low + amax * t := by
  induction rs generalizing P t with
  | nil =>
      dsimp [idealUpdate, advancePotential]
      exact ⟨add_le_add le_rfl (mul_le_mul_of_nonneg_right hb.1 ht),
        add_le_add le_rfl (mul_le_mul_of_nonneg_right hb.2.1 ht),
        add_le_add le_rfl (mul_le_mul_of_nonneg_right hb.2.2.1 ht),
        add_le_add le_rfl (mul_le_mul_of_nonneg_right hb.2.2.2 ht)⟩
  | cons r rs ih =>
      obtain ⟨hu0, hut⟩ := stageTime_bounds P r t ht
      have hr := hrs r (List.mem_cons_self ..)
      have htail : ∀ q ∈ rs, amin ≤ q.highRate ∧ q.highRate ≤ amax ∧
          bmin ≤ q.lowRate ∧ q.lowRate ≤ amax :=
        fun q hq => hrs q (List.mem_cons_of_mem _ hq)
      have hi := ih htail (advancePotential P r (stageTime P r t))
        (t - stageTime P r t) (sub_nonneg.mpr hut)
      dsimp [idealUpdate, advancePotential] at hi ⊢
      have h1 := mul_le_mul_of_nonneg_right hr.1 hu0
      have h2 := mul_le_mul_of_nonneg_right hr.2.1 hu0
      have h3 := mul_le_mul_of_nonneg_right hr.2.2.1 hu0
      have h4 := mul_le_mul_of_nonneg_right hr.2.2.2 hu0
      constructor
      · nlinarith [hi.1]
      constructor
      · nlinarith [hi.2.1]
      constructor
      · nlinarith [hi.2.2.1]
      · nlinarith [hi.2.2.2]

/-- Larger-endpoint labels remain valid throughout every rate stage. -/
theorem idealUpdate_preserves_order (base : PotentialStage) (rs : List PotentialStage)
    (hb : base.lowRate ≤ base.highRate)
    (hrs : ∀ r ∈ rs, r.lowRate ≤ r.highRate)
    (P : PotentialPair) (hP : P.low ≤ P.high) (t : ℝ) (ht : 0 ≤ t) :
    (idealUpdate base rs P t).low ≤ (idealUpdate base rs P t).high := by
  induction rs generalizing P t with
  | nil =>
      exact add_le_add hP (mul_le_mul_of_nonneg_right hb ht)
  | cons r rs ih =>
      obtain ⟨hu0, hut⟩ := stageTime_bounds P r t ht
      apply ih (fun q hq => hrs q (List.mem_cons_of_mem _ hq))
      · exact add_le_add hP (mul_le_mul_of_nonneg_right (hrs r (List.mem_cons_self ..)) hu0)
      · exact sub_nonneg.mpr hut

/-- Upward rounding to a positive grid. -/
noncomputable def roundUp (grid amount : ℝ) : ℝ := grid * (⌈amount / grid⌉ : ℤ)

/-- Upward rounding never loses value and adds strictly less than one grid step. -/
theorem roundUp_bounds (grid amount : ℝ) (hg : 0 < grid) :
    amount ≤ roundUp grid amount ∧ roundUp grid amount < amount + grid := by
  have hlo := Int.le_ceil (amount / grid)
  have hhi := Int.ceil_lt_add_one (amount / grid)
  constructor
  · have h := mul_le_mul_of_nonneg_left hlo hg.le
    simpa [roundUp, hg.ne', mul_div_cancel₀] using h
  · have h := mul_lt_mul_of_pos_left hhi hg
    simpa [roundUp, mul_add, hg.ne', mul_div_cancel₀] using h

/-- Round each complete ideal endpoint increment exactly once. -/
noncomputable def roundedUpdate (base : PotentialStage) (rs : List PotentialStage)
    (P : PotentialPair) (t grid : ℝ) : PotentialPair :=
  let Q := idealUpdate base rs P t
  ⟨P.high + roundUp grid (Q.high - P.high),
    P.low + roundUp grid (Q.low - P.low)⟩

/-- The rounded update is above the exact one and less than one grid step above it. -/
theorem roundedUpdate_bounds (base : PotentialStage) (rs : List PotentialStage)
    (P : PotentialPair) (t grid : ℝ) (hg : 0 < grid) :
    (idealUpdate base rs P t).high ≤ (roundedUpdate base rs P t grid).high ∧
    (roundedUpdate base rs P t grid).high < (idealUpdate base rs P t).high + grid ∧
    (idealUpdate base rs P t).low ≤ (roundedUpdate base rs P t grid).low ∧
    (roundedUpdate base rs P t grid).low < (idealUpdate base rs P t).low + grid := by
  have hH := roundUp_bounds grid ((idealUpdate base rs P t).high - P.high) hg
  have hL := roundUp_bounds grid ((idealUpdate base rs P t).low - P.low) hg
  dsimp [roundedUpdate]
  constructor
  · linarith [hH.1]
  constructor
  · linarith [hH.2]
  constructor
  · linarith [hL.1]
  · linarith [hL.2]

/-- Symbolic input conditions for the streaming potential routine. These are
rate and arithmetic hypotheses; none is a growth or storage conclusion. -/
structure PotentialConfig where
  base : PotentialStage
  stages : List PotentialStage
  p : ℝ
  theta : ℝ
  gap : ℝ
  grid : ℝ
  tau : ℝ
  minHigh : ℝ
  minLow : ℝ
  maxRate : ℝ
  kappa : ℝ
  p_pos : 0 < p
  theta_pos : 0 < theta
  theta_le_tau : theta ≤ tau
  gap_nonneg : 0 ≤ gap
  grid_pos : 0 < grid
  grid_le : grid ≤ p * tau
  minLow_pos : 0 < minLow
  minLow_le_minHigh : minLow ≤ minHigh
  kappa_pos : 0 < kappa
  kappa_le_high : kappa ≤ minHigh
  kappa_le_low : kappa ≤ 2 * minLow
  growth_le_one : kappa * p ≤ 1
  base_bounds : minHigh ≤ base.highRate ∧ base.highRate ≤ maxRate ∧
    minLow ≤ base.lowRate ∧ base.lowRate ≤ maxRate
  stage_bounds : ∀ r ∈ stages, minHigh ≤ r.highRate ∧ r.highRate ≤ maxRate ∧
    minLow ≤ r.lowRate ∧ r.lowRate ≤ maxRate

/-- First positive potential guaranteed by one accepted incidence. -/
def PotentialConfig.seed (C : PotentialConfig) : ℝ := C.minLow * C.p * C.theta

/-- Multiplicative factor guaranteed by every subsequent accepted incidence. -/
def PotentialConfig.factor (C : PotentialConfig) : ℝ := 1 + C.kappa * C.p

/-- Uniform upper bound on every potential in one fixed-guess instance. -/
def PotentialConfig.cap (C : PotentialConfig) : ℝ := (1 + (C.maxRate + 1) * C.p) * C.tau

theorem PotentialConfig.seed_pos (C : PotentialConfig) : 0 < C.seed :=
  mul_pos (mul_pos C.minLow_pos C.p_pos) C.theta_pos

theorem PotentialConfig.factor_gt_one (C : PotentialConfig) : 1 < C.factor := by
  dsimp [PotentialConfig.factor]
  linarith [mul_pos C.kappa_pos C.p_pos]

/-- One accepted, ordered endpoint update: both endpoints grow by the stated
factor, acquire the positive seed, and remain under the uniform cap. -/
theorem roundedUpdate_accepted_bounds (C : PotentialConfig) (P : PotentialPair) (w : ℝ)
    (hH : 0 ≤ P.high) (hL : 0 ≤ P.low) (horder : P.low ≤ P.high)
    (hseed : C.theta ≤ w) (haccept : P.high + P.low + C.gap ≤ w)
    (hweight : w ≤ C.tau) :
    let Q := roundedUpdate C.base C.stages P (C.p * w) C.grid
    C.factor * P.high ≤ Q.high ∧ C.factor * P.low ≤ Q.low ∧
    C.seed ≤ Q.high ∧ C.seed ≤ Q.low ∧ Q.high ≤ C.cap ∧ Q.low ≤ C.cap := by
  have hw : 0 ≤ w := C.theta_pos.le.trans hseed
  have hminH : 0 ≤ C.minHigh := C.minLow_pos.le.trans C.minLow_le_minHigh
  have hmax : 0 ≤ C.maxRate := C.minLow_pos.le.trans
    (C.base_bounds.2.2.1.trans C.base_bounds.2.2.2)
  have hHle : P.high ≤ w := by linarith [C.gap_nonneg]
  have hLle : P.low ≤ w := by linarith [C.gap_nonneg]
  have htwoL : 2 * P.low ≤ w := by linarith [C.gap_nonneg]
  have hb := idealUpdate_bounds C.base C.stages C.minHigh C.minLow C.maxRate
    C.base_bounds C.stage_bounds P (C.p * w) (mul_nonneg C.p_pos.le hw)
  have hr := roundedUpdate_bounds C.base C.stages P (C.p * w) C.grid C.grid_pos
  have hhighGrow := mul_le_mul C.kappa_le_high
    (mul_le_mul_of_nonneg_left hHle C.p_pos.le)
    (mul_nonneg C.p_pos.le hH) hminH
  have hlowGrow1 := mul_le_mul_of_nonneg_right C.kappa_le_low (mul_nonneg C.p_pos.le hL)
  have hlowGrow2 := mul_le_mul_of_nonneg_left htwoL (mul_nonneg C.minLow_pos.le C.p_pos.le)
  have hseedLow := mul_le_mul_of_nonneg_left hseed (mul_nonneg C.minLow_pos.le C.p_pos.le)
  have hseedHigh := mul_le_mul_of_nonneg_right C.minLow_le_minHigh (mul_nonneg C.p_pos.le hw)
  have hupper := mul_le_mul_of_nonneg_left hweight (mul_nonneg hmax C.p_pos.le)
  dsimp [PotentialConfig.factor, PotentialConfig.seed, PotentialConfig.cap]
  constructor
  · nlinarith [hb.1, hr.1]
  constructor
  · nlinarith [hb.2.2.1, hr.2.2.1]
  constructor
  · nlinarith [hb.1, hr.1]
  constructor
  · nlinarith [hb.2.2.1, hr.2.2.1]
  constructor
  · nlinarith [hb.2.1, hr.2.1, C.grid_le]
  · nlinarith [hb.2.2.2, hr.2.2.2, C.grid_le]

/-- Swap endpoint labels. -/
def PotentialPair.swap (P : PotentialPair) : PotentialPair := ⟨P.low, P.high⟩

/-- The routine sorts the two endpoint potentials, keeps labels fixed inside
an update, and restores the original order afterward. -/
noncomputable def updateUnordered (C : PotentialConfig)
    (P : PotentialPair) (w : ℝ) : PotentialPair :=
  if P.low ≤ P.high then roundedUpdate C.base C.stages P (C.p * w) C.grid
  else (roundedUpdate C.base C.stages P.swap (C.p * w) C.grid).swap

/-- Actual sorting-and-rounding step satisfies both endpoint bounds. -/
theorem updateUnordered_accepted_bounds (C : PotentialConfig) (P : PotentialPair) (w : ℝ)
    (hH : 0 ≤ P.high) (hL : 0 ≤ P.low)
    (hseed : C.theta ≤ w) (haccept : P.high + P.low + C.gap ≤ w)
    (hweight : w ≤ C.tau) :
    let Q := updateUnordered C P w
    C.factor * P.high ≤ Q.high ∧ C.factor * P.low ≤ Q.low ∧
    C.seed ≤ Q.high ∧ C.seed ≤ Q.low ∧ Q.high ≤ C.cap ∧ Q.low ≤ C.cap := by
  unfold updateUnordered
  split_ifs with horder
  · exact roundedUpdate_accepted_bounds C P w hH hL horder hseed haccept hweight
  · have hswap : P.swap.high + P.swap.low + C.gap ≤ w := by
      simpa only [PotentialPair.swap, add_comm] using haccept
    have h := roundedUpdate_accepted_bounds C P.swap w hL hH
      (le_of_not_ge horder) hseed hswap hweight
    exact ⟨h.2.1, h.1, h.2.2.2.1, h.2.2.1, h.2.2.2.2.2, h.2.2.2.2.1⟩

end SubmodularMatching.Streaming
