import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step48 : ProjectedGoal ⟨540, 546, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0x21c021ce8d4a5100004800a) (.leaf 0x21d021de8d4a5100004800a)) (.m (.leaf 0x21e021ee8d4a5100004800a) (.leaf 0x21f021fe8d4a5100004800a))) (.x (.x (.leaf 0x2220220e8d4a51000048049) (.x (.leaf 0x2220220e8d4a5100004804a) (.x (.leaf 0x2220220e8d4a5100004804b) (.x (.x (.leaf 0x2220220e8d4a51000048050) (.x (.y (.y (.leaf 0x2220220e8d4a51000049051) (.y (.leaf 0x2220220e8d4a5100004a051) (.y (.leaf 0x2220220e8d4a5100004b051) (.y (.m (.m (.leaf 0x2200220e8d4a5100004c051) (.leaf 0x2210221e8d4a5100004c051)) (.leaf 0x2220222e8d4a5100004c051)) (.leaf 0x2220220e8d4a5100004d051))))) (.leaf 0x2220220e8d4a5100004e051)) (.leaf 0x2220220e8d4a51000048052))) (.leaf 0x2220220e8d4a5100004804d))))) (.leaf 0x2220220e8d4a5100004804e))) (by decide +kernel)

private theorem step49 : ProjectedGoal ⟨547, 550, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x2240223e8d4a51000048049) (.x (.leaf 0x2240223e8d4a5100004804a) (.x (.leaf 0x2240223e8d4a5100004804b) (.x (.x (.leaf 0x2240223e8d4a51000048050) (.x (.y (.y (.leaf 0x2240223e8d4a51000049051) (.y (.leaf 0x2240223e8d4a5100004a051) (.y (.leaf 0x2240223e8d4a5100004b051) (.y (.m (.leaf 0x2230223e8d4a5100004c051) (.leaf 0x2240224e8d4a5100004c051)) (.leaf 0x2240223e8d4a5100004d051))))) (.leaf 0x2240223e8d4a5100004e051)) (.leaf 0x2240223e8d4a51000048052))) (.leaf 0x2240223e8d4a5100004804d))))) (.leaf 0x2240223e8d4a5100004804e)) (.x (.x (.leaf 0x2260225e8d4a51000048049) (.x (.leaf 0x2260225e8d4a5100004804a) (.x (.leaf 0x2260225e8d4a5100004804b) (.x (.x (.leaf 0x2260225e8d4a51000048050) (.x (.y (.y (.leaf 0x2260225e8d4a51000049051) (.y (.leaf 0x2260225e8d4a5100004a051) (.y (.leaf 0x2260225e8d4a5100004b051) (.y (.m (.leaf 0x2250225e8d4a5100004c051) (.leaf 0x2260226e8d4a5100004c051)) (.leaf 0x2260225e8d4a5100004d051))))) (.leaf 0x2260225e8d4a5100004e051)) (.leaf 0x2260225e8d4a51000048052))) (.leaf 0x2260225e8d4a5100004804d))))) (.leaf 0x2260225e8d4a5100004804e))) (by decide +kernel)

private theorem step50 : ProjectedGoal ⟨551, 553, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x2280227e8d4a51000048049) (.x (.leaf 0x2280227e8d4a5100004804a) (.x (.leaf 0x2280227e8d4a5100004804b) (.x (.x (.leaf 0x2280227e8d4a51000048050) (.x (.y (.y (.leaf 0x2280227e8d4a51000049051) (.y (.leaf 0x2280227e8d4a5100004a051) (.y (.leaf 0x2280227e8d4a5100004b051) (.y (.m (.leaf 0x2270227e8d4a5100004c051) (.leaf 0x2280228e8d4a5100004c051)) (.leaf 0x2280227e8d4a5100004d051))))) (.leaf 0x2280227e8d4a5100004e051)) (.leaf 0x2280227e8d4a51000048052))) (.leaf 0x2280227e8d4a5100004804d))))) (.leaf 0x2280227e8d4a5100004804e)) (.leaf 0x2290229e8d4a5100004800a)) (by decide +kernel)

private theorem step51 : ProjectedGoal ⟨547, 553, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 550 (by decide) (by decide) (step49 rates cones) (step50 rates cones)

private theorem step52 : ProjectedGoal ⟨540, 553, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 546 (by decide) (by decide) (step48 rates cones) (step51 rates cones)

private theorem step53 : ProjectedGoal ⟨554, 560, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0x22a022ae8d4a5100004800a) (.leaf 0x22b022be8d4a5100004800a)) (.m (.leaf 0x22c022ce8d4a5100004800a) (.leaf 0x22d022de8d4a5100004800a))) (.x (.x (.leaf 0x230022ee8d4a51000048049) (.x (.leaf 0x230022ee8d4a5100004804a) (.x (.leaf 0x230022ee8d4a5100004804b) (.x (.x (.leaf 0x230022ee8d4a51000048050) (.x (.y (.y (.leaf 0x230022ee8d4a51000049051) (.y (.leaf 0x230022ee8d4a5100004a051) (.y (.leaf 0x230022ee8d4a5100004b051) (.y (.m (.m (.leaf 0x22e022ee8d4a5100004c051) (.leaf 0x22f022fe8d4a5100004c051)) (.leaf 0x2300230e8d4a5100004c051)) (.leaf 0x230022ee8d4a5100004d051))))) (.leaf 0x230022ee8d4a5100004e051)) (.leaf 0x230022ee8d4a51000048052))) (.leaf 0x230022ee8d4a5100004804d))))) (.leaf 0x230022ee8d4a5100004804e))) (by decide +kernel)

private theorem step54 : ProjectedGoal ⟨561, 563, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.x (.x (.leaf 0x2320231e8d4a51000048049) (.x (.leaf 0x2320231e8d4a5100004804a) (.x (.leaf 0x2320231e8d4a5100004804b) (.x (.x (.leaf 0x2320231e8d4a51000048050) (.x (.y (.y (.leaf 0x2320231e8d4a51000049051) (.y (.leaf 0x2320231e8d4a5100004a051) (.y (.leaf 0x2320231e8d4a5100004b051) (.y (.m (.leaf 0x2310231e8d4a5100004c051) (.leaf 0x2320232e8d4a5100004c051)) (.leaf 0x2320231e8d4a5100004d051))))) (.leaf 0x2320231e8d4a5100004e051)) (.leaf 0x2320231e8d4a51000048052))) (.leaf 0x2320231e8d4a5100004804d))))) (.leaf 0x2320231e8d4a5100004804e)) (.leaf 0x2330233e8d4a5100004800a)) (by decide +kernel)

private theorem step55 : ProjectedGoal ⟨564, 566, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.x (.x (.leaf 0x2360234e8d4a51000048049) (.x (.leaf 0x2360234e8d4a5100004804a) (.x (.leaf 0x2360234e8d4a5100004804b) (.x (.x (.leaf 0x2360234e8d4a51000048050) (.x (.y (.y (.leaf 0x2360234e8d4a51000049051) (.y (.leaf 0x2360234e8d4a5100004a051) (.y (.leaf 0x2360234e8d4a5100004b051) (.y (.m (.m (.leaf 0x2340234e8d4a5100004c051) (.leaf 0x2350235e8d4a5100004c051)) (.leaf 0x2360236e8d4a5100004c051)) (.leaf 0x2360234e8d4a5100004d051))))) (.leaf 0x2360234e8d4a5100004e051)) (.leaf 0x2360234e8d4a51000048052))) (.leaf 0x2360234e8d4a5100004804d))))) (.leaf 0x2360234e8d4a5100004804e)) (by decide +kernel)

private theorem step56 : ProjectedGoal ⟨561, 566, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 563 (by decide) (by decide) (step54 rates cones) (step55 rates cones)

private theorem step57 : ProjectedGoal ⟨554, 566, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 560 (by decide) (by decide) (step53 rates cones) (step56 rates cones)

private theorem step58 : ProjectedGoal ⟨540, 566, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 553 (by decide) (by decide) (step52 rates cones) (step57 rates cones)

theorem Part00004 : ProjectedGoal ⟨540, 566, 0, 283, 0, 283⟩ := step58

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
