import SubmodularMatching.LowerBoundGlobalExperiment

/-! # Splitting a base draw into the exposed history and the continuation -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

variable {N P t H : ℕ}

abbrev BeforePhase (i : Fin P) := { j : Fin P // j < i }
abbrev AfterPhase (i : Fin P) := { j : Fin P // i < j }
abbrev UnexposedPhase (i : Fin P) := { j : Fin P // ¬j < i }

abbrev PhaseHistory (N t : ℕ) (i : Fin P) :=
  (BeforePhase i → Fin t) × (BeforePhase i → PhaseSample N)

abbrev PhaseFuture (N t : ℕ) (i : Fin P) :=
  (UnexposedPhase i → Fin t) × (AfterPhase i → PhaseSample N)

def mergeTuple (i : Fin P) (earlier : BeforePhase i → Fin t)
    (later : UnexposedPhase i → Fin t) : Fin P → Fin t :=
  (Equiv.piEquivPiSubtypeProd (fun j => j < i) (fun _ => Fin t)).symm (earlier, later)

@[simp] theorem mergeTuple_before (i : Fin P) (earlier : BeforePhase i → Fin t)
    (later : UnexposedPhase i → Fin t) (j : BeforePhase i) :
    mergeTuple i earlier later j = earlier j := by
  simp [mergeTuple, Equiv.piEquivPiSubtypeProd, j.property]

@[simp] theorem mergeTuple_unexposed (i : Fin P) (earlier : BeforePhase i → Fin t)
    (later : UnexposedPhase i → Fin t) (j : UnexposedPhase i) :
    mergeTuple i earlier later j = later j := by
  simp [mergeTuple, Equiv.piEquivPiSubtypeProd, j.property]

def representative (i : Fin P) (earlier : BeforePhase i → Fin t) [Nonempty (Fin t)] :
    Fin P → Fin t :=
  mergeTuple i earlier (fun _ => Classical.choice inferInstance)

theorem mergeTuple_mem_prefix (i : Fin P) (earlier : BeforePhase i → Fin t) [Nonempty (Fin t)]
    (later : UnexposedPhase i → Fin t) :
    mergeTuple i earlier later ∈ prefixTuples i (representative i earlier) := by
  apply Finset.mem_filter.mpr
  refine ⟨Finset.mem_univ _, fun j hj => ?_⟩
  rw [representative]
  exact (mergeTuple_before i earlier later ⟨j, hj⟩).trans
    (mergeTuple_before i earlier _ ⟨j, hj⟩).symm

/-- Forgetting the exposed coordinates maps the prefix fiber bijectively
to the independent unseen tuple coordinates. -/
def unexposedTupleEquiv (i : Fin P) (earlier : BeforePhase i → Fin t) [Nonempty (Fin t)] :
    (UnexposedPhase i → Fin t) ≃ prefixTuples i (representative i earlier) where
  toFun later := ⟨mergeTuple i earlier later, mergeTuple_mem_prefix i earlier later⟩
  invFun J j := J.val j
  left_inv := by intro later; funext j; exact mergeTuple_unexposed i earlier later j
  right_inv := by
    intro J
    apply Subtype.ext
    funext j
    by_cases hj : j < i
    · exact (mergeTuple_before i earlier _ ⟨j, hj⟩).trans
        ((Finset.mem_filter.mp J.property).2 j hj |>.trans
          (mergeTuple_before i earlier _ ⟨j, hj⟩)).symm
    · exact mergeTuple_unexposed i earlier _ ⟨j, hj⟩

theorem unexposedTuple_card (i : Fin P) (earlier : BeforePhase i → Fin t) [Nonempty (Fin t)] :
    Fintype.card (UnexposedPhase i → Fin t) = (prefixTuples i (representative i earlier)).card := by
  simpa using Fintype.card_congr (unexposedTupleEquiv i earlier)

theorem fullTuple_card_factor (i : Fin P) :
    Fintype.card (Fin P → Fin t) =
      Fintype.card (BeforePhase i → Fin t) * Fintype.card (UnexposedPhase i → Fin t) := by
  simpa only [Fintype.card_prod] using
    Fintype.card_congr (Equiv.piEquivPiSubtypeProd (fun j => j < i) (fun _ => Fin t))

def mergePhaseSamples (i : Fin P) (earlier : BeforePhase i → PhaseSample N)
    (S : PhaseSample N) (later : AfterPhase i → PhaseSample N) (j : Fin P) : PhaseSample N :=
  if hj : j < i then earlier ⟨j, hj⟩ else if hi : i < j then later ⟨j, hi⟩ else S

@[simp] theorem mergePhaseSamples_before (i : Fin P) (earlier : BeforePhase i → PhaseSample N)
    (S : PhaseSample N) (later : AfterPhase i → PhaseSample N) (j : BeforePhase i) :
    mergePhaseSamples i earlier S later j = earlier j := by
  simp [mergePhaseSamples, j.property]

@[simp] theorem mergePhaseSamples_at (i : Fin P) (earlier : BeforePhase i → PhaseSample N)
    (S : PhaseSample N) (later : AfterPhase i → PhaseSample N) :
    mergePhaseSamples i earlier S later i = S := by simp [mergePhaseSamples]

@[simp] theorem mergePhaseSamples_after (i : Fin P) (earlier : BeforePhase i → PhaseSample N)
    (S : PhaseSample N) (later : AfterPhase i → PhaseSample N) (j : AfterPhase i) :
    mergePhaseSamples i earlier S later j = later j := by
  simp [mergePhaseSamples, j.property, not_lt_of_ge j.property.le]

/-- The finite sample space at a phase boundary. The past contains only
tuple coordinates before the phase, with the corresponding prior samples. -/
def phaseDrawEquiv (i : Fin P) :
    BaseDraw N P t ≃ PhaseHistory N t i × (PhaseSample N × PhaseFuture N t i) where
  toFun draw :=
    ((fun j => draw.1 j, fun j => draw.2 j),
      draw.2 i, (fun j => draw.1 j, fun j => draw.2 j))
  invFun values :=
    (mergeTuple i values.1.1 values.2.2.1,
      mergePhaseSamples i values.1.2 values.2.1 values.2.2.2)
  left_inv := by
    intro draw
    apply Prod.ext
    · exact (Equiv.piEquivPiSubtypeProd (fun j => j < i) (fun _ => Fin t)).symm_apply_apply draw.1
    · funext j
      by_cases hj : j < i
      · exact mergePhaseSamples_before i _ _ _ ⟨j, hj⟩
      · by_cases hi : i < j
        · exact mergePhaseSamples_after i _ _ _ ⟨j, hi⟩
        · have he : j = i := le_antisymm (le_of_not_gt hi) (le_of_not_gt hj)
          subst j
          exact mergePhaseSamples_at i _ _ _
  right_inv := by
    rintro ⟨⟨pastTuple, pastSamples⟩, sample, nextTuple, nextSamples⟩
    simp only [Prod.mk.injEq]
    exact ⟨⟨funext (mergeTuple_before i pastTuple nextTuple),
      funext (mergePhaseSamples_before i pastSamples sample nextSamples)⟩,
      mergePhaseSamples_at i pastSamples sample nextSamples,
      funext (mergeTuple_unexposed i pastTuple nextTuple),
      funext (mergePhaseSamples_after i pastSamples sample nextSamples)⟩

def pastPhaseLaw [Nonempty (Fin t)] (b : BlueprintExpansion N P t H) (q : ℝ)
    (i : Fin P) (past : PhaseHistory N t i) : ℝ :=
  (1 / (Fintype.card (BeforePhase i → Fin t) : ℝ)) *
    ∏ j : BeforePhase i, phaseRetainedMass b q (representative i past.1) j (past.2 j)

def nextPhaseLaw (b : BlueprintExpansion N P t H) (q : ℝ)
    (i : Fin P) (pastTuple : BeforePhase i → Fin t) (next : PhaseFuture N t i) : ℝ :=
  (1 / (Fintype.card (UnexposedPhase i → Fin t) : ℝ)) *
    ∏ j : AfterPhase i, phaseRetainedMass b q (mergeTuple i pastTuple next.1) j (next.2 j)

theorem pastPhaseLaw_nonneg [Nonempty (Fin t)] (b : BlueprintExpansion N P t H) (q : ℝ)
    (i : Fin P) (past : PhaseHistory N t i) :
    0 ≤ pastPhaseLaw b q i past :=
  mul_nonneg (by positivity) (Finset.prod_nonneg fun _ _ => uniformSubsetMass_nonneg _ _ _)

theorem nextPhaseLaw_nonneg (b : BlueprintExpansion N P t H) (q : ℝ)
    (i : Fin P) (pastTuple : BeforePhase i → Fin t) (next : PhaseFuture N t i) :
    0 ≤ nextPhaseLaw b q i pastTuple next :=
  mul_nonneg (by positivity) (Finset.prod_nonneg fun _ _ => uniformSubsetMass_nonneg _ _ _)

theorem pastPhaseLaw_total [Nonempty (Fin t)] (b : BlueprintExpansion N P t H) (q : ℝ)
    (hq0 : 0 ≤ q) (hq1 : q ≤ 1) (i : Fin P) : ∑ past, pastPhaseLaw b q i past = 1 := by
  rw [Fintype.sum_prod_type]
  calc
    _ = ∑ _A : BeforePhase i → Fin t, 1 / (Fintype.card (BeforePhase i → Fin t) : ℝ) := by
      apply Finset.sum_congr rfl
      intro A _
      simp only [pastPhaseLaw, ← Finset.mul_sum]
      rw [← Fintype.prod_sum]
      simp [phaseRetainedMass_total b q hq0 hq1]
    _ = _ := by rw [Finset.sum_const, nsmul_eq_mul, Finset.card_univ]; field_simp

theorem nextPhaseLaw_total [Nonempty (Fin t)] (b : BlueprintExpansion N P t H) (q : ℝ)
    (hq0 : 0 ≤ q) (hq1 : q ≤ 1) (i : Fin P) (pastTuple : BeforePhase i → Fin t) :
    ∑ next, nextPhaseLaw b q i pastTuple next = 1 := by
  rw [Fintype.sum_prod_type]
  calc
    _ = ∑ _A : UnexposedPhase i → Fin t, 1 / (Fintype.card (UnexposedPhase i → Fin t) : ℝ) := by
      apply Finset.sum_congr rfl
      intro A _
      simp only [nextPhaseLaw, ← Finset.mul_sum]
      rw [← Fintype.prod_sum]
      simp [phaseRetainedMass_total b q hq0 hq1]
    _ = _ := by rw [Finset.sum_const, nsmul_eq_mul, Finset.card_univ]; field_simp

/-- The actual joint mass factors exactly in the coordinates available at
the phase boundary. In particular no independence of the future phase
samples from the full hidden tuple is assumed. -/
theorem baseDrawMass_factor [Nonempty (Fin t)] (b : BlueprintExpansion N P t H) (q : ℝ)
    (i : Fin P) (past : PhaseHistory N t i) (S : PhaseSample N) (next : PhaseFuture N t i) :
    baseDrawMass b q ((phaseDrawEquiv i).symm (past, S, next)) =
      pastPhaseLaw b q i past *
        phaseRetainedMass b q (representative i past.1) i S *
        nextPhaseLaw b q i past.1 next := by
  let J' : prefixTuples i (representative i past.1) := unexposedTupleEquiv i past.1 next.1
  change (1 / (Fintype.card (Fin P → Fin t) : ℝ)) *
      (∏ j, phaseRetainedMass b q J' j (mergePhaseSamples i past.2 S next.2 j)) = _
  rw [phaseSampleLaw_fixed_prefix b q i (representative i past.1) J']
  simp only [mergePhaseSamples_at, mergePhaseSamples_before, mergePhaseSamples_after,
    pastPhaseLaw, nextPhaseLaw, fullTuple_card_factor i, Nat.cast_mul, div_mul_eq_mul_div,
    one_mul]
  field_simp; rfl

theorem pastPhaseLaw_pos [Nonempty (Fin t)] (b : BlueprintExpansion N P t H) (q : ℝ)
    (i : Fin P) (past : PhaseHistory N t i) (h : 0 < pastPhaseLaw b q i past)
    (j : BeforePhase i) :
    0 < phaseRetainedMass b q (representative i past.1) j (past.2 j) := by
  have hne : ∏ k : BeforePhase i, phaseRetainedMass b q (representative i past.1) k
      (past.2 k) ≠ 0 := by
    intro hzero
    exact (ne_of_gt h) (by simp [pastPhaseLaw, hzero])
  exact lt_of_le_of_ne (uniformSubsetMass_nonneg _ _ _)
    (Finset.prod_ne_zero_iff.mp hne j (Finset.mem_univ _)).symm

theorem nextPhaseLaw_pos (b : BlueprintExpansion N P t H) (q : ℝ)
    (i : Fin P) (pastTuple : BeforePhase i → Fin t) (next : PhaseFuture N t i)
    (h : 0 < nextPhaseLaw b q i pastTuple next) (j : AfterPhase i) :
    0 < phaseRetainedMass b q (mergeTuple i pastTuple next.1) j (next.2 j) := by
  have hne : ∏ k : AfterPhase i, phaseRetainedMass b q (mergeTuple i pastTuple next.1) k
      (next.2 k) ≠ 0 := by
    intro hzero
    exact (ne_of_gt h) (by simp [nextPhaseLaw, hzero])
  exact lt_of_le_of_ne (uniformSubsetMass_nonneg _ _ _)
    (Finset.prod_ne_zero_iff.mp hne j (Finset.mem_univ _)).symm

/-- The probability of a special original pair in the actual continuation
kernel, averaged over all unexposed coordinates and future samples. -/
theorem nextPhaseLaw_rarity [Nonempty (Fin t)] (b : BlueprintExpansion N P t H)
    (q : ℝ) (hq0 : 0 ≤ q) (hq1 : q ≤ 1) (i : Fin P)
    (pastTuple : BeforePhase i → Fin t) (e : Fin N × Fin N) :
    (∑ next : PhaseFuture N t i,
      if e ∈ b.phases (representative i pastTuple) i ∧
        specialBase (b.canonical (mergeTuple i pastTuple next.1)) e then
          nextPhaseLaw b q i pastTuple next else 0) ≤ (P : ℝ) / t := by
  classical
  rw [Fintype.sum_prod_type]
  let J := representative i pastTuple
  let relevant := fun suffix : UnexposedPhase i → Fin t =>
    e ∈ b.phases J i ∧ specialBase (b.canonical (mergeTuple i pastTuple suffix)) e
  let w : ℝ := 1 / (Fintype.card (UnexposedPhase i → Fin t) : ℝ)
  calc
    _ = ∑ suffix : UnexposedPhase i → Fin t, if relevant suffix then w else 0 := by
      apply Finset.sum_congr rfl
      intro suffix _
      change (∑ future : AfterPhase i → PhaseSample N,
        if relevant suffix then nextPhaseLaw b q i pastTuple (suffix, future) else 0) =
        if relevant suffix then w else 0
      by_cases h : relevant suffix
      · simp only [if_pos h, nextPhaseLaw, ← Finset.mul_sum]
        rw [futurePhaseMass_total b q hq0 hq1]
        simp only [mul_one, w]
      · simp only [if_neg h, Finset.sum_const_zero]
    _ = ∑ J' : prefixTuples i J,
        if e ∈ b.phases J i ∧ specialBase (b.canonical J') e then
          1 / ((prefixTuples i J).card : ℝ) else 0 := by
      rw [← (unexposedTupleEquiv i pastTuple).sum_comp]
      simp only [relevant, w, unexposedTuple_card i pastTuple, J, unexposedTupleEquiv]
      rfl
    _ ≤ _ := prefix_rarity_sum b i J e

end

end SubmodularMatching.LowerBoundGlobal
