import SubmodularMatching.NonmonotoneLayersRounding

namespace SubmodularMatching.NonmonotoneLayers

open VarianceBound Information
open scoped BigOperators
variable {E Ω : Type*} [DecidableEq E] [Fintype Ω]

/-- Equation (29) with a per-coordinate grid error, noisy first-stage loss,
and finite Gibbs error, all charged under the same first-stage law. -/
theorem rounding_with_errors (edges : ℕ → E) (n : ℕ) (f : Finset E → ℝ) (hf : IsSubmodular f)
    (hinj : ∀ i < n, ∀ j < n, edges i = edges j → i = j)
    (μ : Ω → ℝ) (hμ : ∀ ω, 0 ≤ μ ω) (htotal : ∑ ω, μ ω = 1)
    (T : Ω → Finset E) (z : Ω → ℕ → ℝ) (wh x : ℕ → ℝ) (value : Ω → ℝ)
    (p ξ G γ Fg η ρ δ : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1) (hξ : 0 ≤ ξ) (hξ1 : ξ ≤ 1)
    (hz : ∀ ω i, i < n → 0 ≤ z ω i ∧ z ω i ≤ p)
    (hw : ∀ i < n, 0 ≤ wh i ∧ wh i ≤ arrivalWeight edges p f i)
    (hlinear : (∑ i ∈ Finset.range n, wh i*x i) ≤ G)
    (halter : ∀ i < n, (1-ξ)*x i - η ≤ finiteMean μ (fun ω => z ω i))
    (hprio : γ*Fg - ρ ≤ finiteMean μ (fun ω => residualValue edges p f n (T ω)))
    (hconditional : ∀ ω, (1-ξ)*bernoulliExpectation edges (z ω) (fun A => f (T ω ∪ A)) n - δ ≤ value ω) :
    (1-ξ)*(f ∅ + (∑ i ∈ Finset.range n, wh i*x i) + γ*Fg - ξ*G) -
      ((1-ξ)*(ρ + η*(∑ i ∈ Finset.range n, wh i)) + δ) ≤ finiteMean μ value := by
  let L := ∑ i ∈ Finset.range n, wh i*x i
  let W := ∑ i ∈ Finset.range n, wh i
  let lin := fun ω => ∑ i ∈ Finset.range n, wh i*z ω i
  let gain := fun ω => residualValue edges p f n (T ω)
  have hex : finiteMean μ lin = ∑ i ∈ Finset.range n, wh i*finiteMean μ (fun ω => z ω i) := by
    unfold lin finiteMean
    simp only [Finset.mul_sum]
    rw [Finset.sum_comm]
    exact Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun ω _ => by ring))
  have hl : (1-ξ)*L - η*W ≤ finiteMean μ lin := by
    rw [hex]
    dsimp only [L,W]
    rw [Finset.mul_sum,Finset.mul_sum,← Finset.sum_sub_distrib]
    apply Finset.sum_le_sum
    intro i hi
    have h := Finset.mem_range.mp hi
    nlinarith only [mul_le_mul_of_nonneg_left (halter i h) (hw i h).1]
  have hpt (ω : Ω) : (1-ξ)*(f ∅+gain ω+lin ω) - δ ≤ value ω := by
    have h := mul_le_mul_of_nonneg_left (signed_history_recovery edges p (z ω) wh f hf hp hp1 n (T ω)
      hinj (hz ω) hw) (sub_nonneg.mpr hξ1)
    exact (sub_le_sub_right h δ).trans (hconditional ω)
  have hav : finiteMean μ (fun ω => (1-ξ)*(f ∅+gain ω+lin ω)-δ) ≤ finiteMean μ value :=
    Finset.sum_le_sum (fun ω _ => mul_le_mul_of_nonneg_left (hpt ω) (hμ ω))
  rw [finiteMean_sub,finiteMean_const_mul,finiteMean_add,finiteMean_add,finiteMean_const μ htotal,
    finiteMean_const μ htotal] at hav
  change L ≤ G at hlinear
  change γ*Fg - ρ ≤ finiteMean μ gain at hprio
  have hinside : f ∅+L+γ*Fg-ξ*G-(ρ+η*W) ≤ f ∅+finiteMean μ gain+finiteMean μ lin := by
    nlinarith only [hl,hprio,mul_le_mul_of_nonneg_left hlinear hξ]
  change (1-ξ)*(f ∅+L+γ*Fg-ξ*G)-((1-ξ)*(ρ+η*W)+δ) ≤ _
  nlinarith only [hav,mul_le_mul_of_nonneg_left hinside (sub_nonneg.mpr hξ1)]

end SubmodularMatching.NonmonotoneLayers
