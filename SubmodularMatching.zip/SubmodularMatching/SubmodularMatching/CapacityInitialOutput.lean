import SubmodularMatching.CapacityWordScheduler
import SubmodularMatching.TwoStageLoad

/-! The empty-set and singleton incumbent and the unit-capacity specialization. -/
namespace SubmodularMatching.Capacity
open Streaming
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def initialCandidate (edges : ℕ → E) (oracle : Finset E → ℚ) : ℕ → Finset E
  | 0 => ∅
  | k+1 =>
      let old := initialCandidate edges oracle k
      if oracle old < oracle {edges k} then {edges k} else old

theorem initialCandidate_value (edges : ℕ → E) (f : Finset E → ℚ) (hn : 0 ≤ f ∅) (k : ℕ) :
    (f (initialCandidate edges f k):ℝ) =
      singletonMaximum (seededScale (f ∅) (fun i => (f {edges i}:ℝ))) (k+1) := by
  induction k with
  | zero => simp [initialCandidate,singletonMaximum,seededScale,(show (0:ℝ) ≤ f ∅ by exact_mod_cast hn)]
  | succ k ih =>
    simp only [initialCandidate,singletonMaximum,seededScale] at ih ⊢
    split_ifs with h
    · rw [max_eq_right (ih ▸ (by exact_mod_cast h.le : (f (initialCandidate edges f k):ℝ) ≤ f {edges k}))]
    · have hs : (f {edges k}:ℝ) ≤ f (initialCandidate edges f k) := by exact_mod_cast le_of_not_gt h
      simpa only [← ih,max_eq_left hs]

theorem singleton_feasible (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0<cap (ends e).1 ∧ 0<cap (ends e).2) (e : E) :
    feasible ends cap {e} := by
  intro v
  by_cases h : touches ends v e
  · have hcap : 0<cap v := by rcases h with h|h <;> subst v; exact (hpos _).1; exact (hpos _).2
    exact ((Finset.card_le_card (Finset.filter_subset _ ({e}:Finset E))).trans_eq
      (Finset.card_singleton e)).trans hcap
  · have hz : incidences ends {e} v = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro a ha
      obtain ⟨ha,ha'⟩ := Finset.mem_filter.mp ha
      exact h (Finset.mem_singleton.mp ha ▸ ha')
    simp [hz]

theorem initialCandidate_feasible (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0<cap (ends e).1 ∧ 0<cap (ends e).2) (edges : ℕ → E)
    (f : Finset E → ℚ) (k : ℕ) : feasible ends cap (initialCandidate edges f k) := by
  induction k with
  | zero => intro v; simp [initialCandidate,incidences]
  | succ k ih =>
    rw [initialCandidate]; split_ifs
    · exact singleton_feasible _ _ hpos _
    · exact ih

theorem unit_feasible_iff (ends : E → V × V) (s : Finset E) :
    feasible ends (fun _ => 1) s ↔ IsMatchingOn (TwoStage.pairEnds ends) s := by
  have ht (v : V) (e : E) : touches ends v e ↔ v ∈ TwoStage.pairEnds ends e := by
    simp [touches,TwoStage.pairEnds]
  constructor
  · intro hf a ha b hb hab
    apply Finset.disjoint_left.mpr
    intro v hva hvb
    exact hab (Finset.card_le_one.mp (hf v) a (Finset.mem_filter.mpr ⟨ha,(ht _ _).mpr hva⟩)
      b (Finset.mem_filter.mpr ⟨hb,(ht _ _).mpr hvb⟩))
  · intro h v
    apply Finset.card_le_one.mpr
    intro a ha b hb
    obtain ⟨ha',hva⟩ := Finset.mem_filter.mp ha
    obtain ⟨hb',hvb⟩ := Finset.mem_filter.mp hb
    by_contra hn
    exact Finset.disjoint_left.mp (h ha' hb' hn) ((ht _ _).mp hva) ((ht _ _).mp hvb)

end SubmodularMatching.Capacity
