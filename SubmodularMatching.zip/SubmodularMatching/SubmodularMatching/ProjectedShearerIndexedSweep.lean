import SubmodularMatching.ProjectedShearerIndexedTicket
import SubmodularMatching.ProjectedShearerCappedSampler

/-! # The bounded indexed sampler equals the finite-word matching run -/

namespace SubmodularMatching.ShearerCappedSampler
open GibbsMatching GibbsSampler ShearerSampler Shearer UpperBoundAssembly
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem mem_indexedList (get : ℕ → Option E) (start n : ℕ) (e : E) :
    e ∈ indexedList get start n ↔ ∃ j, start ≤ j ∧ j < start+n ∧ get j = some e := by
  induction n generalizing start with
  | zero => simp [indexedList]; omega
  | succ n ih =>
    cases he : get start with
    | none =>
      simp only [indexedList,he,Option.elim_none,ih]
      constructor
      · rintro ⟨j,h1,h2,h3⟩; exact ⟨j,by omega,by omega,h3⟩
      · rintro ⟨j,h1,h2,h3⟩
        have neq : j ≠ start := by rintro rfl; simp [he] at h3
        exact ⟨j,by omega,by omega,h3⟩
    | some a =>
      simp only [indexedList,he,Option.elim_some,List.mem_cons,ih]
      constructor
      · rintro (rfl|⟨j,h1,h2,h3⟩)
        · exact ⟨start,le_rfl,by omega,he⟩
        · exact ⟨j,by omega,by omega,h3⟩
      · rintro ⟨j,h1,h2,h3⟩
        by_cases eq : j = start
        · subst j; exact Or.inl (Option.some.inj (h3.symm.trans he))
        · exact Or.inr ⟨j,by omega,by omega,h3⟩

def getIndex {N : ℕ} (atIndex : Fin N → E) (j : ℕ) : Option E := if hj : j < N then some (atIndex ⟨j,hj⟩) else none

theorem suffix_membership {N : ℕ} (atIndex : Fin N → E) (hi : Function.Injective atIndex)
    (cut n : ℕ) (hlen : cut+n=N) (j : ℕ) (hj : j < N) (e : E) (he : getIndex atIndex j = some e) :
    e ∈ (indexedList (getIndex atIndex) cut n).toFinset ↔ cut ≤ j := by
  rw [List.mem_toFinset,mem_indexedList]
  constructor
  · rintro ⟨k,hk,hk',he'⟩
    have hkN : k<N := by omega
    have ea := Option.some.inj (by simpa only [getIndex,dif_pos hkN,dif_pos hj] using he'.trans he.symm)
    have eq := congrArg Fin.val (hi ea)
    change k=j at eq
    omega
  · exact fun h => ⟨j,h,by omega,he⟩

/-- A constant-cursor descending fold over the finite index interval. -/
def sweep {A : Type*} (step : ℕ → A → A) (start : ℕ) : ℕ → A → A
  | 0, a => a
  | n+1, a => sweep step start n (step (start+n) a)

private def rangeSpec {A : Type*} (step : ℕ → A → A) (start : ℕ) : ℕ → A → A
  | 0, a => a
  | n+1, a => step start (rangeSpec step (start+1) n a)

private theorem sweep_spec {A : Type*} (step : ℕ → A → A) (start n : ℕ) (a : A) :
    sweep step start n a = rangeSpec step start n a := by
  have snoc (s b : ℕ) (x : A) : rangeSpec step s (b+1) x = rangeSpec step s b (step (s+b) x) := by
    induction b generalizing s with
    | zero => simp [rangeSpec]
    | succ b ih =>
      change step s (rangeSpec step (s+1) (b+1) x) = step s (rangeSpec step (s+1) b (step (s+(b+1)) x))
      rw [ih]
      congr 3 <;> omega
  induction n generalizing a with
  | zero => rfl
  | succ n ih => rw [sweep,ih,snoc]

def status (K : ℕ) (A : Finset E) : Option (Finset E) := if K ≤ A.card then none else some A

/-- An aborted state skips every subsequent coin draw. An active state
stores only the matching, with fewer than `K` selected edge identifiers. -/
def sweepStep (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V) (get : ℕ → Option E)
    (N K B fuel : ℕ) (words : ℕ → AcceptanceWordTape c B fuel) (j : ℕ) : Option (Finset E) → Option (Finset E)
  | none => none
  | some A => match get j with
    | none => some A
    | some e => status K (indexedDecision c ends ep get N (j+1) A e B fuel (words j))

/-- No prefix, rejection graph, or list of all implicit slot pairs is
stored. The available slot pairs are recomputed by their index as needed. -/
def sparseRun {N : ℕ} (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V)
    (atIndex : Fin N → E) (K B fuel : ℕ) (words : ℕ → AcceptanceWordTape c B fuel) : Option (Finset E) :=
  sweep (sweepStep c ends ep (getIndex atIndex) N K B fuel words) 0 N (status K ∅)

/-- State-by-state mathematical equivalence with the bounded-rejection
three-word tapes. In particular the real implementation can abort as soon
as the size cap is reached and never exceed its memory budget. -/
theorem sparseRun_eq {N : ℕ} (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V)
    (atIndex : Fin N → E) (hi : Function.Injective atIndex) (K B fuel : ℕ)
    (words : ℕ → AcceptanceWordTape c B fuel) :
    let stored := indexedList (getIndex atIndex) 0 N
    sparseRun c ends ep atIndex K B fuel words = status K
      (compactShearerRun c ends ep stored B fuel stored (fun i => words i.val)).2 := by
  intro stored
  let get := getIndex atIndex
  let step := sweepStep c ends ep get N K B fuel words
  have aux (start n : ℕ) (hlen : start+n=N) :
      rangeSpec step start n (status K ∅) = status K
      (compactShearerRun c ends ep stored B fuel (indexedList get start n) (fun i => words (start+i.val))).2 := by
    induction n generalizing start with
    | zero => rfl
    | succ n ih =>
      have hstart : start<N := by omega
      let e := atIndex ⟨start,hstart⟩
      have eg : get start = some e := by simp [get,getIndex,hstart,e]
      let prior := indexedList get (start+1) n
      let tape : Fin prior.length → AcceptanceWordTape c B fuel := fun i => words (start+1+i.val)
      let A := (compactShearerRun c ends ep stored B fuel prior tape).2
      let P := prior.toFinset
      have hAS : A ⊆ P := ((mem_matchings ends P A).mp (compactShearerRun_valid c ends ep P stored B fuel prior (Finset.Subset.refl _) tape)).1
      have eqL : indexedList get start (n+1) = e::prior := by simp [indexedList,eg,prior]
      rw [rangeSpec,ih (start+1) (by omega)]
      change step start (status K A) = _
      have htail : Fin.tail (fun i : Fin (e::prior).length => words (start+i.val)) = tape := by
        funext i; apply congrArg words; change start+(i.val+1) = start+1+i.val; omega
      have full : (compactShearerRun c ends ep stored B fuel (indexedList get start (n+1)) (fun i => words (start+i.val))).2 =
          compactMatchingDecision c ends ep stored B fuel P A e (words start) := by
        rw [eqL,compactShearerRun,htail,compactShearerRun_prefix]
        simp only [Nat.add_zero]; rfl
      rw [full]
      have hidx := indexedDecision_eq c ends ep get N (start+1) A P e B fuel (words start) hAS
        (suffix_membership atIndex hi (start+1) n (by omega))
      by_cases big : K ≤ A.card
      · have hs : A ⊆ compactMatchingDecision c ends ep stored B fuel P A e (words start) := by
          unfold compactMatchingDecision; split_ifs; exact Finset.subset_insert _ _; rfl
        simp [step,sweepStep,status,big,big.trans (Finset.card_le_card hs)]
      · simp only [status,if_neg big,step,sweepStep,eg,hidx]
        rfl
  rw [sparseRun,sweep_spec]
  simpa only [Nat.zero_add] using aux 0 N (Nat.zero_add _)

/-- On every fresh tape, at each point a successful stored matching has
fewer than the cap number of edges. -/
theorem sparseRun_card {N : ℕ} (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V)
    (atIndex : Fin N → E) (hi : Function.Injective atIndex) (K B fuel : ℕ)
    (words : ℕ → AcceptanceWordTape c B fuel) (A : Finset E)
    (hA : sparseRun c ends ep atIndex K B fuel words = some A) : A.card < K := by
  rw [sparseRun_eq c ends ep atIndex hi] at hA
  unfold status at hA
  split_ifs at hA with hc
  cases hA; exact lt_of_not_ge hc

end SubmodularMatching.ShearerCappedSampler
