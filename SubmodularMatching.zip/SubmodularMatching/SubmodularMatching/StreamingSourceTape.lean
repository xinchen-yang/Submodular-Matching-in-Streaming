import SubmodularMatching.StreamingSchedulerCharge
import SubmodularMatching.UpperBoundFinalGuess
import SubmodularMatching.UpperBoundFiniteExecution

/-!
# Normalized finite law of the complete source transcript

The finite law samples a fresh independent batch in each scheduled context,
then evaluates the next context using the actual prefix. The raw batches
serve as outcomes for composing the source analysis with postprocessing.
-/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming GibbsSampler MeasureTheory ProbabilityTheory

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The exact finite kernels of the streaming phase composed in schedule
order. The tape is an outcome in the proof of the randomized program. -/
def sourceTapeFrom (P : ScheduledSource E V) (N : ℕ) :
    ℕ → ℕ → (ℕ → Fin N → ℝ) → CandidateLaw (ℕ → Fin N → ℝ)
  | 0, _, batches => CandidateLaw.pure batches
  | steps + 1, i, batches => by
    classical
    let ctx := P.context i (P.history batches i)
    exact (CandidateLaw.ofMeasure (ctx.kernel N)).bind
      (fun draw => sourceTapeFrom P N steps (i + 1) (Function.update batches i (ctx.samples draw)))

/-- All source batches are included, even those at guesses later dropped. -/
def sourceTape (P : ScheduledSource E V) (N : ℕ) : CandidateLaw (ℕ → Fin N → ℝ) :=
  sourceTapeFrom P N P.calls.length 0 (fun _ _ => 0)

omit [DecidableEq V] in
private theorem history_update_future (P : ScheduledSource E V) {N : ℕ}
    (batches : ℕ → Fin N → ℝ) (i : ℕ) (batch : Fin N → ℝ) (j : ℕ) (h : j ≤ i) :
    P.history (Function.update batches i batch) j = P.history batches j := by
  induction j with
  | zero => rfl
  | succ j ih =>
    rw [ScheduledSource.history, ScheduledSource.history, ih (Nat.le_of_succ_le h)]
    rw [Function.update_of_ne (by omega : j ≠ i)]

/-- Only calls already made are constrained on a prefix of the tape. -/
def goodSourcePrefix (P : ScheduledSource E V) {N : ℕ} (batches : ℕ → Fin N → ℝ) (i : ℕ) : Prop :=
  ∀ t < i,
    let ctx := P.context t (P.history batches t)
    ∃ ω : Fin N → Fin ctx.outcomes.length, batches t = ctx.samples ω ∧ ctx.accurate ω

private theorem goodSourcePrefix_extend (P : ScheduledSource E V) {N : ℕ}
    (batches : ℕ → Fin N → ℝ) (i : ℕ) (h : goodSourcePrefix P batches i)
    (draw : Fin N → Fin (P.context i (P.history batches i)).outcomes.length)
    (hgood : (P.context i (P.history batches i)).accurate draw) :
    goodSourcePrefix P (Function.update batches i ((P.context i (P.history batches i)).samples draw))
      (i + 1) := by
  intro t ht
  rw [history_update_future P batches i _ t (Nat.lt_succ_iff.mp ht)]
  by_cases hEq : t = i
  · subst t
    exact ⟨draw, by simp, hgood⟩
  · rw [Function.update_of_ne hEq]
    exact h t (by omega)


/-- Indicator of at least one inaccurate source call. -/
def sourceFailureIndicator (P : ScheduledSource E V) {N : ℕ}
    (batches : ℕ → Fin N → ℝ) : ℝ := by
  classical
  exact if goodStreamingBatches P batches then 0 else 1

/-- Integrate the per-history failure bound over the actual adaptive finite
tree. No independence between calls is imposed. -/
theorem sourceTapeFrom_failure_le (P : ScheduledSource E V) (N K : ℕ) (hN : 0 < N)
    (hsize : 2 * (P.vertices : ℝ) ^ 4 * K / P.epsilon ^ 2 ≤ N)
    (steps i : ℕ) (batches : ℕ → Fin N → ℝ) (hfinish : i + steps = P.calls.length)
    (hprev : goodSourcePrefix P batches i) :
    expected (sourceTapeFrom P N steps i batches).outcomes (sourceTapeFrom P N steps i batches).mass
      (sourceFailureIndicator P) ≤
        (steps : ℝ) * (2 / (2 : ℝ) ^ K) := by
  classical
  induction steps generalizing i batches with
  | zero =>
    have hgood : goodStreamingBatches P batches := by
      unfold goodStreamingBatches
      have he : i = P.calls.length := by omega
      rw [← he]
      exact hprev
    rw [sourceTapeFrom, CandidateLaw.pure_expected]
    simp [sourceFailureIndicator, hgood]
  | succ steps ih =>
    let ctx := P.context i (P.history batches i)
    let q := CandidateLaw.ofMeasure (ctx.kernel N)
    let rest := fun draw => sourceTapeFrom P N steps (i + 1) (Function.update batches i (ctx.samples draw))
    let test := sourceFailureIndicator P (N := N)
    let bound := (steps : ℝ) * (2 / (2 : ℝ) ^ K)
    let bad : Set (Fin N → Fin ctx.outcomes.length) := {ω | ¬ ctx.accurate ω}
    have hbound : 0 ≤ bound := by dsimp [bound]; positivity
    have hb : MeasurableSet bad := (Set.toFinite bad).measurableSet
    have hcond : (ctx.kernel N).real bad ≤ 2 / (2 : ℝ) ^ K :=
      P.call_failure_le hN (by omega) hsize (P.history batches i)
    rw [sourceTapeFrom]
    change expected (q.bind rest).outcomes (q.bind rest).mass test ≤ _
    rw [CandidateLaw.bind_expected]
    calc
      _ ≤ expected q.outcomes q.mass (fun draw => bad.indicator (1 : (Fin N → Fin ctx.outcomes.length) → ℝ)
          draw + bound) := by
        unfold expected
        apply Finset.sum_le_sum
        intro draw hd
        apply mul_le_mul_of_nonneg_left _ (q.probability.nonnegative draw hd)
        by_cases hg : ctx.accurate draw
        · have he := ih (i + 1) (Function.update batches i (ctx.samples draw)) (by omega)
            (goodSourcePrefix_extend P batches i hprev draw hg)
          simpa [bad, hg, rest, test, bound] using he
        · have he : expected (rest draw).outcomes (rest draw).mass test ≤ 1 := by
            unfold expected
            calc
              _ ≤ ∑ x ∈ (rest draw).outcomes, (rest draw).mass x := by
                apply Finset.sum_le_sum
                intro x hx
                exact mul_le_of_le_one_right ((rest draw).probability.nonnegative x hx)
                  (by dsimp [test, sourceFailureIndicator]; split_ifs <;> norm_num)
              _ = _ := (rest draw).probability.total
          exact he.trans (by simpa [bad, hg] using le_add_of_nonneg_right (a := (1 : ℝ)) hbound)
      _ = (ctx.kernel N).real bad + bound := by
        dsimp only [q]
        rw [CandidateLaw.ofMeasure_expected, integral_add Integrable.of_finite Integrable.of_finite,
          integral_indicator_one hb]
        simp
      _ ≤ ((steps + 1 : ℕ) : ℝ) * (2 / (2 : ℝ) ^ K) := by
        rw [Nat.cast_succ, add_mul, one_mul]
        change _ + bound ≤ bound + _
        simpa only [add_comm] using add_le_add_right hcond bound

/-- The exact finite source tape spends at most half the allotted error
probability. This result supplies the good source event to the final theorem. -/
theorem sourceTape_failure_budget (P : ScheduledSource E V) (N K L : ℕ) (omega : ℝ)
    (hN : 0 < N) (hL : P.span + 1 ≤ L)
    (hsize : 2 * (P.vertices : ℝ) ^ 4 * K / P.epsilon ^ 2 ≤ N)
    (hbits : 4 * (P.vertices : ℝ) ^ 2 * L ≤ omega * 2 ^ K) :
    expected (sourceTape P N).outcomes (sourceTape P N).mass
      (sourceFailureIndicator P) ≤ omega / 2 := by
  classical
  have hbound : P.calls.length ≤ P.vertices ^ 2 * L := by
    rw [ScheduledSource.calls, sourceScheduleList_length]
    exact sourceEstimateSchedule_card_le _ _ _ _ _ _ P.width_bound P.arrivals_bound hL
  have hb : (P.calls.length : ℝ) ≤ (P.vertices : ℝ) ^ 2 * L := by exact_mod_cast hbound
  calc
    _ ≤ (P.calls.length : ℝ) * (2 / (2 : ℝ) ^ K) := by
      unfold sourceTape
      exact sourceTapeFrom_failure_le P N K hN hsize _ _ _ (by simp)
        (fun _ h => (Nat.not_lt_zero _ h).elim)
    _ ≤ (P.vertices : ℝ) ^ 2 * L * (2 / (2 : ℝ) ^ K) :=
      mul_le_mul_of_nonneg_right hb (by positivity)
    _ ≤ omega / 2 := by
      rw [← mul_div_assoc]
      apply (div_le_iff₀ (by positivity : 0 < (2 : ℝ) ^ K)).2
      linarith

end

end SubmodularMatching.UpperBoundAssembly
