import SubmodularMatching.StreamingK1RealProgram

/-! Signed integer accumulator bounds for the real oracle, including negative samples. -/
namespace SubmodularMatching.Capacity.RealOracle

open Streaming Finset
noncomputable section

theorem signed_sample_floor_bound (K : ℕ) (x d : ℝ) (hd : 0<d)
    (hl : -(K:ℝ)*d ≤ x) (hu : x ≤ (K:ℝ)*d) :
    -(4*(K:ℤ)) ≤ ⌊4*x/d⌋ ∧ ⌊4*x/d⌋ ≤ 4*(K:ℤ) := by
  constructor
  · apply Int.le_floor.mpr
    push_cast
    rw [le_div_iff₀ hd]
    linarith
  · have h : 4*x/d ≤ ((4*(K:ℤ):ℤ):ℝ) := by
      push_cast
      rw [div_le_iff₀ hd]
      linarith
    simpa only [Int.floor_intCast] using Int.floor_le_floor h

/-- On any block with scaled marginal magnitude bounded by K, every partial signed sum
has magnitude at most 4 times the number of samples times K. -/
theorem signed_accumulator_bound (K N : ℕ) (d : ℝ) (hd : 0 < d) (x : ℕ → ℝ)
    (h : ∀ i < N, -(K:ℝ)*d ≤ x i ∧ x i ≤ (K:ℝ)*d) (t : ℕ) (ht : t ≤ N) :
    -(4*(K:ℤ)*t) ≤ RealSource.accumulateMarginalLoop d x t 0 ∧
      RealSource.accumulateMarginalLoop d x t 0 ≤ 4*(K:ℤ)*t := by
  rw [RealSource.accumulateMarginalLoop_eq,zero_add]
  change -(4*(K:ℤ)*t) ≤ ∑ i : Fin t, ⌊4*x i/d⌋ ∧
       ∑ i : Fin t, ⌊4*x i/d⌋ ≤ 4*(K:ℤ)*t
  have hr (i : Fin t) := signed_sample_floor_bound K (x i) d hd
    (h i (i.isLt.trans_le ht)).1 (h i (i.isLt.trans_le ht)).2
  constructor
  · have hh := Finset.sum_le_sum (s := (Finset.univ : Finset (Fin t))) (fun i _ => (hr i).1)
    simpa only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,
      mul_neg,neg_mul,mul_comm (t:ℤ)] using hh
  · have hh := Finset.sum_le_sum (s := (Finset.univ : Finset (Fin t))) (fun i _ => (hr i).2)
    simpa only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,
      mul_neg,neg_mul,mul_comm (t:ℤ)] using hh


/-- The physical loop visits sample indices in descending order. This is its
accumulator after the first t such visits of a batch of N. -/
def runningAccumulator (d : ℝ) (x : ℕ → ℝ) (N : ℕ) : ℕ → ℤ
  | 0 => 0
  | t+1 => runningAccumulator d x N t + ⌊4*x (N-(t+1))/d⌋

theorem runningAccumulator_resume (d : ℝ) (x : ℕ → ℝ) (N t : ℕ) (ht : t≤N) :
    RealSource.accumulateMarginalLoop d x (N-t) (runningAccumulator d x N t) =
      RealSource.accumulateMarginalLoop d x N 0 := by
  induction t with
  | zero => rfl
  | succ t ih =>
    have h := ih (by omega)
    rw [show N-t=(N-(t+1))+1 by omega, RealSource.accumulateMarginalLoop] at h
    exact h

theorem runningAccumulator_bound (K N : ℕ) (d : ℝ) (hd : 0 < d) (x : ℕ → ℝ)
    (h : ∀ i < N, -(K:ℝ)*d ≤ x i ∧ x i ≤ (K:ℝ)*d) (t : ℕ) (ht : t ≤ N) :
    -(4*(K:ℤ)*t) ≤ runningAccumulator d x N t ∧
      runningAccumulator d x N t ≤ 4*(K:ℤ)*t := by
  induction t with
  | zero => simp [runningAccumulator]
  | succ t ih =>
    have hh := h (N-(t+1)) (by omega)
    have hf := signed_sample_floor_bound K _ _ hd hh.1 hh.2
    have hp := ih (by omega)
    rw [runningAccumulator]
    push_cast
    constructor <;> linarith only [hp.1,hp.2,hf.1,hf.2]

end
end SubmodularMatching.Capacity.RealOracle
