import SubmodularMatching.CapacityRealQueryPolynomial
import SubmodularMatching.CapacityRealBankSpace
import SubmodularMatching.CapacitySelectedConfidence
import SubmodularMatching.CapacityVerifiedGrid
import SubmodularMatching.NonmonotoneActionWordCost
import SubmodularMatching.NonmonotoneOptimizerResources

/-! # Source query and retained packing resources at the paper's actual schedules -/

namespace SubmodularMatching.Capacity
open Streaming Streaming.OracleQuery AppendixM LinearPacking NonmonotoneOptimizer
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

/-- The real scheduler completing any prefix has the same number of queries as its
instrumented execution and its full table fits the archive bound. The same fixed bit
and sample schedule is used in the selected pass probability theorem. -/
theorem signed_source_resources (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0<cap (ends e).1 ∧ 0<cap (ends e).2) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (n k J : ℕ) (hv : 2≤n^2) (hk : k≤n^2) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hn : ∀ A, 0≤f A) (edges : ℕ → E) (draw : ℕ → ℕ → ℕ → ℕ → ℕ)
    (hinj : ∀ i < k, ∀ l < k, edges i=edges l → i=l)
    (Z : Finset E) (hz : feasible ends cap Z) (hm : ∀ t, feasible ends cap t → t.card ≤ Z.card) :
    let v := n^2
    let K := sourceWordScale v (v^2)
    let N := batchCount K J
    let bits := batchBits K
    let state := RealOracle.countedBank ends cap hpos v N bits f edges draw k
    state.1 = RealOracle.forwardBank ends cap hpos v N bits f edges draw k ∧
    RealOracle.bankCells state.1 ≤ (4+9*signedGuessCountConstant*(14+26*incidenceConstant))*
      (Z.card+1)*((n+1).log2+1)^2 ∧
    state.2 ≤ 1+n^2*(1+2*(4*(2^42*(v^2+2)*(v^2+1)+v^2)^3*J+1)*
      (signedGuessCountConstant*(v+2))) := by
  intro v K N bits state
  have hc := RealOracle.forward_queries_polynomial ends cap hpos n J k hk f edges draw
  refine ⟨hc.1,?_,hc.2⟩
  rw [show state.1=RealOracle.forwardBank ends cap hpos v N bits f edges draw k from hc.1]
  exact RealOracle.forwardBank_space ends cap hpos hloop n N bits hv (by dsimp only [N,batchCount]; omega)
    f hf hn edges draw k hinj Z hz hm

/-- The retained-label oracle has at most five rows and two columns per stored
label. This substitutes those dimensions into both the optimizer buffer bound
and its actual packing loop work formula, including the paper's dyadic exponent. -/
theorem retained_packing_resources {I : Type*} [Fintype I] [DecidableEq I]
    (ends : I → V × V) (cap : V → ℕ) (pair : I → BSlot cap × BSlot cap)
    {m l : ℕ} (rows : Fin m ≃ ↑(activeRows ends cap pair)) (cols : Fin l ≃ (I⊕I))
    (J : ℕ) :
    let s := Fintype.card I
    let k := paperExponent l
    let P := 2^37*(2*s+1)
    2*m+12*l ≤ 34*s ∧
    ascentFuel k*projectionFuel k*packingIterationsNat m l ((scale k)^5)
      ≤ 1024*(5*s)^2*(2*s)^6*P^43 ∧ actionBatch l J ≤ 4*8^4*J*P^40+1 := by
  intro s k P
  have hm : m ≤ 5*s := by
    have h := Fintype.card_congr rows
    rw [Fintype.card_fin,Fintype.card_coe] at h
    exact h ▸ activeRows_card ends cap pair
  have hl : l = 2*s := by
    simpa only [Fintype.card_fin,Fintype.card_sum,two_mul] using Fintype.card_congr cols
  have hp : scale k ≤ P := by simpa only [P,← hl] using (paperScale_bounds l).2.2
  refine ⟨by omega,?_,?_⟩
  · rw [(packing_work m l k).2.2]
    gcongr <;> exact hl.le
  · simpa only [P,← hl] using action_batch_polynomial l J

/-- During sequential optimization of any actual archived guess, all the
optimizer vectors and the entire live bank together fit a constant multiple
of the bank alone. The member condition selects the physical record. -/
theorem live_packing_cells (cap : V → ℕ) (bank : RealOracle.GuessBank (SparseSlots E cap))
    (a : ℕ × SparseSlots E cap) (ha : a ∈ bank.states) (ends : E → V × V)
    (pair : E → BSlot cap × BSlot cap) :
    let kept := (a.2.machine.edges.map Prod.fst).toFinset
    ∀ {m l : ℕ} (rows : Fin m ≃ ↑(activeRows (fun e : kept => ends e.val) cap
      (fun e : kept => pair e.val))) (cols : Fin l ≃ (kept ⊕ kept))
      (K : PackingGrid m l) (s nxt : Registers l) (g y r v rounded : Vec l)
      (c : Fin l → ℚ) (P R : ℕ) (pk : PackingE1Vectors m l),
    let dec := packingE1Decisions K.entry c K.den P pk
    let step := packingE1VectorStep K.entry c K.den P R pk
    RealOracle.bankCells bank + (s.state.toArray.size + s.bestState.toArray.size +
      nxt.state.toArray.size + nxt.bestState.toArray.size + g.toArray.size + y.toArray.size +
      r.toArray.size + v.toArray.size + rounded.toArray.size + pk.dual.toArray.size +
      pk.accumulator.toArray.size + dec.toArray.size + step.dual.toArray.size + step.accumulator.toArray.size)
      ≤ 35 * RealOracle.bankCells bank := by
  intro kept m l rows cols K s nxt g y r v rounded c P R pk dec step
  have hrows := (retained_packing_resources (fun e : kept => ends e.val) cap
    (fun e : kept => pair e.val) rows cols 1).1
  have hbuf := (optimizer_array_cells K s nxt g y r v rounded c P R pk).trans hrows
  have hkept : Fintype.card kept ≤ a.2.machine.edges.length := by
    change Fintype.card ↥((a.2.machine.edges.map Prod.fst).toFinset) ≤ _
    rw [Fintype.card_coe]
    exact (List.toFinset_card_le _).trans_eq (List.length_map _)
  have hentry : payloadCells a.2 ≤ (bank.states.map (fun kv => payloadCells kv.2)).sum :=
    List.le_sum_of_mem (List.mem_map.mpr ⟨a,ha,rfl⟩)
  have harch : a.2.machine.edges.length ≤ RealOracle.bankCells bank := by
    have hbase : a.2.machine.edges.length ≤ payloadCells a.2 := by unfold payloadCells; omega
    exact (hbase.trans hentry).trans (Nat.le_add_left _ 4)
  have hbound := hbuf.trans (Nat.mul_le_mul_left 34 (hkept.trans harch))
  exact (Nat.add_le_add_left hbound (RealOracle.bankCells bank)).trans_eq (by ring)

end
end SubmodularMatching.Capacity
