import SubmodularMatching.CapacityAction

/-! # Sparse dyadic projection outputs satisfy the physical slot constraints -/

namespace SubmodularMatching.Capacity
open Finset LinearPacking NonmonotoneOptimizer
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V] {M N : ℕ}

theorem ratMatrix_valid (ends : E → V × V) (cap : V → ℕ) (pair : E → BSlot cap × BSlot cap)
    (p d Av Bv Ae Be : ℚ) (hF : 0 ≤ p*Ae/Av ∧ p*Ae/Av ≤ 1)
    (hv : 0 ≤ Bv*d/Av ∧ Bv*d/Av ≤ 1) (he : 0 ≤ Be*d/Ae ∧ 2*(Be*d/Ae) ≤ 1)
    (r : V ⊕ BSlot cap ⊕ E) (c : E ⊕ E) :
    0 ≤ ratMatrix ends cap pair p d Av Bv Ae Be r c ∧ ratMatrix ends cap pair p d Av Bv Ae Be r c ≤ 1 := by
  have h := capacityMatrix_bounds ends cap pair p d Av Bv Ae Be (by exact_mod_cast hF)
    (by exact_mod_cast hv) (by exact_mod_cast he) r c
  rw [← cast_ratMatrix] at h
  exact_mod_cast h

theorem physical_of_sparse_grid (ends : E → V × V) (cap : V → ℕ) (pair : E → BSlot cap × BSlot cap)
    (p d Av Bv Ae Be : ℚ) (hp : 0<p) (hd : 0≤d) (hAv : 0<Av) (hAe : 0<Ae)
    (hF : 0 ≤ p*Ae/Av ∧ p*Ae/Av ≤ 1)
    (hv : 0 ≤ Bv*d/Av ∧ Bv*d/Av ≤ 1) (he : 0 ≤ Be*d/Ae ∧ 2*(Be*d/Ae) ≤ 1)
    (rows : Fin M ≃ ↑(activeRows ends cap pair)) (cols : Fin N ≃ (E ⊕ E))
    (bits : ℕ) (hM : 0 < M) (hN : 0 < N) (y : Fin N → ℝ) :
    let A := ratMatrix ends cap pair p d Av Bv Ae Be
    let G := dyadicGrid A (fun j => (rows j).val) cols bits hM hN
      (ratMatrix_valid ends cap pair p d Av Bv Ae Be hF hv he)
    NonmonotoneOptimizer.feasible G.entry G.den y →
      PhysicalAction ends cap pair p d Av Bv Ae Be
        (fun e => (p:ℝ)*Ae*y (cols.symm (.inl e))) (fun e => (d:ℝ)*y (cols.symm (.inr e))) := by
  intro A G hy
  let t := fun (c : E ⊕ E) => y (cols.symm c)
  let F := fun e => t (.inl e)
  let u := fun e => t (.inr e)
  have ht : Sum.elim F u = t := by funext c; cases c <;> rfl
  have hz : (fun i => t (cols i)) = y := by funext i; simp [t]
  have hgrid := (roundedPacking_scaling (fun j i => A (rows j).val (cols i)) (2^bits)
    (by positivity) y hy.1).1 hy
  have hactive (r : V ⊕ BSlot cap ⊕ E) (hr : r ∈ activeRows ends cap pair) :
      load (capacityMatrix ends cap pair p d Av Bv Ae Be) (Sum.elim F u) r ≤ 1 := by
    let j := rows.symm ⟨r,hr⟩
    have hrow := hgrid j
    rw [← hz,reindex_load A t (fun j => (rows j).val) cols j] at hrow
    have hj : (rows j).val = r := congrArg Subtype.val (rows.apply_symm_apply _)
    rw [hj] at hrow
    rw [ht]
    simpa only [A,cast_ratMatrix] using hrow
  have hrows := activeRows_suffice ends cap pair p d Av Bv Ae Be (by exact_mod_cast hv.1)
    (by exact_mod_cast hv.2) F u hactive
  exact physicalAction_of_rows ends cap pair p d Av Bv Ae Be (by exact_mod_cast hp) (by exact_mod_cast hd)
    (by exact_mod_cast hAv) (by exact_mod_cast hAe) F u (fun e => (hy.1 _).1) (fun e => hy.1 _) hrows

end
end SubmodularMatching.Capacity
