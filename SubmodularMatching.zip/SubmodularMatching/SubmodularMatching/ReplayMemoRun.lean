import SubmodularMatching.ReplayMemo
import SubmodularMatching.ReplayRateLookup
import SubmodularMatching.ReplayMemoRawRow

/-! # Bounds requiring only one monotone run

An interval contained in one source run needs the two endpoint rows.
Intervals crossing runs can still use the general checked region.
-/

namespace SubmodularMatching.SourceCertificate.Replay

def VerifiedRawRow.row {k : ℕ} (r : VerifiedRawRow k) : RawSourceMode :=
  ⟨r.data.high, r.data.low, r.data.boundary⟩

theorem VerifiedRawRow.source {k : ℕ} (r : VerifiedRawRow k) : quickRow k = r.row :=
  congrArg (fun v : RawRateTriple => (⟨v.high, v.low, v.boundary⟩ : RawSourceMode)) r.sourceTriple

def regionOfRows (lo hi : ℕ) (a b : RawSourceMode) (cLo cHi : ℕ) : AppendixModeRegion :=
  match a, b with
  | ⟨ah, al, _⟩, ⟨bh, bl, _⟩ =>
    ⟨lo, hi, ⟨min ah bh, max ah bh, min al bl, max al bl, cLo, cHi⟩⟩

def oneRunRegion (row : ℕ → RawSourceMode) (lo hi : ℕ) : AppendixModeRegion :=
  regionOfRows lo hi (row (lo / 2)) (row (hi / 2))
    (row ((lo + 1) / 2)).boundary (row ((hi + 1) / 2)).boundary

theorem oneRunRegion_bounds (row : ℕ → RawSourceMode) (lo hi : ℕ) :
    (oneRunRegion row lo hi).p =
      let a := row (lo/2)
      let b := row (hi/2)
      ⟨min a.high b.high, max a.high b.high, min a.low b.low, max a.low b.low,
        (row ((lo+1)/2)).boundary, (row ((hi+1)/2)).boundary⟩ := by
  unfold oneRunRegion regionOfRows
  generalize row (lo / 2) = a
  generalize row (hi / 2) = b
  cases a
  cases b
  rfl

theorem oneRunRegion_lo (row : ℕ → RawSourceMode) (lo hi : ℕ) :
    (oneRunRegion row lo hi).lo = lo := by
  unfold oneRunRegion regionOfRows
  generalize row (lo / 2) = a
  generalize row (hi / 2) = b
  cases a
  cases b
  rfl

theorem oneRunRegion_hi (row : ℕ → RawSourceMode) (lo hi : ℕ) :
    (oneRunRegion row lo hi).hi = hi := by
  unfold oneRunRegion regionOfRows
  generalize row (lo / 2) = a
  generalize row (hi / 2) = b
  cases a
  cases b
  rfl

theorem oneRunRegion_valid (row : ℕ → RawSourceMode)
    (rowMatches : ∀ k < 27648, row k = appendixRawMode k)
    (boundaryMatches : ∀ k ≤ 27648, (row k).boundary = appendixRawBoundary k)
    (lo hi : ℕ) (run : RateRun) (mem : run ∈ appendixRateRuns)
    (runLo : run.lo ≤ lo/2) (runHi : hi/2 ≤ run.hi) : (oneRunRegion row lo hi).Valid := by
  intro e helo hehi
  have hlo : lo ≤ e := by
    simpa only [oneRunRegion_lo] using helo
  have hhi : e ≤ hi := by
    simpa only [oneRunRegion_hi] using hehi
  have hrhi := appendixRateRun_hi run mem
  have valid := validAppendixRateRun run mem
  rw [oneRunRegion_bounds]
  have hk : e / 2 < 27648 := by omega
  have hv : run.Valid row := by
    intro k hkl hkh
    rw [rowMatches k (by omega), rowMatches (k+1) (by omega)]
    exact valid k hkl hkh
  have hsHi := rate_between_of_steps (fun z => (row z).high) run.highRises
    (lo / 2) (hi / 2) (e / 2)
    (fun k kl kh => (hv k (runLo.trans kl) (kh.trans_le runHi)).1) (by omega) (by omega)
  have hsLo := rate_between_of_steps (fun z => (row z).low) run.lowRises
    (lo / 2) (hi / 2) (e / 2)
    (fun k kl kh => (hv k (runLo.trans kl) (kh.trans_le runHi)).2) (by omega) (by omega)
  dsimp only at hsHi hsLo
  rw [rowMatches _ hk] at hsHi hsLo
  have hc₀ := appendixRawBoundary_mono ((lo + 1) / 2) ((e + 1) / 2) (by omega) (by omega)
  have hc₁ := appendixRawBoundary_mono ((e + 1) / 2) ((hi + 1) / 2) (by omega) (by omega)
  have hidx : endpointMode e + (if endpointSide e then 1 else 0) = (e + 1) / 2 := by
    unfold endpointMode endpointSide
    split <;> simp_all <;> omega
  refine ⟨hsHi.1, hsHi.2, hsLo.1, hsLo.2, ?_, ?_⟩
  · change (row ((lo+1)/2)).boundary ≤ appendixRawRatio (endpointMode e) (endpointSide e)
    rw [boundaryMatches _ (by omega), appendixRawRatio, hidx]
    exact hc₀
  · change appendixRawRatio (endpointMode e) (endpointSide e) ≤ (row ((hi+1)/2)).boundary
    rw [boundaryMatches _ (by omega), appendixRawRatio, hidx]
    exact hc₁

def appendixRunAt (index : ℕ) : RateRun :=
  appendixRateRuns[index]?.getD ⟨0,0,false,false⟩

theorem appendixRunAt_mem (index : ℕ) (bound : index < 11) :
    appendixRunAt index ∈ appendixRateRuns := by
  have h : index < appendixRateRuns.length := by simpa [appendixRateRuns] using bound
  simp only [appendixRunAt, List.getElem?_eq_getElem h, Option.getD_some]
  exact List.getElem_mem _

def VerifiedRegion.ofRunLiteral (lo hi index : ℕ) (literal : AppendixModeRegion)
    (indexBound : index < 11) (hlo : (appendixRunAt index).lo ≤ lo/2)
    (hhi : hi/2 ≤ (appendixRunAt index).hi)
    (same : oneRunRegion quickRow lo hi = literal) : VerifiedRegion :=
  ⟨literal, same ▸ oneRunRegion_valid quickRow quickRow_eq quickRow_boundary lo hi
    (appendixRunAt index) (appendixRunAt_mem _ indexBound) hlo hhi⟩

/-- Obtain all six bounds from previously checked rows in one monotone run. -/
def VerifiedRegion.ofRunRowsLiteral (lo hi index : ℕ) (literal : AppendixModeRegion)
    (indexBound : index < 11) (hlo : (appendixRunAt index).lo ≤ lo/2)
    (hhi : hi/2 ≤ (appendixRunAt index).hi)
    (a : VerifiedRawRow (lo/2)) (b : VerifiedRawRow (hi/2))
    (c : VerifiedRawRow ((lo+1)/2)) (d : VerifiedRawRow ((hi+1)/2))
    (same : regionOfRows lo hi a.row b.row c.row.boundary d.row.boundary = literal) : VerifiedRegion :=
  VerifiedRegion.ofRunLiteral lo hi index literal indexBound hlo hhi (by
    simp only [oneRunRegion, a.source, b.source, c.source, d.source]
    exact same)

end SubmodularMatching.SourceCertificate.Replay
