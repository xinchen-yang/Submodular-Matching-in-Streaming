import SubmodularMatching.NonmonotoneFreshBank
import SubmodularMatching.NonmonotoneOriginalInput

/-! The singleton incumbent and active archives share each forward update. -/
namespace SubmodularMatching.Capacity.RealOracle
open Streaming WordWindow AppendixM UpperBoundAssembly GibbsSampler Finset
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def incumbentStep (old : Option E × ℝ) (e : E) (val : ℝ) : Option E × ℝ :=
  if old.2 < val then (some e,val) else old

theorem incumbentStep_actual (f : Finset E → ℝ) (edges : ℕ → E) (i : ℕ) :
    incumbentStep (realIncumbent f edges i) (edges i) (f {edges i}) =
      realIncumbent f edges (i+1) := rfl

section
variable (ends : E → V × V) (cap : V → ℕ) (pos : ∀ e, 0 < cap (ends e).1 ∧ 0 < cap (ends e).2)
variable (v N bits : ℕ) (f : Finset E → ℝ)

def advanceCached (e : E) (val : ℝ) (i : ℕ) (st : GuessBank (SparseSlots E cap))
    (row : WordBatch (sourceGuessCount v*N) (v^2) bits) : GuessBank (SparseSlots E cap) :=
  st.advance (sparseEmpty cap) (guessWidth v) (guessSpan v) val fun j τ payload =>
    sparseStep ends cap pos (wordGrid v) payload e
      (slotWeight v N bits f τ e payload (bankDraw N (tapeInsert (fun _ _ _ => 0) i row) i j))

def jointStateStep (edges : ℕ → E) (i : ℕ) (u : GuessBank (SparseSlots E cap) × (Option E × ℝ)) :
    CandidateLaw (GuessBank (SparseSlots E cap) × (Option E × ℝ)) := by
  classical
  let e := edges i
  let singleton := f {e}
  let incumbent := incumbentStep u.2 e singleton
  exact (CandidateLaw.ofMeasure (wordBatchLaw (sourceGuessCount v*N) (v^2) bits)).map
    (fun row => (advanceCached ends cap pos v N bits f e singleton i u.1 row,incumbent))

theorem jointStep_observe (edges : ℕ → E) (i : ℕ) (st : GuessBank (SparseSlots E cap))
    (inc : Option E × ℝ) (test : GuessBank (SparseSlots E cap) × (Option E × ℝ) → ℝ) :
    let row := jointStateStep ends cap pos v N bits f edges i (st,inc)
    let next := freshBankStep ends cap pos v N bits f edges i st
    expected row.outcomes row.mass test = expected next.outcomes next.mass
      (fun x => test (x,incumbentStep inc (edges i) (f {edges i}))) := by
  dsimp only
  unfold jointStateStep freshBankStep
  rw [CandidateLaw.map_expected,CandidateLaw.map_expected]
  rfl

set_option maxRecDepth 4096 in
theorem jointPass_observe (edges : ℕ → E) (st : GuessBank (SparseSlots E cap))
    (i n : ℕ) (test : GuessBank (SparseSlots E cap) × (Option E × ℝ) → ℝ) :
    let q := CandidateLaw.execute (jointStateStep ends cap pos v N bits f edges) n i
      (st,realIncumbent f edges i)
    let r := CandidateLaw.execute (freshBankStep ends cap pos v N bits f edges) n i st
    expected q.outcomes q.mass test =
      expected r.outcomes r.mass (fun b => test (b,realIncumbent f edges (i+n))) := by
  classical
  induction n generalizing i st with
  | zero => simp [CandidateLaw.execute,CandidateLaw.pure_expected]
  | succ n ih =>
    dsimp only
    rw [CandidateLaw.execute_expected,CandidateLaw.execute_expected,jointStep_observe]
    apply sum_congr rfl
    intro b hb
    dsimp only
    rw [incumbentStep_actual]
    simpa only [Nat.add_succ,Nat.succ_add] using congrArg (_ * ·) (ih b (i+1))

theorem jointPass_incumbent (edges : ℕ → E) (st : GuessBank (SparseSlots E cap))
    (i n : ℕ) (z : GuessBank (SparseSlots E cap) × (Option E × ℝ))
    (hz : z ∈ (CandidateLaw.execute (jointStateStep ends cap pos v N bits f edges) n i
      (st,realIncumbent f edges i)).outcomes) :
    z.2 = realIncumbent f edges (i+n) := by
  classical
  apply CandidateLaw.execute_invariant (jointStateStep ends cap pos v N bits f edges)
    (fun j a => a.2=realIncumbent f edges j) _ n i (st,realIncumbent f edges i) rfl z hz
  intro j old hOld new hNew
  unfold jointStateStep at hNew
  obtain ⟨row,_,rfl⟩ := Finset.mem_image.mp hNew
  change incumbentStep old.2 (edges j) (f {edges j}) = realIncumbent f edges (j+1)
  rw [hOld,incumbentStep_actual]

end

end
end SubmodularMatching.Capacity.RealOracle
