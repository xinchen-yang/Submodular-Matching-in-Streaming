import SubmodularMatching.StreamingPotential

/-!
# Deterministic storage bound for the defined streaming instance

This derives the logarithmic incidence cap from the actual recursion and
combines it with a maximum matching's endpoint cover. Accuracy of the sampled
weight estimates is not needed for this deterministic bound.
-/

namespace SubmodularMatching.Streaming

/-- The elementary logarithm inequality used in (SF4). -/
theorem half_le_log_one_add (x : ℝ) (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    x / 2 ≤ Real.log (1 + x) := by
  have hpos : 0 < 1 + x := by linarith
  have hlog := Real.one_sub_inv_le_log_of_pos hpos
  have hi : (1 + x)⁻¹ * (1 + x) = 1 := inv_mul_cancel₀ hpos.ne'
  have hmid : x / 2 ≤ 1 - (1 + x)⁻¹ := by
    apply (mul_le_mul_iff_left₀ hpos).mp
    nlinarith [mul_nonneg hx (sub_nonneg.mpr hx1)]
  exact hmid.trans hlog

/-- The configuration's positive seed does not exceed its potential cap. -/
theorem PotentialConfig.seed_le_cap (C : PotentialConfig) : C.seed ≤ C.cap := by
  have hm : C.minLow ≤ C.maxRate := C.base_bounds.2.2.1.trans C.base_bounds.2.2.2
  have ht : 0 ≤ C.tau := C.theta_pos.le.trans C.theta_le_tau
  have h := mul_le_mul hm (mul_le_mul_of_nonneg_left C.theta_le_tau C.p_pos.le)
    (mul_nonneg C.p_pos.le C.theta_pos.le) (C.minLow_pos.le.trans hm)
  dsimp [PotentialConfig.seed, PotentialConfig.cap]
  nlinarith [mul_nonneg C.p_pos.le ht]

/-- A geometrically growing positive sequence in the specified range has
at most the incidence count in (SF4). -/
theorem count_le_logarithmic_bound (C : PotentialConfig) (k : ℕ) (value : ℝ)
    (hcap : value ≤ C.cap)
    (hlower : 0 < k → C.seed * C.factor ^ (k - 1) ≤ value) :
    (k : ℝ) ≤ 1 + 2 / (C.kappa * C.p) * Real.log (C.cap / C.seed) := by
  have hkp : 0 < C.kappa * C.p := mul_pos C.kappa_pos C.p_pos
  have hf : 0 < C.factor := zero_lt_one.trans C.factor_gt_one
  have hratio : 0 ≤ Real.log (C.cap / C.seed) :=
    Real.log_nonneg ((one_le_div C.seed_pos).2 C.seed_le_cap)
  by_cases hk : k = 0
  · simp only [hk, Nat.cast_zero]
    exact add_nonneg zero_le_one (mul_nonneg (div_nonneg (by norm_num) hkp.le) hratio)
  · have hk1 : 1 ≤ k := Nat.one_le_iff_ne_zero.mpr hk
    have hl := Real.log_le_log
      (mul_pos C.seed_pos (pow_pos hf (k - 1)))
      ((hlower (Nat.pos_of_ne_zero hk)).trans hcap)
    rw [Real.log_mul C.seed_pos.ne' (pow_pos hf (k - 1)).ne', Real.log_pow] at hl
    have hlf : C.kappa * C.p / 2 ≤ Real.log C.factor :=
      half_le_log_one_add (C.kappa * C.p) hkp.le C.growth_le_one
    have hmul := mul_le_mul_of_nonneg_left hlf (Nat.cast_nonneg (k - 1) : (0 : ℝ) ≤ _)
    have hcast : ((k - 1 : ℕ) : ℝ) = (k : ℝ) - 1 := by
      rw [Nat.cast_sub hk1]
      norm_num
    rw [hcast] at hl hmul
    have hlog : Real.log (C.cap / C.seed) = Real.log C.cap - Real.log C.seed :=
      Real.log_div C.cap_pos.ne' C.seed_pos.ne'
    have hdiv : (k : ℝ) - 1 ≤ (2 * Real.log (C.cap / C.seed)) / (C.kappa * C.p) := by
      apply (le_div_iff₀ hkp).2
      rw [hlog]
      nlinarith
    calc
      (k : ℝ) = ((k : ℝ) - 1) + 1 := by ring
      _ ≤ (2 * Real.log (C.cap / C.seed)) / (C.kappa * C.p) + 1 := add_le_add hdiv le_rfl
      _ = 1 + 2 / (C.kappa * C.p) * Real.log (C.cap / C.seed) := by ring

/-- Integer form of the proven logarithmic incidence bound. -/
noncomputable def PotentialConfig.incidenceLimit (C : PotentialConfig) : ℕ :=
  ⌊1 + 2 / (C.kappa * C.p) * Real.log (C.cap / C.seed)⌋₊

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Every vertex has at most the logarithmic number of accepted incidences. -/
theorem runPotential_count_le (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (n : ℕ)
    (hw : ∀ i < n, (input i).2 ≤ C.tau) (v : V) :
    (runPotential C ends input n).count v ≤ C.incidenceLimit := by
  have hi := runPotential_invariant_prefix C ends input n hw v
  apply Nat.le_floor
  exact count_le_logarithmic_bound C _ _ hi.2.1 hi.2.2.1

/-- A stored-incidence cap follows from the instrumented counter bound. -/
theorem runPotential_incidence_le (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (n : ℕ)
    (hw : ∀ i < n, (input i).2 ≤ C.tau) (v : V) :
    (storedIncidences ends (runPotential C ends input n).stored v).card ≤
      C.incidenceLimit := by
  exact (runPotential_invariant_prefix C ends input n hw v).2.2.2.trans
    (runPotential_count_le C ends input n hw v)

/-- Every stored edge is an arrived edge in the specified input universe. -/
theorem runPotential_stored_subset (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (allEdges : Finset E) (n : ℕ)
    (hin : ∀ i < n, (input i).1 ∈ allEdges) :
    (runPotential C ends input n).stored ⊆ allEdges := by
  classical
  induction n with
  | zero => exact Finset.empty_subset _
  | succ n ih =>
      simp only [runPotential, processPotential]
      split_ifs
      · intro e he
        rcases Finset.mem_insert.mp he with rfl | he
        · exact hin n (Nat.lt_succ_self n)
        · exact ih (fun i hi => hin i (Nat.lt_trans hi (Nat.lt_succ_self n))) he
      · exact ih (fun i hi => hin i (Nat.lt_trans hi (Nat.lt_succ_self n)))

/-- The two-element endpoint set of an ordinary edge. -/
def endpointSet (ends : E → V × V) (e : E) : Finset V :=
  {(ends e).1, (ends e).2}

/-- The actual fixed-guess program stores at most `2ν` times the logarithmic
incidence cap on every weight transcript bounded by `tau`.
The maximum matching is used for analysis only and is not an input to the program. -/
theorem runPotential_storage_bound (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (allEdges M : Finset E) (n : ℕ)
    (hw : ∀ i < n, (input i).2 ≤ C.tau)
    (hin : ∀ i < n, (input i).1 ∈ allEdges)
    (hloopless : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ N : Finset E, N ⊆ allEdges →
      IsMatchingOn (endpointSet ends) N → N.card ≤ M.card) :
    (runPotential C ends input n).stored.card ≤ 2 * M.card * C.incidenceLimit := by
  apply stored_edges_le_twice_matching_card_mul (endpointSet ends) allEdges M
    (runPotential C ends input n).stored C.incidenceLimit hMsub
    (runPotential_stored_subset C ends input allEdges n hin) hM
  · intro e he
    simp [endpointSet, hloopless e he]
  · exact hmax
  · intro v _
    simpa only [storedIncidences, IsIncident, endpointSet, Finset.mem_insert,
      Finset.mem_singleton] using runPotential_incidence_le C ends input n hw v

end SubmodularMatching.Streaming
