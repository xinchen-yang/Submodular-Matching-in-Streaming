import SubmodularMatching.GibbsCalibration

/-!
# Explicit Gibbs activities for a fractional matching

The GM8 activity formula is defined on finite endpoint sets. Positivity,
the activity and row caps, and its exact reference fixed point are proved
from the fractional degree constraints.
-/

namespace SubmodularMatching.GibbsMatching

open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

noncomputable def vertexLoad (ends : E → Finset V) (S : Finset E) (x : E → ℝ) (v : V) : ℝ :=
  ∑ e ∈ incident ends S v, x e

noncomputable def referenceMonomer (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (gamma : ℝ) (v : V) : ℝ := 1 - gamma * vertexLoad ends S x v

noncomputable def calibratedActivity (ends : E → Finset V) (S : Finset E)
    (x : E → ℝ) (gamma : ℝ) (e : E) : ℝ :=
  (gamma * x e) / ∏ v ∈ ends e, referenceMonomer ends S x gamma v

omit [DecidableEq E] in
theorem vertexLoad_nonnegative (ends : E → Finset V) (S : Finset E)
    (x : E → ℝ) (hx : ∀ e ∈ S, 0 ≤ x e) (v : V) :
    0 ≤ vertexLoad ends S x v := by
  exact Finset.sum_nonneg fun e he => hx e (Finset.mem_filter.mp he).1

omit [DecidableEq E] in
theorem referenceMonomer_bounds (ends : E → Finset V) (S : Finset E)
    (x : E → ℝ) (hx : ∀ e ∈ S, 0 ≤ x e)
    (hdegree : ∀ v, vertexLoad ends S x v ≤ 1)
    (gamma : ℝ) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) (v : V) :
    0 < referenceMonomer ends S x gamma v ∧
      referenceMonomer ends S x gamma v ≤ 1 ∧
        1 - gamma ≤ referenceMonomer ends S x gamma v := by
  have hv0 := vertexLoad_nonnegative ends S x hx v
  have hv1 := hdegree v
  unfold referenceMonomer
  have hs0 := mul_nonneg hgamma0.le hv0
  have hs1 := mul_le_mul_of_nonneg_left hv1 hgamma0.le
  constructor
  · nlinarith
  · constructor <;> nlinarith

omit [DecidableEq E] in
theorem calibratedActivity_pair (ends : E → Finset V) (S : Finset E)
    (x : E → ℝ) (gamma : ℝ) (e : E) (v w : V) (hwv : w ≠ v)
    (hew : ends e = {v, w}) :
    calibratedActivity ends S x gamma e =
      (gamma * x e) / (referenceMonomer ends S x gamma v *
        referenceMonomer ends S x gamma w) := by
  simp [calibratedActivity, hew, hwv.symm]

omit [DecidableEq E] in
theorem calibratedActivity_nonnegative (ends : E → Finset V) (S : Finset E)
    (x : E → ℝ) (hx : ∀ e ∈ S, 0 ≤ x e)
    (hdegree : ∀ v, vertexLoad ends S x v ≤ 1)
    (gamma : ℝ) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) (e : E) (he : e ∈ S) :
    0 ≤ calibratedActivity ends S x gamma e := by
  apply div_nonneg (mul_nonneg hgamma0.le (hx e he))
  exact (Finset.prod_pos fun v _ =>
    (referenceMonomer_bounds ends S x hx hdegree gamma hgamma0 hgamma1 v).1).le

omit [DecidableEq E] in
/-- Every calibrated activity is bounded by `R` times its fractional edge
coordinate, where `R = gamma/(1-gamma)^2`. -/
theorem calibratedActivity_le_scaled_coordinate
    (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (hx : ∀ e ∈ S, 0 ≤ x e) (hdegree : ∀ v, vertexLoad ends S x v ≤ 1)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (gamma : ℝ) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) (e : E) (he : e ∈ S) :
    calibratedActivity ends S x gamma e ≤ (gamma / (1 - gamma) ^ 2) * x e := by
  obtain ⟨v, w, hvw, hew⟩ := Finset.card_eq_two.mp (hends e he)
  have hqv := referenceMonomer_bounds ends S x hx hdegree gamma hgamma0 hgamma1 v
  have hqw := referenceMonomer_bounds ends S x hx hdegree gamma hgamma0 hgamma1 w
  have hg : 0 < 1 - gamma := by linarith
  rw [calibratedActivity_pair ends S x gamma e v w hvw.symm hew]
  have hden : (1 - gamma) ^ 2 ≤ referenceMonomer ends S x gamma v *
      referenceMonomer ends S x gamma w := by
    simpa only [pow_two] using mul_le_mul hqv.2.2 hqw.2.2 hg.le hqv.1.le
  calc
    _ ≤ (gamma * x e) / (1 - gamma) ^ 2 :=
      div_le_div_of_nonneg_left (mul_nonneg hgamma0.le (hx e he)) (sq_pos_of_pos hg) hden
    _ = _ := by ring

omit [DecidableEq E] in
theorem calibratedActivity_cap
    (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (hx : ∀ e ∈ S, 0 ≤ x e) (hdegree : ∀ v, vertexLoad ends S x v ≤ 1)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (gamma p : ℝ) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (hcoord : ∀ e ∈ S, x e ≤ p) (e : E) (he : e ∈ S) :
    calibratedActivity ends S x gamma e ≤ (gamma / (1 - gamma) ^ 2) * p := by
  exact (calibratedActivity_le_scaled_coordinate ends S x hx hdegree hends
    gamma hgamma0 hgamma1 e he).trans
    (mul_le_mul_of_nonneg_left (hcoord e he) (div_nonneg hgamma0.le (sq_nonneg _)))

omit [DecidableEq E] in
theorem calibratedActivity_row_cap
    (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (hx : ∀ e ∈ S, 0 ≤ x e) (hdegree : ∀ v, vertexLoad ends S x v ≤ 1)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (gamma : ℝ) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) (v : V) :
    (∑ e ∈ incident ends S v, calibratedActivity ends S x gamma e) ≤
      gamma / (1 - gamma) ^ 2 := by
  calc
    _ ≤ ∑ e ∈ incident ends S v, (gamma / (1 - gamma) ^ 2) * x e := by
      apply Finset.sum_le_sum
      intro e he
      exact calibratedActivity_le_scaled_coordinate ends S x hx hdegree hends
        gamma hgamma0 hgamma1 e (Finset.mem_filter.mp he).1
    _ = (gamma / (1 - gamma) ^ 2) * vertexLoad ends S x v := by
      rw [← Finset.mul_sum]
      rfl
    _ ≤ gamma / (1 - gamma) ^ 2 := by
      simpa only [mul_one] using mul_le_mul_of_nonneg_left (hdegree v)
        (div_nonneg hgamma0.le (sq_nonneg (1 - gamma)))

omit [DecidableEq E] in
theorem neighborActivity_weighted_sum [Fintype V]
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ) (q : V → ℝ) (v : V) :
    (∑ u, neighborActivity ends S activity v u * q u) =
      ∑ e ∈ incident ends S v, activity e * ∑ u ∈ (ends e).erase v, q u := by
  classical
  unfold neighborActivity
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro e _
  rw [Finset.mul_sum]
  simp only [ite_mul, zero_mul]
  rw [← Finset.sum_filter]
  congr 1
  ext u
  simp

omit [DecidableEq E] in
/-- The reference monomer vector is an exact fixed point for the calibrated
activities, with no fixed-point assumption left to supply. -/
theorem calibratedActivity_fixedPoint [Fintype V]
    (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (hx : ∀ e ∈ S, 0 ≤ x e) (hdegree : ∀ v, vertexLoad ends S x v ≤ 1)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (gamma : ℝ) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) (v : V) :
    (referenceMonomer ends S x gamma v)⁻¹ =
      1 + ∑ u, neighborActivity ends S (calibratedActivity ends S x gamma) v u *
        referenceMonomer ends S x gamma u := by
  have hqv := (referenceMonomer_bounds ends S x hx hdegree gamma hgamma0 hgamma1 v).1
  rw [neighborActivity_weighted_sum]
  have hterm : ∀ e ∈ incident ends S v,
      calibratedActivity ends S x gamma e *
          (∑ u ∈ (ends e).erase v, referenceMonomer ends S x gamma u) =
        (gamma * x e) / referenceMonomer ends S x gamma v := by
    intro e he
    obtain ⟨w, hwv, hew⟩ := exists_other_endpoint ends e
      (hends e (Finset.mem_filter.mp he).1) v (Finset.mem_filter.mp he).2
    have hqw := (referenceMonomer_bounds ends S x hx hdegree gamma hgamma0 hgamma1 w).1
    rw [calibratedActivity_pair ends S x gamma e v w hwv hew]
    simp [hew, hwv.symm]
    field_simp
  have hsum : (∑ e ∈ incident ends S v,
      calibratedActivity ends S x gamma e *
        (∑ u ∈ (ends e).erase v, referenceMonomer ends S x gamma u)) =
      gamma * vertexLoad ends S x v / referenceMonomer ends S x gamma v := by
    calc
      _ = ∑ e ∈ incident ends S v,
          (gamma * x e) / referenceMonomer ends S x gamma v :=
        Finset.sum_congr rfl hterm
      _ = _ := by rw [← Finset.sum_div, ← Finset.mul_sum]; rfl
  rw [hsum]
  field_simp [hqv.ne']
  simp only [referenceMonomer]
  ring

omit [DecidableEq E] in
theorem calibratedActivity_target
    (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (hx : ∀ e ∈ S, 0 ≤ x e) (hdegree : ∀ v, vertexLoad ends S x v ≤ 1)
    (gamma : ℝ) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1)
    (e : E) (v w : V) (hwv : w ≠ v) (hew : ends e = {v, w}) :
    calibratedActivity ends S x gamma e * referenceMonomer ends S x gamma v *
      referenceMonomer ends S x gamma w = gamma * x e := by
  have hqv := (referenceMonomer_bounds ends S x hx hdegree gamma hgamma0 hgamma1 v).1.ne'
  have hqw := (referenceMonomer_bounds ends S x hx hdegree gamma hgamma0 hgamma1 w).1.ne'
  rw [calibratedActivity_pair ends S x gamma e v w hwv hew]
  field_simp

/-- GM9 after substituting the actual GM8 activity construction. -/
theorem calibrated_edge_marginal_bounds [Finite V]
    (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (hx : ∀ e ∈ S, 0 ≤ x e) (hdegree : ∀ v, vertexLoad ends S x v ≤ 1)
    (hends : ∀ e ∈ S, (ends e).card = 2) (hsimple : Set.InjOn ends (S : Set E))
    (gamma p : ℝ) (hgamma0 : 0 < gamma) (hgamma1 : gamma < 1) (hp : 0 ≤ p)
    (hcoord : ∀ e ∈ S, x e ≤ p) (e : E) (he : e ∈ S) :
    let R := gamma / (1 - gamma) ^ 2
    let h := R * p
    Real.exp (-(5 * (1 + R) * h)) * (gamma * x e) ≤
        edgeMean ends S (calibratedActivity ends S x gamma) e ∧
      edgeMean ends S (calibratedActivity ends S x gamma) e ≤
        Real.exp (5 * (1 + R) * h) * (gamma * x e) := by
  letI : Fintype V := Fintype.ofFinite V
  dsimp only
  obtain ⟨v, w, hvw, hew⟩ := Finset.card_eq_two.mp (hends e he)
  have hR : 0 ≤ gamma / (1 - gamma) ^ 2 := div_nonneg hgamma0.le (sq_nonneg _)
  have hcal := edge_marginal_calibration ends S (calibratedActivity ends S x gamma)
    (calibratedActivity_nonnegative ends S x hx hdegree gamma hgamma0 hgamma1)
    hends hsimple ((gamma / (1 - gamma) ^ 2) * p) (gamma / (1 - gamma) ^ 2)
    (mul_nonneg hR hp) hR
    (calibratedActivity_cap ends S x hx hdegree hends gamma p hgamma0 hgamma1 hcoord)
    (calibratedActivity_row_cap ends S x hx hdegree hends gamma hgamma0 hgamma1)
    (referenceMonomer ends S x gamma)
    (fun u => ⟨(referenceMonomer_bounds ends S x hx hdegree gamma hgamma0 hgamma1 u).1,
      (referenceMonomer_bounds ends S x hx hdegree gamma hgamma0 hgamma1 u).2.1⟩)
    (calibratedActivity_fixedPoint ends S x hx hdegree hends gamma hgamma0 hgamma1)
    e he v w hvw.symm hew
  rw [calibratedActivity_target ends S x hx hdegree gamma hgamma0 hgamma1 e v w hvw.symm hew]
    at hcal
  exact hcal

end SubmodularMatching.GibbsMatching
