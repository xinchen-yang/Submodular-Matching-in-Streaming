import SubmodularMatching.NonmonotoneGridRowExecution
import SubmodularMatching.NonmonotoneLayersExactPriority
import SubmodularMatching.NonmonotoneLayersPhysicalDecoder
import SubmodularMatching.NonmonotoneLayersSourceGeometry
import SubmodularMatching.NonmonotoneMarkedPriority
import SubmodularMatching.NonmonotoneStreamingCharge

/-! The numerical priority guarantee directly on a decoded optimizer iterate
and the retained original stream labels. -/

namespace SubmodularMatching.AppendixM

open Capacity UpperBoundAssembly NonmonotoneLayers NonmonotoneOptimizer
open TwoLayerDiffuse Shearer GibbsMatching VarianceBound

variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

/-- A range bound for every proposed, accepted, or rejected label set in
the priority sign queries, assuming only a maximum value for each singleton. -/
theorem retained_shift_bound (hist : ℕ → E) (p : ℝ) (s : ℕ) (hp : 0 ≤ p) (hp1 : p ≤ 1)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hn : ∀ U, 0 ≤ f U)
    (τ : ℝ) (h0 : f ∅ ≤ τ) (hs : ∀ e, f {e} ≤ τ) (U : Finset E) :
    shiftResidual hist p f s U ≤ (Fintype.card E+1:ℝ)*τ := by
  have bound (A : Finset E) : f A ≤ (Fintype.card E+1:ℝ)*τ := by
    have hsub := signed_disjoint_singleton_charge f hf (hn _) ∅ A (by simp)
    rw [Finset.empty_union] at hsub
    have hsum := Finset.sum_le_sum (s:=A) (fun e _ => hs e)
    simp only [Finset.sum_const,nsmul_eq_mul] at hsum
    have hcard := mul_le_mul_of_nonneg_right (show (A.card:ℝ) ≤ Fintype.card E by exact_mod_cast Finset.card_le_univ A)
      ((hn ∅).trans h0)
    linarith only [hsub,hsum,hcard,h0]
  rw [shiftResidual_eq]
  calc
    _ ≤ bernoulliExpectation hist (fun _ => p) (fun _ => (Fintype.card E+1:ℝ)*τ) s :=
      bernoulliExpectation_mono _ _ _ _ _ (fun _ _ => ⟨hp,hp1⟩) (fun A => bound (U∪A))
    _ = _ := bernoulliExpectation_const .. 

end SubmodularMatching.AppendixM

namespace SubmodularMatching.NonmonotoneCandidate.GridRow

open Capacity UpperBoundAssembly NonmonotoneLayers AppendixM TwoLayerDiffuse
open Shearer GibbsMatching VarianceBound

noncomputable section
variable {I V : Type*} [Fintype I] [DecidableEq I] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream I V} {b : V → ℕ} (g : GridRow S b)

/-- The right hand side is the same marked law used by the integer diffuse
registers. Its calibrated coordinate is the true nonlinear coordinate
selected in the retained-pass objective. -/
theorem physical_priority_decoded (hb : ∀ v, 0<b v) (rank : Slots b ↪ ℕ) (fallback : I)
    (els hist : ℕ → I) (r s : ℕ) (cover : ∀ i, i ∈ replacementPrefix els r)
    (hi : ∀ j<r, ∀ l<r, els j=els l → j=l) (p τ ε : ℝ) (hp : 0≤p) (hp1 : p≤1) (hε : 0≤ε)
    (f : Finset I → ℝ) (hf : IsSubmodular f) (hn : ∀ A, 0≤ f A) (h0 : f ∅≤τ) (hs : ∀ e, f {e}≤τ) :
    letI : LinearOrder (Slots b × Slots b) := keyedOrder (slotPairKey b rank)
    let supp := layerSupport S b rank
    let K := scaleFor (S:=S) rank
    let Q := trialTimeGrid K
    let a := firstBins K
    let z := secondBins K
    let lab := sourceSlotLabel S b fallback
    let h := shiftResidual hist p f s
    let H := (Fintype.card I+1:ℝ)*τ
    let prob := fun j => unalteredMarginal pairVertices supp (g.weight 1) lab Q a z (els j)
    let F := bernoulliExpectation els prob (residualValue hist p f s) r
    ∀ estimate : PriorityEstimate (Slots b × Slots b), (∀ A e, |estimate A e-marginal h (binLabel lab e) (A.image (binLabel lab))|≤ε) →
      gamma*F-priorityLossBudget supp.card r Q H ε 0 ≤
        finiteMean (nativeMarkedPair pairVertices supp a z (g.weight firstProportion) (g.weight secondProportion))
          (fun t => residualValue hist p f s (priorityLabels pairVertices supp a z lab h estimate t)) := by
  letI : LinearOrder (Slots b × Slots b) := keyedOrder (slotPairKey b rank)
  dsimp only
  let K := scaleFor (S:=S) rank
  obtain ⟨_,hQ,ha,hb',hA,hB⟩ := trial_time_widths K
  have hA' : (firstBins K:ℝ)/trialTimeGrid K/degree = firstProportion := by rw [hA]; rfl
  have hB' : (secondBins K:ℝ)/trialTimeGrid K/degree = secondProportion := by
    rw [hB]; norm_num [layerTwo,degree,layerOne,secondProportion,firstProportion]
  have hx (e : Slots b × Slots b) : g.weight firstProportion e =
      (firstBins K:ℝ)/trialTimeGrid K/degree*g.weight 1 e := hA' ▸ g.weight_factor firstProportion e
  have hy (e : Slots b × Slots b) : g.weight secondProportion e =
      (secondBins K:ℝ)/trialTimeGrid K/degree*g.weight 1 e := hB' ▸ g.weight_factor secondProportion e
  exact exact_marked_priority pairVertices (layerSupport S b rank) (g.weight 1) (sourceSlotLabel S b fallback)
    els hist r s p hp hp1 f hf hn ((Fintype.card I+1:ℝ)*τ) ε (retained_shift_bound hist p s hp hp1 f hf hn τ h0 hs)
    hε (fun e _ => g.weight_nonneg e) (support_two rank) (g.support_degree hb rank) (trialTimeGrid K)
    (firstBins K) (secondBins K) hQ ha hb' hA hB (g.weight firstProportion) (g.weight secondProportion) hx hy
    (fun e _ => cover e) hi

end
end SubmodularMatching.NonmonotoneCandidate.GridRow
