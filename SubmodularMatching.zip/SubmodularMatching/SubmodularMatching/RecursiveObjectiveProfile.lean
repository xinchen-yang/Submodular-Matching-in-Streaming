import SubmodularMatching.RecursiveObjective

/-! The paper's profile bound for the actual recursive lower-bound objective. -/

namespace SubmodularMatching.RecursiveObjective

noncomputable section

variable {E : Type*}

/-- Distinguished-label mass plus stage-size excess, summed over active stages. -/
def penalty (unit : ℝ) (stage : E → ℕ) (label : E → Bool) (excess : ℕ → ℝ)
    (S : Finset E) (start : ℕ) : ℕ → ℝ
  | 0 => 0
  | n + 1 => stageMass unit stage label start true S + excess start +
      penalty unit stage label excess S (start + 1) n

theorem penalty_nonnegative (unit : ℝ) (hunit : 0 ≤ unit) (stage : E → ℕ)
    (label : E → Bool) (excess : ℕ → ℝ) (hexcess : ∀ i, 0 ≤ excess i)
    (S : Finset E) (count start : ℕ) :
    0 ≤ penalty unit stage label excess S start count := by
  induction count generalizing start with
  | zero => exact le_rfl
  | succ n ih =>
    exact add_nonneg
      (add_nonneg (stageMass_nonnegative unit hunit stage label start true S) (hexcess start))
      (ih (start + 1))

theorem penalty_eq_sum (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (excess : ℕ → ℝ) (S : Finset E) (count start : ℕ) :
    penalty unit stage label excess S start count =
      (Finset.range count).sum (fun j =>
        stageMass unit stage label (start + j) true S + excess (start + j)) := by
  induction count generalizing start with
  | zero => simp [penalty]
  | succ n ih =>
    rw [penalty, Finset.sum_range_succ']
    simp only [Nat.add_zero, ih]
    have heq : (fun j => stageMass unit stage label (start + 1 + j) true S +
        excess (start + 1 + j)) = (fun j => stageMass unit stage label (start + (j + 1)) true S +
        excess (start + (j + 1))) := by
      funext j
      congr 2 <;> omega
    rw [heq]
    ring

theorem raw_excess_bound (C g t z c ε : ℝ) (hC : 0 < C)
    (hz0 : 0 ≤ z) (hzC : z ≤ C) (hε : 0 ≤ ε) (ht : t ≤ c + ε) :
    raw C g t z ≤ g + ε + raw C 0 c z := by
  have hc := coefficient_bounds C z hC hz0 hzC
  have hm : (t - c) * (1 - z / C) ≤ ε := by
    calc
      _ ≤ ε * (1 - z / C) := mul_le_mul_of_nonneg_right (by linarith) hc.1
      _ ≤ ε * 1 := mul_le_mul_of_nonneg_left hc.2 hε
      _ = ε := mul_one _
  have hid : raw C g t z - (g + raw C 0 c z) = (t - c) * (1 - z / C) := by
    unfold raw
    ring
  linarith

theorem raw_suffix_error (C c z v ε : ℝ) (hC : 0 < C)
    (hc0 : 0 ≤ c) (hcC : c ≤ C) (hε : 0 ≤ ε) (hz : z ≤ v + ε) :
    raw C 0 c z ≤ raw C 0 c v + ε := by
  have hc := coefficient_bounds C c hC hc0 hcC
  have hm : (1 - c / C) * (z - v) ≤ ε := by
    calc
      _ ≤ (1 - c / C) * ε := mul_le_mul_of_nonneg_left (by linarith) hc.1
      _ ≤ 1 * ε := mul_le_mul_of_nonneg_right hc.2 hε
      _ = ε := one_mul _
  have hid : raw C 0 c z - raw C 0 c v = (1 - c / C) * (z - v) := by
    unfold raw
    ring
  linarith

/-- The real-valued profile inequality before substituting the closed form.
No integrality restriction on the budgets is needed. -/
theorem objective_le_profile_add_penalty (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (excess : ℕ → ℝ)
    (hexcess : ∀ i, 0 ≤ excess i) (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (count start : ℕ) (S : Finset E)
    (hbudget : ∀ i, start ≤ i → i < start + count →
      totalStageMass unit stage i S ≤ c + excess i) :
    objective unit stage label start count S ≤
      LowerBoundProfile.profile c count + penalty unit stage label excess S start count := by
  induction count generalizing start with
  | zero => simp [objective, penalty, LowerBoundProfile.profile]
  | succ n ih =>
    have hC : (0 : ℝ) < n + 1 := by positivity
    have hcC : c ≤ (n + 1 : ℝ) := by
      have hn : (0 : ℝ) ≤ n := Nat.cast_nonneg n
      linarith
    have hgood := stageMass_nonnegative unit hunit stage label start true S
    have hbud := hbudget start (by omega) (by omega)
    have ht : min (stageMass unit stage label start false S) (n + 1 : ℝ) ≤ c + excess start := by
      have hpart := stageMass_partition unit stage label start S
      have hm := min_le_left (stageMass unit stage label start false S) (n + 1 : ℝ)
      linarith
    have hbound := objective_bounds unit hunit stage label n (start + 1) S
    have hraw := raw_excess_bound (n + 1) (stageMass unit stage label start true S)
      (min (stageMass unit stage label start false S) (n + 1))
      (objective unit stage label (start + 1) n S) c (excess start)
      hC hbound.1 (by linarith [hbound.2]) (hexcess start) ht
    have htail := ih (start + 1) (by
      intro i hi hi'
      apply hbudget i <;> omega)
    have hsuffix := raw_suffix_error (n + 1) c
      (objective unit stage label (start + 1) n S) (LowerBoundProfile.profile c n)
      (penalty unit stage label excess S (start + 1) n) hC hc0 hcC
      (penalty_nonnegative unit hunit stage label excess hexcess S n (start + 1)) htail
    have houter := min_le_right (n + 1 : ℝ)
      (unclipped unit stage label start n S)
    change objective unit stage label start (n + 1) S ≤ _ at houter
    change objective unit stage label start (n + 1) S ≤ _
    simp only [LowerBoundProfile.profile, penalty, raw] at hsuffix hraw ⊢
    change objective unit stage label start (n + 1) S ≤
      raw (n + 1) (stageMass unit stage label start true S)
        (min (stageMass unit stage label start false S) (n + 1))
        (objective unit stage label (start + 1) n S) at houter
    unfold raw at houter
    linarith

/-- Full profile bound for the explicit objective, corresponding to the
paper's lower-bound profile lemma after counts are divided by `M`. -/
theorem objective_profile_bound (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (excess : ℕ → ℝ)
    (hexcess : ∀ i, 0 ≤ excess i) (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (count start : ℕ) (S : Finset E)
    (hbudget : ∀ i, start ≤ i → i < start + count →
      totalStageMass unit stage i S ≤ c + excess i) :
    objective unit stage label start count S ≤ c * (count + 1 : ℝ) / (1 + c) +
      (Finset.range count).sum (fun j =>
        stageMass unit stage label (start + j) true S + excess (start + j)) := by
  have h := objective_le_profile_add_penalty unit hunit stage label excess hexcess c hc0 hc1
    count start S hbudget
  rw [penalty_eq_sum] at h
  exact h.trans (add_le_add (LowerBoundProfile.profile_bound hc0 hc1 count) (le_refl _))

end

end SubmodularMatching.RecursiveObjective
