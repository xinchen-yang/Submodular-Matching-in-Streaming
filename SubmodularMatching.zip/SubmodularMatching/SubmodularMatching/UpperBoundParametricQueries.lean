import SubmodularMatching.UpperBoundParametricSampleResources
import SubmodularMatching.UpperBoundParametricSpace

/-! # Uniform query counts for every fixed member of the approximation family -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint NumericalCertificate
open scoped BigOperators

noncomputable section

variable {slack : ℝ} (a : FamilyParameters slack)

/-- The chosen confidence allowance remains inverse polynomial in the
announced vertex count. -/
theorem parametricConfidence_inv_le (n c : ℕ) (hn : 0 < n) :
    let δ := ((n : ℝ) ^ c)⁻¹
    let ω := min a.error (δ / 2)
    0 < ω ∧ ω⁻¹ ≤ (((a.K + 2) * (n + 1) ^ c : ℕ) : ℝ) := by
  intro δ ω
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hδ : 0 < δ := inv_pos.mpr (pow_pos hn' _)
  have hp : (1 : ℝ) ≤ ((n : ℝ) + 1) ^ c := one_le_pow₀ (by linarith)
  have hpow : (n : ℝ) ^ c ≤ ((n : ℝ) + 1) ^ c :=
    pow_le_pow_left₀ hn'.le (by linarith) _
  refine ⟨lt_min a.error_pos (div_pos hδ (by norm_num)), ?_⟩
  push_cast
  dsimp only [ω]
  rcases le_total a.error (δ / 2) with h | h
  · rw [min_eq_left h]
    have hi : a.error⁻¹ = (a.K : ℝ) := by
      change (1 / (a.K : ℝ))⁻¹ = _
      rw [inv_div, div_one]
    rw [hi]
    have hK : (0 : ℝ) ≤ a.K := Nat.cast_nonneg a.K
    nlinarith only [hp, mul_nonneg hK (sub_nonneg.mpr hp)]
  · rw [min_eq_right h]
    have he : (δ / 2)⁻¹ = (2 : ℝ) * (n : ℝ) ^ c := by dsimp [δ]; rw [inv_div, div_inv_eq_mul]
    rw [he]
    have hval := mul_le_mul_of_nonneg_left hpow (show 0 ≤ (2 : ℝ) by norm_num)
    have hK : (0 : ℝ) ≤ a.K := Nat.cast_nonneg a.K
    nlinarith only [hval, hp, mul_nonneg hK ((zero_le_one : (0 : ℝ) ≤ 1).trans hp)]

/-- Confidence increases only the logarithmic number of sequential trials. -/
def parametricTrialCountConstant (c : ℕ) : ℕ := a.trialMultiplier * (c + 2) + 1

theorem parametricTrials_le (n c : ℕ) :
    a.trials (((n : ℝ) ^ c)⁻¹) ≤ parametricTrialCountConstant a c * ((n + 1).log2 + 1) := by
  let δ := ((n : ℝ) ^ c)⁻¹
  let w := (n + 1).log2 + 1
  have hw : 1 ≤ w := by dsimp [w]; omega
  have hb : binaryBudget (2 / δ) ≤ (c + 2) * w := by
    have h := binaryBudget_polynomial (x := 2 / δ) (C := 2) (d := c) (n := n) (by
      push_cast
      rw [show 2 / δ = (2 : ℝ) * (n : ℝ) ^ c by dsimp [δ]; rw [div_inv_eq_mul]]
      gcongr <;> linarith)
    simpa [w, show (2 : ℕ).log2 = 1 by decide, Nat.add_assoc] using h
  unfold FamilyParameters.trials parametricTrialCountConstant
  calc
    _ ≤ a.trialMultiplier * ((c + 2) * w) + w := Nat.add_le_add (Nat.mul_le_mul_left _ hb) hw
    _ = _ := by ring

private theorem parametricCompact_derivative_query_bound {Guess : Type*} [Fintype Guess]
    (L mmax samples : ℕ) (stored : Guess → ℕ)
    (hL : Fintype.card Guess ≤ L) (hm : ∀ i, stored i ≤ mmax) :
    Fintype.card (Σ i : Guess,
      Fin (FiniteGreedy.stages NumericalCertificate.degree (stored i) a.error) ×
        Fin (stored i) × Fin samples × Fin 2) ≤
      2 * L * ((2 * a.K + 1) * (mmax + 1) ^ 2) * mmax * samples := by
  apply total_derivative_query_count L _ mmax samples _ stored hL _ hm
  intro i
  exact (parametricOptimizer_stages_le a.K a.K_pos (stored i)).trans (by gcongr; exact hm i)

/-- Counting coordinate/sample queries using the actual global sample
schedule, across all final stored graphs. -/
theorem parametricGradientQueries_le {Guess : Type*} [Fintype Guess]
    (n c : ℕ) (hn : 0 < n) (stored : Guess → ℕ)
    (hcard : Fintype.card Guess ≤ Nat.clog 2 (n * a.K) + 1)
    (hstored : ∀ j, stored j ≤ n ^ 2) :
    let L := Nat.clog 2 (n * a.K) + 1
    let w := (n + 1).log2 + 1
    let δ := ((n : ℝ) ^ c)⁻¹
    let ω := min a.error (δ / 2)
    let S := parametricGradientSamples a.error (n ^ 2) L ω
    let Cg := c + 7 + (4 * (2 * (parametricGuessCountConstant a)) * (2 * a.K + 1) *
      (a.K + 2)).log2 + 1
    let C := 2 * (parametricGuessCountConstant a) * (2 * a.K + 1) * (8 * (16 * a.K) ^ 2 * Cg + 2)
    Fintype.card (Σ i : Guess,
      Fin (FiniteGreedy.stages NumericalCertificate.degree (stored i) a.error) ×
        Fin (stored i) × Fin S × Fin 2) ≤ C * (n + 1) ^ 10 * w ^ 2 := by
  intro L w δ ω S Cg C
  have hw : w ≤ 2 * (n + 1) := by
    have h := Nat.log2_le_self (n + 1)
    dsimp [w]
    omega
  have hL : L ≤ (parametricGuessCountConstant a) * w := parametricGuessCount_le a n
  have hcapL : L ≤ (2 * (parametricGuessCountConstant a)) * (n + 1) := by
    calc
      _ ≤ (parametricGuessCountConstant a) * w := hL
      _ ≤ (parametricGuessCountConstant a) * (2 * (n + 1)) := Nat.mul_le_mul_left _ hw
      _ = _ := by ring
  have hω := parametricConfidence_inv_le a n c hn
  have hS : S ≤ (8 * (16 * a.K) ^ 2 * Cg + 2) * (n + 1) ^ 4 * w :=
    (parametricSampleCounts_polynomial a.K a.K_pos hn hcapL ω hω.1 hω.2).2
  have h := parametricCompact_derivative_query_bound a L (n ^ 2) S stored hcard hstored
  have hn2 : n ^ 2 + 1 ≤ (n + 1) ^ 2 := by nlinarith only [Nat.zero_le n]
  have hm2 : n ^ 2 ≤ (n + 1) ^ 2 := Nat.pow_le_pow_left (Nat.le_succ _) _
  calc
    _ ≤ 2 * L * ((2 * a.K + 1) * (n ^ 2 + 1) ^ 2) * n ^ 2 * S := h
    _ ≤ 2 * ((parametricGuessCountConstant a) * w) * ((2 * a.K + 1) * ((n + 1) ^ 2) ^ 2) *
        ((n + 1) ^ 2) * ((8 * (16 * a.K) ^ 2 * Cg + 2) * (n + 1) ^ 4 * w) :=
      Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul_left _ hL)
        (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hn2 _))) hm2) hS
    _ = _ := by dsimp only [C]; ring

/-- The other queries count all per-arrival singleton and marginal calls,
one initial empty-set normalization, and one call per rounded candidate. -/
theorem parametricSourceAndRoundingQueries_le (n arrivals c : ℕ) (hn : 0 < n)
    (harrivals : arrivals ≤ n ^ 2) :
    let L := Nat.clog 2 (n * a.K) + 1
    let w := (n + 1).log2 + 1
    let δ := ((n : ℝ) ^ c)⁻¹
    let ω := min a.error (δ / 2)
    let Cs := c + 3 + (4 * (2 * (parametricGuessCountConstant a)) * (a.K + 2)).log2 + 1
    let C := 2 * (parametricGuessCountConstant a) * ((2 * a.K ^ 2) * Cs + 1) +
      (parametricGuessCountConstant a) * (parametricTrialCountConstant a c) + 2
    1 + arrivals + 2 * arrivals * L * parametricSourceSamples a.error n L ω + L * a.trials δ ≤
      C * (n + 1) ^ 6 * w ^ 2 := by
  intro L w δ ω Cs C
  have hw : w ≤ 2 * (n + 1) := by
    have hh := Nat.log2_le_self (n + 1)
    dsimp [w]
    omega
  have hw1 : 1 ≤ w := by dsimp [w]; omega
  have hL : L ≤ (parametricGuessCountConstant a) * w := parametricGuessCount_le a n
  have hcapL : L ≤ (2 * (parametricGuessCountConstant a)) * (n + 1) := by
    calc
      _ ≤ (parametricGuessCountConstant a) * (2 * (n + 1)) := hL.trans (Nat.mul_le_mul_left _ hw)
      _ = _ := by ring
  have hω := parametricConfidence_inv_le a n c hn
  have hS : parametricSourceSamples a.error n L ω ≤ ((2 * a.K ^ 2) * Cs + 1) * (n + 1) ^ 4 * w :=
    (parametricSampleCounts_polynomial a.K a.K_pos hn hcapL ω hω.1 hω.2).1
  have hT := parametricTrials_le a n c
  have ha := harrivals.trans (Nat.pow_le_pow_left (Nat.le_succ n) 2)
  have hN : 1 ≤ n + 1 := by omega
  have hN6 : 1 ≤ (n + 1) ^ 6 := one_le_pow₀ hN
  have hW : 1 ≤ w ^ 2 := one_le_pow₀ hw1
  have hmul : 1 ≤ (n + 1) ^ 6 * w ^ 2 := one_le_mul_of_one_le_of_one_le hN6 hW
  have ha' : arrivals ≤ (n + 1) ^ 6 * w ^ 2 := ha.trans
    ((Nat.pow_le_pow_right (by omega : 0 < n + 1) (by decide : (2 : ℕ) ≤ 6)).trans
      (Nat.le_mul_of_pos_right _ hW))
  have hsource : 2 * arrivals * L * parametricSourceSamples a.error n L ω ≤
      (2 * (parametricGuessCountConstant a) * ((2 * a.K ^ 2) * Cs + 1)) * (n + 1) ^ 6 * w ^ 2 := by
    calc
      _ ≤ 2 * (n + 1) ^ 2 * ((parametricGuessCountConstant a) * w) *
          (((2 * a.K ^ 2) * Cs + 1) * (n + 1) ^ 4 * w) :=
        Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul_left _ ha) hL) hS
      _ = _ := by ring
  have hround : L * a.trials δ ≤
      ((parametricGuessCountConstant a) * (parametricTrialCountConstant a c)) * (n + 1) ^ 6 * w ^ 2 := by
    calc
      _ ≤ ((parametricGuessCountConstant a) * w) * ((parametricTrialCountConstant a c) * w) :=
        Nat.mul_le_mul hL hT
      _ ≤ _ := by
        calc
          _ = ((parametricGuessCountConstant a) * (parametricTrialCountConstant a c)) * 1 * w ^ 2 := by ring
          _ ≤ _ := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ hN6)
  calc
    _ ≤ (n + 1) ^ 6 * w ^ 2 + (n + 1) ^ 6 * w ^ 2 + _ + _ :=
      Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hmul ha') hsource) hround
    _ = _ := by dsimp only [C]; ring


end

end SubmodularMatching.UpperBoundAssembly
