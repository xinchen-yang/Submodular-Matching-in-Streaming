import SubmodularMatching.FiniteShearerTapeCandidate
import SubmodularMatching.UpperBoundVertexCoordinates

/-!
# Retaining the compact optimizer endpoint

After solving one guess, keep two arrays of exact rounded numerators.
The rounding candidate and its executable word law can be recovered
from those arrays and the stored graph.
-/

namespace SubmodularMatching.UpperBoundAssembly

open Joint TwoStage LinearPacking NumericalCertificate
open scoped BigOperators

noncomputable section

structure CompactRoundedEndpoint (m : ℕ) where
  xNumerators : Array ℕ
  yNumerators : Array ℕ
  xSize : xNumerators.size = m
  ySize : yNumerators.size = m

/-- Both coordinate families contain one word per stored edge. -/
def CompactRoundedEndpoint.cells {m : ℕ} (data : CompactRoundedEndpoint m) : ℕ :=
  data.xNumerators.size + data.yNumerators.size

@[simp] theorem CompactRoundedEndpoint.cells_eq {m : ℕ} (data : CompactRoundedEndpoint m) :
    data.cells = 2*m := by
  simp only [CompactRoundedEndpoint.cells,data.xSize,data.ySize]
  omega

def compactRoundedXDenominator (vertices m : ℕ) : ℕ :=
  appendixShearerDenominator vertices m ^ 2 * appendixCompensatedDenominator m

def compactRoundedXIndex (vertices m : ℕ) (x : ℝ) : ℕ :=
  Int.toNat ⌊(compactRoundedXDenominator vertices m : ℝ)*x⌋

def CompactRoundedEndpoint.xIndex {m : ℕ} (data : CompactRoundedEndpoint m) (e : Fin m) : ℕ :=
  data.xNumerators[e.val]'(data.xSize.symm ▸ e.isLt)

def CompactRoundedEndpoint.yIndex {m : ℕ} (data : CompactRoundedEndpoint m) (e : Fin m) : ℕ :=
  data.yNumerators[e.val]'(data.ySize.symm ▸ e.isLt)

/-- Materialize both coordinate families, with no reference to the
optimizer draw in the retained type. -/
def retainCompactRoundedEndpoint {m : ℕ} (vertices : ℕ)
    (t : (Fin m → ℝ) × (Fin m → ℝ)) : CompactRoundedEndpoint m :=
  ⟨Array.ofFn (fun e : Fin m => compactRoundedXIndex vertices m (t.1 e)),
    Array.ofFn (appendixRoundedNumerators t.2 vertices),by simp,by simp⟩

@[simp] theorem retained_xIndex {m : ℕ} (vertices : ℕ)
    (t : (Fin m → ℝ) × (Fin m → ℝ)) (e : Fin m) :
    (retainCompactRoundedEndpoint vertices t).xIndex e = compactRoundedXIndex vertices m (t.1 e) := by
  simp [CompactRoundedEndpoint.xIndex,retainCompactRoundedEndpoint]

@[simp] theorem retained_yIndex {m : ℕ} (vertices : ℕ)
    (t : (Fin m → ℝ) × (Fin m → ℝ)) (e : Fin m) :
    (retainCompactRoundedEndpoint vertices t).yIndex e = appendixRoundedNumerators t.2 vertices e := by
  simp [CompactRoundedEndpoint.yIndex,retainCompactRoundedEndpoint]

def CompactRoundedEndpoint.decode {m : ℕ} (vertices : ℕ) (data : CompactRoundedEndpoint m) :
    (Fin m → ℝ) × (Fin m → ℝ) :=
  (fun e => (data.xIndex e : ℝ)/compactRoundedXDenominator vertices m,
    fun e => (data.yIndex e : ℝ)/appendixShearerDenominator vertices m)

private theorem roundXIndex_decodes {vertices m : ℕ} (hm : 0 < m) {x : ℝ}
    (hx : 0 ≤ x) (hgrid : OnGrid (compactRoundedXDenominator vertices m) x) :
    (compactRoundedXIndex vertices m x : ℝ)/compactRoundedXDenominator vertices m = x := by
  let D := compactRoundedXDenominator vertices m
  have hD : 0 < D := by
    unfold D compactRoundedXDenominator appendixCompensatedDenominator
    exact Nat.mul_pos (pow_pos (appendixShearerDenominator_pos vertices m hm) _) (by positivity)
  have hR : 0 < (D:ℝ) := by exact_mod_cast hD
  obtain ⟨a,ha⟩ := hgrid
  have hA : 0 ≤ a := by exact_mod_cast (ha ▸ mul_nonneg hR.le hx : 0 ≤ (a:ℝ))
  unfold compactRoundedXIndex
  rw [ha,Int.floor_intCast,← Int.cast_natCast (R := ℝ),Int.toNat_of_nonneg hA]
  exact (div_eq_iff hR.ne').mpr (ha.symm.trans (mul_comm _ _))

variable {m N : ℕ} {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Exact equality of the packed and original optimizer endpoints. -/
theorem retainCompactRoundedEndpoint_decode [Fintype V] (hm : 0 < m) (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N) :
    let v := Fintype.card V
    let t := appendixRoundedPoint ends tau w f Q draw
    (retainCompactRoundedEndpoint v t).decode v = t := by
  intro v t
  have hFeas := appendixRoundedPoint_feasible hm ends hloop tau w f Q draw
  have hGrid (e : Fin m) := appendixRoundedPoint_xy_grids hm ends hloop tau w f Q draw e
  apply Prod.ext
  · funext e
    change ((retainCompactRoundedEndpoint v t).xIndex e:ℝ)/compactRoundedXDenominator v m = t.1 e
    rw [retained_xIndex]
    exact roundXIndex_decodes hm (hFeas.x_nonneg e) (hGrid e).2.1
  · funext e
    change ((retainCompactRoundedEndpoint v t).yIndex e:ℝ)/appendixShearerDenominator v m = t.2 e
    rw [retained_yIndex]
    exact congrFun (appendixRoundedNumerators_exact t.2 v hm hFeas.y_nonneg (fun i => (hGrid i).1)) e

/-- The sampler uses only stored endpoints, edge IDs, and the retained
point. The proof fields certify the same feasible common-grid point. -/
def compactGuessFromRetained (hm : 0 < m) (emb : Fin m ↪ E) (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (data : CompactRoundedEndpoint m)
    (hFeas : let ep := restrictEnds (ends ∘ emb)
      let t := data.decode (Fintype.card (IncidentVertex (ends ∘ emb)))
      Feasible coordinateCap NumericalCertificate.degree ep ep t.1 t.2)
    (hGrid : let n := Fintype.card (IncidentVertex (ends ∘ emb))
      ∀ e, OnGrid (appendixShearerDenominator n m) ((data.decode n).2 e)) :
    CandidateLaw (Finset E) :=
  let ep := restrictEnds (ends ∘ emb)
  let t := data.decode (Fintype.card (IncidentVertex (ends ∘ emb)))
  (appendixRoundingCandidate hm ep (restrictEnds_loopless _ (fun i => hloop (emb i)))
    (incidentVertex_card_pos hm _) t.1 t.2 hFeas hGrid).map (Finset.map emb)

private theorem appendixRoundingCandidate_congr_point [Fintype V]
    (hm : 0 < m) (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hv : 0 < Fintype.card V)
    (t t' : (Fin m → ℝ) × (Fin m → ℝ)) (h : t = t')
    (hf : Feasible coordinateCap NumericalCertificate.degree ends ends t.1 t.2)
    (hg : ∀ e, OnGrid (appendixShearerDenominator (Fintype.card V) m) (t.2 e))
    (hf' : Feasible coordinateCap NumericalCertificate.degree ends ends t'.1 t'.2)
    (hg' : ∀ e, OnGrid (appendixShearerDenominator (Fintype.card V) m) (t'.2 e)) :
    appendixRoundingCandidate hm ends hloop hv t.1 t.2 hf hg =
      appendixRoundingCandidate hm ends hloop hv t'.1 t'.2 hf' hg' := by
  subst t'
  rfl

/-- After materializing the two coordinate arrays, every resampling can
drop the full optimizer tape without changing the candidate law. -/
theorem compactAppendixGuessCandidate_factor_endpoint (hm : 0 < m) (emb : Fin m ↪ E)
    (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (tau : ℝ) (w : E → ℝ) (f : Finset E → ℝ) (Q : ℕ) (draw : AppendixDraw m N) :
    let ep := restrictEnds (ends ∘ emb)
    let n := Fintype.card (IncidentVertex (ends ∘ emb))
    let t := appendixRoundedPoint ep tau (w ∘ emb) (reindexedObjective emb f) Q draw
    let data := retainCompactRoundedEndpoint n t
    ∃ (hF : Feasible coordinateCap NumericalCertificate.degree ep ep
          (data.decode n).1 (data.decode n).2)
      (hG : ∀ e, OnGrid (appendixShearerDenominator n m) ((data.decode n).2 e)),
      data.cells = 2*m ∧
        compactAppendixGuessCandidate hm emb ends hloop tau w f Q draw =
          compactGuessFromRetained hm emb ends hloop data hF hG := by
  intro ep n t data
  let hlo := restrictEnds_loopless (ends ∘ emb) (fun i => hloop (emb i))
  let hv := incidentVertex_card_pos hm (ends ∘ emb)
  have hEq : data.decode n = t := retainCompactRoundedEndpoint_decode hm ep hlo tau
    (w ∘ emb) (reindexedObjective emb f) Q draw
  have hF : Feasible coordinateCap NumericalCertificate.degree ep ep t.1 t.2 :=
    appendixRoundedPoint_feasible hm ep hlo tau (w ∘ emb) (reindexedObjective emb f) Q draw
  have hG := appendixRoundedPoint_y_grid hm ep tau (w ∘ emb) (reindexedObjective emb f) Q draw
  have hFeas : Feasible coordinateCap NumericalCertificate.degree ep ep (data.decode n).1 (data.decode n).2 :=
    hEq.symm ▸ hF
  have hGrid : ∀ e, OnGrid (appendixShearerDenominator n m) ((data.decode n).2 e) :=
    hEq.symm ▸ hG
  refine ⟨hFeas,hGrid,data.cells_eq,?_⟩
  exact congrArg (fun q : CandidateLaw (Finset (Fin m)) => q.map (Finset.map emb))
    (appendixRoundingCandidate_congr_point hm ep hlo hv t (data.decode n) hEq.symm hF hG hFeas hGrid)

/-- The same retained point is sufficient for the actual finite-word
execution, including all conditional Gibbs stages. -/
theorem compactAppendixTapeOutcomeMass_factor_endpoint (hm : 0 < m)
    (ends : Fin m → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ)
    (draw : AppendixDraw m N) (M : Finset (Fin m)) :
    let n := Fintype.card (IncidentVertex ends)
    let t := appendixRoundedPoint (restrictEnds ends) tau w f Q draw
    let data := retainCompactRoundedEndpoint n t
    compactAppendixTapeOutcomeMass hm ends tau w f Q draw M =
      compactPointTapeOutcomeMass hm ends (data.decode n) M := by
  intro n t data
  have h := retainCompactRoundedEndpoint_decode hm (restrictEnds ends) (restrictEnds_loopless ends hloop)
    tau w f Q draw
  exact congrArg (fun p => compactPointTapeOutcomeMass hm ends p M) h.symm


/-- The stored coordinate indices are bounded by the common denominators,
so the existing grid magnitude bounds also cover actual array cells. -/
theorem retainCompactRoundedEndpoint_word_bounds [Fintype V] (hm : 0 < m)
    (ends : Fin m → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends))
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ)
    (draw : AppendixDraw m N) (e : Fin m) :
    let n := Fintype.card V
    let t := appendixRoundedPoint ends tau w f Q draw
    let data := retainCompactRoundedEndpoint n t
    data.xIndex e ≤ compactRoundedXDenominator n m ∧
      data.yIndex e ≤ appendixShearerDenominator n m := by
  intro n t data
  have h := appendixRounding_coordinateNumerators hm ends hloop hsimple tau w f Q draw ∅ e
  obtain ⟨⟨y,hy,hyVal⟩,⟨x,hx,hxVal⟩,-⟩ := h
  have hXP : (compactRoundedXDenominator n m : ℝ)*t.1 e = (x:ℝ) := hxVal
  have hYP : (appendixShearerDenominator n m : ℝ)*t.2 e = (y:ℝ) := hyVal
  constructor
  · change (retainCompactRoundedEndpoint n t).xIndex e ≤ _
    rw [retained_xIndex,compactRoundedXIndex,hXP,Int.floor_natCast,Int.toNat_natCast]
    exact hx
  · change (retainCompactRoundedEndpoint n t).yIndex e ≤ _
    rw [retained_yIndex,appendixRoundedNumerators,hYP,Int.floor_natCast,Int.toNat_natCast]
    exact hy

/-- Simultaneous endpoint storage across guesses adds exactly two index
cells per stored edge instance. -/
theorem retainedEndpoints_cells {Guess : Type*} [Fintype Guess] (stored : Guess → ℕ)
    (data : ∀ i, CompactRoundedEndpoint (stored i)) :
    (∑ i, (data i).cells) = 2*(∑ i, stored i) := by
  simp only [CompactRoundedEndpoint.cells_eq,Finset.mul_sum]

end

end SubmodularMatching.UpperBoundAssembly
