import SubmodularMatching.NonmonotoneRetainedRuntimeFacts
import SubmodularMatching.NonmonotoneRegisterTrial
import SubmodularMatching.NonmonotoneRowFeasible

/-! The retained graph's rounding row reads the optimizer registers.
Finite rational arithmetic checks their encoding and packing constraints. -/
namespace SubmodularMatching.AppendixM.RetainedRuntime
open Capacity Finset Streaming NonmonotoneOptimizer NonmonotoneCandidate NonmonotoneLayers
  TwoLayerDiffuse Shearer UpperBoundAssembly GibbsSampler
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream E V} {b : V→ℕ} {records : List (E×ℕ)} (R : RetainedRuntime S b records)

private def RationalFeasible {r l : ℕ} (G : PackingGrid r l) (x : Vec l) : Prop :=
  (∀ i, 0 ≤ atRat x i ∧ atRat x i ≤ 1) ∧
    ∀ j, (∑ i, ((G.entry j i:ℚ)/G.den)*atRat x i) ≤ 1

private instance {r l : ℕ} (G : PackingGrid r l) (x : Vec l) : Decidable (RationalFeasible G x) := by
  unfold RationalFeasible
  infer_instance

private theorem rationalFeasible_iff {r l : ℕ} (G : PackingGrid r l) (x : Vec l) :
    RationalFeasible G x ↔ NonmonotoneOptimizer.feasible G.entry G.den (coordinates x) := by
  unfold RationalFeasible NonmonotoneOptimizer.feasible
  constructor
  · intro ⟨hx,hh⟩
    refine ⟨fun i => ⟨?_,?_⟩,?_⟩
    · change (0:ℝ) ≤ (atRat x i:ℝ)
      exact_mod_cast (hx i).1
    · change ((atRat x i:ℚ):ℝ) ≤ 1
      exact_mod_cast (hx i).2
    · intro j
      unfold LinearPacking.load NonmonotoneOptimizer.matrix coordinates
      exact_mod_cast hh j
  · intro ⟨hx,hh⟩
    refine ⟨fun i => ⟨?_,?_⟩,?_⟩
    · have h := (hx i).1
      dsimp [coordinates] at h
      exact_mod_cast h
    · have h := (hx i).2
      dsimp [coordinates] at h
      exact_mod_cast h
    · intro j
      have h := hh j
      unfold LinearPacking.load NonmonotoneOptimizer.matrix coordinates at h
      exact_mod_cast h

private def EncodedBest (x : Vec R.l) : Prop :=
  (∀ j, atRat x j = (BlockData.stateNumerator R.l x j:ℚ)/BlockData.bestDen R.l) ∧
    RationalFeasible R.grid x

private instance (x : Vec R.l) : Decidable (R.EncodedBest x) := by
  unfold EncodedBest
  infer_instance

private def registerShape (q : ℕ) (hb : ∀ i,0<b i) (best : Vec R.l)
    (hw : R.EncodedBest best) : GridRow R.graph b :=
  GridRow.ofCoordinates R.graph b hb R.left R.right R.rows R.cols (optimizerRowBits R.l) R.hm
    R.hl (paperExponent R.l) q (BlockData.bestDen R.l) (by unfold BlockData.bestDen; positivity)
    (atRat best) (BlockData.stateNumerator R.l best) hw.1 ((rationalFeasible_iff _ _).1 hw.2)

private def registerSampler (hb : ∀ i,0<b i) (rank : Slots b ↪ ℕ)
    (f : Finset E→ℝ) (τ : ℝ) (g : GridRow R.graph b) : CandidateLaw (Finset E) :=
  letI : NeZero (records.map Prod.fst).length := ⟨R.nonempty.ne'⟩
  letI : LinearOrder (↑(records.map Prod.fst).toFinset) := R.tieOrder
  (g.trial hb rank (R.enum 0) (retainedChronological _ R.nodup) (records.map Prod.fst).length τ
    (retainedObjective _ f)).map (fun U => U.image Subtype.val)

def registerRow (q : ℕ) (hb : ∀ i,0<b i) (rank : Slots b ↪ ℕ)
    (f : Finset E→ℝ) (τ : ℝ) (r : Option (Registers R.l)) : CandidateLaw (Finset E) :=
  match r with
  | none => CandidateLaw.pure ∅
  | some st =>
    if hw : R.EncodedBest st.bestState then
      R.registerSampler hb rank f τ (R.registerShape q hb st.bestState hw)
    else CandidateLaw.pure ∅

abbrev probabilities (_ : RetainedRuntime S b records) : ℕ→ℝ := fun _ => sourceProbability

theorem probabilities_valid : ∀ j < (records.map Prod.fst).length,
    0≤R.probabilities j ∧ R.probabilities j≤1 := by
  intro _ _
  norm_num [probabilities,sourceProbability]

set_option maxRecDepth 4096 in
set_option maxHeartbeats 1200000 in
theorem registerRow_return (v q : ℕ) (hb : ∀ i,0<b i) (rank : Slots b ↪ ℕ)
    (hw : R.Bounded v) (f : Finset E→ℝ) (τ : ℝ) {J : ℕ} (W : R.Words J) :
    letI : NeZero (records.map Prod.fst).length := ⟨R.nonempty.ne'⟩
    let h := fun i => (records.map Prod.fst).getD i (R.enum 0).val
    let A := (R.block v).paperAnswers h R.probabilities (records.map Prod.fst).length f τ R.probabilities_valid W
    let returned := (R.block v).candidateRun R.grid (paperExponent R.l) A (ascentFuel (paperExponent R.l))
    R.registerRow q hb rank f τ (some returned) = R.physicalRow v q hb rank hw f τ W := by
  intro h A returned
  letI : NeZero (records.map Prod.fst).length := ⟨R.nonempty.ne'⟩
  have hc : 0 < (R.block v).c := by norm_num [RetainedRuntime.block,retainedBlock]
  have good := (R.block v).returned_best_words R.grid h R.probabilities _ R.probabilities_valid f τ W hc rfl hw
  have feas := (R.block v).returned_best_feasible R.grid h R.probabilities _ R.probabilities_valid f τ W hc rfl hw
  have hguard : R.EncodedBest returned.bestState :=
    ⟨fun j => (good j).2,(rationalFeasible_iff _ _).2 feas⟩
  unfold registerRow
  dsimp only
  rw [dif_pos hguard]
  rfl

def indexedRetainedRegisters (v q : ℕ) (hb : ∀ i,0<b i) (rank : Slots b ↪ ℕ)
    (f : Finset E→ℝ) (J : ℕ) (τ : ℝ) : CandidateLaw (Finset E) := by
  classical
  letI : NeZero (records.map Prod.fst).length := ⟨R.nonempty.ne'⟩
  let h := fun i => (records.map Prod.fst).getD i (R.enum 0).val
  exact if R.Bounded v then
    registerTrial (R.block v) R.grid h R.probabilities R.probabilities_valid f τ J (R.registerRow q hb rank f τ)
  else CandidateLaw.pure ∅

set_option maxRecDepth 4096 in
set_option maxHeartbeats 1200000 in
theorem indexedRetainedRegisters_observe (v q : ℕ) (hb : ∀ i,0<b i) (rank : Slots b ↪ ℕ)
    (f test : Finset E→ℝ) (J : ℕ) (τ : ℝ) :
    let reg := R.indexedRetainedRegisters v q hb rank f J τ
    let raw := R.indexedRetainedProgram v q hb rank f J τ
    expected reg.outcomes reg.mass test = expected raw.outcomes raw.mass test := by
  classical
  dsimp only
  unfold indexedRetainedRegisters indexedRetainedProgram
  by_cases hw : R.Bounded v
  · rw [if_pos hw,dif_pos hw]
    letI : NeZero (records.map Prod.fst).length := ⟨R.nonempty.ne'⟩
    let h := fun i => (records.map Prod.fst).getD i (R.enum 0).val
    let metric := fun r => expected (R.registerRow q hb rank f τ r).outcomes
      (R.registerRow q hb rank f τ r).mass test
    let action := fun W : R.Words J => expected (R.physicalRow v q hb rank hw f τ W).outcomes
      (R.physicalRow v q hb rank hw f τ W).mass test
    let B := R.block v
    let T := ascentFuel (paperExponent R.l)
    have eq : (fun a : R.Words J × Bool => metric
        (some (B.candidateRun R.grid (paperExponent R.l)
          (B.paperAnswers h R.probabilities (records.map Prod.fst).length f τ R.probabilities_valid a.1) T))) =
        fun a : R.Words J×Bool => action a.1 := by
      funext a
      dsimp only [metric,action,B,T]
      rw [R.registerRow_return v q hb rank hw f τ a.1]
    have H := B.marked_register_expectation R.grid h R.probabilities R.probabilities_valid f τ J metric
    have K := B.markedOptimizer_observable R.grid h R.probabilities R.probabilities_valid f τ J action
    dsimp only at H
    rw [eq] at H
    unfold registerTrial optimizerTrial
    rw [CandidateLaw.bind_expected,CandidateLaw.bind_expected]
    exact H.symm.trans K
  · rw [if_neg hw,dif_neg hw]

set_option maxRecDepth 4096 in
set_option maxHeartbeats 1500000 in
private theorem registerSampler_feasible (hb : ∀ i,0<b i) (rank : Slots b ↪ ℕ)
    (f : Finset E→ℝ) (τ : ℝ) (g : GridRow R.graph b) :
    ∀ M∈(R.registerSampler hb rank f τ g).outcomes, Capacity.feasible S.ends b M := by
  classical
  letI : NeZero (records.map Prod.fst).length := ⟨R.nonempty.ne'⟩
  letI : LinearOrder (↑(records.map Prod.fst).toFinset) := R.tieOrder
  dsimp only [registerSampler]
  apply feasible_retained_law
  exact g.trial_feasible_all hb rank (R.enum 0) (retainedChronological _ R.nodup)
    (records.map Prod.fst).length τ (retainedObjective _ f)

theorem registerRow_feasible (q : ℕ) (hb : ∀ i,0<b i) (rank : Slots b ↪ ℕ)
    (f : Finset E→ℝ) (τ : ℝ) (reg : Option (Registers R.l)) :
    ∀ M∈(R.registerRow q hb rank f τ reg).outcomes, Capacity.feasible S.ends b M := by
  classical
  have empty : ∀ M∈(CandidateLaw.pure (∅ : Finset E)).outcomes, Capacity.feasible S.ends b M := by
    intro M h
    have h0 : M=∅ := by simpa [CandidateLaw.pure] using h
    subst M
    intro v
    simp [incidences]
  cases reg with
  | none => exact empty
  | some st =>
    unfold registerRow
    dsimp only
    split
    · exact R.registerSampler_feasible hb rank f τ _
    · exact empty

set_option maxRecDepth 4096 in
set_option maxHeartbeats 1000000 in
theorem indexedRetainedRegisters_feasible (v q : ℕ) (hb : ∀ i,0<b i)
    (rank : Slots b ↪ ℕ) (f : Finset E→ℝ) (J : ℕ) (τ : ℝ) :
    ∀ M∈(R.indexedRetainedRegisters v q hb rank f J τ).outcomes, Capacity.feasible S.ends b M := by
  classical
  letI : NeZero (records.map Prod.fst).length := ⟨R.nonempty.ne'⟩
  unfold indexedRetainedRegisters
  dsimp only
  split
  · exact registerTrial_support _ _ _ _ _ _ _ _ _ _ (R.registerRow_feasible q hb rank f τ)
  · intro M h
    have he : M=∅ := by simpa [CandidateLaw.pure] using h
    subst M
    intro v
    simp [incidences]

end
end SubmodularMatching.AppendixM.RetainedRuntime
