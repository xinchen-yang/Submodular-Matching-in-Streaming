import SubmodularMatching.ProjectedShearerLayers
import SubmodularMatching.ShearerCovariance
import Mathlib.Analysis.SpecialFunctions.Log.Basic

/-! Tail probability for aborting an implicit slot-layer sample, Appendix M.4. -/

namespace SubmodularMatching.Shearer
open GibbsMatching
open scoped BigOperators
noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem layer_size_mgf (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (law : InteriorLaw ends S x) (t : ℝ) (ht : 0 ≤ t) :
    expectation ends S x (fun M => (1+t)^M.card) ≤ Real.exp (t * S.sum x) := by
  have hid (M : Finset E) (hM : M ∈ matchings ends S) :
      (1+t)^M.card = ∑ T ∈ S.powerset, if T ⊆ M then t^T.card else 0 := by
    have hs := (mem_matchings ends S M).mp hM |>.1
    have hp : S.powerset.filter (fun T => T ⊆ M) = M.powerset := by
      ext T
      simp only [Finset.mem_filter, Finset.mem_powerset]
      exact ⟨And.right, fun h => ⟨h.trans hs,h⟩⟩
    rw [← Finset.sum_filter, hp]
    simpa using (Finset.prod_one_add (s := M) (f := fun _ => t))
  rw [expectation_congr ends S x _ _ hid, expectation_sum]
  calc
    _ ≤ ∑ T ∈ S.powerset, ∏ e ∈ T, t * x e := by
      apply Finset.sum_le_sum
      intro T hT
      have heq : (fun M : Finset E => if T ⊆ M then t^T.card else 0) =
          fun M => t^T.card * (if T ⊆ M then 1 else 0) := by funext M; split_ifs <;> simp
      rw [heq, expectation_const_mul, joint_moment, Finset.prod_mul_distrib]
      simp only [Finset.prod_const]
      by_cases h : T ∈ matchings ends S
      · simp [h,weight]
      · simp only [if_neg h, mul_zero]
        exact mul_nonneg (pow_nonneg ht _) (Finset.prod_nonneg (fun e he =>
          law.coordinate_nonneg e (Finset.mem_powerset.mp hT he)))
    _ = ∏ e ∈ S, (1 + t*x e) := (Finset.prod_one_add S).symm
    _ ≤ ∏ e ∈ S, Real.exp (t*x e) := by
      apply Finset.prod_le_prod
      · intro e he
        positivity [mul_nonneg ht (law.coordinate_nonneg e he)]
      · intro e _
        linarith [Real.add_one_le_exp (t*x e)]
    _ = _ := by rw [← Real.exp_sum, Finset.mul_sum]

theorem layer_size_tail (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (law : InteriorLaw ends S x) (k : ℕ) (t : ℝ) (ht : 0 ≤ t) :
    expectation ends S x (fun M => if k ≤ M.card then 1 else 0) ≤
      Real.exp (t * S.sum x) / (1+t)^k := by
  apply (le_div_iff₀ (pow_pos (by linarith : 0 < 1+t) _)).2
  rw [← expectation_mul_const]
  apply le_trans _ (layer_size_mgf ends S x law t ht)
  apply law.expectation_le
  intro M _
  by_cases h : k ≤ M.card
  · simp only [h, if_true, one_mul]
    exact pow_le_pow_right₀ (by linarith) h
  · simp only [h, if_false, zero_mul]
    positivity

/-- A cap linear in the total activity and in the log inverse failure budget.
Only `k` selected copies need to be stored before aborting. -/
theorem layer_abort_budget (ends : E → Finset V) (S : Finset E) (x : E → ℝ)
    (law : InteriorLaw ends S x) (k : ℕ) (δ : ℝ) (hδ : 0 < δ)
    (hk : S.sum x + Real.log (1/δ) ≤ k * Real.log 2) :
    expectation ends S x (fun M => if k ≤ M.card then 1 else 0) ≤ δ := by
  have ht := layer_size_tail ends S x law k 1 (by norm_num)
  norm_num only [one_mul, one_add_one_eq_two] at ht
  apply ht.trans
  apply (div_le_iff₀ (by positivity : 0 < (2:ℝ)^k)).2
  have he : (2:ℝ)^k = Real.exp ((k:ℝ)*Real.log 2) := by
    rw [Real.exp_nat_mul, Real.exp_log (by norm_num : (0:ℝ) < 2)]
  rw [he, ← Real.exp_log hδ, ← Real.exp_add]
  apply Real.exp_le_exp.mpr
  rw [one_div, Real.log_inv] at hk
  linarith

end
end SubmodularMatching.Shearer
