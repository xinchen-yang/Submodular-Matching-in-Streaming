import SubmodularMatching.ReplayRateLookup
import SubmodularMatching.CertificateHullConeData
import SubmodularMatching.ReplayHardNextRightPart00023

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

theorem checked : AppendixBoxGoal false false ⟨54864, 55079, 0, 1135, 0, 1135⟩ :=
  Part00023 (fun z _ => runRegion_valid quickRow quickRow_eq quickRow_boundary z)
    appendixFastConeAt_sufficient

#print axioms checked

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
