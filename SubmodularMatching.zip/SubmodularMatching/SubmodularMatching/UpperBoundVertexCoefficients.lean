import SubmodularMatching.UpperBoundVertexResources
import SubmodularMatching.UpperBoundSourceProgram
import SubmodularMatching.PackingResourcesSparse

/-! # Integer coefficients in an actual compact direction solve -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint Streaming TwoStage NumericalCertificate
open LinearPacking (OnGrid)

noncomputable section

variable {m N : ℕ} {V : Type*} [DecidableEq V]

private theorem grid_scale_denominator {d : ℕ} {x : ℝ} (h : OnGrid d x) (a : ℕ) :
    OnGrid (a * d) x := by
  simpa only [Int.cast_one, one_mul] using (OnGrid.integer a 1).mul h

/-- The constant joint matrix has this single integer scale. -/
def appendixPackingMatrixDenominator : ℕ := 10 ^ 48 * 62500000000000000000000

private theorem appendixPackingMatrix_grid (ends : Fin m → V × V) :
    ∀ row col, OnGrid appendixPackingMatrixDenominator
      (matrix coordinateCap NumericalCertificate.degree ends ends row col) := by
  apply matrix_grid
  · have hp : OnGrid (10 ^ 48) coordinateCap := ⟨1, by norm_num [coordinateCap]⟩
    simpa only [appendixPackingMatrixDenominator, Nat.mul_comm] using
      grid_scale_denominator hp 62500000000000000000000
  · have hD : OnGrid 62500000000000000000000 NumericalCertificate.degree :=
      ⟨15609923359958673284671, by norm_num [degree_exact]⟩
    exact grid_scale_denominator hD (10 ^ 48)

/-- Frozen incoming weights are relative to the guess's original scale. -/
theorem appendixFrozenWeight_grid (n : ℕ) (hn : 2 ≤ n) (tau : ℝ) (htau : 0 < tau) (a : ℕ) :
    let C := appendixGuessConfig n hn tau
    OnGrid (10000000000 * n ^ 2) (C.gap * a / C.tau) := by
  intro C
  obtain ⟨ht, _, hd, _⟩ := appendixGuessConfig_spec n hn tau htau
  change C.tau = tau at ht
  change C.gap = finiteError * tau / (n : ℝ) ^ 2 at hd
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast (show n ≠ 0 by omega)
  refine ⟨a, ?_⟩
  rw [ht, hd]
  push_cast
  norm_num [finiteError]
  field_simp [hn', htau.ne']

/-- A denominator proportional to the stored size works in either branch
of the prescribed derivative precision. -/
def appendixAccuracyDenominator (m : ℕ) : ℕ := 4 * (160000000000 * 15609923359958673284671 * m)

theorem appendixAccuracy_rat {m : ℕ} (hm : 0 < m) :
    0 < appendixAccuracyDenominator m ∧ ∃ a : ℕ,
      FiniteGreedy.accuracy NumericalCertificate.degree m finiteError =
        (a : ℝ) / appendixAccuracyDenominator m := by
  let d := 160000000000 * 15609923359958673284671 * m
  have hd : 0 < d := by dsimp [d]; positivity
  have hd' : (d : ℝ) ≠ 0 := by exact_mod_cast hd.ne'
  have hm' : (m : ℝ) ≠ 0 := by exact_mod_cast hm.ne'
  refine ⟨Nat.mul_pos (by decide) hd, ?_⟩
  unfold FiniteGreedy.accuracy
  rcases le_total (1 / 4 : ℝ) (finiteError / (16 * NumericalCertificate.degree * m)) with h | h
  · refine ⟨d, ?_⟩
    rw [min_eq_left h]
    change (1 / 4 : ℝ) = (d : ℝ) / ((4 * d : ℕ) : ℝ)
    push_cast
    field_simp [hd']
  · refine ⟨4 * 62500000000000000000000, ?_⟩
    rw [min_eq_right h]
    unfold appendixAccuracyDenominator
    push_cast
    norm_num [finiteError, degree_exact]
    field_simp [hm']
    norm_num

private theorem clip_div_scale (tau a : ℝ) (htau : 0 < tau) :
    LinearPacking.clip tau a / tau = LinearPacking.clip 1 (a / tau) := by
  unfold LinearPacking.clip
  rw [← min_div_div_right htau.le, ← max_div_div_right htau.le, div_self htau.ne', zero_div]

/-- After dividing by the guess scale, both kinds of direction coefficient
are integral indices. The bound is independent of the empirical outcomes. -/
theorem appendixSampledCoefficient_grid (hm : 0 < m) (hN : 0 < N) (tau : ℝ) (htau : 0 < tau)
    (w : Fin m → ℝ) (W : ℕ) (hw : ∀ e, OnGrid W (w e / tau))
    (f : Finset (Fin m) → ℝ) (Q : ℕ) (hQ : 0 < Q) (draw : AppendixDraw m N)
    (j : ℕ) (t : Fin m ⊕ Fin m → ℝ) (i : Fin m ⊕ Fin m) :
    let H := Q * 8 * N * appendixAccuracyDenominator m
    OnGrid (appendixPackingMatrixDenominator * (W * H))
      (sampledCoefficient coordinateCap NumericalCertificate.degree tau w
        (oracleCoefficient NumericalCertificate.degree tau finiteError Q f draw) j t i) := by
  intro H
  obtain ⟨hden, a, haccuracy⟩ := appendixAccuracy_rat hm
  let estimate := oracleCoefficient NumericalCertificate.degree tau finiteError Q f draw
  have hg (e : Fin m) : OnGrid H (estimate j t e / tau) :=
    oracleCoefficient_normalized_grid _ _ _ Q a _ htau hQ hden hN haccuracy f draw j t e
  have hp : OnGrid appendixPackingMatrixDenominator coordinateCap := by
    have hp0 : OnGrid (10 ^ 48) coordinateCap := ⟨1, by norm_num [coordinateCap]⟩
    simpa only [appendixPackingMatrixDenominator, Nat.mul_comm] using
      grid_scale_denominator hp0 62500000000000000000000
  have hD : OnGrid appendixPackingMatrixDenominator NumericalCertificate.degree :=
    grid_scale_denominator (show OnGrid 62500000000000000000000 NumericalCertificate.degree from
      ⟨15609923359958673284671, by norm_num [degree_exact]⟩) (10 ^ 48)
  rcases i with e | e
  · simp only [sampledCoefficient, directionCoefficient, one_mul, mul_div_assoc]
    exact hp.mul (by simpa only [Nat.mul_comm] using grid_scale_denominator (hw e) H)
  · simp only [sampledCoefficient, directionCoefficient, one_mul, mul_div_assoc, clip_div_scale tau _ htau]
    have hc : OnGrid H (LinearPacking.clip 1 (estimate j t e / tau)) :=
      OnGrid.clip (by simpa only [Int.cast_one] using OnGrid.integer H 1) (hg e)
    exact hD.mul (grid_scale_denominator hc W)

/-- Reading a grid numerator by flooring is exact. This can be used for
implicit matrix entries or for the current coefficient array. -/
def appendixGridIndex (denominator : ℕ) (x : ℝ) : ℤ := ⌊(denominator : ℝ) * x⌋

theorem appendixGridIndex_exact (d : ℕ) (hd : 0 < d) {x : ℝ} (hx : OnGrid d x) :
    (appendixGridIndex d x : ℝ) / d = x := by
  obtain ⟨a, ha⟩ := hx
  have hd' : (d : ℝ) ≠ 0 := by exact_mod_cast hd.ne'
  rw [appendixGridIndex, ha, Int.floor_intCast, ← ha, mul_comm, mul_div_cancel_right₀ _ hd']

/-- In the compact exact-grid encoding, the integer direction program
returns the very coordinates used by the real-valued optimizer proof. -/
theorem compactAppendixIntegerDirection_eq (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (htau : 0 < tau) (w : Fin m → ℝ) (W : ℕ) (hW : 0 < W)
    (hw : ∀ e, OnGrid W (w e / tau)) (hN : 0 < N) (f : Finset (Fin m) → ℝ)
    (Q : ℕ) (hQ : 0 < Q) (draw : AppendixDraw m N) (j : ℕ) (t : Fin m ⊕ Fin m → ℝ)
    (i : Fin m ⊕ Fin m) :
    let A := matrix coordinateCap NumericalCertificate.degree (restrictEnds ends) (restrictEnds ends)
    let c := sampledCoefficient coordinateCap NumericalCertificate.degree tau w
      (oracleCoefficient NumericalCertificate.degree tau finiteError Q f draw) j t
    let M := Fintype.card (IncidentVertex ends ⊕ IncidentVertex ends ⊕ Fin m)
    let L := Fintype.card (Fin m ⊕ Fin m)
    let a := appendixPackingMatrixDenominator
    let b := 80000000000
    let cden := a * (W * (Q * 8 * N * appendixAccuracyDenominator m))
    let P := 2 * b * M * L ^ 2 * a
    let R := Nat.ceil (4 * (L : ℝ) ^ 2 / (finiteError / 8))
    let J := LinearPacking.iterationCount M L (finiteError / 8)
    let state := LinearPacking.integerRun (fun row col => appendixGridIndex a (A row col))
      (fun col => appendixGridIndex cden (c col)) a P cden R 1 J
    LinearPacking.solve A c (finiteError / 8) i =
      ((state.accumulator i * (2 * L * b) : ℕ) : ℝ) /
        LinearPacking.rationalOutputDenominator M L 1 b := by
  intro A c M L a b cden P R J state
  have ha : 0 < a := by dsimp [a, appendixPackingMatrixDenominator]; positivity
  have hb : 0 < b := by decide
  have hc : 0 < cden := by
    have hd := (appendixAccuracy_rat hm).1
    dsimp only [cden]
    positivity
  have hM : 0 < M := by dsimp [M]; simp only [Fintype.card_sum, Fintype.card_fin]; omega
  have hL : 0 < L := by dsimp [L]; simp only [Fintype.card_sum, Fintype.card_fin]; omega
  have hA : (fun row col => (appendixGridIndex a (A row col) : ℝ) / a) = A := by
    funext row col
    exact appendixGridIndex_exact _ ha (appendixPackingMatrix_grid (restrictEnds ends) row col)
  have hcg : (fun col => (appendixGridIndex cden (c col) : ℝ) / cden) = c := by
    funext col
    exact appendixGridIndex_exact _ hc (appendixSampledCoefficient_grid hm hN tau htau w W hw f Q hQ draw j t col)
  have he : (finiteError / 8) = ((1 : ℕ) : ℝ) / (b : ℝ) := by norm_num [finiteError, b]
  have h := LinearPacking.integerPacking_output_eq
    (fun row col => appendixGridIndex a (A row col)) (fun col => appendixGridIndex cden (c col))
    a cden 1 b ha hc (by decide) hb (by decide) hM hL i
  dsimp only at h
  rw [hA, hcg, ← he] at h
  exact h

end

end SubmodularMatching.UpperBoundAssembly
