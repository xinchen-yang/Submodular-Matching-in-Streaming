import SubmodularMatching.CapacitySlots

/-! # Every feasible b-matching lifts while retaining its preassigned slots -/

namespace SubmodularMatching.Capacity
open Finset

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

structure Allocation (E V : Type*) where
  kept : Finset E
  slot : V → E → ℕ

/-- The bound by the number of occupied slots ensures the next free slot is its successor. -/
structure Consistent (ends : E → V × V) (cap : V → ℕ) (a : Allocation E V) : Prop where
  capacity : feasible ends cap a.kept
  bounded : ∀ v e, e ∈ incidences ends a.kept v → a.slot v e < (incidences ends a.kept v).card
  injective : ∀ v, Set.InjOn (a.slot v) (↑(incidences ends a.kept v))

def designated (ends : E → V × V) (a : Allocation E V) (e : E) : Copy E :=
  ⟨e, a.slot (ends e).1 e, a.slot (ends e).2 e⟩

/-- Accepted labels have their permanent pair; each rejected label has all valid pairs. -/
def allowed (ends : E → V × V) (cap : V → ℕ) (a : Allocation E V) (c : Copy E) : Prop :=
  valid ends cap c ∧ (c.label ∈ a.kept → c = designated ends a c.label)

theorem lift_matching (ends : E → V × V) (hnoloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (cap : V → ℕ) (a : Allocation E V) (ha : Consistent ends cap a)
    (s : Finset E) (hs : feasible ends cap s) :
    ∃ t : Finset (Copy E), project t = s ∧ matching ends t ∧ ∀ c ∈ t, allowed ends cap a c := by
  classical
  let U := incidences ends s
  let K := incidences ends a.kept
  have chooseSeats (v : V) : ∃ g : E → ℕ, (∀ e ∈ U v, g e < cap v) ∧
      Set.InjOn g (↑(U v)) ∧ ∀ e ∈ U v ∩ K v, g e = a.slot v e :=
    extend_slots (U v) (U v ∩ K v) (cap v) (a.slot v) (hs v) inter_subset_left
      (fun e he => (ha.bounded v e (mem_inter.mp he).2).trans_le (ha.capacity v))
      (fun _ hx _ hy => ha.injective v (mem_inter.mp hx).2 (mem_inter.mp hy).2)
  choose g hbound hinj hfixed using chooseSeats
  let make (e : E) : Copy E := ⟨e, g (ends e).1 e, g (ends e).2 e⟩
  have hindex (e : E) (v : V) (hv : touches ends v e) : index ends (make e) v = g v e := by
    rcases hv with rfl | rfl
    · simp [index, make]
    · simp [index, make, Ne.symm (hnoloop e)]
  refine ⟨s.image make, ?_, ?_, ?_⟩
  · ext e
    simp [project, mem_image, make]
  · intro v x hx y hy hxy
    obtain ⟨hx, hxt⟩ := mem_filter.mp hx
    obtain ⟨hy, hyt⟩ := mem_filter.mp hy
    obtain ⟨e, he, rfl⟩ := mem_image.mp hx
    obtain ⟨f, hf, rfl⟩ := mem_image.mp hy
    change touches ends v e at hxt
    change touches ends v f at hyt
    change index ends (make e) v = index ends (make f) v at hxy
    rw [hindex e v hxt, hindex f v hyt] at hxy
    exact congrArg make (hinj v (mem_filter.mpr ⟨he,hxt⟩) (mem_filter.mpr ⟨hf,hyt⟩) hxy)
  · intro c hc
    obtain ⟨e, he, rfl⟩ := mem_image.mp hc
    have hl : touches ends (ends e).1 e := Or.inl rfl
    have hr : touches ends (ends e).2 e := Or.inr rfl
    have hul : e ∈ U (ends e).1 := mem_filter.mpr ⟨he,hl⟩
    have hur : e ∈ U (ends e).2 := mem_filter.mpr ⟨he,hr⟩
    refine ⟨⟨hbound _ _ hul,hbound _ _ hur⟩, ?_⟩
    intro hk
    change e ∈ a.kept at hk
    have hkl : e ∈ K (ends e).1 := mem_filter.mpr ⟨hk,hl⟩
    have hkr : e ∈ K (ends e).2 := mem_filter.mpr ⟨hk,hr⟩
    change Copy.mk e (g _ e) (g _ e) = Copy.mk e _ _
    rw [hfixed _ _ (mem_inter.mpr ⟨hul,hkl⟩), hfixed _ _ (mem_inter.mpr ⟨hur,hkr⟩)]

/-- An optimal b-matching lifts to an optimal ordinary matching, with exactly the same value. -/
theorem optimum_preserved (ends : E → V × V) (hnoloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (cap : V → ℕ) (a : Allocation E V) (ha : Consistent ends cap a)
    (f : Finset E → ℝ) (s : Finset E) (hs : feasible ends cap s)
    (hopt : ∀ u, feasible ends cap u → f u ≤ f s) :
    ∃ t : Finset (Copy E), project t = s ∧ matching ends t ∧
      (∀ c ∈ t, allowed ends cap a c) ∧ ∀ u, matching ends u →
      (∀ c ∈ u, allowed ends cap a c) → f (project u) ≤ f (project t) := by
  obtain ⟨t,ht,hm,ha'⟩ := lift_matching ends hnoloop cap a ha s hs
  refine ⟨t,ht,hm,ha',?_⟩
  intro u hum hua
  rw [ht]
  exact hopt _ (projection_feasible ends cap u hum fun c hc => (hua c hc).1)

end SubmodularMatching.Capacity
