import SubmodularMatching.IndependentSampling

/-!
# Lemma 3.2: comparison of arrival marginal values

This file proves the paper's comparison using an exact finite independent
sample. `edges i` is the edge at position `i`; only positions `i < n` matter.
For distinct edges this is exactly the paper's ordered stored set `S`.
All expectations and weights are defined below, rather than supplied as
assumptions. The set `T` may overlap the stored edges.
-/

namespace SubmodularMatching

open scoped BigOperators

variable {E : Type*} [DecidableEq E]

/-- The true expected marginal recorded when position `i` arrives. -/
noncomputable def arrivalWeight (edges : ℕ → E) (p : ℝ)
    (f : Finset E → ℝ) (i : ℕ) : ℝ :=
  bernoulliExpectation edges (fun _ => p) (fun A => marginal f (edges i) A) i

/-- The same arrival marginal after adjoining `T` to the random prefix. -/
noncomputable def conditionalArrivalWeight (edges : ℕ → E) (p : ℝ)
    (f : Finset E → ℝ) (T : Finset E) (i : ℕ) : ℝ :=
  bernoulliExpectation edges (fun _ => p)
    (fun A => marginal f (edges i) (T ∪ A)) i

/-- `g(T)` in the paper: expected additional value over the full `p`-sample. -/
noncomputable def residualValue (edges : ℕ → E) (p : ℝ)
    (f : Finset E → ℝ) (n : ℕ) (T : Finset E) : ℝ :=
  bernoulliExpectation edges (fun _ => p) (fun A => f (T ∪ A) - f A) n

/-- `F_{f_T}(z)`, with independent decisions on the stored positions. -/
noncomputable def residualMultilinear (edges : ℕ → E) (z : ℕ → ℝ)
    (f : Finset E → ℝ) (n : ℕ) (T : Finset E) : ℝ :=
  bernoulliExpectation edges z (fun A => f (T ∪ A) - f T) n

theorem marginal_union_conditioning (f : Finset E → ℝ) (T A : Finset E) (e : E) :
    marginal (fun B => f (T ∪ B)) e A = marginal f e (T ∪ A) := by
  simp only [marginal, Finset.union_assoc]

theorem marginal_residual_conditioning (f : Finset E → ℝ)
    (T A : Finset E) (e : E) :
    marginal (fun B => f (T ∪ B) - f T) e A = marginal f e (T ∪ A) := by
  simp only [marginal, Finset.union_assoc]
  ring

theorem arrivalWeight_nonnegative
    (edges : ℕ → E) (p : ℝ) (f : Finset E → ℝ) (hm : IsMonotone f)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (i : ℕ) :
    0 ≤ arrivalWeight edges p f i := by
  apply bernoulliExpectation_nonnegative edges (fun _ => p) _ i
    (fun _ _ => ⟨hp, hp1⟩)
  intro A
  exact marginal_nonnegative f hm (edges i) A

/-- The value of the full product sample equals the initial value plus the
sum of expected arrival contributions. -/
theorem expected_arrival_value
    (edges : ℕ → E) (p : ℝ) (f : Finset E → ℝ) (n : ℕ) :
    bernoulliExpectation edges (fun _ => p) f n =
      f ∅ + p * (∑ i ∈ Finset.range n, arrivalWeight edges p f i) := by
  rw [bernoulliExpectation_telescoping, Finset.mul_sum]
  rfl

theorem conditionalArrivalWeight_nonnegative
    (edges : ℕ → E) (p : ℝ) (f : Finset E → ℝ) (hm : IsMonotone f)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (T : Finset E) (i : ℕ) :
    0 ≤ conditionalArrivalWeight edges p f T i := by
  apply bernoulliExpectation_nonnegative edges (fun _ => p) _ i
    (fun _ _ => ⟨hp, hp1⟩)
  intro A
  exact marginal_nonnegative f hm (edges i) (T ∪ A)

theorem conditionalArrivalWeight_le
    (edges : ℕ → E) (p : ℝ) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (T : Finset E) (i : ℕ) :
    conditionalArrivalWeight edges p f T i ≤ arrivalWeight edges p f i := by
  apply bernoulliExpectation_mono edges (fun _ => p) _ _ i
    (fun _ _ => ⟨hp, hp1⟩)
  intro A
  exact marginal_antitone f hf hm A (T ∪ A) (edges i) Finset.subset_union_right

/-- The paper's exact expected marginal-loss identity. No submodularity or
probability bounds are required for this algebraic identity. Normalization
`f ∅ = 0` is explicitly recorded. -/
theorem expected_marginal_loss_identity
    (edges : ℕ → E) (p : ℝ) (f : Finset E → ℝ)
    (hzero : f ∅ = 0) (n : ℕ) (T : Finset E) :
    p * (∑ i ∈ Finset.range n,
      (arrivalWeight edges p f i - conditionalArrivalWeight edges p f T i)) =
      f T - residualValue edges p f n T := by
  have hplain := bernoulliExpectation_telescoping edges (fun _ => p) f n
  have hshift := bernoulliExpectation_telescoping edges (fun _ => p)
    (fun A => f (T ∪ A)) n
  simp only [Finset.union_empty, marginal_union_conditioning] at hshift
  change bernoulliExpectation edges (fun _ => p) f n = f ∅ +
    ∑ i ∈ Finset.range n, p * arrivalWeight edges p f i at hplain
  change bernoulliExpectation edges (fun _ => p) (fun A => f (T ∪ A)) n = f T +
    ∑ i ∈ Finset.range n, p * conditionalArrivalWeight edges p f T i at hshift
  rw [hzero, zero_add, ← Finset.mul_sum] at hplain
  rw [← Finset.mul_sum] at hshift
  rw [Finset.sum_sub_distrib, mul_sub]
  unfold residualValue
  rw [bernoulliExpectation_sub]
  linarith

/-- The multilinear value dominates the `z`-weighted arrival marginals
conditioned on `T`. This proves the sampling/coupling part of Lemma 3.2. -/
theorem residualMultilinear_lower_bound
    (edges : ℕ → E) (p : ℝ) (z : ℕ → ℝ) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (hp1 : p ≤ 1)
    (n : ℕ) (hz : ∀ i < n, 0 ≤ z i ∧ z i ≤ p) (T : Finset E) :
    (∑ i ∈ Finset.range n, z i * conditionalArrivalWeight edges p f T i) ≤
      residualMultilinear edges z f n T := by
  have htelescope := bernoulliExpectation_telescoping edges z
    (fun A => f (T ∪ A) - f T) n
  simp only [Finset.union_empty, sub_self, zero_add,
    marginal_residual_conditioning] at htelescope
  unfold residualMultilinear
  rw [htelescope]
  apply Finset.sum_le_sum
  intro i hi
  have hin : i < n := Finset.mem_range.mp hi
  apply mul_le_mul_of_nonneg_left _ (hz i hin).1
  apply bernoulliExpectation_antitone_probabilities edges z (fun _ => p)
    (fun A => marginal f (edges i) (T ∪ A)) i
  · intro j hj
    exact ⟨(hz j (hj.trans hin)).1, (hz j (hj.trans hin)).2, hp1⟩
  · intro A B hAB
    exact marginal_antitone f hf hm (T ∪ A) (T ∪ B) (edges i)
      (Finset.union_subset_union (Finset.Subset.refl T) hAB)

/-- Lemma 3.2 of *The Complexity of Submodular Matching in One-Pass Streams*.
The weights, multilinear extension, and residual objective are defined from
finite independent sampling. There is no hypothesis assuming the desired
comparison, telescoping identity, or coupling inequality. -/
theorem lemma_3_2
    (edges : ℕ → E) (p : ℝ) (z wh : ℕ → ℝ) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (n : ℕ)
    (hz : ∀ i < n, 0 ≤ z i ∧ z i ≤ p)
    (hwh : ∀ i < n, wh i ≤ arrivalWeight edges p f i)
    (T : Finset E) :
    residualValue edges p f n T + (∑ i ∈ Finset.range n, wh i * z i) ≤
      f T + residualMultilinear edges z f n T := by
  have hmulti := residualMultilinear_lower_bound edges p z f hf hm hp1 n hz T
  have hloss := expected_marginal_loss_identity edges p f hzero n T
  have hsum : (∑ i ∈ Finset.range n, wh i * z i) -
      (∑ i ∈ Finset.range n, z i * conditionalArrivalWeight edges p f T i) ≤
      p * (∑ i ∈ Finset.range n,
        (arrivalWeight edges p f i - conditionalArrivalWeight edges p f T i)) := by
    rw [← Finset.sum_sub_distrib, Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i hi
    have hin : i < n := Finset.mem_range.mp hi
    have hweight := mul_le_mul_of_nonneg_right (hwh i hin) (hz i hin).1
    have hnonneg := conditionalArrivalWeight_le edges p f hf hm hp hp1 T i
    have hbudget := mul_le_mul_of_nonneg_right (hz i hin).2 (sub_nonneg.mpr hnonneg)
    nlinarith
  linarith

end SubmodularMatching
