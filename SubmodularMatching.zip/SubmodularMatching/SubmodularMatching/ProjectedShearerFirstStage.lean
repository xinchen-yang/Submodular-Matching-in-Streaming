import SubmodularMatching.ProjectedShearerOutput
import SubmodularMatching.ShearerTimeCollisions

/-! # An explicit finite-grid first-stage output guarantee -/

namespace SubmodularMatching.Shearer
open GibbsMatching AppendixM
open scoped BigOperators

variable {E V L : Type*} [DecidableEq E] [DecidableEq V] [DecidableEq L]
variable (ends : E → Finset V) (label : E → L) (h : Finset L → ℝ) (S : Finset E) (Y : E → ℝ)

set_option maxHeartbeats 900000 in
/-- Expected gain of the actual feasible priority output at any common
integer grid resolving the two rational layer widths. All randomness here
comes from the single pair of uniformly time-marked Shearer samples. -/
theorem finite_first_stage_priority [LinearOrder E] (hf : IsSubmodular h) (H : ℝ)
    (hlo : ∀ U, 0 ≤ h U) (hhi : ∀ U, h U ≤ H) (h0 : ∀ e ∈ S, 0 ≤ Y e)
    (hends : ∀ a ∈ S, (ends a).card = 2) (hY : ∀ w, ∑ a ∈ incident ends S w, Y a ≤ degree)
    (Q m n : ℕ) (hQ : 0 < Q) (hn : 0 < n) (hm : (m:ℝ)/Q = layerOne) (hw : (n:ℝ)/Q = layerTwo)
    (els : ℕ → L) (k : ℕ) (hcover : S.image label ⊆ replacementPrefix els k)
    (hdistinct : ∀ i < k, ∀ j < k, els i = els j → i = j) :
    let avg := binLaw ends S Y Q m n
    let orig := markedPair ends S S (fun a => layerOne/degree*Y a) (fun a => layerTwo/degree*Y a)
    let marginal := fun l => orig (fun A B => if l ∈ (A∪B).image label then 1 else 0)
    (∀ A B, Streaming.IsMatchingOn (binEnds ends) (markedOutput ends label h A B)) ∧
    gamma * (bernoulliExpectation els (fun i => marginal (els i)) h k - h ∅) -
      ((gamma + 2*S.card)*H) * (3*(S.card:ℝ)^2/Q) ≤
    avg (fun A B => h ((markedOutput ends label h A B).image (binLabel label))-h ∅) := by
  classical
  intro avg orig marginal
  have hq : 0 < (Q:ℝ) := by exact_mod_cast hQ
  have hmp : (0:ℝ) < (m:ℝ)/Q := hm ▸ layerDegrees.1
  have hmp' : 0 < m := by exact_mod_cast ((div_pos_iff_of_pos_right hq).mp hmp)
  have frac : ∀ a ∈ S, Y a ≤ degree := by
    intro a ha
    obtain ⟨v,hv⟩ := Finset.card_pos.mp (show 0 < (ends a).card by rw [hends a ha]; decide)
    have hv' : a ∈ incident ends S v := Finset.mem_filter.mpr ⟨ha,hv⟩
    exact (Finset.single_le_sum (s := incident ends S v) (f := Y) (fun i hi => h0 i (Finset.mem_filter.mp hi).1) hv').trans (hY v)
  have mass_le (j : ℕ) (a : E×ℕ) (ha : a ∈ binSupport S j) : binMass Y Q a ≤ 1/Q :=
    div_le_div_of_nonneg_right ((div_le_one (by norm_num [degree])).mpr (frac _ (Finset.mem_product.mp ha).1)) hq.le
  have mQ : m ≤ Q := by exact_mod_cast (div_le_one hq).mp (hm.trans_le (layerDegrees.2.1.le.trans (by norm_num)))
  have nQ : n ≤ Q := by exact_mod_cast (div_le_one hq).mp (hw.trans_le ((layerDegrees.2.2.2.trans layerDegrees.2.1).le.trans (by norm_num)))
  have io : InteriorLaw (binEnds ends) (binSupport S m) (binMass Y Q) := bin_interior ends S Y h0 hends hY Q m (hm.trans_lt layerDegrees.2.1)
  have ip : InteriorLaw (binEnds ends) (binSupport S n) (binMass Y Q) := bin_interior ends S Y h0 hends hY Q n (hw.trans_lt (layerDegrees.2.2.2.trans layerDegrees.2.1))
  have cc := timeClone_collision_bound ends S m n Q hQ mQ nQ (binMass Y Q) (binMass Y Q) io ip (mass_le m) (mass_le n)
  have eqc : (collision : Finset (E×ℕ) → Finset (E×ℕ) → ℝ) = fun (A B : Finset (E×ℕ)) =>
      if Disjoint A B ∧ Set.InjOn Prod.snd (↑(A∪B) : Set (E×ℕ)) then 0 else 1 := by
    classical
    funext A B
    by_cases hgood : goodTimes A B <;> simp only [collision,goodTimes] at * <;> simp [hgood]
  have c : avg collision ≤ 3*(S.card:ℝ)^2/Q := by rw [eqc]; exact cc
  have p (l : L) : unalteredMarginal ends S Y label Q m n l = marginal l := by
    simpa only [hm,hw,orig,marginal] using unalteredMarginal_original ends S Y label Q m n hmp' hn hends l
  obtain ⟨feasible,retention⟩ := finite_priority_output ends S Y label h hf H hlo hhi h0 hends hY Q m n hQ hn hm hw els k hcover hdistinct
  refine ⟨feasible,?_⟩
  simp only [p] at retention
  have gam : 0 ≤ gamma := by norm_num [gamma,AppendixM.retention,priorityArea,priorityLoss,rootHi,rootLo,degree,layerOne,layerTwo,discriminant]
  have scale : 0 ≤ (gamma+2*(S.card:ℝ))*H := mul_nonneg (add_nonneg gam (by positivity)) ((hlo ∅).trans (hhi ∅))
  exact (sub_le_sub_left (mul_le_mul_of_nonneg_left c scale) _).trans retention

/-- The exact integer widths can be refined by any common integer
factor. In particular the explicit collision allowance can be driven
below every positive tolerance without changing the degree schedule. -/
theorem exists_exact_priority_grid (N : ℕ) : ∃ Q m n : ℕ, N < Q ∧ 0 < Q ∧ 0 < n ∧
    (m:ℝ)/Q = layerOne ∧ (n:ℝ)/Q = layerTwo := by
  let j := N+1
  refine ⟨62500000000000000000000*j,15609923359958673284671*j,4702576640041326715329*j,?_,by positivity,by positivity,?_,?_⟩
  · dsimp [j]; omega
  all_goals push_cast
  all_goals simp only [layerTwo,layerOne,degree] <;> field_simp [show (j:ℝ) ≠ 0 by positivity] <;> ring

end SubmodularMatching.Shearer
