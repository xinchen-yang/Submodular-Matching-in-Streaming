import SubmodularMatching.CapacityComparator
import SubmodularMatching.CapacitySignedTrace

/-! # The source LP on assigned slots at fractional comparator loads -/

namespace SubmodularMatching.Capacity
open Finset SourceCertificate SourceCertificate.Asymmetric Streaming
open scoped BigOperators
noncomputable section

variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

theorem uniform_slot_comparator (D : Shape) (H : Bool → SourceFunction) (C : PotentialConfig)
    (a β Cmax : ℝ) (hflag : ∀ i, a * D.flag i = β * unmatched i)
    (cert : RunSourceConditions H C D a Cmax) (v0 v1 e0 e1 : ℝ)
    (hv : ∀ i, D.vertex i = v0-v1*bit i)
    (he : ∀ i j, D.edge i j = e0-e1*(bit i+bit j))
    (hver : ∀ i, 0 < D.vertex i) (hcap : ∀ i j k, C.p*D.edge i j ≤ D.vertex k)
    (hcap1 : ∀ i j, C.p*D.edge i j ≤ 1)
    (ends : E → V × V) (hn : ∀ e, (ends e).1 ≠ (ends e).2) (cap : V → ℕ)
    (left : (e : E) → Fin (cap (ends e).1)) (right : (e : E) → Fin (cap (ends e).2))
    (hslots : 1 ≤ Fintype.card (BSlot cap)) (hE : 1 ≤ Fintype.card E)
    (input : ℕ → E × ℝ) (n : ℕ)
    (hinj : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j)
    (w : E → ℝ) (hw : ∀ e, 0 ≤ w e ∧ w e ≤ C.tau) (heq : ∀ i < n, (input i).2 = w (input i).1)
    (O : Finset E) (hO : feasible ends cap O) :
    let pair := slotPair ends cap left right
    let S := (runPotential C pair input n).stored
    let t := fun v => (incidences ends O v).card / (cap v : ℝ)
    ∃ z : E → ℝ, (∀ e, 0 ≤ z e ∧ z e ≤ C.p*(e0-e1*(t (ends e).1+t (ends e).2))) ∧
      (∀ x : BSlot cap, Joint.degree pair z x ≤ v0-v1*t x.1) ∧ (∀ e, e ∉ S → z e = 0) ∧
      a*(C.p*S.sum w) + β*unoccupiedCharge ends cap O (fun v j => idealPotential C pair input n ⟨v,j⟩)
        ≤ ∑ e, w e*z e := by
  classical
  intro pair S t
  let k := fun v => (incidences ends O v).card
  let A := (v : V) → Occupied (cap v) (k v)
  letI (v : V) : Nonempty (Occupied (cap v) (k v)) := occupied_nonempty _ _ (hO v)
  let flag := fun (u : A) (x : BSlot cap) => decide (x.2 ∈ (u x.1).val)
  have hm (x : BSlot cap) : finiteMean (fun u : A => bit (flag u x)) = t x.1 := by
    have hr := independent_flag_probability cap k hO x.1 x.2
    have hh (u : A) : (if x.2 ∈ (u x.1).val then (0:ℝ) else 1) = 1-bit (flag u x) := by
      by_cases h : x.2 ∈ (u x.1).val <;> simp [flag,bit,h]
    simp only [hh, finiteMean_sub, finiteMean_const] at hr
    change 1-_ = 1-t x.1 at hr
    linarith
  have hp (e : E) : (pair e).1 ≠ (pair e).2 := fun h => hn e (congrArg Sigma.fst h)
  have hcert (u : A) := stored_comparator_bound D H C a β Cmax hflag cert (flag u) pair hp
    hslots hE hver (fun _ _ => hcap _ _ _) hcap1 input n hinj w hw heq
  have hav := averaged_comparator D pair S w C.p C.p_pos.le flag (fun x => t x.1) hm v0 v1 e0 e1
    (a*(C.p*S.sum w)) β (idealPotential C pair input n) hv he hcert
  have he' : (∑ x : BSlot cap, (1-t x.1)*idealPotential C pair input n x) =
      unoccupiedCharge ends cap O (fun v j => idealPotential C pair input n ⟨v,j⟩) := by
    rw [Fintype.sum_sigma]
    simp only [unoccupiedCharge,t,mul_sum]
  simpa only [he'] using hav

end
end SubmodularMatching.Capacity
