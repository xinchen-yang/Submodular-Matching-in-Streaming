import SubmodularMatching.AJXUpstream.Blueprint.Blueprint
import SubmodularMatching.LowerBoundGlobalCyclicTheorem

/-! # Relating the AJX coauthors' blueprint type to the chapter's expansion -/

namespace SubmodularMatching.LowerBoundGlobal.AJX

open AJXUpstream

noncomputable section

/-- Convert phase-tagged matched edges to the partitioned matching used
by the expansion. The prefix bans are the same condition in both types. -/
def ofUpstreamBlueprint (b : SimpleProperBlueprint) : ProperBlueprint b.P b.C where
  phases := b.E
  phases_disjoint := by
    intro i j hne
    apply Finset.disjoint_left.mpr
    intro e he hf
    exact hne (b.left_matching he hf).1
  matching := by
    constructor
    · intro e he f hf heq
      obtain ⟨i, _, hi⟩ := Finset.mem_biUnion.mp he
      obtain ⟨j, _, hj⟩ := Finset.mem_biUnion.mp hf
      obtain ⟨l, r⟩ := e
      obtain ⟨l', r'⟩ := f
      change l = l' at heq
      subst l'
      exact Prod.ext rfl (b.left_matching hi hj).2
    · intro e he f hf heq
      obtain ⟨i, _, hi⟩ := Finset.mem_biUnion.mp he
      obtain ⟨j, _, hj⟩ := Finset.mem_biUnion.mp hf
      obtain ⟨l, r⟩ := e
      obtain ⟨l', r'⟩ := f
      change r = r' at heq
      subst r'
      exact Prod.ext (b.right_matching hi hj).2 rfl
  ban := by
    intro i e he f hf g hg hprefix hsuffix
    let tail : Suffix b.P b.C i := fun j _ => f.1 j
    have hl : patchVertex i e.1 tail = f.1 := by
      funext j
      by_cases hj : i ≤ j
      · simp [patchVertex, tail, hj]
      · simp [patchVertex, hj, (hprefix j (lt_of_not_ge hj)).1]
    have hr : patchVertex i e.2 tail = g.2 := by
      funext j
      by_cases hj : i ≤ j
      · simp [patchVertex, tail, hj, hsuffix j (not_lt_of_ge hj)]
      · simp [patchVertex, hj, (hprefix j (lt_of_not_ge hj)).2]
    obtain ⟨i', _, hi'⟩ := Finset.mem_biUnion.mp hf
    obtain ⟨j', _, hj'⟩ := Finset.mem_biUnion.mp hg
    rcases b.bans he tail with h | h
    · exact h (hl.symm ▸ show leftMatched b.E f.1 from ⟨i', f.2, hi'⟩)
    · exact h (hr.symm ▸ show rightMatched b.E g.2 from ⟨j', g.1, hj'⟩)

private theorem upstream_edgeCount_eq (b : SimpleProperBlueprint) :
    b.edgeCount = (ofUpstreamBlueprint b).edges.card := by
  classical
  let unpack : {e : b.EdgeOver // e.2 ∈ b.E e.1} → (ofUpstreamBlueprint b).edges :=
    fun e => ⟨e.val.2, Finset.mem_biUnion.mpr ⟨e.val.1, Finset.mem_univ _, e.property⟩⟩
  have hinj : Function.Injective unpack := by
    rintro ⟨⟨i, e⟩, he⟩ ⟨⟨j, f⟩, hf⟩ h
    have hef : e = f := congrArg Subtype.val h
    subst f
    have hij : i = j := (b.left_matching he hf).1
    subst j
    rfl
  have hsurj : Function.Surjective unpack := by
    rintro ⟨e, he⟩
    obtain ⟨i, _, hi⟩ := Finset.mem_biUnion.mp he
    exact ⟨⟨⟨i, e⟩, hi⟩, rfl⟩
  have heq := Fintype.card_congr (Equiv.ofBijective unpack ⟨hinj, hsurj⟩)
  simpa only [SimpleProperBlueprint.edgeCount, Fintype.card_coe] using heq

theorem ofUpstreamBlueprint_value (b : SimpleProperBlueprint) :
    (ofUpstreamBlueprint b).value = b.value := by
  have hv : b.vertexCount = b.C ^ b.P := by simp [SimpleProperBlueprint.vertexCount, Vertex]
  rw [ProperBlueprint.value, SimpleProperBlueprint.value, upstream_edgeCount_eq, hv, Nat.cast_pow]

/-- Transfer the feasibility and value guaranteed by AJX's construction. -/
theorem near_of_upstream
    (h : ∀ ε : ℝ, 0 < ε → ∃ B : SimpleProperBlueprint, (2 : ℝ) / 3 - ε < B.value) :
    ProperBlueprintsNearTwoThirds := by
  intro ε hε
  obtain ⟨B, hB⟩ := h ε hε
  exact ⟨B.P, B.C, B.hP, B.hC, ofUpstreamBlueprint B, by
    rw [ofUpstreamBlueprint_value]
    exact hB.le⟩

end

end SubmodularMatching.LowerBoundGlobal.AJX
