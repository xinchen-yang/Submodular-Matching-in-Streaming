import SubmodularMatching.NonmonotoneOptimizerScoreRegisters

/-! Both scores retained for a comparison are bounded polynomial rationals
on every transcript of an active stream guess. -/
namespace SubmodularMatching.NonmonotoneOptimizer
open Streaming Capacity.RealOracle AppendixM
variable {E : Type*} [DecidableEq E] {n N m s bits : ℕ} [NeZero n]

theorem batch_mean_size (Q : OracleQuery E) (P K : ℕ) (hP : 0<P) (hs : 0<s)
    (range : ∀ A ⊆ (Finset.range Q.size).image Q.edges, -(K:ℝ) ≤ Q.evaluate A ∧ Q.evaluate A ≤ K)
    (words : WordBatch s Q.size bits) : |wordMean Q (1/(P:ℚ)^2) words| ≤ K := by
  let d : ℚ := 1/(P:ℚ)^2
  let v := fun i : ℕ => if hi : i<s then Q.wordValue bits (words ⟨i,hi⟩) else 0
  have hd : (0:ℝ)<(d:ℝ) := by dsimp [d]; positivity
  have eq : ((K*P^2:ℕ):ℝ)*(d:ℝ) = K := by simp [d,Nat.cast_ne_zero.mpr hP.ne']
  have hbound (i : ℕ) (hi : i<s) : -((K*P^2:ℕ):ℝ)*(d:ℝ) ≤ v i ∧ v i ≤ ((K*P^2:ℕ):ℝ)*(d:ℝ) := by
    rw [neg_mul,eq]
    simp only [v,dif_pos hi]
    exact wordValue_range Q _ _ bits range _
  have k := runningAccumulator_bound (K*P^2) s d hd v hbound s le_rfl
  have hq : |(runningAccumulator (d:ℝ) v s s:ℚ)| ≤ 4*((K*P^2:ℕ):ℚ)*(s:ℚ) := by
    rw [abs_le]; exact_mod_cast k
  rw [streamed_wordMean]
  change |d*(runningAccumulator (d:ℝ) v s s:ℚ)/(4*(s:ℚ))| ≤ (K:ℚ)
  rw [abs_div,abs_mul,abs_of_nonneg (by dsimp [d]; positivity : 0≤d),
    abs_of_nonneg (by positivity : (0:ℚ) ≤ 4*(s:ℚ)),div_le_iff₀ (by positivity)]
  apply (mul_le_mul_of_nonneg_left hq (by dsimp [d]; positivity)).trans_eq
  dsimp [d]
  push_cast
  field_simp

namespace BlockData
variable (B : BlockData E n N)

theorem observed_score_size (h : ℕ→E) (p : ℕ→ℝ) (F : Finset E→ℝ) (τ : ℝ)
    (hp : ∀ j<m,0≤p j ∧ p j≤1) (W : OptimizerWords m n N s bits) (hs : 0<s) (t : ℕ)
    (r : Vec N) (hm : ∀ j,|atRat r j| ≤ 1)
    (hw : ∀ i,|(B.frozen i:ℝ)|≤paperScale N)
    (ht : 0<τ) (hf : IsSubmodular F) (hn : ∀ A,0≤F A) (h0 : F ∅ ≤ τ)
    (hh : ∀ j<m,F {h j}≤τ) (hfro : ∀ i,F {B.label i}≤τ) :
    |(B.paperAnswers h p m F τ hp W).score t r| ≤ (n*(paperScale N)+2*(m+n+1):ℕ) := by
  let P := paperScale N
  let K := m+n+1
  let d := queryTolerance N
  let a := B.actionQuery r h p m (normalized F τ) hp
  let b := baseQuery h p m (normalized F τ) hp
  have hP : 0<P := (by decide : 0<2^36).trans_le (paperScale_bounds N).1
  have range (j : ActionKey n) :
      let q := B.keyQuery r h p (normalized F τ) hp j
      ∀ A⊆(Finset.range q.size).image q.edges,-(K:ℝ) ≤ q.evaluate A ∧ q.evaluate A ≤ K := by
    simpa only [K,Nat.cast_add,Nat.cast_one] using B.keyRange r h p hp F τ ht hf hn h0 hh hfro j
  have va := batch_mean_size a P K hP hs (range (.inr true)) (W.active t r)
  have vb := batch_mean_size b P K hP hs (range (.inr false)) (W.base t r)
  have hdif : |wordMean a d (W.active t r)-wordMean b d (W.base t r)| ≤ (K:ℚ)+K :=
    (abs_sub ..).trans (add_le_add va vb)
  have hlin : |B.linearRat r| ≤ (n:ℚ)*P := by
    unfold linearRat
    apply (Finset.abs_sum_le_sum_abs ..).trans
    calc
      _ ≤ ∑ _i : Fin n,(P:ℚ) := Finset.sum_le_sum (fun i _ => by
        rw [abs_mul]
        have b := mul_le_of_le_one_right (abs_nonneg (B.frozen i)) (hm (B.columns (.inl i)))
        exact b.trans (by exact_mod_cast hw i))
      _ = _ := by simp
  have hγ := scoreConstants.2.2.2.1
  have hγ0 := scoreConstants.2.2.1
  change |B.linearRat r+scoreGamma*(wordMean a d (W.active t r)-wordMean b d (W.base t r))| ≤ _
  apply (abs_add_le ..).trans
  rw [abs_mul,abs_of_nonneg hγ0]
  have hright := (mul_le_of_le_one_left (abs_nonneg _) hγ).trans hdif
  have hsum := add_le_add hlin hright
  refine hsum.trans_eq ?_
  dsimp only [P,K]
  push_cast
  ring

end BlockData
end SubmodularMatching.NonmonotoneOptimizer
