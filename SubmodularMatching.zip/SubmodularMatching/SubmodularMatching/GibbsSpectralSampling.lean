import SubmodularMatching.GibbsSpectralContraction
import SubmodularMatching.FiniteShearerBudget

/-!
# Finite Gibbs sampler parameters from canonical paths

Sinclair's weighted all-matchings paths have length at most the number of
vertices and congestion at most `4m C²` for the original chain. Explicit
laziness divides every moving capacity by two, giving congestion `8m C²`.
This module isolates that combinatorial obligation and checks its exact
contraction, time horizon, word count, and output-law consequences.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The cited canonical-path estimate for the exact lazy Gibbs kernel. -/
def HasSinclairPaths (ends : E → Finset V) (edges : Finset E) (activity : E → ℝ)
    (n : ℕ) (C : ℝ) : Prop :=
  Nonempty (CanonicalPathCertificate (matchings ends edges)
    (probability ends edges activity) (transition ends edges activity) n
    (8*(edges.card:ℝ)*C^2))

theorem sinclairPaths_contraction (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (ha : ∀ e ∈ edges, 0 < activity e)
    (n : ℕ) (hn : 0 < n) (hm : edges.Nonempty) (C : ℝ) (hC : 1 ≤ C)
    (hpaths : HasSinclairPaths ends edges activity n C) (f : Finset E → ℝ)
    (hmean : ∑ M ∈ matchings ends edges, probability ends edges activity M * f M = 0) :
    squareEnergy (matchings ends edges) (probability ends edges activity)
      (actOnFunctions (matchings ends edges) (transition ends edges activity) f) ≤
      (1-(8*(n:ℝ)*(edges.card:ℝ)*C^2)⁻¹)^2 *
        squareEnergy (matchings ends edges) (probability ends edges activity) f := by
  have hn' : 1 ≤ (n:ℝ) := by exact_mod_cast hn
  have hm' : 1 ≤ (edges.card:ℝ) := by exact_mod_cast Finset.card_pos.mpr hm
  have hC' : 1 ≤ C^2 := one_le_pow₀ hC
  have h₀ : 1 ≤ 8*(n:ℝ)*(edges.card:ℝ)*C^2 := by
    calc
      (1:ℝ) = 1*1*1*1 := by norm_num
      _ ≤ _ := by gcongr; norm_num
  have hInv : (8*(n:ℝ)*(edges.card:ℝ)*C^2)⁻¹ ≤ 1 := inv_le_one_of_one_le₀ h₀
  let states := matchings ends edges
  let π := probability ends edges activity
  let P := transition ends edges activity
  let cap := 8*(n:ℝ)*(edges.card:ℝ)*C^2
  let gap := cap⁻¹
  have ha₀ : ∀ e ∈ edges, 0 ≤ activity e := fun e he => (ha e he).le
  have hπ : IsProbability states π :=
    ⟨fun M _ => probability_nonnegative ends edges activity ha₀ _, probability_total ends edges activity ha₀⟩
  have hP : IsKernel states P :=
    ⟨fun M hM => ⟨fun N hN => transition_nonnegative ends edges activity ha₀ M N hM hN,
      transition_total ends edges activity M hM⟩⟩
  have hrev : ∀ M ∈ states, ∀ N ∈ states, π M*P M N = π N*P N M :=
    fun M hM N hN => detailed_balance ends edges activity M N hM hN
  have hLazy (M : Finset E) (hM : M ∈ states) : 1/2 ≤ P M M := by
    dsimp only [P,transition]
    rw [if_pos rfl]
    linarith only [offDiagonal_outgoing_le_half ends edges activity ha₀ M hM]
  obtain ⟨paths⟩ := hpaths
  refine squareEnergy_contract_of_poincare states π P hπ hP hrev hLazy gap hInv ?_ f hmean
  intro g hg
  have hPi := canonicalPaths_poincare states π P hπ n _ paths g
  rw [pairVariance_eq_centered_energy states π hπ g hg] at hPi
  have hBound : squareEnergy states π g ≤ cap*dirichlet states π P g := by
    dsimp only [cap]
    convert hPi using 1
    ring
  have hPositive : 0 < cap := zero_lt_one.trans_le h₀
  calc
    gap * squareEnergy states π g ≤ gap*(cap*dirichlet states π P g) :=
      mul_le_mul_of_nonneg_left hBound (inv_nonneg.mpr hPositive.le)
    _ = _ := by dsimp only [gap]; rw [← mul_assoc, inv_mul_cancel₀ hPositive.ne', one_mul]

noncomputable def gibbsPrecision (δ : ℝ) : ℕ :=
  ShearerSampler.decayCutoff ((2:ℝ)⁻¹) (1/δ)

noncomputable def gibbsSteps (n m : ℕ) (C totalActivity δ : ℝ) : ℕ :=
  ⌈8*(n:ℝ)*(m:ℝ)*C^2*(totalActivity/2+gibbsPrecision δ)⌉₊

noncomputable def gibbsBits (steps m : ℕ) (δ : ℝ) : ℕ :=
  ShearerSampler.decayCutoff ((2:ℝ)⁻¹) (2*(steps+1)*(m+1)/δ)

theorem gibbsPrecision_spec (δ : ℝ) (hδ : 0 < δ ∧ δ ≤ 1) :
    1 ≤ δ * (2:ℝ)^(gibbsPrecision δ) := by
  have h := (ShearerSampler.decayCutoff_bounds _ _ (by norm_num : 0 < (2:ℝ)⁻¹ ∧ (2:ℝ)⁻¹ < 1)
    ((le_div_iff₀ hδ.1).2 (by simpa only [one_mul] using hδ.2))).1
  change (1/δ) * ((2:ℝ)⁻¹)^gibbsPrecision δ ≤ 1 at h
  rw [inv_pow, ← one_div, div_mul_eq_mul_div, one_mul, div_div] at h
  have hpos : 0 < (2:ℝ)^gibbsPrecision δ * δ := mul_pos (by positivity) hδ.1
  simpa only [mul_comm] using (div_le_one hpos).1 h

theorem gibbsSteps_spec (n m : ℕ) (hn : 0 < n) (hm : 0 < m) (C totalActivity δ : ℝ)
    (hC : 0 < C) :
    totalActivity/2 + (gibbsPrecision δ:ℝ) ≤
      (8*(n:ℝ)*(m:ℝ)*C^2)⁻¹ * (gibbsSteps n m C totalActivity δ:ℝ) := by
  have hn' : 0 < (n:ℝ) := by exact_mod_cast hn
  have hm' : 0 < (m:ℝ) := by exact_mod_cast hm
  have hp : 0 < 8*(n:ℝ)*(m:ℝ)*C^2 := by positivity
  rw [mul_comm _ (gibbsSteps n m C totalActivity δ : ℝ), ← div_eq_mul_inv]
  exact (le_div_iff₀ hp).2 (by
    simpa only [mul_comm (totalActivity/2+(gibbsPrecision δ:ℝ))] using
      Nat.le_ceil (8*(n:ℝ)*(m:ℝ)*C^2*(totalActivity/2+gibbsPrecision δ)))

theorem gibbsBits_spec (T m : ℕ) (δ : ℝ) (hδ : 0 < δ ∧ δ ≤ 1) :
    (T:ℝ)*((m:ℝ)*((2:ℝ)^gibbsBits T m δ)⁻¹) ≤ δ/2 := by
  have h₁ : 1 ≤ 2*((T:ℝ)+1)*((m:ℝ)+1)/δ := by
    apply (le_div_iff₀ hδ.1).2
    have hT : 0 ≤ (T:ℝ) := by positivity
    have hm : 0 ≤ (m:ℝ) := by positivity
    nlinarith only [hδ.2,hT,hm,mul_nonneg hT hm]
  have h := (ShearerSampler.decayCutoff_bounds _ _ (by norm_num : 0 < (2:ℝ)⁻¹ ∧ (2:ℝ)⁻¹ < 1) h₁).1
  change 2*((T:ℝ)+1)*((m:ℝ)+1)/δ * ((2:ℝ)⁻¹)^gibbsBits T m δ ≤ 1 at h
  rw [inv_pow, div_mul_eq_mul_div] at h
  have hBound := (div_le_one hδ.1).mp h
  have hMass : (T:ℝ)*(m:ℝ) ≤ ((T:ℝ)+1)*((m:ℝ)+1) := by
    exact mul_le_mul (le_add_of_nonneg_right zero_le_one) (le_add_of_nonneg_right zero_le_one)
      (by positivity) (by positivity)
  have hScale := mul_le_mul_of_nonneg_right hMass
    (show 0 ≤ ((2:ℝ)^gibbsBits T m δ)⁻¹ by positivity)
  linarith only [hBound,hScale]

/-- The finite supported Gibbs law, with actual polynomial-window parameters.
An empty positive graph uses the same formula and only has one state. -/
noncomputable def finiteGibbsLaw (ends : E → Finset V) (edges : Finset E) (activity : E → ℝ)
    (n : ℕ) (C δ : ℝ) (M : Finset E) : ℝ :=
  let support := positiveEdges edges activity
  let T := gibbsSteps n support.card C (∑ e ∈ support, activity e) δ
  let b := gibbsBits T support.card δ
  supportedGibbsLaw ends edges activity b T M

theorem finiteGibbsLaw_probability (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (n : ℕ) (C δ : ℝ) :
    IsProbability (matchings ends edges) (finiteGibbsLaw ends edges activity n C δ) :=
  supportedGibbsLaw_probability ends edges activity _ _

theorem finiteGibbsLaw_variation (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (ha : ∀ e ∈ edges, 0 ≤ activity e)
    (n : ℕ) (hn : 0 < n) (C : ℝ) (hC : 1 ≤ C)
    (δ : ℝ) (hδ : 0 < δ ∧ δ ≤ 1)
    (hPaths : (positiveEdges edges activity).Nonempty →
      HasSinclairPaths ends (positiveEdges edges activity) activity n C) :
    variation (matchings ends edges) (finiteGibbsLaw ends edges activity n C δ)
      (probability ends edges activity) ≤ δ := by
  classical
  let support := positiveEdges edges activity
  let T := gibbsSteps n support.card C (∑ e ∈ support, activity e) δ
  let b := gibbsBits T support.card δ
  change variation (matchings ends edges) (supportedGibbsLaw ends edges activity b T)
      (probability ends edges activity) ≤ δ
  rw [supportedGibbsLaw_variation ends edges activity ha]
  by_cases hm : support.Nonempty
  · let gap := (8*(n:ℝ)*(support.card:ℝ)*C^2)⁻¹
    have hp : ∀ e ∈ support, 0 < activity e := fun e he => (Finset.mem_filter.mp he).2
    have hn' : 1 ≤ (n:ℝ) := by exact_mod_cast hn
    have hm' : 1 ≤ (support.card:ℝ) := by exact_mod_cast Finset.card_pos.mpr hm
    have hC2 : 1 ≤ C^2 := one_le_pow₀ hC
    have hCap : 1 ≤ 8*(n:ℝ)*(support.card:ℝ)*C^2 := by
      calc
        (1:ℝ) = 1*1*1*1 := by norm_num
        _ ≤ _ := by gcongr; norm_num
    exact rounded_gibbs_mixing ends support activity hp gap (inv_le_one_of_one_le₀ hCap)
      (sinclairPaths_contraction ends support activity hp n hn hm C hC (hPaths hm))
      T (gibbsPrecision δ) b δ (gibbsSteps_spec n support.card hn (Finset.card_pos.mpr hm) C _
        δ (zero_lt_one.trans_le hC)) (gibbsPrecision_spec δ hδ) (gibbsBits_spec T support.card δ hδ)
  · have hEmpty : support = ∅ := Finset.not_nonempty_iff_eq_empty.mp hm
    let states := matchings ends support
    let p := iterateKernel states (roundedTransition ends support activity b) (pointMass ∅) T
    let q := probability ends support activity
    have hP : IsProbability states p :=
      iterateKernel_probability states _ _ (pointMass_probability states ∅ (empty_mem_matchings ends support))
        (roundedTransition_isKernel ends support activity b (fun e he => (Finset.mem_filter.mp he).2.le)) T
    have hQ : IsProbability states q :=
      ⟨fun M _ => probability_nonnegative ends support activity (fun e he => (Finset.mem_filter.mp he).2.le) M,
        probability_total ends support activity (fun e he => (Finset.mem_filter.mp he).2.le)⟩
    have hStates : states = {∅} := by
      dsimp only [states]
      rw [hEmpty, Shearer.matchings_empty]
    have hp : p ∅ = 1 := by simpa only [hStates, Finset.sum_singleton] using hP.total
    have hq : q ∅ = 1 := by simpa only [hStates, Finset.sum_singleton] using hQ.total
    change variation states p q ≤ δ
    simp [variation,hStates,hp,hq,hδ.1.le]

end SubmodularMatching.GibbsSampler
