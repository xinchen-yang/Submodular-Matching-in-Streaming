import SubmodularMatching.NonmonotoneWideTape
import SubmodularMatching.CapacitySelectedConfidence

/-! Every active guess reads a separate row of a fresh arrival batch.
Only its stored order determines how many of that row's words are consumed. -/
namespace SubmodularMatching.Capacity
open Streaming

/-- Room for every absolute dyadic index reached at any legal prefix. -/
def sourceGuessCount (v : ℕ) : ℕ := (v^2+2)*(guessSpan v+1)

end SubmodularMatching.Capacity

namespace SubmodularMatching.Capacity.WordWindow
open Streaming Streaming.OracleQuery UpperBoundAssembly AppendixM GibbsSampler MeasureTheory Finset
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def guessTape (P : WordWindow E V) (N : ℕ) (t : SourceWordTape) : SourceWordTape :=
  fun a r => t (P.b+a) (P.j*N+r)

def bankDraw (N : ℕ) (t : SourceWordTape) : ℕ → ℕ → ℕ → ℕ → ℕ :=
  fun i j r => t i (j*N+r)

def guessRow {N G j : ℕ} (h : j<G) : Fin N ↪ Fin (G*N) :=
  ⟨fun r => ⟨j*N+r, (Nat.add_lt_add_left r.isLt (j*N)).trans_le (by
      rw [← Nat.succ_mul]
      exact Nat.mul_le_mul_right N (by omega))⟩,
    fun x y hxy => Fin.ext (Nat.add_left_cancel (congrArg Fin.val hxy))⟩

def wideEstimate (P : WordWindow E V) (N G width bits : ℕ) (hj : P.j<G)
    (i : ℕ) (t : SourceWordTape) (w : WordBatch (G*N) width bits) : Bool :=
  if P.b ≤ i ∧ i < P.k then
    let a := i-P.b
    let z := P.guessTape N t
    let Q := P.Q N bits a z
    if hw : Q.size ≤ width then
      let w' := prefixBatch hw (selectBatchRows (guessRow hj) w)
      decide (Q.target-P.gap ≤ sourceAverage P.gap (fun r => Q.wordValue bits (w' r)) ∧
        sourceAverage P.gap (fun r => Q.wordValue bits (w' r)) ≤ Q.target+P.gap)
    else false
  else true

theorem wideEstimate_good (P : WordWindow E V) (N G width bits : ℕ) (hj : P.j<G) (i : ℕ) (hi : i<P.k)
    (t : SourceWordTape) (hg : P.Good N bits (i-P.b) (P.guessTape N t))
    (w : WordBatch (G*N) width bits) (hw : P.wideEstimate N G width bits hj i t w = true) :
    P.Good N bits (i+1-P.b) (P.guessTape N (tapeInsert t i w)) := by
  by_cases hb : P.b ≤ i
  · let z := P.guessTape N t
    let z' := P.guessTape N (tapeInsert t i w)
    let a := i-P.b
    have hai : P.b+a=i := by omega
    have prev (l : ℕ) (hl : l<a) : z' l=z l := by
      unfold z' z guessTape tapeInsert
      rw [Function.update_of_ne (by omega : P.b+l≠i)]
    intro l hl
    have hst := P.state_causal N bits l z' z (fun j hj => prev j (by omega))
    have hq : P.Q N bits l z' = P.Q N bits l z := by simp only [Q,hst]
    change (P.Q N bits l z').target-P.gap ≤ sourceAverage P.gap (P.raw N bits l z') ∧
      sourceAverage P.gap (P.raw N bits l z') ≤ (P.Q N bits l z').target+P.gap
    rw [hq]
    by_cases he : l<a
    · have hraw : P.raw N bits l z'=P.raw N bits l z := by
        funext r
        simp only [raw,hst,prev l he]
      rw [hraw]
      exact hg l he
    · have hl' : l=a := by omega
      subst l
      have hinside : P.b ≤ i ∧ i < P.k := ⟨hb,hi⟩
      simp only [wideEstimate,if_pos hinside] at hw
      change (if h : (P.Q N bits a z).size ≤ width then _ else false)=true at hw
      split at hw
      next h =>
        have hv := of_decide_eq_true hw
        have heq (r : Fin N) : P.raw N bits a z' r =
            (P.Q N bits a z).wordValue bits (prefixBatch h (selectBatchRows (guessRow hj) w) r) := by
          unfold raw
          rw [hst]
          apply RealOracle.bankRaw_wordValue
          intro y
          dsimp only [z',guessTape]
          rw [hai]
          have hr : P.j*N+r.val<G*N := (guessRow (N:=N) hj r).isLt
          simp [tapeInsert,hr,finiteWord_in_range _ _ _ (y.isLt.trans_le h),
            prefixBatch,selectBatchRows,guessRow,Fin.castLE]
        rw [funext heq]
        exact hv
      next h => simp at hw
  · intro a ha
    omega

end
end SubmodularMatching.Capacity.WordWindow
