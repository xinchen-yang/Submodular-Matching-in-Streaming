import SubmodularMatching.NonmonotoneActionRound

/-! Conditional failure probability of all physical queries at an arbitrary state. -/
namespace SubmodularMatching.NonmonotoneOptimizer
open Streaming MeasureTheory ProbabilityTheory
noncomputable section
variable {E : Type*} [DecidableEq E] {m n l : ℕ} [NeZero n]

def actionBatch (l J : ℕ) := OracleQuery.batchCount (wordScheduleSize l) (J*wordScheduleSize l)
def actionBits (l : ℕ) := OracleQuery.batchBits (wordScheduleSize l)

theorem BlockData.round_failure (B : BlockData E n l) (r : Vec l) (h : ℕ → E)
    (p : ℕ → ℝ) (hp : ∀ i<m, 0 ≤ p i ∧ p i ≤ 1) (hm : m≤n)
    (F : Finset E → ℝ) (τ : ℝ) (ht : 0<τ) (hf : IsSubmodular F)
    (hn : ∀ T, 0 ≤ F T) (h0 : F ∅ ≤ τ) (hh : ∀ i<m, F {h i} ≤ τ) (hs : ∀ i, F {B.label i} ≤ τ)
    (J : ℕ) (hJ : 0<J) :
    let μ := roundLaw m n (actionBatch l J) (actionBits l)
    μ.real {ω | ¬ ∀ j, B.keyGood r h p (normalized F τ) hp (queryTolerance l) j (ω j)} ≤
      (2*(n:ℝ)+2)/((J:ℝ)*(wordScheduleSize l:ℝ)) := by
  intro μ
  classical
  let K := wordScheduleSize l
  let d := queryTolerance l
  let G := normalized F τ
  let width : ℝ := m+n+1
  obtain ⟨hK,_,hnK,hd,hratio⟩ := action_word_sizes m n l hm (column_count B)
  let size := keySize m n
  let ν := fun j : ActionKey n => wordBatchLaw (actionBatch l J) (size j) (actionBits l)
  let bad := fun j : ActionKey n => {w : WordBatch (actionBatch l J) (keySize m n j) (actionBits l) | ¬ B.keyGood r h p G hp d j w}
  have prob (j : ActionKey n) : (ν j).real (bad j) ≤ 1/(J*K:ℕ) := by
    have H := B.keyRange r h p hp F τ ht hf hn h0 hh hs j
    let Q := B.keyQuery r h p G hp j
    have sz : Q.size ≤ K := by
      rw [show Q.size = keySize m n j from B.keyQuery_size _ _ _ _ _ _]
      rcases j with ⟨flag,i⟩|v
      · exact hnK
      · cases v
        · exact (Nat.le_add_right _ _).trans hnK
        · exact hnK
    have hw : 0<width := by dsimp [width]; positivity
    have S := word_single_budget Q d K (J*K) hK (Nat.mul_pos hJ hK) (-width) width hd
      (by linarith only [hw]) (by dsimp only [width]; linarith only [hratio]) sz H
    rcases j with ⟨flag,i⟩|u
    · exact S
    · cases u <;> exact S
  have select (j : ActionKey n) :
      μ.real ((fun ω : ActionRound m n (actionBatch l J) (actionBits l) => ω j) ⁻¹' bad j) =
        (ν j).real (bad j) := by
    have eqn := (measurePreserving_eval ν j).measure_preimage (Set.toFinite (bad j)).measurableSet.nullMeasurableSet
    exact congrArg ENNReal.toReal eqn
  have eqn : {ω : ActionRound m n (actionBatch l J) (actionBits l) | ¬ ∀ j, B.keyGood r h p G hp d j (ω j)} =
      ⋃ j, (fun ω : ActionRound m n (actionBatch l J) (actionBits l) => ω j) ⁻¹' bad j := by
    ext ω
    simp only [Set.mem_setOf_eq,Set.mem_iUnion,Set.mem_preimage,bad,not_forall]
  rw [eqn]
  apply (measureReal_iUnion_fintype_le _).trans
  have H := Finset.sum_le_sum (s:=Finset.univ) (fun j _ => (select j).le.trans (prob j))
  apply H.trans_eq
  simp [ActionKey,Fintype.card_sum,Fintype.card_prod,div_eq_mul_inv,K]

end
end SubmodularMatching.NonmonotoneOptimizer
