import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step176 : ProjectedGoal ⟨54864, 54971, 0, 70, 1099, 1135⟩ :=
  projectedGoal_chunk _ (.m (.leaf 0xd685d6500000000000cd8191) (.m (.m (.leaf 0xd693d6860000000000cd8191) (.leaf 0xd6a0d6940000000000cd8191)) (.m (.m (.leaf 0xd6a7d6a10000000000cd8191) (.leaf 0xd6aed6a80000000000cd8191)) (.m (.leaf 0xd6b5d6af0000000000cd8191) (.leaf 0xd6bbd6b60000000000cd8191))))) (by decide +kernel)

private theorem step177 : ProjectedGoal ⟨54972, 54998, 0, 70, 1099, 1135⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0xd6bfd6bc0000000000cd8191) (.m (.leaf 0xd6c1d6c00000000000cd8191) (.leaf 0xd6c2d6c20000000000cd8191))) (.m (.m (.m (.leaf 0xd6c3d6c30000000000cd8191) (.leaf 0xd6c4d6c40000000000cd8191)) (.m (.leaf 0xd6c5d6c50000000000cd8191) (.leaf 0xd6c6d6c60000000000cd8191))) (.m (.m (.leaf 0xd6c7d6c70000000000cd8191) (.leaf 0xd6c8d6c80000000000cd8191)) (.leaf 0xd6c9d6c90000000000cd8191)))) (.m (.m (.m (.leaf 0xd6cbd6ca0000000000cd8191) (.leaf 0xd6cdd6cc0000000000cd8191)) (.m (.leaf 0xd6cfd6ce0000000000cd8191) (.leaf 0xd6d0d6d00000000000cd8191))) (.m (.m (.m (.leaf 0xd6d1d6d10000000000cd8191) (.leaf 0xd6d2d6d20000000000cd8191)) (.leaf 0xd6d3d6d30000000000cd8191)) (.m (.leaf 0xd6d5d6d40000000000cd8191) (.leaf 0xd6d6d6d60000000000cd8191))))) (by decide +kernel)

private theorem step178 : ProjectedGoal ⟨54999, 55025, 0, 70, 1099, 1135⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.m (.leaf 0xd6d7d6d70000000000cd8191) (.leaf 0xd6d8d6d80000000000cd8191)) (.m (.leaf 0xd6d9d6d90000000000cd8191) (.leaf 0xd6dad6da0000000000cd8191))) (.m (.m (.leaf 0xd6dbd6db0000000000cd8191) (.leaf 0xd6dcd6dc0000000000cd8191)) (.leaf 0xd6ddd6dd0000000000cd8191))) (.m (.m (.leaf 0xd6dfd6de0000000000cd8191) (.leaf 0xd6e1d6e00000000000cd8191)) (.m (.leaf 0xd6e3d6e20000000000cd8191) (.leaf 0xd6e4d6e40000000000cd8191)))) (.m (.m (.m (.m (.leaf 0xd6e5d6e50000000000cd8191) (.leaf 0xd6e6d6e60000000000cd8191)) (.m (.leaf 0xd6e7d6e70000000000cd8191) (.leaf 0xd6e8d6e80000000000cd8191))) (.m (.m (.leaf 0xd6e9d6e90000000000cd8191) (.leaf 0xd6ead6ea0000000000cd8191)) (.leaf 0xd6ebd6eb0000000000cd8191))) (.m (.m (.leaf 0xd6edd6ec0000000000cd8191) (.leaf 0xd6eed6ee0000000000cd8191)) (.m (.m (.leaf 0xd6efd6ef0000000000cd8191) (.leaf 0xd6f0d6f00000000000cd8191)) (.leaf 0xd6f1d6f10000000000cd8191))))) (by decide +kernel)

private theorem step179 : ProjectedGoal ⟨54972, 55025, 0, 70, 1099, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54998 (by decide) (by decide) (step177 rates cones) (step178 rates cones)

private theorem step180 : ProjectedGoal ⟨55026, 55052, 0, 70, 1099, 1135⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.leaf 0xd6f3d6f20000000000cd8191) (.leaf 0xd6f5d6f40000000000cd8191)) (.m (.leaf 0xd6f7d6f60000000000cd8191) (.leaf 0xd6f8d6f80000000000cd8191))) (.m (.m (.m (.leaf 0xd6f9d6f90000000000cd8191) (.leaf 0xd6fad6fa0000000000cd8191)) (.m (.leaf 0xd6fbd6fb0000000000cd8191) (.leaf 0xd6fcd6fc0000000000cd8191))) (.x (.x (.m (.m (.leaf 0xd6fdd6fd0000000000cd8500) (.leaf 0xd6fed6fe0000000000cd8500)) (.leaf 0xd6ffd6ff0000000000cd8500)) (.leaf 0xd6ffd6fd0000000000cd81c9)) (.leaf 0xd6ffd6fd0000000000cd817f)))) (.m (.m (.m (.leaf 0xd701d7000000000000cd8191) (.leaf 0xd703d7020000000000cd8191)) (.m (.leaf 0xd705d7040000000000cd8191) (.leaf 0xd706d7060000000000cd8191))) (.m (.x (.x (.m (.m (.leaf 0xd707d7070000000000cd8500) (.leaf 0xd708d7080000000000cd8500)) (.leaf 0xd709d7090000000000cd8500)) (.leaf 0xd709d7070000000000cd81c9)) (.leaf 0xd709d7070000000000cd817f)) (.m (.leaf 0xd70bd70a0000000000cd8191) (.leaf 0xd70cd70c0000000000cd8191))))) (by decide +kernel)

private theorem step181 : ProjectedGoal ⟨55053, 55066, 0, 70, 1099, 1135⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.leaf 0xd70dd70d0000000000cd8191) (.leaf 0xd70ed70e0000000000cd8191)) (.m (.leaf 0xd70fd70f0000000000cd8191) (.leaf 0xd710d7100000000000cd8191))) (.x (.x (.m (.m (.leaf 0xd711d7110000000000cd8500) (.leaf 0xd712d7120000000000cd8500)) (.leaf 0xd713d7130000000000cd8500)) (.leaf 0xd713d7110000000000cd81c9)) (.leaf 0xd713d7110000000000cd817f))) (.m (.m (.leaf 0xd715d7140000000000cd8191) (.leaf 0xd717d7160000000000cd8191)) (.m (.leaf 0xd719d7180000000000cd8191) (.leaf 0xd71ad71a0000000000cd8191)))) (by decide +kernel)

private theorem step182 : ProjectedGoal ⟨55067, 55079, 0, 70, 1099, 1135⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.leaf 0xd71bd71b0000000000cd8191) (.leaf 0xd71cd71c0000000000cd8191)) (.m (.leaf 0xd71dd71d0000000000cd8191) (.leaf 0xd71ed71e0000000000cd8191))) (.x (.x (.m (.m (.leaf 0xd71fd71f0000000000cd8500) (.leaf 0xd720d7200000000000cd8500)) (.leaf 0xd721d7210000000000cd8500)) (.leaf 0xd721d71f0000000000cd81c9)) (.leaf 0xd721d71f0000000000cd817f))) (.m (.m (.leaf 0xd723d7220000000000cd8191) (.leaf 0xd724d7240000000000cd8191)) (.x (.x (.m (.m (.leaf 0xd725d7250000000000cd8500) (.leaf 0xd726d7260000000000cd8500)) (.leaf 0xd727d7270000000000cd8500)) (.leaf 0xd727d7250000000000cd81c9)) (.leaf 0xd727d7250000000000cd817f)))) (by decide +kernel)

private theorem step183 : ProjectedGoal ⟨55053, 55079, 0, 70, 1099, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55066 (by decide) (by decide) (step181 rates cones) (step182 rates cones)

private theorem step184 : ProjectedGoal ⟨55026, 55079, 0, 70, 1099, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55052 (by decide) (by decide) (step180 rates cones) (step183 rates cones)

private theorem step185 : ProjectedGoal ⟨54972, 55079, 0, 70, 1099, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55025 (by decide) (by decide) (step179 rates cones) (step184 rates cones)

private theorem step186 : ProjectedGoal ⟨54864, 55079, 0, 70, 1099, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54971 (by decide) (by decide) (step176 rates cones) (step185 rates cones)

theorem Part00018 : ProjectedGoal ⟨54864, 55079, 0, 70, 1099, 1135⟩ := step186

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
