import SubmodularMatching.SourceDataInterpolation
import SubmodularMatching.CertificateRationalLog

/-!
# Source functions from knot tables

The first two tabulated heights are zero. This gives a neighborhood of
zero on which the density vanishes and permits an improper integral over
the whole positive half-line.
-/

namespace SubmodularMatching.SourceCertificate

open MeasureTheory Set Filter
open scoped BigOperators Topology

noncomputable section

theorem weighted_integrable_of_constant_tails (F : ℝ → ℝ) (a b : ℝ)
    (ha : 0 < a) (hab : a ≤ b) (hc : Continuous F)
    (hzero : ∀ x ∈ Ioc 0 a, F x = 0)
    (htail : ∀ x ∈ Ici b, F x = F b) (hval : 0 ≤ F b) :
    IntegrableOn (fun x => F x / x ^ 2) (Ioi 0) := by
  rw [← Ioc_union_Ioi_eq_Ioi ha.le, integrableOn_union]
  constructor
  · refine (integrableOn_zero (s := Ioc (0 : ℝ) a) (μ := volume) (ε' := ℝ)).congr_fun
        (fun x hx => ?_) measurableSet_Ioc
    rw [hzero x hx, zero_div]
  · rw [← Ioc_union_Ioi_eq_Ioi hab, integrableOn_union]
    constructor
    · have hmid : ContinuousOn (fun x => F x / x ^ 2) (Icc a b) :=
        hc.continuousOn.div (continuous_id.pow 2).continuousOn
          (fun x hx => pow_ne_zero _ (ha.trans_le hx.1).ne')
      exact (hmid.integrableOn_Icc).mono_set Ioc_subset_Icc_self
    · have hb := ha.trans_le hab
      have hderiv (x : ℝ) (hx : x ∈ Ici b) :
          HasDerivAt (fun y : ℝ => -F b / y) (F x / x ^ 2) x := by
        rw [htail x hx]
        convert (hasDerivAt_const x (-F b)).div (hasDerivAt_id x) (hb.trans_le hx).ne' using 1
        simp
      have hlim : Tendsto (fun y : ℝ => -F b / y) atTop (𝓝 0) := by
        simpa only [div_eq_mul_inv, mul_zero] using tendsto_inv_atTop_zero.const_mul (-F b)
      exact integrableOn_Ioi_deriv_of_nonneg' hderiv
        (fun x hx => by rw [htail x (mem_Ici.mpr (mem_Ioi.mp hx).le)]; exact div_nonneg hval (sq_nonneg _)) hlim

/-- Finite rational data for the two potentials. Every predicate is bounded
by the number of entries in the table. -/
structure SourcePotentialTable where
  count : ℕ
  knot : ℕ → ℚ
  height : Bool → ℕ → ℚ
  positive_count : 0 < count
  first_knot : knot 0 = 0
  increasing_knots : ∀ i < count, knot i < knot (i + 1)
  zero_first : ∀ i, height i 0 = 0
  zero_second : ∀ i, height i 1 = 0
  increasing_heights : ∀ b i, i < count → height b i ≤ height b (i + 1)

namespace SourcePotentialTable

def realKnot (T : SourcePotentialTable) (i : ℕ) : ℝ := T.knot i

def realHeight (T : SourcePotentialTable) (b : Bool) (i : ℕ) : ℝ := T.height b i

def value (T : SourcePotentialTable) (b : Bool) : ℝ → ℝ :=
  realInterpolate T.count T.realKnot (T.realHeight b)

theorem ordered (T : SourcePotentialTable) : OrderedKnots T.count T.realKnot := by
  intro i hi
  unfold realKnot
  exact_mod_cast T.increasing_knots i hi

theorem height_nonnegative (T : SourcePotentialTable) (b : Bool) (i : ℕ) (hi : i ≤ T.count) :
    0 ≤ T.realHeight b i := by
  induction i with
  | zero => simp [realHeight, T.zero_first]
  | succ i ih =>
    have h : T.realHeight b i ≤ T.realHeight b (i + 1) := by
      unfold realHeight
      exact_mod_cast T.increasing_heights b i (Nat.lt_of_succ_le hi)
    exact (ih (Nat.le_of_succ_le hi)).trans h

theorem knot_zero (T : SourcePotentialTable) : T.realKnot 0 = 0 := by simp [realKnot, T.first_knot]

theorem first_positive (T : SourcePotentialTable) : 0 < T.realKnot 1 := by
  have h := T.ordered 0 T.positive_count
  simpa only [T.knot_zero] using h

theorem nonnegative (T : SourcePotentialTable) (i : ℕ) (hi : i ≤ T.count) : 0 ≤ T.realKnot i := by
  rw [← T.knot_zero]
  exact T.ordered.le (Nat.zero_le _) hi

theorem value_continuous (T : SourcePotentialTable) (b : Bool) : Continuous (T.value b) :=
  realInterpolate_continuous _ _ _

theorem value_monotone (T : SourcePotentialTable) (b : Bool) : Monotone (T.value b) := by
  apply realInterpolate_monotone _ _ _ T.ordered
  intro i hi
  unfold realHeight
  exact_mod_cast T.increasing_heights b i hi

theorem value_zero_near (T : SourcePotentialTable) (b : Bool) (x : ℝ) (hx : x ∈ Icc 0 (T.realKnot 1)) :
    T.value b x = 0 := by
  rw [value, realInterpolate_cell T.count T.realKnot (T.realHeight b) T.ordered 0 T.positive_count x
    (by simpa only [T.knot_zero] using hx.1) hx.2]
  simp [realHeight, T.zero_first, T.zero_second]

theorem value_nonnegative (T : SourcePotentialTable) (b : Bool) (x : ℝ) (hx : 0 ≤ x) :
    0 ≤ T.value b x := by
  rw [← T.value_zero_near b 0 ⟨le_rfl, T.first_positive.le⟩]
  exact T.value_monotone b hx

theorem value_tail (T : SourcePotentialTable) (b : Bool) (x : ℝ) (hx : T.realKnot T.count ≤ x) :
    T.value b x = T.realHeight b T.count :=
  realInterpolate_above _ _ _ T.ordered hx

theorem value_integrable (T : SourcePotentialTable) (b : Bool) :
    IntegrableOn (fun x => T.value b x / x ^ 2) (Ioi 0) := by
  apply weighted_integrable_of_constant_tails _ (T.realKnot 1) (T.realKnot T.count)
    T.first_positive (T.ordered.le T.positive_count le_rfl) (T.value_continuous b)
  · exact fun x hx => T.value_zero_near b x ⟨hx.1.le, hx.2⟩
  · intro x hx
    rw [T.value_tail b x hx, T.value_tail b _ le_rfl]
  · exact T.value_nonnegative b _ (T.nonnegative _ le_rfl)

def sourceFunction (T : SourcePotentialTable) (b : Bool) : SourceFunction :=
  ⟨T.value b, T.value_continuous b, T.value_zero_near b 0 ⟨le_rfl, T.first_positive.le⟩,
    T.value_nonnegative b, T.value_integrable b⟩

def sourceKnots (T : SourcePotentialTable) : SourceKnots :=
  ⟨T.count, T.realKnot, T.knot_zero, T.nonnegative⟩

/-- Real slope on one knot interval. -/
def slope (T : SourcePotentialTable) (b : Bool) (i : ℕ) : ℝ :=
  (T.realHeight b (i + 1) - T.realHeight b i) / (T.realKnot (i + 1) - T.realKnot i)

theorem slope_nonnegative (T : SourcePotentialTable) (b : Bool) (i : ℕ) (hi : i < T.count) :
    0 ≤ T.slope b i := by
  apply div_nonneg _ (sub_pos.mpr (T.ordered i hi)).le
  exact sub_nonneg.mpr (by unfold realHeight; exact_mod_cast T.increasing_heights b i hi)

theorem value_affine (T : SourcePotentialTable) (b : Bool) (i : ℕ) (hi : i < T.count)
    (x : ℝ) (hx : T.realKnot i ≤ x) (hx' : x ≤ T.realKnot (i + 1)) :
    T.value b x = T.slope b i * x + (T.realHeight b i - T.slope b i * T.realKnot i) := by
  rw [value, realInterpolate_cell _ _ _ T.ordered i hi x hx hx']
  unfold slope
  ring

theorem piecewiseAffine (T : SourcePotentialTable) (b : Bool) :
    T.sourceKnots.PiecewiseAffine (T.value b) := by
  constructor
  · exact fun i hi => ⟨T.slope b i, T.realHeight b i - T.slope b i * T.realKnot i,
      fun x hx hx' => T.value_affine b i hi x hx hx'⟩
  · intro z hz
    change T.realKnot T.count ≤ z at hz
    change T.value b z = T.value b (T.realKnot T.count)
    rw [T.value_tail b z hz, T.value_tail b _ le_rfl]

theorem evaluate (T : SourcePotentialTable) (b : Bool) (x : ℚ) :
    T.value b (x : ℝ) = (rationalInterpolate T.count T.knot (T.height b) x : ℝ) :=
  RealizesKnotTable.eval _ _ _ _ (realInterpolate_realizes _ _ _ T.ordered) x

end SourcePotentialTable

end

end SubmodularMatching.SourceCertificate
