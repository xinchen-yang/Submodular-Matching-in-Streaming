import SubmodularMatching.NonmonotoneDiffuseLoad
import SubmodularMatching.NonmonotoneDiffuseConstants

/-! # Diffuse alteration on the vertices left vacant by two Shearer layers -/

open scoped BigOperators

namespace SubmodularMatching.TwoLayerDiffuse

open GibbsMatching VarianceBound TwoStage
noncomputable section

variable {E V : Type*} [Fintype E] [Fintype V] [DecidableEq E] [DecidableEq V]

def alteredSparse {C : Type*} [DecidableEq C] (base : C → Finset V) (active : Finset C)
    (ends : E → V × V) (A B : Layer base active)
    (x : E → ℝ) (ξ : ℝ) (ω : DualOutcome base active) (e : E) : ℝ :=
  altered ends (fun d => x d / (A.pair (ends d).1 (ends d).2 * B.pair (ends d).1 (ends d).2))
    (vacant base active) (tolerance ξ) ω e

/-- A diffuse edge can live on a different support from the sampled layers.
The shared vertex type is the slot ground set in the capacitated algorithm. -/
theorem sparse_alteration_verified {C : Type*} [DecidableEq C]
    (base : C → Finset V) (active : Finset C) (he : ∀ e ∈ active, (base e).card = 2)
    (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (A B : Layer base active)
    (d p ξ : ℝ) (hd : 0 ≤ d) (hd' : d ≤ 1/3) (hξ : 0 < ξ) (hp : 0 ≤ p)
    (hpc : p ≤ coordinateCap ξ) (degree : ∀ v, A.deg v + B.deg v ≤ d)
    (x : E → ℝ) (hx : ∀ e, 0 ≤ x e)
    (vertexBudget : ∀ v, Joint.degree ends x v ≤ A.free v * B.free v)
    (edgeBudget : ∀ e, x e ≤ p*((1 - A.deg (ends e).1 - A.deg (ends e).2)*
      (1 - B.deg (ends e).1 - B.deg (ends e).2))) :
    (∀ ω e, 0 ≤ alteredSparse base active ends A B x ξ ω e ∧ alteredSparse base active ends A B x ξ ω e ≤ p) ∧
    (∀ ω v, Joint.degree ends (alteredSparse base active ends A B x ξ ω) v ≤ 1) ∧
    (∀ ω e, alteredSparse base active ends A B x ξ ω e ≠ 0 →
      vacant base active (ends e).1 ω = 1 ∧
      vacant base active (ends e).2 ω = 1) ∧
    ∀ e, (1-ξ)*x e ≤ finiteMean (joint A B) (fun ω => alteredSparse base active ends A B x ξ ω e) := by
  let T := pairEnds ends
  let S : Finset E := Finset.univ
  let q := fun u v => A.pair u v * B.pair u v
  let a := fun e => x e / q (ends e).1 (ends e).2
  let U := vacant base active
  let ε := tolerance ξ
  let δ := meanAllowance p d
  let K := 2*p*d*(1+δ)
  have hqL (u v : V) : (1-A.deg u-A.deg v)*(1-B.deg u-B.deg v) ≤ q u v := by
    apply mul_le_mul (A.pair_bounds he u v).1 (B.pair_bounds he u v).1 _ (A.pair_nonneg he u v)
    have h₁ : B.deg u ≤ 1/4 := B.small u
    have h₂ : B.deg v ≤ 1/4 := B.small v
    linarith
  have hql (u v : V) : 1-2*d ≤ q u v := by
    apply le_trans _ (hqL u v)
    have hA : 0 ≤ A.deg u + A.deg v := add_nonneg
      (Shearer.vertexDegree_nonnegative _ _ _ A.nonneg _) (Shearer.vertexDegree_nonnegative _ _ _ A.nonneg _)
    have hB : 0 ≤ B.deg u + B.deg v := add_nonneg
      (Shearer.vertexDegree_nonnegative _ _ _ B.nonneg _) (Shearer.vertexDegree_nonnegative _ _ _ B.nonneg _)
    nlinarith only [degree u, degree v, mul_nonneg hA hB]
  have hpos (u v : V) : 0 < q u v := lt_of_lt_of_le (by linarith) (hql u v)
  have hsym (u v : V) : q u v = q v u := by
    simp only [q, Layer.pair, Shearer.unmatchedPair, mul_comm]
  have ha (e : E) : 0 ≤ a e ∧ a e ≤ p := by
    refine ⟨div_nonneg (hx e) (hpos _ _).le, (div_le_iff₀ (hpos _ _)).2 ?_⟩
    exact (edgeBudget e).trans (mul_le_mul_of_nonneg_left (hqL _ _) hp)
  let c := fun u v => neighborActivity T S a u v
  have hc (u v : V) : 0 ≤ c u v ∧ c u v ≤ p := neighbor_coefficients_bounds ends hloop hsimple a p hp ha u v
  have hcB (u : V) : (∑ v, c u v * q u v) ≤ A.free u * B.free u := by
    exact (neighbor_pair_budget ends hloop x q hsym (fun e => (hpos _ _).ne') u).trans_le (vertexBudget u)
  have hL (u : V) : load ends a U u = (fun ω => ∑ v, c u v * U v ω) := by
    funext ω
    exact load_eq_neighbor_sum ends hloop a U u ω
  have hm (u : V) : finiteMean (joint A B) (load ends a U u) ≤ 1+δ := by
    rw [hL]
    exact load_mean A B he d p hd (by linarith) hp degree u (c u) (hc u)
      (neighborActivity_self T S a u) (hcB u)
  have hV (u : V) : finiteVariance (joint A B) (load ends a U u) ≤ K := by
    rw [hL]
    apply (load_variance A B he d p hd hp degree (c u) (hc u)).trans
    rw [← hL]
    exact mul_le_mul_of_nonneg_left (hm u) (mul_nonneg (by linarith) hd)
  obtain ⟨hε,hδε,hK,hfactor⟩ := retention_constants ξ p d hξ hp hpc hd hd'
  refine ⟨fun ω e => altered_bounds ends a U ε p hε ha ω e,
    fun ω v => altered_degree ends a U ε hε (fun e => (ha e).1) vacant_zero_one ω v,
    fun ω e => altered_support ends a U ε ω e, ?_⟩
  intro e
  have hret := altered_expectation ends a U (joint A B)
    (fun ω => mul_nonneg (A.positive he ω.1) (B.positive he ω.2)) vacant_zero_one ε δ K
    (1-2*d) hε hδε hK (by linarith) (fun e => (ha e).1) hm hV e
    (q (ends e).1 (ends e).2) (x e) (vacant_pair A B _ _) (hql _ _) (div_mul_cancel₀ _ (hpos _ _).ne')
  exact (mul_le_mul_of_nonneg_right hfactor (hx e)).trans hret

end
end SubmodularMatching.TwoLayerDiffuse
