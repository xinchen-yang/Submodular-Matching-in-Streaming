import SubmodularMatching.SourceSegments
import SubmodularMatching.SourceDual
import SubmodularMatching.PotentialUpdate

/-!
# Source inequality for the actual descending-interval update

This connects the analytic segment theorem to `Streaming.idealUpdate`, whose
boundary times and clipped durations are computed explicitly. No ratio-path
certificate is assumed of a run: the static rate conditions derive the needed
endpoint geometry and scaling through the recursive update.
-/

namespace SubmodularMatching.SourceCertificate

open Streaming

noncomputable section

theorem idealUpdate_zero (base : PotentialStage) (rs : List PotentialStage)
    (P : PotentialPair) : idealUpdate base rs P 0 = P := by
  induction rs generalizing P with
  | nil => simp [idealUpdate, advancePotential]
  | cons r rs ih =>
    have hz : stageTime P r 0 = 0 := by
      exact min_eq_left (le_max_left 0 (boundaryTime P r))
    simp only [idealUpdate, hz, advancePotential, mul_zero, add_zero, sub_zero]
    exact ih P

/-- A positive clipped stage starts above its lower boundary and stays above
that boundary until it either exhausts its time or reaches the boundary. -/
theorem positive_stage_geometry (P : PotentialPair) (r : PotentialStage) (T : ℝ)
    (hdrift : r.highRate < r.boundary * (r.highRate + r.lowRate))
    (hu : 0 < stageTime P r T) :
    r.boundary * (P.high + P.low) < P.high ∧
      r.boundary * ((advancePotential P r (stageTime P r T)).high +
        (advancePotential P r (stageTime P r T)).low) ≤
          (advancePotential P r (stageTime P r T)).high := by
  have hd : 0 < r.boundary * (r.highRate + r.lowRate) - r.highRate := sub_pos.mpr hdrift
  have hb : 0 < boundaryTime P r := by
    by_contra h
    have hmax : max 0 (boundaryTime P r) = 0 := max_eq_left (le_of_not_gt h)
    have hmin := min_le_right T (max 0 (boundaryTime P r))
    change stageTime P r T ≤ _ at hmin
    rw [hmax] at hmin
    linarith
  have hstart : 0 < P.high - r.boundary * (P.high + P.low) := by
    exact (div_pos_iff_of_pos_right hd).mp hb
  have htime : stageTime P r T ≤ boundaryTime P r := by
    exact (min_le_right T (max 0 (boundaryTime P r))).trans_eq (max_eq_right hb.le)
  have hprod := (le_div_iff₀ hd).mp htime
  constructor
  · linarith
  · dsimp [advancePotential]
    nlinarith

/-- If a stage leaves time for a lower interval, its final ratio is at most
that interval's upper endpoint. This also handles skipped intervals. -/
theorem remaining_stage_geometry (P : PotentialPair) (r : PotentialStage) (T : ℝ)
    (hdrift : r.highRate < r.boundary * (r.highRate + r.lowRate))
    (hremain : stageTime P r T < T) :
    (advancePotential P r (stageTime P r T)).high ≤
      r.boundary * ((advancePotential P r (stageTime P r T)).high +
        (advancePotential P r (stageTime P r T)).low) := by
  have hd : 0 < r.boundary * (r.highRate + r.lowRate) - r.highRate := sub_pos.mpr hdrift
  have hmax : stageTime P r T = max 0 (boundaryTime P r) := by
    by_cases h : T ≤ max 0 (boundaryTime P r)
    · have hu : stageTime P r T = T := min_eq_left h
      exact False.elim ((ne_of_lt hremain) hu)
    · exact min_eq_right (le_of_not_ge h)
  have htime : boundaryTime P r ≤ stageTime P r T := by
    rw [hmax]
    exact le_max_right _ _
  have hprod := (div_le_iff₀ hd).mp htime
  dsimp [advancePotential]
  nlinarith

/-- Static local source inequalities for one rate pair. -/
def RateLocal (H J : SourceFunction) (sH sL k sigma mH mL : ℝ)
    (r : PotentialStage) (lo hi : ℝ) : Prop :=
  ∀ a d, 0 ≤ a → 0 ≤ d →
    sigma * (1 + mH * r.highRate + mL * r.lowRate) ≤
      localValue H.value J.value sH sL r.highRate r.lowRate k lo a d ∧
    sigma * (1 + mH * r.highRate + mL * r.lowRate) ≤
      localValue H.value J.value sH sL r.highRate r.lowRate k hi a d

/-- Descending rate intervals satisfying SP0 and the endpoint source checks.
The final equal-rate interval has lower endpoint `1/2`. -/
def RateChain (H J : SourceFunction) (sH sL k sigma mH mL Cmax : ℝ)
    (base : PotentialStage) : List PotentialStage → ℝ → Prop
  | [], upper => (1 / 2 : ℝ) ≤ upper ∧ base.highRate = base.lowRate ∧
      0 < base.lowRate ∧ base.highRate + base.lowRate ≤ Cmax ∧
      RateLocal H J sH sL k sigma mH mL base (1 / 2) upper
  | r :: rs, upper => (1 / 2 : ℝ) ≤ r.boundary ∧ r.boundary ≤ upper ∧
      r.lowRate ≤ r.highRate ∧ 0 < r.lowRate ∧
      r.highRate < r.boundary * (r.highRate + r.lowRate) ∧
      r.highRate + r.lowRate ≤ Cmax ∧
      RateLocal H J sH sL k sigma mH mL r r.boundary upper ∧
      RateChain H J sH sL k sigma mH mL Cmax base rs r.boundary

/-- The concrete finite boundary-time algorithm satisfies the source increment
inequality from static SP0/local conditions. Skipped intervals and exact final
boundary hits are included; no condition on an uncomputed interior path occurs. -/
theorem idealUpdate_source_increment (H J : SourceFunction)
    (sH sL k sigma mH mL Cmax scale priceH priceL weight : ℝ)
    (hscale : 0 < scale) (hpriceH : 0 ≤ priceH) (hpriceL : 0 ≤ priceL)
    (hk : 0 ≤ k) (hCmax : 0 ≤ Cmax)
    (base : PotentialStage) (rs : List PotentialStage) (upper : ℝ)
    (P : PotentialPair) (T : ℝ)
    (hchain : RateChain H J sH sL k sigma mH mL Cmax base rs upper)
    (hP : 0 ≤ P.high ∧ 0 ≤ P.low) (horder : P.low ≤ P.high)
    (hupper : T = 0 ∨ P.high ≤ upper * (P.high + P.low)) (hT : 0 ≤ T)
    (hbudget : scale * (P.high + P.low + Cmax * T) ≤ weight) :
    sigma * (T + mH * ((idealUpdate base rs P T).high - P.high) +
      mL * ((idealUpdate base rs P T).low - P.low)) ≤
      (auxiliary H.value sH scale priceH (idealUpdate base rs P T).high -
        auxiliary H.value sH scale priceH P.high) +
      (auxiliary J.value sL scale priceL (idealUpdate base rs P T).low -
        auxiliary J.value sL scale priceL P.low) +
      T * k * max (1 - (priceH + priceL) / weight) 0 := by
  induction rs generalizing upper P T with
  | nil =>
    by_cases hT0 : T = 0
    · simp [hT0, idealUpdate_zero]
    rcases hchain with ⟨hhalf, hequal, hB, hsum, hlocal⟩
    have hA : 0 < base.highRate := by simpa only [hequal] using hB
    have hupper' := hupper.resolve_left hT0
    have hcoef : 0 ≤ upper * (base.highRate + base.lowRate) - base.highRate := by
      have hm := mul_nonneg (sub_nonneg.mpr hhalf) (add_pos hA hB).le
      nlinarith
    have hstart : (1 / 2 : ℝ) * (P.high + P.low) ≤ P.high ∧
        P.high ≤ upper * (P.high + P.low) := ⟨by linarith, hupper'⟩
    have hfinish : (1 / 2 : ℝ) * ((P.high + base.highRate * T) +
        (P.low + base.lowRate * T)) ≤ P.high + base.highRate * T ∧
      P.high + base.highRate * T ≤ upper *
        ((P.high + base.highRate * T) + (P.low + base.lowRate * T)) := by
      constructor
      · rw [hequal]
        linarith
      · nlinarith [mul_nonneg hcoef hT]
    have hsumEnd : (P.high + base.highRate * T) + (P.low + base.lowRate * T) ≤
        P.high + P.low + Cmax * T := by
      nlinarith [mul_nonneg (sub_nonneg.mpr hsum) hT]
    have hscaled := (mul_le_mul_of_nonneg_left hsumEnd hscale.le).trans hbudget
    have hs := segment_increment H J sH sL scale priceH priceL P.high P.low
      base.highRate base.lowRate k (1 / 2) upper
      (sigma * (1 + mH * base.highRate + mL * base.lowRate)) weight T
      hscale hpriceH hpriceL hP.1 hP.2 hA hB hk hT hstart hfinish hscaled hlocal
    dsimp only [idealUpdate, advancePotential]
    convert hs using 1
    ring
  | cons r rs ih =>
    by_cases hT0 : T = 0
    · simp [hT0, idealUpdate_zero]
    rcases hchain with ⟨_hhalf, hboundary, horderRate, hB, hdrift, hsum, hlocal, htailChain⟩
    have hA : 0 < r.highRate := hB.trans_le horderRate
    have hupper' := hupper.resolve_left hT0
    let u := stageTime P r T
    let Q := advancePotential P r u
    have hu := stageTime_bounds P r T hT
    have hu0 : 0 ≤ u := hu.1
    have huT : u ≤ T := hu.2
    have hQ : 0 ≤ Q.high ∧ 0 ≤ Q.low := by
      dsimp [Q, advancePotential]
      constructor
      · exact add_nonneg hP.1 (mul_nonneg hA.le hu0)
      · exact add_nonneg hP.2 (mul_nonneg hB.le hu0)
    have hQorder : Q.low ≤ Q.high := by
      dsimp [Q, advancePotential]
      exact add_le_add horder (mul_le_mul_of_nonneg_right horderRate hu0)
    have hupperTail : T - u = 0 ∨ Q.high ≤ r.boundary * (Q.high + Q.low) := by
      by_cases hrem : T - u = 0
      · exact Or.inl hrem
      · have hstrict : u < T :=
          lt_of_le_of_ne huT (fun he => hrem (sub_eq_zero.mpr he.symm))
        exact Or.inr (remaining_stage_geometry P r T hdrift hstrict)
    have hsumRemaining : Q.high + Q.low + Cmax * (T - u) ≤
        P.high + P.low + Cmax * T := by
      dsimp [Q, advancePotential]
      nlinarith [mul_nonneg (sub_nonneg.mpr hsum) hu0]
    have hbudgetTail := (mul_le_mul_of_nonneg_left hsumRemaining hscale.le).trans hbudget
    have htail := ih r.boundary Q (T - u) htailChain hQ hQorder hupperTail
      (sub_nonneg.mpr huT) hbudgetTail
    have hpiece : sigma * (u + mH * (Q.high - P.high) + mL * (Q.low - P.low)) ≤
        (auxiliary H.value sH scale priceH Q.high - auxiliary H.value sH scale priceH P.high) +
        (auxiliary J.value sL scale priceL Q.low - auxiliary J.value sL scale priceL P.low) +
        u * k * max (1 - (priceH + priceL) / weight) 0 := by
      by_cases huZero : u = 0
      · simp [Q, advancePotential, huZero]
      have huPos : 0 < u := lt_of_le_of_ne hu0 (Ne.symm huZero)
      have hgeometry := positive_stage_geometry P r T hdrift huPos
      have hstart : r.boundary * (P.high + P.low) ≤ P.high ∧
          P.high ≤ upper * (P.high + P.low) := ⟨hgeometry.1.le, hupper'⟩
      have hcoef : 0 ≤ upper * (r.highRate + r.lowRate) - r.highRate := by
        have hm := mul_le_mul_of_nonneg_right hboundary (add_pos hA hB).le
        linarith
      have hfinish : r.boundary * ((P.high + r.highRate * u) +
          (P.low + r.lowRate * u)) ≤ P.high + r.highRate * u ∧
        P.high + r.highRate * u ≤ upper *
          ((P.high + r.highRate * u) + (P.low + r.lowRate * u)) := by
        constructor
        · exact hgeometry.2
        · nlinarith [mul_nonneg hcoef hu0]
      have hsumEnd : Q.high + Q.low ≤ P.high + P.low + Cmax * T := by
        have hm := mul_nonneg hCmax (sub_nonneg.mpr huT)
        linarith
      have hscaled := (mul_le_mul_of_nonneg_left hsumEnd hscale.le).trans hbudget
      have hs := segment_increment H J sH sL scale priceH priceL P.high P.low
        r.highRate r.lowRate k r.boundary upper
        (sigma * (1 + mH * r.highRate + mL * r.lowRate)) weight u
        hscale hpriceH hpriceL hP.1 hP.2 hA hB hk hu0 hstart hfinish hscaled hlocal
      dsimp only [Q, advancePotential]
      convert hs using 1
      ring
    change sigma * (T + mH * ((idealUpdate base rs Q (T - u)).high - P.high) +
      mL * ((idealUpdate base rs Q (T - u)).low - P.low)) ≤
        (auxiliary H.value sH scale priceH (idealUpdate base rs Q (T - u)).high -
          auxiliary H.value sH scale priceH P.high) +
        (auxiliary J.value sL scale priceL (idealUpdate base rs Q (T - u)).low -
          auxiliary J.value sL scale priceL P.low) +
        T * k * max (1 - (priceH + priceL) / weight) 0
    nlinarith only [hpiece, htail]

/-- An accepted edge's exact rounded update satisfies the source increment
bound. Its charge uses ideal increments, and its budget uses rounded potentials. -/
theorem rounded_accepted_source_increment (H J : SourceFunction)
    (sH sL k sigma mH mL Cmax p priceH priceL weight grid : ℝ)
    (hsH : 0 ≤ sH) (hsL : 0 ≤ sL) (hk : 0 ≤ k) (hCmax : 0 ≤ Cmax)
    (hp : 0 < p) (hpriceH : 0 ≤ priceH) (hpriceL : 0 ≤ priceL)
    (hw : 0 < weight) (hgrid : 0 < grid)
    (base : PotentialStage) (rs : List PotentialStage) (P : PotentialPair)
    (hchain : RateChain H J sH sL k sigma mH mL Cmax base rs 1)
    (hP : 0 ≤ P.high ∧ 0 ≤ P.low) (horder : P.low ≤ P.high)
    (haccept : P.high + P.low ≤ weight) :
    sigma * (p * weight + mH * ((idealUpdate base rs P (p * weight)).high - P.high) +
      mL * ((idealUpdate base rs P (p * weight)).low - P.low)) ≤
      (auxiliary H.value sH (1 / (1 + p * Cmax)) priceH
          (roundedUpdate base rs P (p * weight) grid).high -
        auxiliary H.value sH (1 / (1 + p * Cmax)) priceH P.high) +
      (auxiliary J.value sL (1 / (1 + p * Cmax)) priceL
          (roundedUpdate base rs P (p * weight) grid).low -
        auxiliary J.value sL (1 / (1 + p * Cmax)) priceL P.low) +
      p * k * max (weight - priceH - priceL) 0 := by
  let scale : ℝ := 1 / (1 + p * Cmax)
  have hd : 0 < 1 + p * Cmax := by positivity
  have ht : 0 < scale := one_div_pos.mpr hd
  have hbudget : scale * (P.high + P.low + Cmax * (p * weight)) ≤ weight := by
    dsimp [scale]
    rw [one_div, inv_mul_eq_div]
    apply (div_le_iff₀ hd).2
    nlinarith
  have hi := idealUpdate_source_increment H J sH sL k sigma mH mL Cmax scale
    priceH priceL weight ht hpriceH hpriceL hk hCmax base rs 1 P (p * weight)
    hchain hP horder (Or.inr (by simp only [one_mul]; linarith [hP.2]))
    (mul_pos hp hw).le hbudget
  have hr := roundedUpdate_bounds base rs P (p * weight) grid hgrid
  have hH := auxiliary_monotone H.value sH scale priceH hsH ht hpriceH
    H.at_zero H.integrable H.nonnegative hr.1
  have hJ := auxiliary_monotone J.value sL scale priceL hsL ht hpriceL
    J.at_zero J.integrable J.nonnegative hr.2.2.1
  have hslack : p * weight * k * max (1 - (priceH + priceL) / weight) 0 =
      p * k * max (weight - priceH - priceL) 0 := by
    calc
      _ = p * k * (weight * max (1 - (priceH + priceL) / weight) 0) := by ring
      _ = p * k * max (weight - (priceH + priceL)) 0 := by
        rw [scale_positive_part weight (priceH + priceL) hw]
      _ = _ := by rw [sub_sub]
  rw [hslack] at hi
  change _ ≤ (auxiliary H.value sH scale priceH
      (roundedUpdate base rs P (p * weight) grid).high - auxiliary H.value sH scale priceH P.high) +
    (auxiliary J.value sL scale priceL
      (roundedUpdate base rs P (p * weight) grid).low - auxiliary J.value sL scale priceL P.low) + _
  linarith only [hi, hH, hJ]

end

end SubmodularMatching.SourceCertificate
