import SubmodularMatching.NonmonotoneOptimizerPaper
import SubmodularMatching.NonmonotoneFiniteMargin
import Mathlib.Data.Nat.Log

/-! # Dimension and precision for the signed optimizer

All optimizer payoffs are expressed in units of the positive scale guess.
The projection uses a dyadic denominator of degree four in the ascent scale.
The gradient and value queries use tolerance equal to its inverse square.
-/

namespace SubmodularMatching.NonmonotoneOptimizer
open AppendixM

def paperExponent (N : ℕ) := 36 + Nat.clog 2 (N+1)
def paperScale (N : ℕ) := scale (paperExponent N)
def paperDen (N : ℕ) := (paperScale N)^4
def queryTolerance (N : ℕ) : ℚ := 1/(paperScale N:ℚ)^2

theorem paperScale_bounds (N : ℕ) :
    2^36 ≤ paperScale N ∧ N+1 ≤ paperScale N ∧ paperScale N ≤ 2^37*(N+1) := by
  have e := Nat.le_pow_clog (by decide : 1 < 2) (N+1)
  have up : 2^(Nat.clog 2 (N+1)) ≤ 2*(N+1) := by
    cases he : Nat.clog 2 (N+1) with
    | zero => simp; omega
    | succ k =>
      have hN : 1 < N+1 := by
        by_contra! h
        have : N=0 := by omega
        simp [this] at he
      have h := Nat.pow_pred_clog_lt_self (by decide : 1<2) hN
      rw [he] at h
      simp only [Nat.pred_succ] at h
      rw [pow_succ]
      omega
  simp only [paperScale,paperExponent,scale,pow_add]
  constructor
  · exact Nat.le_mul_of_pos_right _ (by positivity)
  constructor
  · exact e.trans (Nat.le_mul_of_pos_left _ (by decide))
  · calc
      _ ≤ 2^36*(2*(N+1)) := Nat.mul_le_mul_left _ up
      _ = _ := by ring

theorem column_count {E : Type*} {n N : ℕ} (B : BlockData E n N) : N = n+n := by
  simpa using (Fintype.card_congr B.columns).symm

/-- Combined physical loss from the comparator mesh, ascent regret, query
gradient and best-score comparison. A difference of two value estimates
costs at most twice the query tolerance. -/
theorem physical_loss_with_decode (N : ℕ) (β γ τ opt : ℝ) (hβ : 0 ≤ β) (hβ' : β ≤ 1)
    (hγ : 0 ≤ γ) (hγ' : γ ≤ 1) (hτ : 0 ≤ τ) (hτ' : τ ≤ 2*opt) :
    let P : ℝ := paperScale N
    let δ : ℝ := queryTolerance N
    τ * ((P + β*δ)*(N:ℝ)^2/paperDen N + (5/P + N*(β*δ)) + 2*(2*γ*δ) + 2/P) ≤
      implementationUnit*opt/2 := by
  intro P δ
  have hBig : (2:ℝ)^36 ≤ P := by
    dsimp only [P]
    exact_mod_cast (paperScale_bounds N).1
  have h1 : 1 ≤ P := by norm_num at hBig; linarith only [hBig]
  have hp : 0 < P := by linarith only [h1]
  have hn : (N:ℝ) ≤ P := by
    dsimp only [P]
    exact_mod_cast (Nat.le_succ N).trans (paperScale_bounds N).2.1
  have hd : δ = 1/P^2 := by dsimp [δ, P, queryTolerance]; push_cast; rfl
  have hu : (paperDen N : ℝ) = P^4 := by simp [paperDen,P]
  have hd0 : 0 ≤ δ := by rw [hd]; positivity
  have hd1 : δ ≤ 1 := by rw [hd]; exact (div_le_one (sq_pos_of_pos hp)).mpr (one_le_pow₀ h1)
  have hbd : β*δ ≤ δ := by simpa using mul_le_mul_of_nonneg_right hβ' hd0
  have hgd : γ*δ ≤ δ := by simpa using mul_le_mul_of_nonneg_right hγ' hd0
  have n2 := pow_le_pow_left₀ (Nat.cast_nonneg N : 0 ≤ (N:ℝ)) hn 2
  have hrow : (P+β*δ)*(N:ℝ)^2/paperDen N ≤ 2/P := by
    rw [hu]
    have h := mul_le_mul (show P+β*δ ≤ 2*P by linarith only [hbd,hd1,h1])
      n2 (sq_nonneg _) (by positivity)
    apply (div_le_div_of_nonneg_right h (by positivity : (0:ℝ) ≤ P^4)).trans_eq
    field_simp <;> ring
  have hnδ : (N:ℝ)*(β*δ) ≤ 1/P := by
    apply (mul_le_mul hn hbd (mul_nonneg hβ hd0) hp.le).trans_eq
    rw [hd]; field_simp
  have hv : δ ≤ 1/P := by
    rw [hd]; exact one_div_le_one_div_of_le hp (by nlinarith only [mul_nonneg hp.le (sub_nonneg.mpr h1)])
  have hall : (P+β*δ)*(N:ℝ)^2/(paperDen N:ℝ) + (5/P+N*(β*δ)) + 2*(2*γ*δ) ≤ 12/P := by
    simp only [div_eq_mul_inv] at hrow hnδ hv ⊢
    nlinarith only [hrow,hnδ,hgd,hv]
  have hadd : (P+β*δ)*(N:ℝ)^2/(paperDen N:ℝ) + (5/P+N*(β*δ)) + 2*(2*γ*δ) + 2/P ≤ 14/P := by
    simp only [div_eq_mul_inv] at hall ⊢
    linarith only [hall]
  have hc : 14/P ≤ implementationUnit/4 := by
    apply (div_le_iff₀ hp).mpr
    norm_num [implementationUnit] at hBig ⊢
    linarith only [hBig]
  have h := mul_le_mul_of_nonneg_left (hadd.trans hc) hτ
  have h' := mul_le_mul_of_nonneg_right hτ' (by norm_num [implementationUnit] : 0 ≤ implementationUnit/4)
  linarith only [h,h']

end SubmodularMatching.NonmonotoneOptimizer
