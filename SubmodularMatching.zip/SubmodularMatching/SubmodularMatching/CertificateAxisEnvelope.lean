import SubmodularMatching.CertificateIntegerAxis

/-!
# Reusing certified lower chords on the knot tables

A height lies above a chord when its cleared cross-product dominates the
two endpoint heights. Any axis lower bound checked at the chord endpoints
then holds at that height, provided the height coefficient is nonnegative.
-/

namespace SubmodularMatching.SourceCertificate

def integerChordCheck (x h xLo hLo xHi hHi : ℕ) : Bool :=
  decide ((hLo : ℤ) * ((xHi : ℤ) - x) + (hHi : ℤ) * ((x : ℤ) - xLo) ≤
    (h : ℤ) * ((xHi : ℤ) - xLo))

theorem integerAxisCheck_of_chord (gridScale x h xLo hLo xHi hHi : ℕ)
    (weight penalty lower : ℤ) (hw : 0 ≤ weight)
    (hxLo : xLo ≤ x) (hxHi : x ≤ xHi) (horder : xLo < xHi)
    (hL : integerAxisCheck gridScale xLo hLo weight penalty lower = true)
    (hR : integerAxisCheck gridScale xHi hHi weight penalty lower = true)
    (hChord : integerChordCheck x h xLo hLo xHi hHi = true) :
    integerAxisCheck gridScale x h weight penalty lower = true := by
  have hl : lower ≤ weight * (hLo : ℤ) - penalty * (xLo : ℤ) := of_decide_eq_true hL
  have hr : lower ≤ weight * (hHi : ℤ) - penalty * (xHi : ℤ) := of_decide_eq_true hR
  have hz : (hLo : ℤ) * ((xHi : ℤ) - x) + (hHi : ℤ) * ((x : ℤ) - xLo) ≤
      (h : ℤ) * ((xHi : ℤ) - xLo) := of_decide_eq_true hChord
  have hxLo' : (xLo : ℤ) ≤ (x : ℤ) := by exact_mod_cast hxLo
  have hxHi' : (x : ℤ) ≤ (xHi : ℤ) := by exact_mod_cast hxHi
  have hspan : (0 : ℤ) < (xHi : ℤ) - xLo := sub_pos.mpr (by exact_mod_cast horder)
  have hleft := mul_le_mul_of_nonneg_right hl (sub_nonneg.mpr hxHi')
  have hright := mul_le_mul_of_nonneg_right hr (sub_nonneg.mpr hxLo')
  have hheight := mul_le_mul_of_nonneg_left hz hw
  apply decide_eq_true
  apply le_of_mul_le_mul_right _ hspan
  nlinarith only [hleft, hright, hheight]

end SubmodularMatching.SourceCertificate
