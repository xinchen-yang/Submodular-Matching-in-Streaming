import SubmodularMatching.NonmonotoneSlotGraph
import SubmodularMatching.NonmonotoneDiffuseGrid

/-! A common integer accumulator for slot-pair availability, despite differing capacities. -/

namespace SubmodularMatching.TwoLayerDiffuse

open GibbsMatching
open scoped BigOperators
noncomputable section

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- Each term is rounded alone; the accumulator is an integer on the common grid. -/
def floorSum (m : ℕ) (t : V → ℝ) : ℝ := (↑(∑ w, gridNumerator m (t w)) : ℝ)/m

theorem floorSum_bounds (m : ℕ) (hm : 0 < m) (t : V → ℝ) (h : ∀ v, 0 ≤ t v) :
    floorSum m t ≤ ∑ w, t w ∧ (∑ w, t w) - (Fintype.card V : ℝ)/m ≤ floorSum m t := by
  have hfloor : floorSum m t = ∑ w, gridValue m (t w) := by
    simp [floorSum,gridValue,Nat.cast_sum,Finset.sum_div]
  rw [hfloor]
  refine ⟨Finset.sum_le_sum (fun v _ => (gridValue_bounds m hm _ (h v)).2.1),?_⟩
  have hz := Finset.sum_le_sum (s := Finset.univ) (fun v _ => (gridValue_bounds m hm _ (h v)).2.2)
  simpa only [Finset.sum_sub_distrib,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one_div]
    using hz

def scanPairUpper (b : V → ℕ) (Y : V → V → ℝ) (θ : ℝ) (m : ℕ) (i j : Slots b) : ℝ :=
  let di := θ/(b i.1 : ℝ)*∑ w, Y i.1 w
  let dj := θ/(b j.1 : ℝ)*∑ w, Y j.1 w
  let a := slotWeight b Y θ i j
  let terms := fun w => (θ^2/((b i.1 : ℝ)*(b j.1 : ℝ))) * (Y i.1 w*Y j.1 w/(b w : ℝ))
  min 1 ((1-di)*(1-dj)+a*(1-di-dj+a)-floorSum m terms)

/-- The upper estimate computed by scanning original vertices, compared with
the actual one-layer probability on slots (independent of the two slot indices). -/
theorem scanPairUpper_error (b : V → ℕ) (hb : ∀ v, 0 < b v) (rank : Slots b ↪ ℕ)
    (Y : V → V → ℝ) (hs : ∀ u v, Y u v = Y v u) (hz : ∀ u, Y u u = 0)
    (hy : ∀ u v, 0 ≤ Y u v) (θ : ℝ) (m : ℕ) (hm : 0 < m)
    (i j : Slots b) (hne : i ≠ j)
    (hprob : Shearer.unmatchedPair pairVertices (orderedPairs rank) (fun z => slotWeight b Y θ z.1 z.2) i j ≤ 1) :
    let q := Shearer.unmatchedPair pairVertices (orderedPairs rank) (fun z => slotWeight b Y θ z.1 z.2) i j
    q ≤ scanPairUpper b Y θ m i j ∧ scanPairUpper b Y θ m i j ≤ 1 ∧
      scanPairUpper b Y θ m i j ≤ q + (Fintype.card V : ℝ)/m := by
  intro q
  let t := fun w => (θ^2/((b i.1 : ℝ)*(b j.1 : ℝ))) * (Y i.1 w*Y j.1 w/(b w : ℝ))
  have ht (w : V) : 0 ≤ t w := mul_nonneg (by positivity)
    (div_nonneg (mul_nonneg (hy _ _) (hy _ _)) (by positivity))
  obtain ⟨h₁,h₂⟩ := floorSum_bounds m hm t ht
  have hq := implicit_pair_probability b hb rank Y hs hz θ i j hne
  dsimp only at hq
  have heq : θ^2/((b i.1 : ℝ)*(b j.1 : ℝ)) * (∑ w, Y i.1 w*Y j.1 w/(b w : ℝ)) = ∑ w, t w := by
    rw [Finset.mul_sum]
  rw [heq] at hq
  change q = _ - (∑ w, t w) at hq
  dsimp only [scanPairUpper]
  refine ⟨le_min hprob ?_,min_le_left _ _,(min_le_right _ _).trans ?_⟩
  · change q ≤ _ - floorSum m t
    linarith only [hq,h₁]
  · change _ - floorSum m t ≤ q + _
    linarith only [hq,h₂]

/-- Multiplication of the two independently estimated layer denominators
adds their individual additive errors. -/
theorem independent_pair_upper (q₁ q₂ Q₁ Q₂ δ : ℝ) (hq₁ : 0 ≤ q₁) (hq₂ : 0 ≤ q₂)
    (h₁ : q₁ ≤ Q₁ ∧ Q₁ ≤ q₁+δ ∧ Q₁ ≤ 1) (h₂ : q₂ ≤ Q₂ ∧ Q₂ ≤ q₂+δ ∧ Q₂ ≤ 1) :
    q₁*q₂ ≤ Q₁*Q₂ ∧ Q₁*Q₂ ≤ q₁*q₂+2*δ := by
  refine ⟨mul_le_mul h₁.1 h₂.1 hq₂ (hq₁.trans h₁.1),?_⟩
  have he : 0 ≤ δ := by linarith only [h₁.1,h₁.2.1]
  have hp₁ := mul_le_mul_of_nonneg_right h₁.2.1 hq₂
  have hp₂ := mul_le_mul_of_nonneg_left h₂.2.1 (hq₁.trans h₁.1)
  nlinarith only [hp₁,hp₂,mul_le_mul_of_nonneg_right h₁.2.2 he,
    mul_le_mul_of_nonneg_right (h₂.1.trans h₂.2.2) he]

end
end SubmodularMatching.TwoLayerDiffuse
