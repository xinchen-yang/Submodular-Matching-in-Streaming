import SubmodularMatching.UpperBoundCertifiedInteriorBand
import SubmodularMatching.UpperBoundParametricCorollary
import SubmodularMatching.ReplayUncoveredMiddle.Result

/-! # The upper bounds with the complete kernel-checked price certificate -/

namespace SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream

open SourceCertificate UpperBoundAssembly GibbsSampler NumericalCertificate

noncomputable section

theorem completeSourceObligation (n : ℕ) (hn : 2 ≤ n) : AppendixSourceObligation n hn :=
  appendixSourceObligation_of_nextBand n hn Replay.UncoveredMiddle.checked

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- The fixed approximation factor with the complete numerical premise
proved by exact standard-kernel certificate replay. -/
theorem theorem1_1_verified (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, f M ≤ f O)
    (delta : ℝ) (hδ : 0 < delta) :
    let p := S.expectedOutput f hf hm
    let q := S.amplifiedOutput f hf hm delta
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / targetFactor ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤ delta :=
  S.theorem1_1_value f hf hm h0 (completeSourceObligation (Fintype.card V)) O hO hopt delta hδ

/-- The manuscript's inverse-polynomial confidence guarantee. -/
theorem theorem1_1_confidence_verified (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, f M ≤ f O)
    (hn : 1 ≤ Fintype.card V) (c : ℝ) :
    let n := Fintype.card V
    let delta := (((n : ℝ) ^ ⌈c⌉₊)⁻¹)
    let q := S.amplifiedOutput f hf hm delta
    q.outcomes ⊆ S.matchings ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤
        (n : ℝ) ^ (-c) :=
  S.theorem1_1_confidence f hf hm h0 (completeSourceObligation (Fintype.card V)) O hO hopt hn c

/-- The numerical certificate also supplies the paper's full
fixed-accuracy family. -/
theorem approximationFamily_verified (S : SimpleEdgeStream E V) {slack : ℝ}
    (a : FamilyParameters slack) (hslack : 0 < slack) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, f M ≤ f O)
    (delta : ℝ) (hδ : 0 < delta) :
    let p := S.familyExpectedOutput a f hf hm
    let q := S.familyAmplifiedOutput a f hf hm delta
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / a.target ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / a.target ≤ f M then 0 else 1) ≤ delta :=
  S.approximationFamily_value a hslack f hf hm h0 (completeSourceObligation (Fintype.card V))
    O hO hopt delta hδ

/-- The complete approximation-family result chooses one set of fixed
parameters for each ratio and works uniformly on all input streams. -/
theorem approximationFamily_corollary_verified (ratio : ℝ) (hr : (45246551 : ℝ) / 10000000 < ratio) :
    ∃ a : FamilyParameters (ratio - 45246551 / 10000000),
      ∀ (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
        (hf : IsSubmodular f) (hmono : IsMonotone f) (_h0 : 0 ≤ f ∅)
        (O : Finset E) (_hO : O ∈ S.matchings)
        (_hopt : ∀ M ∈ S.matchings, f M ≤ f O) (δ : ℝ) (_hδ : 0 < δ),
        let p := S.familyExpectedOutput a f hf hmono
        let q := S.familyAmplifiedOutput a f hf hmono δ
        p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
          f O / ratio ≤ expected p.outcomes p.mass f ∧
          expected q.outcomes q.mass (fun M => if f O / ratio ≤ f M then 0 else 1) ≤ δ :=
  UpperBoundAssembly.approximationFamily_corollary ratio hr (completeSourceObligation (Fintype.card V))


end

end SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream
