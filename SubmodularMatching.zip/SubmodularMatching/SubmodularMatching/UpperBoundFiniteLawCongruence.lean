import SubmodularMatching.UpperBoundAssignment

/-! # Replacing specification laws by equivalent executable word draws -/

namespace SubmodularMatching.UpperBoundAssembly.CandidateLaw

open GibbsSampler

noncomputable section

variable {A : Type*}

theorem execute_congr_expected (step₁ step₂ : ℕ → A → CandidateLaw A)
    (hstep : ∀ j a (test : A → ℝ),
      expected (step₁ j a).outcomes (step₁ j a).mass test =
        expected (step₂ j a).outcomes (step₂ j a).mass test)
    (n j : ℕ) (initial : A) (test : A → ℝ) :
    expected (execute step₁ n j initial).outcomes (execute step₁ n j initial).mass test =
      expected (execute step₂ n j initial).outcomes (execute step₂ n j initial).mass test := by
  induction n generalizing j initial with
  | zero => rfl
  | succ n ih =>
    rw [execute_expected, execute_expected, hstep]
    apply congrArg (expected (step₂ j initial).outcomes (step₂ j initial).mass)
    funext a
    exact ih (j + 1) a

variable {F : ℕ → Type*}

theorem assign_congr_expected (choices₁ choices₂ : ∀ j, CandidateLaw (F j))
    (hchoice : ∀ j (test : F j → ℝ), expected (choices₁ j).outcomes (choices₁ j).mass test =
      expected (choices₂ j).outcomes (choices₂ j).mass test)
    (is : List ℕ) (initial : ∀ j, F j) (test : (∀ j, F j) → ℝ) :
    expected (assign choices₁ is initial).outcomes (assign choices₁ is initial).mass test =
      expected (assign choices₂ is initial).outcomes (assign choices₂ is initial).mass test := by
  classical
  induction is generalizing initial with
  | nil => rfl
  | cons j rest ih =>
    change expected ((choices₁ j).bind fun a => assign choices₁ rest (Function.update initial j a)).outcomes
      ((choices₁ j).bind fun a => assign choices₁ rest (Function.update initial j a)).mass test =
      expected ((choices₂ j).bind fun a => assign choices₂ rest (Function.update initial j a)).outcomes
        ((choices₂ j).bind fun a => assign choices₂ rest (Function.update initial j a)).mass test
    rw [bind_expected, bind_expected, hchoice]
    apply congrArg (expected (choices₂ j).outcomes (choices₂ j).mass)
    funext a
    exact ih (Function.update initial j a)

end

end SubmodularMatching.UpperBoundAssembly.CandidateLaw
