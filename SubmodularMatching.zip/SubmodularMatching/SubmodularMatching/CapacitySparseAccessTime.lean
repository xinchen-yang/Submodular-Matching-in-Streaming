import SubmodularMatching.CapacityIndexCursor
import SubmodularMatching.CapacitySparseOnline

/-! Lookup and cardinality scans of the existing sparse capacity algorithms. -/
namespace SubmodularMatching.Capacity
open Streaming
variable {E T V : Type*}

/-- Instrument the tail-recursive slot index reader using a counter that
charges one source-label inspection for each visited list record. -/
def countedSeek (len : E → ℕ) (emit : (e : E) → Fin (len e) → T) :
    List E → ℕ → ℕ → Option T × ℕ
  | [],_,k => (none,k)
  | e::s,i,k => if h : i<len e then (some (emit e ⟨i,h⟩),k+1)
    else countedSeek len emit s (i-len e) (k+1)

theorem countedSeek_spec (len : E → ℕ) (emit : (e : E) → Fin (len e) → T)
    (s : List E) (i k : ℕ) : (countedSeek len emit s i k).1 = seekBlock len emit s i ∧
      (countedSeek len emit s i k).2 ≤ k+s.length := by
  induction s generalizing i k with
  | nil => exact ⟨rfl,by simp [countedSeek]⟩
  | cons e s ih =>
    simp only [countedSeek,seekBlock]
    split_ifs
    · exact ⟨rfl,by simp⟩
    · exact ⟨(ih _ _).1,(ih _ _).2.trans_eq (by simp; omega)⟩

/-- At most one stored vertex record is visited per list cell in an index lookup. -/
def countedIndex [DecidableEq V] : List (V×ℕ) → V → ℕ → ℕ×ℕ
  | [],_,k => (0,k)
  | (v,val)::tail,u,k => if u=v then (val,k+1) else countedIndex tail u (k+1)

theorem countedIndex_spec [DecidableEq V] (entries : List (V×ℕ)) (v : V) (k : ℕ) :
    (countedIndex entries v k).1 = indexAt entries v ∧ (countedIndex entries v k).2 ≤ k+entries.length := by
  induction entries generalizing k with
  | nil => exact ⟨rfl,by simp [countedIndex]⟩
  | cons a xs ih =>
    rcases a with ⟨a,w⟩
    simp only [countedIndex,indexAt]
    split_ifs
    · exact ⟨rfl,by simp⟩
    · exact ⟨(ih _).1,(ih _).2.trans_eq (by simp; omega)⟩

def countedMinScan (read : ℕ → ℕ×ℕ) (best next todo k : ℕ) : ℕ × ℕ :=
  match todo with
  | 0 => (best,k)
  | t+1 =>
    let x := read next
    let b := read best
    countedMinScan read (if x.1<b.1 then next else best) (next+1) t (k+x.2+b.2)

theorem countedMinScan_spec (read : ℕ → ℕ×ℕ) (values : ℕ → ℕ) (s : ℕ)
    (hval : ∀ j, (read j).1=values j) (hcost : ∀ j, (read j).2≤s)
    (best next todo k : ℕ) : (countedMinScan read best next todo k).1=scanIndex values best next todo ∧
    (countedMinScan read best next todo k).2 ≤ k+2*todo*s := by
  induction todo generalizing best next k with
  | zero => exact ⟨rfl,by simp [countedMinScan]⟩
  | succ t ih =>
    simp only [countedMinScan,scanIndex,hval]
    refine ⟨(ih _ _ _).1,(ih _ _ _).2.trans ?_⟩
    have h := Nat.add_le_add (hcost next) (hcost best)
    rw [show 2*(t+1)*s=2*t*s+(s+s) by ring]
    omega

theorem sparseMinimum_work [DecidableEq V] (cap : V→ℕ) (v : V) (hv : 0<cap v)
    (entries : List (BSlot cap×ℕ)) :
    let read (j : ℕ) := if h : j<cap v then countedIndex entries ⟨v,⟨j,h⟩⟩ 0 else (0,0)
    let cost := countedMinScan read 0 1 (cap v-1) 0
    cost.1=(sparseMinimum cap entries v hv).val ∧ cost.2 ≤ 2*(cap v-1)*entries.length := by
  intro read cost
  have he (j : ℕ) : (read j).1=slotIndex cap entries v j := by
    dsimp only [read,slotIndex]; split_ifs <;> first | rfl | exact (countedIndex_spec ..).1
  have hc (j : ℕ) : (read j).2 ≤ entries.length := by
    dsimp only [read]; split_ifs <;> first | exact Nat.zero_le _ | simpa only [Nat.zero_add] using (countedIndex_spec entries _ 0).2
  exact (by simpa only [sparseMinimum,Nat.zero_add] using countedMinScan_spec read _ _ he hc 0 1 (cap v-1) 0)

end SubmodularMatching.Capacity
