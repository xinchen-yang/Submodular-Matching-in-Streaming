import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull015_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 711, 712, 1, 0x1642c7⟩ (by decide +kernel)

private def hull015_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 712, 713, 1, 0x164ac8⟩ (by decide +kernel)

private def hull015_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 713, 1, 0x164ac5⟩ (by decide +kernel)

private def hull015_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 713, 715, 1, 0x165ac9⟩ (by decide +kernel)

private def hull015_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 715, 717, 1, 0x166acb⟩ (by decide +kernel)

private def hull015_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 713, 714, 1, 0x1652c9⟩ (by decide +kernel)

private def hull015_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 714, 715, 1, 0x165aca⟩ (by decide +kernel)

private def hull015_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 713, 717, 1, 0x166ac9⟩ (by decide +kernel)

private def hull015_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 715, 716, 1, 0x1662cb⟩ (by decide +kernel)

private def hull015_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 716, 717, 1, 0x166acc⟩ (by decide +kernel)

private def hull015_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 717, 1, 0x166ac5⟩ (by decide +kernel)

private def hull015_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 717, 719, 2, 0xb3d672cd⟩ (by decide +kernel)

private def hull015_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 719, 721, 2, 0xb45682cf⟩ (by decide +kernel)

private def hull015_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 721, 726, 5, 0x16b2d55a8b4d692d1⟩ (by decide +kernel)

private def hull015_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 717, 726, 8, 0x2d65aab5169ad25a0b3d672cd⟩ (by decide +kernel)

private def hull015_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 717, 721, 4, 0x2d15a0b3d672cd⟩ (by decide +kernel)

private def hull015_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 851, 24, 0x35369ad31a432b654c3d8630b5f2be173ae55c8b8d6e2db5b4b656bad65aab5169ac5⟩ (by decide +kernel)

private def hull015_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 35, 18, 0x8c1102104007c0f01d03806c0d01903005c0b01502804c09011⟩ (by decide +kernel)

private def hull015_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 567, 851, 49, 0x1a9b4d698d2195b2a61ec3185af95f0b9d72ae45c6b716dada5b2b5d6b2d55a8b4d622c2582afd5f2ab554a9d53295528a4948a895109fd3f27b4f49cd392624c29812fa37⟩ (by decide +kernel)

private def hull015_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 726, 4, 0x2d65aab5169ac5⟩ (by decide +kernel)

private def hull015_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 726, 728, 2, 0xb616bad6⟩ (by decide +kernel)

private def hull015_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 728, 730, 2, 0xb696cad8⟩ (by decide +kernel)

private def hull015_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 730, 735, 3, 0x5beb716dada⟩ (by decide +kernel)

private def hull015_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 735, 744, 5, 0x1742e75cab9171adf⟩ (by decide +kernel)

private def hull015_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 21, 26, 5, 0xd01903005c0b015⟩ (by decide +kernel)

private def hull015_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 726, 730, 3, 0x5b4b656bad6⟩ (by decide +kernel)

private def hull015_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 726, 735, 6, 0xb7d6e2db5b4b656bad6⟩ (by decide +kernel)

private def hull015_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 730, 732, 2, 0xb716dada⟩ (by decide +kernel)

private def hull015_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 732, 733, 1, 0x16eadc⟩ (by decide +kernel)

private def hull015_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 733, 735, 1, 0x16fadd⟩ (by decide +kernel)

private def hull015_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 732, 735, 1, 0x16fadc⟩ (by decide +kernel)

private def hull015_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 733, 734, 1, 0x16f2dd⟩ (by decide +kernel)

private def hull015_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 734, 735, 1, 0x16fade⟩ (by decide +kernel)

private def hull015_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 21, 23, 2, 0x5c0b015⟩ (by decide +kernel)

private def hull015_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 23, 26, 3, 0x340640c017⟩ (by decide +kernel)

private def hull015_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 735, 737, 1, 0x170adf⟩ (by decide +kernel)

private def hull015_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 737, 739, 1, 0x171ae1⟩ (by decide +kernel)

private def hull015_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 739, 744, 4, 0x2e85ceb95722e3⟩ (by decide +kernel)

private def hull015_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 735, 736, 1, 0x1702df⟩ (by decide +kernel)

private def hull015_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 736, 737, 1, 0x170ae0⟩ (by decide +kernel)

private def hull015_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 141, 132, 0x8d11822c4508911021c4308510820c410811001fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull015_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 26, 9, 0xd01903005c0b01502804c09011⟩ (by decide +kernel)

private def hull015_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 744, 14, 0xba173ae55c8b8d6e2db5b4b656bad65aab5169ac5⟩ (by decide +kernel)

private def hull015_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 737, 738, 1, 0x1712e1⟩ (by decide +kernel)

private def hull015_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 738, 739, 1, 0x171ae2⟩ (by decide +kernel)

private def hull015_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 735, 739, 1, 0x171adf⟩ (by decide +kernel)

private def hull015_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 739, 741, 2, 0xb95722e3⟩ (by decide +kernel)

private def hull015_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 741, 742, 1, 0x1732e5⟩ (by decide +kernel)

private def hull015_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 742, 744, 2, 0xba173ae6⟩ (by decide +kernel)

private def hull015_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 23, 24, 1, 0xc017⟩ (by decide +kernel)

private def hull015_050 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 741, 744, 2, 0xba173ae5⟩ (by decide +kernel)

private def hull015_051 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 24, 26, 2, 0x680c818⟩ (by decide +kernel)

private def hull015_052 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 726, 744, 10, 0xba173ae55c8b8d6e2db5b4b656bad6⟩ (by decide +kernel)

private def hull015_053 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 70, 61, 0x2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull015_054 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 709, 780, 17, 0x18630b5f2be173ae55c8b8d6e2db5b4b656bad65aab5169ac5⟩ (by decide +kernel)

private def hull015_055 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 744, 753, 1, 0x178ae8⟩ (by decide +kernel)

private def hull015_056 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 753, 762, 3, 0x5f4be57c2f1⟩ (by decide +kernel)

private def hull015_057 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 762, 780, 2, 0xc3185afa⟩ (by decide +kernel)

private def hull015_058 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 744, 748, 1, 0x1762e8⟩ (by decide +kernel)

private def hull015_059 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 748, 753, 1, 0x178aec⟩ (by decide +kernel)

private def hull015_060 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 744, 746, 2, 0xba974ae8⟩ (by decide +kernel)

private def hull015_061 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 746, 748, 1, 0x1762ea⟩ (by decide +kernel)

private def hull015_062 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 746, 747, 1, 0x175aea⟩ (by decide +kernel)

private def hull015_063 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 747, 748, 1, 0x1762eb⟩ (by decide +kernel)

private def hull015_064 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 748, 750, 1, 0x1772ec⟩ (by decide +kernel)

private def hull015_065 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 750, 753, 1, 0x178aee⟩ (by decide +kernel)

private def hull015_066 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 748, 749, 1, 0x176aec⟩ (by decide +kernel)

private def hull015_067 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 749, 750, 1, 0x1772ed⟩ (by decide +kernel)

private def supportedCone1920 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨711, 712, 712, 711, 712⟩, ⟨5000000000, 53716307, 0, 0, 2180000000000, 670609338882⟩⟩
    hull015_000 1 (by decide +kernel)

private def supportedCone1921 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨712, 713, 712, 712, 713⟩, ⟨0, 0, 5000000000, 53656892, 2180000000000, 670609338882⟩⟩
    hull015_001 0 (by decide +kernel)

private def supportedCone1922 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨712, 713, 713, 712, 713⟩, ⟨5000000000, 53656892, 0, 0, 2185000000000, 670662995774⟩⟩
    hull015_001 1 (by decide +kernel)

private def supportedCone1923 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 713, 713, 709, 713⟩, ⟨20000000000, 236045683, 0, 0, 2185000000000, 670662995774⟩⟩
    hull015_002 1 (by decide +kernel)

private def supportedCone1924 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨713, 715, 713, 713, 715⟩, ⟨0, 0, 10000000000, 106537584, 2185000000000, 670662995774⟩⟩
    hull015_003 0 (by decide +kernel)

private def supportedCone1925 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨715, 717, 715, 715, 717⟩, ⟨0, 0, 10000000000, 105519090, 2195000000000, 670769533358⟩⟩
    hull015_004 0 (by decide +kernel)

private def supportedCone1926 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨713, 714, 713, 713, 714⟩, ⟨0, 0, 5000000000, 53387468, 2185000000000, 670662995774⟩⟩
    hull015_005 0 (by decide +kernel)

private def supportedCone1927 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨714, 715, 714, 714, 715⟩, ⟨0, 0, 5000000000, 53150116, 2190000000000, 670716383242⟩⟩
    hull015_006 0 (by decide +kernel)

private def supportedCone1928 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨713, 714, 714, 713, 714⟩, ⟨5000000000, 53387468, 0, 0, 2190000000000, 670716383242⟩⟩
    hull015_005 1 (by decide +kernel)

private def supportedCone1929 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨713, 715, 715, 713, 715⟩, ⟨10000000000, 106537584, 0, 0, 2195000000000, 670769533358⟩⟩
    hull015_003 1 (by decide +kernel)

private def supportedCone1930 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨714, 715, 715, 714, 715⟩, ⟨5000000000, 53150116, 0, 0, 2195000000000, 670769533358⟩⟩
    hull015_006 1 (by decide +kernel)

private def supportedCone1931 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨713, 717, 717, 713, 717⟩, ⟨20000000000, 212056674, 0, 0, 2205000000000, 670875052448⟩⟩
    hull015_007 1 (by decide +kernel)

private def supportedCone1932 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨715, 716, 715, 715, 716⟩, ⟨0, 0, 5000000000, 52877336, 2195000000000, 670769533358⟩⟩
    hull015_008 0 (by decide +kernel)

private def supportedCone1933 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨716, 717, 716, 716, 717⟩, ⟨0, 0, 5000000000, 52641754, 2200000000000, 670822410694⟩⟩
    hull015_009 0 (by decide +kernel)

private def supportedCone1934 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨715, 716, 716, 715, 716⟩, ⟨5000000000, 52877336, 0, 0, 2200000000000, 670822410694⟩⟩
    hull015_008 1 (by decide +kernel)

private def supportedCone1935 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨715, 717, 717, 715, 717⟩, ⟨10000000000, 105519090, 0, 0, 2205000000000, 670875052448⟩⟩
    hull015_004 1 (by decide +kernel)

private def supportedCone1936 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 717, 717, 709, 717⟩, ⟨40000000000, 448102357, 0, 0, 2205000000000, 670875052448⟩⟩
    hull015_010 1 (by decide +kernel)

private def supportedCone1937 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨716, 717, 717, 716, 717⟩, ⟨5000000000, 52641754, 0, 0, 2205000000000, 670875052448⟩⟩
    hull015_009 1 (by decide +kernel)

private def supportedCone1938 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 719, 717, 717, 718⟩, ⟨0, 0, 5000000000, 52372338, 2205000000000, 670875052448⟩⟩
    hull015_011 0 (by decide +kernel)

private def supportedCone1939 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨719, 721, 719, 719, 720⟩, ⟨0, 0, 5000000000, 53534817, 2215000000000, 670979952740⟩⟩
    hull015_012 0 (by decide +kernel)

private def supportedCone1940 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨721, 726, 721, 721, 722⟩, ⟨0, 0, 5000000000, 53593583, 2225000000000, 671087419488⟩⟩
    hull015_013 0 (by decide +kernel)

private def supportedCone1941 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 726, 718, 717, 719⟩, ⟨5000000000, 52372338, 5000000000, 52527954, 2210000000000, 670927424786⟩⟩
    hull015_014 1 (by decide +kernel)

private def supportedCone1942 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 721, 717, 717, 718⟩, ⟨0, 0, 5000000000, 52372338, 2205000000000, 670875052448⟩⟩
    hull015_015 0 (by decide +kernel)

private def supportedCone1943 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 721, 721, 720, 721⟩, ⟨5000000000, 53931931, 0, 0, 2225000000000, 671087419488⟩⟩
    hull015_015 4 (by decide +kernel)

private def supportedCone1944 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 726, 722, 720, 723⟩, ⟨10000000000, 107525514, 5000000000, 54573418, 2230000000000, 671141013071⟩⟩
    hull015_014 4 (by decide +kernel)

private def supportedCone1945 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 726, 719, 718, 720⟩, ⟨5000000000, 52527954, 5000000000, 53534817, 2215000000000, 670979952740⟩⟩
    hull015_014 2 (by decide +kernel)

private def supportedCone1946 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 851, 725, 724, 726⟩, ⟨5000000000, 60110100, 5000000000, 62542085, 2245000000000, 671312688607⟩⟩
    hull015_016 3 (by decide +kernel)

private def supportedCone1947 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 726, 720, 719, 722⟩, ⟨5000000000, 53534817, 10000000000, 107525514, 2220000000000, 671033487557⟩⟩
    hull015_014 3 (by decide +kernel)

private def supportedCone1948 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 721, 720, 719, 721⟩, ⟨5000000000, 53534817, 5000000000, 53931931, 2220000000000, 671033487557⟩⟩
    hull015_015 3 (by decide +kernel)

private def supportedCone1949 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 33, 32, 34⟩, ⟨1263823080, 49116029, 827221629, 34669607, 257669451199, 548307064⟩⟩
    hull015_017 16 (by decide +kernel)

private def supportedCone1950 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 21, 20, 22⟩, ⟨1970044404, 29103683, 1444783328, 26634160, 242625893577, 107379951⟩⟩
    hull015_017 4 (by decide +kernel)

private def supportedCone1951 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨721, 726, 722, 721, 723⟩, ⟨5000000000, 53593583, 5000000000, 54573418, 2230000000000, 671141013071⟩⟩
    hull015_013 1 (by decide +kernel)

def appendixHullConeBlock0060 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1920,
    supportedCone1921,
    supportedCone1922,
    supportedCone1923,
    supportedCone1924,
    supportedCone1925,
    supportedCone1926,
    supportedCone1927,
    supportedCone1928,
    supportedCone1929,
    supportedCone1930,
    supportedCone1931,
    supportedCone1932,
    supportedCone1933,
    supportedCone1934,
    supportedCone1935,
    supportedCone1936,
    supportedCone1937,
    supportedCone1938,
    supportedCone1939,
    supportedCone1940,
    supportedCone1941,
    supportedCone1942,
    supportedCone1943,
    supportedCone1944,
    supportedCone1945,
    supportedCone1946,
    supportedCone1947,
    supportedCone1948,
    supportedCone1949,
    supportedCone1950,
    supportedCone1951,
  ], rfl⟩

private def supportedCone1952 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨717, 726, 723, 722, 724⟩, ⟨5000000000, 54573418, 5000000000, 56992018, 2235000000000, 671195586489⟩⟩
    hull015_014 5 (by decide +kernel)

private def supportedCone1953 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 851, 724, 723, 725⟩, ⟨5000000000, 56992018, 5000000000, 60110100, 2240000000000, 671252578507⟩⟩
    hull015_016 2 (by decide +kernel)

private def supportedCone1954 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 724, 723, 725⟩, ⟨5000000000, 56992018, 5000000000, 60110100, 2240000000000, 671252578507⟩⟩
    hull015_018 27 (by decide +kernel)

private def supportedCone1955 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 725, 724, 726⟩, ⟨5000000000, 60110100, 5000000000, 62542085, 2245000000000, 671312688607⟩⟩
    hull015_018 28 (by decide +kernel)

private def supportedCone1956 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 729, 727, 730⟩, ⟨10000000000, 128994694, 5000000000, 66596355, 2265000000000, 671568493546⟩⟩
    hull015_018 31 (by decide +kernel)

private def supportedCone1957 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 726, 726, 725, 726⟩, ⟨5000000000, 62542085, 0, 0, 2250000000000, 671375230692⟩⟩
    hull015_019 4 (by decide +kernel)

private def supportedCone1958 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨726, 728, 728, 727, 728⟩, ⟨5000000000, 64541395, 0, 0, 2260000000000, 671504040247⟩⟩
    hull015_020 2 (by decide +kernel)

private def supportedCone1959 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨728, 730, 728, 728, 729⟩, ⟨0, 0, 5000000000, 64453299, 2260000000000, 671504040247⟩⟩
    hull015_021 0 (by decide +kernel)

private def supportedCone1960 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨730, 735, 730, 730, 731⟩, ⟨0, 0, 5000000000, 69194080, 2270000000000, 671635089901⟩⟩
    hull015_022 0 (by decide +kernel)

private def supportedCone1961 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨735, 744, 735, 735, 739⟩, ⟨0, 0, 17000000000, 238804894, 2295000000000, 671988424284⟩⟩
    hull015_023 0 (by decide +kernel)

private def supportedCone1962 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨726, 728, 727, 726, 728⟩, ⟨5000000000, 64268160, 5000000000, 64541395, 2255000000000, 671439498852⟩⟩
    hull015_020 1 (by decide +kernel)

private def supportedCone1963 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 730, 729, 731⟩, ⟨5000000000, 66596355, 5000000000, 69194080, 2270000000000, 671635089901⟩⟩
    hull015_018 32 (by decide +kernel)

private def supportedCone1964 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨21, 26, 26, 25, 26⟩, ⟨1603882869, 43246842, 0, 0, 249154536560, 259521177⟩⟩
    hull015_024 5 (by decide +kernel)

private def supportedCone1965 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨726, 730, 727, 726, 729⟩, ⟨5000000000, 64268160, 10000000000, 128994694, 2255000000000, 671439498852⟩⟩
    hull015_025 1 (by decide +kernel)

private def supportedCone1966 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨726, 730, 730, 729, 730⟩, ⟨5000000000, 66596355, 0, 0, 2270000000000, 671635089901⟩⟩
    hull015_025 3 (by decide +kernel)

private def supportedCone1967 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 731, 730, 732⟩, ⟨5000000000, 69194080, 5000000000, 70519163, 2275000000000, 671704283981⟩⟩
    hull015_018 33 (by decide +kernel)

private def supportedCone1968 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 732, 731, 739⟩, ⟨5000000000, 70519163, 32000000000, 452426034, 2280000000000, 671774803144⟩⟩
    hull015_018 34 (by decide +kernel)

private def supportedCone1969 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 740, 739, 741⟩, ⟨3000000000, 42631294, 5000000000, 73311669, 2315000000000, 672269860472⟩⟩
    hull015_018 36 (by decide +kernel)

private def supportedCone1970 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 779, 761, 780⟩, ⟨80000000000, 1191540500, 5000000000, 75276437, 2500000000000, 675019206928⟩⟩
    hull015_018 41 (by decide +kernel)

private def supportedCone1971 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨726, 735, 732, 731, 735⟩, ⟨5000000000, 70519163, 15000000000, 213621140, 2280000000000, 671774803144⟩⟩
    hull015_026 5 (by decide +kernel)

private def supportedCone1972 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨730, 732, 732, 731, 732⟩, ⟨5000000000, 70519163, 0, 0, 2280000000000, 671774803144⟩⟩
    hull015_027 2 (by decide +kernel)

private def supportedCone1973 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨732, 733, 733, 732, 733⟩, ⟨5000000000, 71475835, 0, 0, 2285000000000, 671846278979⟩⟩
    hull015_028 1 (by decide +kernel)

private def supportedCone1974 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨733, 735, 733, 733, 735⟩, ⟨0, 0, 10000000000, 142145305, 2285000000000, 671846278979⟩⟩
    hull015_029 0 (by decide +kernel)

private def supportedCone1975 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨726, 735, 735, 732, 735⟩, ⟨15000000000, 213621140, 0, 0, 2295000000000, 671988424284⟩⟩
    hull015_026 6 (by decide +kernel)

private def supportedCone1976 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 739, 732, 740⟩, ⟨32000000000, 452426034, 3000000000, 42631294, 2312000000000, 672227229178⟩⟩
    hull015_018 35 (by decide +kernel)

private def supportedCone1977 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨732, 733, 732, 732, 733⟩, ⟨0, 0, 5000000000, 71475835, 2280000000000, 671774803144⟩⟩
    hull015_028 0 (by decide +kernel)

private def supportedCone1978 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨732, 735, 735, 732, 735⟩, ⟨15000000000, 213621140, 0, 0, 2295000000000, 671988424284⟩⟩
    hull015_030 1 (by decide +kernel)

private def supportedCone1979 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨732, 735, 732, 732, 735⟩, ⟨0, 0, 15000000000, 213621140, 2280000000000, 671774803144⟩⟩
    hull015_030 0 (by decide +kernel)

private def supportedCone1980 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨733, 735, 735, 733, 735⟩, ⟨10000000000, 142145305, 0, 0, 2295000000000, 671988424284⟩⟩
    hull015_029 1 (by decide +kernel)

private def supportedCone1981 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨733, 734, 733, 733, 734⟩, ⟨0, 0, 5000000000, 71245417, 2285000000000, 671846278979⟩⟩
    hull015_031 0 (by decide +kernel)

private def supportedCone1982 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨734, 735, 734, 734, 735⟩, ⟨0, 0, 5000000000, 70899888, 2290000000000, 671917524396⟩⟩
    hull015_032 0 (by decide +kernel)

private def supportedCone1983 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨733, 734, 734, 733, 734⟩, ⟨5000000000, 71245417, 0, 0, 2290000000000, 671917524396⟩⟩
    hull015_031 1 (by decide +kernel)

def appendixHullConeBlock0061 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1952,
    supportedCone1953,
    supportedCone1954,
    supportedCone1955,
    supportedCone1956,
    supportedCone1957,
    supportedCone1958,
    supportedCone1959,
    supportedCone1960,
    supportedCone1961,
    supportedCone1962,
    supportedCone1963,
    supportedCone1964,
    supportedCone1965,
    supportedCone1966,
    supportedCone1967,
    supportedCone1968,
    supportedCone1969,
    supportedCone1970,
    supportedCone1971,
    supportedCone1972,
    supportedCone1973,
    supportedCone1974,
    supportedCone1975,
    supportedCone1976,
    supportedCone1977,
    supportedCone1978,
    supportedCone1979,
    supportedCone1980,
    supportedCone1981,
    supportedCone1982,
    supportedCone1983,
  ], rfl⟩

private def supportedCone1984 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 761, 760, 779⟩, ⟨5000000000, 74348908, 80000000000, 1191540500, 2420000000000, 673827666428⟩⟩
    hull015_018 40 (by decide +kernel)

private def supportedCone1985 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨21, 23, 23, 22, 23⟩, ⟨929323095, 19209070, 0, 0, 245000000000, 153223181⟩⟩
    hull015_033 2 (by decide +kernel)

private def supportedCone1986 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨23, 26, 26, 25, 26⟩, ⟨1603882869, 43246842, 0, 0, 249154536560, 259521177⟩⟩
    hull015_034 3 (by decide +kernel)

private def supportedCone1987 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨23, 26, 24, 23, 25⟩, ⟨1407888149, 33953019, 1142765542, 29098135, 246407888149, 187176200⟩⟩
    hull015_034 1 (by decide +kernel)

private def supportedCone1988 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨734, 735, 735, 734, 735⟩, ⟨5000000000, 70899888, 0, 0, 2295000000000, 671988424284⟩⟩
    hull015_032 1 (by decide +kernel)

private def supportedCone1989 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨735, 744, 739, 735, 740⟩, ⟨17000000000, 238804894, 3000000000, 42631294, 2312000000000, 672227229178⟩⟩
    hull015_023 1 (by decide +kernel)

private def supportedCone1990 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨735, 737, 737, 735, 737⟩, ⟨10000000000, 140874241, 0, 0, 2305000000000, 672129298525⟩⟩
    hull015_035 1 (by decide +kernel)

private def supportedCone1991 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨737, 739, 737, 737, 739⟩, ⟨0, 0, 7000000000, 97930653, 2305000000000, 672129298525⟩⟩
    hull015_036 0 (by decide +kernel)

private def supportedCone1992 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨739, 744, 739, 739, 740⟩, ⟨0, 0, 3000000000, 42631294, 2312000000000, 672227229178⟩⟩
    hull015_037 0 (by decide +kernel)

private def supportedCone1993 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨735, 736, 736, 735, 736⟩, ⟨5000000000, 70594217, 0, 0, 2300000000000, 672059018501⟩⟩
    hull015_038 1 (by decide +kernel)

private def supportedCone1994 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨736, 737, 736, 736, 737⟩, ⟨0, 0, 5000000000, 70280024, 2300000000000, 672059018501⟩⟩
    hull015_039 0 (by decide +kernel)

private def supportedCone1995 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 760, 743, 761⟩, ⟨85000000000, 1262284167, 5000000000, 74348908, 2415000000000, 673753317520⟩⟩
    hull015_018 39 (by decide +kernel)

private def supportedCone1996 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 91, 90, 92⟩, ⟨1491781946, 242343210, 413317129, 67209419, 326491781946, 7859693302⟩⟩
    hull015_040 82 (by decide +kernel)

private def supportedCone1997 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 851, 760, 743, 761⟩, ⟨85000000000, 1262284167, 5000000000, 74348908, 2415000000000, 673753317520⟩⟩
    hull015_016 14 (by decide +kernel)

private def supportedCone1998 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 851, 732, 731, 739⟩, ⟨5000000000, 70519163, 32000000000, 452426034, 2280000000000, 671774803144⟩⟩
    hull015_016 9 (by decide +kernel)

private def supportedCone1999 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨735, 736, 735, 735, 736⟩, ⟨0, 0, 5000000000, 70594217, 2295000000000, 671988424284⟩⟩
    hull015_038 0 (by decide +kernel)

private def supportedCone2000 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 26, 24, 23, 25⟩, ⟨1407888149, 33953019, 1142765542, 29098135, 246407888149, 187176200⟩⟩
    hull015_041 7 (by decide +kernel)

private def supportedCone2001 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 744, 743, 741, 744⟩, ⟨10000000000, 147861212, 5000000000, 74658643, 2330000000000, 672491033353⟩⟩
    hull015_042 13 (by decide +kernel)

private def supportedCone2002 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 743, 741, 760⟩, ⟨10000000000, 147861212, 85000000000, 1262284167, 2330000000000, 672491033353⟩⟩
    hull015_018 38 (by decide +kernel)

private def supportedCone2003 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨736, 737, 737, 736, 737⟩, ⟨5000000000, 70280024, 0, 0, 2305000000000, 672129298525⟩⟩
    hull015_039 1 (by decide +kernel)

private def supportedCone2004 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨737, 738, 737, 737, 738⟩, ⟨0, 0, 5000000000, 70010177, 2305000000000, 672129298525⟩⟩
    hull015_043 0 (by decide +kernel)

private def supportedCone2005 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨738, 739, 738, 738, 739⟩, ⟨0, 0, 2000000000, 27920476, 2310000000000, 672199308702⟩⟩
    hull015_044 0 (by decide +kernel)

private def supportedCone2006 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨21, 26, 25, 24, 26⟩, ⟨1142765542, 29098135, 1603882869, 43246842, 247550653691, 216274335⟩⟩
    hull015_024 4 (by decide +kernel)

private def supportedCone2007 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨737, 738, 738, 737, 738⟩, ⟨5000000000, 70010177, 0, 0, 2310000000000, 672199308702⟩⟩
    hull015_043 1 (by decide +kernel)

private def supportedCone2008 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨737, 739, 739, 737, 739⟩, ⟨7000000000, 97930653, 0, 0, 2312000000000, 672227229178⟩⟩
    hull015_036 1 (by decide +kernel)

private def supportedCone2009 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 741, 740, 743⟩, ⟨5000000000, 73311669, 10000000000, 147861212, 2320000000000, 672343172141⟩⟩
    hull015_018 37 (by decide +kernel)

private def supportedCone2010 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨735, 744, 740, 739, 741⟩, ⟨3000000000, 42631294, 5000000000, 73311669, 2315000000000, 672269860472⟩⟩
    hull015_023 2 (by decide +kernel)

private def supportedCone2011 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨735, 739, 739, 735, 739⟩, ⟨17000000000, 238804894, 0, 0, 2312000000000, 672227229178⟩⟩
    hull015_045 1 (by decide +kernel)

private def supportedCone2012 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨23, 26, 25, 24, 26⟩, ⟨1142765542, 29098135, 1603882869, 43246842, 247550653691, 216274335⟩⟩
    hull015_034 2 (by decide +kernel)

private def supportedCone2013 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨739, 741, 741, 740, 741⟩, ⟨5000000000, 73311669, 0, 0, 2320000000000, 672343172141⟩⟩
    hull015_046 2 (by decide +kernel)

private def supportedCone2014 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨741, 742, 742, 741, 742⟩, ⟨5000000000, 74119297, 0, 0, 2325000000000, 672417291438⟩⟩
    hull015_047 1 (by decide +kernel)

private def supportedCone2015 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨742, 744, 742, 742, 743⟩, ⟨0, 0, 5000000000, 73741915, 2325000000000, 672417291438⟩⟩
    hull015_048 0 (by decide +kernel)

def appendixHullConeBlock0062 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1984,
    supportedCone1985,
    supportedCone1986,
    supportedCone1987,
    supportedCone1988,
    supportedCone1989,
    supportedCone1990,
    supportedCone1991,
    supportedCone1992,
    supportedCone1993,
    supportedCone1994,
    supportedCone1995,
    supportedCone1996,
    supportedCone1997,
    supportedCone1998,
    supportedCone1999,
    supportedCone2000,
    supportedCone2001,
    supportedCone2002,
    supportedCone2003,
    supportedCone2004,
    supportedCone2005,
    supportedCone2006,
    supportedCone2007,
    supportedCone2008,
    supportedCone2009,
    supportedCone2010,
    supportedCone2011,
    supportedCone2012,
    supportedCone2013,
    supportedCone2014,
    supportedCone2015,
  ], rfl⟩

private def supportedCone2016 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨23, 24, 24, 23, 24⟩, ⟨1407888149, 33953019, 0, 0, 246407888149, 187176200⟩⟩
    hull015_049 1 (by decide +kernel)

private def supportedCone2017 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨741, 744, 741, 741, 743⟩, ⟨0, 0, 10000000000, 147861212, 2320000000000, 672343172141⟩⟩
    hull015_050 0 (by decide +kernel)

private def supportedCone2018 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨24, 26, 25, 24, 26⟩, ⟨1142765542, 29098135, 1603882869, 43246842, 247550653691, 216274335⟩⟩
    hull015_051 1 (by decide +kernel)

private def supportedCone2019 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨741, 742, 741, 741, 742⟩, ⟨0, 0, 5000000000, 74119297, 2320000000000, 672343172141⟩⟩
    hull015_047 0 (by decide +kernel)

private def supportedCone2020 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨24, 26, 24, 24, 25⟩, ⟨0, 0, 1142765542, 29098135, 246407888149, 187176200⟩⟩
    hull015_051 0 (by decide +kernel)

private def supportedCone2021 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨742, 744, 743, 742, 744⟩, ⟨5000000000, 73741915, 5000000000, 74658643, 2330000000000, 672491033353⟩⟩
    hull015_048 1 (by decide +kernel)

private def supportedCone2022 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨741, 744, 744, 743, 744⟩, ⟨5000000000, 74658643, 0, 0, 2335000000000, 672565691996⟩⟩
    hull015_050 2 (by decide +kernel)

private def supportedCone2023 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨726, 744, 744, 743, 744⟩, ⟨5000000000, 74658643, 0, 0, 2335000000000, 672565691996⟩⟩
    hull015_052 10 (by decide +kernel)

private def supportedCone2024 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 22, 21, 23⟩, ⟨1444783328, 26634160, 929323095, 19209070, 244070676905, 134014111⟩⟩
    hull015_053 13 (by decide +kernel)

private def supportedCone2025 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 744, 744, 743, 744⟩, ⟨5000000000, 74658643, 0, 0, 2335000000000, 672565691996⟩⟩
    hull015_042 14 (by decide +kernel)

private def supportedCone2026 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 780, 740, 739, 741⟩, ⟨3000000000, 42631294, 5000000000, 73311669, 2315000000000, 672269860472⟩⟩
    hull015_054 11 (by decide +kernel)

private def supportedCone2027 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨709, 780, 741, 740, 743⟩, ⟨5000000000, 73311669, 10000000000, 147861212, 2320000000000, 672343172141⟩⟩
    hull015_054 12 (by decide +kernel)

private def supportedCone2028 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨744, 753, 744, 744, 753⟩, ⟨0, 0, 45000000000, 677674180, 2335000000000, 672565691996⟩⟩
    hull015_055 0 (by decide +kernel)

private def supportedCone2029 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨753, 762, 753, 753, 760⟩, ⟨0, 0, 35000000000, 509951344, 2380000000000, 673243366176⟩⟩
    hull015_056 0 (by decide +kernel)

private def supportedCone2030 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨762, 780, 762, 762, 779⟩, ⟨0, 0, 75000000000, 1115133662, 2425000000000, 673904073266⟩⟩
    hull015_057 0 (by decide +kernel)

private def supportedCone2031 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨744, 748, 744, 744, 748⟩, ⟨0, 0, 20000000000, 304172653, 2335000000000, 672565691996⟩⟩
    hull015_058 0 (by decide +kernel)

private def supportedCone2032 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨748, 753, 748, 748, 753⟩, ⟨0, 0, 25000000000, 373501527, 2355000000000, 672869864649⟩⟩
    hull015_059 0 (by decide +kernel)

private def supportedCone2033 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨744, 748, 748, 744, 748⟩, ⟨20000000000, 304172653, 0, 0, 2355000000000, 672869864649⟩⟩
    hull015_058 1 (by decide +kernel)

private def supportedCone2034 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨744, 746, 744, 744, 745⟩, ⟨0, 0, 5000000000, 76242749, 2335000000000, 672565691996⟩⟩
    hull015_060 0 (by decide +kernel)

private def supportedCone2035 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨746, 748, 746, 746, 748⟩, ⟨0, 0, 10000000000, 151624155, 2345000000000, 672718240494⟩⟩
    hull015_061 0 (by decide +kernel)

private def supportedCone2036 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨744, 746, 745, 744, 746⟩, ⟨5000000000, 76242749, 5000000000, 76305749, 2340000000000, 672641934745⟩⟩
    hull015_060 1 (by decide +kernel)

private def supportedCone2037 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨744, 746, 746, 745, 746⟩, ⟨5000000000, 76305749, 0, 0, 2345000000000, 672718240494⟩⟩
    hull015_060 2 (by decide +kernel)

private def supportedCone2038 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨746, 748, 748, 746, 748⟩, ⟨10000000000, 151624155, 0, 0, 2355000000000, 672869864649⟩⟩
    hull015_061 1 (by decide +kernel)

private def supportedCone2039 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨746, 747, 746, 746, 747⟩, ⟨0, 0, 5000000000, 75986980, 2345000000000, 672718240494⟩⟩
    hull015_062 0 (by decide +kernel)

private def supportedCone2040 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨747, 748, 747, 747, 748⟩, ⟨0, 0, 5000000000, 75637175, 2350000000000, 672794227474⟩⟩
    hull015_063 0 (by decide +kernel)

private def supportedCone2041 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨746, 747, 747, 746, 747⟩, ⟨5000000000, 75986980, 0, 0, 2350000000000, 672794227474⟩⟩
    hull015_062 1 (by decide +kernel)

private def supportedCone2042 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨747, 748, 748, 747, 748⟩, ⟨5000000000, 75637175, 0, 0, 2355000000000, 672869864649⟩⟩
    hull015_063 1 (by decide +kernel)

private def supportedCone2043 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨748, 750, 748, 748, 750⟩, ⟨0, 0, 10000000000, 150328996, 2355000000000, 672869864649⟩⟩
    hull015_064 0 (by decide +kernel)

private def supportedCone2044 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨750, 753, 750, 750, 753⟩, ⟨0, 0, 15000000000, 223172531, 2365000000000, 673020193645⟩⟩
    hull015_065 0 (by decide +kernel)

private def supportedCone2045 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨748, 749, 748, 748, 749⟩, ⟨0, 0, 5000000000, 75339473, 2355000000000, 672869864649⟩⟩
    hull015_066 0 (by decide +kernel)

private def supportedCone2046 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨749, 750, 749, 749, 750⟩, ⟨0, 0, 5000000000, 74989523, 2360000000000, 672945204122⟩⟩
    hull015_067 0 (by decide +kernel)

private def supportedCone2047 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨748, 749, 749, 748, 749⟩, ⟨5000000000, 75339473, 0, 0, 2360000000000, 672945204122⟩⟩
    hull015_066 1 (by decide +kernel)

def appendixHullConeBlock0063 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2016,
    supportedCone2017,
    supportedCone2018,
    supportedCone2019,
    supportedCone2020,
    supportedCone2021,
    supportedCone2022,
    supportedCone2023,
    supportedCone2024,
    supportedCone2025,
    supportedCone2026,
    supportedCone2027,
    supportedCone2028,
    supportedCone2029,
    supportedCone2030,
    supportedCone2031,
    supportedCone2032,
    supportedCone2033,
    supportedCone2034,
    supportedCone2035,
    supportedCone2036,
    supportedCone2037,
    supportedCone2038,
    supportedCone2039,
    supportedCone2040,
    supportedCone2041,
    supportedCone2042,
    supportedCone2043,
    supportedCone2044,
    supportedCone2045,
    supportedCone2046,
    supportedCone2047,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
