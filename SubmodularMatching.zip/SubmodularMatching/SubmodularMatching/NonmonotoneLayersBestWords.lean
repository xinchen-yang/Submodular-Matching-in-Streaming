import SubmodularMatching.NonmonotoneActionBestFeasible
import SubmodularMatching.NonmonotoneOptimizerResources

/-! Exact integer input to the two layer samplers, read directly from the
chosen state of the materialized optimizer. -/

namespace SubmodularMatching.NonmonotoneOptimizer.BlockData
open Streaming LinearPacking
variable {E : Type*} [DecidableEq E] {n l m s bits : ℕ} [NeZero n] (B : BlockData E n l)

def bestDen (l : ℕ) := 2^(18*paperExponent l)

def stateNumerator (l : ℕ) (state : Vec l) (j : Fin l) : ℕ :=
  ⌊(bestDen l:ℚ)*atRat state j⌋₊

theorem returned_best_words (G : PackingGrid m l) (h : ℕ → E) (p : ℕ → ℝ) (a : ℕ)
    (hp : ∀ i<a, 0 ≤ p i ∧ p i ≤ 1) (f : Finset E → ℝ) (τ : ℝ)
    (words : OptimizerWords a n l s bits) (hc : 0 < B.c) (hb : B.β=scoreBeta)
    (hw : ∀ i, |(B.frozen i:ℝ)| ≤ paperScale l) :
    let A := B.paperAnswers h p a f τ hp words
    let R := B.candidateRun G (paperExponent l) A
    let best := (R (ascentFuel (paperExponent l))).bestState
    ∀ j, stateNumerator l best j ≤ bestDen l ∧ atRat best j = (stateNumerator l best j:ℚ)/bestDen l := by
  intro A R best
  let k := paperExponent l
  let T := ascentFuel k
  let D := bestDen l
  have hd : 0 < D := by dsimp [D,bestDen]; positivity
  have grid (t : ℕ) : ∀ j, OnGrid D (coordinates (R t).state j) := by
    induction t with
    | zero => intro j; simpa [R,candidateRun,scheduledRun,run,runLoop,start,coordinates,atRat] using OnGrid.zero D
    | succ t ih =>
      have eq : R (t+1) = outerStep G (schedule k) (projectionFuel k) (stepSize k) (B.gradient A) A.score (R t) :=
        run_succ _ _ _ _ _ _ _
      rw [eq]; dsimp only [outerStep]
      split_ifs <;> exact projectLoop_onGrid G (schedule k) _ _ _ ih
  have hbstate : best = (R (R T).bestTime).state :=
    (run_best G (schedule k) (projectionFuel k) (stepSize k) (B.gradient A) A.score T).2.1
  have bound := B.returned_best_feasible G h p a hp f τ words hc hb hw
  intro j
  have hg : OnGrid D (coordinates best j) := hbstate ▸ grid _ j
  obtain ⟨z,hz,he⟩ := OnGrid.bounded_numerator (R:=1) hg (bound.1 j).1 (by simpa using (bound.1 j).2)
  have hq : (D:ℚ)*atRat best j=z := by
    change (D:ℝ)*(atRat best j:ℝ) = (z:ℝ) at he
    exact_mod_cast he
  have heq : stateNumerator l best j = z := by
    dsimp only [stateNumerator]
    change ⌊(D:ℚ)*atRat best j⌋₊ = z
    rw [hq,Nat.floor_natCast]
  rw [heq]
  refine ⟨by simpa [D] using hz,?_⟩
  apply (eq_div_iff (by exact_mod_cast hd.ne' : (D:ℚ) ≠ 0)).mpr
  simpa only [mul_comm] using hq

end SubmodularMatching.NonmonotoneOptimizer.BlockData
