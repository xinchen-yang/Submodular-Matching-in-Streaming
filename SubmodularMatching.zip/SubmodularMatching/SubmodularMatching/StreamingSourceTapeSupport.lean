import SubmodularMatching.StreamingSourceTape

/-!
# Support of the finite source law for arbitrary real objectives

Each raw observation is an oracle marginal on the incoming edge.
Uninitialized history cells contain zero and therefore also have a
marginal witness.
-/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Support of a source tape prefix without an accuracy requirement. -/
def SourceTapeHasMarginals (P : ScheduledSource E V) {N : ℕ}
    (batches : ℕ → Fin N → ℝ) (t : ℕ) : Prop :=
  ∀ i < t, ∀ r, ∃ A, batches i r = marginal P.objective (P.edges (P.call i).1) A

private theorem sourceTapeHasMarginals_extend (P : ScheduledSource E V) {N : ℕ}
    (batches : ℕ → Fin N → ℝ) (i : ℕ) (h : SourceTapeHasMarginals P batches i)
    (draw : Fin N → Fin (P.context i (P.history batches i)).outcomes.length) :
    SourceTapeHasMarginals P (Function.update batches i ((P.context i (P.history batches i)).samples draw))
      (i + 1) := by
  intro t ht r
  by_cases he : t = i
  · subst t
    rw [Function.update_self]
    let ctx := P.context i (P.history batches i)
    refine ⟨ctx.outcomes[(draw r).val].1, ?_⟩
    unfold EstimateContext.samples
    change marginal P.objective (P.edges (P.birth (P.call i) + ((P.call i).1 - P.birth (P.call i))))
      _ = _
    have hb : P.birth (P.call i) ≤ (P.call i).1 :=
      Nat.le_of_lt_succ (guessBirth_lt _ _ _ _)
    rw [Nat.add_sub_of_le hb]
  · rw [Function.update_of_ne he]
    exact h t (by omega) r

/-- Processing the next adaptive call adds only genuine observations,
including when the numerical concentration event fails at that call. -/
theorem sourceTapeFrom_support_marginals (P : ScheduledSource E V) (N : ℕ)
    (steps i : ℕ) (batches other : ℕ → Fin N → ℝ)
    (hprev : SourceTapeHasMarginals P batches i)
    (h : other ∈ (sourceTapeFrom P N steps i batches).outcomes) :
    SourceTapeHasMarginals P other (i + steps) := by
  classical
  induction steps generalizing i batches with
  | zero =>
    have hh : other = batches := Finset.mem_singleton.mp h
    subst other
    simpa only [Nat.add_zero] using hprev
  | succ steps ih =>
    let ctx := P.context i (P.history batches i)
    rw [sourceTapeFrom] at h
    obtain ⟨draw, -, hd⟩ := (CandidateLaw.mem_bind _ _ _).1 h
    have hh := ih (i + 1) (Function.update batches i (ctx.samples draw))
      (sourceTapeHasMarginals_extend P batches i hprev draw) hd
    simpa only [Nat.add_right_comm i 1 steps, Nat.add_succ] using hh

/-- Every full tape in the finite support contains only true oracle
marginals for each scheduled arrival. -/
theorem sourceTape_support_marginals (P : ScheduledSource E V) (N : ℕ)
    (batches : ℕ → Fin N → ℝ) (h : batches ∈ (sourceTape P N).outcomes) :
    SourceTapeHasMarginals P batches P.calls.length := by
  have hh := sourceTapeFrom_support_marginals P N P.calls.length 0 _ batches
    (fun i hi => (Nat.not_lt_zero i hi).elim) h
  simpa only [Nat.zero_add] using hh

/-- Every history value of a supported tape is a genuine oracle marginal.
A default zero is witnessed by the singleton containing the same edge. -/
theorem sourceTape_history_marginal (P : ScheduledSource E V) (N : ℕ)
    (batches : ℕ → Fin N → ℝ) (h : batches ∈ (sourceTape P N).outcomes)
    (t : ℕ) (ht : t ≤ P.calls.length) (i j : ℕ) (r : Fin N) :
    ∃ A, P.history batches t (i, j) r = marginal P.objective (P.edges i) A := by
  have hs := sourceTape_support_marginals P N batches h
  induction t with
  | zero => exact ⟨{P.edges i}, by simp [ScheduledSource.history, marginal]⟩
  | succ t ih =>
    rw [ScheduledSource.history, ScheduledSource.advance]
    by_cases he : (i, j) = P.call t
    · rw [he, Function.update_self]
      have hi : i = (P.call t).1 := congrArg Prod.fst he
      rw [hi]
      exact hs t (Nat.lt_of_succ_le ht) r
    · rw [Function.update_of_ne he]
      exact ih (Nat.le_of_succ_le ht)

end SubmodularMatching.UpperBoundAssembly
