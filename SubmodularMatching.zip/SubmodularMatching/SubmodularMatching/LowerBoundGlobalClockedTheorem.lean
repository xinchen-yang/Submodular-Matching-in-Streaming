import SubmodularMatching.LowerBoundGlobalClock
import SubmodularMatching.LowerBoundGlobalCoverage
import SubmodularMatching.LowerBoundGlobalRandomTheorem

/-! # The lower bound with separately indexed per-arrival random tapes -/

namespace SubmodularMatching.LowerBoundGlobal

open Filter LowerBoundAssembly MeasureTheory
open scoped Topology

noncomputable section

abbrev BlueprintArrivalCount {R : ℝ} (params : Parameters R)
    (family : BlueprintFamily params.densityLoss) (A : ℝ) (i : ℕ) : ℕ :=
  announcedStreamLength params.stages (family.expansions i) (BlueprintClone A (family.N i))
    (hardRetention params) (hardRetention params)

/-- The same lower bound holds if an algorithm additionally has an
arrival clock that selects the fixed tape used at each step. Its clock
is already included in the simulated machine and charged here. -/
theorem factor_three_for_clocked_blueprint {R A a : ℝ} (hR : 1 ≤ R)
    (params : Parameters R) (family : BlueprintFamily params.densityLoss)
    (ha : 0 ≤ a) (hA : a + 1 < A)
    {State Seed : ℕ → Type*} [∀ i, Fintype (State i)] [∀ i, Nonempty (State i)]
    [∀ i, MeasurableSpace (Seed i)]
    (μ : ∀ i, Measure (Seed i)) [∀ i, IsProbabilityMeasure (μ i)]
    (alg : ∀ i, BlueprintRandomProgram params family A i
      (Fin (BlueprintArrivalCount params family A i + 1) × State i) (Seed i) (μ i))
    (space : WordSpace (BlueprintVertexCount params family A) a)
    (hstates : ∀ i, Fintype.card (State i) ≤ 2 ^ space.bits i)
    {prob : ℝ} (hprob : 0 < prob) :
    ∀ᶠ i : ℕ in atTop, HasHardCounterexamples params family i (alg i) prob := by
  have hn := (blueprintVertexCount_tendsto_atTop (A := A) params family).eventually
    (eventually_ge_atTop (Real.exp 1))
  let clockSpace := space.withClock ha hn
  apply factor_three_for_random_blueprint hR params family ha hA μ alg clockSpace _ hprob
  intro i
  letI : Nonempty (Fin (family.t i)) := ⟨⟨0, family.t_pos i⟩⟩
  have hq0 := (hardRetention_pos params).le
  have hq1 := (hardRetention_lt_one params).le
  exact clock_states_le (n := BlueprintVertexCount params family A i)
    (m := BlueprintArrivalCount params family A i)
    (announcedStreamLength_le_vertexSquared (p := params.stages)
      (C := BlueprintClone A (family.N i)) (family.expansions i) _ _ hq0 hq1 hq0 hq1)
    (hstates i)

end

end SubmodularMatching.LowerBoundGlobal
