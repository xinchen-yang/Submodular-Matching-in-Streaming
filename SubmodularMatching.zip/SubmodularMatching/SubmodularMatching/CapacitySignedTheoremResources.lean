import SubmodularMatching.CapacitySignedProgramBudget
import SubmodularMatching.CapacityArrivalCache
import SubmodularMatching.NonmonotoneConfidenceSchedule

/-! Public-confidence bounds on the actual signed bank, cached capacities,
retained-action queries, and sequential compact postprocessing reserve. -/
namespace SubmodularMatching.Capacity
open Streaming Streaming.OracleQuery AppendixM UpperBoundAssembly NonmonotoneOptimizer Finset
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

theorem signed_public_query_bound (S : SimpleEdgeStream E V) (cap : V→ℕ)
    (hpos : ∀ e, 0<cap (S.ends e).1 ∧ 0<cap (S.ends e).2) (f : Finset E→ℝ)
    (edges : ℕ→E) (draw : ℕ→ℕ→ℕ→ℕ→ℕ) (c : ℝ) (k Ja Npriority h : ℕ)
    (hk : k≤(Fintype.card V)^2) :
    let n := Fintype.card V
    let v := n^2
    let δ := confidenceTarget n c
    let J := sourceFailureBudget δ
    let K := sourceWordScale v (v^2)
    let src := RealOracle.countedBank S.ends cap hpos v (batchCount K J) (batchBits K) f edges draw k
    let cost := fun (st : ℕ × SparseSlots E cap) =>
      let s := (st.2.machine.edges.map Prod.fst).toFinset.card
      max 1 (postprocessCount δ)*((∑ j : ActionKey s, actionBatch (2*s) Ja*keyCalls j)*ascentFuel (paperExponent (2*s))) +
        postprocessCount δ*(2*Npriority*(2*(2*s+(2*h+2)+1))+2)
    let H := 2^37*(2*v+1)
    let T := ⌈1/trialSuccess⌉₊*(Nat.clog 2 (max 1 n)*⌈c⌉₊+1)
    let Jmax := 2000000000+2*(max 1 n)^⌈c⌉₊
    let Q := 1+v*(1+2*(4*(2^42*(v^2+2)*(v^2+1)+v^2)^3*Jmax+1)*(signedGuessCountConstant*(v+2)))
    let O := (4*v+2)*(4*8^4*Ja*H^40+1)*H^8
    src.2+2*postprocessCount δ+(src.1.states.map cost).sum ≤ Q+2*T+signedGuessCountConstant*(v+2)*
      (max 1 T*O+T*(2*Npriority*(2*(2*v+(2*h+2)+1))+2)) := by
  intro n v δ J K src cost H T Jmax Q O
  have hp := signed_program_oracle_budget S cap hpos f edges draw k J Ja Npriority (2*h+2)
    (postprocessCount δ) T hk (postprocessCount_logarithmic n c)
  apply hp.trans
  have hJ : J ≤ Jmax := sourceFailureBudget_polynomial n c
  dsimp only [Q,O,H,v,n,T,δ] at *
  gcongr

/-- Reuses the proven bank and sequential scratch bounds on every real
tape. The optional first-appearance cache is accounted separately. -/
theorem signed_public_workspace (S : SimpleEdgeStream E V) (cap : V→ℕ)
    (hpos : ∀ e, 0<cap (S.ends e).1 ∧ 0<cap (S.ends e).2) (hn : 2≤(Fintype.card V)^2)
    (f : Finset E→ℝ) (hf : IsSubmodular f) (hnn : ∀ A, 0≤f A)
    (edges : ℕ→E) (draw : ℕ→ℕ→ℕ→ℕ→ℕ) (k : ℕ) (c : ℝ)
    (hinj : ∀ i < k, ∀ l < k, edges i=edges l → i=l)
    (Z : Finset E) (hz : feasible S.ends cap Z) (hmax : ∀ X, feasible S.ends cap X → X.card≤Z.card)
    (rawCap : V→ℕ) (cache : CapacityCache V) (hcache : CacheValid rawCap cache)
    (hcap : ∀ v, cap v≤Fintype.card V) (D C d : ℕ)
    (hD : D≤C*(Fintype.card V+1)^d) :
    let n := Fintype.card V
    let v := n^2
    let K₀ := sourceWordScale v (v^2)
    let N := batchCount K₀ (sourceFailureBudget (confidenceTarget n c))
    let bank := RealOracle.forwardBank S.ends cap hpos v N (batchBits K₀) f edges draw k
    let bankC := 4+9*signedGuessCountConstant*(14+26*incidenceConstant)
    let T := d+C.log2+1
    let w := (n+1).log2+1
    2*cache.length ≤ 2*n ∧
    ∀ a ∈ bank.states,
      let kept := (a.2.machine.edges.map Prod.fst).toFinset
      let s := kept.card
      let m := blockCount (fiberSize S.ends cap) kept.toList
      let q := Nat.clog 2 D
      let K := 2*s+q+1
      let L := ShearerSampler.samplerFuel (51/100) (((2:ℝ)^q)⁻¹) m
      let scratch := max (34*s) (4*s+8*(2*K+2*L))
      RealOracle.bankCells bank + frozenCells cap bank + scratch + 2*Z.card+16 ≤
        (38*bankC+8*(5000*(7+T)+2*T+4)+18)*(Z.card+1)*w^2 := by
  intro n v K₀ N bank bankC T w
  refine ⟨capacityCache_words rawCap cache hcache,?_⟩
  intro a ha kept s m q K L scratch
  have hB : RealOracle.bankCells bank ≤ bankC*(Z.card+1)*w^2 :=
    RealOracle.forwardBank_space S.ends cap hpos S.loopless n N (batchBits K₀) hn (by
      dsimp only [N,batchCount]; omega) f hf hnn edges draw k hinj Z hz hmax
  have hm : m ≤ s*n^2 := by
    simpa only [m,s,Finset.length_toList] using layerIndex_bound S.ends cap kept.toList n hcap
  exact signed_sequential_workspace cap bank a ha n Z.card C d D m hD s rfl
    (kept.card_le_univ.trans (physical_ground_size S)) hm bankC hB

end
end SubmodularMatching.Capacity
