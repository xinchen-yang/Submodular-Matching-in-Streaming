import SubmodularMatching.UpperBoundK1ArchiveLists
import SubmodularMatching.StreamingK1RealSamplewise

/-! # Value of the actual one-pass K.1 archive and optimizer -/

namespace SubmodularMatching.UpperBoundAssembly.K1ProgramInput

open GibbsSampler Streaming
open scoped BigOperators

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]
variable {a : K1Parameters} (I : K1ProgramInput a E V)

/-- Attach feasibility evidence to each state in the same probability law. -/
private def lawWithSupport {A : Type*} (p : CandidateLaw A) :
    CandidateLaw {x // x ∈ p.outcomes} where
  outcomes := p.outcomes.attach
  mass := fun x => p.mass x
  probability := by
    refine ⟨fun x _ => p.probability.nonnegative x x.property, ?_⟩
    rw [Finset.sum_attach]
    exact p.probability.total

private theorem lawWithSupport_value {A : Type*} (p : CandidateLaw A) (test : A → ℝ) :
    let q := lawWithSupport p
    expected q.outcomes q.mass (fun x => test x) = expected p.outcomes p.mass test := by
  simp only [expected, lawWithSupport]
  exact Finset.sum_attach p.outcomes (fun x : A => p.mass x * test x)

structure ArchivedPreparation where
  state : RealSource.OnlineStreamState E V
  arrived : state.ArchivesArrived (arrivedEdges I.P.edges I.P.arrivals)
  points : ArchivedPoints state

def prepareArchivedState (ω : ℝ) (state : RealSource.OnlineStreamState E V)
    (harrived : state.ArchivesArrived (arrivedEdges I.P.edges I.P.arrivals)) :
    CandidateLaw I.ArchivedPreparation := by
  classical
  exact (I.compiledOptimizerLaw (I.Ng ω) state).map (ArchivedPreparation.mk state harrived)

def freshSource (ω : ℝ) : CandidateLaw (RealSource.OnlineStreamState E V) :=
  RealSource.samplewisePrefixLaw I.P I.onlineGrid (I.Ns ω) a.p I.P.arrivals

theorem freshSource_support (ω : ℝ) :
    (I.freshSource ω).outcomes ⊆
      (RealSource.freshStateLaw I.P I.onlineGrid (I.Ns ω) a.p).outcomes :=
  RealSource.samplewisePrefixLaw_support I.P I.onlineGrid (I.Ns ω) a.p I.P.arrivals

/-- The state-only source has the same physical singleton register on
every support point. -/
theorem freshSource_retainsBest (ω : ℝ) (st : RealSource.OnlineStreamState E V)
    (hst : st ∈ (I.freshSource ω).outcomes) :
    let J := I.withRetainedBest
    st.bestEdge = some (J.P.edges J.bestIndex) := by
  let coins : ℕ → ℕ → ℕ → ℕ → ℕ := fun _ _ _ _ => 0
  exact (RealSource.freshStateLaw_bestEdge I.P I.onlineGrid (I.Ns ω) a.p st
    (I.freshSource_support ω hst) coins).trans
    (I.withRetainedBest_physical ω coins)

def archivedPreparation (ω : ℝ) : CandidateLaw I.ArchivedPreparation := by
  classical
  exact (lawWithSupport (I.freshSource ω)).bind fun st =>
    I.prepareArchivedState ω st.val
      (RealSource.freshStateLaw_archivesArrived I.P I.onlineGrid (I.Ns ω) a.p st.val
        (I.freshSource_support ω st.property))

theorem archivedPreparation_uses_physicalBest (ω : ℝ)
    (t : I.withRetainedBest.ArchivedPreparation)
    (ht : t ∈ (I.withRetainedBest.archivedPreparation ω).outcomes) :
    t.state.bestEdge = some (I.withRetainedBest.P.edges I.withRetainedBest.bestIndex) := by
  classical
  unfold archivedPreparation at ht
  obtain ⟨st, _, hpoint⟩ := (CandidateLaw.mem_bind _ _ _).mp ht
  unfold prepareArchivedState CandidateLaw.map at hpoint
  obtain ⟨_, _, rfl⟩ := Finset.mem_image.mp hpoint
  exact I.freshSource_retainsBest ω st.val st.property

def archivedCandidates (t : I.ArchivedPreparation) : List (CandidateLaw (Finset E)) :=
  I.candidatesFromArchive t.state t.points

/-- Every subset queried by an archived optimizer is interpreted through
the sparse rows of its own guess, all of which have already arrived. -/
theorem archivedOptimizerQuery_legal (st : RealSource.OnlineStreamState E V)
    (harrived : st.ArchivesArrived (arrivedEdges I.P.edges I.P.arrivals)) (j : ℕ)
    (S : Finset (Fin (archivedRows st j).length)) :
    S.image (fun i => ((archivedRows st j).get i).1) ⊆ arrivedEdges I.P.edges I.P.arrivals := by
  intro edge he
  obtain ⟨i, -, rfl⟩ := Finset.mem_image.mp he
  have hs := st.initialize_edges_subset _ harrived false j
  change ((archivedRows st j).map Prod.fst).toFinset ⊆ _ at hs
  exact hs (List.mem_toFinset.2 (List.mem_map.2
    ⟨(archivedRows st j).get i, List.getElem_mem i.isLt, rfl⟩))

theorem archivedCandidates_legal (t : I.ArchivedPreparation) :
    ∀ q ∈ I.archivedCandidates t, q.outcomes ⊆ I.feasible := by
  intro q hq
  unfold archivedCandidates candidatesFromArchive at hq
  obtain ⟨j, -, h⟩ := List.mem_filterMap.mp hq
  dsimp only at h
  split_ifs at h with hm hn
  obtain rfl := Option.some.inj h
  apply k1CompactGuessFromPoint_feasible
  intro edge he
  rw [Finset.map_eq_image] at he
  exact I.archivedOptimizerQuery_legal t.state t.arrived j _ he

/-- Every observable of the completed candidate laws agrees under the
sparse archive and the proof-side transcript. -/
theorem archivedPreparation_value (ω : ℝ) (hω : 0 < ω) (test : List (CandidateLaw (Finset E)) → ℝ) :
    let p := I.archivedPreparation ω
    let q := I.livePreparation ω
    expected p.outcomes p.mass (test ∘ I.archivedCandidates) =
      expected q.outcomes q.mass (test ∘ I.liveCandidates ω) := by
  classical
  dsimp only
  unfold archivedPreparation prepareArchivedState livePreparation
  rw [CandidateLaw.bind_expected, CandidateLaw.bind_expected]
  simp only [CandidateLaw.map_expected]
  let observe := fun st : RealSource.OnlineStreamState E V =>
    let law := I.compiledOptimizerLaw (I.Ng ω) st
    expected law.outcomes law.mass (test ∘ I.candidatesFromArchive st)
  change expected (lawWithSupport (I.freshSource ω)).outcomes (lawWithSupport (I.freshSource ω)).mass
    (fun st => observe st.val) = _
  rw [lawWithSupport_value]
  have hs : expected (I.freshSource ω).outcomes (I.freshSource ω).mass observe =
      expected (I.source ω).outcomes (I.source ω).mass (fun batches => observe (I.replayState ω batches)) :=
    (RealSource.samplewisePrefixLaw_value I.P I.onlineGrid (I.Ns ω) a.p I.P.arrivals observe).trans
      (RealSource.freshStateLaw_value I.P I.onlineGrid I.width_one_le I.onlineGrid_matches
        (I.Ns ω) a.p observe)
  rw [hs]
  unfold expected
  apply Finset.sum_congr rfl
  intro batches hb
  congr 1
  exact (I.compiledOptimizerLaw_value ω hω batches hb
    (test ∘ I.candidatesFromArchive (I.replayState ω batches))).trans
    (I.archiveOptimizerLaw_value ω batches test)

def archivedExpectedLaw : CandidateLaw (Finset E) :=
  expectedOutputLaw (I.archivedPreparation a.error) I.feasible I.P.objective (a.error * I.B / 2)
    I.archivedCandidates I.initial I.initial_legal I.archivedCandidates_legal

def archivedAmplifiedLaw (C : K1Confidence a) (δ : ℝ) : CandidateLaw (Finset E) :=
  let ω := min a.error (δ / 2)
  refinedOutputLaw (I.archivedPreparation ω) I.feasible I.P.objective (a.error * I.B / 2)
    (C.comparisonMesh * I.B) I.archivedCandidates I.initial I.initial_legal
    I.archivedCandidates_legal (C.trials δ)

theorem archivedExpectedLaw_value (test : Finset E → ℝ) :
    let p := I.archivedExpectedLaw
    let q := I.liveExpectedLaw
    expected p.outcomes p.mass test = expected q.outcomes q.mass test := by
  dsimp only
  unfold archivedExpectedLaw liveExpectedLaw
  rw [expectedOutputLaw_value, expectedOutputLaw_value]
  exact I.archivedPreparation_value a.error a.error_pos (fun qs =>
    scanExpectation I.P.objective (a.error * I.B / 2) test qs I.initial)

theorem archivedAmplifiedLaw_value (C : K1Confidence a) (δ : ℝ) (hδ : 0 < δ)
    (test : Finset E → ℝ) :
    let p := I.archivedAmplifiedLaw C δ
    let q := I.liveAmplifiedLaw C δ
    expected p.outcomes p.mass test = expected q.outcomes q.mass test := by
  dsimp only
  unfold archivedAmplifiedLaw liveAmplifiedLaw
  rw [refinedOutputLaw_value, refinedOutputLaw_value]
  exact I.archivedPreparation_value (min a.error (δ / 2)) (lt_min a.error_pos (by positivity)) (fun qs =>
    selectionExpectation I.feasible (scanMass I.P.objective (a.error * I.B / 2) qs I.initial)
      I.P.objective (C.comparisonMesh * I.B) test (C.trials δ) I.initial)

variable [Fintype E]

/-- Appendix K.1 for the actual sparse archive, with the best singleton
used by the physical streaming register in both confidence modes. -/
theorem archived_guarantees (C : K1Confidence a) (O : Finset E) (hO : O ∈ I.feasible)
    (hopt : ∀ M ∈ I.feasible, I.P.objective M ≤ I.P.objective O)
    (δ : ℝ) (hδ : 0 < δ) :
    let J := I.withRetainedBest
    let p := J.archivedExpectedLaw
    let q := J.archivedAmplifiedLaw C δ
    p.outcomes ⊆ I.feasible ∧ q.outcomes ⊆ I.feasible ∧
      ((1 - a.error) * a.theta * a.eta / (1 + 5 * a.error)) * I.P.objective O ≤
        expected p.outcomes p.mass I.P.objective ∧
      expected q.outcomes q.mass (fun M => if I.P.objective O / C.target ≤ I.P.objective M
        then 0 else 1) ≤ δ := by
  classical
  dsimp only
  let J := I.withRetainedBest
  refine ⟨expectedOutputLaw_supported _ _ _ _ _ _ _ _,
    refinedOutputLaw_supported _ _ _ _ _ _ _ _ _ _, ?_, ?_⟩
  · rw [← a.expectedFactor_eq, J.archivedExpectedLaw_value, J.liveExpectedLaw_value]
    exact J.expectation O hO hopt
  · rw [J.archivedAmplifiedLaw_value C δ hδ, J.liveAmplifiedLaw_value]
    exact J.high_probability C O hO hopt δ hδ

end

end SubmodularMatching.UpperBoundAssembly.K1ProgramInput
