import SubmodularMatching.ProjectedShearerBestSchedule
import SubmodularMatching.ProjectedShearerSweepCost

/-! Scalar and inspection bounds for decoding a physical slot-index lookup. -/
namespace SubmodularMatching.Capacity
open UpperBoundAssembly GibbsMatching ShearerCappedSampler ShearerSampler TwoLayerDiffuse AppendixM
open scoped BigOperators
variable {E V T : Type*}

/-- A cursor traverses one original label per visited block. The accumulator
is a proof-side instrumentation of the same tail-recursive decoder. -/
def meteredSeek (len : E→ℕ) (emit : (e:E)→Fin (len e)→T) : List E → ℕ → ℕ → Option T × ℕ
  | [],_,t => (none,t)
  | e::s,k,t => if h : k<len e then (some (emit e ⟨k,h⟩),t+1) else meteredSeek len emit s (k-len e) (t+1)

theorem meteredSeek_spec (len : E→ℕ) (emit : (e:E)→Fin (len e)→T) (s : List E) (k t : ℕ) :
    let out := meteredSeek len emit s k t
    out.1=seekBlock len emit s k ∧ out.2≤t+s.length := by
  induction s generalizing k t with
  | nil => simp [meteredSeek,seekBlock]
  | cons e s ih =>
    by_cases hc : k<len e
    · simp [meteredSeek,seekBlock,hc]
    · simpa only [meteredSeek,seekBlock,dif_neg hc,List.length_cons,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using ih (k-len e) (t+1)

variable [DecidableEq V]

/-- Carry the number of original-label inspections and the current physical
numerator on the same pass. -/
def chargeNumerator (ends : E→V×V) (a : E→ℕ) (u v : V) : List E→ℕ→ℕ→ℕ×ℕ
  | [],acc,n => (acc,n)
  | e::es,acc,n => chargeNumerator ends a u v es (acc+if hasEndpoints ends e u v then a e else 0) (n+1)

theorem chargeNumerator_spec (ends : E→V×V) (a : E→ℕ) (u v : V) (es : List E) (D acc n : ℕ)
    (h : ∀ e∈es,a e≤D) :
    let out := chargeNumerator ends a u v es acc n
    out.1=scanLabelNumerator ends a u v es acc ∧ out.2=n+es.length ∧ out.1≤acc+es.length*D := by
  induction es generalizing acc n with
  | nil => simp [chargeNumerator,scanLabelNumerator]
  | cons e es ih =>
    let x := if hasEndpoints ends e u v then a e else 0
    have b : x≤D := by dsimp [x]; split_ifs <;> simp [h e List.mem_cons_self]
    obtain ⟨he,hn,hs⟩ := ih (acc+x) (n+1) (fun d hd => h d (List.mem_cons_of_mem e hd))
    exact ⟨he,hn.trans (by simp [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm]),hs.trans (by simp only [List.length_cons,Nat.succ_mul]; omega)⟩

variable [Fintype E] [Fintype V] [DecidableEq E]

/-- All integers in the physical numerator and denominator have explicit
polynomial bounds in the original label count and precision denominators.
This is independent of heterogeneous slot capacities. -/
theorem physical_cell_width (S : SimpleEdgeStream E V) (b : V→ℕ) (u : E→ℕ) (d θn θd D n : ℕ)
    (hcap : ∀ v,b v≤n) (hu : ∀ e,u e≤d) (p : Slots b × Slots b) :
    D*slotNum S b u θn p ≤ D*θn*(S.arrivals.length*d) ∧
    slotDen b d θd p ≤ θd*d*n^2 := by
  have h := chargeNumerator_spec S.ends u p.1.1 p.2.1 S.arrivals d 0 0 (fun e _ => hu e)
  have sn : scanLabelNumerator S.ends u p.1.1 p.2.1 S.arrivals 0 ≤ S.arrivals.length*d := by
    simpa only [h.1,Nat.zero_add] using h.2.2
  refine ⟨?_,?_⟩
  · unfold slotNum
    rw [←Nat.mul_assoc]
    exact Nat.mul_le_mul_left _ sn
  · unfold slotDen
    rw [Nat.mul_assoc, sq]
    exact Nat.mul_le_mul_left _ (Nat.mul_le_mul (hcap _) (hcap _))

/-- The original decoded scalar, stored before the virtual-edge sweeps, fits
in one common-grid numerator. Thus physical_cell_width applies to exactly
the input vector of returnedBestSamplers. -/
theorem decoded_word_bound (S : SimpleEdgeStream E V) (b : V→ℕ) (k q T : ℕ) (hT : 0<T) (u : E→ℕ) (e : E)
    (hy : (decodedCoordinate S b k q (fun i=>(u i:ℚ)/T) e:ℝ)≤1) :
    decodedNum S b k q T u e ≤ decodedDen T k := by
  have rhs := (decoded_number S b k q T u hT e).trans_le hy
  have hd : 0<decodedDen T k := by unfold decodedDen; positivity
  exact_mod_cast (div_le_one (by exact_mod_cast hd)).mp rhs

end SubmodularMatching.Capacity
