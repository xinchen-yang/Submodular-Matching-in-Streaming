import SubmodularMatching.UpperBoundOptimizerTape
import SubmodularMatching.UpperBoundFiniteGuess

/-! # A good optimizer tape passes every empirical accuracy test -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint GibbsSampler
open NumericalCertificate (coordinateCap finiteError)

noncomputable section

variable {m N : ℕ} {V : Type*} [Fintype V] [DecidableEq V]

private def optimizerPrefixAccurate (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q q : ℕ)
    (t : OptimizerTape m N) : Prop :=
  t.good = true → ∀ j < q, j < FiniteGreedy.stages NumericalCertificate.degree m finiteError →
    ∀ e, let ξ := FiniteGreedy.accuracy NumericalCertificate.degree m finiteError
      let g := residualValue (enumerateEdge hm) coordinateCap f m
      |snappedCoordinate f ξ tau (t.batches j) e - exactGradient hm NumericalCertificate.degree g
        (optimizerPoint ends tau w f Q t j) e| ≤ ξ * tau / 2

theorem optimizerTape_accurate (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q bits : ℕ)
    (t : OptimizerTape m N) (ht : t ∈ (optimizerTapeLaw hm ends tau w f Q bits).outcomes)
    (hg : t.good = true) : appendixOptimizerAccurate hm ends tau w f Q t.draw := by
  classical
  let D := NumericalCertificate.degree
  let K := FiniteGreedy.stages D m finiteError
  let ξ := FiniteGreedy.accuracy D m finiteError
  let g := residualValue (enumerateEdge hm) coordinateCap f m
  let inv := optimizerPrefixAccurate (N := N) hm ends tau w f Q
  have hi : inv 0 (OptimizerTape.empty m N) := by intro _ j hj; omega
  have hstep (j : ℕ) (s : OptimizerTape m N) (hs : inv j s)
      (u : OptimizerTape m N) (hu : u ∈ (optimizerTapeStep hm ends tau w f Q bits j s).outcomes) :
      inv (j + 1) u := by
    unfold optimizerTapeStep CandidateLaw.map at hu
    obtain ⟨batch, _, rfl⟩ := Finset.mem_image.mp hu
    let u := optimizerTapeNext hm ends tau w f Q j s batch
    have hup (k : ℕ) (hk : k < j) : u.batches k = s.batches k := by
      simp [u, optimizerTapeNext, Function.update_of_ne (Nat.ne_of_lt hk)]
    have hpoint (k : ℕ) (hk : k ≤ j) :
        optimizerPoint ends tau w f Q u k = optimizerPoint ends tau w f Q s k :=
      optimizerPoint_prefix ends tau w f Q u s k (fun a ha => hup a (ha.trans_le hk))
    intro hgood k hk hkK e
    change (s.good && optimizerStageGood hm tau f j (optimizerPoint ends tau w f Q s j) batch) = true
      at hgood
    simp only [Bool.and_eq_true] at hgood
    obtain ⟨hsg, hlocal⟩ := hgood
    change |snappedCoordinate f ξ tau (u.batches k) e -
      exactGradient hm D g (optimizerPoint ends tau w f Q u k) e| ≤ ξ * tau / 2
    rw [hpoint k (by omega)]
    rcases lt_or_eq_of_le (Nat.le_of_lt_succ hk) with hlt | heq
    · rw [hup k hlt]
      exact hs hsg k hlt hkK e
    · subst k
      have hbatch : u.batches j = batch := by simp [u, optimizerTapeNext]
      rw [hbatch]
      unfold optimizerStageGood at hlocal
      have h := of_decide_eq_true hlocal e
      exact le_of_not_gt (fun hlt => h ⟨hkK, hlt⟩)
  have h := CandidateLaw.execute_invariant (optimizerTapeStep hm ends tau w f Q bits)
    inv hstep K 0 (OptimizerTape.empty m N) hi t ht
  intro j hj e
  exact h hg j (by simpa only [Nat.zero_add] using hj) hj e

end

end SubmodularMatching.UpperBoundAssembly
