import SubmodularMatching.UpperBoundParametricGibbsWords
import SubmodularMatching.UpperBoundParametricStored
import SubmodularMatching.FiniteShearerTapeAppendix

/-! # Composition of the exact sampler word laws at family precision -/

namespace SubmodularMatching.UpperBoundAssembly

open ShearerSampler GibbsSampler GibbsMatching Joint TwoStage NumericalCertificate
open scoped BigOperators

noncomputable section

variable {m N : ℕ} {V : Type*} [DecidableEq V]

/-- The two executed rounding samplers on one compact rounded point. -/
def parametricTapeOutcomeMass (hm : 0 < m) (K : ℕ) (hK : 0 < K) (ends : Fin m → V × V)
    (t : (Fin m → ℝ) × (Fin m → ℝ)) (M : Finset (Fin m)) : ℝ :=
  let ep := restrictEnds ends
  let n := Fintype.card (IncidentVertex ends)
  let mesh := parametricShearerDenominator n m K
  let c := appendixShearerInput mesh (parametricShearerDenominator_pos n m K hm hK)
    (fun i => (appendixGridIndex mesh (t.2 i)).toNat)
  let D := 4 * n * K
  let first := appendixFirstTapeLaw c ep D
  let e : ℝ := 1 / K
  let second := fun T =>
    let z := shearerAltered ep t.1 t.2 (e / 4) T
    gridGibbsWalkLaw (numberedEnds ends) (8 * K - 1) (8 * K) (parametricAlteredDenominator m K)
      (fun i => parametricAlteredIndex m K (z i)) (List.finRange m) D
  let states := matchings (pairEnds ep) (Finset.univ : Finset (Fin m))
  ∑ pair ∈ states ×ˢ states,
    if compactRoundingOutcome ep pair = M then first pair.1 * second pair.1 pair.2 else 0

set_option maxHeartbeats 1200000 in
/-- The sampler mass in the family value proof equals the word execution
with fresh first-stage words and conditional second-stage Gibbs words. -/
theorem parametricTapeOutcomeMass_eq (hm : 0 < m) (K : ℕ) (hK : 0 < K)
    (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1) (he1 : (1 : ℝ) / K < 1)
    (hcap : p ≤ (1 / (K : ℝ)) ^ 5 / 163840) (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (M : Finset (Fin m)) :
    let ep := restrictEnds ends
    let t := parametricRoundedPoint K p tau ep w f Q draw
    parametricTapeOutcomeMass hm K hK ends t M =
      (parametricSampledCandidate hm K hK p tau hp hp1 ep (restrictEnds_loopless ends hloop)
        (incidentVertex_card_pos hm ends) w f Q draw).mass M := by
  classical
  intro ep t
  let n := Fintype.card (IncidentVertex ends)
  let e : ℝ := 1 / K
  let D := 4 * n * K
  let mesh := parametricShearerDenominator n m K
  let hd := parametricShearerDenominator_pos n m K hm hK
  let num := fun i => (appendixGridIndex mesh (t.2 i)).toNat
  let c := appendixShearerInput mesh hd num
  let hlo := restrictEnds_loopless ends hloop
  let hv := incidentVertex_card_pos hm ends
  let hFeas := parametricRoundedPoint_feasible hm K hK p tau hp hp1 ep hlo w f Q draw
  let second := fun T =>
    let z := shearerAltered ep t.1 t.2 (e / 4) T
    gridGibbsWalkLaw (numberedEnds ends) (8 * K - 1) (8 * K) (parametricAlteredDenominator m K)
      (fun i => parametricAlteredIndex m K (z i)) (List.finRange m) D
  let S := matchings (pairEnds ep) (Finset.univ : Finset (Fin m))
  have hc : c.x = t.2 := parametricShearer_grid_decode hm K hK p tau hp hp1 ep hlo w f Q draw
  have hδ : (1 : ℝ) / D = e / (4 * (n : ℝ)) := by
    dsimp only [D, e]
    rw [div_div]
    push_cast
    rw [mul_comm (K : ℝ)]
  have hFirst : appendixFirstTapeLaw c ep D = appendixFirstLaw c ep (e / (4 * (n : ℝ))) := by
    rw [← hδ]
    apply appendixFirstTapeLaw_eq c ep hlo
    · exact sampler_bounds.1.le
    · intro v
      rw [hc]
      exact hFeas.y_degree v
  have hSecond (T : Finset (Fin m)) : second T =
      lowActivityGibbsLaw (pairEnds ep) Finset.univ
        (secondActivity ep t.1 c.x (e / 4) (e / 2) T) D := by
    rw [hc]
    exact parametricGibbs_gridWalk_eq hm K hK p hp hp1 he1 hcap ends hloop hsimple tau w f Q draw T
  change (∑ pair ∈ S ×ˢ S,
    if compactRoundingOutcome ep pair = M then appendixFirstTapeLaw c ep D pair.1 * second pair.1 pair.2 else 0) =
      (parametricRoundingCandidate K hK ep hlo hv p t.1 mesh hd num (hc.symm ▸ hFeas)).mass M
  unfold parametricRoundingCandidate finiteRoundingCandidate CandidateLaw.map CandidateLaw.imageMass
    roundingJointCandidate jointLaw
  dsimp only
  apply Finset.sum_congr rfl
  intro pair _
  rw [hFirst, hSecond pair.1]
  by_cases h : compactRoundingOutcome ep pair = M
  · simp only [h, ite_true]
    rfl
  · simp only [h, ite_false]

end

end SubmodularMatching.UpperBoundAssembly
