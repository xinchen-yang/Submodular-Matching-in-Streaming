import SubmodularMatching.CapacityIndexCursor

/-! # A one-word canonical rank for a slot, without a slot lookup table -/

namespace SubmodularMatching.Capacity
variable {V : Type*} {n : ℕ}

def packedSlot (id : V ↪ Fin n) (b : V → ℕ) (hb : ∀ v, b v ≤ n) :
    BSlot b ↪ Fin (n*n) where
  toFun x := finProdFinEquiv (id x.1, Fin.castLE (hb x.1) x.2)
  inj' := by
    rintro ⟨v,j⟩ ⟨u,k⟩ he
    have h := finProdFinEquiv.injective he
    have hv : v = u := id.injective (congrArg Prod.fst h)
    subst u
    have hj : j = k := Fin.ext (congrArg (fun p : Fin n × Fin n => p.2.val) h)
    subst k
    rfl

def boundedSlotRank (id : V ↪ Fin n) (b : V → ℕ) (hb : ∀ v, b v ≤ n) : BSlot b ↪ ℕ :=
  (packedSlot id b hb).trans Fin.valEmbedding

theorem boundedSlotRank_formula (id : V ↪ Fin n) (b : V → ℕ) (hb : ∀ v, b v ≤ n) (x : BSlot b) :
    boundedSlotRank id b hb x = x.2.val + n*(id x.1).val ∧ boundedSlotRank id b hb x < n^2 := by
  exact ⟨rfl,by simpa only [sq] using (packedSlot id b hb x).isLt⟩

end SubmodularMatching.Capacity
