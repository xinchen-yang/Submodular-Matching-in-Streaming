import SubmodularMatching.LowerBoundGlobalCut
import SubmodularMatching.LowerBoundAssemblyCompleteness
import Mathlib.Data.Finset.Preimage

/-! # The information estimate at the end of a stage -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

/-- Embedding tagged blocks in the full edge universe preserves the
containment probability needed by the entropy bound. A request containing
an edge outside the embedded universe has containment probability zero. -/
theorem mapped_block_inclusion_le {I E Edge : Type*}
    [Fintype I] [Fintype E] [DecidableEq I] [DecidableEq E] [DecidableEq Edge]
    (embed : I × E ↪ Edge) (U : I → Finset E) (q : ℝ) (hq0 : 0 ≤ q) (hq1 : q ≤ 1)
    (hU : ∀ i, 0 < (U i).card) (A : Finset Edge) :
    (∑ S : I → Finset E,
      if A ⊆ (taggedSample S).map embed then
        independentSubsetMass U (fun i => retainedSize q (U i).card) S else 0) ≤ q ^ A.card := by
  classical
  let k := fun i => retainedSize q (U i).card
  have hk : ∀ i, k i ≤ (U i).card := fun i => retainedSize_le hq0 hq1 _
  have hrate (i : I) : (k i : ℝ) / ((U i).card : ℝ) ≤ q := by
    have huc : (0 : ℝ) < (U i).card := by exact_mod_cast hU i
    apply (div_le_iff₀ huc).2
    exact Nat.floor_le (by positivity)
  by_cases hA : A ⊆ Finset.univ.map embed
  · let B := A.preimage embed embed.injective.injOn
    have hmap : B.map embed = A := by
      ext edge
      constructor
      · intro he
        obtain ⟨a, ha, rfl⟩ := Finset.mem_map.mp he
        exact Finset.mem_preimage.mp ha
      · intro he
        obtain ⟨a, _, rfl⟩ := Finset.mem_map.mp (hA he)
        exact Finset.mem_map.mpr ⟨a, Finset.mem_preimage.mpr he, rfl⟩
    rw [← hmap]
    simp only [Finset.map_subset_map, Finset.card_map]
    exact independentSubsetMass_inclusion_le U k q hU hk hrate B
  · have hz (S : I → Finset E) : ¬ A ⊆ (taggedSample S).map embed :=
      fun hs => hA (hs.trans (Finset.map_subset_map.mpr (Finset.subset_univ _)))
    simp only [hz, if_false, Finset.sum_const_zero]
    positivity

/-- Actual stage output recovers at most s/(K d) distinguished edges on
average under the two independent laws: uniform label and thinned blocks. -/
theorem stage_output_bound {I E Edge State Label : Type*}
    [Fintype I] [Fintype E] [Finite Edge] [DecidableEq I] [DecidableEq E] [DecidableEq Edge]
    [Fintype State] [Nonempty State] [Fintype Label] [Nonempty Label] [DecidableEq Label]
    {m : Machine Edge State}
    (embed : I × E ↪ Edge) (U : I → Finset E)
    (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) (hU : ∀ i, 0 < (U i).card)
    (cut : Cut (Side := Label) m (independentSubsetMass U (fun i => retainedSize q (U i).card)))
    (hsample : ∀ S, cut.sampled S = (taggedSample S).map embed)
    (publicLabel : Edge → Label) (s : ℕ) (hstates : Fintype.card State ≤ 2 ^ s) :
    (∑ S, independentSubsetMass U (fun i => retainedSize q (U i).card) S *
      ((∑ label,
        (((m.output (cut.oracle label) (cut.before S ++ cut.after label) ∩ cut.oldEdges).filter
          (fun e => publicLabel e = label)).card : ℝ)) / (Fintype.card Label : ℝ))) ≤
      s / ((Fintype.card Label : ℝ) * Real.logb 2 (1 / q)) := by
  apply cut.expected_distinguished_le publicLabel q s
    (independentSubsetMass_nonneg U _)
    (sum_independentSubsetMass U _ (fun i => retainedSize_le hq0.le hq1.le _))
    hq0 hq1 _ hstates
  intro A
  simp only [hsample]
  exact mapped_block_inclusion_le embed U q hq0.le hq1.le hU A

/-- The stage-cut bound for a concrete one-pass execution with the actual
recursive objective. The starting reference label is arbitrary by prefix
invisibility. Future data independent of the clone sample can be fixed
before applying this estimate. -/
theorem distinguished_stage_recovery {I E Edge State Label : Type*}
    [Fintype I] [Fintype E] [Finite Edge] [DecidableEq I] [DecidableEq E] [DecidableEq Edge]
    [Fintype State] [Nonempty State] [Fintype Label] [Nonempty Label] [DecidableEq Label]
    (m : Machine Edge State)
    (embed : I × E ↪ Edge) (U : I → Finset E)
    (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) (hU : ∀ i, 0 < (U i).card)
    (oldEdges : Finset Edge) (before : (I → Finset E) → List Edge) (after : Label → List Edge)
    (unit : ℝ) (hunit : 0 ≤ unit) (stage : Edge → ℕ) (labels : Label → Edge → Bool)
    (reference : Label) (start count cutoff : ℕ)
    (harrival : ∀ S, 0 < independentSubsetMass U (fun i => retainedSize q (U i).card) S →
      ∀ e ∈ before S, stage e ≤ cutoff)
    (hearlier : ∀ o e, stage e < cutoff → labels o e = labels reference e)
    (hbefore : ∀ S e, 0 < independentSubsetMass U (fun i => retainedSize q (U i).card) S →
      e ∈ before S → e ∈ oldEdges → e ∈ (taggedSample S).map embed)
    (hafter : ∀ o e, e ∈ after o → e ∉ oldEdges)
    (hlegal : ∀ S o, 0 < independentSubsetMass U (fun i => retainedSize q (U i).card) S →
      m.legal (RecursiveObjective.objective unit stage (labels o) start count)
        (before S ++ after o))
    (publicLabel : Edge → Label) (s : ℕ) (hstates : Fintype.card State ≤ 2 ^ s) :
    (∑ S, independentSubsetMass U (fun i => retainedSize q (U i).card) S *
      ((∑ o,
        (((m.output (RecursiveObjective.objective unit stage (labels o) start count)
          (before S ++ after o) ∩ oldEdges).filter (fun e => publicLabel e = o)).card : ℝ)) /
          (Fintype.card Label : ℝ))) ≤ s / ((Fintype.card Label : ℝ) * Real.logb 2 (1 / q)) := by
  let cut := Cut.stageCut m
    (independentSubsetMass U (fun i => retainedSize q (U i).card)) oldEdges
    (fun S => (taggedSample S).map embed) before after unit hunit stage labels
    reference start count cutoff harrival hearlier hbefore hafter hlegal
  exact stage_output_bound embed U q hq0 hq1 hU cut (fun _ => rfl) publicLabel s hstates

end

end SubmodularMatching.LowerBoundGlobal
