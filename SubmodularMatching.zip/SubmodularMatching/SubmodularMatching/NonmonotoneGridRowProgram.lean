import SubmodularMatching.NonmonotoneGridRowExecution
import SubmodularMatching.NonmonotoneLayersPhysicalPriority

/-! Output program and compact indexing for the postprocessing row. -/

namespace SubmodularMatching.NonmonotoneCandidate.GridRow

open Capacity UpperBoundAssembly NonmonotoneLayers AppendixM TwoLayerDiffuse
open Shearer GibbsMatching GibbsSampler TwoStage
noncomputable section

variable {I V : Type*} [Fintype I] [LinearOrder I] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream I V} {b : V → ℕ} (g : GridRow S b)

def slot := compactSlot S.arrivals g.pair
def endpoints := compactPair S.arrivals g.pair S.complete

theorem endpoint_values (i : I) : g.slot (g.endpoints i).1=(g.pair i).1 ∧ g.slot (g.endpoints i).2=(g.pair i).2 :=
  compactPair_values S.arrivals g.pair S.complete i

theorem lifted_endpoints : (fun i => (g.slot (g.endpoints i).1,g.slot (g.endpoints i).2)) = g.pair := by
  funext i
  exact Prod.ext (g.endpoint_values i).1 (g.endpoint_values i).2

theorem endpoint_geometry (i : I) : pairVertices (g.pair i) = pairEnds (fun j => (g.slot (g.endpoints j).1,g.slot (g.endpoints j).2)) i := by
  rw [g.lifted_endpoints]; rfl

theorem endpoints_loopless (i : I) : (g.endpoints i).1 ≠ (g.endpoints i).2 :=
  compactPair_loopless S.arrivals g.pair S.complete (fun e he => S.loopless e (congrArg Sigma.fst he)) i

theorem endpoints_simple : Function.Injective (pairEnds g.endpoints) :=
  compactPair_simple S.arrivals g.pair S.complete (assigned_pair_simple S.ends S.simple b g.left g.right)

def trial (hb : ∀ v, 0<b v) (rank : Slots b ↪ ℕ) (fallback : I) (hist : ℕ→I) (m : ℕ) (τ : ℝ) (f : Finset I→ℝ) :
    CandidateLaw (Finset I) :=
  letI : LinearOrder (Slots b × Slots b) := keyedOrder (slotPairKey b rank)
  (g.wordData hb rank τ).run g.endpoints Finset.univ (Function.Embedding.refl I) (sourceSlotLabel S b fallback) hist m
    sourceProbability (by norm_num [sourceProbability]) f

end
end SubmodularMatching.NonmonotoneCandidate.GridRow
