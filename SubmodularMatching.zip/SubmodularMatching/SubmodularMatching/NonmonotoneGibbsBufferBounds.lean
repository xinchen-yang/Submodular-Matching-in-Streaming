import SubmodularMatching.NonmonotoneGibbsRegisterTable

/-! Word bounds for the actual arrays and integer loads reserved before the
Gibbs sampler, on every feasible optimizer register vector. -/
namespace SubmodularMatching.NonmonotoneCandidate.GridRow
open Capacity Finset TwoLayerDiffuse Shearer GibbsMatching AppendixM NonmonotoneLayers UpperBoundAssembly
open scoped BigOperators
noncomputable section
variable {I V : Type*} [Fintype I] [DecidableEq I] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream I V} {b : V→ℕ} (g : GridRow S b) {n : ℕ}

private theorem physicalAvailability_lower (hb : ∀ v,0<b v) (rank : Slots b ↪ ℕ) (i : I) :
    1/4≤g.upper rank i := by
  let p := g.pair i
  let Q := pairScanGrid (scaleFor (S:=S) rank)
  have hQ : 0<Q := by have hK:=g.scale_pos rank; dsimp [Q,pairScanGrid]; positivity
  have hload (v : V) : TwoLayerDiffuse.slotLoad b g.table v ≤ degree :=
    (labelTable_load S.ends S.loopless b g.mass v).le.trans (g.feasible.degree v)
  have diff : p.1≠p.2 := fun he => S.loopless i (congrArg Sigma.fst he)
  have h (θ : ℝ) (hn : 0≤θ) (hr : θ*degree≤1/4) : 1/2≤scanPairUpper b g.table θ Q p.1 p.2 := by
    let layer := retainedSlotLayer b hb rank (univ.image S.ends) g.table (labelTable_symm S.ends g.mass)
      (labelTable_diag S.ends S.loopless g.mass) (labelTable_support S.ends g.mass)
      (labelTable_nonneg S.ends g.mass (fun e => (g.feasible.y_bounded e).1)) θ degree hn hr hload
    have hscan := retained_scan_error b hb rank (univ.image S.ends) g.table (labelTable_symm S.ends g.mass)
      (labelTable_diag S.ends S.loopless g.mass) (labelTable_support S.ends g.mass)
      (labelTable_nonneg S.ends g.mass (fun e => (g.feasible.y_bounded e).1)) θ degree hn hr hload Q hQ p.1 p.2 diff
    have L : 1/2≤layer.pair p.1 p.2 := by
      have hl := (layer.pair_bounds (support_two (S:=S) rank) p.1 p.2).1
      linarith only [hl,layer.small p.1,layer.small p.2]
    exact L.trans hscan.1
  obtain ⟨_,_,hf,hs,_,hfd,hsd⟩ := actual_layer_parameters
  have lo := mul_le_mul (h _ hf hfd) (h _ hs hsd) (by norm_num) ((by norm_num : (0:ℝ)≤1/2).trans (h _ hf hfd))
  norm_num at lo
  exact lo

private theorem sourceCoordinate_cap (i : I) : g.x i≤(sourceProbability:ℝ) := by
  have nn (v : V) : 0≤Capacity.slotLoad S.ends b g.mass v :=
    sum_nonneg (fun e _ => mul_nonneg (slotInc_bounds S.ends b v e).1 (g.feasible.y_bounded e).1)
  have H := g.feasible.edge i
  have slope : 0≤1-2*firstProportion*secondProportion*(13/20*degree) := by
    norm_num [firstProportion,secondProportion,degree,layerOne]
  have intercept : 1-firstProportion*secondProportion*(13/20*degree)^2≤1 := by
    norm_num [firstProportion,secondProportion,degree,layerOne]
  have nonneg := mul_nonneg slope (add_nonneg (nn (S.ends i).1) (nn (S.ends i).2))
  have le : g.x i/(sourceProbability:ℝ)≤1 := (le_add_of_nonneg_right nonneg).trans (H.trans intercept)
  simpa using (div_le_iff₀ parameter_cutoffs.1).mp le

theorem gibbs_buffers (hb : ∀ v,0<b v) (rank : Slots b ↪ ℕ) (order : Fin n ≃ I) (x : I→ℚ)
    (hx : ∀i,(x i:ℝ)=g.x i) :
    let Q := assignedGrid (scaleFor (S:=S) rank)
    (g.compensatedArray rank order x).size=n ∧
    (∀ i,g.loadEntry rank order x i≤Q) ∧
    (∀ free v, maskedLoad g.pair (g.loadEntry rank order x) free v≤n*Q) ∧
    ∀ z, (g.alterationTable rank order x z).size=n ∧ ∀ i : Fin n,
      (g.alterationTable rank order x z)[i.val]'(by simp [alterationTable])≤Q := by
  intro Q
  have hf (i : I) : g.loadEntry rank order x i≤Q := by
    rw [g.loadEntry_eq,floorRegister_cast,Rat.cast_div,hx,g.rationalUpper_cast]
    have hc := g.sourceCoordinate_cap i
    have hl := g.physicalAvailability_lower hb rank i
    have le : g.x i/g.upper rank i ≤ 1 := by
      apply (div_le_one (by linarith only [hl])).mpr
      exact hc.trans ((by norm_num [sourceProbability] : (sourceProbability:ℝ)≤1/4).trans hl)
    apply Nat.floor_le_of_le
    exact (mul_le_mul_of_nonneg_right le (Nat.cast_nonneg Q)).trans_eq (one_mul _)
  refine ⟨by simp [compensatedArray],hf,?_,?_⟩
  · intro free v
    have h := maskedLoad_bound g.pair _ Q hf free v
    have e : Fintype.card I=n := by simpa using (Fintype.card_congr order).symm
    simpa only [e] using h
  · intro z
    refine ⟨by simp [alterationTable],fun i => ?_⟩
    dsimp only [alterationTable]
    simp only [Array.getElem_ofFn,Fin.eta]
    unfold alteredInteger
    split_ifs
    · apply le_trans _ (hf (order i))
      apply Nat.div_le_of_le_mul
      rw [Nat.mul_comm ((2:ℕ)^31+1)]
      exact Nat.mul_le_mul_left _ (Nat.le_succ _)
    · omega

end
end SubmodularMatching.NonmonotoneCandidate.GridRow
