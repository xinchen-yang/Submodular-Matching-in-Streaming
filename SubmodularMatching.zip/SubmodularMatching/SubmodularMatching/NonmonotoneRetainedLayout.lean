import SubmodularMatching.NonmonotoneRetainedRegisters
import SubmodularMatching.CapacityAssignedLookup
import Mathlib.Data.List.NodupEquivFin

/-! Recover the optimizer's sparse rows, chronological columns and assigned slots
from the physical retained payload. All row identifiers come from retained edges. -/
namespace SubmodularMatching.AppendixM
open Capacity UpperBoundAssembly Finset GibbsSampler
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

def readAssigned (S : SimpleEdgeStream E V) (b : V → ℕ) (st : SparseSlots E b) (e : E) :
    Option (Fin (b (S.ends e).1) × Fin (b (S.ends e).2)) :=
  match st.assigned.lookup e with
  | none => none
  | some p => if h : p.1.1=(S.ends e).1 ∧ p.2.1=(S.ends e).2 then
    some (Fin.cast (congrArg b h.1) p.1.2, Fin.cast (congrArg b h.2) p.2.2)
    else none

theorem readAssigned_witness (S : SimpleEdgeStream E V) (b : V → ℕ) (st : SparseSlots E b)
    (l : (e:E) → Fin (b (S.ends e).1)) (r : (e:E) → Fin (b (S.ends e).2))
    (horder : st.assigned.map Prod.fst = st.machine.edges.map Prod.fst)
    (hp : ∀ a∈st.assigned, a.2=slotPair S.ends b l r a.1)
    (e : ↑(st.machine.edges.map Prod.fst).toFinset) :
    readAssigned S b st e.val = some (l e.val,r e.val) := by
  have h := assigned_lookup_of_order b st _ horder hp e.val (List.mem_toFinset.mp e.property)
  simp [readAssigned,h,slotPair]

structure LayoutGuard (S : SimpleEdgeStream E V) (b : V → ℕ) (st : SparseSlots E b) : Prop where
  nodup : (st.machine.edges.map Prod.fst).Nodup
  nonempty : 0 < (st.machine.edges.map Prod.fst).length
  assigned : ∀ e : ↑(st.machine.edges.map Prod.fst).toFinset, (readAssigned S b st e.val).isSome

def layoutRows (G : SimpleEdgeStream E V) (b : V → ℕ) (pair : E → BSlot b × BSlot b) :
    List (V ⊕ BSlot b ⊕ E) :=
  (G.arrivals.flatMap (fun e => [Sum.inl (G.ends e).1,.inl (G.ends e).2,
    .inr (.inl (pair e).1),.inr (.inl (pair e).2),.inr (.inr e)])).dedup

theorem mem_layoutRows (G : SimpleEdgeStream E V) (b : V → ℕ) (pair : E → BSlot b × BSlot b)
    (x : V ⊕ BSlot b ⊕ E) : x ∈ layoutRows G b pair ↔ x ∈ activeRows G.ends b pair := by
  rcases x with v|s|e <;> simp [layoutRows,List.mem_flatMap,G.complete,activeRows,activeEndpoints]

def layoutRowEquiv (G : SimpleEdgeStream E V) (b : V → ℕ) (pair : E → BSlot b × BSlot b) :
    Fin (layoutRows G b pair).length ≃ ↑(activeRows G.ends b pair) :=
  (List.Nodup.getEquiv _ (List.nodup_dedup _)).trans
    ⟨fun x => ⟨x.val,(mem_layoutRows G b pair x.val).mp x.property⟩,
     fun x => ⟨x.val,(mem_layoutRows G b pair x.val).mpr x.property⟩,fun _ => rfl,fun _ => rfl⟩

def retainedLayout (S : SimpleEdgeStream E V) (b : V → ℕ) (st : SparseSlots E b)
    (hg : LayoutGuard S b st) : RetainedRuntime S b st.machine.edges := by
  let L := st.machine.edges.map Prod.fst
  let enum := storedOrderEquiv L hg.nodup
  let G := retainedGraph S L hg.nodup
  let p := fun e : ↑L.toFinset => (readAssigned S b st e.val).get (hg.assigned e)
  let pair := slotPair G.ends b (fun e => (p e).1) (fun e => (p e).2)
  let rows := layoutRowEquiv G b pair
  refine ⟨hg.nodup,hg.nonempty,(fun e => (p e).1),(fun e => (p e).2),L.length + L.length,
    (layoutRows G b pair).length, finSumFinEquiv.symm.trans (Equiv.sumCongr enum enum),
    rows,?_, Nat.add_pos_left hg.nonempty _⟩
  let e := enum ⟨0,hg.nonempty⟩
  have h := (mem_layoutRows G b pair (.inr (.inr e))).2 (by simp [activeRows])
  exact List.length_pos_of_mem h

theorem layoutGuard_of_witness (S : SimpleEdgeStream E V) (b : V → ℕ) (st : SparseSlots E b)
    (l : (e:E) → Fin (b (S.ends e).1)) (r : (e:E) → Fin (b (S.ends e).2))
    (horder : st.assigned.map Prod.fst = st.machine.edges.map Prod.fst)
    (hp : ∀ a∈st.assigned, a.2=slotPair S.ends b l r a.1)
    (hn : (st.machine.edges.map Prod.fst).Nodup) (hs : 0<(st.machine.edges.map Prod.fst).length) :
    LayoutGuard S b st :=
  ⟨hn,hs,fun e => by rw [readAssigned_witness S b st l r horder hp e]; rfl⟩

theorem retainedLayout_slots (S : SimpleEdgeStream E V) (b : V → ℕ) (st : SparseSlots E b)
    (hg : LayoutGuard S b st)
    (l : (e:E) → Fin (b (S.ends e).1)) (r : (e:E) → Fin (b (S.ends e).2))
    (horder : st.assigned.map Prod.fst = st.machine.edges.map Prod.fst)
    (hp : ∀ a∈st.assigned, a.2=slotPair S.ends b l r a.1) :
    (retainedLayout S b st hg).left = (fun e : ↑(st.machine.edges.map Prod.fst).toFinset => l e.val) ∧
    (retainedLayout S b st hg).right = (fun e : ↑(st.machine.edges.map Prod.fst).toFinset => r e.val) := by
  have eq (e : ↑(st.machine.edges.map Prod.fst).toFinset) :
      (readAssigned S b st e.val).get (hg.assigned e) = (l e.val,r e.val) := by
    exact Option.get_of_eq_some _ (readAssigned_witness S b st l r horder hp e)
  exact ⟨funext (fun e => congrArg Prod.fst (eq e)),funext (fun e => congrArg Prod.snd (eq e))⟩

theorem retainedLayout_pair (S : SimpleEdgeStream E V) (b : V → ℕ) (st : SparseSlots E b)
    (hg : LayoutGuard S b st)
    (l : (e:E) → Fin (b (S.ends e).1)) (r : (e:E) → Fin (b (S.ends e).2))
    (horder : st.assigned.map Prod.fst = st.machine.edges.map Prod.fst)
    (hp : ∀ a∈st.assigned, a.2=slotPair S.ends b l r a.1) :
    let R := retainedLayout S b st hg
    (fun e : ↑(st.machine.edges.map Prod.fst).toFinset => slotPair S.ends b l r e.val) =
      slotPair R.graph.ends b R.left R.right := by
  intro R
  have hh := retainedLayout_slots S b st hg l r horder hp
  change _ = slotPair R.graph.ends b (retainedLayout S b st hg).left (retainedLayout S b st hg).right
  rw [hh.1,hh.2]
  rfl

theorem retainedLayout_dimensions (S : SimpleEdgeStream E V) (b : V → ℕ) (st : SparseSlots E b)
    (hg : LayoutGuard S b st) :
    let R := retainedLayout S b st hg
    let s := (st.machine.edges.map Prod.fst).length
    R.l = 2*s ∧ R.m ≤ 5*s := by
  intro R s
  refine ⟨(two_mul s).symm,?_⟩
  let A := activeRows R.graph.ends b (slotPair R.graph.ends b R.left R.right)
  have hcard : R.m=A.card := by
    simpa only [Fintype.card_fin,Fintype.card_coe] using Fintype.card_congr R.rows
  rw [hcard]
  apply (activeRows_card _ b _).trans
  simp only [Fintype.card_coe,List.toFinset_card_of_nodup hg.nodup,le_refl,s]

def postprocess (S : SimpleEdgeStream E V) (b : V → ℕ) (hb : ∀ i, 0<b i)
    (rank : TwoLayerDiffuse.Slots b ↪ ℕ) (f : Finset E → ℝ) (q J : ℕ) (τ : ℝ)
    (st : SparseSlots E b) : CandidateLaw (Finset E) := by
  classical
  exact if hg : LayoutGuard S b st then
    (retainedLayout S b st hg).indexedRetainedRegisters ((Fintype.card V)^2) q hb rank f J τ
  else CandidateLaw.pure ∅

theorem postprocess_layout (S : SimpleEdgeStream E V) (b : V → ℕ) (hb : ∀ i, 0<b i)
    (rank : TwoLayerDiffuse.Slots b ↪ ℕ) (f : Finset E → ℝ) (q J : ℕ) (τ : ℝ)
    (st : SparseSlots E b) (hg : LayoutGuard S b st) :
    postprocess S b hb rank f q J τ st =
      (retainedLayout S b st hg).indexedRetainedRegisters ((Fintype.card V)^2) q hb rank f J τ := by
  simp [postprocess,hg]

theorem postprocess_of_empty (S : SimpleEdgeStream E V) (b : V → ℕ) (hb : ∀ i, 0<b i)
    (rank : TwoLayerDiffuse.Slots b ↪ ℕ) (f : Finset E → ℝ) (q J : ℕ) (τ : ℝ)
    (st : SparseSlots E b) (hempty : st.machine.edges=[]) :
    postprocess S b hb rank f q J τ st = CandidateLaw.pure ∅ := by
  have h : ¬LayoutGuard S b st := fun hg => by simpa [hempty] using hg.nonempty
  simp [postprocess,h]

theorem postprocess_feasible (S : SimpleEdgeStream E V) (b : V → ℕ) (hb : ∀ i, 0<b i)
    (rank : TwoLayerDiffuse.Slots b ↪ ℕ) (f : Finset E → ℝ) (q J : ℕ) (τ : ℝ)
    (st : SparseSlots E b) :
    ∀ A∈(postprocess S b hb rank f q J τ st).outcomes, feasible S.ends b A := by
  classical
  by_cases hg : LayoutGuard S b st
  · rw [postprocess_layout S b hb rank f q J τ st hg]
    exact (retainedLayout S b st hg).indexedRetainedRegisters_feasible _ q hb rank f J τ
  · intro A hA
    have hempty : A=∅ := by simpa [postprocess,hg,CandidateLaw.pure] using hA
    subst A
    intro v
    simp [incidences]

end
end SubmodularMatching.AppendixM
