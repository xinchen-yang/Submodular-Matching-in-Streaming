import SubmodularMatching.UpperBoundK1ProgramResources
import SubmodularMatching.UpperBoundK1Stored
import SubmodularMatching.UpperBoundLiveFamily

/-! # Runtime specialization to the rational parameters and live optimizer points -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint Streaming ShearerSampler GibbsSampler

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]
variable {a : K1Parameters}

namespace K1ProgramInput

variable (I : K1ProgramInput a E V)

def finalRoundingInput {Ns : ℕ} {batches : ℕ → Fin Ns → ℝ}
    (points : FinalPointFamily I.P batches) (j : I.ActiveGuess batches) :
    RationalShearerInput (Fin (I.guessSize j)) :=
  let vertices := Fintype.card (IncidentVertex (I.guessEndpoints j))
  let q := a.eulerDenominator (I.guessSize j) vertices
  let hq := a.eulerDenominator_pos (I.guessSize_bounds j).1 vertices
  k1RoundingShearerInput a.roundingSettings
    (k1PhysicalOfNormalizedPoint a.optimizerSettings (points j.val)).2 q hq

/-- Compactifying the stored endpoints leaves the number of incident
vertices used by the finite sampler unchanged. -/
theorem storedSamplerVertices_eq {Ns : ℕ} {batches : ℕ → Fin Ns → ℝ}
    (j : I.ActiveGuess batches) :
    (incidentVertexList (restrictEnds (I.guessEndpoints j))).length =
      Fintype.card (IncidentVertex (I.guessEndpoints j)) := by
  let ends := I.guessEndpoints j
  have hall (v : IncidentVertex ends) : v ∈ incidentVertices (restrictEnds ends) := by
    obtain ⟨e, he⟩ := (mem_incidentVertices ends v.val).mp v.property
    exact (mem_incidentVertices (restrictEnds ends) v).mpr
      ⟨e, he.imp Subtype.ext Subtype.ext⟩
  have hset : incidentVertices (restrictEnds ends) = Finset.univ :=
    Finset.eq_univ_of_forall hall
  rw [incidentVertexList_length, Fintype.card_coe, hset, Finset.card_univ]

/-- Filtering out zero activities in the actual Gibbs walk can only reduce
its iteration and arithmetic budget. -/
def finalGibbsSize {Ns : ℕ} {batches : ℕ → Fin Ns → ℝ}
    (j : I.ActiveGuess batches) (activities : Fin (I.guessSize j) → ActivityWords) : ℕ :=
  (positiveActivityList activities (List.finRange (I.guessSize j))).length

theorem finalGibbsSize_le {Ns : ℕ} {batches : ℕ → Fin Ns → ℝ}
    (j : I.ActiveGuess batches) (activities : Fin (I.guessSize j) → ActivityWords) :
    I.finalGibbsSize j activities ≤ I.guessSize j := by
  unfold finalGibbsSize positiveActivityList
  simpa only [List.length_finRange] using
    List.length_filter_le (fun e => decide (0 < (activities e).numerator))
      (List.finRange (I.guessSize j))

/-- Uniform constants for the source and optimizer query bounds. -/
def k1QueryConstant (k c trialMultiplier : ℕ) : ℕ :=
  let CL := 3 + k.log2
  let Cs := (2 * k ^ 2) * (c + 3 + (4 * (2 * CL) * (k + 2)).log2 + 1) + 1
  let Cg := 8 * (16 * k) ^ 2 * (c + 7 + (4 * (2 * CL) * (k + 1) * (k + 2)).log2 + 1) + 2
  let Ct := trialMultiplier * (c + 2) + 1
  2 * CL * (k + 1) * Cg + 2 * CL * Cs + CL * Ct + 2

def k1VisitConstant (k c trialMultiplier stopDenominator : ℕ) : ℕ :=
  let CL := 3 + k.log2
  let Ct := trialMultiplier * (c + 2) + 1
  CL * k1DirectionVisitConstant k + 8 * k1QueryConstant k c trialMultiplier +
    2 * (CL * Ct * k1RoundVisitConstant stopDenominator k)

/-- Polynomial query and arithmetic bounds at the actual source schedule,
completed optimizer point and retained-array Gibbs support. The activities
may depend on the earlier sampler choices and all estimates. -/
theorem finalRuntime_polynomial (C : K1Confidence a) (c : ℕ)
    (hspan : I.P.span = Nat.clog 2 ((I.P.vertices * a.k + 1) / 2))
    {Ns : ℕ} {batches : ℕ → Fin Ns → ℝ} (points : FinalPointFamily I.P batches)
    (activity : (j : I.ActiveGuess batches) →
      Fin (C.trials (((I.P.vertices : ℝ) ^ c)⁻¹)) → Fin (I.guessSize j) → ActivityWords) :
    let n := I.P.vertices
    let w := (n + 1).log2 + 1
    let δ := ((n : ℝ) ^ c)⁻¹
    let ω := min a.error (δ / 2)
    let T := C.trials δ
    let stored : I.ActiveGuess batches → ℕ := I.guessSize
    let ends : (j : I.ActiveGuess batches) → Fin (stored j) → V × V := I.guessEndpoints
    let Q := k1ExactQueryCount a.degree a.k I.P.arrivals I.L (I.Ns ω) (I.Ng ω) T stored
    let A := k1DirectionVisitCount a.degree a.k stored ends +
      4 * (n + 1) ^ 2 * Q + k1RoundingVisitCount a.k T stored ends
        (I.finalRoundingInput points) (fun j t => I.finalGibbsSize j (activity j t))
    Q ≤ k1QueryConstant a.k c C.trialMultiplier * (n + 1) ^ 10 * w ^ 2 ∧
      A ≤ k1VisitConstant a.k c C.trialMultiplier a.roundingSettings.rDen * (n + 1) ^ 22 * w := by
  exact I.resources_polynomial C c hspan batches a.roundingSettings.rDen
    (I.finalRoundingInput points) (fun _ => rfl)
    (fun j t => I.finalGibbsSize j (activity j t))
    (fun j t => I.finalGibbsSize_le j (activity j t))

end K1ProgramInput

end

end SubmodularMatching.UpperBoundAssembly
