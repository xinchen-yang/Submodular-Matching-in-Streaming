import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextLeft

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step1 : ProjectedGoal ⟨216, 229, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.m (.leaf 0xd800d8e8d4a51000048048) (.leaf 0xd900d9e8d4a51000048048)) (.m (.leaf 0xda00dae8d4a51000048048) (.leaf 0xdb00dbe8d4a51000048048))) (.x (.x (.leaf 0xde00dce8d4a51000048049) (.x (.leaf 0xde00dce8d4a5100004804a) (.x (.leaf 0xde00dce8d4a5100004804b) (.x (.y (.y (.leaf 0xde00dce8d4a5100004904c) (.y (.leaf 0xde00dce8d4a5100004a04c) (.y (.leaf 0xde00dce8d4a5100004b04c) (.y (.m (.m (.leaf 0xdc00dce8d4a5100004c04c) (.leaf 0xdd00dde8d4a5100004c04c)) (.leaf 0xde00dee8d4a5100004c04c)) (.leaf 0xde00dce8d4a5100004d04c))))) (.leaf 0xde00dce8d4a5100004e04c)) (.leaf 0xde00dce8d4a5100004804d))))) (.leaf 0xde00dce8d4a5100004804e))) (.m (.m (.leaf 0xe000dfe8d4a51000048048) (.leaf 0xe200e1e8d4a51000048048)) (.m (.leaf 0xe400e3e8d4a51000048048) (.leaf 0xe500e5e8d4a51000048048)))) (by decide +kernel)

private theorem step2 : ProjectedGoal ⟨230, 236, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0xe600e6e8d4a51000048048) (.leaf 0xe700e7e8d4a51000048048)) (.m (.leaf 0xe800e8e8d4a51000048048) (.leaf 0xe900e9e8d4a51000048048))) (.x (.x (.leaf 0xec00eae8d4a51000048049) (.x (.leaf 0xec00eae8d4a5100004804a) (.x (.leaf 0xec00eae8d4a5100004804b) (.x (.y (.y (.leaf 0xec00eae8d4a5100004904c) (.y (.leaf 0xec00eae8d4a5100004a04c) (.y (.leaf 0xec00eae8d4a5100004b04c) (.y (.m (.m (.leaf 0xea00eae8d4a5100004c04c) (.leaf 0xeb00ebe8d4a5100004c04c)) (.leaf 0xec00ece8d4a5100004c04c)) (.leaf 0xec00eae8d4a5100004d04c))))) (.leaf 0xec00eae8d4a5100004e04c)) (.leaf 0xec00eae8d4a5100004804d))))) (.leaf 0xec00eae8d4a5100004804e))) (by decide +kernel)

private theorem step3 : ProjectedGoal ⟨237, 242, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.leaf 0xee00ede8d4a51000048048) (.leaf 0xef00efe8d4a51000048048)) (.x (.x (.leaf 0xf200f0e8d4a51000048049) (.x (.leaf 0xf200f0e8d4a5100004804a) (.x (.leaf 0xf200f0e8d4a5100004804b) (.x (.y (.y (.leaf 0xf200f0e8d4a5100004904c) (.y (.leaf 0xf200f0e8d4a5100004a04c) (.y (.leaf 0xf200f0e8d4a5100004b04c) (.y (.m (.m (.leaf 0xf000f0e8d4a5100004c04c) (.leaf 0xf100f1e8d4a5100004c04c)) (.leaf 0xf200f2e8d4a5100004c04c)) (.leaf 0xf200f0e8d4a5100004d04c))))) (.leaf 0xf200f0e8d4a5100004e04c)) (.leaf 0xf200f0e8d4a5100004804d))))) (.leaf 0xf200f0e8d4a5100004804e))) (by decide +kernel)

private theorem step4 : ProjectedGoal ⟨230, 242, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 236 (by decide) (by decide) (step2 rates cones) (step3 rates cones)

private theorem step5 : ProjectedGoal ⟨216, 242, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 229 (by decide) (by decide) (step1 rates cones) (step4 rates cones)

private theorem step6 : ProjectedGoal ⟨243, 256, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0xf400f3e8d4a51000048048) (.leaf 0xf600f5e8d4a51000048048)) (.m (.leaf 0xf800f7e8d4a51000048048) (.leaf 0xf900f9e8d4a51000048048))) (.m (.m (.m (.leaf 0xfa00fae8d4a51000048048) (.leaf 0xfb00fbe8d4a51000048048)) (.m (.leaf 0xfc00fce8d4a51000048048) (.leaf 0xfd00fde8d4a51000048048))) (.x (.x (.leaf 0x10000fee8d4a51000048049) (.x (.leaf 0x10000fee8d4a5100004804a) (.x (.leaf 0x10000fee8d4a5100004804b) (.x (.y (.y (.leaf 0x10000fee8d4a5100004904c) (.y (.leaf 0x10000fee8d4a5100004a04c) (.y (.leaf 0x10000fee8d4a5100004b04c) (.y (.m (.m (.leaf 0xfe00fee8d4a5100004c04c) (.leaf 0xff00ffe8d4a5100004c04c)) (.leaf 0x1000100e8d4a5100004c04c)) (.leaf 0x10000fee8d4a5100004d04c))))) (.leaf 0x10000fee8d4a5100004e04c)) (.leaf 0x10000fee8d4a5100004804d))))) (.leaf 0x10000fee8d4a5100004804e)))) (by decide +kernel)

private theorem step7 : ProjectedGoal ⟨257, 269, 0, 283, 0, 283⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0x1020101e8d4a51000048048) (.leaf 0x1040103e8d4a51000048048)) (.m (.leaf 0x1060105e8d4a51000048048) (.leaf 0x1070107e8d4a51000048048))) (.m (.x (.x (.leaf 0x10a0108e8d4a51000048049) (.x (.leaf 0x10a0108e8d4a5100004804a) (.x (.leaf 0x10a0108e8d4a5100004804b) (.x (.y (.y (.leaf 0x10a0108e8d4a5100004904c) (.y (.leaf 0x10a0108e8d4a5100004a04c) (.y (.leaf 0x10a0108e8d4a5100004b04c) (.y (.m (.m (.leaf 0x1080108e8d4a5100004c04c) (.leaf 0x1090109e8d4a5100004c04c)) (.leaf 0x10a010ae8d4a5100004c04c)) (.leaf 0x10a0108e8d4a5100004d04c))))) (.leaf 0x10a0108e8d4a5100004e04c)) (.leaf 0x10a0108e8d4a5100004804d))))) (.leaf 0x10a0108e8d4a5100004804e)) (.m (.leaf 0x10c010be8d4a51000048048) (.leaf 0x10d010de8d4a51000048048)))) (by decide +kernel)

private theorem step8 : ProjectedGoal ⟨243, 269, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 256 (by decide) (by decide) (step6 rates cones) (step7 rates cones)

private theorem step9 : ProjectedGoal ⟨216, 269, 0, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 242 (by decide) (by decide) (step5 rates cones) (step8 rates cones)

theorem Part00000 : ProjectedGoal ⟨216, 269, 0, 283, 0, 283⟩ := step9

end SubmodularMatching.SourceCertificate.Replay.HardNextLeft
