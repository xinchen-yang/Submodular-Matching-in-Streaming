import SubmodularMatching.ProjectedShearerPriority

/-! # Priority sampling thins the Shearer marginals

Applying independent retention decisions to the sampled edges preserves
the Shearer law, replacing each processed edge marginal by its product
with the corresponding retention probability. -/

namespace SubmodularMatching.Shearer

open GibbsMatching

variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable (ends : E → Finset V) (S : Finset E) (x : E → ℝ)

/-- A single independent thinning decision applied to an actual set. -/
noncomputable def thinCoordinate (e : E) (p : ℝ) (f : Finset E → ℝ) (M : Finset E) : ℝ :=
  (1 - p) * f (M.erase e) + p * f M

private theorem expectation_agree (T : Finset E) (y : E → ℝ)
    (hy : ∀ d ∈ T, y d = x d) (f : Finset E → ℝ) :
    expectation ends T y f = expectation ends T x f := by
  unfold expectation
  apply Finset.sum_congr rfl
  intro M hM
  rw [mass_of_mem ends T y M hM, mass_of_mem ends T x M hM]
  congr 2
  · apply Finset.prod_congr rfl
    intro d hd
    exact hy d (((mem_matchings ends T M).mp hM).1 hd)
  · unfold signedPartition partition
    apply Finset.sum_congr rfl
    intro N hN
    apply Finset.prod_congr rfl
    intro d hd
    exact congrArg Neg.neg (hy d ((residualEdges_subset ends T M) (((mem_matchings ends _ N).mp hN).1 hd)))

/-- Shearer's exact expectation identity for one independently thinned
coordinate. This holds even as a signed polynomial identity. -/
theorem thinCoordinate_law (e : E) (he : e ∈ S) (p : ℝ) (f : Finset E → ℝ) :
    expectation ends S x (thinCoordinate e p f) =
      expectation ends S (Function.update x e (p*x e)) f := by
  classical
  let y := Function.update x e (p*x e)
  let T := S.erase e
  let C := compatibleEdges ends S e
  have hy (H : Finset E) (hH : H ⊆ T) (F : Finset E → ℝ) :
      expectation ends H y F = expectation ends H x F :=
    expectation_agree ends x H y (fun d hd => Function.update_of_ne (Finset.mem_erase.mp (hH hd)).1 _ _) F
  have hbase : expectation ends T x (thinCoordinate e p f) = expectation ends T x f := by
    apply expectation_congr
    intro N hN
    have hn : e ∉ N := fun hn => (Finset.mem_erase.mp (((mem_matchings ends T N).mp hN).1 hn)).1 rfl
    rw [thinCoordinate, Finset.erase_eq_of_notMem hn]
    ring
  have hdiff : expectation ends C x (fun N => thinCoordinate e p f (insert e N) - thinCoordinate e p f N) =
      p * expectation ends C x (fun N => f (insert e N) - f N) := by
    rw [← expectation_const_mul]
    apply expectation_congr
    intro N hN
    have hn := not_mem_compatible_matching ends S N e hN
    simp only [thinCoordinate, Finset.erase_insert hn, Finset.erase_eq_of_notMem hn]
    ring
  rw [expectation_edge_decomposition ends S x e he, expectation_edge_decomposition ends S y e he]
  rw [hbase, hdiff, hy T (Finset.Subset.refl _), hy C (compatibleEdges_subset_erase ends S e)]
  simp [y, mul_left_comm, mul_comm, mul_assoc]

/-- Independently retain each listed coordinate with its specified
probability. The list order only specifies the sequence of tosses. -/
noncomputable def thinList (p : E → ℝ) : List E → (Finset E → ℝ) → Finset E → ℝ
  | [], f => f
  | e :: es, f => thinCoordinate e (p e) (thinList p es f)

theorem thinList_law (p : E → ℝ) (es : List E) (hn : es.Nodup) (hs : ∀ e ∈ es, e ∈ S)
    (f : Finset E → ℝ) :
    expectation ends S x (thinList p es f) =
      expectation ends S (fun e => if e ∈ es then p e*x e else x e) f := by
  classical
  induction es generalizing x with
  | nil => simp [thinList]
  | cons e es ih =>
    rw [thinList, thinCoordinate_law ends S x e (hs e List.mem_cons_self) (p e)]
    rw [ih _ (List.nodup_cons.mp hn).2 (fun d hd => hs d (List.mem_cons_of_mem _ hd))]
    congr 1
    funext d
    by_cases he : d = e
    · subst d
      simp [List.nodup_cons.mp hn]
    · simp [he]

/-- The law of the earlier edges at a fixed priority threshold. -/
theorem thinSupport_law (p : E → ℝ) (f : Finset E → ℝ) :
    expectation ends S x (thinList p S.toList f) =
      expectation ends S (fun e => p e*x e) f := by
  rw [thinList_law ends S x p _ S.nodup_toList (by simp) f]
  exact expectation_agree ends (fun e => p e*x e) S _ (by intro d hd; simp [hd]) f

end SubmodularMatching.Shearer
