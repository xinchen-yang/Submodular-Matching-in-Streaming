import SubmodularMatching.CapacityReducedResources

/-! # Equality of the lazy input pass and the virtual solver's arrival sequence -/

namespace SubmodularMatching.Capacity

open Finset UpperBoundAssembly

noncomputable section

variable {E V State : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- Every consumer sees precisely the virtual stream in order, with the proof of
membership in that stream erased. It can consume each copy as it is generated. -/
theorem reduced_run (S : SimpleEdgeStream E V) (cap : V → ℕ)
    (consume : State → Copy E → State) (st : State) :
    run S.ends (clipped cap) consume ∅ st S.arrivals =
      ((allocation S cap).kept,
       (reduced S cap).arrivals.foldl (fun state e => consume state e.val) st) := by
  change run S.ends (clipped cap) consume (emptyAllocation : Allocation E V).kept st S.arrivals =
    ((final S.ends (clipped cap) emptyAllocation S.arrivals).kept,
      (emittedCopies S cap).attach.foldl (fun state e => consume state e.val) st)
  simpa only [emittedCopies, List.foldl_attach] using
    run_eq S.ends (clipped cap) emptyAllocation consume st S.arrivals

/-- The original labels kept by the reduction at any input prefix fit the same
cardinality budget, independently of the state of the ordinary solver. -/
theorem reduced_prefix_storage (S : SimpleEdgeStream E V) (cap : V → ℕ)
    (consume : State → Copy E → State) (st : State) (k νb : ℕ)
    (hν : ∀ M, feasible S.ends cap M → M.card ≤ νb) :
    (run S.ends (clipped cap) consume ∅ st (S.arrivals.take k)).1.card ≤ νb := by
  apply run_storage _ _ _ _ _ (List.Nodup.sublist (List.take_sublist k S.arrivals) S.distinct)
  exact fun s hs => hν s ((feasible_clipped_iff S cap s).1 hs)

end

end SubmodularMatching.Capacity
