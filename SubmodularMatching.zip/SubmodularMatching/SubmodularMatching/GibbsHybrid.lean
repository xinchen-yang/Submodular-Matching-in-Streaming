import SubmodularMatching.GibbsConditioning
import SubmodularMatching.IndependentSampling

/-!
# Hybrid comparison with independent rounding

The hybrid replaces ordered actual matching indicators by independent
Bernoulli indicators with the same marginals. No conditioning on previously
revealed indicators occurs.
-/

namespace SubmodularMatching.GibbsMatching

open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Coordinates already replaced by independent decisions. -/
def replacementPrefix (edges : ℕ → E) (n : ℕ) : Finset E := (Finset.range n).image edges

@[simp] theorem replacementPrefix_zero (edges : ℕ → E) : replacementPrefix edges 0 = ∅ := by
  simp [replacementPrefix]

theorem replacementPrefix_succ (edges : ℕ → E) (n : ℕ) :
    replacementPrefix edges (n + 1) = insert (edges n) (replacementPrefix edges n) := by
  simp [replacementPrefix, Finset.range_add_one]

theorem bernoulli_const_mul (edges : ℕ → E) (q : ℕ → ℝ)
    (c : ℝ) (F : Finset E → ℝ) (n : ℕ) :
    bernoulliExpectation edges q (fun A => c * F A) n =
      c * bernoulliExpectation edges q F n := by
  induction n generalizing F with
  | zero => rfl
  | succ n ih =>
    simp only [bernoulliExpectation_succ, ih]
    ring

theorem bernoulli_congr (edges : ℕ → E) (q : ℕ → ℝ)
    (F H : Finset E → ℝ) (n : ℕ) (hFH : ∀ A, F A = H A) :
    bernoulliExpectation edges q F n = bernoulliExpectation edges q H n := by
  have hfun : F = H := funext hFH
  rw [hfun]

/-- The independent prefix and remaining true matching indicators form a
hybrid random edge set. -/
noncomputable def hybridValue (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (edges : ℕ → E) (f : Finset E → ℝ) (k : ℕ) : ℝ :=
  bernoulliExpectation edges (fun i => edgeMean ends S activity (edges i))
    (fun R => expectation ends S activity
      (fun M => f ((M \ replacementPrefix edges k) ∪ R))) k

theorem hybridValue_zero (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (edges : ℕ → E) (f : Finset E → ℝ) :
    hybridValue ends S activity edges f 0 = expectation ends S activity f := by
  simp [hybridValue]

theorem hybridValue_terminal (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (ha : ∀ e ∈ S, 0 ≤ activity e)
    (edges : ℕ → E) (f : Finset E → ℝ) (n : ℕ)
    (hS : S ⊆ replacementPrefix edges n) :
    hybridValue ends S activity edges f n =
      bernoulliExpectation edges (fun i => edgeMean ends S activity (edges i)) f n := by
  apply bernoulli_congr
  intro R
  calc
    _ = expectation ends S activity (fun _ => f R) := by
      apply expectation_congr
      intro M hM
      have hsub := (((mem_matchings ends S M).mp hM).1).trans hS
      rw [Finset.sdiff_eq_empty_iff_subset.mpr hsub, Finset.empty_union]
    _ = f R := expectation_const ends S activity ha (f R)

theorem erase_sdiff_of_mem (M C : Finset E) (e : E) (he : e ∈ C) :
    M.erase e \ C = M \ C := by
  ext d
  simp only [Finset.mem_sdiff, Finset.mem_erase]
  by_cases hde : d = e
  · subst d
    simp [he]
  · simp [hde]

/-- A single unreplaced matching indicator contributes exactly its marginal
value, multiplied by its zero-one presence indicator. -/
theorem projection_marginal_identity (f : Finset E → ℝ)
    (M C R : Finset E) (e : E) (he : e ∉ C) :
    f ((M \ C) ∪ R) = f ((M \ insert e C) ∪ R) +
      (if e ∈ M then marginal f e ((M \ insert e C) ∪ R) else 0) := by
  by_cases hem : e ∈ M
  · have hset : (M \ C) ∪ R = ((M \ insert e C) ∪ R) ∪ {e} := by
      ext d
      by_cases hde : d = e
      · subst d
        simp [hem, he]
      · simp only [Finset.mem_union, Finset.mem_sdiff, Finset.mem_insert,
          Finset.mem_singleton, hde, false_or, or_false]
    rw [if_pos hem, marginal, ← hset]
    ring
  · have hset : M \ C = M \ insert e C := by
      ext d
      by_cases hde : d = e
      · subst d
        simp [hem]
      · simp [hde]
    rw [if_neg hem, hset, add_zero]

/-- Exact algebraic difference of two consecutive hybrids. -/
theorem hybridValue_increment (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (edges : ℕ → E) (f : Finset E → ℝ) (k : ℕ)
    (he : edges k ∉ replacementPrefix edges k) :
    hybridValue ends S activity edges f (k + 1) - hybridValue ends S activity edges f k =
      bernoulliExpectation edges (fun i => edgeMean ends S activity (edges i))
        (fun R => edgeMean ends S activity (edges k) *
          expectation ends S activity
            (fun M => marginal f (edges k) ((M \ replacementPrefix edges (k + 1)) ∪ R)) -
          expectation ends S activity (fun M => if edges k ∈ M then
            marginal f (edges k) ((M \ replacementPrefix edges (k + 1)) ∪ R) else 0)) k := by
  have hold : ∀ R, expectation ends S activity
      (fun M => f ((M \ replacementPrefix edges k) ∪ R)) =
      expectation ends S activity
        (fun M => f ((M \ replacementPrefix edges (k + 1)) ∪ R)) +
      expectation ends S activity (fun M => if edges k ∈ M then
        marginal f (edges k) ((M \ replacementPrefix edges (k + 1)) ∪ R) else 0) := by
    intro R
    rw [← expectation_add]
    apply expectation_congr
    intro M _
    rw [replacementPrefix_succ]
    exact projection_marginal_identity f M (replacementPrefix edges k) R (edges k) he
  have hnew : ∀ R, expectation ends S activity
      (fun M => f ((M \ replacementPrefix edges (k + 1)) ∪ (R ∪ {edges k}))) =
      expectation ends S activity
        (fun M => f ((M \ replacementPrefix edges (k + 1)) ∪ R)) +
      expectation ends S activity
        (fun M => marginal f (edges k) ((M \ replacementPrefix edges (k + 1)) ∪ R)) := by
    intro R
    rw [← expectation_add]
    apply expectation_congr
    intro M _
    rw [marginal, Finset.union_assoc]
    ring
  unfold hybridValue
  rw [bernoulliExpectation_succ]
  simp_rw [hold, hnew, bernoulliExpectation_add, bernoulliExpectation_sub,
    bernoulli_const_mul]
  ring

/-- The one-step hybrid error is at most the Gibbs dependence constant times
the independent marginal contribution at this coordinate. -/
theorem hybridValue_increment_le [Finite V]
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (hsimple : Set.InjOn ends (S : Set E)) (h : ℝ) (hh : 0 ≤ h)
    (hcap : ∀ e ∈ S, activity e ≤ h)
    (edges : ℕ → E) (f : Finset E → ℝ) (hf : IsSubmodular f) (hm : IsMonotone f)
    (k : ℕ) (hmem : ∀ i ≤ k, edges i ∈ S)
    (he : edges k ∉ replacementPrefix edges k) :
    hybridValue ends S activity edges f (k + 1) - hybridValue ends S activity edges f k ≤
      Real.sqrt (h / 2) *
        (bernoulliExpectation edges (fun i => edgeMean ends S activity (edges i)) f (k + 1) -
          bernoulliExpectation edges (fun i => edgeMean ends S activity (edges i)) f k) := by
  let q := fun i => edgeMean ends S activity (edges i)
  let C := replacementPrefix edges (k + 1)
  have heC : edges k ∈ C := by simp [C, replacementPrefix_succ]
  have hpoint (R : Finset E) :
      q k * expectation ends S activity
        (fun M => marginal f (edges k) ((M \ C) ∪ R)) -
      expectation ends S activity (fun M => if edges k ∈ M then
        marginal f (edges k) ((M \ C) ∪ R) else 0) ≤
      q k * Real.sqrt (h / 2) * marginal f (edges k) R := by
    let g := fun M : Finset E => marginal f (edges k) ((M \ C) ∪ R)
    have hdec : ∀ A B : Finset E, A ⊆ B → g B ≤ g A := by
      intro A B hAB
      apply marginal_antitone f hf hm
      exact Finset.union_subset_union (Finset.sdiff_subset_sdiff hAB (Finset.Subset.refl _))
        (Finset.Subset.refl _)
    have hgb : ∀ N ∈ matchings ends (compatibleEdges ends S (edges k)),
        0 ≤ g N ∧ g N ≤ marginal f (edges k) R := by
      intro N _
      exact ⟨marginal_nonnegative f hm _ _,
        marginal_antitone f hf hm R ((N \ C) ∪ R) (edges k) Finset.subset_union_right⟩
    have hreg := gibbs_indicator_regression ends S activity ha hends hsimple h
      (marginal f (edges k) R) hh (marginal_nonnegative f hm _ _) hcap
      (edges k) (hmem k le_rfl) g hdec hgb
    have herase : ∀ M, g (M.erase (edges k)) = g M := by
      intro M
      dsimp [g]
      rw [erase_sdiff_of_mem M C (edges k) heC]
    simpa only [herase] using hreg
  rw [hybridValue_increment ends S activity edges f k he]
  have hq : ∀ i < k, 0 ≤ q i ∧ q i ≤ 1 :=
    fun i hi => edgeMean_bounds ends S activity ha (edges i) (hmem i (Nat.le_of_lt hi))
  have havg := bernoulliExpectation_mono edges q _ _ k hq hpoint
  rw [bernoulli_const_mul] at havg
  have hind := bernoulliExpectation_increment edges q f k
  change _ ≤ Real.sqrt (h / 2) * (_ - _)
  rw [hind]
  convert havg using 1
  ring

/-- GM7: Gibbs rounding preserves at least the positive part of
`1 - sqrt(h/2)` times the independent multilinear value at its actual edge
marginals. The first `n` entries enumerate the finite edge set distinctly. -/
theorem gibbs_submodular_comparison [Finite V]
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (hsimple : Set.InjOn ends (S : Set E)) (h : ℝ) (hh : 0 ≤ h)
    (hcap : ∀ e ∈ S, activity e ≤ h)
    (edges : ℕ → E) (n : ℕ)
    (hmem : ∀ i < n, edges i ∈ S)
    (hcover : S ⊆ replacementPrefix edges n)
    (hdistinct : ∀ i < n, ∀ j < n, edges i = edges j → i = j)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0) :
    max 0 (1 - Real.sqrt (h / 2)) *
        bernoulliExpectation edges (fun i => edgeMean ends S activity (edges i)) f n ≤
      expectation ends S activity f := by
  let q := fun i => edgeMean ends S activity (edges i)
  have htel : ∀ k, k ≤ n →
      hybridValue ends S activity edges f k - expectation ends S activity f ≤
        Real.sqrt (h / 2) * (bernoulliExpectation edges q f k - f ∅) := by
    intro k
    induction k with
    | zero =>
      intro _
      simp [hybridValue_zero]
    | succ k ih =>
      intro hkn
      have hklt : k < n := Nat.lt_of_lt_of_le (Nat.lt_succ_self k) hkn
      have hprev := ih (Nat.le_of_lt hklt)
      have hnot : edges k ∉ replacementPrefix edges k := by
        intro hk
        obtain ⟨i, hi, hik⟩ := Finset.mem_image.mp hk
        have hiklt := Finset.mem_range.mp hi
        have hieq := hdistinct i (Nat.lt_trans hiklt hklt) k hklt hik
        exact (Nat.ne_of_lt hiklt) hieq
      have hstep := hybridValue_increment_le ends S activity ha hends hsimple
        h hh hcap edges f hf hm k
        (fun i hi => hmem i (Nat.lt_of_le_of_lt hi hklt)) hnot
      change _ ≤ Real.sqrt (h / 2) *
        (bernoulliExpectation edges q f (k + 1) - bernoulliExpectation edges q f k) at hstep
      nlinarith only [hprev, hstep]
  have hfinal := htel n le_rfl
  rw [hybridValue_terminal ends S activity ha edges f n hcover, hzero, sub_zero] at hfinal
  have hnonneg : 0 ≤ expectation ends S activity f := by
    apply expectation_nonnegative ends S activity ha
    intro M _
    have hmono := hm ∅ M (Finset.empty_subset M)
    simpa only [hzero] using hmono
  by_cases hd : 0 ≤ 1 - Real.sqrt (h / 2)
  · rw [max_eq_right hd]
    change (1 - Real.sqrt (h / 2)) * bernoulliExpectation edges q f n ≤ _
    nlinarith only [hfinal]
  · rw [max_eq_left (le_of_not_ge hd), zero_mul]
    exact hnonneg

end SubmodularMatching.GibbsMatching
