import SubmodularMatching.CertificateEndpointTarget

/-!
# Retaining the rate dependence of the target in a box proof

Centering each source height by its own share of the target preserves the
correlation between a rate on the left and on the right. For any fixed
price, the resulting affine expression is bounded by checks at the two
rate endpoints.
-/

namespace SubmodularMatching.SourceCertificate

open Streaming

theorem centered_axis_from_rate_endpoints (height capacity shift penalty price lower lo hi rate : ℝ)
    (hlo : lo ≤ rate) (hhi : rate ≤ hi)
    (hL : lower ≤ lo * (capacity * height - shift) - penalty * price)
    (hR : lower ≤ hi * (capacity * height - shift) - penalty * price) :
    lower ≤ rate * (capacity * height - shift) - penalty * price := by
  have h := affine_lower_of_endpoints (capacity * height - shift) (-(penalty * price)) lo hi rate lower
    hlo hhi (by linarith only [hL]) (by linarith only [hR])
  linarith only [h]

theorem centered_source_box_dual_lower (T : SourcePotentialTable) (i j : Bool)
    (A B D sigma q c : ℝ) (t L R a d : ℝ)
    (ht0 : 0 ≤ t) (htq : t ≤ q)
    (hL : L ≤ A * (vertexCapacity D i * T.value i a - sigma * unmatched i) - (t * c) * a)
    (hR : R ≤ B * (vertexCapacity D j * T.value j d - sigma * unmatched j) - (t * (1 - c)) * d)
    (htarget : sigma ≤ L + R + t) :
    sigma * (1 + unmatched i * A + unmatched j * B) ≤
      gridValue (fun x => vertexCapacity D i * A * T.value i x)
        (fun y => vertexCapacity D j * B * T.value j y) q c a d := by
  have hmax :
      t * (1 - c * a - (1 - c) * d) ≤ q * max (1 - c * a - (1 - c) * d) 0 :=
    (mul_le_mul_of_nonneg_left (le_max_left _ _) ht0).trans
      (mul_le_mul_of_nonneg_right htq (le_max_right _ _))
  unfold gridValue
  nlinarith only [hmax, hL, hR, htarget]

theorem gridValue_le_when_ratio_high (U V : ℝ → ℝ) (q r c a d : ℝ)
    (hq : 0 ≤ q) (hr : c ≤ r) (hda : d ≤ a) :
    gridValue U V q r a d ≤ gridValue U V q c a d := by
  have hm := mul_nonneg (sub_nonneg.mpr hr) (sub_nonneg.mpr hda)
  have harg : 1 - r * a - (1 - r) * d ≤ 1 - c * a - (1 - c) * d := by
    nlinarith only [hm]
  unfold gridValue
  exact add_le_add le_rfl (mul_le_mul_of_nonneg_left (max_le_max harg le_rfl) hq)

theorem gridValue_le_when_ratio_low (U V : ℝ → ℝ) (q r c a d : ℝ)
    (hq : 0 ≤ q) (hr : r ≤ c) (had : a ≤ d) :
    gridValue U V q r a d ≤ gridValue U V q c a d := by
  have hm := mul_nonneg (sub_nonneg.mpr hr) (sub_nonneg.mpr had)
  have harg : 1 - r * a - (1 - r) * d ≤ 1 - c * a - (1 - c) * d := by
    nlinarith only [hm]
  unfold gridValue
  exact add_le_add le_rfl (mul_le_mul_of_nonneg_left (max_le_max harg le_rfl) hq)

theorem centered_source_box_ratio_endpoints (U V : ℝ → ℝ) (q lo hi c a d target : ℝ)
    (hq : 0 ≤ q) (hlo : lo ≤ c) (hhi : c ≤ hi)
    (hLeft : a ≤ d → target ≤ gridValue U V q lo a d)
    (hRight : d ≤ a → target ≤ gridValue U V q hi a d) :
    target ≤ gridValue U V q c a d := by
  by_cases h : a ≤ d
  · exact (hLeft h).trans (gridValue_le_when_ratio_low _ _ _ _ _ _ _ hq hlo h)
  · have hd := (lt_of_not_ge h).le
    exact (hRight hd).trans (gridValue_le_when_ratio_high _ _ _ _ _ _ _ hq hhi hd)

end SubmodularMatching.SourceCertificate
