import SubmodularMatching.UpperBoundParametricScan

/-! # Family amplification for the actual comparison-grid output law -/

namespace SubmodularMatching.UpperBoundAssembly

open NumericalCertificate GibbsSampler ProbabilityAmplification
open scoped BigOperators

noncomputable section

variable {A T : Type*}

private theorem selection_retained_threshold_zero (s : Finset A) (mass value : A → ℝ)
    (step target threshold : ℝ) (hstep : 0 < step) (hmargin : target ≤ threshold - step)
    (count : ℕ) (initial : A) (hi : ⌊threshold / step⌋ ≤ comparisonIndex value step initial) :
    selectionExpectation s mass value step (fun a => if target ≤ value a then 0 else 1)
      count initial = 0 := by
  induction count generalizing initial with
  | zero =>
      have hfloor : (⌊threshold / step⌋ : ℝ) ≤ comparisonIndex value step initial := by
        exact_mod_cast hi
      have h : threshold / step < value initial / step + 1 := by
        unfold comparisonIndex at hfloor
        linarith [Int.lt_floor_add_one (threshold / step), Int.floor_le (value initial / step)]
      have h' := (div_lt_iff₀ hstep).mp h
      rw [add_mul, div_mul_cancel₀ _ hstep.ne', one_mul] at h'
      have hv : target ≤ value initial := by linarith only [h', hmargin]
      simp [selectionExpectation, hv]
  | succ count ih =>
      unfold selectionExpectation
      apply Finset.sum_eq_zero
      intro b _
      rw [ih _ (hi.trans (comparisonIndex_le_left value step initial b)), mul_zero]

/-- One successful trial keeps a sufficient grid index through all later
challengers. Thus the actual selection failure is at most all-trials failure. -/
theorem parametricSelection_failure_le (s : Finset A) (mass value : A → ℝ)
    (step target threshold : ℝ) (hstep : 0 < step) (hmargin : target ≤ threshold - step)
    (hmass : ∀ a ∈ s, 0 ≤ mass a) (count : ℕ) (initial : A) :
    selectionExpectation s mass value step (fun a => if target ≤ value a then 0 else 1)
        count initial ≤ repeatedFailure s mass value threshold count := by
  classical
  induction count generalizing initial with
  | zero =>
      simp only [selectionExpectation, repeatedFailure, Nat.rec_zero]
      split_ifs <;> norm_num
  | succ count ih =>
      rw [selectionExpectation, repeatedFailure_succ]
      apply Finset.sum_le_sum
      intro b hb
      by_cases h : threshold ≤ value b
      · have hi : ⌊threshold / step⌋ ≤ comparisonIndex value step b :=
          Int.floor_mono ((div_le_div_iff_of_pos_right hstep).mpr h)
        have zz := selection_retained_threshold_zero s mass value step target threshold
          hstep hmargin count (keepBetter value step initial b)
          (hi.trans (comparisonIndex_le_right value step initial b))
        simp [h, zz]
      · rw [if_neg h]
        exact mul_le_mul_of_nonneg_left (ih _) (hmass b hb)

/-- The conditional factor obtained from FJ8 by retaining the best singleton. -/
def k1TrialFactor (e θ η : ℝ) : ℝ := (1 + 5 * e) / (θ * η)

theorem k1Conditional_trialValue (e θ η opt B Y : ℝ) (he : 0 ≤ e)
    (hbest : B ≤ Y) (hvalue : θ * η * opt ≤ Y + 5 * e * B) :
    opt / k1TrialFactor e θ η ≤ Y := by
  have h := FiniteError.absorb_additive Y B (5 * e) (θ * η * opt) (by positivity) hbest hvalue
  have hd : 0 < 1 + 5 * e := by positivity
  unfold k1TrialFactor
  rw [div_div_eq_mul_div]
  exact (div_le_iff₀ hd).mpr (by nlinarith only [h])

/-- Appendix K.4 amplification on the finite sequential output law, allowing
independent estimation precision and rounding loss. -/
theorem k1Program_high_probability (prep : CandidateLaw T)
    (good : T → Prop) [DecidablePred good] (states : Finset A) (value : A → ℝ)
    (qs : T → List (CandidateLaw A)) (initial : A) (e θ η opt B δ R₁ R selectorMesh : ℝ)
    (he : 0 < e) (hθ : 0 < θ) (hη : 0 < η) (hopt : 0 < opt) (hB : 0 < B) (hBopt : B ≤ opt) (hδ : 0 < δ)
    (hR₁ : 1 < R₁) (_hR : 0 < R) (htrial : k1TrialFactor e θ η < R₁)
    (hmesh : 0 < selectorMesh) (hmargin : 1 / R ≤ 1 / R₁ - selectorMesh)
    (hi : initial ∈ states) (hs : ∀ t, ∀ q ∈ qs t, q.outcomes ⊆ states)
    (hrange : ∀ a ∈ states, value a ≤ opt)
    (hbad : (∑ t ∈ prep.outcomes, if good t then 0 else prep.mass t) ≤ δ / 2)
    (hgood : ∀ t ∈ prep.outcomes, good t →
      let Y := scanExpectation value (e * B / 2) value (qs t) initial
      B ≤ Y ∧ θ * η * opt ≤ Y + 5 * e * B)
    (count : ℕ)
    (hcount : Real.log (2 / δ) /
      ((R₁ - k1TrialFactor e θ η) / (k1TrialFactor e θ η * (R₁ - 1))) ≤ (count : ℝ)) :
    let law := refinedOutputLaw prep states value (e * B / 2) (selectorMesh * B) qs initial hi hs count
    expected law.outcomes law.mass (fun a => if opt / R ≤ value a then 0 else 1) ≤ δ := by
  dsimp only
  rw [refinedOutputLaw_value]
  let step := e * B / 2
  let decisionStep := selectorMesh * B
  let test := fun a : A => if opt / R ≤ value a then (0 : ℝ) else 1
  let Q := (R₁ - k1TrialFactor e θ η) / (k1TrialFactor e θ η * (R₁ - 1))
  have hF : 0 < k1TrialFactor e θ η := by
    unfold k1TrialFactor
    exact div_pos (by positivity) (mul_pos hθ hη)
  have hQ : 0 < Q := div_pos (sub_pos.mpr htrial) (mul_pos hF (sub_pos.mpr hR₁))
  have hstep : 0 < decisionStep := mul_pos hmesh hB
  have hmargin' : opt / R ≤ opt / R₁ - decisionStep := by
    have h := mul_le_mul_of_nonneg_left hmargin hopt.le
    have h₂ := mul_le_mul_of_nonneg_left hBopt hmesh.le
    dsimp only [decisionStep]
    simp only [mul_sub, mul_one_div] at h
    nlinarith only [h, h₂]
  have hcount' : Real.log (1 / (δ / 2)) / Q ≤ (count : ℝ) := by
    have heq : 1 / (δ / 2) = 2 / δ := by field_simp
    rw [heq]
    exact hcount
  let Y (t : T) := selectionExpectation states (scanMass value step (qs t) initial)
      value decisionStep test count initial
  have hY (t : T) (ht : t ∈ prep.outcomes) :
      prep.mass t * Y t ≤ prep.mass t * (δ / 2) + if good t then 0 else prep.mass t := by
    let μ := scanMass value step (qs t) initial
    have hμ := scanMass_probability states value step (qs t) initial hi (hs t)
    by_cases hg : good t
    · have hy := hgood t ht hg
      have hmean := k1Conditional_trialValue e θ η opt B _ he.le hy.1 hy.2
      have hactual : opt / k1TrialFactor e θ η ≤ states.sum (fun a => μ a * value a) := by
        change _ ≤ expected states μ value
        rw [scanMass_expected states value value step (qs t) initial hi (hs t)]
        exact hmean
      have hsingle := one_trial_success states μ value opt (k1TrialFactor e θ η) R₁
        hopt hF hR₁ hμ.nonnegative hμ.total hrange hactual
      have hsamp := logarithmic_repetition_bound states μ value (opt / R₁) Q (δ / 2)
        hμ.nonnegative hμ.total hQ (div_pos hδ (by norm_num)) hsingle count hcount'
      have hsel := parametricSelection_failure_le states μ value decisionStep (opt / R) (opt / R₁)
        hstep hmargin' hμ.nonnegative count initial
      simpa only [if_pos hg, add_zero] using
        mul_le_mul_of_nonneg_left (hsel.trans hsamp) (prep.probability.nonnegative t ht)
    · have hsel := selectionExpectation_mono states μ value decisionStep test (fun _ => 1)
        hμ.nonnegative (fun a => by unfold test; split_ifs <;> norm_num) count initial
      rw [selectionExpectation_const _ _ _ _ _ hμ.total] at hsel
      rw [if_neg hg]
      have hh : 0 ≤ prep.mass t * (δ / 2) := mul_nonneg (prep.probability.nonnegative t ht) (by positivity)
      exact (mul_le_mul_of_nonneg_left hsel (prep.probability.nonnegative t ht)).trans
        (by rw [mul_one]; exact le_add_of_nonneg_left hh)
  calc
    _ ≤ ∑ t ∈ prep.outcomes, (prep.mass t * (δ / 2) + if good t then 0 else prep.mass t) :=
      Finset.sum_le_sum hY
    _ ≤ _ := by
      rw [Finset.sum_add_distrib, ← Finset.sum_mul, prep.probability.total, one_mul]
      linarith only [hbad]

/-- Generic high-probability family theorem on the same finite, sequential
selection law used in the fixed-parameter specialization. -/
theorem parametricProgram_high_probability (prep : CandidateLaw T)
    (good : T → Prop) [DecidablePred good] (states : Finset A) (value : A → ℝ)
    (qs : T → List (CandidateLaw A)) (initial : A) (e opt B δ R₁ R : ℝ)
    (he : 0 < e) (he1 : e < 1) (hopt : 0 < opt) (hB : 0 < B) (hBopt : B ≤ opt) (hδ : 0 < δ)
    (hR₁ : 1 < R₁) (_hR : 0 < R) (htrial : familyTrialFactor e < R₁)
    (hmargin : 1 / R ≤ 1 / R₁ - e / 2)
    (hi : initial ∈ states) (hs : ∀ t, ∀ q ∈ qs t, q.outcomes ⊆ states)
    (hrange : ∀ a ∈ states, value a ≤ opt)
    (hbad : (∑ t ∈ prep.outcomes, if good t then 0 else prep.mass t) ≤ δ / 2)
    (hgood : ∀ t ∈ prep.outcomes, good t →
      let Y := scanExpectation value (e * B / 2) value (qs t) initial
      B ≤ Y ∧ (1 - e) * sigma * opt ≤ Y + 5 * e * B)
    (count : ℕ)
    (hcount : Real.log (2 / δ) /
      ((R₁ - familyTrialFactor e) / (familyTrialFactor e * (R₁ - 1))) ≤ (count : ℝ)) :
    let law := amplifiedOutputLaw prep states value (e * B / 2) qs initial hi hs count
    expected law.outcomes law.mass (fun a => if opt / R ≤ value a then 0 else 1) ≤ δ := by
  have hfactor : k1TrialFactor e (1 - e) sigma = familyTrialFactor e := rfl
  have hmesh : (e / 2) * B = e * B / 2 := by ring
  have h := k1Program_high_probability prep good states value qs initial e (1 - e) sigma opt B δ R₁ R (e / 2)
    he (sub_pos.mpr he1) sigma_pos hopt hB hBopt hδ hR₁ _hR
    (hfactor.symm ▸ htrial) (by positivity) hmargin hi hs hrange hbad hgood count (hfactor.symm ▸ hcount)
  simpa only [hmesh] using h

end

end SubmodularMatching.UpperBoundAssembly
