import SubmodularMatching.UpperBoundAppendixCheckedSource
import SubmodularMatching.UpperBoundGraphConfidence

/-! # Theorem 1.1 specialized to the exact Appendix L data -/

namespace SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream

open SourceCertificate NumericalCertificate GibbsSampler

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- The upper bound for the actual Appendix L data, reduced to the
single uncovered/uncovered root of the numerical partition. -/
theorem theorem1_1_of_uncovered_root (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (h0 : 0 ≤ f ∅)
    (h00 : AppendixBoxGoal false false appendixPriceRoot)
    (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (delta : ℝ) (hδ : 0 < delta) :
    let p := S.expectedOutput f hf hmono
    let q := S.amplifiedOutput f hf hmono delta
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / targetFactor ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤ delta :=
  S.theorem1_1_value f hf hmono h0 (fun hn =>
    appendixSourceObligation_of_uncovered_root (Fintype.card V) hn h00) O hO hopt delta hδ

/-- High-probability form with the manuscript's precise exponent. -/
theorem theorem1_1_confidence_of_uncovered_root (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (h0 : 0 ≤ f ∅)
    (h00 : AppendixBoxGoal false false appendixPriceRoot)
    (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (hn : 1 ≤ Fintype.card V) (c : ℝ) :
    let n := Fintype.card V
    let delta := (((n : ℝ) ^ ⌈c⌉₊)⁻¹)
    let q := S.amplifiedOutput f hf hmono delta
    q.outcomes ⊆ S.matchings ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤
        (n : ℝ) ^ (-c) :=
  S.theorem1_1_confidence f hf hmono h0 (fun hn =>
    appendixSourceObligation_of_uncovered_root (Fintype.card V) hn h00) O hO hopt hn c

end

end SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream
