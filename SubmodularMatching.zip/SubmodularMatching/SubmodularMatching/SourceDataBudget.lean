import SubmodularMatching.SourceDataPotential
import Mathlib.Algebra.BigOperators.Intervals

/-!
# The finite logarithmic budget of the tabulated source functions

The first interpolation interval has zero slope and starts at zero, so it is
omitted from the sum of logarithmic terms.
-/

namespace SubmodularMatching.SourceCertificate.SourcePotentialTable

open MeasureTheory Set
open scoped BigOperators

noncomputable section

def rationalSlope (T : SourcePotentialTable) (b : Bool) (i : ℕ) : ℚ :=
  (T.height b (i + 1) - T.height b i) / (T.knot (i + 1) - T.knot i)

theorem rationalSlope_cast (T : SourcePotentialTable) (b : Bool) (i : ℕ) :
    (T.rationalSlope b i : ℝ) = T.slope b i := by
  unfold rationalSlope slope realHeight realKnot
  push_cast
  rfl

theorem integral_eq_log_sum (T : SourcePotentialTable) (b : Bool) :
    (∫ x in Ioi (0 : ℝ), T.value b x / x ^ 2) =
      ∑ i ∈ Finset.Ico 1 T.count, T.slope b i * Real.log (T.realKnot (i + 1) / T.realKnot i) := by
  let k (i : ℕ) := T.realKnot (min (i + 1) T.count)
  let s (i : ℕ) := T.slope b (i + 1)
  let z (i : ℕ) := T.realHeight b (i + 1) - s i * T.realKnot (i + 1)
  have hfirst : k 0 = T.realKnot 1 := by dsimp [k]; rw [min_eq_left T.positive_count]
  have hlast : k (T.count - 1) = T.realKnot T.count := by
    dsimp only [k]
    rw [Nat.sub_add_cancel T.positive_count, min_self]
  have hmon : Monotone k := fun i j hij =>
    T.ordered.le (min_le_min (Nat.succ_le_succ hij) le_rfl) (min_le_right _ _)
  have hcells (i : ℕ) (hi : i < T.count - 1) (x : ℝ)
      (hx : x ∈ Icc (k i) (k (i + 1))) :
      T.value b x = s i * x + z i := by
    have hi' : i + 1 < T.count := by omega
    have hi'' : i + 1 + 1 ≤ T.count := by omega
    obtain ⟨ha, hb⟩ := hx
    dsimp only [k] at ha hb
    rw [min_eq_left hi'.le] at ha
    rw [min_eq_left hi''] at hb
    exact T.value_affine b (i + 1) hi' x ha hb
  have htail (x : ℝ) (hx : k (T.count - 1) ≤ x) :
      T.value b x = T.value b (k (T.count - 1)) := by
    rw [hlast] at hx ⊢
    rw [T.value_tail b x hx, T.value_tail b _ le_rfl]
  rw [weighted_integral_eq_log_sum (T.value b) k s z (T.count - 1)
    (hfirst ▸ T.first_positive) hmon (by rw [hfirst]; exact T.value_zero_near b)
    hcells htail (T.value_integrable b)]
  have hs := Finset.sum_Ico_add'
    (fun i => T.slope b i * Real.log (T.realKnot (i + 1) / T.realKnot i)) 0 (T.count - 1) 1
  rw [zero_add, Nat.sub_add_cancel T.positive_count] at hs
  rw [← Nat.Ico_zero_eq_range, ← hs]
  apply Finset.sum_congr rfl
  intro i hi
  have hib := (Finset.mem_Ico.mp hi).2
  dsimp only [k, s]
  rw [min_eq_left (show i + 1 + 1 ≤ T.count by omega),
    min_eq_left (show i + 1 ≤ T.count by omega)]

theorem integral_le_of_terms (T : SourcePotentialTable) (b : Bool)
    (upper : ℕ → ℝ) (bound : ℝ)
    (hterm : ∀ i ∈ Finset.Ico 1 T.count,
      T.slope b i * Real.log (T.realKnot (i + 1) / T.realKnot i) ≤ upper i)
    (hbudget : ∑ i ∈ Finset.Ico 1 T.count, upper i ≤ bound) :
    (∫ x in Ioi (0 : ℝ), T.value b x / x ^ 2) ≤ bound := by
  rw [T.integral_eq_log_sum b]
  exact (Finset.sum_le_sum hterm).trans hbudget

theorem integral_le_rational_log_budget (T : SourcePotentialTable) (b : Bool)
    (terms fuel : ℕ) (bound : ℚ)
    (hbudget : (∑ i ∈ Finset.Ico 1 T.count,
      T.rationalSlope b i * rationalDyadicLogUpper (T.knot (i + 1) / T.knot i) terms fuel) ≤ bound) :
    (∫ x in Ioi (0 : ℝ), T.value b x / x ^ 2) ≤ (bound : ℝ) := by
  apply T.integral_le_of_terms b
    (fun i => ((T.rationalSlope b i * rationalDyadicLogUpper (T.knot (i + 1) / T.knot i) terms fuel : ℚ) : ℝ))
  · intro i hi
    obtain ⟨hil, hiu⟩ := Finset.mem_Ico.mp hi
    have hpos : 0 < T.knot i := by
      have h := T.first_positive.trans_le (T.ordered.le hil hiu.le)
      unfold realKnot at h
      exact_mod_cast h
    have hratio : 1 ≤ T.knot (i + 1) / T.knot i :=
      (le_div_iff₀ hpos).2 (by simpa using (T.increasing_knots i hiu).le)
    have hlog := log_le_rationalDyadicLogUpper _ terms fuel hratio
    push_cast at hlog ⊢
    rw [rationalSlope_cast T b i]
    exact mul_le_mul_of_nonneg_left hlog (T.slope_nonnegative b i hiu)
  · exact_mod_cast hbudget

end

end SubmodularMatching.SourceCertificate.SourcePotentialTable
