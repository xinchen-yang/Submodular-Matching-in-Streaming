import SubmodularMatching.ReplayHardLastPiece00
import SubmodularMatching.ReplayHardLastPiece01
import SubmodularMatching.ReplayHardLastPiece02
import SubmodularMatching.ReplayHardLastPiece03
import SubmodularMatching.ReplayHardLastPiece04
import SubmodularMatching.ReplayHardLastPiece05
import SubmodularMatching.ReplayHardLastPiece06
import SubmodularMatching.ReplayHardLastPiece07
import SubmodularMatching.ReplayHardLastPiece08
import SubmodularMatching.ReplayHardLastPiece09
import SubmodularMatching.ReplayHardLastPiece10
import SubmodularMatching.ReplayHardLastPiece11
import SubmodularMatching.ReplayHardLastPiece12
import SubmodularMatching.ReplayHardLastPiece13
import SubmodularMatching.ReplayHardLastPiece14
import SubmodularMatching.ReplayHardLastPiece15

namespace SubmodularMatching.SourceCertificate.Replay.HardLast

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000
private theorem node3 : ProjectedGoal ⟨55080,55187,141,283,0,141⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55133 (by decide) (by decide) (chunk1 rates cones) (chunk2 rates cones)
private theorem node6 : ProjectedGoal ⟨55188,55295,141,283,0,141⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55241 (by decide) (by decide) (chunk4 rates cones) (chunk5 rates cones)
private theorem node7 : ProjectedGoal ⟨55080,55295,141,283,0,141⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55187 (by decide) (by decide) (node3 rates cones) (node6 rates cones)
private theorem node9 : ProjectedGoal ⟨55080,55295,141,283,0,283⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 141 (by decide) (by decide) (node7 rates cones) (chunk8 rates cones)
private theorem node11 : ProjectedGoal ⟨55080,55295,141,283,0,567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 283 (by decide) (by decide) (node9 rates cones) (chunk10 rates cones)
private theorem node12 : ProjectedGoal ⟨55080,55295,0,283,0,567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 141 (by decide) (by decide) (chunk0 rates cones) (node11 rates cones)
private theorem node14 : ProjectedGoal ⟨55080,55295,0,567,0,567⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 283 (by decide) (by decide) (node12 rates cones) (chunk13 rates cones)
private theorem node21 : ProjectedGoal ⟨55080,55093,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55086 (by decide) (by decide) (chunk19 rates cones) (chunk20 rates cones)
private theorem node23 : ProjectedGoal ⟨55080,55106,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55093 (by decide) (by decide) (node21 rates cones) (chunk22 rates cones)
private theorem node26 : ProjectedGoal ⟨55107,55120,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55113 (by decide) (by decide) (chunk24 rates cones) (chunk25 rates cones)
private theorem node29 : ProjectedGoal ⟨55121,55133,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55127 (by decide) (by decide) (chunk27 rates cones) (chunk28 rates cones)
private theorem node30 : ProjectedGoal ⟨55107,55133,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55120 (by decide) (by decide) (node26 rates cones) (node29 rates cones)
private theorem node31 : ProjectedGoal ⟨55080,55133,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55106 (by decide) (by decide) (node23 rates cones) (node30 rates cones)
private theorem node34 : ProjectedGoal ⟨55134,55160,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55147 (by decide) (by decide) (chunk32 rates cones) (chunk33 rates cones)
private theorem node36 : ProjectedGoal ⟨55134,55187,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55160 (by decide) (by decide) (node34 rates cones) (chunk35 rates cones)
private theorem node37 : ProjectedGoal ⟨55080,55187,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55133 (by decide) (by decide) (node31 rates cones) (node36 rates cones)
private theorem node39 : ProjectedGoal ⟨55080,55295,0,70,1072,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55187 (by decide) (by decide) (node37 rates cones) (chunk38 rates cones)
private theorem node40 : ProjectedGoal ⟨55080,55295,0,70,1064,1081⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1072 (by decide) (by decide) (chunk18 rates cones) (node39 rates cones)
private theorem node44 : ProjectedGoal ⟨55107,55133,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55120 (by decide) (by decide) (chunk42 rates cones) (chunk43 rates cones)
private theorem node45 : ProjectedGoal ⟨55080,55133,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55106 (by decide) (by decide) (chunk41 rates cones) (node44 rates cones)
private theorem node48 : ProjectedGoal ⟨55134,55160,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55147 (by decide) (by decide) (chunk46 rates cones) (chunk47 rates cones)
private theorem node51 : ProjectedGoal ⟨55161,55174,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55167 (by decide) (by decide) (chunk49 rates cones) (chunk50 rates cones)
private theorem node54 : ProjectedGoal ⟨55175,55181,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55178 (by decide) (by decide) (chunk52 rates cones) (chunk53 rates cones)
private theorem node56 : ProjectedGoal ⟨55175,55187,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55181 (by decide) (by decide) (node54 rates cones) (chunk55 rates cones)
private theorem node57 : ProjectedGoal ⟨55161,55187,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55174 (by decide) (by decide) (node51 rates cones) (node56 rates cones)
private theorem node58 : ProjectedGoal ⟨55134,55187,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55160 (by decide) (by decide) (node48 rates cones) (node57 rates cones)
private theorem node59 : ProjectedGoal ⟨55080,55187,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55133 (by decide) (by decide) (node45 rates cones) (node58 rates cones)
private theorem node62 : ProjectedGoal ⟨55188,55201,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55194 (by decide) (by decide) (chunk60 rates cones) (chunk61 rates cones)
private theorem node64 : ProjectedGoal ⟨55188,55214,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55201 (by decide) (by decide) (node62 rates cones) (chunk63 rates cones)
private theorem node67 : ProjectedGoal ⟨55215,55228,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55221 (by decide) (by decide) (chunk65 rates cones) (chunk66 rates cones)
private theorem node70 : ProjectedGoal ⟨55229,55241,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55235 (by decide) (by decide) (chunk68 rates cones) (chunk69 rates cones)
private theorem node71 : ProjectedGoal ⟨55215,55241,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55228 (by decide) (by decide) (node67 rates cones) (node70 rates cones)
private theorem node72 : ProjectedGoal ⟨55188,55241,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55214 (by decide) (by decide) (node64 rates cones) (node71 rates cones)
private theorem node74 : ProjectedGoal ⟨55188,55295,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55241 (by decide) (by decide) (node72 rates cones) (chunk73 rates cones)
private theorem node75 : ProjectedGoal ⟨55080,55295,0,70,1081,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55187 (by decide) (by decide) (node59 rates cones) (node74 rates cones)
private theorem node76 : ProjectedGoal ⟨55080,55295,0,70,1064,1099⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1081 (by decide) (by decide) (node40 rates cones) (node75 rates cones)
private theorem node80 : ProjectedGoal ⟨55107,55133,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55120 (by decide) (by decide) (chunk78 rates cones) (chunk79 rates cones)
private theorem node81 : ProjectedGoal ⟨55080,55133,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55106 (by decide) (by decide) (chunk77 rates cones) (node80 rates cones)
private theorem node85 : ProjectedGoal ⟨55161,55187,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55174 (by decide) (by decide) (chunk83 rates cones) (chunk84 rates cones)
private theorem node86 : ProjectedGoal ⟨55134,55187,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55160 (by decide) (by decide) (chunk82 rates cones) (node85 rates cones)
private theorem node87 : ProjectedGoal ⟨55080,55187,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55133 (by decide) (by decide) (node81 rates cones) (node86 rates cones)
private theorem node91 : ProjectedGoal ⟨55215,55241,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55228 (by decide) (by decide) (chunk89 rates cones) (chunk90 rates cones)
private theorem node92 : ProjectedGoal ⟨55188,55241,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55214 (by decide) (by decide) (chunk88 rates cones) (node91 rates cones)
private theorem node95 : ProjectedGoal ⟨55242,55255,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55248 (by decide) (by decide) (chunk93 rates cones) (chunk94 rates cones)
private theorem node98 : ProjectedGoal ⟨55256,55268,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55262 (by decide) (by decide) (chunk96 rates cones) (chunk97 rates cones)
private theorem node99 : ProjectedGoal ⟨55242,55268,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55255 (by decide) (by decide) (node95 rates cones) (node98 rates cones)
private theorem node102 : ProjectedGoal ⟨55269,55275,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55272 (by decide) (by decide) (chunk100 rates cones) (chunk101 rates cones)
private theorem node104 : ProjectedGoal ⟨55269,55282,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55275 (by decide) (by decide) (node102 rates cones) (chunk103 rates cones)
private theorem node106 : ProjectedGoal ⟨55269,55295,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55282 (by decide) (by decide) (node104 rates cones) (chunk105 rates cones)
private theorem node107 : ProjectedGoal ⟨55242,55295,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55268 (by decide) (by decide) (node99 rates cones) (node106 rates cones)
private theorem node108 : ProjectedGoal ⟨55188,55295,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55241 (by decide) (by decide) (node92 rates cones) (node107 rates cones)
private theorem node109 : ProjectedGoal ⟨55080,55295,0,70,1099,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55187 (by decide) (by decide) (node87 rates cones) (node108 rates cones)
private theorem node110 : ProjectedGoal ⟨55080,55295,0,70,1064,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1099 (by decide) (by decide) (node76 rates cones) (node109 rates cones)
private theorem node112 : ProjectedGoal ⟨55080,55295,0,141,1064,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 70 (by decide) (by decide) (node110 rates cones) (chunk111 rates cones)
private theorem node113 : ProjectedGoal ⟨55080,55295,0,141,993,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1064 (by decide) (by decide) (chunk17 rates cones) (node112 rates cones)
private theorem node115 : ProjectedGoal ⟨55080,55295,0,283,993,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 141 (by decide) (by decide) (node113 rates cones) (chunk114 rates cones)
private theorem node116 : ProjectedGoal ⟨55080,55295,0,283,851,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 993 (by decide) (by decide) (chunk16 rates cones) (node115 rates cones)
private theorem node117 : ProjectedGoal ⟨55080,55295,0,283,567,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 851 (by decide) (by decide) (chunk15 rates cones) (node116 rates cones)
private theorem node119 : ProjectedGoal ⟨55080,55295,0,567,567,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 283 (by decide) (by decide) (node117 rates cones) (chunk118 rates cones)
private theorem node120 : ProjectedGoal ⟨55080,55295,0,567,0,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 567 (by decide) (by decide) (node14 rates cones) (node119 rates cones)
private theorem node122 : ProjectedGoal ⟨55080,55295,0,1135,0,1135⟩ := by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 567 (by decide) (by decide) (node120 rates cones) (chunk121 rates cones)

theorem checked : ProjectedGoal ⟨55080,55295,0,1135,0,1135⟩ := node122

end SubmodularMatching.SourceCertificate.Replay.HardLast
