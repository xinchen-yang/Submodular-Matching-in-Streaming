import SubmodularMatching.LowerBoundGlobalDistinguished
import SubmodularMatching.LowerBoundGlobalBaseStream

/-! # The full finite hard-instance experiment -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

abbrev BaseDraw (N P t : ℕ) := (Fin P → Fin t) × (Fin P → PhaseSample N)

abbrev HardDraw (p N P t : ℕ) (C : Type*) :=
  (Fin p → BaseDraw N P t) × (Fin p → StageDraw (PaddedPair N) (C × C) C)

abbrev HardEdge (p N : ℕ) (C : Type*) := StagedEdge p (PaddedPair N) (C × C)

variable {p N P t H : ℕ} {C : Type*}

def baseDrawMass (b : BlueprintExpansion N P t H) (q : ℝ) (draw : BaseDraw N P t) : ℝ :=
  (1 / (Fintype.card (Fin P → Fin t) : ℝ)) * ∏ i, phaseRetainedMass b q draw.1 i (draw.2 i)

theorem baseDrawMass_nonneg (b : BlueprintExpansion N P t H) (q : ℝ) (draw : BaseDraw N P t) :
    0 ≤ baseDrawMass b q draw := by
  apply mul_nonneg (by positivity)
  exact Finset.prod_nonneg (fun _ _ => uniformSubsetMass_nonneg _ _ _)

theorem baseDrawMass_total (b : BlueprintExpansion N P t H) (q : ℝ)
    (hq0 : 0 ≤ q) (hq1 : q ≤ 1) [Nonempty (Fin t)] :
    (∑ draw, baseDrawMass b q draw) = 1 := by
  let T := (Fintype.card (Fin P → Fin t) : ℝ)
  have hT : T ≠ 0 := by dsimp [T]; positivity
  rw [Fintype.sum_prod_type]
  calc
    _ = ∑ _J : Fin P → Fin t, 1 / T := by
      apply Finset.sum_congr rfl
      intro J _
      simp only [baseDrawMass, ← Finset.mul_sum]
      rw [← Fintype.prod_sum]
      simp only [phaseRetainedMass_total b q hq0 hq1, Finset.prod_const_one, mul_one, T]
    _ = _ := by
      rw [Finset.sum_const, nsmul_eq_mul]
      change T * (1 / T) = 1
      field_simp

theorem baseDrawMass_pos_iff (b : BlueprintExpansion N P t H) (q : ℝ)
    (draw : BaseDraw N P t) [Nonempty (Fin t)] :
    0 < baseDrawMass b q draw ↔ ∀ i, 0 < phaseRetainedMass b q draw.1 i (draw.2 i) := by
  constructor
  · intro hd i
    have hp : ∏ j, phaseRetainedMass b q draw.1 j (draw.2 j) ≠ 0 := by
      intro hp0
      exact (ne_of_gt hd) (by simp [baseDrawMass, hp0])
    exact lt_of_le_of_ne (uniformSubsetMass_nonneg _ _ _)
      (Finset.prod_ne_zero_iff.mp hp i (Finset.mem_univ _)).symm
  · intro hip
    exact mul_pos (by positivity) (Finset.prod_pos (fun i _ => hip i))

def allCloneSlots (N : ℕ) (C : Type*) [Fintype C] : PaddedPair N → Finset (C × C) :=
  fun _ => Finset.univ

def hardDrawMass [Fintype C] [DecidableEq C] (b : BlueprintExpansion N P t H)
    (qBase qClone : ℝ) (draw : HardDraw p N P t C) : ℝ :=
  (∏ j, baseDrawMass b qBase (draw.1 j)) *
    (∏ j, stageDrawMass (allCloneSlots N C) qClone (draw.2 j))

theorem hardDrawMass_nonneg [Fintype C] [DecidableEq C] (b : BlueprintExpansion N P t H)
    (qBase qClone : ℝ) (draw : HardDraw p N P t C) :
    0 ≤ hardDrawMass b qBase qClone draw :=
  mul_nonneg (Finset.prod_nonneg fun j _ => baseDrawMass_nonneg b qBase (draw.1 j))
    (Finset.prod_nonneg fun j _ => stageDrawMass_nonneg _ _ (draw.2 j))

theorem hardDrawMass_total [Fintype C] [DecidableEq C] [Nonempty C] [Nonempty (Fin t)]
    (b : BlueprintExpansion N P t H)
    (qBase qClone : ℝ) (hqb0 : 0 ≤ qBase) (hqb1 : qBase ≤ 1)
    (hql0 : 0 ≤ qClone) (hql1 : qClone ≤ 1) :
    ∑ draw : HardDraw p N P t C, hardDrawMass b qBase qClone draw = 1 := by
  have hbase : (∑ S : Fin p → BaseDraw N P t, ∏ j, baseDrawMass b qBase (S j)) = 1 := by
    rw [← Fintype.prod_sum]
    simp only [baseDrawMass_total b qBase hqb0 hqb1, Finset.prod_const_one]
  have hclone : (∑ S : Fin p → StageDraw (PaddedPair N) (C × C) C,
      ∏ j, stageDrawMass (allCloneSlots N C) qClone (S j)) = 1 := by
    rw [← Fintype.prod_sum]
    simp only [stageDrawMass_total _ _ hql0 hql1, Finset.prod_const_one]
  rw [Fintype.sum_prod_type]
  simp only [hardDrawMass, ← Finset.mul_sum, hclone, mul_one, hbase]

theorem hardDrawMass_pos_iff [Fintype C] [DecidableEq C] (b : BlueprintExpansion N P t H)
    (qBase qClone : ℝ) (draw : HardDraw p N P t C) :
    0 < hardDrawMass b qBase qClone draw ↔
      (∀ j, 0 < baseDrawMass b qBase (draw.1 j)) ∧
        (∀ j, 0 < stageDrawMass (allCloneSlots N C) qClone (draw.2 j)) := by
  constructor
  · intro hd
    have hne := mul_ne_zero_iff.mp (ne_of_gt hd)
    constructor
    · intro j
      exact lt_of_le_of_ne (baseDrawMass_nonneg b qBase _)
        (Finset.prod_ne_zero_iff.mp hne.1 j (Finset.mem_univ _)).symm
    · intro j
      exact lt_of_le_of_ne (stageDrawMass_nonneg _ _ _)
        (Finset.prod_ne_zero_iff.mp hne.2 j (Finset.mem_univ _)).symm
  · rintro ⟨hb, hl⟩
    exact mul_pos (Finset.prod_pos fun j _ => hb j) (Finset.prod_pos fun j _ => hl j)

def hardOrders (b : BlueprintExpansion N P t H) (baseDraws : Fin p → BaseDraw N P t) :
    Fin p → List (PaddedPair N) :=
  fun j => blueprintBaseOrder b (baseDraws j).1 (baseDraws j).2

def hardStream (b : BlueprintExpansion N P t H) (draw : HardDraw p N P t C) :
    List (HardEdge p N C) :=
  sequentialStream (hardOrders b draw.1) (fun j => (draw.2 j).1)

def hardPublicLabel [Sub C] (pair : PaddedPair N × (C × C)) : C :=
  pair.2.2 - pair.2.1

def hardOracle [Sub C] [DecidableEq C] (unit : ℝ) (draw : HardDraw p N P t C) :
    Finset (HardEdge p N C) → ℝ :=
  mixedOracle unit hardPublicLabel draw.2

def hardLeft (e : HardEdge p N C) : Fin p × (PaddedVertex N × C) :=
  (e.1, e.2.1.1, e.2.2.1)

def hardRight (e : HardEdge p N C) : Fin p × (PaddedVertex N × C) :=
  (e.1, e.2.1.2, e.2.2.2)

def HardMatching (edges : Finset (HardEdge p N C)) : Prop :=
  Set.InjOn hardLeft (edges : Set (HardEdge p N C)) ∧
    Set.InjOn hardRight (edges : Set (HardEdge p N C))

end

end SubmodularMatching.LowerBoundGlobal
