import SubmodularMatching.UpperBoundTrialGuarantee

/-! # Sequential comparison across stored guesses -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler

noncomputable section

variable {A : Type*}

/-- One guess's finite candidate draw. The finite law is a specification of
an individual sampler call, and can be traversed without accumulating a list
of sampled matchings. -/
structure CandidateLaw (A : Type*) where
  outcomes : Finset A
  mass : A → ℝ
  probability : IsProbability outcomes mass

/-- Expected observable after independently drawing and comparing one
candidate from every guess, keeping only the incumbent between draws. -/
def scanExpectation (value : A → ℝ) (step : ℝ) (test : A → ℝ) :
    List (CandidateLaw A) → A → ℝ
  | [], a => test a
  | q :: qs, a => ∑ b ∈ q.outcomes, q.mass b *
      scanExpectation value step test qs (keepBetter value step a b)

def comparisonIndex (value : A → ℝ) (step : ℝ) (a : A) : ℤ := ⌊value a / step⌋

theorem comparisonIndex_le_left (value : A → ℝ) (step : ℝ) (a b : A) :
    comparisonIndex value step a ≤ comparisonIndex value step (keepBetter value step a b) := by
  simp only [comparisonIndex, keepBetter_index, le_max_left]

theorem comparisonIndex_le_right (value : A → ℝ) (step : ℝ) (a b : A) :
    comparisonIndex value step b ≤ comparisonIndex value step (keepBetter value step a b) := by
  simp only [comparisonIndex, keepBetter_index, le_max_right]

theorem scanExpectation_const (value : A → ℝ) (step c : ℝ)
    (qs : List (CandidateLaw A)) (initial : A) :
    scanExpectation value step (fun _ => c) qs initial = c := by
  induction qs generalizing initial with
  | nil => rfl
  | cons q qs ih =>
    simp only [scanExpectation, ih, ← Finset.sum_mul, q.probability.total, one_mul]

/-- Invariants on the incumbent determine an interval for any final
observable. This applies to the true value and to support indicators. -/
theorem scanExpectation_range (value : A → ℝ) (step : ℝ) (test : A → ℝ)
    (valid : A → Prop) (l u : ℝ) (qs : List (CandidateLaw A)) (initial : A)
    (hinit : valid initial)
    (hsupport : ∀ q ∈ qs, ∀ a ∈ q.outcomes, valid a)
    (hvalid : ∀ a, valid a → l ≤ test a ∧ test a ≤ u) :
    l ≤ scanExpectation value step test qs initial ∧
      scanExpectation value step test qs initial ≤ u := by
  induction qs generalizing initial with
  | nil => exact hvalid _ hinit
  | cons q qs ih =>
    unfold scanExpectation
    have hbound (b : A) (hb : b ∈ q.outcomes) :
        l ≤ scanExpectation value step test qs (keepBetter value step initial b) ∧
          scanExpectation value step test qs (keepBetter value step initial b) ≤ u := by
      refine ih _ ?_ (fun s hs => hsupport s (List.mem_cons_of_mem q hs))
      unfold keepBetter
      split_ifs
      · exact hsupport q (List.mem_cons_self) b hb
      · exact hinit
    constructor
    · have h := Finset.sum_le_sum fun b hb => mul_le_mul_of_nonneg_left (hbound b hb).1
        (q.probability.nonnegative b hb)
      simpa only [← Finset.sum_mul, q.probability.total, one_mul] using h
    · have h := Finset.sum_le_sum fun b hb => mul_le_mul_of_nonneg_left (hbound b hb).2
        (q.probability.nonnegative b hb)
      simpa only [← Finset.sum_mul, q.probability.total, one_mul] using h

theorem scanExpectation_retains_index (value : A → ℝ) (step : ℝ) (test : A → ℝ)
    (qs : List (CandidateLaw A)) (initial : A) (i : ℤ) (l : ℝ)
    (hinit : i ≤ comparisonIndex value step initial)
    (hbound : ∀ a, i ≤ comparisonIndex value step a → l ≤ test a) :
    l ≤ scanExpectation value step test qs initial := by
  induction qs generalizing initial with
  | nil => exact hbound _ hinit
  | cons q qs ih =>
    unfold scanExpectation
    have h := Finset.sum_le_sum fun b hb => mul_le_mul_of_nonneg_left
      (ih (keepBetter value step initial b) (hinit.trans (comparisonIndex_le_left value step _ _)))
      (q.probability.nonnegative b hb)
    simpa only [← Finset.sum_mul, q.probability.total, one_mul] using h

theorem value_ge_of_index_ge (value : A → ℝ) (step : ℝ) (hs : 0 < step)
    (a b : A) (h : comparisonIndex value step a ≤ comparisonIndex value step b) :
    value a - step ≤ value b := by
  have hin : (comparisonIndex value step a : ℝ) ≤ comparisonIndex value step b := by
    exact_mod_cast h
  unfold comparisonIndex at hin
  have hh := (div_lt_iff₀ hs).mp (show value a / step < value b / step + 1 by
    linarith [Int.lt_floor_add_one (value a / step), Int.floor_le (value b / step)])
  rw [add_mul, div_mul_cancel₀ _ hs.ne', one_mul] at hh
  linarith

/-- Even if the selected guess is preceded or followed by several other
samplers, its expected true value is lost by at most one grid step. -/
theorem scanExpectation_keeps_candidate (value : A → ℝ) (step : ℝ) (hs : 0 < step)
    (qs : List (CandidateLaw A)) (initial : A) (q : CandidateLaw A) (hq : q ∈ qs) :
    expected q.outcomes q.mass value - step ≤ scanExpectation value step value qs initial := by
  induction qs generalizing initial with
  | nil => simp at hq
  | cons b bs ih =>
    rw [List.mem_cons] at hq
    rcases hq with rfl | hmem
    · unfold scanExpectation
      have h := Finset.sum_le_sum fun a ha => mul_le_mul_of_nonneg_left
        (scanExpectation_retains_index value step value bs (keepBetter value step initial a)
          (comparisonIndex value step a) (value a - step)
          (comparisonIndex_le_right value step _ _) (value_ge_of_index_ge value step hs a))
        (q.probability.nonnegative a ha)
      simpa only [expected, mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul,
        q.probability.total, one_mul] using h
    · unfold scanExpectation
      have h := Finset.sum_le_sum fun a ha => mul_le_mul_of_nonneg_left
        (ih (keepBetter value step initial a) hmem) (b.probability.nonnegative a ha)
      simpa only [← Finset.sum_mul, b.probability.total, one_mul] using h

/-- A singleton whose value is a grid point remains a lower bound on the
returned value throughout the candidate scan. -/
theorem scanExpectation_keeps_reference (value : A → ℝ) (step : ℝ) (hs : 0 < step)
    (qs : List (CandidateLaw A)) (initial : A) (i : ℤ)
    (hi : value initial = step * (i : ℝ)) :
    value initial ≤ scanExpectation value step value qs initial := by
  have hquot : value initial / step = i := by rw [hi, mul_comm, mul_div_cancel_right₀ _ hs.ne']
  apply scanExpectation_retains_index value step value qs initial i _
  · simp [comparisonIndex, hquot]
  · intro a ha
    have hc : (i : ℝ) ≤ comparisonIndex value step a := by exact_mod_cast ha
    exact (div_le_div_iff_of_pos_right hs).1
      (hquot.le.trans (hc.trans (Int.floor_le _)))

end

end SubmodularMatching.UpperBoundAssembly
