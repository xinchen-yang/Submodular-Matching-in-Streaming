import SubmodularMatching.GibbsCoordinateConstant

namespace SubmodularMatching.GibbsMatching

noncomputable def signedRoundingError (ξ : ℝ) : ℝ := min ξ 1 / 8

noncomputable def signedRoundingGamma (ξ : ℝ) : ℝ := 1 - signedRoundingError ξ

noncomputable def signedRoundingRate (ξ : ℝ) : ℝ :=
  signedRoundingGamma ξ / (1 - signedRoundingGamma ξ)^2

noncomputable def signedRoundingCap (ξ : ℝ) : ℝ :=
  let e := signedRoundingError ξ
  let R := signedRoundingRate ξ
  min (e ^ 2) (min e (e / (5 * (1 + R)))) / R

theorem signedRoundingError_bounds (ξ : ℝ) (hξ : 0 < ξ) :
    0 < signedRoundingError ξ ∧ signedRoundingError ξ ≤ 1/8 ∧
      8*signedRoundingError ξ ≤ ξ := by
  have hmin := lt_min hξ zero_lt_one
  have h₁ := min_le_left ξ 1
  have h₂ := min_le_right ξ 1
  unfold signedRoundingError
  exact ⟨by positivity, by linarith, by linarith⟩

theorem signedRoundingGamma_bounds (ξ : ℝ) (hξ : 0 < ξ) :
    0 < signedRoundingGamma ξ ∧ signedRoundingGamma ξ < 1 := by
  obtain ⟨he,hcap,_⟩ := signedRoundingError_bounds ξ hξ
  unfold signedRoundingGamma
  constructor <;> linarith

theorem signedRoundingRate_pos (ξ : ℝ) (hξ : 0 < ξ) : 0 < signedRoundingRate ξ := by
  obtain ⟨hg,hg1⟩ := signedRoundingGamma_bounds ξ hξ
  exact div_pos hg (sq_pos_of_pos (sub_pos.mpr hg1))

theorem signedRoundingCap_pos (ξ : ℝ) (hξ : 0 < ξ) : 0 < signedRoundingCap ξ := by
  have he := (signedRoundingError_bounds ξ hξ).1
  have hR := signedRoundingRate_pos ξ hξ
  exact div_pos (lt_min (sq_pos_of_pos he) (lt_min he (div_pos he (by positivity)))) hR

theorem signedRounding_factor (ξ : ℝ) (hξ : 0 < ξ) :
    let R := signedRoundingRate ξ
    let h := R * signedRoundingCap ξ
    0 ≤ h ∧ h < 1 ∧ 0 ≤ 1 - Real.sqrt (h/2) - 2*h ∧
      1-ξ ≤ (1 - Real.sqrt (h/2) - 2*h) * (1-h) *
        signedRoundingGamma ξ * Real.exp (-(5*(1+R)*h)) := by
  let e := signedRoundingError ξ
  let R := signedRoundingRate ξ
  let h := R * signedRoundingCap ξ
  change 0 ≤ h ∧ h < 1 ∧ _
  obtain ⟨he,he1,heξ⟩ := signedRoundingError_bounds ξ hξ
  change 0 < e at he
  change e ≤ 1/8 at he1
  change 8*e ≤ ξ at heξ
  have hR : 0 < R := signedRoundingRate_pos ξ hξ
  have hh : 0 ≤ h := (mul_pos hR (signedRoundingCap_pos ξ hξ)).le
  have heq : h = min (e^2) (min e (e/(5*(1+R)))) := by
    unfold h signedRoundingCap
    dsimp only
    change R * (_ / R) = _
    field_simp <;> rfl
  have hsmall : h ≤ e^2 := heq ▸ min_le_left _ _
  have hsmall' : h ≤ e := heq ▸ (min_le_right _ _).trans (min_le_left _ _)
  have hK : 5*(1+R)*h ≤ e := by
    have hp : h ≤ e/(5*(1+R)) := heq ▸ (min_le_right _ _).trans (min_le_right _ _)
    nlinarith only [(le_div_iff₀ (show 0 < 5*(1+R) by positivity)).mp hp]
  have hD : Real.sqrt (h/2) ≤ e := Real.sqrt_le_iff.mpr ⟨he.le, by nlinarith [sq_nonneg e]⟩
  have h₀ : 0 ≤ 1-3*e := by linarith
  have h₁ : 1-3*e ≤ 1-Real.sqrt (h/2)-2*h := by linarith
  have h₂ : 1-e ≤ 1-h := by linarith
  have h₃ : 1-e ≤ Real.exp (-(5*(1+R)*h)) := by linarith only [Real.add_one_le_exp (-(5*(1+R)*h)), hK]
  have hγ : 0 ≤ 1-e := by linarith
  refine ⟨hh, by linarith, h₀.trans h₁, ?_⟩
  change 1-ξ ≤ (1-Real.sqrt (h/2)-2*h)*(1-h)*(1-e)*Real.exp (-(5*(1+R)*h))
  have hcube : 1-3*e ≤ (1-e)^3 := by nlinarith only [mul_nonneg (sq_nonneg e) (show 0 ≤ 3-e by linarith)]
  calc
    1-ξ ≤ (1-3*e)*(1-3*e) := by nlinarith only [sq_nonneg e, heξ, he]
    _ ≤ (1-3*e)*(1-e)^3 := mul_le_mul_of_nonneg_left hcube h₀
    _ = (1-3*e)*(1-e)*(1-e)*(1-e) := by ring
    _ ≤ _ := mul_le_mul (mul_le_mul_of_nonneg_right (mul_le_mul h₁ h₂ hγ (h₀.trans h₁)) hγ)
      h₃ hγ (mul_nonneg (mul_nonneg (h₀.trans h₁) (hγ.trans h₂)) hγ)

end SubmodularMatching.GibbsMatching
