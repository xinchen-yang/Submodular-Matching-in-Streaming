import SubmodularMatching.AppendixMNumericalLog10
namespace SubmodularMatching.AppendixM
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
theorem logBlock11 : logBlock 89 8 = true := by decide +kernel
end SubmodularMatching.AppendixM
