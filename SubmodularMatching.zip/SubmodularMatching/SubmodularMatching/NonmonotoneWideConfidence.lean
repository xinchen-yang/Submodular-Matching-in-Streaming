import SubmodularMatching.NonmonotoneWideEstimate

/-! Confidence of the chosen surviving guess under the actual independent word tape. -/
namespace SubmodularMatching.Streaming.OracleQuery
open MeasureTheory UpperBoundAssembly GibbsSampler
noncomputable section
variable {E : Type*} [DecidableEq E]

theorem wide_batch_failure (Q : OracleQuery E) (K J width : ℕ)
    (hK : 0<K) (hJ : 0<J) (hsize : Q.size≤K) (hwidth : Q.size≤width)
    (lo hi d : ℝ) (hd : 0<d) (hw : 0<hi-lo) (hmax : hi-lo ≤ (K:ℝ)*d)
    (hv : ∀ A, A ⊆ (Finset.range Q.size).image Q.edges → lo ≤ Q.evaluate A ∧ Q.evaluate A ≤ hi) :
    let N := batchCount K J
    let bits := batchBits K
    let p := CandidateLaw.ofMeasure (wordBatchLaw N width bits)
    expected p.outcomes p.mass (fun w =>
      if Q.target-d ≤ sourceAverage d (fun r => Q.wordValue bits (prefixBatch hwidth w r)) ∧
        sourceAverage d (fun r => Q.wordValue bits (prefixBatch hwidth w r)) ≤ Q.target+d
      then 0 else 1) ≤ 1/((K:ℝ)*J) := by
  classical
  intro N bits p
  let ok := fun (w : WordBatch N Q.size bits) =>
    Q.target-d ≤ sourceAverage d (fun r => Q.wordValue bits (w r)) ∧
    sourceAverage d (fun r => Q.wordValue bits (w r)) ≤ Q.target+d
  change expected p.outcomes p.mass (fun w => if ok (prefixBatch hwidth w) then 0 else 1) ≤ _
  rw [wordBatch_prefix_expected hwidth (fun w => if ok w then (0:ℝ) else 1)]
  rw [CandidateLaw.ofMeasure_expected]
  have heq : (fun w => if ok w then (0:ℝ) else 1) = Set.indicator {w | ¬ok w} (fun _ => 1) := by
    funext w
    by_cases h : ok w <;> simp [h]
  rw [heq,integral_indicator ((Set.toFinite {w | ¬ok w}).measurableSet),setIntegral_const]
  simp only [smul_eq_mul,mul_one]
  have hN : 0<N := by dsimp [N,batchCount]; omega
  have hk : (0:ℝ)<K := by exact_mod_cast hK
  have hj : (0:ℝ)<J := by exact_mod_cast hJ
  have hbias : (Q.size:ℝ)*(1/(2:ℝ)^bits)*(hi-lo) ≤ d/64 := by
    have ht : (0:ℝ)<(2:ℝ)^bits := by positivity
    have hb : 64*(K:ℝ)^2*d ≤ (2:ℝ)^bits*d :=
      mul_le_mul_of_nonneg_right (batchBits_valid K) hd.le
    have hs : (Q.size:ℝ)≤K := by exact_mod_cast hsize
    have hg := mul_le_mul hs hmax hw.le hk.le
    field_simp [ht.ne']
    nlinarith only [hb,hg]
  refine (word_batch_failure Q N bits lo hi d hN hd hv hbias).trans ?_
  let u := (2*(N:ℝ)*(d/2)^2)/(hi-lo)^2
  have hU : 2*(K:ℝ)*J ≤ u := by
    apply (le_div_iff₀ (sq_pos_of_pos hw)).2
    have hh := mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hw.le hmax 2)
      (show 0 ≤ 2*(K:ℝ)*J by positivity)
    have hN' : (N:ℝ)=4*(K:ℝ)^3*J+1 := by simp [N,batchCount]
    rw [hN']
    nlinarith only [hh,sq_nonneg d]
  have hu : 2*(K:ℝ)*J ≤ Real.exp u :=
    hU.trans ((le_add_of_nonneg_right zero_le_one).trans (Real.add_one_le_exp u))
  change 2*Real.exp (-(2*(N:ℝ)*(d/2)^2)/(hi-lo)^2) ≤ _
  rw [neg_div, ← show u=(2*(N:ℝ)*(d/2)^2)/(hi-lo)^2 from rfl, Real.exp_neg]
  change 2/(Real.exp u) ≤ 1/((K:ℝ)*J)
  exact (div_le_div_iff₀ (Real.exp_pos _) (mul_pos hk hj)).2 (by linarith)

end
end SubmodularMatching.Streaming.OracleQuery

namespace SubmodularMatching.Capacity.WordWindow
open Streaming Streaming.OracleQuery UpperBoundAssembly AppendixM GibbsSampler Finset
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem wide_source_confidence (P : WordWindow E V) (J : ℕ) (hJ : 0<J)
    (hv : 2≤P.v) (hk : P.k≤P.v^2) (hj : P.j<sourceGuessCount P.v) (hf : IsSubmodular P.f) (hn : ∀ A, 0≤P.f A)
    (ha : guessActive (guessWidth P.v) (guessAnchor (guessWidth P.v) (RealOracle.edgeClock P.edges P.f) (P.k+1))
      (singletonMaximum (RealOracle.edgeClock P.edges P.f) (P.k+1)) P.j) (initial : SourceWordTape) :
    let K := sourceWordScale P.v (P.v^2)
    let N := batchCount K J
    let bits := batchBits K
    let G := sourceGuessCount P.v
    let p := RectangularSource.tapeLaw (G*N) (P.v^2) bits (P.wideEstimate N G (P.v^2) bits hj) P.k 0 initial true
    (∑ z ∈ p.outcomes, if z.2 then 0 else p.mass z) ≤ 1/(J:ℝ) ∧
      ∀ z ∈ p.outcomes, z.2=true → P.Good N bits P.calls (P.guessTape N z.1) := by
  classical
  intro K N bits G p
  have hp := sourceWordScale_bounds P.v (P.v^2) P.k hv hk
  have hkp : 0<K := by dsimp [K,sourceWordScale]; positivity
  have eqtau : P.scale = guessAnchor ↑(guessWidth P.v) (RealOracle.edgeClock P.edges P.f) (P.k+1) *
      (2:ℝ)^P.j := by
    dsimp only [scale,RealSource.OnlineEpoch.scale]
    rw [(RealSource.runOnlineEpoch_real _ _ _ _).2]
  have ht : 0<P.scale := eqtau ▸ ha.1.trans_le ha.2.1
  have hv' : (0:ℝ)<P.v := by exact_mod_cast (show 0<P.v by omega)
  have hstream : (0:ℝ)<(streamTolerance:ℚ) := by norm_num [streamTolerance]
  have hgap : 0<P.gap := div_pos (mul_pos hstream ht) (sq_pos_of_pos hv')
  let lo := -((P.k:ℝ)+1)*P.scale
  let hi := P.scale
  have hlo' : lo≤0 := mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr (by positivity)) ht.le
  have hw : 0<hi-lo := sub_pos.mpr (hlo'.trans_lt ht)
  have hks : (P.k:ℝ)+2 ≤ (K:ℝ)*((streamTolerance:ℝ)/(P.v:ℝ)^2) := by
    have hbound := hp.2.2
    push_cast at hbound
    have hh : (P.k:ℝ) ≤ (P.v:ℝ)^2 := by exact_mod_cast hk
    exact (add_le_add_left hh 2).trans hbound
  have hratio : hi-lo ≤ (K:ℝ)*P.gap := by
    calc
      _ = ((P.k:ℝ)+2)*P.scale := by dsimp [hi,lo]; ring
      _ ≤ (K:ℝ)*((streamTolerance:ℝ)/(P.v:ℝ)^2)*P.scale := mul_le_mul_of_nonneg_right hks ht.le
      _ = (K:ℝ)*P.gap := by unfold gap; ring
  have herr (i : ℕ) (hlo : 0 ≤ i) (hhi : i < 0+P.k) (t : SourceWordTape) :
      let d := CandidateLaw.ofMeasure (wordBatchLaw (G*N) (P.v^2) bits)
      expected d.outcomes d.mass (fun w => if P.wideEstimate N G (P.v^2) bits hj i t w then 0 else 1) ≤
        1/((K:ℝ)*J) := by
    have hip : i < P.k := by omega
    by_cases hb : P.b ≤ i
    · let z := P.guessTape N t
      let a := i-P.b
      let Q := P.Q N bits a z
      have hQ : Q.size≤P.k ∧ ∀ A ⊆ (range Q.size).image Q.edges,
          lo≤Q.evaluate A ∧ Q.evaluate A≤hi :=
        RealOracle.active_bank_query_range P.ends P.cap P.positive P.v N bits P.f P.edges
          (tapeDraw z P.b P.j P.other) P.k P.j P.b a (by omega) hf hn ha
      have hh := wide_batch_failure Q K J (P.v^2) hkp hJ (hQ.1.trans hp.1)
        (hQ.1.trans hk) lo hi P.gap hgap hw hratio hQ.2
      have hproj := wordBatch_rows_expected (width:=P.v^2) (bits:=bits) (guessRow (N:=N) hj)
        (fun w => if Q.target-P.gap ≤ sourceAverage P.gap (fun r => Q.wordValue bits (prefixBatch (hQ.1.trans hk) w r)) ∧
          sourceAverage P.gap (fun r => Q.wordValue bits (prefixBatch (hQ.1.trans hk) w r)) ≤ Q.target+P.gap
          then (0:ℝ) else 1)
      have hfin := hproj.trans_le hh
      have inside : P.b ≤ i ∧ i < P.k := ⟨hb,hip⟩
      simpa only [wideEstimate,if_pos inside,a,z,Q,dif_pos (hQ.1.trans hk),decide_eq_true_eq] using hfin
    · have hh : ¬(P.b ≤ i ∧ i < P.k) := fun h => hb h.1
      simp only [wideEstimate,if_neg hh,if_true,expected,mul_zero,sum_const_zero]
      positivity
  refine ⟨?_,?_⟩
  · have hm := RectangularSource.failure_budget (G*N) (P.v^2) bits (P.wideEstimate N G (P.v^2) bits hj)
      P.k 0 initial (1/((K:ℝ)*J)) (by positivity) herr
    have hc : (P.k:ℝ)≤K := by exact_mod_cast hp.1
    have hK : (0:ℝ)<K := by exact_mod_cast hkp
    have hJ' : (0:ℝ)<J := by exact_mod_cast hJ
    apply le_trans _ (hm.trans ?_)
    · apply le_of_eq
      unfold expected
      apply sum_congr rfl
      intro z hz
      rcases z with ⟨t,ok⟩
      cases ok <;> simp [p]
    · field_simp
      nlinarith only [hc, mul_le_mul_of_nonneg_right hc hJ'.le]
  · intro z hz hy
    let inv := fun i t => P.Good N bits (i-P.b) (P.guessTape N t)
    have hs := RectangularSource.tape_support (G*N) (P.v^2) bits (P.wideEstimate N G (P.v^2) bits hj) inv 0 P.k
      (fun i _ hi t ht w hw => P.wideEstimate_good N G (P.v^2) bits hj i hi t ht w hw)
      P.k 0 (by omega) (by omega) initial true (fun _ => by
        intro a ha
        simp at ha) z hz hy
    simpa [inv,calls] using hs

end
end SubmodularMatching.Capacity.WordWindow
