import SubmodularMatching.ProjectedShearerTimeLaw
import SubmodularMatching.ProjectedShearerExposure
import SubmodularMatching.ProjectedShearerScoreCurve

/-! # Time-integrated retention for an actual two-layer Shearer score -/

namespace SubmodularMatching.Shearer

open GibbsMatching AppendixM
open scoped BigOperators Interval

variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable (ends : E → Finset V) (S : Finset E) (Y : E → ℝ)

noncomputable def scaledLayer (width : ℝ) (a : E) := width/degree*Y a
noncomputable def earlierWidth (width t : ℝ) := min (max 0 t) width
noncomputable def earlierRate (width t : ℝ) := earlierWidth width t / width
noncomputable def earlierLayer (width t : ℝ) := scaledLayer Y (earlierWidth width t)

private theorem earlier_pos (w t : ℝ) (hw : 0 ≤ w) : 0 ≤ earlierWidth w t :=
  le_min (le_max_left _ _) hw
private theorem earlier_mono (w : ℝ) : Monotone (earlierWidth w) :=
  fun _ _ h => min_le_min (max_le_max_left _ h) le_rfl
private theorem rate_bounds (w t : ℝ) (hw : 0 < w) : earlierRate w t ∈ Set.Icc 0 1 :=
  ⟨div_nonneg (earlier_pos _ _ hw.le) hw.le, (div_le_one hw).mpr (min_le_right _ _)⟩
private theorem earlier_eq (w t : ℝ) (hw : 0 < w) : earlierLayer Y w t =
    fun a => earlierRate w t * scaledLayer Y w a := by
  funext a
  unfold earlierLayer earlierRate scaledLayer
  field_simp [hw.ne']

private theorem scaledDegree (w : ℝ) (hw : 0 ≤ w)
    (hdeg : ∀ v, ∑ a ∈ incident ends S v, Y a ≤ degree) (v : V) :
    ∑ a ∈ incident ends S v, scaledLayer Y w a ≤ w := by
  have hd : 0 < degree := by norm_num [degree]
  unfold scaledLayer
  rw [← Finset.mul_sum]
  calc
    _ ≤ w / degree * degree := mul_le_mul_of_nonneg_left (hdeg v) (div_nonneg hw hd.le)
    _ = w := div_mul_cancel₀ _ hd.ne'

private theorem scaledInterior (C : Finset E) (hC : C ⊆ S) (w : ℝ) (hw : 0 ≤ w) (hw' : w < 1/4)
    (hY : ∀ e ∈ S, 0 ≤ Y e) (hends : ∀ e ∈ S, (ends e).card = 2)
    (hdeg : ∀ v, ∑ a ∈ incident ends S v, Y a ≤ degree) : InteriorLaw ends C (scaledLayer Y w) := by
  have hr := priorityRoot_probability hw hw'
  have hx : ∀ e ∈ S, 0 ≤ scaledLayer Y w e := fun e he =>
    mul_nonneg (div_nonneg hw (by norm_num [degree])) (hY e he)
  apply interiorLaw_of_degree _ hr.1 hr.2.1 (fun e he => hx e (hC he)) (fun e he => hends e (hC he))
  intro v
  rw [hr.2.2]
  exact (incident_sum_le_of_subset ends C S _ hx hC v).trans (scaledDegree ends S Y w hw hdeg v)

noncomputable def timedScore (C : Finset E) (f : Finset E → ℝ) (own opp t : ℝ) : ℝ :=
  expectation ends C (earlierLayer Y own t) (fun A =>
    expectation ends C (earlierLayer Y opp t) (fun B => f (A ∪ B)))

noncomputable def timedKept (C : Finset E) (f : Finset E → ℝ) (own opp t : ℝ) : ℝ :=
  expectation ends C (earlierLayer Y own t) (fun A =>
    expectation ends S (earlierLayer Y opp t) (fun B => if B ⊆ C then f (A ∪ B) else 0))

private theorem timedScore_swap (C : Finset E) (f : Finset E → ℝ) (own opp t : ℝ) :
    timedScore ends Y C f own opp t = timedScore ends Y C f opp own t := by
  unfold timedScore
  rw [independent_expectation_swap ends C C]
  simp only [Finset.union_comm]

private theorem timedScore_anti (C : Finset E) (hCS : C ⊆ S) (f : Finset E → ℝ) (hf : Antitone f)
    (a b : ℝ) (ha : 0 < a) (hb : 0 < b) (ha' : a < 1/4) (hb' : b < 1/4)
    (hY : ∀ e ∈ S, 0 ≤ Y e) (hends : ∀ e ∈ S, (ends e).card = 2)
    (hdeg : ∀ v, ∑ e ∈ incident ends S v, Y e ≤ degree) : Antitone (timedScore ends Y C f a b) := by
  intro t u htu
  unfold timedScore
  rw [earlier_eq Y a t ha,earlier_eq Y a u ha,earlier_eq Y b t hb,earlier_eq Y b u hb]
  apply mean_score_antitone ends C (scaledLayer Y a) (scaledLayer Y b)
    (scaledInterior ends S Y C hCS a ha.le ha' hY hends hdeg)
    (scaledInterior ends S Y C hCS b hb.le hb' hY hends hdeg)
    (fun _ => earlierRate a t) (fun _ => earlierRate b t) (fun _ => earlierRate a u) (fun _ => earlierRate b u)
    (fun _ => rate_bounds a t ha) (fun _ => rate_bounds b t hb) (fun _ => rate_bounds a u ha)
    (fun _ => rate_bounds b u hb) (fun _ => div_le_div_of_nonneg_right (earlier_mono a htu) ha.le)
    (fun _ => div_le_div_of_nonneg_right (earlier_mono b htu) hb.le) f hf

private theorem timedScore_nonneg (C : Finset E) (hCS : C ⊆ S) (f : Finset E → ℝ) (hf : ∀ A, 0 ≤ f A)
    (a b t : ℝ) (ha : 0 < a) (hb : 0 < b) (ha' : a < 1/4) (hb' : b < 1/4)
    (hY : ∀ e ∈ S, 0 ≤ Y e) (hends : ∀ e ∈ S, (ends e).card = 2)
    (hdeg : ∀ v, ∑ e ∈ incident ends S v, Y e ≤ degree) : 0 ≤ timedScore ends Y C f a b t := by
  have hi (w : ℝ) (hw : 0 < w) (hw' : w < 1/4) : InteriorLaw ends C (earlierLayer Y w t) :=
    scaledInterior ends S Y C hCS _ (earlier_pos w t hw.le) ((min_le_right _ _).trans_lt hw') hY hends hdeg
  unfold timedScore expectation
  exact Finset.sum_nonneg (fun A hA => mul_nonneg ((hi a ha ha').nonneg A hA)
    (Finset.sum_nonneg (fun B hB => mul_nonneg ((hi b hb hb').nonneg B hB) (hf _))))

private theorem timedKept_bound (u v : V) (f : Finset E → ℝ) (hf : ∀ A, 0 ≤ f A)
    (own opp t : ℝ) (ho : 0 ≤ own) (ho' : own < 1/4) (hp : 0 ≤ opp) (hp' : opp < 1/4)
    (hY : ∀ e ∈ S, 0 ≤ Y e) (hends : ∀ e ∈ S, (ends e).card = 2)
    (hdeg : ∀ v, ∑ e ∈ incident ends S v, Y e ≤ degree) :
    let C := outsideEndpoints ends S u v
    priorityRoot (earlierWidth opp t)^2 * timedScore ends Y C f own opp t ≤
      timedKept ends S Y C f own opp t := by
  intro C
  have hown := scaledInterior ends S Y C (outsideEndpoints_subset ends S u v) (earlierWidth own t)
    (earlier_pos own t ho) ((min_le_right _ _).trans_lt ho') hY hends hdeg
  have hr := priorityRoot_probability (earlier_pos opp t hp) ((min_le_right _ _).trans_lt hp')
  have hyp : ∀ e ∈ S, 0 ≤ earlierLayer Y opp t e := fun e he =>
    mul_nonneg (div_nonneg (earlier_pos opp t hp) (by norm_num [degree])) (hY e he)
  unfold timedScore timedKept
  rw [← expectation_const_mul]
  apply Finset.sum_le_sum
  intro A hA
  apply mul_le_mul_of_nonneg_left _ (hown.nonneg A hA)
  have h := priority_expected_score ends S (earlierLayer Y opp t) _ hr.1 hr.2.1 hyp hends
    (fun v => (scaledDegree ends S Y _ (earlier_pos opp t hp) hdeg v).trans hr.2.2.ge) u v
    (fun B => f (A ∪ B)) (fun B => hf _)
  dsimp only at h
  rw [expectation_restriction ends S _ _ (outsideEndpoints_subset ends S u v) (fun B => f (A ∪ B))] at h
  exact h

private theorem continuous_expectation (C : Finset E) (x : ℝ → E → ℝ) (hx : ∀ e, Continuous (fun t => x t e))
    (g : ℝ → Finset E → ℝ) (hg : ∀ M, Continuous (fun t => g t M)) :
    Continuous (fun t => expectation ends C (x t) (g t)) := by
  unfold expectation
  apply continuous_finset_sum
  intro M hM
  simp only [mass_of_mem ends C _ M hM,weight,signedPartition,partition]
  fun_prop (disch := assumption)

private theorem timedKept_continuous (C : Finset E) (f : Finset E → ℝ) (own opp : ℝ) :
    Continuous (timedKept ends S Y C f own opp) := by
  have hx (w : ℝ) (e : E) : Continuous (fun t => earlierLayer Y w t e) := by
    unfold earlierLayer scaledLayer earlierWidth
    fun_prop
  apply continuous_expectation ends C _ (hx own)
  intro A
  apply continuous_expectation ends S _ (hx opp)
  intro B
  exact continuous_const

/-- Both conditional surviving-score curves are derived from the native
full and outside Shearer laws. At the two actual layer widths their sum
of time integrals dominates `gamma` times the common score integral. -/
theorem two_layer_timed_retention (u v : V) (f : Finset E → ℝ) (hf : Antitone f) (hf0 : ∀ A, 0 ≤ f A)
    (hY : ∀ e ∈ S, 0 ≤ Y e) (hends : ∀ e ∈ S, (ends e).card = 2)
    (hdeg : ∀ w, ∑ e ∈ incident ends S w, Y e ≤ degree) :
    let C := outsideEndpoints ends S u v
    let m := timedScore ends Y C f layerOne layerTwo
    gamma * ((∫ t in (0:ℝ)..layerOne, m t) + (∫ t in (0:ℝ)..layerTwo, m t)) ≤
      (∫ t in (0:ℝ)..layerOne, timedKept ends S Y C f layerOne layerTwo t) +
      (∫ t in (0:ℝ)..layerTwo, timedKept ends S Y C f layerTwo layerOne t) := by
  intro C m
  obtain ⟨ha,ha',hb,hba⟩ := layerDegrees
  have hb' := hba.trans ha'
  have hCS := outsideEndpoints_subset ends S u v
  apply two_layer_score_integral m _ _ (timedScore_anti ends S Y C hCS f hf _ _ ha hb ha' hb' hY hends hdeg)
    (fun t => timedScore_nonneg ends S Y C hCS f hf0 _ _ t ha hb ha' hb' hY hends hdeg)
  · intro t ht
    simpa only [timeSurvival,m,earlierWidth,max_eq_right ht.1] using
      timedKept_bound ends S Y u v f hf0 layerOne layerTwo t ha.le ha' hb.le hb' hY hends hdeg
  · intro t ht
    rw [show m t = timedScore ends Y C f layerTwo layerOne t from timedScore_swap ends Y C f _ _ t]
    simpa only [timeSurvival,earlierWidth,max_eq_right ht.1,min_eq_left ht.2,min_eq_left (ht.2.trans hba.le)] using
      timedKept_bound ends S Y u v f hf0 layerTwo layerOne t hb.le hb' ha.le ha' hY hends hdeg
  · exact (timedKept_continuous ends S Y C f _ _).intervalIntegrable _ _
  · exact (timedKept_continuous ends S Y C f _ _).intervalIntegrable _ _

end SubmodularMatching.Shearer
