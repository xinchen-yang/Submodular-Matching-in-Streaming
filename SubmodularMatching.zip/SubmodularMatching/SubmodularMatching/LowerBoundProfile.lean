import Mathlib.Data.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

/-!
# Scalar recurrence in the lower-bound profile lemma

The paper bounds the residual objective after distinguished-label and excess
edges are removed by `V_C = c + (1-c/C)V_(C-1)`. This file checks that
recurrence and its bound for all numbers of stages. It does not formalize the
graph construction, deletion argument, entropy bound, or streaming lower bound.
-/

namespace SubmodularMatching.LowerBoundProfile

noncomputable section

/-- Worst-case suffix recurrence with at most `c` normalized edges per stage. -/
def profile (c : ℝ) : ℕ → ℝ
  | 0 => 0
  | n + 1 => c + (1 - c / (n + 1 : ℝ)) * profile c n

theorem coefficient_nonnegative {c : ℝ} (hc : c ≤ 1) (n : ℕ) :
    0 ≤ 1 - c / (n + 1 : ℝ) := by
  have hn : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  have hp : (0 : ℝ) < n + 1 := by linarith
  apply sub_nonneg.mpr
  apply (div_le_iff₀ hp).mpr
  linarith

theorem profile_nonnegative {c : ℝ} (hc0 : 0 ≤ c) (hc1 : c ≤ 1) (n : ℕ) :
    0 ≤ profile c n := by
  induction n with
  | zero => simp [profile]
  | succ n ih =>
    exact add_nonneg hc0 (mul_nonneg (coefficient_nonnegative hc1 n) ih)

/-- The scalar induction used in the paper's lower-bound profile lemma. -/
theorem profile_bound {c : ℝ} (hc0 : 0 ≤ c) (hc1 : c ≤ 1) (n : ℕ) :
    profile c n ≤ c * (n + 1 : ℝ) / (1 + c) := by
  have hd : 0 < 1 + c := by linarith
  induction n with
  | zero =>
    simpa [profile] using div_nonneg hc0 hd.le
  | succ n ih =>
    have hn : (0 : ℝ) < n + 1 := by
      have hnat : (0 : ℝ) ≤ n := Nat.cast_nonneg n
      linarith
    calc
      profile c (n + 1) = c + (1 - c / (n + 1 : ℝ)) * profile c n := rfl
      _ ≤ c + (1 - c / (n + 1 : ℝ)) * (c * (n + 1 : ℝ) / (1 + c)) :=
        add_le_add (le_refl c) (mul_le_mul_of_nonneg_left ih (coefficient_nonnegative hc1 n))
      _ = c * ((n + 1 : ℕ) + 1 : ℝ) / (1 + c) := by
        simp only [Nat.cast_add, Nat.cast_one]
        field_simp [ne_of_gt hn, ne_of_gt hd]
        ring

/-- Any objective values dominated step by step by the recurrence obey the
same profile. The hypotheses expose the precise recurrence obligation. -/
theorem of_step_bound {c : ℝ} (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (V : ℕ → ℝ) (hzero : V 0 ≤ 0)
    (hstep : ∀ n, V (n + 1) ≤ c + (1 - c / (n + 1 : ℝ)) * V n)
    (n : ℕ) : V n ≤ c * (n + 1 : ℝ) / (1 + c) := by
  have hdom : ∀ k, V k ≤ profile c k := by
    intro k
    induction k with
    | zero => exact hzero
    | succ k ih =>
      exact (hstep k).trans
        (add_le_add (le_refl c) (mul_le_mul_of_nonneg_left ih (coefficient_nonnegative hc1 k)))
  exact (hdom n).trans (profile_bound hc0 hc1 n)

/-- At half a unit per stage, the residual profile is at most `(n+1)/3`. -/
theorem half_profile_bound (n : ℕ) :
    profile (1 / 2) n ≤ (n + 1 : ℝ) / 3 := by
  have h := profile_bound (c := 1 / 2) (by norm_num) (by norm_num) n
  convert h using 1
  ring

end

end SubmodularMatching.LowerBoundProfile
