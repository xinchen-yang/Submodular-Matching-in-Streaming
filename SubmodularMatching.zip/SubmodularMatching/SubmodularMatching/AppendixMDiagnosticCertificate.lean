import SubmodularMatching.AppendixMDiagnostics.M11
import SubmodularMatching.AppendixMDiagnostics.M10
import SubmodularMatching.AppendixMDiagnostics.M00
import SubmodularMatching.AppendixMDiagnostics.M01

namespace SubmodularMatching.AppendixM.Diagnostics

/-- The four reported diagnostic floors hold at every price and every ratio in each original mode. -/
theorem equation26_diagnostic (m : ℕ) (hm : m < 27648) (i j : Bool) (c : ℝ)
    (hcL : (rescaledRateTable.boundary m : ℝ) ≤ c) (hcH : c ≤ (rescaledRateTable.boundary (m+1) : ℝ))
    (a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d) :
    alpha + (slackMicro i j : ℝ)/1000000 + beta*(SourceCertificate.unmatched i*rescaledRateTable.high m +
       SourceCertificate.unmatched j*rescaledRateTable.low m) ≤
      localValue i j (rescaledRateTable.high m) (rescaledRateTable.low m) c a d := by
  have h : Range i j 0 27648 := by
    cases i <;> cases j
    · exact full00
    · exact full01
    · exact full10
    · exact full11
  exact h m (Nat.zero_le _) hm c hcL hcH a d ha hd

end SubmodularMatching.AppendixM.Diagnostics
