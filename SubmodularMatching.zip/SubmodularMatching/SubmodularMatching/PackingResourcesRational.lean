import SubmodularMatching.PackingResources

/-!
# Common grid for rational packing accuracy

The optimizer uses a fixed rational accuracy, potentially with an odd
denominator. A direct rational grid proves the numeric representation
invariant for exactly the optimizer already formalized.
-/

open scoped BigOperators

namespace SubmodularMatching.LinearPacking

noncomputable section

variable {Row Col : Type*} [Fintype Row] [Fintype Col]

/-- If the fixed solver accuracy is `a/b`, then this denominator works
for every coefficient vector and every packing direction. -/
def rationalOutputDenominator (M N a b : ℕ) : ℕ :=
  iterationCount M N ((a : ℝ) / b) * (2 * N * b + a)

theorem solve_rational_output_grid (A : Row → Col → ℝ) (c : Col → ℝ) (a b : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hab : a ≤ b) (hM : 0 < Fintype.card Row)
    (hN : 0 < Fintype.card Col) (i : Col) :
    OnGrid (rationalOutputDenominator (Fintype.card Row) (Fintype.card Col) a b)
      (solve A c ((a : ℝ) / b) i) := by
  let M := Fintype.card Row
  let N := Fintype.card Col
  let epsilon := (a : ℝ) / b
  let J := iterationCount M N epsilon
  let η := stepSize M N epsilon
  obtain ⟨k, _, hk⟩ := accumulated_action_numerator A c (radius N epsilon) η J i
  refine ⟨(k : ℤ) * (2 * (N : ℤ) * b), ?_⟩
  have ha' : (0 : ℝ) < a := by exact_mod_cast ha
  have hb' : (0 : ℝ) < b := by exact_mod_cast hb
  have he : 0 < epsilon := div_pos ha' hb'
  have he1 : epsilon ≤ 1 := (div_le_one hb').mpr (by exact_mod_cast hab)
  have hJ : 0 < J := (concrete_parameters M N epsilon hM hN he he1).2.2.1
  have hJr : (0 : ℝ) < J := by exact_mod_cast hJ
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  change ((J * (2 * N * b + a) : ℕ) : ℝ) *
    (((∑ j ∈ Finset.range J, action A c (dual A c (radius N epsilon) η j) i) / J) /
      (1 + rescaling N epsilon)) = _
  rw [hk, rescaling]
  push_cast
  dsimp [epsilon]
  field_simp

theorem iterate_rational_output_grid (A : Row → Col → ℝ)
    (coeff : ℕ → (Col → ℝ) → Col → ℝ) (a b K j : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hab : a ≤ b) (hM : 0 < Fintype.card Row)
    (hN : 0 < Fintype.card Col) (i : Col) :
    OnGrid (K * rationalOutputDenominator (Fintype.card Row) (Fintype.card Col) a b)
      (iterate A coeff ((a : ℝ) / b) K j i) := by
  by_cases hK : K = 0
  · subst K
    exact ⟨0, by simp⟩
  have hK' : (K : ℝ) ≠ 0 := by exact_mod_cast hK
  induction j with
  | zero => exact OnGrid.zero _
  | succ j ih =>
    rw [iterate]
    exact ih.add ((show OnGrid K (1 / (K : ℝ)) from ⟨1, by simp [hK']⟩).mul
      (solve_rational_output_grid A _ a b ha hb hab hM hN i))

/-- A real dual step with accuracy `a / b` is on the fixed grid
`2 b M N² Q`, and its numerator never exceeds that denominator times
the clipping radius. -/
theorem solve_rational_dual_index_bound (A : Row → Col → ℝ) (c : Col → ℝ)
    (Q a b : ℕ) (hM : 0 < Fintype.card Row) (hN : 0 < Fintype.card Col) (hb : 0 < b)
    (hA : ∀ h i, OnGrid Q (A h i)) (j : ℕ) (h : Row) :
    let M := Fintype.card Row
    let N := Fintype.card Col
    let epsilon := (a : ℝ) / b
    let P := 2 * b * M * N ^ 2 * Q
    let R := Nat.ceil (4 * (N : ℝ) ^ 2 / epsilon)
    ∃ k : ℕ, k ≤ P * R ∧ (P : ℝ) * dual A c R (stepSize M N epsilon) j h = k := by
  intro M N epsilon P R
  have hstep : OnGrid (2 * b * M * N ^ 2) (stepSize M N epsilon) := by
    refine ⟨a, ?_⟩
    unfold stepSize
    dsimp [epsilon]
    push_cast
    have hb' : (0 : ℝ) < b := by exact_mod_cast hb
    have hM' : (0 : ℝ) < M := by exact_mod_cast hM
    have hN' : (0 : ℝ) < N := by exact_mod_cast hN
    field_simp
  have hgrid := dual_grid A c Q _ R _ hA hstep j h
  have hbounded := dual_bounds A c (eta := stepSize M N epsilon) (Nat.cast_nonneg R) j h
  exact OnGrid.bounded_numerator hgrid hbounded.1 hbounded.2

end

end SubmodularMatching.LinearPacking
