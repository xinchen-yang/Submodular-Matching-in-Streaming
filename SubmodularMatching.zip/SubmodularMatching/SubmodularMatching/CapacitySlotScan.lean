import SubmodularMatching.CapacityOnlineSlots
import SubmodularMatching.StreamingOnlineInstance

/-! # Constant-counter integer scans for the least minimum of a sparse slot table -/

namespace SubmodularMatching.Capacity
open Streaming

/-- A tail-recursive scan; equal entries keep the earlier index. -/
def scanIndex (values : ℕ → ℕ) (best next : ℕ) : ℕ → ℕ
  | 0 => best
  | todo+1 => scanIndex values (if values next < values best then next else best) (next+1) todo

theorem scanIndex_spec (values : ℕ → ℕ) (best next todo : ℕ) (hb : best < next)
    (h : ∀ j < next, values best ≤ values j ∧ (values best = values j → best ≤ j)) :
    let r := scanIndex values best next todo
    r < next+todo ∧ ∀ j < next+todo, values r ≤ values j ∧ (values r = values j → r ≤ j) := by
  induction todo generalizing best next with
  | zero => exact ⟨hb,h⟩
  | succ todo ih =>
    by_cases hn : values next < values best
    · have H (j : ℕ) (hj : j < next+1) : values next ≤ values j ∧
          (values next = values j → next ≤ j) := by
        rcases Nat.eq_or_lt_of_le (Nat.le_of_lt_succ hj) with rfl|hj
        · exact ⟨le_rfl,fun _ => le_rfl⟩
        · have hlt := hn.trans_le (h j hj).1
          exact ⟨hlt.le,fun he => (hlt.ne he).elim⟩
      simpa only [scanIndex,if_pos hn,Nat.add_right_comm,Nat.add_assoc,Nat.add_left_comm]
        using ih next (next+1) (by omega) H
    · have H (j : ℕ) (hj : j < next+1) : values best ≤ values j ∧
          (values best = values j → best ≤ j) := by
        rcases Nat.eq_or_lt_of_le (Nat.le_of_lt_succ hj) with rfl|hj
        · exact ⟨Nat.le_of_not_gt hn,fun _ => hb.le⟩
        · exact h j hj
      simpa only [scanIndex,if_neg hn,Nat.add_right_comm,Nat.add_assoc,Nat.add_left_comm]
        using ih best (next+1) (by omega) H

private theorem scanned_spec (b : ℕ) (hb : 0 < b) (p : ℕ → ℕ) :
    let r := scanIndex p 0 1 (b-1)
    r < b ∧ ∀ j < b, p r ≤ p j ∧ (p r = p j → r ≤ j) := by
  have h := scanIndex_spec p 0 1 (b-1) (by omega) (fun j hj => by
    have : j = 0 := by omega
    subst j
    exact ⟨le_rfl,fun _ => le_rfl⟩)
  simpa only [show 1+(b-1)=b by omega] using h

variable {V E : Type*} [DecidableEq V]

def slotIndex (cap : V → ℕ) (entries : List (BSlot cap × ℕ)) (v : V) (i : ℕ) :=
  if h : i < cap v then indexAt entries ⟨v,⟨i,h⟩⟩ else 0

def sparseMinimum (cap : V → ℕ) (entries : List (BSlot cap × ℕ)) (v : V) (hv : 0 < cap v) :
    Fin (cap v) :=
  ⟨scanIndex (slotIndex cap entries v) 0 1 (cap v-1),
    (scanned_spec _ hv (slotIndex cap entries v)).1⟩

theorem sparseMinimum_spec (cap : V → ℕ) (entries : List (BSlot cap × ℕ)) (v : V) (hv : 0 < cap v) :
    let q := fun i : Fin (cap v) => indexAt entries (⟨v,i⟩ : BSlot cap)
    let r := sparseMinimum cap entries v hv
    (∀ i, q r ≤ q i) ∧ ∀ i, (∀ j, q i ≤ q j) → r ≤ i := by
  intro q r
  have h := (scanned_spec _ hv (slotIndex cap entries v)).2
  have hf (i : Fin (cap v)) : slotIndex cap entries v i.val = q i := by
    simp [slotIndex,i.isLt,q]
  have he (i : Fin (cap v)) : q r ≤ q i ∧ (q r = q i → r ≤ i) := by
    have hi := h i.val i.isLt
    change slotIndex cap entries v r.val ≤ _ ∧ (slotIndex cap entries v r.val = _ → r.val ≤ i.val) at hi
    simpa only [hf] using hi
  exact ⟨fun i => (he i).1,fun i hi => (he i).2 (le_antisymm (he i).1 (hi r))⟩

theorem sparseMinimum_eq_real [DecidableEq E] (cap : V → ℕ) (C : PotentialConfig)
    (st : OnlineInstance E (BSlot cap)) (s : PotentialState E (BSlot cap)) (h : st.Represents C s)
    (v : V) (hv : 0 < cap v) :
    sparseMinimum cap st.vertices v hv = leastSlot _ (fun j => s.potential ⟨v,j⟩) hv := by
  let p := fun j : Fin (cap v) => indexAt st.vertices (⟨v,j⟩ : BSlot cap)
  let q := fun j : Fin (cap v) => s.potential (⟨v,j⟩ : BSlot cap)
  have he (i j : Fin (cap v)) : p i ≤ p j ↔ q i ≤ q j := by
    simp only [p,q,← h.potential,mul_le_mul_iff_right₀ C.grid_pos,Nat.cast_le]
  have hi := sparseMinimum_spec cap st.vertices v hv
  have hj := leastSlot_spec _ q hv
  exact le_antisymm (hi.2 _ (fun j => (he _ j).mpr (hj.1 j)))
    (hj.2 _ (fun j => (he _ j).mp (hi.1 j)))

end SubmodularMatching.Capacity
