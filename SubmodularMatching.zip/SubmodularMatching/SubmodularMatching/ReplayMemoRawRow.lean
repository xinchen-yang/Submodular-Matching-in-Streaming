import SubmodularMatching.ReplayRatePacked

/-! # Checked unpacking of the source rate table

Each word lookup supplies sixteen rows. A checked word equality is shared
by its sixteen literal row definitions.
-/

namespace SubmodularMatching.SourceCertificate.Replay

structure RawRateTriple where
  high : Nat
  low : Nat
  boundary : Nat

def unpackRateWord (word index : Nat) : RawRateTriple :=
  let row := word >>> (126 * index)
  ⟨row &&& 4398046511103, (row >>> 42) &&& 4398046511103,
    (row >>> 84) &&& 4398046511103⟩

structure VerifiedRawRow (k : Nat) where
  data : RawRateTriple
  sourceTriple : unpackRateWord (rateWord (k / 16)) (k % 16) = data

def VerifiedRawRow.ofWord (index word : Nat) (row : RawRateTriple)
    (lookup : rateWord (index / 16) = word)
    (unpack : unpackRateWord word (index % 16) = row) : VerifiedRawRow index :=
  ⟨row, lookup ▸ unpack⟩

end SubmodularMatching.SourceCertificate.Replay
