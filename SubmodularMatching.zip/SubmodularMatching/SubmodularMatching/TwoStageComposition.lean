import SubmodularMatching.GibbsSmallCoordinates
import SubmodularMatching.ShearerRounding
import SubmodularMatching.ResidualObjective

/-!
# Composing the two actual matching laws with Lemma 3.2

The inner law is the calibrated Gibbs distribution for the residual objective.
The outer law is the explicit Shearer distribution. The value comparison is
proved from these laws, with the alteration's coordinate-retention property
exposed as its input.
-/

open scoped BigOperators

namespace SubmodularMatching.TwoStage

open GibbsMatching (replacementPrefix)

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem conditioned_submodular (f : Finset E → ℝ) (hf : IsSubmodular f) (T : Finset E) :
    IsSubmodular (fun B => f (T ∪ B) - f T) := by
  intro A B
  have hu : (T ∪ A) ∪ (T ∪ B) = T ∪ (A ∪ B) := by
    ext e
    simp only [Finset.mem_union]
    tauto
  have hi : (T ∪ A) ∩ (T ∪ B) = T ∪ (A ∩ B) := by
    ext e
    simp only [Finset.mem_union, Finset.mem_inter]
    tauto
  have h := hf (T ∪ A) (T ∪ B)
  rw [hu, hi] at h
  dsimp
  linarith

theorem conditioned_monotone (f : Finset E → ℝ) (hm : IsMonotone f) (T : Finset E) :
    IsMonotone (fun B => f (T ∪ B) - f T) := by
  intro A B hAB
  exact sub_le_sub_right (hm _ _ (Finset.union_subset_union (Finset.Subset.refl T) hAB)) _

/-- The actual conditional expected objective after the second matching draw. -/
noncomputable def conditionalValue (ends : E → Finset V) (S : Finset E)
    (z : Finset E → E → ℝ) (ε : ℝ) (f : Finset E → ℝ) (T : Finset E) : ℝ :=
  GibbsMatching.expectation ends S
    (GibbsMatching.calibratedActivity ends S (z T) (1 - ε / 4))
    (fun N => f (T ∪ N))

/-- Lemma 3.2 and the actual Gibbs rounding law give the conditional value bound. -/
theorem conditional_value_lower_bound [Finite V]
    (ends : E → Finset V) (S : Finset E) (z : Finset E → E → ℝ)
    (ε p : ℝ) (he0 : 0 < ε) (he1 : ε < 1) (hp : 0 ≤ p) (hp1 : p ≤ 1)
    (hcap : p ≤ ε ^ 5 / 5120)
    (stored : ℕ → E) (n : ℕ)
    (hmem : ∀ i < n, stored i ∈ S) (hcover : S ⊆ replacementPrefix stored n)
    (hdistinct : ∀ i < n, ∀ j < n, stored i = stored j → i = j)
    (hends : ∀ e ∈ S, (ends e).card = 2) (hsimple : Set.InjOn ends (S : Set E))
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0)
    (wh : ℕ → ℝ) (hwh : ∀ i < n, wh i ≤ arrivalWeight stored p f i)
    (T : Finset E)
    (hz : ∀ e ∈ S, 0 ≤ z T e ∧ z T e ≤ p)
    (hdegree : ∀ v, GibbsMatching.vertexLoad ends S (z T) v ≤ 1) :
    (1 - ε) * (residualValue stored p f n T +
      ∑ i ∈ Finset.range n, wh i * z T (stored i)) ≤ conditionalValue ends S z ε f T := by
  have hround := GibbsMatching.gibbs_epsilon_rounding ends S (z T)
    (fun e he => (hz e he).1) hdegree hends hsimple ε he0 he1
    (fun e he => ((hz e he).2).trans hcap) stored n hmem hcover hdistinct
    (fun N => f (T ∪ N) - f T) (conditioned_submodular f hf T)
    (conditioned_monotone f hm T) (by simp)
  have ha := GibbsMatching.calibratedActivity_nonnegative ends S (z T)
    (fun e he => (hz e he).1) hdegree (1 - ε / 4) (by linarith) (by linarith)
  rw [GibbsMatching.expectation_sub, GibbsMatching.expectation_const ends S _ ha] at hround
  have hhistory := lemma_3_2 stored p (fun i => z T (stored i)) wh f hf hm hzero hp hp1 n
    (fun i hi => hz _ (hmem i hi)) hwh T
  have hscaled := mul_le_mul_of_nonneg_left hhistory (show 0 ≤ 1 - ε by linarith)
  have hT : 0 ≤ f T := by simpa only [hzero] using hm ∅ T (Finset.empty_subset T)
  change (1 - ε) * residualMultilinear stored (fun i => z T (stored i)) f n T ≤
    conditionalValue ends S z ε f T - f T at hround
  nlinarith [mul_nonneg he0.le hT]

theorem shearer_expectation_sum {I : Type*} (ends : E → Finset V)
    (A : Finset E) (y : E → ℝ) (s : Finset I) (F : I → Finset E → ℝ) :
    Shearer.expectation ends A y (fun T => ∑ i ∈ s, F i T) =
      ∑ i ∈ s, Shearer.expectation ends A y (F i) := by
  unfold Shearer.expectation
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]

/-- GJ5 for the actual two-stage finite probability law. The remaining
input is the coordinate retention supplied by the explicit alteration. -/
theorem two_stage_value [Finite V]
    (ends : E → Finset V) (S A : Finset E) (y x : E → ℝ)
    (z : Finset E → E → ℝ) (r ε p κ : ℝ)
    (hr0 : 0 < r) (hr1 : r ≤ 1) (he0 : 0 < ε) (he1 : ε < 1)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (hcap : p ≤ ε ^ 5 / 5120)
    (hy : ∀ e ∈ A, 0 ≤ y e)
    (hAends : ∀ e ∈ A, (ends e).card = 2)
    (hydegree : ∀ v, (∑ e ∈ GibbsMatching.incident ends A v, y e) ≤ r * (1 - r))
    (stored : ℕ → E) (n : ℕ)
    (hmem : ∀ i < n, stored i ∈ S) (hcover : S ⊆ replacementPrefix stored n)
    (hdistinct : ∀ i < n, ∀ j < n, stored i = stored j → i = j)
    (hSends : ∀ e ∈ S, (ends e).card = 2) (hsimple : Set.InjOn ends (S : Set E))
    (active : ℕ → E) (m : ℕ)
    (hAmem : ∀ i < m, active i ∈ A) (hAcover : A ⊆ replacementPrefix active m)
    (hAdistinct : ∀ i < m, ∀ j < m, active i = active j → i = j)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0)
    (wh : ℕ → ℝ) (hwh0 : ∀ i < n, 0 ≤ wh i)
    (hwh : ∀ i < n, wh i ≤ arrivalWeight stored p f i)
    (hz : ∀ T ∈ GibbsMatching.matchings ends A, ∀ e ∈ S, 0 ≤ z T e ∧ z T e ≤ p)
    (hdegree : ∀ T ∈ GibbsMatching.matchings ends A, ∀ v,
      GibbsMatching.vertexLoad ends S (z T) v ≤ 1)
    (hretention : ∀ e ∈ S, κ * x e ≤ Shearer.expectation ends A y (fun T => z T e)) :
    (1 - ε) * (bernoulliExpectation active (fun i => y (active i))
        (residualValue stored p f n) m + κ * ∑ i ∈ Finset.range n, wh i * x (stored i)) ≤
      Shearer.expectation ends A y (conditionalValue ends S z ε f) := by
  have hpoint := Shearer.expectation_mono ends A y r hr0 hr1 hy hAends hydegree
    (fun T => (1 - ε) * (residualValue stored p f n T +
      ∑ i ∈ Finset.range n, wh i * z T (stored i))) (conditionalValue ends S z ε f)
    (fun T hT => conditional_value_lower_bound ends S z ε p he0 he1 hp hp1 hcap
      stored n hmem hcover hdistinct hSends hsimple f hf hm hzero wh hwh T
      (hz T hT) (hdegree T hT))
  rw [Shearer.expectation_const_mul, Shearer.expectation_add, shearer_expectation_sum] at hpoint
  have hres := Shearer.submodular_comparison ends A y r hr0 hr1 hy hAends hydegree
    active m hAmem hAcover hAdistinct (residualValue stored p f n)
    (residualValue_submodular stored p f hf hp hp1 n)
  have hsum : κ * (∑ i ∈ Finset.range n, wh i * x (stored i)) ≤
      ∑ i ∈ Finset.range n, Shearer.expectation ends A y (fun T => wh i * z T (stored i)) := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i hi
    have hin := Finset.mem_range.mp hi
    rw [Shearer.expectation_const_mul]
    have h := mul_le_mul_of_nonneg_left (hretention _ (hmem i hin)) (hwh0 i hin)
    nlinarith only [h]
  exact (mul_le_mul_of_nonneg_left (add_le_add hres hsum)
    (show 0 ≤ 1 - ε by linarith)).trans hpoint

end SubmodularMatching.TwoStage
