import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextLeft

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step56 : ProjectedGoal ⟨216, 323, 0, 17, 567, 638⟩ :=
  projectedGoal_chunk _ (.x (.leaf 0x14300d800e8d4a51059b3b8) (.y (.leaf 0x14300d8e8d4a5100059d59c) (.y (.y (.y (.leaf 0x14300d801d1a94a2059e4fb) (.m (.m (.leaf 0xf200d8000000000059f4f7) (.m (.leaf 0x10000f3000000000059f4f7) (.leaf 0x10d01010001d1a94a5a04fc))) (.m (.m (.m (.m (.leaf 0x111010e000746a5285a14fc) (.m (.leaf 0x1130112001d1a94a25a14fc) (.leaf 0x1140114001d1a94a25a14fc))) (.m (.y (.leaf 0x118011500e8d4a5105a24fb) (.y (.m (.leaf 0x1160115001d1a94a25a34fc) (.leaf 0x1180117001d1a94a25a34fc)) (.leaf 0x118011500000000005a44f7))) (.leaf 0x11b0119001d1a94a25a14fc))) (.y (.leaf 0x128011c00e8d4a5105a24fb) (.y (.m (.m (.leaf 0x11f011c001d1a94a25a34fc) (.leaf 0x1220120001d1a94a25a34fc)) (.leaf 0x1280123002ba7def35a34fc)) (.leaf 0x128011c00000000005a44f7)))) (.y (.leaf 0x143012900e8d4a5105a24fb) (.m (.y (.m (.leaf 0x12f0129002ba7def35a34fc) (.leaf 0x1360130002ba7def35a34fc)) (.leaf 0x136012900000000005a44f7)) (.m (.leaf 0x13d0137002ba7def35a54fc) (.leaf 0x143013e002ba7def35a54fc))))))) (.leaf 0x14300d800000000005a64f7)) (.leaf 0x14300d800000000005a74f7)))) (by decide +kernel)

theorem Part00007 : ProjectedGoal ⟨216, 323, 0, 17, 567, 638⟩ := step56

end SubmodularMatching.SourceCertificate.Replay.HardNextLeft
