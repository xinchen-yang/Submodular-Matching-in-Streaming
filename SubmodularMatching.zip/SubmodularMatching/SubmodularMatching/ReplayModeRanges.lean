import SubmodularMatching.CertificateIntegerBox
import Mathlib.Data.List.GetD

/-! # Exact source-rate and boundary bounds on an endpoint interval -/

namespace SubmodularMatching.SourceCertificate.Replay

def allIndexed (f : ℕ → α → Bool) : ℕ → List α → Bool
  | _, [] => true
  | k, v :: vs => f k v && allIndexed f (k+1) vs

theorem allIndexed_at (f : ℕ → α → Bool) (offset : ℕ) (xs : List α)
    (h : allIndexed f offset xs = true) (k : ℕ) (hk : k < xs.length) (d : α) :
    f (offset+k) (xs.getD k d) = true := by
  induction xs generalizing offset k with
  | nil => simp at hk
  | cons v vs ih =>
    obtain ⟨hv,ht⟩ := Bool.and_eq_true_iff.mp h
    cases k with
    | zero => simpa using hv
    | succ k =>
      rw [List.getD_cons_succ]
      have he : offset + (k+1) = (offset+1) + k := by omega
      rw [he]
      exact ih (offset+1) ht k (by simpa using hk)

def checkRegionChunks (f : ℕ → α → Bool) (lo hi : ℕ) : ℕ → List (List α) → Bool
  | _, [] => true
  | offset, xs :: rest =>
    let last := offset + xs.length
    (if hi < offset ∨ last ≤ lo then true else allIndexed f offset xs) &&
      checkRegionChunks f lo hi last rest

theorem checkRegionChunks_at (f : ℕ → α → Bool) (lo hi offset : ℕ) (chunks : List (List α))
    (h : checkRegionChunks f lo hi offset chunks = true)
    (k : ℕ) (hk : k < chunks.flatten.length) (hlo : lo ≤ offset+k) (hhi : offset+k ≤ hi)
    (d : α) : f (offset+k) (chunks.flatten.getD k d) = true := by
  induction chunks generalizing offset k with
  | nil => simp at hk
  | cons xs ys ih =>
    obtain ⟨hl,hr⟩ := Bool.and_eq_true_iff.mp h
    simp only [List.flatten_cons, List.length_append] at hk ⊢
    by_cases hmem : k < xs.length
    · have hkeep : ¬(hi < offset ∨ offset+xs.length ≤ lo) := by omega
      rw [if_neg hkeep] at hl
      rw [List.getD_append _ _ _ _ hmem]
      exact allIndexed_at _ _ _ hl k hmem d
    · rw [List.getD_append_right _ _ _ _ (Nat.le_of_not_gt hmem)]
      have he : offset+k = (offset+xs.length)+(k-xs.length) := by omega
      rw [he]
      exact ih _ hr _ (by omega) (by omega) (by omega)

def chunkRowCheck (p : AppendixBoxParameters) (lo hi k : ℕ) (r : RawSourceMode) : Bool :=
  decide ((lo/2 ≤ k ∧ k ≤ hi/2 → p.amin ≤ r.high ∧ r.high ≤ p.amax ∧
      p.bmin ≤ r.low ∧ r.low ≤ p.bmax) ∧
    ((lo+1)/2 ≤ k ∧ k ≤ (hi+1)/2 → p.cLo ≤ r.boundary ∧ r.boundary ≤ p.cHi))

/-- The original source rows, retaining their evaluated 1,024-row chunks. -/
def ratePieces0 : List (List RawSourceMode) := [sourceRates00000, sourceRates01024, sourceRates02048, sourceRates03072, sourceRates04096, sourceRates05120, sourceRates06144, sourceRates07168, sourceRates08192]
private theorem ratePieces0_flat : ratePieces0.flatten = sourceRateBlock0 := by
  simp only [ratePieces0, List.flatten_cons, List.flatten_nil, List.append_nil, sourceRateBlock0, List.append_assoc]
def ratePieces1 : List (List RawSourceMode) := [sourceRates09216, sourceRates10240, sourceRates11264, sourceRates12288, sourceRates13312, sourceRates14336, sourceRates15360, sourceRates16384, sourceRates17408]
private theorem ratePieces1_flat : ratePieces1.flatten = sourceRateBlock1 := by
  simp only [ratePieces1, List.flatten_cons, List.flatten_nil, List.append_nil, sourceRateBlock1, List.append_assoc]
def ratePieces2 : List (List RawSourceMode) := [sourceRates18432, sourceRates19456, sourceRates20480, sourceRates21504, sourceRates22528, sourceRates23552, sourceRates24576, sourceRates25600, sourceRates26624]
private theorem ratePieces2_flat : ratePieces2.flatten = sourceRateBlock2 := by
  simp only [ratePieces2, List.flatten_cons, List.flatten_nil, List.append_nil, sourceRateBlock2, List.append_assoc]

def ratePieces := ratePieces0 ++ ratePieces1 ++ ratePieces2 ++ [[sourceEndRow sourceScale]]

theorem ratePieces_flat :
    ratePieces.flatten = appendixRateRows ++ [sourceEndRow sourceScale] := by
  simp only [ratePieces, List.flatten_append, List.flatten_cons, List.flatten_nil, List.append_nil,
    ratePieces0_flat, ratePieces1_flat, ratePieces2_flat, appendixRateRows, List.append_assoc]

def modeRangeCheck (p : AppendixBoxParameters) (lo hi : ℕ) : Bool :=
  checkRegionChunks (chunkRowCheck p lo hi) (lo/2) ((hi+1)/2) 0 ratePieces

theorem modeRangeCheck_sound (p : AppendixBoxParameters) (lo hi e : ℕ)
    (hc : modeRangeCheck p lo hi = true) (hl : lo ≤ e) (hr : e ≤ hi) (hmax : hi < 55296) :
    p.Bounds (endpointMode e) (endpointSide e) := by
  let raw := sourceEndRow sourceScale
  have he : endpointMode e + (if endpointSide e then 1 else 0) = (e+1)/2 := by
    unfold endpointMode endpointSide
    split <;> simp_all <;> omega
  have hlen : ratePieces.flatten.length = 27649 := by
    rw [ratePieces_flat, List.length_append, appendixRateRows_length]
    decide
  have hs (k : ℕ) (hlo : lo/2 ≤ k) (hhi : k ≤ (hi+1)/2) :
      chunkRowCheck p lo hi k (ratePieces.flatten.getD k raw) = true := by
    have h := checkRegionChunks_at _ _ _ _ _ hc k (by rw [hlen]; omega) (by omega) (by omega) raw
    simpa only [Nat.zero_add] using h
  have hm : endpointMode e < 27648 := by unfold endpointMode; omega
  have hmode := hs (e/2) (by omega) (by omega)
  have hratio := hs ((e+1)/2) (by omega) (by omega)
  rw [ratePieces_flat, List.getD_append _ _ _ _ (by rw [appendixRateRows_length]; omega)] at hmode
  obtain ⟨h1,h2,h3,h4⟩ := (of_decide_eq_true hmode).1 ⟨by omega, by omega⟩
  obtain ⟨h5,h6⟩ := (of_decide_eq_true hratio).2 ⟨by omega, by omega⟩
  have hbound : appendixRawRatio (endpointMode e) (endpointSide e) =
      (ratePieces.flatten.getD ((e+1)/2) raw).boundary := by
    rw [appendixRawRatio, he, appendixRawBoundary, ratePieces_flat]
    split
    · rename_i hk
      rw [List.getD_append _ _ _ _ (by rwa [appendixRateRows_length])]
      rfl
    · rename_i hk
      have heq : (e+1)/2 = 27648 := by omega
      rw [List.getD_append_right _ _ _ _ (by rw [appendixRateRows_length]; omega),
        appendixRateRows_length, heq]
      rfl
  exact ⟨h1,h2,h3,h4,hbound ▸ h5,hbound ▸ h6⟩

end SubmodularMatching.SourceCertificate.Replay
