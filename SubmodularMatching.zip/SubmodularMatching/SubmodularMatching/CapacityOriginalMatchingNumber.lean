import SubmodularMatching.NonmonotoneOriginalInput

/-! Clipping, endpoint filtering and isolated dummy slots preserve the capacity matching number. -/
namespace SubmodularMatching.Capacity
open Finset UpperBoundAssembly
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

theorem original_matching_number_lifts (S : SimpleEdgeStream E V) (cap : V→ℕ) (Z : Finset E)
    (hZ : feasible S.ends cap Z) (hk : ∀ B, feasible S.ends cap B → B.card≤Z.card) :
    ∃ X : Finset (Admissible S cap),
      feasible (admissibleStream S cap).ends (effectiveCapacity cap) X ∧
      X.card=Z.card ∧ ∀ A, feasible (admissibleStream S cap).ends (effectiveCapacity cap) A → A.card≤X.card := by
  obtain ⟨X,hX,_,hbound⟩ := original_optimum_lifts S cap (fun A => (A.card:ℝ)) Z hZ
    (fun A hA => by
      change (A.card:ℝ) ≤ (Z.card:ℝ)
      exact_mod_cast hk A hA)
  have size : X.card=Z.card := by
    rw [← hX]
    exact (card_map _).symm
  refine ⟨X,(effective_feasible_iff S cap X).2 (hX ▸ hZ),size,?_⟩
  intro A hA
  have hh := hk (originalLabels S cap A) ((effective_feasible_iff S cap A).1 hA)
  change (A.map (Function.Embedding.subtype _)).card ≤ Z.card at hh
  simpa only [card_map, size] using hh

end
end SubmodularMatching.Capacity
