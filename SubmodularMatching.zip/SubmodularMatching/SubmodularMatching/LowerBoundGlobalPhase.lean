import SubmodularMatching.LowerBoundGlobalCut
import SubmodularMatching.LowerBoundAssemblyCompleteness

/-! # The information estimate at a phase boundary -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundInformation LowerBoundAssembly
open scoped BigOperators

noncomputable section

variable {L R C State T : Type*}
variable [Fintype L] [Fintype R] [Fintype C] [Fintype State] [Nonempty State]
variable [Fintype T] [DecidableEq L] [DecidableEq R] [DecidableEq C]

abbrev LiftEdge (L R C : Type*) := (L × C) × (R × C)

/-- The actual output of a legal run contributes at most the rare-base-pair
estimate. The experiment fixes the clone samples for all potential pairs,
so each surviving clone's base pair is in the present phase sample. -/
theorem phase_output_bound
    (m : Machine (LiftEdge L R C) State) (U : Finset (L × R))
    (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) (hU : 0 < U.card)
    (cut : Cut (Side := T) m (uniformSubsetMass U (retainedSize q U.card)))
    (sideLaw : T → ℝ) (hside : ∀ t, 0 ≤ sideLaw t)
    (special : T → L × R → Prop) [∀ t, DecidablePred (special t)] (ρ : ℝ) (hρ : 0 ≤ ρ)
    (hrare : ∀ e, (∑ t, if special t e then sideLaw t else 0) ≤ ρ)
    (s : ℕ) (hstates : Fintype.card State ≤ 2 ^ s)
    (hbase : ∀ S, (cut.sampled S).image CloneLift.basePair ⊆ S)
    (hmatching : ∀ S, 0 < uniformSubsetMass U (retainedSize q U.card) S → ∀ t,
      CloneLift.IsMatching (m.output (cut.oracle t) (cut.before S ++ cut.after t))) :
    (∑ S, uniformSubsetMass U (retainedSize q U.card) S *
      (∑ t, sideLaw t * (((((m.output (cut.oracle t) (cut.before S ++ cut.after t)) ∩
        cut.oldEdges).filter (fun e => special t (CloneLift.basePair e))).card : ℝ)))) ≤
      (Fintype.card C : ℝ) * (ρ * (s / Real.logb 2 (1 / q))) := by
  classical
  let k := retainedSize q U.card
  let μ := uniformSubsetMass U k
  let output := fun y t =>
    if CloneLift.IsMatching (cut.continuation y t) then cut.continuation y t else ∅
  have hk : k ≤ U.card := retainedSize_le hq0.le hq1.le U.card
  have hqr : ((k : ℝ) / (U.card : ℝ)) ≤ q := by
    have hUc : (0 : ℝ) < U.card := by exact_mod_cast hU
    apply (div_le_iff₀ hUc).2
    exact Nat.floor_le (by positivity)
  have ha : ∀ S, 0 < μ S → ∀ t,
      output (cut.state S) t = m.output (cut.oracle t) (cut.before S ++ cut.after t) ∩
        cut.oldEdges := by
    intro S hs t
    have heq := cut.continuation_eq_output S t hs
    unfold output
    rw [heq, if_pos]
    exact CloneLift.isMatching_subset (hmatching S hs t) Finset.inter_subset_left
  have hv : ∀ S, 0 < μ S → ∀ t, (output (cut.state S) t).image CloneLift.basePair ⊆ S := by
    intro S hs t
    rw [ha S hs t, ← cut.continuation_eq_output S t hs]
    exact (Finset.image_subset_image (cut.continuation_subset_sampled S hs t)).trans (hbase S)
  have hbound := expected_special_clone_edges_le μ id cut.state sideLaw special output ρ q s
    (uniformSubsetMass_nonneg U k) (sum_uniformSubsetMass U k hk) hside hρ hq0 hq1
    (fun A => (uniformSubsetMass_inclusion_le U A k hU hk).trans
      (pow_le_pow_left₀ (by positivity) hqr A.card))
    hstates hrare
    (fun y t => by
      unfold output
      split_ifs with hm
      · exact hm
      · simp [CloneLift.IsMatching, Set.InjOn])
    hv
  calc
    _ = (∑ S, μ S * (∑ t, sideLaw t * (((output (cut.state S) t).filter
        (fun e => special t (CloneLift.basePair e))).card : ℝ))) := by
      apply Finset.sum_congr rfl
      intro S _
      by_cases hs : 0 < μ S
      · rw [show uniformSubsetMass U (retainedSize q U.card) S = μ S by rfl]
        simp only [ha S hs]
      · have hz := le_antisymm (le_of_not_gt hs) (uniformSubsetMass_nonneg U k S)
        have hz' : uniformSubsetMass U (retainedSize q U.card) S = 0 := hz
        simp [hz, hz']
    _ ≤ _ := hbound

end

end SubmodularMatching.LowerBoundGlobal

namespace SubmodularMatching.LowerBoundGlobal

open LowerBoundAssembly
open scoped BigOperators

noncomputable section

/-- Conditioning a uniform tuple on its exposed prefix amounts to
normalizing the count of completions. -/
theorem prefix_rarity_sum {N P t H : ℕ} (blueprint : BlueprintExpansion N P t H)
    (phase : Fin P) (J : Fin P → Fin t) (e : Fin N × Fin N) :
    (∑ J' : (prefixTuples phase J),
      if e ∈ blueprint.phases J phase ∧ specialBase (blueprint.canonical J') e
      then 1 / ((prefixTuples phase J).card : ℝ) else 0) ≤ (P : ℝ) / t := by
  classical
  by_cases he : e ∈ blueprint.phases J phase
  · have hcard :
        ((Finset.univ.filter fun J' : (prefixTuples phase J) =>
          specialBase (blueprint.canonical J') e).card) =
        ((prefixTuples phase J).filter
          (fun J' => specialBase (blueprint.canonical J') e)).card := by
      apply Finset.card_bij (fun J' _ => J'.val)
      · intro J' hJ'
        exact Finset.mem_filter.mpr ⟨J'.property, (Finset.mem_filter.mp hJ').2⟩
      · intro a _ b _ hab
        exact Subtype.ext hab
      · intro y hy
        have hs := Finset.mem_filter.mp hy
        exact ⟨⟨y, hs.1⟩, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hs.2⟩, rfl⟩
    simpa only [he, true_and, ← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul,
      hcard, mul_one_div] using blueprint.rarity phase J e he
  · simp only [he, false_and, if_false, Finset.sum_const_zero]
    positivity

end

end SubmodularMatching.LowerBoundGlobal
