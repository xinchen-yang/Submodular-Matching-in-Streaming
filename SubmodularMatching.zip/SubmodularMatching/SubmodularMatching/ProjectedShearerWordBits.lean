import SubmodularMatching.ProjectedShearerTimeProgram
import SubmodularMatching.ProjectedShearerBankRegisters

/-! Size in bits of the actual sampling and signed-priority registers. -/
namespace SubmodularMatching.AppendixM

/-- Magnitude and sign fit in an explicit number of bits on an n-vertex
input, including all intermediate sampled-score accumulators. -/
theorem signed_priority_word_bits {K n : ℕ} (hu : K≤2^35*(n+1)^4) (z : ℤ)
    (hz : |(z:ℝ)|≤8704*(K:ℝ)^12) :
    Nat.clog 2 (z.natAbs+1)+1 ≤ 436+48*Nat.clog 2 (n+1) := by
  have zbound : z.natAbs≤8704*K^12 := by
    exact_mod_cast (by simpa only [Nat.cast_natAbs,Int.cast_abs] using hz :
      (z.natAbs:ℝ)≤8704*(K:ℝ)^12)
  let w := Nat.clog 2 (n+1)
  have hn : n+1≤2^w := Nat.le_pow_clog (by decide : 1<2) _
  have hK : K≤2^(35+4*w) := hu.trans (by rw [pow_add,Nat.mul_comm 4,Nat.pow_mul]; gcongr)
  let r := 12*(35+4*w)
  have hP : K^12≤2^r := by dsimp only [r]; rw [Nat.mul_comm 12,Nat.pow_mul]; exact Nat.pow_le_pow_left hK _
  have hpos : 0<2^r := by positivity
  have all : z.natAbs+1≤2^(15+r) := by
    rw [pow_add]
    calc
      _ ≤ 8704*2^r+1 := Nat.add_le_add_right (zbound.trans (Nat.mul_le_mul_left _ hP)) _
      _ ≤ 32768*2^r := by omega
      _ = _ := by norm_num
  have width := (Nat.clog_le_iff_le_pow (by decide : 1<2)).2 all
  change _ ≤ 436+48*w
  dsimp only [r] at width
  omega

theorem graph_mark_widths {K n : ℕ} (hu : K≤2^35*(n+1)^4) :
    let w := Nat.clog 2 (n+1)
    Nat.clog 2 (firstBins K)≤251+20*w ∧ Nat.clog 2 (secondBins K)≤251+20*w ∧ layerTapeLength K≤70+8*w := by
  intro w
  have hn : n+1≤2^w := Nat.le_pow_clog (by decide : 1<2) _
  have hK : Nat.clog 2 K≤35+4*w := (Nat.clog_le_iff_le_pow (by decide : 1<2)).2
    (hu.trans (by rw [pow_add,Nat.mul_comm 4,Nat.pow_mul]; gcongr))
  obtain ⟨a,b,c⟩ := time_mark_registers K
  omega

end SubmodularMatching.AppendixM
