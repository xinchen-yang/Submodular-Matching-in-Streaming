import SubmodularMatching.CapacitySlotRank
import SubmodularMatching.NonmonotoneSlotSupport
import Mathlib.Data.Nat.Pairing

/-! Canonical total orders used to break ties on retained labels and ordered
slot pairs. Their equality decisions agree with the finite support data. -/

namespace SubmodularMatching.NonmonotoneCandidate

open TwoLayerDiffuse

/-- Taking the tie order from one-word keys also preserves the decidable
equality already used in storing and looking up these objects. -/
def keyedOrder {A : Type*} [d : DecidableEq A] (key : A ↪ ℕ) : LinearOrder A :=
  let o := LinearOrder.lift' key key.injective
  { o with
    toDecidableEq := d
    compare_eq_compareOfLessAndEq := by
      intro a b
      have eq : d = o.toDecidableEq := Subsingleton.elim _ _
      rw [eq]
      exact @LinearOrder.compare_eq_compareOfLessAndEq A o a b }

def slotPairKey {V : Type*} (b : V → ℕ) (rank : Slots b ↪ ℕ) : Slots b × Slots b ↪ ℕ where
  toFun p := Nat.pair (rank p.1) (rank p.2)
  inj' := by
    intro p q hh
    have eq := congrArg Nat.unpair hh
    simp only [Nat.unpair_pair] at eq
    exact Prod.ext (rank.injective (congrArg Prod.fst eq)) (rank.injective (congrArg Prod.snd eq))

end SubmodularMatching.NonmonotoneCandidate
