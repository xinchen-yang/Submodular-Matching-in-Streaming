import SubmodularMatching.UpperBoundK1ArchiveGraph

/-! # Value-oracle archive guarantees at a single advertised factor -/

namespace SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream

open GibbsSampler

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

theorem k1Archived_guarantees_of_expectedFactor_le (S : SimpleEdgeStream E V)
    (a : K1Parameters) (C : K1Confidence a) (hle : a.expectedFactor ≤ C.target)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, f M ≤ f O)
    (δ : ℝ) (hδ : 0 < δ) :
    let p := S.k1ArchivedExpectedOutput a f hf hm
    let q := S.k1ArchivedAmplifiedOutput a f hf hm C δ
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / C.target ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / C.target ≤ f M then 0 else 1) ≤ δ := by
  have h := S.theoremK1_verified a f hf hm h0 O hO hopt C δ hδ
  have hopt0 := h0.trans (hm ∅ O (Finset.empty_subset O))
  have he := h.2.2.1
  rw [← a.expectedFactor_eq] at he
  exact ⟨h.1, h.2.1, (div_le_div_of_nonneg_left hopt0
    (zero_lt_one.trans a.one_lt_expectedFactor) hle).trans he, h.2.2.2⟩

end

end SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream
