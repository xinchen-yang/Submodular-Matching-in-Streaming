import SubmodularMatching.NonmonotoneStreamingCharge

/-! The finite signed-objective charging inequality for ordinary matching (M.2). -/

open scoped BigOperators

namespace SubmodularMatching.Streaming

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

omit [Fintype V] in
/-- Final residual bound of an actual rejected arrival. -/
theorem signed_rejected_trace_residual_bound (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (f : Finset E → ℝ) (n i : ℕ) (hi : i < n)
    (hp1 : C.p ≤ 1) (hf : IsSubmodular f)
    (hw : ∀ j < n, (input j).2 ≤ C.tau)
    (hno : (input i).1 ∉ (runPotential C ends input n).stored)
    (hloop : (ends (input i).1).1 ≠ (ends (input i).1).2)
    (ha : traceWeight C ends input f i ≤ (input i).2 + 3 * C.gap) :
    traceResidual C ends input f n {(input i).1} ≤
      (∑ v ∈ endpointSet ends (input i).1, (runPotential C ends input n).potential v) +
        C.theta + 4 * C.gap := by
  have hpre : ∀ j < i, (input j).2 ≤ C.tau := fun j hj => hw j (hj.trans hi)
  have hstate := runPotential_invariant_prefix C ends input i hpre
  have hr := rejected_arrival_bound C ends (runPotential C ends input i) (input i).1 (input i).2
    (traceWeight C ends input f i) (fun v => (hstate v).1)
    (not_acceptedAt_of_not_stored C ends input n i hi hno) ha
  have hu := runPotential_potential_mono C ends input n hw i hi.le (ends (input i).1).1
  have hv := runPotential_potential_mono C ends input n hw i hi.le (ends (input i).1).2
  have hg := rejected_signed_trace_singleton_le C ends input f n i hi.le (input i).1 hno hf hp1
  change traceResidual C ends input f n {(input i).1} ≤ traceWeight C ends input f i at hg
  simp only [endpointSet, Finset.sum_pair hloop]
  linarith

/-- Charging for the actual finite instance, including the exact ideal
potential sum and all deterministic finite error terms. -/
theorem signed_trace_finite_charge (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (f : Finset E → ℝ) (n : ℕ) (M : Finset E)
    (hp1 : C.p ≤ 1) (hf : IsSubmodular f) (hpos : ∀ A, 0 ≤ f A)
    (hinj : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j)
    (hM : IsMatchingOn (endpointSet ends) M)
    (hMsub : M ⊆ (Finset.range n).image (fun i => (input i).1))
    (hloop : ∀ i < n, (ends (input i).1).1 ≠ (ends (input i).1).2)
    (hw : ∀ i < n, (input i).2 ≤ C.tau)
    (hu : ∀ i < n, traceWeight C ends input f i ≤ (input i).2 + 3 * C.gap)
    (hl : ∀ i < n, acceptedAt C ends input i → (input i).2 ≤ traceWeight C ends input f i) :
    let S := (runPotential C ends input n).stored
    (1-C.p)*f M ≤ f ∅ + traceRecordedValue C ends input n + traceResidual C ends input f n (M ∩ S) +
      (∑ v ∈ Finset.univ \ (M ∩ S).biUnion (endpointSet ends), idealPotential C ends input n v) +
      3 * C.p * C.gap * n + M.card * (C.theta + 4 * C.gap) + 2 * n * C.grid := by
  let S := (runPotential C ends input n).stored
  let g := traceResidual C ends input f n
  let allowance := C.theta + 4 * C.gap
  have hg := signed_trace_residual_submodular C ends input f n hp1 hf
  have hg0 : g ∅ = 0 := by simp [g, traceResidual]
  have hstate := runPotential_invariant_prefix C ends input n hw
  have hrejected (e : E) (he : e ∈ M \ S) :
      g {e} - allowance ≤ ∑ v ∈ endpointSet ends e, (runPotential C ends input n).potential v := by
    obtain ⟨i, hi, hie⟩ := Finset.mem_image.mp (hMsub (Finset.mem_sdiff.mp he).1)
    have hin := Finset.mem_range.mp hi
    have hno : (input i).1 ∉ (runPotential C ends input n).stored := by
      rw [hie]
      exact (Finset.mem_sdiff.mp he).2
    have h := signed_rejected_trace_residual_bound C ends input f n i hin hp1 hf hw hno
      (hloop i hin) (hu i hin)
    rw [hie] at h
    dsimp [g, allowance]
    linarith
  have hc := rejected_charge_le_unmatched_potential (endpointSet ends) M S hM
    (fun e => g {e} - allowance) (runPotential C ends input n).potential
    (fun v => (hstate v).1) hrejected
  simp only [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul] at hc
  have hsplit : (M ∩ S) ∪ (M \ S) = M := by
    ext e
    simp only [Finset.mem_union, Finset.mem_inter, Finset.mem_sdiff]
    tauto
  have hd : Disjoint (M ∩ S) (M \ S) := by
    apply Finset.disjoint_left.mpr
    intro e he he'
    exact (Finset.mem_sdiff.mp he').2 (Finset.mem_inter.mp he).2
  have hs := signed_disjoint_singleton_charge g hg hg0.ge (M ∩ S) (M \ S) hd
  rw [hsplit] at hs
  have hb := signed_trace_augment C ends input f n M hp1 hf hpos hinj
  have he := (signed_trace_base_error C ends input f n hp1 hu hl).2
  have hr := potential_sum_le_ideal_add_rounding C ends input n
    (Finset.univ \ (M ∩ S).biUnion (endpointSet ends))
  have hcard : ((M \ S).card : ℝ) ≤ M.card := by
    exact_mod_cast Finset.card_le_card (Finset.sdiff_subset : M \ S ⊆ M)
  have hallow : 0 ≤ allowance := by dsimp [allowance]; linarith [C.theta_pos, C.gap_nonneg]
  have hcard' := mul_le_mul_of_nonneg_right hcard hallow
  dsimp [S, g, allowance] at hs hc hb hr hcard' ⊢
  linarith

/-- An ignored prefix is charged only by its singleton values, with the loss
made explicit rather than assuming the final charging conclusion. -/
theorem signed_trace_finite_charge_with_prefix (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (f : Finset E → ℝ) (n : ℕ) (M : Finset E) (prefixLoss : ℝ)
    (hp1 : C.p ≤ 1) (hf : IsSubmodular f) (hpos : ∀ A, 0 ≤ f A)
    (hinj : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j)
    (hM : IsMatchingOn (endpointSet ends) M)
    (hloop : ∀ i < n, (ends (input i).1).1 ≠ (ends (input i).1).2)
    (hw : ∀ i < n, (input i).2 ≤ C.tau)
    (hu : ∀ i < n, traceWeight C ends input f i ≤ (input i).2 + 3 * C.gap)
    (hl : ∀ i < n, acceptedAt C ends input i → (input i).2 ≤ traceWeight C ends input f i)
    (hprefix : (∑ e ∈ M \ (Finset.range n).image (fun i => (input i).1), f {e}) ≤ prefixLoss) :
    let S := (runPotential C ends input n).stored
    (1-C.p)*f M ≤ f ∅ + traceRecordedValue C ends input n + traceResidual C ends input f n (M ∩ S) +
      (∑ v ∈ Finset.univ \ (M ∩ S).biUnion (endpointSet ends), idealPotential C ends input n v) +
      prefixLoss + 3 * C.p * C.gap * n + M.card * (C.theta + 4 * C.gap) + 2 * n * C.grid := by
  let arrived := (Finset.range n).image (fun i => (input i).1)
  let M' := M ∩ arrived
  have hM' : IsMatchingOn (endpointSet ends) M' := by
    intro e he d hd hed
    exact hM (Finset.mem_inter.mp he).1 (Finset.mem_inter.mp hd).1 hed
  have hS : (runPotential C ends input n).stored ⊆ arrived :=
    runPotential_stored_subset C ends input arrived n
      (fun i hi => Finset.mem_image.mpr ⟨i, Finset.mem_range.mpr hi, rfl⟩)
  have heq : M' ∩ (runPotential C ends input n).stored =
      M ∩ (runPotential C ends input n).stored := by
    rw [show M' = M ∩ arrived from rfl, Finset.inter_assoc, Finset.inter_eq_right.mpr hS]
  have hc := signed_trace_finite_charge C ends input f n M' hp1 hf hpos hinj hM'
    Finset.inter_subset_right hloop hw hu hl
  dsimp only at hc ⊢
  rw [heq] at hc
  have hd : Disjoint M' (M \ arrived) := by
    apply Finset.disjoint_left.mpr
    intro e he he'
    exact (Finset.mem_sdiff.mp he').2 (Finset.mem_inter.mp he).2
  have hsub := signed_disjoint_singleton_charge f hf (hpos ∅) M' (M \ arrived) hd
  have hsplit : M' ∪ (M \ arrived) = M := by
    ext e
    simp only [M', Finset.mem_union, Finset.mem_inter, Finset.mem_sdiff]
    tauto
  rw [hsplit] at hsub
  have hcard : (M'.card : ℝ) ≤ M.card := by
    exact_mod_cast Finset.card_le_card (Finset.inter_subset_left : M ∩ arrived ⊆ M)
  have hcost := mul_le_mul_of_nonneg_right hcard
    (by linarith [C.theta_pos, C.gap_nonneg] : 0 ≤ C.theta + 4 * C.gap)
  have hmul := mul_le_mul_of_nonneg_left hsub (sub_nonneg.mpr hp1)
  have hprefix0 : 0 ≤ ∑ e ∈ M \ arrived, f {e} := Finset.sum_nonneg (fun e _ => hpos {e})
  have hcost' := mul_nonneg C.p_pos.le hprefix0
  dsimp [arrived] at hmul hcost'
  linarith

end SubmodularMatching.Streaming
