import SubmodularMatching.AppendixMNumerical

/-! Exact two-sided square-root enclosure and decimal bound printed in Appendix M.5
of the November 24 arXiv manuscript. -/
namespace SubmodularMatching.AppendixM

theorem arxiv_priority_certificate :
    rootLo < Real.sqrt discriminant ∧ Real.sqrt discriminant < rootHi ∧
    gamma ≤ retention (Real.sqrt discriminant) (Real.sqrt discriminant) ∧
    1 / beta < 4726494 / 1000000 ∧ (4726494 / 1000000 : ℝ) < 4727/1000 := by
  refine ⟨rootEnclosure.1,rootEnclosure.2,gamma_le_priority,?_,by norm_num⟩
  norm_num [beta, gamma, retention, priorityArea, priorityLoss,
    rootHi, rootLo, degree, layerTwo, layerOne, discriminant]

end SubmodularMatching.AppendixM
