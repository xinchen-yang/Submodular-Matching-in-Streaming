import SubmodularMatching.GibbsSpectralCongestion
import SubmodularMatching.GibbsSpectralSampling

/-!
# Polynomial window from the matching-chain path certificate

Bound the four-edge metadata and place the resulting congestion in the
shape used by the finite lazy-kernel contraction theorem.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [LinearOrder E] [DecidableEq V]

/-- Polynomial count bounding the four-edge metadata of each path encoding. -/
def defectBound (m : ℕ) : ℕ := 5*(m+1)^4

noncomputable def lowActivityC (m : ℕ) : ℝ := Real.sqrt (defectBound m : ℝ)

theorem lowActivityC_sq (m : ℕ) : lowActivityC m ^ 2 = (defectBound m : ℝ) :=
  Real.sq_sqrt (by positivity)

theorem one_le_lowActivityC (m : ℕ) : 1 ≤ lowActivityC m := by
  have h : 1 ≤ defectBound m := by
    apply Nat.succ_le_of_lt
    unfold defectBound
    positivity
  simpa only [lowActivityC, Real.sqrt_one] using
    Real.sqrt_le_sqrt (show (1:ℝ) ≤ (defectBound m : ℝ) by exact_mod_cast h)

theorem lowActivityPaths_hasSinclairPaths (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (hAct : ∀ e ∈ edges, 0 ≤ activity e ∧ activity e ≤ 1)
    (hEnds : ∀ e ∈ edges, (ends e).card = 2) (n m : ℕ)
    (hLength : ∀ I ∈ matchings ends edges, ∀ F ∈ matchings ends edges,
      (matchingRoute ends edges hEnds I F).card ≤ n) (hm : edges.card ≤ m) :
    HasSinclairPaths ends edges activity n (lowActivityC m) := by
  let paths := lowActivityPaths ends edges activity hAct hEnds
  have hcap : (defectSets edges).card ≤ defectBound m :=
    (defectSets_card_le edges).trans (show defectBound edges.card ≤ defectBound m by
      unfold defectBound
      gcongr)
  refine ⟨⟨paths.route,paths.route_subset,paths.telescopes,hLength,?_⟩⟩
  intro a ha b hb
  apply (paths.congestion a ha b hb).trans
  apply mul_le_mul_of_nonneg_right
  · rw [lowActivityC_sq]
    have hcast : ((defectSets edges).card : ℝ) ≤ (defectBound m : ℝ) := by exact_mod_cast hcap
    calc
      _ ≤ 4*(edges.card:ℝ)*(defectBound m:ℝ) := by gcongr
      _ ≤ 8*(edges.card:ℝ)*(defectBound m:ℝ) := by gcongr; norm_num
  · exact mul_nonneg
      (probability_nonnegative ends edges activity (fun e he => (hAct e he).1) a)
      (transition_nonnegative ends edges activity (fun e he => (hAct e he).1) a b ha hb)

end SubmodularMatching.GibbsSampler
