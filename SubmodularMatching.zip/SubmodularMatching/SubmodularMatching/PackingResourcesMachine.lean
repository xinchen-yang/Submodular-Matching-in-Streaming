import SubmodularMatching.PackingResourcesRational

/-!
# Integer implementation of the packing update

The transition maintains a current dual numerator array and accumulators.
Adjusting the numerator by the scaled degree uses integer arithmetic.
The proof relates these arrays pointwise to the exact real-valued solver.
-/

open scoped BigOperators

namespace SubmodularMatching.LinearPacking

variable {Row Col : Type*} [Fintype Row] [Fintype Col]

/-- The two persistent arrays in a packing loop. -/
structure PackingArrays (Row Col : Type*) where
  dual : Row → ℤ
  accumulator : Col → ℕ

/-- Strict comparison in the common denominator of the matrix transpose and
the supplied coefficient grid, with ties consistently returning zero. -/
def integerAction (A : Row → Col → ℤ) (c : Col → ℤ)
    (dual : Row → ℤ) (dualScale matrixScale coefficientScale : ℕ) (i : Col) : ℕ :=
  if (coefficientScale : ℤ) * (∑ h, A h i * dual h) <
      c i * (dualScale : ℤ) * (matrixScale : ℤ) then 1 else 0

/-- The persistent state has two arrays throughout. The response is computed
from the old dual, and all updates use that same response. -/
def integerStep (A : Row → Col → ℤ) (c : Col → ℤ)
    (matrixScale dualScale coefficientScale radius accuracyNumerator : ℕ)
    (state : PackingArrays Row Col) : PackingArrays Row Col :=
  let take := integerAction A c state.dual dualScale matrixScale coefficientScale
  ⟨fun h => min ((dualScale : ℤ) * radius) (max 0 (state.dual h +
      (accuracyNumerator : ℤ) * ((∑ i, A h i * (take i : ℤ)) - matrixScale))),
    fun i => state.accumulator i + take i⟩

/-- Running the two-array transition from zero. -/
def integerRun (A : Row → Col → ℤ) (c : Col → ℤ)
    (matrixScale dualScale coefficientScale radius accuracyNumerator : ℕ) :
    ℕ → PackingArrays Row Col
  | 0 => ⟨fun _ => 0, fun _ => 0⟩
  | j + 1 => integerStep A c matrixScale dualScale coefficientScale radius accuracyNumerator
      (integerRun A c matrixScale dualScale coefficientScale radius accuracyNumerator j)

noncomputable section

omit [Fintype Col] in
/-- Integer comparison computes exactly the real response. -/
theorem integerAction_eq (A : Row → Col → ℤ) (c : Col → ℤ) (U : Row → ℤ)
    (P Q C : ℕ) (hP : 0 < P) (hQ : 0 < Q) (hC : 0 < C) (i : Col) :
    (integerAction A c U P Q C i : ℝ) =
      action (fun h i => (A h i : ℝ) / Q) (fun i => (c i : ℝ) / C) (fun h => (U h : ℝ) / P) i := by
  have hP' : (0 : ℝ) < P := by exact_mod_cast hP
  have hQ' : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hC' : (0 : ℝ) < C := by exact_mod_cast hC
  have heq : column (fun h i => (A h i : ℝ) / Q) (fun h => (U h : ℝ) / P) i =
      (∑ h, (A h i : ℝ) * (U h : ℝ)) / ((P : ℝ) * Q) := by
    unfold column
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro h _
    ring
  unfold integerAction action
  rw [heq]
  split_ifs with hInt hReal hReal
  · norm_num
  · exfalso
    apply hReal
    rw [div_lt_div_iff₀ (mul_pos hP' hQ') hC']
    exact_mod_cast (show (∑ h, A h i * U h) * (C : ℤ) < c i * ((P : ℤ) * Q) by
      simpa only [mul_comm (C : ℤ), mul_assoc] using hInt)
  · exfalso
    apply hInt
    rw [div_lt_div_iff₀ (mul_pos hP' hQ') hC'] at hReal
    have hInt' : (∑ h, A h i * U h) * (C : ℤ) < c i * ((P : ℤ) * Q) := by
      exact_mod_cast hReal
    simpa only [mul_comm (C : ℤ), mul_assoc] using hInt'
  · norm_num

/-- The integer update represents one real projected-gradient step. The
step size is `a Q/P`, so the grid `P` remains fixed across the loop. -/
theorem integerStep_dual_eq (A : Row → Col → ℤ) (c : Col → ℤ)
    (P Q C R a : ℕ) (hP : 0 < P) (hQ : 0 < Q) (hC : 0 < C)
    (state : PackingArrays Row Col) (h : Row) :
    ((integerStep A c Q P C R a state).dual h : ℝ) / P =
      dualStep (fun h i => (A h i : ℝ) / Q) (fun i => (c i : ℝ) / C)
        R ((a : ℝ) * Q / P) (fun h => (state.dual h : ℝ) / P) h := by
  have hP' : (0 : ℝ) < P := by exact_mod_cast hP
  have hQ' : (0 : ℝ) < Q := by exact_mod_cast hQ
  simp only [integerStep, Int.cast_min, Int.cast_max, Int.cast_zero, Int.cast_mul,
    Int.cast_natCast, Int.cast_add, Int.cast_sub, Int.cast_sum]
  simp_rw [integerAction_eq A c state.dual P Q C hP hQ hC]
  unfold dualStep clip load
  rw [← min_div_div_right hP'.le, ← max_div_div_right hP'.le, zero_div,
    mul_div_cancel_left₀ _ hP'.ne']
  simp_rw [div_mul_eq_mul_div]
  rw [← Finset.sum_div]
  apply congrArg (fun x : ℝ => min (R : ℝ) (max 0 x))
  field_simp

/-- Decoding the two persistent arrays gives the actual solver dual and its
running sum of binary decisions at every iteration. -/
theorem integerRun_eq (A : Row → Col → ℤ) (c : Col → ℤ)
    (P Q C R a : ℕ) (hP : 0 < P) (hQ : 0 < Q) (hC : 0 < C) (j : ℕ) :
    let A' := fun h i => (A h i : ℝ) / Q
    let c' := fun i => (c i : ℝ) / C
    let η := (a : ℝ) * Q / P
    let state := integerRun A c Q P C R a j
    (∀ h, (state.dual h : ℝ) / P = dual A' c' R η j h) ∧
      ∀ i, (state.accumulator i : ℝ) = ∑ s ∈ Finset.range j, action A' c' (dual A' c' R η s) i := by
  dsimp only
  induction j with
  | zero => simp [integerRun, dual]
  | succ j ih =>
    let state := integerRun A c Q P C R a j
    have hu : (fun h => (state.dual h : ℝ) / P) =
        dual (fun h i => (A h i : ℝ) / Q) (fun i => (c i : ℝ) / C) R ((a : ℝ) * Q / P) j :=
      funext ih.1
    constructor
    · intro h
      rw [integerRun, integerStep_dual_eq A c P Q C R a hP hQ hC state h, hu, dual]
    · intro i
      rw [integerRun, integerStep, Nat.cast_add, ih.2, Finset.sum_range_succ]
      rw [integerAction_eq A c state.dual P Q C hP hQ hC, hu]

/-- Finite machine output represented by two nonnegative integer arrays:
the indexed action count contributes the numerator and the denominator is
fixed by the problem dimensions and requested accuracy. -/
theorem integerPacking_output_eq (A : Row → Col → ℤ) (c : Col → ℤ)
    (Q C a b : ℕ) (hQ : 0 < Q) (hC : 0 < C) (ha : 0 < a) (hb : 0 < b)
    (hab : a ≤ b) (hM : 0 < Fintype.card Row) (hN : 0 < Fintype.card Col) (i : Col) :
    let M := Fintype.card Row
    let N := Fintype.card Col
    let epsilon := (a : ℝ) / b
    let P := 2 * b * M * N ^ 2 * Q
    let R := Nat.ceil (4 * (N : ℝ) ^ 2 / epsilon)
    let J := iterationCount M N epsilon
    let state := integerRun A c Q P C R a J
    solve (fun h i => (A h i : ℝ) / Q) (fun i => (c i : ℝ) / C) epsilon i =
      ((state.accumulator i * (2 * N * b) : ℕ) : ℝ) /
        rationalOutputDenominator M N a b := by
  intro M N epsilon P R J state
  have hP : 0 < P := by dsimp [P]; positivity
  have hMr : (0 : ℝ) < M := by exact_mod_cast hM
  have hNr : (0 : ℝ) < N := by exact_mod_cast hN
  have har : (0 : ℝ) < a := by exact_mod_cast ha
  have hbr : (0 : ℝ) < b := by exact_mod_cast hb
  have hQr : (0 : ℝ) < Q := by exact_mod_cast hQ
  have he : 0 < epsilon := div_pos har hbr
  have he1 : epsilon ≤ 1 := (div_le_one hbr).mpr (by exact_mod_cast hab)
  have hJ : 0 < J := (concrete_parameters M N epsilon hM hN he he1).2.2.1
  have hJr : (0 : ℝ) < J := by exact_mod_cast hJ
  have hη : (a : ℝ) * Q / P = stepSize M N epsilon := by
    unfold stepSize
    dsimp [P, epsilon]
    push_cast
    field_simp
  have hc := (integerRun_eq A c P Q C R a hP hQ hC J).2 i
  change (state.accumulator i : ℝ) = _ at hc
  rw [hη] at hc
  let A' := fun h i => (A h i : ℝ) / Q
  let c' := fun i => (c i : ℝ) / C
  change ((∑ j ∈ Finset.range J, action A' c' (dual A' c' R (stepSize M N epsilon) j) i) / J) /
    (1 + rescaling N epsilon) = _
  rw [← hc, rescaling]
  change _ = (↑(state.accumulator i * (2 * N * b)) : ℝ) / ↑(J * (2 * N * b + a))
  push_cast
  dsimp [epsilon]
  field_simp


end

end SubmodularMatching.LinearPacking
