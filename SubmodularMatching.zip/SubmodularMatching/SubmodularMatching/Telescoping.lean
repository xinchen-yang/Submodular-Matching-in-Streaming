import SubmodularMatching.MarginalValues

open scoped BigOperators

namespace SubmodularMatching

theorem telescoping_sum
    (a : ℕ → ℝ) (n : ℕ) :
    (∑ i ∈ Finset.range n, (a (i + 1) - a i)) =
      a n - a 0 := by
  induction n with
  | zero =>
      simp
  | succ n ih =>
      rw [Finset.sum_range_succ, ih]
      ring

theorem marginal_loss_telescoping
    (a b : ℕ → ℝ) (n : ℕ) :
    (∑ i ∈ Finset.range n,
      ((a (i + 1) - a i) -
       (b (i + 1) - b i))) =
      (a n - a 0) - (b n - b 0) := by
  rw [Finset.sum_sub_distrib]
  rw [telescoping_sum a n]
  rw [telescoping_sum b n]

end SubmodularMatching
