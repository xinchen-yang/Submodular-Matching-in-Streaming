import SubmodularMatching.UpperBoundReindex
import SubmodularMatching.StoredEmbedding

/-!
# Transfer the charged optimum to the compact comparator

A matching in the original graph supplies its stored part as the actual
comparator on the compact edge universe. Its uncovered vertices and the
streaming charge agree with the inputs of the source certificate.
-/

open scoped BigOperators

namespace SubmodularMatching.UpperBoundAssembly

open Joint SourceCertificate TwoStage Streaming

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

private theorem ideal_unordered_nondecreasing (C : PotentialConfig) (P : PotentialPair)
    (w : ℝ) (hw : 0 ≤ w) :
    P.high ≤ (idealUnordered C P w).high ∧ P.low ≤ (idealUnordered C P w).low := by
  have ht : 0 ≤ C.p * w := mul_nonneg C.p_pos.le hw
  have hh := mul_nonneg (C.minLow_pos.le.trans C.minLow_le_minHigh) ht
  have hl := mul_nonneg C.minLow_pos.le ht
  have h (P : PotentialPair) := idealUpdate_bounds C.base C.stages C.minHigh C.minLow C.maxRate
    C.base_bounds C.stage_bounds P (C.p * w) ht
  unfold idealUnordered
  split_ifs
  · exact ⟨by linarith [(h P).1], by linarith [(h P).2.2.1]⟩
  · dsimp only [PotentialPair.swap]
    exact ⟨by have h' := (h P.swap).2.2.1; dsimp [PotentialPair.swap] at h'; linarith,
      by have h' := (h P.swap).1; dsimp [PotentialPair.swap] at h'; linarith⟩

theorem ideal_trace_nonnegative (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (n : ℕ) (v : V) :
    0 ≤ Streaming.idealPotential C ends input n v := by
  classical
  induction n with
  | zero => simp [Streaming.idealPotential]
  | succ n ih =>
    rw [Streaming.idealPotential]
    refine add_nonneg ih ?_
    split_ifs with h
    · have hw : 0 ≤ (input n).2 := C.theta_pos.le.trans h.1
      let P : PotentialPair := ⟨(runPotential C ends input n).potential (ends (input n).1).1,
        (runPotential C ends input n).potential (ends (input n).1).2⟩
      have hg := ideal_unordered_nondecreasing C P (input n).2 hw
      unfold idealIncrement
      split_ifs with h₁ h₂
      · subst v
        exact sub_nonneg.mpr hg.1
      · subst v
        exact sub_nonneg.mpr hg.2
      · exact le_rfl
    · exact le_rfl

theorem traceRecorded_eq_weight_sum (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (n : ℕ) (w : E → ℝ)
    (huniq : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j)
    (hrecord : ∀ i < n, (input i).2 = w (input i).1) :
    traceRecordedValue C ends input n = C.p * ((runPotential C ends input n).stored.sum w) := by
  classical
  unfold traceRecordedValue
  rw [Finset.mul_sum, ← accepted_sum_eq_stored C ends input (fun e => C.p * w e) n huniq]
  apply Finset.sum_congr rfl
  intro j hj
  by_cases h : accepts C ends (runPotential C ends input j) (input j).1 (input j).2
  · simp [traceProbability, acceptedAt, hrecord j (Finset.mem_range.mp hj)]
  · simp [traceProbability, acceptedAt, h]

/-- The stored part of an original matching, indexed by compact edge
positions. -/
def compactOptimum {m : ℕ} (emb : Fin m ↪ E) (M : Finset E) : Finset (Fin m) :=
  Finset.univ.filter (fun i => emb i ∈ M)

theorem compactOptimum_map {m : ℕ} (emb : Fin m ↪ E) (M S : Finset E)
    (hS : Finset.univ.map emb = S) :
    (compactOptimum emb M).map emb = M ∩ S := by
  classical
  ext e
  rw [← hS]
  simp only [compactOptimum, Finset.mem_map, Finset.mem_filter, Finset.mem_univ, true_and,
    Finset.mem_inter]
  constructor
  · rintro ⟨i, hi, rfl⟩
    exact ⟨hi, i, rfl⟩
  · rintro ⟨he, i, rfl⟩
    exact ⟨i, he, rfl⟩

theorem compactOptimum_isMatching {m : ℕ} (emb : Fin m ↪ E) (M : Finset E)
    (ends : E → V × V) (hM : IsMatchingOn (endpointSet ends) M) :
    IsMatchingOn (endpointSet (ends ∘ emb)) (compactOptimum emb M) := by
  intro i hi j hj hij
  have hiM : emb i ∈ M := (Finset.mem_filter.mp (show i ∈ Finset.univ.filter
    (fun k => emb k ∈ M) from hi)).2
  have hjM : emb j ∈ M := (Finset.mem_filter.mp (show j ∈ Finset.univ.filter
    (fun k => emb k ∈ M) from hj)).2
  exact hM hiM hjM (fun eq => hij (emb.injective eq))

/-- A Boolean indicator of membership in the original matching's endpoints.
Used when the source certificate is stated with Boolean coverage classes. -/
def coveredBit (ends : E → V × V) (M : Finset E) (v : V) : Bool :=
  decide (v ∈ M.biUnion (endpointSet ends))

omit [DecidableEq E] in
theorem coveredBit_compact {m : ℕ} (emb : Fin m ↪ E) (O : Finset (Fin m))
    (ends : E → V × V) (v : V) :
    bit (coveredBit ends (O.map emb) v) = coveredIndicator (ends ∘ emb) O v := by
  classical
  have hmem : v ∈ (O.map emb).biUnion (endpointSet ends) ↔
      ∃ e ∈ O, v = (ends (emb e)).1 ∨ v = (ends (emb e)).2 := by
    simp only [Finset.mem_biUnion, Finset.mem_map]
    constructor
    · rintro ⟨e, ⟨i, hi, rfl⟩, hv⟩
      exact ⟨i, hi, by simpa [endpointSet] using hv⟩
    · rintro ⟨i, hi, hv⟩
      exact ⟨emb i, ⟨i, hi, rfl⟩, by simpa [endpointSet] using hv⟩
  simp [bit, coveredBit, coveredIndicator, hmem]

/-- The expression charged by the streaming analysis is exactly the one
consumed by the compact optimization and the source certificate. -/
theorem charge_on_compact_optimum {m : ℕ} [Fintype V]
    (C : PotentialConfig) (ends : E → V × V) (input : ℕ → E × ℝ)
    (n : ℕ) (w : E → ℝ) (f : Finset E → ℝ) (M : Finset E)
    (opt epsilon : ℝ)
    (hunique : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j)
    (hrecord : ∀ i < n, (input i).2 = w (input i).1)
    (emb : Fin m ↪ E) (hS : Finset.univ.map emb = (runPotential C ends input n).stored)
    (hcharge : opt ≤ traceRecordedValue C ends input n +
        traceResidual C ends input f n (M ∩ (runPotential C ends input n).stored) +
        (∑ v ∈ Finset.univ \ (M ∩ (runPotential C ends input n).stored).biUnion (endpointSet ends),
          Streaming.idealPotential C ends input n v) + 6 * epsilon * C.tau) :
    let O := compactOptimum emb M
    let I := coveredBit ends (O.map emb)
    let X := C.p * ((runPotential C ends input n).stored.sum w) +
      ∑ v, unmatched (I v) * Streaming.idealPotential C ends input n v
    opt ≤ X + traceResidual C ends input f n (O.map emb) + 6 * epsilon * C.tau := by
  classical
  dsimp only
  rw [compactOptimum_map emb M _ hS, ← traceRecorded_eq_weight_sum C ends input n w hunique hrecord]
  let R := M ∩ (runPotential C ends input n).stored
  let U := R.biUnion (endpointSet ends)
  have hsum : ∑ v, unmatched (coveredBit ends R v) * Streaming.idealPotential C ends input n v =
      ∑ v ∈ Finset.univ \ U, Streaming.idealPotential C ends input n v := by
    rw [show Finset.univ \ U = Finset.univ.filter (fun v => v ∉ U) by ext v; simp, Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro v _
    by_cases hv : v ∈ U <;> simp [unmatched, bit, coveredBit, hv, U]
  rw [hsum]
  linarith only [hcharge]

end

end SubmodularMatching.UpperBoundAssembly
