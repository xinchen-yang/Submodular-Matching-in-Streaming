import SubmodularMatching.NonmonotoneRetainedRuntimeFacts
import SubmodularMatching.NonmonotoneRetainedGoodPhysical

/-! End-to-end quality of the executable finite optimizer and output program
on a retained record array from the decisive guess. -/
namespace SubmodularMatching.AppendixM.RetainedRuntime
open Capacity Finset Streaming NonmonotoneOptimizer NonmonotoneCandidate NonmonotoneLayers
open TwoLayerDiffuse Shearer UpperBoundAssembly GibbsSampler
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream E V} {b : V → ℕ} {records : List (E×ℕ)} (R : RetainedRuntime S b records)

set_option maxRecDepth 5000 in
set_option maxHeartbeats 900000 in
theorem indexedRetainedProgram_quality (C : PotentialConfig) (hp : (sourceProbability:ℝ)=C.p)
    (pair : E → BSlot b × BSlot b) (pairEq : (fun e : ↑(records.map Prod.fst).toFinset => pair e.val)=
      slotPair R.graph.ends b R.left R.right)
    (v k : ℕ) (edge : ℕ→E) (idx : ℕ→ℕ) (f : Finset E→ℝ) (M : Finset E) (τ : ℝ)
    (ht : 0<τ) (hopt : τ≤2*f M) (hτ : C.tau=τ) (hf : IsSubmodular f) (hn : ∀ T, 0≤f T)
    (D : RetainedPassData C S.ends b pair v k edge idx f M τ records) (J : ℕ) (hJ : 0<J)
    (hfails : 1/(J:ℝ)≤outerError) (hb : ∀ i, 0<b i) (rank : Slots b ↪ ℕ) (q : ℕ)
    (hcap : ∀ i, b i ≤ 2^q) :
    let out := R.indexedRetainedProgram v q hb rank f J τ
    (1000/4727+2*implementationUnit)*f M ≤ expected out.outcomes out.mass f := by
  letI : NeZero (records.map Prod.fst).length := ⟨R.nonempty.ne'⟩
  let L := records.map Prod.fst
  let h := fun j => L.getD j (R.enum 0).val
  let p := fun _ : ℕ => (sourceProbability:ℝ)
  have hpr : ∀ j<L.length,0≤p j ∧ p j≤1 := fun _ _ => by norm_num [p,sourceProbability]
  let hw := R.bounded_of_source C pair v k edge idx f M τ ht D
  have good := R.optimizer_good_physical C hp pair pairEq v k edge idx f M τ ht hopt hτ hf hn D J hJ hb rank q hcap hw
  dsimp only
  unfold indexedRetainedProgram
  rw [dif_pos hw]
  exact optimizerTrial_value (R.block v) R.grid h p hpr f τ (f M) J (R.physicalRow v q hb rank hw f τ)
    f hn (hn M) hfails good.1 good.2

end
end SubmodularMatching.AppendixM.RetainedRuntime
