import SubmodularMatching.CapacityRealBankWords
import SubmodularMatching.CapacityRealBankSpace

/-! Absolute scale for all active guesses, on any values of the source
estimator words. -/
namespace SubmodularMatching.Capacity.RealOracle
open AppendixM Streaming UpperBoundAssembly
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem advance_member_scale {X : Type*} (st : GuessBank X) (fresh : X) (W : ℝ) (span : ℕ)
    (value : ℝ) (act : ℕ → ℝ → X → X) (item : ℕ × X)
    (h : item ∈ (st.advance fresh W span value act).states) :
    item.1 ∈ (st.epoch.step W span value).active W span ∧
      (st.advance fresh W span value act).lookup item.1 = some item.2 := by
  let ep := st.epoch.step W span value
  let F := fun j => act j (ep.scale j) (if st.epoch.resets W value then fresh
    else (st.lookup j).getD fresh)
  change item ∈ (ep.active W span).map (fun j => (j,F j)) at h
  obtain ⟨j,hj,rfl⟩ := List.mem_map.mp h
  refine ⟨hj,?_⟩
  change ((ep.active W span).map (fun j => (j,F j))).lookup j = _
  generalize ep.active W span = keys at hj ⊢
  induction keys with
  | nil => simp at hj
  | cons i is ih =>
    by_cases he : j=i
    · subst i; simp
    · have hf : (j == i) = false := beq_eq_false_iff_ne.mpr he
      simpa [List.lookup,hf] using ih (by simpa [he] using hj)

theorem every_active_objective_bounds (ends : E→V×V) (cap : V→ℕ)
    (hpos : ∀ e, 0<cap (ends e).1 ∧ 0<cap (ends e).2)
    (v N bits : ℕ) (hv : 2≤v) (f : Finset E→ℝ) (edges : ℕ→E)
    (draw : ℕ→ℕ→ℕ→ℕ→ℕ) (k : ℕ) :
    let bank := forwardBank ends cap hpos v N bits f edges draw k
    ∀ a∈bank.states, let τ := bank.epoch.scale a.1
      0<τ ∧ f ∅≤τ ∧ ∀ e∈a.2.machine.edges.map Prod.fst, f {e}≤τ := by
  intro bank a hm τ
  let W := (guessWidth v:ℝ)
  let span := guessSpan v
  let val := edgeClock edges f
  let ep := RealSource.runOnlineEpoch W span val
  let act := slotAction ends cap hpos v N bits f edges draw
  let old := GuessBank.run (sparseEmpty cap) W span val act k
  have h := advance_member_scale old (sparseEmpty cap) W span (val k) (act k) a hm
  have he : old.epoch=ep k := GuessBank.clock _ _ _ _ _ _
  have he' : bank.epoch=ep (k+1) := GuessBank.clock _ _ _ _ _ _
  have hj := h.1
  rw [he] at hj
  obtain ⟨wlo,whi⟩ := guessWidth_bounds v hv
  have hw : 2≤W := by dsimp only [W]; exact_mod_cast wlo
  have hw' : W≤2^span := by dsimp only [W,span]; exact_mod_cast whi
  have ha := (RealSource.runOnlineEpoch_active_iff W span val (le_trans (by norm_num) hw)
    hw' (k+1) a.1).mp hj
  have hτ : τ=guessAnchor W val (k+1)*2^a.1 := by
    change bank.epoch.scale a.1=_
    rw [he']
    dsimp only [ep,RealSource.OnlineEpoch.scale]
    rw [(RealSource.runOnlineEpoch_real _ _ _ _).2]
  refine ⟨(ha.1.trans_le ha.2.1).trans_eq hτ.symm,
    (singleton_le_maximum val (i:=0) (k:=k+1) (by omega)).trans (ha.2.1.trans_eq hτ.symm),?_⟩
  let b := signedBirth W (f ∅) (fun i => f {edges i}) a.1 k
  let w := fun t (st : SparseSlots E cap) => slotWeight v N bits f ((ep (t+2)).scale a.1) (edges t) st (draw t a.1)
  let F := fun t (st : SparseSlots E cap) => sparseStep ends cap hpos (wordGrid v) st (edges t) (w t st)
  have hval : val=seededScale (f ∅) (fun i => f {edges i}) := by funext i; cases i <;> rfl
  have har := ha
  rw [hval] at har
  have hx := forwardBank_suffix ends cap hpos v N bits hv f edges draw k a.1 har
  have heq : a.2=suffixRun (sparseEmpty cap) F b (k-b) := Option.some.inj (h.2.symm.trans hx)
  have hl := sparseSuffix_labels ends cap hpos (wordGrid v) edges w b (k-b)
  intro e helem
  rw [heq] at helem
  obtain ⟨l,j,eqn⟩ := hl.2 e helem
  rw [eqn]
  change f {edges (b+l)} ≤ bank.epoch.scale _
  rw [he']
  exact active_edge_value W span edges f a.1 k ha _ (by omega)

end SubmodularMatching.Capacity.RealOracle
