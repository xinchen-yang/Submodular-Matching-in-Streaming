import SubmodularMatching.ReplayMemo
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Ring

/-! # Natural-number arithmetic for uncovered endpoints

Cancel the positive common factors and move all subtracted terms to the
left-hand side. The resulting boolean checker uses exact natural arithmetic.
-/

namespace SubmodularMatching.SourceCertificate.Replay

def monoNatAxisCheck (X : AppendixConeCoordinates) (weight penalty : ℕ) : Bool :=
  match X.leftDx, X.leftDh, X.rightDx, X.rightDh with
  | .ofNat ldx, .ofNat ldh, .ofNat rdx, .ofNat rdh =>
    Nat.ble (weight * ldh) (penalty * ldx) && Nat.ble (penalty * rdx) (weight * rdh)
  | _, _, _, _ => false

def monoNatGapCheck (p : AppendixBoxParameters) (t : ℕ)
    (X Y : AppendixConeCoordinates) : Bool :=
  Nat.ble (10000000 * (sourceScale + p.amax + p.bmax) * (sourceScale * sourceScale) +
      45246551 * t * (p.cHi * X.x + (sourceScale - p.cLo) * Y.x))
    (45246551 * (sourceScale * (p.amin * X.h + p.bmin * Y.h) + t * (sourceScale * sourceScale)))

def monoNatCheckRaw (box : PriceBox) (m : AppendixModeRegion)
    (x y : AppendixFastCone) (t : ℕ) : Bool :=
  match box, m, x, y with
  | ⟨ml, mh, xl, xh, yl, yh⟩, ⟨lo, hi, p⟩,
    ⟨xc, ⟨xlo, xhi, _, _, _⟩, xp⟩, ⟨yc, ⟨ylo, yhi, _, _, _⟩, yp⟩ =>
    Nat.ble lo ml && Nat.ble mh hi && !xc && !yc &&
    Nat.beq xlo xl && Nat.beq xhi xh && Nat.beq ylo yl && Nat.beq yhi yh &&
    Nat.ble p.cLo sourceScale && Nat.ble t sourceScale &&
    monoNatAxisCheck xp (p.amin * sourceScale) (t * p.cHi) &&
    monoNatAxisCheck yp (p.bmin * sourceScale) (t * (sourceScale - p.cLo)) &&
    monoNatGapCheck p t xp yp


def memoNatCheck (box : PriceBox) (w : MemoLeaf) : Bool :=
  monoNatCheckRaw box w.region.region w.xCone.cone w.yCone.cone w.multiplier

private theorem monoNatAxisCheck_sound (X : AppendixConeCoordinates) (weight penalty : ℕ)
    (h : monoNatAxisCheck X weight penalty = true) :
    X.minCheck ((weight : ℤ) * appendixDD) ((penalty : ℤ) * appendixDD) = true := by
  obtain ⟨ldx, ldh, rdx, rdh, x, height⟩ := X
  cases ldx <;> cases ldh <;> cases rdx <;> cases rdh <;>
    simp only [monoNatAxisCheck, Bool.and_eq_true, Nat.ble_eq] at h <;> try contradiction
  rename_i ldx ldh rdx rdh
  unfold AppendixConeCoordinates.minCheck
  apply decide_eq_true
  have hD : 0 ≤ appendixDD := by decide
  have hL : (weight : ℤ) * ldh ≤ (penalty : ℤ) * ldx := by exact_mod_cast h.1
  have hR : (penalty : ℤ) * rdx ≤ (weight : ℤ) * rdh := by exact_mod_cast h.2
  exact ⟨by simpa only [mul_right_comm _ appendixDD] using mul_le_mul_of_nonneg_right hL hD,
    by simpa only [mul_right_comm _ appendixDD] using mul_le_mul_of_nonneg_right hR hD⟩

private theorem monoNatGapCheck_sound (p : AppendixBoxParameters) (t : ℕ)
    (X Y : AppendixConeCoordinates) (hc : p.cLo ≤ sourceScale)
    (h : monoNatGapCheck p t X Y = true) :
    boxGapCheckCoordinates p false false t X Y = true := by
  simp only [monoNatGapCheck, Nat.ble_eq] at h
  have h' : (10000000 : ℤ) * ((sourceScale : ℤ) + p.amax + p.bmax) *
      ((sourceScale : ℤ) * sourceScale) + 45246551 * t *
        ((p.cHi : ℤ) * X.x + ((sourceScale : ℤ) - p.cLo) * Y.x) ≤
      45246551 * ((sourceScale : ℤ) * ((p.amin : ℤ) * X.h + (p.bmin : ℤ) * Y.h) +
        t * ((sourceScale : ℤ) * sourceScale)) := by
    exact_mod_cast h
  unfold boxGapCheckCoordinates
  apply decide_eq_true
  simp only [boxTargetNumerator, boxCommon, boxTargetDenominator, boxWeightX, boxWeightY,
    boxPenaltyX, boxPenaltyY, AppendixConeCoordinates.value, appendixBit, Bool.false_eq_true,
    if_false, mul_zero, sub_zero, one_mul]
  have hD : 0 ≤ appendixDD * sourceScale := by decide
  have h'' := mul_le_mul_of_nonneg_right h' hD
  unfold appendixSN appendixSD
  linear_combination h''

theorem monoNatCheckRaw_sound (box : PriceBox) (m : AppendixModeRegion)
    (x y : AppendixFastCone) (t : ℕ) (h : monoNatCheckRaw box m x y t = true) :
    memoCheckRaw box m x y t = true := by
  rcases box with ⟨ml,mh,xl,xh,yl,yh⟩
  rcases m with ⟨lo,hi,p⟩
  rcases x with ⟨xc,⟨xlo,xhi,xi,xprev,xnext⟩,xdata⟩
  rcases y with ⟨yc,⟨ylo,yhi,yi,yprev,ynext⟩,ydata⟩
  simp only [monoNatCheckRaw, Bool.and_eq_true, Nat.ble_eq, Bool.not_eq_true'] at h
  obtain ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨hl, hh⟩, hxc⟩, hyc⟩, hxl⟩, hxh⟩, hyl⟩, hyh⟩, hc⟩, ht⟩, hx⟩, hy⟩, hg⟩ := h
  simp only [memoCheckRaw, Bool.and_eq_true, decide_eq_true_eq]
  refine ⟨⟨hl,hh,hxc,hyc,Nat.eq_of_beq_eq_true hxl,Nat.eq_of_beq_eq_true hxh,
    Nat.eq_of_beq_eq_true hyl,Nat.eq_of_beq_eq_true hyh⟩, ?_, ?_, ?_,
    monoNatGapCheck_sound p t xdata ydata hc hg⟩
  · have weight : boxWeightX p false = ((p.amin * sourceScale : ℕ) : ℤ) * appendixDD := by
      simp only [boxWeightX, appendixBit, Bool.false_eq_true, if_false, mul_zero, sub_zero]
      push_cast
      ring
    have penalty : boxPenaltyX p t = ((t * p.cHi : ℕ) : ℤ) * appendixDD := by
      simp only [boxPenaltyX]
      push_cast
      rfl
    rw [weight, penalty]
    exact monoNatAxisCheck_sound _ _ _ hx
  · have weight : boxWeightY p false = ((p.bmin * sourceScale : ℕ) : ℤ) * appendixDD := by
      simp only [boxWeightY, appendixBit, Bool.false_eq_true, if_false, mul_zero, sub_zero]
      push_cast
      ring
    have penalty : boxPenaltyY p t = ((t * (sourceScale - p.cLo) : ℕ) : ℤ) * appendixDD := by
      simp only [boxPenaltyY]
      push_cast [Nat.cast_sub hc]
      rfl
    rw [weight, penalty]
    exact monoNatAxisCheck_sound _ _ _ hy
  · simp only [boxMultiplierCheck, appendixBit, Bool.false_eq_true, if_false, add_zero,
      mul_zero, sub_zero, decide_eq_true_eq]
    have hD : 0 ≤ appendixDD := by decide
    have ht' : (t : ℤ) ≤ sourceScale := by exact_mod_cast ht
    simpa only [mul_comm appendixDD] using mul_le_mul_of_nonneg_right ht' hD

theorem memoNatGoal_chunk (box : PriceBox) (tree : MidpointPartition MemoLeaf)
    (check : tree.check memoNatCheck box = true) : AppendixBoxGoal false false box :=
  AppendixBoxGoal.chunk false false box memoNatCheck
    (fun b w hb checked => memoLeaf_sound b w hb (monoNatCheckRaw_sound _ _ _ _ _ checked))
    tree check

end SubmodularMatching.SourceCertificate.Replay
