import SubmodularMatching.SourceDataBudget
import SubmodularMatching.SourceDataEndpoints
import SubmodularMatching.NumericalCertificate

/-!
# Descending source rate tables and the streaming source conditions

The rational rate table generates exactly the base interval and decreasing
list of remaining intervals consumed by the streaming update recursion.
Each tested endpoint feeds the local inequality of that interval.
-/

namespace SubmodularMatching.SourceCertificate

open Streaming MeasureTheory Set
open scoped BigOperators

structure SourceRateTable where
  count : ℕ
  high : ℕ → ℚ
  low : ℕ → ℚ
  boundary : ℕ → ℚ
  maxTotal : ℚ
  positive_count : 0 < count
  start_boundary : boundary 0 = 1 / 2
  end_boundary : boundary count = 1
  ordered_boundaries : ∀ i < count, boundary i ≤ boundary (i + 1)
  balanced_base : high 0 = low 0
  ordered_rates : ∀ i < count, low i ≤ high i
  positive_rates : ∀ i < count, 0 < low i
  total_bound : ∀ i < count, high i + low i ≤ maxTotal
  drift : ∀ i < count, 0 < i → high i < boundary i * (high i + low i)

namespace SourceRateTable

noncomputable section

def stage (R : SourceRateTable) (i : ℕ) : PotentialStage :=
  ⟨R.high i, R.low i, R.boundary i⟩

def stagesThrough (R : SourceRateTable) : ℕ → List PotentialStage
  | 0 => []
  | i + 1 => R.stage (i + 1) :: R.stagesThrough i

def stages (R : SourceRateTable) : List PotentialStage :=
  R.stagesThrough (R.count - 1)

theorem boundary_lower (R : SourceRateTable) (i : ℕ) (hi : i ≤ R.count) :
    (1 / 2 : ℚ) ≤ R.boundary i := by
  induction i with
  | zero => rw [R.start_boundary]
  | succ i ih =>
    exact (ih (Nat.le_of_succ_le hi)).trans (R.ordered_boundaries i (Nat.lt_of_succ_le hi))

theorem boundary_upper (R : SourceRateTable) (i : ℕ) (hi : i ≤ R.count) : R.boundary i ≤ 1 := by
  have hb : ∀ j ≤ R.count, i ≤ j → R.boundary i ≤ R.boundary j := by
    intro j
    induction j with
    | zero => intro _ hij; simp [Nat.eq_zero_of_le_zero hij]
    | succ j ih =>
      intro hj hij
      obtain heq | hlt := hij.eq_or_lt
      · simp [heq]
      · exact (ih (Nat.le_of_succ_le hj) (Nat.le_of_lt_succ hlt)).trans
          (R.ordered_boundaries _ (Nat.lt_of_succ_le hj))
  simpa only [R.end_boundary] using hb R.count le_rfl hi

theorem maxTotal_nonnegative (R : SourceRateTable) : 0 ≤ R.maxTotal := by
  exact (add_nonneg ((R.positive_rates 0 R.positive_count).le.trans
    (R.ordered_rates 0 R.positive_count)) (R.positive_rates 0 R.positive_count).le).trans
    (R.total_bound 0 R.positive_count)

end

/-- The four capacity classes use one shared endpoint inequality form. -/
def bitQ (b : Bool) : ℚ := if b then 1 else 0

theorem bitQ_cast (b : Bool) : (bitQ b : ℝ) = bit b := by cases b <;> norm_num [bitQ, bit]

def checkMode (R : SourceRateTable) (T : SourcePotentialTable) (D sigma : ℚ)
    (mode : ℕ) (upper i j : Bool) : Bool :=
  T.checkTableEndpoint ((1 - D * bitQ i) * R.high mode) ((1 - D * bitQ j) * R.low mode)
    (1 - D * (bitQ i + bitQ j)) (R.boundary (mode + if upper then 1 else 0))
    (sigma * (1 + (1 - bitQ i) * R.high mode + (1 - bitQ j) * R.low mode)) i j

theorem checkMode_sound (R : SourceRateTable) (T : SourcePotentialTable) (D sigma : ℚ)
    (hD : 2 * (D : ℝ) ≤ 1) (i j : Bool)
    (mode : ℕ) (hm : mode < R.count)
    (hlo : R.checkMode T D sigma mode false i j = true)
    (hhi : R.checkMode T D sigma mode true i j = true) :
    RateLocal (T.sourceFunction i) (T.sourceFunction j) (vertexCapacity (D : ℝ) i)
      (vertexCapacity (D : ℝ) j) (edgeCapacity (D : ℝ) i j) (sigma : ℝ)
      (unmatched i) (unmatched j) (R.stage mode) (R.boundary mode : ℝ) (R.boundary (mode + 1) : ℝ) := by
  intro a d ha hd
  have hs (upper : Bool) (hc : R.checkMode T D sigma mode upper i j = true) :
      (sigma : ℝ) * (1 + unmatched i * (R.high mode : ℝ) + unmatched j * (R.low mode : ℝ)) ≤
        localValue (T.value i) (T.value j) (vertexCapacity (D : ℝ) i) (vertexCapacity (D : ℝ) j)
          (R.high mode : ℝ) (R.low mode : ℝ) (edgeCapacity (D : ℝ) i j)
          (R.boundary (mode + if upper then 1 else 0) : ℝ) a d := by
    let k := mode + if upper then 1 else 0
    have hk : k ≤ R.count := by
      cases upper
      · simpa [k] using hm.le
      · simpa [k] using Nat.succ_le_of_lt hm
    have hq : 0 < R.boundary k := lt_of_lt_of_le (by norm_num) (R.boundary_lower k hk)
    have hhigh : 0 ≤ (1 - D * bitQ i) * R.high mode := by
      apply mul_nonneg _ ((R.positive_rates mode hm).le.trans (R.ordered_rates mode hm))
      have hvc := vertexCapacity_nonnegative (D : ℝ) hD i
      rw [vertexCapacity, ← bitQ_cast] at hvc
      exact_mod_cast hvc
    have hlow : 0 ≤ (1 - D * bitQ j) * R.low mode := by
      apply mul_nonneg _ (R.positive_rates mode hm).le
      have hvc := vertexCapacity_nonnegative (D : ℝ) hD j
      rw [vertexCapacity, ← bitQ_cast] at hvc
      exact_mod_cast hvc
    have hvalue := T.checkTableEndpoint_sound _ _ _ (R.boundary k) _ i j hq
      (R.boundary_upper k hk) hhigh hlow hc a d ha hd
    push_cast at hvalue
    simpa only [bitQ_cast, vertexCapacity, edgeCapacity, unmatched, gridValue, localValue, k] using hvalue
  exact ⟨by simpa [stage, SourcePotentialTable.sourceFunction] using hs false hlo,
    by simpa [stage, SourcePotentialTable.sourceFunction] using hs true hhi⟩

theorem mode_chain (R : SourceRateTable) {H J : SourceFunction} (u v q sigma mH mL : ℝ)
    (hlocal : ∀ i < R.count, RateLocal H J u v q sigma mH mL (R.stage i)
      (R.boundary i : ℝ) (R.boundary (i + 1) : ℝ))
    (n : ℕ) (hn : n < R.count) :
    RateChain H J u v q sigma mH mL (R.maxTotal : ℝ) (R.stage 0)
      (R.stagesThrough n) (R.boundary (n + 1) : ℝ) := by
  induction n with
  | zero =>
    change (1 / 2 : ℝ) ≤ (R.boundary 1 : ℝ) ∧ (R.high 0 : ℝ) = (R.low 0 : ℝ) ∧
      (0 : ℝ) < R.low 0 ∧ (R.high 0 : ℝ) + R.low 0 ≤ R.maxTotal ∧
      RateLocal H J u v q sigma mH mL (R.stage 0) (1 / 2) (R.boundary 1 : ℝ)
    refine ⟨by
      have h := (Rat.cast_le (K := ℝ)).mpr (R.boundary_lower 1 R.positive_count)
      simpa only [Rat.cast_div, Rat.cast_one, Rat.cast_ofNat] using h, by rw [R.balanced_base],
      by exact_mod_cast R.positive_rates 0 hn, by exact_mod_cast R.total_bound 0 hn, ?_⟩
    simpa [R.start_boundary] using hlocal 0 hn
  | succ n ih =>
    rw [stagesThrough, RateChain]
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, hlocal _ hn, ih (Nat.lt_of_succ_lt hn)⟩
    · change (1 / 2 : ℝ) ≤ (R.boundary (n + 1) : ℝ)
      have h := (Rat.cast_le (K := ℝ)).mpr (R.boundary_lower _ hn.le)
      simpa only [Rat.cast_div, Rat.cast_one, Rat.cast_ofNat] using h
    · change (R.boundary (n + 1) : ℝ) ≤ (R.boundary (n + 1 + 1) : ℝ)
      exact_mod_cast R.ordered_boundaries _ hn
    · change (R.low (n + 1) : ℝ) ≤ (R.high (n + 1) : ℝ)
      exact_mod_cast R.ordered_rates _ hn
    · change 0 < (R.low (n + 1) : ℝ)
      exact_mod_cast R.positive_rates _ hn
    · change (R.high (n + 1) : ℝ) < (R.boundary (n + 1) : ℝ) *
        ((R.high (n + 1) : ℝ) + (R.low (n + 1) : ℝ))
      exact_mod_cast R.drift _ hn (Nat.succ_pos n)
    · change (R.high (n + 1) : ℝ) + (R.low (n + 1) : ℝ) ≤ (R.maxTotal : ℝ)
      exact_mod_cast R.total_bound _ hn

theorem runSourceConditions (R : SourceRateTable) (T : SourcePotentialTable)
    (D sigma p : ℚ) (C : PotentialConfig)
    (hbase : C.base = R.stage 0) (hstages : C.stages = R.stages) (hp : C.p = (p : ℝ))
    (hD : 2 * (D : ℝ) ≤ 1)
    (hchecks : ∀ mode < R.count, ∀ hi i j, R.checkMode T D sigma mode hi i j = true)
    (hbudget : ∀ i, (∫ a in Ioi (0 : ℝ), T.value i a / a ^ 2) ≤ 1 / (1 + (p : ℝ) * R.maxTotal)) :
    RunSourceConditions T.sourceFunction C (D : ℝ) (sigma : ℝ) (R.maxTotal : ℝ) := by
  refine ⟨by exact_mod_cast R.maxTotal_nonnegative, hD, ?_, fun i => ?_⟩
  · intro i j
    rw [hbase, hstages, stages, ← Rat.cast_one, ← R.end_boundary,
      ← Nat.sub_add_cancel R.positive_count]
    convert R.mode_chain _ _ _ _ _ _ (fun m hm => R.checkMode_sound T D sigma hD i j m hm
      (hchecks m hm false i j) (hchecks m hm true i j)) (R.count - 1)
      (Nat.sub_lt R.positive_count Nat.one_pos) using 1
  · rw [hp]
    exact hbudget i

end SourceRateTable

end SubmodularMatching.SourceCertificate
