import SubmodularMatching.NonmonotoneOptimizerEncoding
import Mathlib.Data.List.Sort
import Mathlib.Data.List.FinRange

/-! Computing the order used by the two-chain payoff at a rational state. -/

namespace SubmodularMatching.NonmonotoneOptimizer

variable {n : ℕ}

def sortedIds (key : Fin n → ℚ) : List (Fin n) :=
  (List.finRange n).mergeSort fun i j => decide (key i ≤ key j)

theorem sortedIds_perm (key : Fin n → ℚ) : (sortedIds key).Perm (List.finRange n) := List.mergeSort_perm _ _

@[simp] theorem sortedIds_length (key : Fin n → ℚ) : (sortedIds key).length = n :=
  (sortedIds_perm key).length_eq.trans List.length_finRange

def rankToId (key : Fin n → ℚ) (i : Fin n) : Fin n :=
  (sortedIds key)[i.val]'(by rw [sortedIds_length]; exact i.isLt)

def idToRank (key : Fin n → ℚ) (j : Fin n) : Fin n :=
  ⟨(sortedIds key).idxOf j, by
    exact (List.idxOf_lt_length_of_mem ((sortedIds_perm key).mem_iff.mpr (List.mem_finRange j))).trans_eq (sortedIds_length key)⟩

/-- Executable rank permutation, with a scan for the inverse. -/
def chainOrder (key : Fin n → ℚ) : Equiv.Perm (Fin n) where
  toFun := rankToId key
  invFun := idToRank key
  left_inv i := by
    apply Fin.ext
    apply List.Nodup.idxOf_getElem
    exact (sortedIds_perm key).nodup_iff.mpr (List.nodup_finRange n)
  right_inv j := List.getElem_idxOf _

theorem chainOrder_monotone (key : Fin n → ℚ) : Monotone (fun i => key (chainOrder key i)) := by
  have hh : (sortedIds key).Pairwise (fun i j => decide (key i ≤ key j) = true) :=
    List.pairwise_mergeSort (le := fun i j => decide (key i ≤ key j)) (fun i j l h₁ h₂ => decide_eq_true (le_trans (of_decide_eq_true h₁) (of_decide_eq_true h₂)))
      (fun i j => by simpa only [Bool.or_eq_true,decide_eq_true_eq] using le_total (key i) (key j)) _
  intro i j hij
  rcases lt_or_eq_of_le hij with h | rfl
  · have h' := List.pairwise_iff_getElem.mp hh i j (by simpa using i.isLt) (by simpa using j.isLt) h
    exact of_decide_eq_true h'
  · exact le_rfl

/-- Sorting by the rational numerator of `μ_e` sorts its real value since the
positive denominator `c` is common to every coordinate. -/
theorem chainOrder_weight (u : Fin n → ℚ) (c : ℝ) (hc : 0 < c) :
    let perm := chainOrder (fun i => u i*(1-u i))
    Monotone (fun i => weight c (u (perm i):ℝ)) := by
  intro perm i j hij
  have h := chainOrder_monotone (fun i => u i*(1-u i)) hij
  unfold weight
  apply div_le_div_of_nonneg_right _ hc.le
  exact_mod_cast h

end SubmodularMatching.NonmonotoneOptimizer
