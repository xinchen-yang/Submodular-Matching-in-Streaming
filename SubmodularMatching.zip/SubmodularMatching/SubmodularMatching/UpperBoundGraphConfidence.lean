import SubmodularMatching.UpperBoundGeneralInput
import SubmodularMatching.UpperBoundConfidence

/-! # The paper's confidence guarantee with a rational program parameter -/

namespace SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream

open GibbsSampler NumericalCertificate

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- For each fixed real exponent, the integer budget passed to the
algorithm gives the exact (n^{-c}) upper bound on failure. -/
theorem theorem1_1_confidence (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (h0 : 0 ≤ f ∅)
    (hcert : ∀ hn : 2 ≤ Fintype.card V, AppendixSourceObligation (Fintype.card V) hn)
    (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (hn : 1 ≤ Fintype.card V) (c : ℝ) :
    let n := Fintype.card V
    let delta := (((n : ℝ) ^ ⌈c⌉₊)⁻¹)
    let q := S.amplifiedOutput f hf hmono delta
    q.outcomes ⊆ S.matchings ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤
        (n : ℝ) ^ (-c) := by
  classical
  dsimp only
  have hn' : (0 : ℝ) < Fintype.card V := by exact_mod_cast (Nat.zero_lt_one.trans_le hn)
  let delta := (((Fintype.card V : ℝ) ^ ⌈c⌉₊)⁻¹)
  have hδ : 0 < delta := inv_pos.mpr (pow_pos hn' _)
  have h := S.theorem1_1_value f hf hmono h0 hcert O hO hopt delta hδ
  exact ⟨h.2.1, h.2.2.2.trans (confidence_integer_le _ hn c)⟩

end

end SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream
