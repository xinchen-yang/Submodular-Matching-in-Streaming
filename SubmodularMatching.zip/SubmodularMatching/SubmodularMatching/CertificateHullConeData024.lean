import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull024_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1017, 1019, 1, 0x1fdbf9⟩ (by decide +kernel)

private def hull024_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1016, 1017, 1, 0x1fcbf8⟩ (by decide +kernel)

private def hull024_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1017, 1018, 1, 0x1fd3f9⟩ (by decide +kernel)

private def hull024_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1018, 1019, 1, 0x1fdbfa⟩ (by decide +kernel)

private def hull024_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1016, 1019, 1, 0x1fdbf8⟩ (by decide +kernel)

private def hull024_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1014, 1019, 1, 0x1fdbf6⟩ (by decide +kernel)

private def hull024_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1010, 1019, 1, 0x1fdbf2⟩ (by decide +kernel)

private def hull024_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1019, 1023, 1, 0x1ffbfb⟩ (by decide +kernel)

private def hull024_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1023, 1028, 1, 0x2023ff⟩ (by decide +kernel)

private def hull024_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1019, 1021, 2, 0xff5fe3fb⟩ (by decide +kernel)

private def hull024_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1021, 1023, 1, 0x1ffbfd⟩ (by decide +kernel)

private def hull024_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1019, 1020, 1, 0x1fe3fb⟩ (by decide +kernel)

private def hull024_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1020, 1021, 1, 0x1febfc⟩ (by decide +kernel)

private def hull024_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1021, 1022, 1, 0x1ff3fd⟩ (by decide +kernel)

private def hull024_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1022, 1023, 1, 0x1ffbfe⟩ (by decide +kernel)

private def hull024_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1023, 1024, 1, 0x2003ff⟩ (by decide +kernel)

private def hull024_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1024, 1025, 1, 0x200c00⟩ (by decide +kernel)

private def hull024_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1025, 1028, 1, 0x202401⟩ (by decide +kernel)

private def hull024_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1023, 1025, 1, 0x200bff⟩ (by decide +kernel)

private def hull024_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1025, 1026, 1, 0x201401⟩ (by decide +kernel)

private def hull024_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1026, 1028, 1, 0x202402⟩ (by decide +kernel)

private def hull024_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1026, 1027, 1, 0x201c02⟩ (by decide +kernel)

private def hull024_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1027, 1028, 1, 0x202403⟩ (by decide +kernel)

private def hull024_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1019, 1028, 1, 0x2023fb⟩ (by decide +kernel)

private def hull024_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1010, 1028, 1, 0x2023f2⟩ (by decide +kernel)

private def hull024_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1028, 1037, 1, 0x206c04⟩ (by decide +kernel)

private def hull024_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1037, 1046, 3, 0x82d04e0940d⟩ (by decide +kernel)

private def hull024_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1046, 1064, 4, 0x42884f09211c16⟩ (by decide +kernel)

private def hull024_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1028, 1032, 1, 0x204404⟩ (by decide +kernel)

private def hull024_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1032, 1037, 1, 0x206c08⟩ (by decide +kernel)

private def hull024_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1028, 1030, 1, 0x203404⟩ (by decide +kernel)

private def hull024_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1030, 1032, 1, 0x204406⟩ (by decide +kernel)

private def hull024_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1028, 1029, 1, 0x202c04⟩ (by decide +kernel)

private def hull024_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1029, 1030, 1, 0x203405⟩ (by decide +kernel)

private def hull024_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1030, 1031, 1, 0x203c06⟩ (by decide +kernel)

private def hull024_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1031, 1032, 1, 0x204407⟩ (by decide +kernel)

private def hull024_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 993, 1028, 1, 0x2023e1⟩ (by decide +kernel)

private def hull024_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1032, 1033, 1, 0x204c08⟩ (by decide +kernel)

private def hull024_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1033, 1034, 1, 0x205409⟩ (by decide +kernel)

private def hull024_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1034, 1037, 1, 0x206c0a⟩ (by decide +kernel)

private def hull024_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1032, 1034, 1, 0x205408⟩ (by decide +kernel)

private def hull024_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1034, 1035, 1, 0x205c0a⟩ (by decide +kernel)

private def hull024_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1035, 1037, 2, 0x10360640b⟩ (by decide +kernel)

private def hull024_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1037, 1039, 2, 0x103e0740d⟩ (by decide +kernel)

private def hull024_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1039, 1041, 1, 0x208c0f⟩ (by decide +kernel)

private def hull024_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1041, 1046, 3, 0x82d04e09411⟩ (by decide +kernel)

private def hull024_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1037, 1038, 1, 0x20740d⟩ (by decide +kernel)

private def hull024_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1038, 1039, 1, 0x207c0e⟩ (by decide +kernel)

private def hull024_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1039, 1040, 1, 0x20840f⟩ (by decide +kernel)

private def hull024_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1040, 1041, 1, 0x208c10⟩ (by decide +kernel)

private def hull024_050 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1037, 1041, 1, 0x208c0d⟩ (by decide +kernel)

private def hull024_051 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1028, 1046, 2, 0x105a09c04⟩ (by decide +kernel)

private def hull024_052 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1041, 1043, 2, 0x104e09411⟩ (by decide +kernel)

private def hull024_053 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1043, 1044, 1, 0x20a413⟩ (by decide +kernel)

private def hull024_054 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1044, 1046, 1, 0x20b414⟩ (by decide +kernel)

private def hull024_055 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 70, 61, 0x2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull024_056 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1044, 1045, 1, 0x20ac14⟩ (by decide +kernel)

private def hull024_057 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1045, 1046, 1, 0x20b415⟩ (by decide +kernel)

private def hull024_058 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 35, 18, 0x8c1102104007c0f01d03806c0d01903005c0b01502804c09011⟩ (by decide +kernel)

private def hull024_059 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1046, 1048, 1, 0x20c416⟩ (by decide +kernel)

private def hull024_060 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1048, 1050, 1, 0x20d418⟩ (by decide +kernel)

private def hull024_061 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1050, 1055, 1, 0x20fc1a⟩ (by decide +kernel)

private def hull024_062 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1055, 1064, 5, 0x21442784908e1141f⟩ (by decide +kernel)

private def hull024_063 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1046, 1050, 1, 0x20d416⟩ (by decide +kernel)

private def hull024_064 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1046, 1047, 1, 0x20bc16⟩ (by decide +kernel)

private def hull024_065 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1047, 1048, 1, 0x20c417⟩ (by decide +kernel)

private def hull024_066 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1046, 1055, 1, 0x20fc16⟩ (by decide +kernel)

private def hull024_067 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1048, 1049, 1, 0x20cc18⟩ (by decide +kernel)

private def hull024_068 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1049, 1050, 1, 0x20d419⟩ (by decide +kernel)

private def hull024_069 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1050, 1052, 2, 0x10720dc1a⟩ (by decide +kernel)

private def hull024_070 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1052, 1055, 1, 0x20fc1c⟩ (by decide +kernel)

private def hull024_071 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1052, 1053, 1, 0x20ec1c⟩ (by decide +kernel)

private def supportedCone3072 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1017, 1019, 1017, 1017, 1019⟩, ⟨0, 0, 3979577012800, 1846933261, 67161634157050, 1013755348964⟩⟩
    hull024_000 0 (by decide +kernel)

private def supportedCone3073 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1016, 1017, 1017, 1016, 1017⟩, ⟨3756962961951, 1856841090, 0, 0, 67161634157050, 1013755348964⟩⟩
    hull024_001 1 (by decide +kernel)

private def supportedCone3074 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1017, 1018, 1017, 1017, 1018⟩, ⟨0, 0, 1866703711610, 942526941, 67161634157050, 1013755348964⟩⟩
    hull024_002 0 (by decide +kernel)

private def supportedCone3075 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1018, 1019, 1018, 1018, 1019⟩, ⟨0, 0, 2112873301190, 904406320, 69028337868660, 1014697875905⟩⟩
    hull024_003 0 (by decide +kernel)

private def supportedCone3076 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1017, 1018, 1018, 1017, 1018⟩, ⟨1866703711610, 942526941, 0, 0, 69028337868660, 1014697875905⟩⟩
    hull024_002 1 (by decide +kernel)

private def supportedCone3077 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1018, 1019, 1019, 1018, 1019⟩, ⟨2112873301190, 904406320, 0, 0, 71141211169850, 1015602282225⟩⟩
    hull024_003 1 (by decide +kernel)

private def supportedCone3078 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1016, 1019, 1019, 1016, 1019⟩, ⟨7736539974751, 3703774351, 0, 0, 71141211169850, 1015602282225⟩⟩
    hull024_004 1 (by decide +kernel)

private def supportedCone3079 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1017, 1019, 1019, 1017, 1019⟩, ⟨3979577012800, 1846933261, 0, 0, 71141211169850, 1015602282225⟩⟩
    hull024_000 1 (by decide +kernel)

private def supportedCone3080 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1014, 1019, 1019, 1014, 1019⟩, ⟨11283341720784, 5769747636, 0, 0, 71141211169850, 1015602282225⟩⟩
    hull024_005 1 (by decide +kernel)

private def supportedCone3081 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1019, 1019, 1010, 1019⟩, ⟨16966894562130, 9510597105, 0, 0, 71141211169850, 1015602282225⟩⟩
    hull024_006 1 (by decide +kernel)

private def supportedCone3082 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1019, 1023, 1019, 1019, 1023⟩, ⟨0, 0, 13410276768084, 4880031180, 71141211169850, 1015602282225⟩⟩
    hull024_007 0 (by decide +kernel)

private def supportedCone3083 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1023, 1028, 1023, 1023, 1028⟩, ⟨0, 0, 15938143809414, 4157351199, 84551487937934, 1020482313405⟩⟩
    hull024_008 0 (by decide +kernel)

private def supportedCone3084 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1019, 1021, 1019, 1019, 1020⟩, ⟨0, 0, 4215381775437, 1692301235, 71141211169850, 1015602282225⟩⟩
    hull024_009 0 (by decide +kernel)

private def supportedCone3085 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1021, 1023, 1021, 1021, 1023⟩, ⟨0, 0, 7916994997164, 2653261841, 76634492940770, 1017829051564⟩⟩
    hull024_010 0 (by decide +kernel)

private def supportedCone3086 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1019, 1021, 1020, 1019, 1021⟩, ⟨4215381775437, 1692301235, 1277899995483, 534468104, 75356592945287, 1017294583460⟩⟩
    hull024_009 1 (by decide +kernel)

private def supportedCone3087 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1019, 1020, 1019, 1019, 1020⟩, ⟨0, 0, 4215381775437, 1692301235, 71141211169850, 1015602282225⟩⟩
    hull024_011 0 (by decide +kernel)

private def supportedCone3088 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1020, 1021, 1020, 1020, 1021⟩, ⟨0, 0, 1277899995483, 534468104, 75356592945287, 1017294583460⟩⟩
    hull024_012 0 (by decide +kernel)

private def supportedCone3089 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1019, 1021, 1021, 1020, 1021⟩, ⟨1277899995483, 534468104, 0, 0, 76634492940770, 1017829051564⟩⟩
    hull024_009 2 (by decide +kernel)

private def supportedCone3090 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1021, 1022, 1022, 1021, 1022⟩, ⟨3187258853194, 1111521642, 0, 0, 79821751793964, 1018940573206⟩⟩
    hull024_013 1 (by decide +kernel)

private def supportedCone3091 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1022, 1023, 1022, 1022, 1023⟩, ⟨0, 0, 4729736143970, 1541740199, 79821751793964, 1018940573206⟩⟩
    hull024_014 0 (by decide +kernel)

private def supportedCone3092 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1021, 1023, 1023, 1021, 1023⟩, ⟨7916994997164, 2653261841, 0, 0, 84551487937934, 1020482313405⟩⟩
    hull024_010 1 (by decide +kernel)

private def supportedCone3093 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1021, 1022, 1021, 1021, 1022⟩, ⟨0, 0, 3187258853194, 1111521642, 76634492940770, 1017829051564⟩⟩
    hull024_013 0 (by decide +kernel)

private def supportedCone3094 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1022, 1023, 1023, 1022, 1023⟩, ⟨4729736143970, 1541740199, 0, 0, 84551487937934, 1020482313405⟩⟩
    hull024_014 1 (by decide +kernel)

private def supportedCone3095 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1019, 1023, 1023, 1019, 1023⟩, ⟨13410276768084, 4880031180, 0, 0, 84551487937934, 1020482313405⟩⟩
    hull024_007 1 (by decide +kernel)

private def supportedCone3096 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1023, 1024, 1023, 1023, 1024⟩, ⟨0, 0, 591418413076, 218583139, 84551487937934, 1020482313405⟩⟩
    hull024_015 0 (by decide +kernel)

private def supportedCone3097 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1024, 1025, 1024, 1024, 1025⟩, ⟨0, 0, 4418572216529, 1270091927, 85142906351010, 1020700896544⟩⟩
    hull024_016 0 (by decide +kernel)

private def supportedCone3098 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1025, 1028, 1025, 1025, 1028⟩, ⟨0, 0, 10928153179809, 2668676133, 89561478567539, 1021970988471⟩⟩
    hull024_017 0 (by decide +kernel)

private def supportedCone3099 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1023, 1024, 1024, 1023, 1024⟩, ⟨591418413076, 218583139, 0, 0, 85142906351010, 1020700896544⟩⟩
    hull024_015 1 (by decide +kernel)

private def supportedCone3100 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1024, 1025, 1025, 1024, 1025⟩, ⟨4418572216529, 1270091927, 0, 0, 89561478567539, 1021970988471⟩⟩
    hull024_016 1 (by decide +kernel)

private def supportedCone3101 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1023, 1025, 1025, 1023, 1025⟩, ⟨5009990629605, 1488675066, 0, 0, 89561478567539, 1021970988471⟩⟩
    hull024_018 1 (by decide +kernel)

private def supportedCone3102 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1025, 1026, 1025, 1025, 1026⟩, ⟨0, 0, 3639286318291, 983178315, 89561478567539, 1021970988471⟩⟩
    hull024_019 0 (by decide +kernel)

private def supportedCone3103 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1026, 1028, 1026, 1026, 1028⟩, ⟨0, 0, 7288866861518, 1685497818, 93200764885830, 1022954166786⟩⟩
    hull024_020 0 (by decide +kernel)

def appendixHullConeBlock0096 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone3072,
    supportedCone3073,
    supportedCone3074,
    supportedCone3075,
    supportedCone3076,
    supportedCone3077,
    supportedCone3078,
    supportedCone3079,
    supportedCone3080,
    supportedCone3081,
    supportedCone3082,
    supportedCone3083,
    supportedCone3084,
    supportedCone3085,
    supportedCone3086,
    supportedCone3087,
    supportedCone3088,
    supportedCone3089,
    supportedCone3090,
    supportedCone3091,
    supportedCone3092,
    supportedCone3093,
    supportedCone3094,
    supportedCone3095,
    supportedCone3096,
    supportedCone3097,
    supportedCone3098,
    supportedCone3099,
    supportedCone3100,
    supportedCone3101,
    supportedCone3102,
    supportedCone3103,
  ], rfl⟩

private def supportedCone3104 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1025, 1026, 1026, 1025, 1026⟩, ⟨3639286318291, 983178315, 0, 0, 93200764885830, 1022954166786⟩⟩
    hull024_019 1 (by decide +kernel)

private def supportedCone3105 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1026, 1027, 1026, 1026, 1027⟩, ⟨0, 0, 1667564919221, 449556633, 93200764885830, 1022954166786⟩⟩
    hull024_021 0 (by decide +kernel)

private def supportedCone3106 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1027, 1028, 1027, 1027, 1028⟩, ⟨0, 0, 5621301942297, 1235941185, 94868329805051, 1023403723419⟩⟩
    hull024_022 0 (by decide +kernel)

private def supportedCone3107 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1026, 1027, 1027, 1026, 1027⟩, ⟨1667564919221, 449556633, 0, 0, 94868329805051, 1023403723419⟩⟩
    hull024_021 1 (by decide +kernel)

private def supportedCone3108 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1027, 1028, 1028, 1027, 1028⟩, ⟨5621301942297, 1235941185, 0, 0, 100489631747348, 1024639664604⟩⟩
    hull024_022 1 (by decide +kernel)

private def supportedCone3109 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1026, 1028, 1028, 1026, 1028⟩, ⟨7288866861518, 1685497818, 0, 0, 100489631747348, 1024639664604⟩⟩
    hull024_020 1 (by decide +kernel)

private def supportedCone3110 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1023, 1028, 1028, 1023, 1028⟩, ⟨15938143809414, 4157351199, 0, 0, 100489631747348, 1024639664604⟩⟩
    hull024_008 1 (by decide +kernel)

private def supportedCone3111 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1019, 1028, 1028, 1019, 1028⟩, ⟨29348420577498, 9037382379, 0, 0, 100489631747348, 1024639664604⟩⟩
    hull024_023 1 (by decide +kernel)

private def supportedCone3112 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1028, 1028, 1010, 1028⟩, ⟨46315315139628, 18547979484, 0, 0, 100489631747348, 1024639664604⟩⟩
    hull024_024 1 (by decide +kernel)

private def supportedCone3113 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1037, 1028, 1028, 1037⟩, ⟨0, 0, 49866538340834, 7617240040, 100489631747348, 1024639664604⟩⟩
    hull024_025 0 (by decide +kernel)

private def supportedCone3114 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1037, 1046, 1037, 1037, 1042⟩, ⟨0, 0, 26491468271418, 2309871068, 150356170088182, 1032256904644⟩⟩
    hull024_026 0 (by decide +kernel)

private def supportedCone3115 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1046, 1064, 1046, 1046, 1059⟩, ⟨0, 0, 187672694333755, 11971832663, 212383735315242, 1040185243661⟩⟩
    hull024_027 0 (by decide +kernel)

private def supportedCone3116 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1032, 1028, 1028, 1032⟩, ⟨0, 0, 15926127896522, 3342944928, 100489631747348, 1024639664604⟩⟩
    hull024_028 0 (by decide +kernel)

private def supportedCone3117 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1032, 1037, 1032, 1032, 1037⟩, ⟨0, 0, 33940410444312, 4274295112, 116415759643870, 1027982609532⟩⟩
    hull024_029 0 (by decide +kernel)

private def supportedCone3118 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1030, 1028, 1028, 1030⟩, ⟨0, 0, 5954385022725, 1294718761, 100489631747348, 1024639664604⟩⟩
    hull024_030 0 (by decide +kernel)

private def supportedCone3119 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1030, 1032, 1030, 1030, 1032⟩, ⟨0, 0, 9971742873797, 2048226167, 106444016770073, 1025934383365⟩⟩
    hull024_031 0 (by decide +kernel)

private def supportedCone3120 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1030, 1030, 1028, 1030⟩, ⟨5954385022725, 1294718761, 0, 0, 106444016770073, 1025934383365⟩⟩
    hull024_030 1 (by decide +kernel)

private def supportedCone3121 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1029, 1029, 1028, 1029⟩, ⟨4371587810082, 950712309, 0, 0, 104861219557430, 1025590376913⟩⟩
    hull024_032 1 (by decide +kernel)

private def supportedCone3122 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1029, 1028, 1028, 1029⟩, ⟨0, 0, 4371587810082, 950712309, 100489631747348, 1024639664604⟩⟩
    hull024_032 0 (by decide +kernel)

private def supportedCone3123 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1029, 1030, 1029, 1029, 1030⟩, ⟨0, 0, 1582797212643, 344006452, 104861219557430, 1025590376913⟩⟩
    hull024_033 0 (by decide +kernel)

private def supportedCone3124 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1029, 1030, 1030, 1029, 1030⟩, ⟨1582797212643, 344006452, 0, 0, 106444016770073, 1025934383365⟩⟩
    hull024_033 1 (by decide +kernel)

private def supportedCone3125 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1030, 1031, 1030, 1030, 1031⟩, ⟨0, 0, 6307204516460, 1318268856, 106444016770073, 1025934383365⟩⟩
    hull024_034 0 (by decide +kernel)

private def supportedCone3126 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1031, 1032, 1031, 1031, 1032⟩, ⟨0, 0, 3664538357337, 729957311, 112751221286533, 1027252652221⟩⟩
    hull024_035 0 (by decide +kernel)

private def supportedCone3127 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1030, 1031, 1031, 1030, 1031⟩, ⟨6307204516460, 1318268856, 0, 0, 112751221286533, 1027252652221⟩⟩
    hull024_034 1 (by decide +kernel)

private def supportedCone3128 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 1028, 1028, 993, 1028⟩, ⟨66829078118289, 41514198640, 0, 0, 100489631747348, 1024639664604⟩⟩
    hull024_036 1 (by decide +kernel)

private def supportedCone3129 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1031, 1032, 1032, 1031, 1032⟩, ⟨3664538357337, 729957311, 0, 0, 116415759643870, 1027982609532⟩⟩
    hull024_035 1 (by decide +kernel)

private def supportedCone3130 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1032, 1032, 1028, 1032⟩, ⟨15926127896522, 3342944928, 0, 0, 116415759643870, 1027982609532⟩⟩
    hull024_028 1 (by decide +kernel)

private def supportedCone3131 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1030, 1032, 1032, 1030, 1032⟩, ⟨9971742873797, 2048226167, 0, 0, 116415759643870, 1027982609532⟩⟩
    hull024_031 1 (by decide +kernel)

private def supportedCone3132 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1032, 1033, 1032, 1032, 1033⟩, ⟨0, 0, 3016391522179, 574670349, 116415759643870, 1027982609532⟩⟩
    hull024_037 0 (by decide +kernel)

private def supportedCone3133 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1033, 1034, 1033, 1033, 1034⟩, ⟨0, 0, 7076799862526, 848247706, 119432151166049, 1028557279881⟩⟩
    hull024_038 0 (by decide +kernel)

private def supportedCone3134 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1034, 1037, 1034, 1034, 1037⟩, ⟨0, 0, 23847219059607, 2851377057, 126508951028575, 1029405527587⟩⟩
    hull024_039 0 (by decide +kernel)

private def supportedCone3135 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1032, 1033, 1033, 1032, 1033⟩, ⟨3016391522179, 574670349, 0, 0, 119432151166049, 1028557279881⟩⟩
    hull024_037 1 (by decide +kernel)

def appendixHullConeBlock0097 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone3104,
    supportedCone3105,
    supportedCone3106,
    supportedCone3107,
    supportedCone3108,
    supportedCone3109,
    supportedCone3110,
    supportedCone3111,
    supportedCone3112,
    supportedCone3113,
    supportedCone3114,
    supportedCone3115,
    supportedCone3116,
    supportedCone3117,
    supportedCone3118,
    supportedCone3119,
    supportedCone3120,
    supportedCone3121,
    supportedCone3122,
    supportedCone3123,
    supportedCone3124,
    supportedCone3125,
    supportedCone3126,
    supportedCone3127,
    supportedCone3128,
    supportedCone3129,
    supportedCone3130,
    supportedCone3131,
    supportedCone3132,
    supportedCone3133,
    supportedCone3134,
    supportedCone3135,
  ], rfl⟩

private def supportedCone3136 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1033, 1034, 1034, 1033, 1034⟩, ⟨7076799862526, 848247706, 0, 0, 126508951028575, 1029405527587⟩⟩
    hull024_038 1 (by decide +kernel)

private def supportedCone3137 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1032, 1034, 1034, 1032, 1034⟩, ⟨10093191384705, 1422918055, 0, 0, 126508951028575, 1029405527587⟩⟩
    hull024_040 1 (by decide +kernel)

private def supportedCone3138 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1034, 1035, 1034, 1034, 1035⟩, ⟨0, 0, 7496126616714, 898140748, 126508951028575, 1029405527587⟩⟩
    hull024_041 0 (by decide +kernel)

private def supportedCone3139 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1035, 1037, 1035, 1035, 1036⟩, ⟨0, 0, 7940300043155, 948506796, 134005077645289, 1030303668335⟩⟩
    hull024_042 0 (by decide +kernel)

private def supportedCone3140 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1034, 1035, 1035, 1034, 1035⟩, ⟨7496126616714, 898140748, 0, 0, 134005077645289, 1030303668335⟩⟩
    hull024_041 1 (by decide +kernel)

private def supportedCone3141 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1035, 1037, 1037, 1036, 1037⟩, ⟨8410792399738, 1004729513, 0, 0, 150356170088182, 1032256904644⟩⟩
    hull024_042 2 (by decide +kernel)

private def supportedCone3142 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1034, 1037, 1037, 1034, 1037⟩, ⟨23847219059607, 2851377057, 0, 0, 150356170088182, 1032256904644⟩⟩
    hull024_039 1 (by decide +kernel)

private def supportedCone3143 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1035, 1037, 1036, 1035, 1037⟩, ⟨7940300043155, 948506796, 8410792399738, 1004729513, 141945377688444, 1031252175131⟩⟩
    hull024_042 1 (by decide +kernel)

private def supportedCone3144 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1032, 1037, 1037, 1032, 1037⟩, ⟨33940410444312, 4274295112, 0, 0, 150356170088182, 1032256904644⟩⟩
    hull024_029 1 (by decide +kernel)

private def supportedCone3145 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1037, 1039, 1037, 1037, 1038⟩, ⟨0, 0, 8909163181115, 1049708369, 150356170088182, 1032256904644⟩⟩
    hull024_043 0 (by decide +kernel)

private def supportedCone3146 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1039, 1041, 1039, 1039, 1041⟩, ⟨0, 0, 15174579995330, 955460710, 160341341049180, 1033500159540⟩⟩
    hull024_044 0 (by decide +kernel)

private def supportedCone3147 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1041, 1046, 1041, 1041, 1042⟩, ⟨0, 0, 1331717315090, 111155462, 175515921044510, 1034455620250⟩⟩
    hull024_045 0 (by decide +kernel)

private def supportedCone3148 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1037, 1037, 1028, 1037⟩, ⟨49866538340834, 7617240040, 0, 0, 150356170088182, 1032256904644⟩⟩
    hull024_025 1 (by decide +kernel)

private def supportedCone3149 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1037, 1039, 1038, 1037, 1039⟩, ⟨8909163181115, 1049708369, 1076007779883, 193546527, 159265333269297, 1033306613013⟩⟩
    hull024_043 1 (by decide +kernel)

private def supportedCone3150 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1037, 1038, 1037, 1037, 1038⟩, ⟨0, 0, 8909163181115, 1049708369, 150356170088182, 1032256904644⟩⟩
    hull024_046 0 (by decide +kernel)

private def supportedCone3151 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1037, 1038, 1038, 1037, 1038⟩, ⟨8909163181115, 1049708369, 0, 0, 159265333269297, 1033306613013⟩⟩
    hull024_046 1 (by decide +kernel)

private def supportedCone3152 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1038, 1039, 1038, 1038, 1039⟩, ⟨0, 0, 1076007779883, 193546527, 159265333269297, 1033306613013⟩⟩
    hull024_047 0 (by decide +kernel)

private def supportedCone3153 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1037, 1039, 1039, 1038, 1039⟩, ⟨1076007779883, 193546527, 0, 0, 160341341049180, 1033500159540⟩⟩
    hull024_043 2 (by decide +kernel)

private def supportedCone3154 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1039, 1040, 1039, 1039, 1040⟩, ⟨0, 0, 8361056507925, 625376323, 160341341049180, 1033500159540⟩⟩
    hull024_048 0 (by decide +kernel)

private def supportedCone3155 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1040, 1041, 1040, 1040, 1041⟩, ⟨0, 0, 6813523487405, 330084387, 168702397557105, 1034125535863⟩⟩
    hull024_049 0 (by decide +kernel)

private def supportedCone3156 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1039, 1040, 1040, 1039, 1040⟩, ⟨8361056507925, 625376323, 0, 0, 168702397557105, 1034125535863⟩⟩
    hull024_048 1 (by decide +kernel)

private def supportedCone3157 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1039, 1041, 1041, 1039, 1041⟩, ⟨15174579995330, 955460710, 0, 0, 175515921044510, 1034455620250⟩⟩
    hull024_044 1 (by decide +kernel)

private def supportedCone3158 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1037, 1041, 1041, 1037, 1041⟩, ⟨25159750956328, 2198715606, 0, 0, 175515921044510, 1034455620250⟩⟩
    hull024_050 1 (by decide +kernel)

private def supportedCone3159 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1041, 1046, 1042, 1041, 1043⟩, ⟨1331717315090, 111155462, 1851004699103, 174904249, 176847638359600, 1034566775712⟩⟩
    hull024_045 1 (by decide +kernel)

private def supportedCone3160 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1037, 1046, 1042, 1037, 1043⟩, ⟨26491468271418, 2309871068, 1851004699103, 174904249, 176847638359600, 1034566775712⟩⟩
    hull024_026 1 (by decide +kernel)

private def supportedCone3161 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1037, 1046, 1043, 1042, 1046⟩, ⟨1851004699103, 174904249, 33685092256539, 5443563700, 178698643058703, 1034741679961⟩⟩
    hull024_026 2 (by decide +kernel)

private def supportedCone3162 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1046, 1043, 1028, 1046⟩, ⟨78209011311355, 10102015357, 33685092256539, 5443563700, 178698643058703, 1034741679961⟩⟩
    hull024_051 1 (by decide +kernel)

private def supportedCone3163 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1041, 1043, 1043, 1042, 1043⟩, ⟨1851004699103, 174904249, 0, 0, 178698643058703, 1034741679961⟩⟩
    hull024_052 2 (by decide +kernel)

private def supportedCone3164 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1043, 1044, 1043, 1043, 1044⟩, ⟨0, 0, 10588560285355, 2610737769, 178698643058703, 1034741679961⟩⟩
    hull024_053 0 (by decide +kernel)

private def supportedCone3165 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1044, 1046, 1044, 1044, 1046⟩, ⟨0, 0, 23096531971184, 2832825931, 189287203344058, 1037352417730⟩⟩
    hull024_054 0 (by decide +kernel)

private def supportedCone3166 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1046, 1046, 1043, 1046⟩, ⟨33685092256539, 5443563700, 0, 0, 212383735315242, 1040185243661⟩⟩
    hull024_051 2 (by decide +kernel)

private def supportedCone3167 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 60, 59, 61⟩, ⟨1135985046, 115441792, 1317712249, 141660608, 290000000000, 2937838851⟩⟩
    hull024_055 51 (by decide +kernel)

def appendixHullConeBlock0098 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone3136,
    supportedCone3137,
    supportedCone3138,
    supportedCone3139,
    supportedCone3140,
    supportedCone3141,
    supportedCone3142,
    supportedCone3143,
    supportedCone3144,
    supportedCone3145,
    supportedCone3146,
    supportedCone3147,
    supportedCone3148,
    supportedCone3149,
    supportedCone3150,
    supportedCone3151,
    supportedCone3152,
    supportedCone3153,
    supportedCone3154,
    supportedCone3155,
    supportedCone3156,
    supportedCone3157,
    supportedCone3158,
    supportedCone3159,
    supportedCone3160,
    supportedCone3161,
    supportedCone3162,
    supportedCone3163,
    supportedCone3164,
    supportedCone3165,
    supportedCone3166,
    supportedCone3167,
  ], rfl⟩

private def supportedCone3168 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1043, 1044, 1044, 1043, 1044⟩, ⟨10588560285355, 2610737769, 0, 0, 189287203344058, 1037352417730⟩⟩
    hull024_053 1 (by decide +kernel)

private def supportedCone3169 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 21, 20, 22⟩, ⟨1970044404, 29103683, 1444783328, 26634160, 242625893577, 107379951⟩⟩
    hull024_055 12 (by decide +kernel)

private def supportedCone3170 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1044, 1045, 1044, 1044, 1045⟩, ⟨0, 0, 11215971926527, 2101538485, 189287203344058, 1037352417730⟩⟩
    hull024_056 0 (by decide +kernel)

private def supportedCone3171 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1045, 1046, 1045, 1045, 1046⟩, ⟨0, 0, 11880560044657, 731287446, 200503175270585, 1039453956215⟩⟩
    hull024_057 0 (by decide +kernel)

private def supportedCone3172 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 24, 23, 25⟩, ⟨1407888149, 33953019, 1142765542, 29098135, 246407888149, 187176200⟩⟩
    hull024_055 15 (by decide +kernel)

private def supportedCone3173 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1044, 1045, 1045, 1044, 1045⟩, ⟨11215971926527, 2101538485, 0, 0, 200503175270585, 1039453956215⟩⟩
    hull024_056 1 (by decide +kernel)

private def supportedCone3174 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1045, 1046, 1046, 1045, 1046⟩, ⟨11880560044657, 731287446, 0, 0, 212383735315242, 1040185243661⟩⟩
    hull024_057 1 (by decide +kernel)

private def supportedCone3175 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 19, 18, 20⟩, ⟨1199287158, 15058052, 655849173, 8806333, 240000000000, 69469935⟩⟩
    hull024_058 2 (by decide +kernel)

private def supportedCone3176 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1044, 1046, 1046, 1044, 1046⟩, ⟨23096531971184, 2832825931, 0, 0, 212383735315242, 1040185243661⟩⟩
    hull024_054 1 (by decide +kernel)

private def supportedCone3177 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1046, 1048, 1046, 1046, 1048⟩, ⟨0, 0, 25914735102042, 2006767265, 212383735315242, 1040185243661⟩⟩
    hull024_059 0 (by decide +kernel)

private def supportedCone3178 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1048, 1050, 1048, 1048, 1050⟩, ⟨0, 0, 29076811022840, 2236310672, 238298470417284, 1042192010926⟩⟩
    hull024_060 0 (by decide +kernel)

private def supportedCone3179 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1050, 1055, 1050, 1050, 1055⟩, ⟨0, 0, 69230254850465, 4947676756, 267375281440124, 1044428321598⟩⟩
    hull024_061 0 (by decide +kernel)

private def supportedCone3180 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1055, 1064, 1055, 1055, 1058⟩, ⟨0, 0, 41072087247661, 1763587162, 336605536290589, 1049375998354⟩⟩
    hull024_062 0 (by decide +kernel)

private def supportedCone3181 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1046, 1050, 1046, 1046, 1050⟩, ⟨0, 0, 54991546124882, 4243077937, 212383735315242, 1040185243661⟩⟩
    hull024_063 0 (by decide +kernel)

private def supportedCone3182 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1046, 1047, 1046, 1046, 1047⟩, ⟨0, 0, 12584527484495, 976723705, 212383735315242, 1040185243661⟩⟩
    hull024_064 0 (by decide +kernel)

private def supportedCone3183 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1047, 1048, 1047, 1047, 1048⟩, ⟨0, 0, 13330207617547, 1030043560, 224968262799737, 1041161967366⟩⟩
    hull024_065 0 (by decide +kernel)

private def supportedCone3184 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1046, 1055, 1046, 1046, 1055⟩, ⟨0, 0, 124221800975347, 9190754693, 212383735315242, 1040185243661⟩⟩
    hull024_066 0 (by decide +kernel)

private def supportedCone3185 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1046, 1047, 1047, 1046, 1047⟩, ⟨12584527484495, 976723705, 0, 0, 224968262799737, 1041161967366⟩⟩
    hull024_064 1 (by decide +kernel)

private def supportedCone3186 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1046, 1048, 1048, 1046, 1048⟩, ⟨25914735102042, 2006767265, 0, 0, 238298470417284, 1042192010926⟩⟩
    hull024_059 1 (by decide +kernel)

private def supportedCone3187 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1046, 1050, 1050, 1046, 1050⟩, ⟨54991546124882, 4243077937, 0, 0, 267375281440124, 1044428321598⟩⟩
    hull024_063 1 (by decide +kernel)

private def supportedCone3188 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1047, 1048, 1048, 1047, 1048⟩, ⟨13330207617547, 1030043560, 0, 0, 238298470417284, 1042192010926⟩⟩
    hull024_065 1 (by decide +kernel)

private def supportedCone3189 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1048, 1049, 1048, 1048, 1049⟩, ⟨0, 0, 14120072076275, 1086908967, 238298470417284, 1042192010926⟩⟩
    hull024_067 0 (by decide +kernel)

private def supportedCone3190 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1049, 1050, 1049, 1049, 1050⟩, ⟨0, 0, 14956738946565, 1149401705, 252418542493559, 1043278919893⟩⟩
    hull024_068 0 (by decide +kernel)

private def supportedCone3191 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1048, 1049, 1049, 1048, 1049⟩, ⟨14120072076275, 1086908967, 0, 0, 252418542493559, 1043278919893⟩⟩
    hull024_067 1 (by decide +kernel)

private def supportedCone3192 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1048, 1050, 1050, 1048, 1050⟩, ⟨29076811022840, 2236310672, 0, 0, 267375281440124, 1044428321598⟩⟩
    hull024_060 1 (by decide +kernel)

private def supportedCone3193 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1049, 1050, 1050, 1049, 1050⟩, ⟨14956738946565, 1149401705, 0, 0, 267375281440124, 1044428321598⟩⟩
    hull024_068 1 (by decide +kernel)

private def supportedCone3194 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1050, 1052, 1050, 1050, 1051⟩, ⟨0, 0, 15842981445653, 1208387408, 267375281440124, 1044428321598⟩⟩
    hull024_069 0 (by decide +kernel)

private def supportedCone3195 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1052, 1055, 1052, 1052, 1055⟩, ⟨0, 0, 36605536290589, 2447264488, 300000000000000, 1046928733866⟩⟩
    hull024_070 0 (by decide +kernel)

private def supportedCone3196 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1050, 1052, 1051, 1050, 1052⟩, ⟨15842981445653, 1208387408, 16781737114223, 1292024860, 283218262885777, 1045636709006⟩⟩
    hull024_069 1 (by decide +kernel)

private def supportedCone3197 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1050, 1052, 1052, 1051, 1052⟩, ⟨16781737114223, 1292024860, 0, 0, 300000000000000, 1046928733866⟩⟩
    hull024_069 2 (by decide +kernel)

private def supportedCone3198 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1052, 1055, 1055, 1052, 1055⟩, ⟨36605536290589, 2447264488, 0, 0, 336605536290589, 1049375998354⟩⟩
    hull024_070 1 (by decide +kernel)

private def supportedCone3199 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1052, 1053, 1052, 1052, 1053⟩, ⟨0, 0, 17776117553187, 1292395632, 300000000000000, 1046928733866⟩⟩
    hull024_071 0 (by decide +kernel)

def appendixHullConeBlock0099 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone3168,
    supportedCone3169,
    supportedCone3170,
    supportedCone3171,
    supportedCone3172,
    supportedCone3173,
    supportedCone3174,
    supportedCone3175,
    supportedCone3176,
    supportedCone3177,
    supportedCone3178,
    supportedCone3179,
    supportedCone3180,
    supportedCone3181,
    supportedCone3182,
    supportedCone3183,
    supportedCone3184,
    supportedCone3185,
    supportedCone3186,
    supportedCone3187,
    supportedCone3188,
    supportedCone3189,
    supportedCone3190,
    supportedCone3191,
    supportedCone3192,
    supportedCone3193,
    supportedCone3194,
    supportedCone3195,
    supportedCone3196,
    supportedCone3197,
    supportedCone3198,
    supportedCone3199,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
