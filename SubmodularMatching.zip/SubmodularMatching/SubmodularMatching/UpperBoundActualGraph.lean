import SubmodularMatching.UpperBoundActualProgram
import SubmodularMatching.UpperBoundGraphConfidence

/-! # The rational-word program on any finite simple graph -/

namespace SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream

open GibbsSampler NumericalCertificate

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

def rationalObjective (oracle : Finset E → ℚ) (A : Finset E) : ℝ := oracle A

def normalizedOracle (oracle : Finset E → ℚ) (A : Finset E) : ℚ := oracle A - oracle ∅

theorem normalizedOracle_correct (oracle : Finset E → ℚ) :
    normalizeObjective (rationalObjective oracle) = rationalObjective (normalizedOracle oracle) := by
  funext A
  simp [normalizeObjective, rationalObjective, normalizedOracle]

variable (S : SimpleEdgeStream E V)

def onlineGraphExpected (oracle : Finset E → ℚ)
    (hf : IsSubmodular (rationalObjective oracle)) (hm : IsMonotone (rationalObjective oracle)) :
    CandidateLaw (Finset E) := by
  classical
  let g := normalizeObjective (rationalObjective oracle)
  have hg := normalizeObjective_properties _ hf hm
  exact if hB : ∃ e, 0 < g {e} then
    (S.positiveProgram g hg.1 hg.2.1 hg.2.2 hB).onlineExpectedLaw (normalizedOracle oracle)
  else CandidateLaw.pure ∅

def onlineGraphAmplified (oracle : Finset E → ℚ)
    (hf : IsSubmodular (rationalObjective oracle)) (hm : IsMonotone (rationalObjective oracle))
    (delta : ℝ) : CandidateLaw (Finset E) := by
  classical
  let g := normalizeObjective (rationalObjective oracle)
  have hg := normalizeObjective_properties _ hf hm
  exact if hB : ∃ e, 0 < g {e} then
    (S.positiveProgram g hg.1 hg.2.1 hg.2.2 hB).onlineAmplifiedLaw (normalizedOracle oracle) delta
  else CandidateLaw.pure ∅

set_option maxHeartbeats 1200000 in
/-- Empty graphs and zero normalized objectives return the empty matching.
Other inputs run the sparse word algorithm on the normalized oracle. -/
theorem onlineGraph_value (oracle : Finset E → ℚ)
    (hf : IsSubmodular (rationalObjective oracle)) (hm : IsMonotone (rationalObjective oracle))
    (h0 : 0 ≤ rationalObjective oracle ∅)
    (hcert : ∀ hn : 2 ≤ Fintype.card V, AppendixSourceObligation (Fintype.card V) hn)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, oracle M ≤ oracle O)
    (delta : ℝ) (hδ : 0 < delta) :
    let p := S.onlineGraphExpected oracle hf hm
    let q := S.onlineGraphAmplified oracle hf hm delta
    let f := rationalObjective oracle
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / targetFactor ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤ delta := by
  classical
  dsimp only
  let f := rationalObjective oracle
  let g := normalizeObjective f
  let hg := normalizeObjective_properties f hf hm
  have hR : 1 ≤ targetFactor := by norm_num [targetFactor]
  by_cases hpos : ∃ e, 0 < normalizeObjective (rationalObjective oracle) {e}
  · let I := S.positiveProgram g hg.1 hg.2.1 hg.2.2 hpos
    let o := normalizedOracle oracle
    have hset := S.positiveProgram_feasible g hg.1 hg.2.1 hg.2.2 hpos
    have hO' : O ∈ I.feasible := by rw [hset]; exact hO
    have ho' (M : Finset E) (h : M ∈ I.feasible) : I.P.objective M ≤ I.P.objective O := by
      rw [hset] at h
      have ho : (oracle M : ℝ) ≤ (oracle O : ℝ) := by exact_mod_cast hopt M h
      exact sub_le_sub_right ho _
    have hg' : I.P.objective = fun A => (o A : ℝ) := normalizedOracle_correct oracle
    have hl := I.onlineWord_guarantees o hg' (hcert I.atLeastTwo) O hO' ho' delta hδ
    rw [hset] at hl
    simp only [onlineGraphExpected, onlineGraphAmplified, dif_pos hpos]
    refine ⟨hl.1, hl.2.1, normalizeObjective_expected_transfer f O _ hR h0 _ _
      (I.onlineExpectedLaw o).probability hl.2.2.1, ?_⟩
    refine ((I.onlineAmplifiedLaw o delta).expected_le _ _ ?_).trans hl.2.2.2
    intro M _
    change (if f O / targetFactor ≤ f M then (0 : ℝ) else 1) ≤
      (if g O / targetFactor ≤ g M then 0 else 1)
    by_cases h : g O / targetFactor ≤ g M
    · rw [if_pos h, if_pos (normalizeObjective_transfer f M O _ hR h0 h)]
    · rw [if_neg h]
      split_ifs <;> norm_num
  · have hz := objective_zero_of_empty_singletons g hg.1 hg.2.1 hg.2.2 hpos O
    have hfO : f O = f ∅ := sub_eq_zero.mp hz
    have hcase : f O / targetFactor ≤ f ∅ := by rw [hfO]; exact div_le_self h0 hR
    have hempty : ∅ ∈ S.matchings := GibbsMatching.empty_mem_matchings _ _
    simp only [onlineGraphExpected, onlineGraphAmplified, dif_neg hpos, CandidateLaw.pure_expected]
    exact ⟨Finset.singleton_subset_iff.2 hempty, Finset.singleton_subset_iff.2 hempty, hcase,
      by
        change (if f O / targetFactor ≤ f ∅ then (0 : ℝ) else 1) ≤ delta
        rw [if_pos hcase]
        exact hδ.le⟩

end

end SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream
