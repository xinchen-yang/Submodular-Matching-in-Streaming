import SubmodularMatching.CapacitySignedTrace
import SubmodularMatching.CapacityStoredLabels
import SubmodularMatching.PotentialSpace

/-! # Online minimum-slot implementation for distinct-edge streams -/

namespace SubmodularMatching.Capacity
open Finset Streaming
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

/-- A one-edge update accesses just that edge's chosen endpoint pair. -/
theorem processPotential_eq_of_pair {W : Type*} [DecidableEq W] (C : PotentialConfig)
    (a b : E → W × W) (s : PotentialState E W) (e : E) (w : ℝ) (he : a e = b e) :
    processPotential C a s e w = processPotential C b s e w := by
  classical
  simp only [processPotential, accepts, acceptPotential, IsIncident, he]

variable (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0 < cap (ends e).1 ∧ 0 < cap (ends e).2)

def chooseLeft (s : PotentialState E (BSlot cap)) (e : E) : Fin (cap (ends e).1) :=
  leastSlot _ (fun j => s.potential ⟨(ends e).1,j⟩) (hpos e).1

def chooseRight (s : PotentialState E (BSlot cap)) (e : E) : Fin (cap (ends e).2) :=
  leastSlot _ (fun j => s.potential ⟨(ends e).2,j⟩) (hpos e).2

/-- The streaming update selects the two minima from its current state. -/
def onlineSlots (C : PotentialConfig) (input : ℕ → E × ℝ) : ℕ → PotentialState E (BSlot cap)
  | 0 => emptyPotentialState
  | i+1 =>
    let s := onlineSlots C input i
    processPotential C (slotPair ends cap (chooseLeft ends cap hpos s) (chooseRight ends cap hpos s))
      s (input i).1 (input i).2

private def arrival (input : ℕ → E × ℝ) (n : ℕ) (e : E) : ℕ := by
  classical
  exact if h : ∃ i < n, (input i).1 = e then h.choose else 0

private theorem arrival_eq (input : ℕ → E × ℝ) (n : ℕ)
    (hinj : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j)
    (i : ℕ) (hi : i < n) : arrival input n (input i).1 = i := by
  classical
  have h : ∃ j < n, (input j).1 = (input i).1 := ⟨i, hi, rfl⟩
  simpa only [arrival, dif_pos h] using hinj _ h.choose_spec.1 _ hi h.choose_spec.2

/-- The actual online run has a fixed pair representation for every prefix.
The chosen pairs achieve the paper's minimum rule at their arrival. -/
theorem onlineSlots_trace_at (C : PotentialConfig) (input : ℕ → E × ℝ) (n : ℕ)
    (hinj : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j) :
    ∃ (left : (e : E) → Fin (cap (ends e).1)) (right : (e : E) → Fin (cap (ends e).2)),
      (∀ i ≤ n, runPotential C (slotPair ends cap left right) input i =
        onlineSlots ends cap hpos C input i) ∧
      (∀ i < n, slotPair ends cap left right (input i).1 =
        slotPair ends cap (chooseLeft ends cap hpos (onlineSlots ends cap hpos C input i))
          (chooseRight ends cap hpos (onlineSlots ends cap hpos C input i)) (input i).1) ∧
      SelectsMin C ends cap left right input n := by
  let s := onlineSlots ends cap hpos C input
  let left := fun e => chooseLeft ends cap hpos (s (arrival input n e)) e
  let right := fun e => chooseRight ends cap hpos (s (arrival input n e)) e
  refine ⟨left,right,?_⟩
  have hs : ∀ i ≤ n, runPotential C (slotPair ends cap left right) input i = s i := by
    intro i
    induction i with
    | zero => intro _; rfl
    | succ i ih =>
      intro hi
      change processPotential C _ (runPotential C _ input i) _ _ =
        processPotential C _ (s i) _ _
      rw [ih (by omega)]
      apply processPotential_eq_of_pair
      simp only [slotPair,left,right,arrival_eq input n hinj i (by omega),s]
  refine ⟨hs,?_,?_⟩
  · intro i hi
    simp only [slotPair,left,right,arrival_eq input n hinj i hi,s]
  intro i hi
  dsimp only
  rw [hs i hi.le]
  simp only [left,right,arrival_eq input n hinj i hi]
  exact ⟨(leastSlot_spec _ (fun j => (s i).potential ⟨(ends (input i).1).1,j⟩) _).1,
    (leastSlot_spec _ (fun j => (s i).potential ⟨(ends (input i).1).2,j⟩) _).1⟩

theorem onlineSlots_trace (C : PotentialConfig) (input : ℕ → E × ℝ) (n : ℕ)
    (hinj : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j) :
    ∃ (left : (e : E) → Fin (cap (ends e).1)) (right : (e : E) → Fin (cap (ends e).2)),
      (∀ i ≤ n, runPotential C (slotPair ends cap left right) input i =
        onlineSlots ends cap hpos C input i) ∧ SelectsMin C ends cap left right input n := by
  obtain ⟨left,right,hr,_,hmin⟩ := onlineSlots_trace_at ends cap hpos C input n hinj
  exact ⟨left,right,hr,hmin⟩

/-- The online instance stores O(ν_b I) original labels for any bounded-weight
transcript, where I is the single-slot logarithmic incidence bound. -/
theorem onlineSlots_storage (C : PotentialConfig) (input : ℕ → E × ℝ) (n : ℕ)
    (hinj : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j)
    (hw : ∀ i < n, (input i).2 ≤ C.tau)
    (hnoloop : ∀ e, (ends e).1 ≠ (ends e).2) (K : Finset E)
    (hk : feasible ends cap K) (hm : ∀ s, feasible ends cap s → s.card ≤ K.card) :
    (onlineSlots ends cap hpos C input n).stored.card ≤
      (1 + 2*C.incidenceLimit)*K.card := by
  obtain ⟨left,right,h,_⟩ := onlineSlots_trace ends cap hpos C input n hinj
  rw [← h n le_rfl]
  apply stored_labels_card ends hnoloop cap K _ hk hm left right C.incidenceLimit
  intro x
  exact runPotential_incidence_le C (slotPair ends cap left right) input n hw x

end
end SubmodularMatching.Capacity
