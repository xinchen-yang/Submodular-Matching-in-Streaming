import SubmodularMatching.StreamingEstimator
import Mathlib.Data.Rat.Floor

/-!
# Executable integer-grid arithmetic for the streaming update

Potential updates take place in units of the potential grid. The normalized
stage durations and rates are rational. After completing the recursion, the
program retains only integer indices. No absolute potential values or
intermediate denominators need to be carried to the next arrival.
-/

namespace SubmodularMatching.Streaming

/-- A rate interval with rational rates and lower ratio boundary. -/
structure RationalStage where
  highRate : ℚ
  lowRate : ℚ
  boundary : ℚ

/-- Interpret executable rational constants in the mathematical model. -/
def RationalStage.real (r : RationalStage) : PotentialStage :=
  ⟨r.highRate, r.lowRate, r.boundary⟩

/-- The normalized rational potentials of the two endpoints. -/
abbrev RationalPotentialPair := ℚ × ℚ

/-- Interpret a potential in units of the current potential grid. -/
def rationalPairReal (grid : ℝ) (P : RationalPotentialPair) : PotentialPair :=
  ⟨grid * P.1, grid * P.2⟩

private def advanceRational (P : RationalPotentialPair) (r : RationalStage) (t : ℚ) :
    RationalPotentialPair :=
  (P.1 + r.highRate * t, P.2 + r.lowRate * t)

private def boundaryTimeRational (P : RationalPotentialPair) (r : RationalStage) : ℚ :=
  (P.1 - r.boundary * (P.1 + P.2)) /
    (r.boundary * (r.highRate + r.lowRate) - r.highRate)

private def stageTimeRational (P : RationalPotentialPair) (r : RationalStage) (t : ℚ) : ℚ :=
  min t (max 0 (boundaryTimeRational P r))

/-- Exhaust the remaining rational time through the descending stage table. -/
def idealUpdateRational (base : RationalStage) :
    List RationalStage → RationalPotentialPair → ℚ → RationalPotentialPair
  | [], P, t => advanceRational P base t
  | r :: rs, P, t =>
    let u := stageTimeRational P r t
    idealUpdateRational base rs (advanceRational P r u) (t - u)

private theorem cast_advanceRational (grid : ℝ) (P : RationalPotentialPair)
    (r : RationalStage) (t : ℚ) :
    rationalPairReal grid (advanceRational P r t) =
      advancePotential (rationalPairReal grid P) r.real (grid * t) := by
  unfold rationalPairReal advanceRational advancePotential RationalStage.real
  push_cast
  congr 1 <;> ring

private theorem cast_boundaryTimeRational (grid : ℝ) (P : RationalPotentialPair)
    (r : RationalStage) :
    grid * (boundaryTimeRational P r : ℝ) = boundaryTime (rationalPairReal grid P) r.real := by
  unfold boundaryTimeRational boundaryTime rationalPairReal RationalStage.real
  push_cast
  rw [← mul_div_assoc]
  congr 1
  ring

private theorem cast_stageTimeRational (grid : ℝ) (P : RationalPotentialPair) (r : RationalStage)
    (t : ℚ) (hg : 0 ≤ grid) :
    grid * (stageTimeRational P r t : ℝ) = stageTime (rationalPairReal grid P) r.real (grid * t) := by
  unfold stageTimeRational stageTime
  rw [Rat.cast_min, Rat.cast_max, Rat.cast_zero,
    mul_min_of_nonneg _ _ hg, mul_max_of_nonneg _ _ hg, mul_zero, cast_boundaryTimeRational]

/-- Interpreting the normalized rational recursion after executing it yields
the paper's update at the original scale. -/
theorem idealUpdateRational_cast (grid : ℝ) (hg : 0 ≤ grid) (base : RationalStage)
    (rs : List RationalStage) (P : RationalPotentialPair) (t : ℚ) :
    rationalPairReal grid (idealUpdateRational base rs P t) =
      idealUpdate base.real (rs.map RationalStage.real) (rationalPairReal grid P) (grid * t) := by
  induction rs generalizing P t with
  | nil => exact cast_advanceRational grid P base t
  | cons r rs ih =>
    simp only [idealUpdateRational, List.map_cons, idealUpdate]
    rw [ih, cast_advanceRational, Rat.cast_sub, mul_sub, cast_stageTimeRational grid P r t hg]

/-- The fixed normalized parameters for an active guess. The units of
`threshold` are one weight grid step. The units of `gain` are one potential
grid step per weight grid index. -/
structure GridUpdateParameters where
  base : RationalStage
  stages : List RationalStage
  threshold : ℚ
  potentialToWeight : ℚ
  gain : ℚ

/-- The rational data needed to compare the executable update with an active
paper instance at scale `tau`. -/
structure GridUpdateParameters.Matches (R : GridUpdateParameters) (C : PotentialConfig) : Prop where
  base : R.base.real = C.base
  stages : R.stages.map RationalStage.real = C.stages
  theta : C.gap * R.threshold = C.theta
  ratio : C.gap * R.potentialToWeight = C.grid
  gain : C.grid * R.gain = C.p * C.gap

/-- Conservative weight fitting computed from a single snapped accumulator.
The program can accumulate the quarter-grid integers one at a time. -/
def sourceWeightIndex (count : ℕ) (accum : ℤ) : ℕ :=
  (⌊(accum : ℚ) / (4 * count)⌋ - 1).toNat

/-- The accumulator conversion implements the existing real source estimator. -/
theorem sourceWeight_eq_index {N : ℕ} (d : ℝ) (samples : Fin N → ℝ) :
    sourceWeight d samples = d * (sourceWeightIndex N (sourceIndex d samples) : ℝ) := by
  unfold sourceWeight sourceWeightIndex
  have hh := Rat.floor_cast (α := ℝ) ((sourceIndex d samples : ℚ) / (4 * N))
  push_cast at hh
  rw [hh]
  congr 1
  norm_cast
  omega

/-- Accept exactly when both rational grid tests succeed. -/
def gridAccepts (R : GridUpdateParameters) (u v w : ℕ) : Bool :=
  decide (R.threshold ≤ (w : ℚ) ∧ R.potentialToWeight * (u + v : ℕ) + 1 ≤ (w : ℚ))

theorem gridAccepts_eq_true_iff (R : GridUpdateParameters) (C : PotentialConfig)
    (h : R.Matches C) (hd : 0 < C.gap) (u v w : ℕ) :
    gridAccepts R u v w = true ↔ C.theta ≤ C.gap * w ∧
      C.grid * u + C.grid * v + C.gap ≤ C.gap * w := by
  rw [gridAccepts, decide_eq_true_eq]
  constructor
  · rintro ⟨h₁, h₂⟩
    have h₁' : (R.threshold : ℝ) ≤ (w : ℝ) := by exact_mod_cast h₁
    have h₂' : (R.potentialToWeight : ℝ) * ((u + v : ℕ) : ℝ) + 1 ≤ (w : ℝ) := by
      exact_mod_cast h₂
    rw [← h.theta, ← h.ratio]
    refine ⟨mul_le_mul_of_nonneg_left h₁' hd.le, ?_⟩
    push_cast at h₂'
    have hf := mul_le_mul_of_nonneg_left h₂' hd.le
    linarith only [show C.gap * ((R.potentialToWeight : ℝ) * ((u : ℝ) + v) + 1) =
      C.gap * (R.potentialToWeight : ℝ) * u +
      C.gap * (R.potentialToWeight : ℝ) * v + C.gap by ring, hf]
  · rintro ⟨h₁, h₂⟩
    constructor
    · rw [← h.theta] at h₁
      exact_mod_cast (mul_le_mul_iff_right₀ hd).1 h₁
    · rw [← h.ratio] at h₂
      have hf : C.gap * ((R.potentialToWeight : ℝ) * ((u + v : ℕ) : ℝ) + 1) ≤ C.gap * w := by
        push_cast
        convert h₂ using 1
        ring
      exact_mod_cast (mul_le_mul_iff_right₀ hd).1 hf

/-- Sorted update in grid units. No intermediate rational values are retained. -/
def orderedGridUpdate (R : GridUpdateParameters) (u v w : ℕ) : ℕ × ℕ :=
  let Q := idealUpdateRational R.base R.stages (u, v) (R.gain * w)
  (u + ⌈Q.1 - (u : ℚ)⌉.toNat, v + ⌈Q.2 - (v : ℚ)⌉.toNat)

/-- Sort by current index, update the two endpoints, and restore their order. -/
def gridUpdate (R : GridUpdateParameters) (u v w : ℕ) : ℕ × ℕ :=
  if v ≤ u then orderedGridUpdate R u v w else (orderedGridUpdate R v u w).swap

private theorem orderedGridUpdate_real (R : GridUpdateParameters) (C : PotentialConfig)
    (h : R.Matches C) (u v w : ℕ) :
    rationalPairReal C.grid ((orderedGridUpdate R u v w).1, (orderedGridUpdate R u v w).2) =
      roundedUpdate C.base C.stages ⟨C.grid * u, C.grid * v⟩ (C.p * (C.gap * w)) C.grid := by
  let Q := idealUpdateRational R.base R.stages (u, v) (R.gain * w)
  have hcast := idealUpdateRational_cast C.grid C.grid_pos.le R.base R.stages
    ((u : ℚ), (v : ℚ)) (R.gain * w)
  rw [h.base, h.stages] at hcast
  push_cast at hcast
  have htime : C.grid * ((R.gain : ℝ) * (w : ℝ)) = C.p * (C.gap * w) := by
    rw [← mul_assoc, h.gain]
    ring
  rw [htime] at hcast
  have hcast' : rationalPairReal C.grid Q =
      idealUpdate C.base C.stages ⟨C.grid * u, C.grid * v⟩ (C.p * (C.gap * w)) := by
    simpa [Q, rationalPairReal] using hcast
  have hbound := idealUpdate_bounds C.base C.stages C.minHigh C.minLow C.maxRate C.base_bounds
    C.stage_bounds ⟨C.grid * u, C.grid * v⟩ (C.p * (C.gap * w))
    (mul_nonneg C.p_pos.le (mul_nonneg C.gap_nonneg (Nat.cast_nonneg _)))
  have hlow : 0 ≤ C.minLow := C.minLow_pos.le
  have hhigh : 0 ≤ C.minHigh := hlow.trans C.minLow_le_minHigh
  have hnH : 0 ≤ Q.1 - (u : ℚ) := by
    rw [sub_nonneg]
    have hh : C.grid * (u : ℝ) ≤ C.grid * (Q.1 : ℝ) := by
      have h' := congrArg PotentialPair.high hcast'
      change C.grid * (Q.1 : ℝ) = _ at h'
      rw [h']
      exact (le_add_of_nonneg_right (mul_nonneg hhigh (mul_nonneg C.p_pos.le
        (mul_nonneg C.gap_nonneg (Nat.cast_nonneg _))))).trans hbound.1
    exact_mod_cast ((mul_le_mul_iff_right₀ C.grid_pos).1 hh)
  have hnL : 0 ≤ Q.2 - (v : ℚ) := by
    rw [sub_nonneg]
    have hl : C.grid * (v : ℝ) ≤ C.grid * (Q.2 : ℝ) := by
      have h' := congrArg PotentialPair.low hcast'
      change C.grid * (Q.2 : ℝ) = _ at h'
      rw [h']
      exact (le_add_of_nonneg_right (mul_nonneg hlow (mul_nonneg C.p_pos.le
        (mul_nonneg C.gap_nonneg (Nat.cast_nonneg _))))).trans hbound.2.2.1
    exact_mod_cast ((mul_le_mul_iff_right₀ C.grid_pos).1 hl)
  unfold roundedUpdate
  rw [← hcast']
  change rationalPairReal C.grid
      ((u + ⌈Q.1 - (u : ℚ)⌉.toNat : ℕ), (v + ⌈Q.2 - (v : ℚ)⌉.toNat : ℕ)) = _
  unfold rationalPairReal roundUp
  push_cast
  have hH : (C.grid * (Q.1 : ℝ) - C.grid * u) / C.grid = (Q.1 : ℝ) - u := by
    exact (by rw [← mul_sub, mul_div_cancel_left₀ _ C.grid_pos.ne'])
  have hL : (C.grid * (Q.2 : ℝ) - C.grid * v) / C.grid = (Q.2 : ℝ) - v := by
    exact (by rw [← mul_sub, mul_div_cancel_left₀ _ C.grid_pos.ne'])
  rw [hH, hL, ← Rat.cast_natCast (α := ℝ) u, ← Rat.cast_natCast (α := ℝ) v,
    ← Rat.cast_sub, ← Rat.cast_sub, Rat.ceil_cast, Rat.ceil_cast]
  have hu' : ((⌈Q.1 - (u : ℚ)⌉.toNat : ℕ) : ℝ) = (⌈Q.1 - (u : ℚ)⌉ : ℤ) := by
    exact_mod_cast Int.toNat_of_nonneg (Int.ceil_nonneg hnH)
  have hv' : ((⌈Q.2 - (v : ℚ)⌉.toNat : ℕ) : ℝ) = (⌈Q.2 - (v : ℚ)⌉ : ℤ) := by
    exact_mod_cast Int.toNat_of_nonneg (Int.ceil_nonneg hnL)
  rw [hu', hv']
  congr 1 <;> push_cast <;> ring

/-- Exact simulation: the two stored integer indices represent the same
rounded endpoint potentials as the paper's real-valued update. -/
theorem gridUpdate_real (R : GridUpdateParameters) (C : PotentialConfig)
    (h : R.Matches C) (u v w : ℕ) :
    rationalPairReal C.grid ((gridUpdate R u v w).1, (gridUpdate R u v w).2) =
      updateUnordered C ⟨C.grid * u, C.grid * v⟩ (C.gap * w) := by
  by_cases he : v ≤ u
  · have hv : C.grid * (v : ℝ) ≤ C.grid * u :=
      mul_le_mul_of_nonneg_left (by exact_mod_cast he) C.grid_pos.le
    simpa [gridUpdate, he, updateUnordered, hv] using orderedGridUpdate_real R C h u v w
  · have hv : ¬C.grid * (v : ℝ) ≤ C.grid * u := by
      intro hh
      exact he (by exact_mod_cast (mul_le_mul_iff_right₀ C.grid_pos).1 hh)
    unfold gridUpdate updateUnordered
    rw [if_neg he, if_neg hv]
    have hh := congrArg PotentialPair.swap (orderedGridUpdate_real R C h v u w)
    exact hh

end SubmodularMatching.Streaming
