import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step113 : ProjectedGoal ⟨54864, 54917, 0, 70, 1064, 1099⟩ :=
  projectedGoal_chunk _ (.m (.leaf 0xd66ad6500000000000c9e191) (.m (.m (.leaf 0xd671d66b0000000000c9e191) (.leaf 0xd678d6720000000000c9e191)) (.m (.m (.leaf 0xd67cd6790000000000c9e191) (.leaf 0xd67fd67d0015d3ef79c9e207)) (.y (.y (.y (.m (.m (.leaf 0xd681d68001d1a94a20c9f662) (.y (.leaf 0xd682d68203a3529440ca1ca0) (.leaf 0xd682d6820000000000ca2191))) (.y (.y (.m (.m (.leaf 0xd683d68303a3529440ca3ca0) (.leaf 0xd684d6840574fbde60ca37e8)) (.leaf 0xd685d68503a3529440ca3ca0)) (.leaf 0xd685d6830000000000ca4191)) (.leaf 0xd685d6830000000000ca2191))) (.leaf 0xd685d6800000000000ca5191)) (.leaf 0xd685d6800000000000ca6191)) (.leaf 0xd685d6800000000000ca7191))))) (by decide +kernel)

private theorem step114 : ProjectedGoal ⟨54918, 54931, 0, 70, 1064, 1068⟩ :=
  projectedGoal_chunk _ (.y (.m (.m (.m (.y (.leaf 0xd687d68605e96630e8ca3835) (.leaf 0xd687d6860000000000ca4191)) (.y (.leaf 0xd689d68806239b5a2cca3835) (.leaf 0xd689d6880000000000ca4191))) (.y (.m (.leaf 0xd68bd68a06239b5a2cca3835) (.leaf 0xd68cd68c0638c0aa29ca3835)) (.leaf 0xd68cd68a0000000000ca4191))) (.y (.m (.m (.m (.leaf 0xd68dd68d0746a52880ca8836) (.leaf 0xd68ed68e06412a5920ca8835)) (.m (.leaf 0xd68fd68f0746a52880ca8836) (.leaf 0xd690d690065dd08370ca8835))) (.m (.m (.leaf 0xd691d6910746a52880ca8836) (.leaf 0xd692d692065dd08370ca8835)) (.leaf 0xd693d6930746a52880ca8836))) (.m (.leaf 0xd690d68d0000000000ca4191) (.leaf 0xd693d69103a3529440ca4ca0)))) (.leaf 0xd693d6860000000000ca2191)) (by decide +kernel)

private theorem step115 : ProjectedGoal ⟨54932, 54944, 0, 70, 1064, 1068⟩ :=
  projectedGoal_chunk _ (.y (.m (.m (.y (.m (.leaf 0xd695d6940746a52880ca8836) (.leaf 0xd697d6960746a52880ca8836)) (.m (.leaf 0xd695d69403a3529440ca4ca0) (.leaf 0xd697d69603a3529440ca4ca0))) (.y (.m (.leaf 0xd699d6980746a52880ca8836) (.leaf 0xd69ad69a0e8d4a5100ca8192)) (.m (.leaf 0xd699d6980417bce6c8ca9c61) (.leaf 0xd69ad69a03faa25226ca4ca0)))) (.y (.leaf 0xd6a0d69b0e8d4a5100ca8192) (.m (.m (.m (.leaf 0xd69bd69b03a3529440ca4ca0) (.leaf 0xd69cd69c040f44aa86ca4c61)) (.leaf 0xd69dd69d03a3529440ca4ca0)) (.m (.leaf 0xd69fd69e0414199433ca4c61) (.leaf 0xd6a0d6a00417bce6c8ca4c61))))) (.m (.leaf 0xd69ad6940000000000ca2191) (.leaf 0xd6a0d69b0000000000ca2191))) (by decide +kernel)

private theorem step116 : ProjectedGoal ⟨54918, 54944, 0, 70, 1064, 1068⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54931 (by decide) (by decide) (step114 rates cones) (step115 rates cones)

private theorem step117 : ProjectedGoal ⟨54945, 54971, 0, 70, 1064, 1066⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.y (.leaf 0xd6a4d6a11d1a94a200ca8caa) (.m (.m (.leaf 0xd6a1d6a103a3529440ca4ca0) (.leaf 0xd6a2d6a20417bce6c8ca4c61)) (.leaf 0xd6a4d6a30434d77b6aca9c61))) (.y (.leaf 0xd6a7d6a51d1a94a200ca8caa) (.leaf 0xd6a7d6a5048c273950ca9c61))) (.m (.leaf 0xd6abd6a80574fbde60cab7e8) (.leaf 0xd6aed6ac0746a52880cab836))) (.leaf 0xd6bbd6af0e8d4a5100cab192)) (by decide +kernel)

private theorem step118 : ProjectedGoal ⟨54945, 54971, 0, 70, 1066, 1068⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0xd6a4d6a10000000000ca2191) (.leaf 0xd6a7d6a50000000000ca2191)) (.m (.m (.leaf 0xd6a9d6a800ae9f7bccca2203) (.y (.leaf 0xd6abd6aa015d3ef798cac629) (.leaf 0xd6abd6aa0000000000cad191))) (.y (.m (.leaf 0xd6add6ac01977420dccac629) (.leaf 0xd6aed6ae01977420dccac629)) (.leaf 0xd6aed6ac0000000000cad191)))) (.y (.m (.m (.m (.m (.leaf 0xd6afd6af01d1a94a20cae662) (.leaf 0xd6b0d6b001a25e1898cae629)) (.m (.leaf 0xd6b1d6b101d1a94a20cae662) (.leaf 0xd6b2d6b201a6016b2dcae629))) (.m (.m (.leaf 0xd6b3d6b301d1a94a20cae662) (.leaf 0xd6b4d6b401d1a94a20cae662)) (.leaf 0xd6b5d6b501d1a94a20cae662))) (.m (.m (.leaf 0xd6b7d6b601d1a94a20cae662) (.leaf 0xd6b8d6b803a3529440caeca0)) (.leaf 0xd6bbd6b903a3529440caeca0))) (.m (.leaf 0xd6b5d6af0000000000cad191) (.leaf 0xd6bbd6b60000000000cad191)))) (by decide +kernel)

private theorem step119 : ProjectedGoal ⟨54945, 54971, 0, 70, 1064, 1068⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1066 (by decide) (by decide) (step117 rates cones) (step118 rates cones)

private theorem step120 : ProjectedGoal ⟨54918, 54971, 0, 70, 1064, 1068⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54944 (by decide) (by decide) (step116 rates cones) (step119 rates cones)

private theorem step121 : ProjectedGoal ⟨54918, 54971, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.m (.m (.leaf 0xd693d6860000000000ca5191) (.leaf 0xd6a0d6940000000000ca5191)) (.m (.m (.leaf 0xd6a7d6a10000000000ca5191) (.leaf 0xd6aed6a80000000000ca5191)) (.m (.leaf 0xd6b5d6af0000000000ca5191) (.leaf 0xd6bbd6b60000000000ca5191)))) (by decide +kernel)

private theorem step122 : ProjectedGoal ⟨54918, 54971, 0, 70, 1064, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1068 (by decide) (by decide) (step120 rates cones) (step121 rates cones)

private theorem step123 : ProjectedGoal ⟨54918, 54971, 0, 70, 1072, 1081⟩ :=
  projectedGoal_chunk _ (.m (.m (.leaf 0xd693d6860000000000ca6191) (.leaf 0xd6a0d6940000000000ca6191)) (.m (.m (.leaf 0xd6a7d6a10000000000ca6191) (.leaf 0xd6aed6a80000000000ca6191)) (.m (.leaf 0xd6b5d6af0000000000ca6191) (.leaf 0xd6bbd6b60000000000ca6191)))) (by decide +kernel)

private theorem step124 : ProjectedGoal ⟨54918, 54971, 0, 70, 1064, 1081⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1072 (by decide) (by decide) (step122 rates cones) (step123 rates cones)

private theorem step125 : ProjectedGoal ⟨54918, 54971, 0, 70, 1081, 1099⟩ :=
  projectedGoal_chunk _ (.m (.m (.leaf 0xd693d6860000000000ca7191) (.leaf 0xd6a0d6940000000000ca7191)) (.m (.m (.leaf 0xd6a7d6a10000000000ca7191) (.leaf 0xd6aed6a80000000000ca7191)) (.m (.leaf 0xd6b5d6af0000000000ca7191) (.leaf 0xd6bbd6b60000000000ca7191)))) (by decide +kernel)

private theorem step126 : ProjectedGoal ⟨54918, 54971, 0, 70, 1064, 1099⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1081 (by decide) (by decide) (step124 rates cones) (step125 rates cones)

private theorem step127 : ProjectedGoal ⟨54864, 54971, 0, 70, 1064, 1099⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54917 (by decide) (by decide) (step113 rates cones) (step126 rates cones)

theorem Part00014 : ProjectedGoal ⟨54864, 54971, 0, 70, 1064, 1099⟩ := step127

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
