import SubmodularMatching.FiniteShearerBinary

/-!
# Total variation guarantee for the binary sampler

The same streamed set of pending matching decisions is used for the ideal
and capped binary laws. The per-edge bound therefore adds over the stream.
-/

namespace SubmodularMatching.ShearerSampler

open GibbsMatching GibbsSampler Shearer
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

private theorem order_tail_subset {edges : Finset E} {e : E} {order : List E}
    (h : (e :: order).toFinset ⊆ edges) : order.toFinset ⊆ edges := by
  rw [List.toFinset_cons] at h
  exact (Finset.subset_insert e order.toFinset).trans h

noncomputable def binaryShearerSchedule (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (fuel B : ℕ)
    (topGrid neighborGrid : CoinFrame edges V → ChoiceGrid) (edgeGrid : E → ChoiceGrid) :
    (order : List E) → order.toFinset ⊆ edges →
    List ((Finset E → Finset E → ℝ) × (Finset E → Finset E → ℝ))
  | [], _ => []
  | e :: previous, h =>
    let hp := order_tail_subset h
    (matchingRow ends edges e (fun A => prefixAcceptance ends previous.toFinset A x e),
      matchingRow ends edges e (fun A =>
        binaryAcceptance ends edges previous.toFinset A x r fuel B topGrid neighborGrid edgeGrid
          e (vertices e).1 (vertices e).2 hp)) ::
    binaryShearerSchedule ends vertices edges x r fuel B topGrid neighborGrid edgeGrid previous hp

theorem binaryShearerSchedule_ideal (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (fuel B : ℕ)
    (topGrid neighborGrid : CoinFrame edges V → ChoiceGrid) (edgeGrid : E → ChoiceGrid)
    (order : List E) (h : order.toFinset ⊆ edges) :
    (binaryShearerSchedule ends vertices edges x r fuel B topGrid neighborGrid edgeGrid order h).map Prod.fst =
      (shearerSchedule ends vertices edges x r fuel order h).map Prod.fst := by
  induction order with
  | nil => rfl
  | cons e prior ih => simp only [binaryShearerSchedule, shearerSchedule, List.map_cons, ih]

theorem binaryShearerSchedule_length (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (fuel B : ℕ)
    (topGrid neighborGrid : CoinFrame edges V → ChoiceGrid) (edgeGrid : E → ChoiceGrid)
    (order : List E) (h : order.toFinset ⊆ edges) :
    (binaryShearerSchedule ends vertices edges x r fuel B topGrid neighborGrid edgeGrid order h).length
      = order.length := by
  induction order with
  | nil => rfl
  | cons e prior ih => simp only [binaryShearerSchedule, List.length_cons, ih]

private theorem binaryMatchingRow_bounds (ends : E → Finset V) (edges P : Finset E)
    (x : E → ℝ) (r : ℝ) (hr : 1/2 ≤ r) (hr1 : r < 1)
    (hx : ∀ e ∈ edges, 0 ≤ x e) (hends : ∀ e ∈ edges, (ends e).card = 2)
    (hdegree : ∀ v, (∑ e ∈ incident ends edges v, x e) ≤ r*(1-r))
    (L B : ℕ) (topGrid neighborGrid : CoinFrame edges V → ChoiceGrid) (edgeGrid : E → ChoiceGrid)
    (e : E) (he : e ∈ edges) (u v : V) (huv : ends e = {u,v}) (hP : P ⊆ edges) :
    let auth := matchingRow ends edges e (fun A => prefixAcceptance ends P A x e)
    let bit := matchingRow ends edges e (fun A =>
      binaryAcceptance ends edges P A x r (2*L) B topGrid neighborGrid edgeGrid e u v hP)
    IsKernel (matchings ends edges) auth ∧ IsKernel (matchings ends edges) bit ∧
    ∀ A ∈ matchings ends edges, variation (matchings ends edges) (auth A) (bit A) ≤
      2*(4*r*(1-r))^L + (8*L+1)*((2:ℝ)^B)⁻¹ := by
  have h (A : Finset E) := binaryAcceptance_error ends edges P A x r hr hr1 hx hends hdegree
    L B topGrid neighborGrid edgeGrid e he u v huv hP
  dsimp only
  refine ⟨matchingRow_isKernel ends edges e _ (fun A _ => ⟨(h A).1.trans (h A).2.1, (h A).2.2.1⟩),
    matchingRow_isKernel ends edges e _ (fun A _ => ⟨(h A).1, (h A).2.1.trans (h A).2.2.1⟩), ?_⟩
  intro A hA
  apply (matchingRow_variation ends edges e _ _ A hA).trans
  rw [abs_of_nonneg (sub_nonneg.mpr (h A).2.1)]
  exact (h A).2.2.2

theorem binaryShearerSchedule_kernels (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (hr : 1/2 ≤ r) (hr1 : r < 1)
    (hx : ∀ e ∈ edges, 0 ≤ x e) (hends : ∀ e ∈ edges, (ends e).card = 2)
    (hpairs : ∀ e ∈ edges, ends e = {(vertices e).1, (vertices e).2})
    (hdegree : ∀ v, (∑ e ∈ incident ends edges v, x e) ≤ r*(1-r))
    (L B : ℕ) (topGrid neighborGrid : CoinFrame edges V → ChoiceGrid) (edgeGrid : E → ChoiceGrid)
    (order : List E) (h : order.toFinset ⊆ edges) :
    ∀ k ∈ binaryShearerSchedule ends vertices edges x r (2*L) B topGrid neighborGrid edgeGrid order h,
      IsKernel (matchings ends edges) k.1 ∧ IsKernel (matchings ends edges) k.2 ∧
      ∀ s ∈ matchings ends edges, variation (matchings ends edges) (k.1 s) (k.2 s) ≤
        2*(4*r*(1-r))^L + (8*L+1)*((2:ℝ)^B)⁻¹ := by
  induction order with
  | nil => simp [binaryShearerSchedule]
  | cons e prior ih =>
    intro k hk
    rw [binaryShearerSchedule] at hk
    rcases List.mem_cons.mp hk with hEq | hmem
    · subst k
      have he := h (List.mem_toFinset.mpr (List.mem_cons_self ..))
      exact binaryMatchingRow_bounds ends edges prior.toFinset x r hr hr1 hx hends hdegree
        L B topGrid neighborGrid edgeGrid e he (vertices e).1 (vertices e).2 (hpairs e he)
        (order_tail_subset h)
    · exact ih _ _ hmem

noncomputable def binaryShearerLaw (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (fuel B : ℕ)
    (topGrid neighborGrid : CoinFrame edges V → ChoiceGrid) (edgeGrid : E → ChoiceGrid)
    (order : List E) (h : order.toFinset ⊆ edges) : Finset E → ℝ :=
  applySchedule (matchings ends edges) (pointMass ∅)
    ((binaryShearerSchedule ends vertices edges x r fuel B topGrid neighborGrid edgeGrid order h).map Prod.snd)

/-- Combined output law after limiting both recursive trials and the
underlying rational primitive draws. -/
theorem binaryShearerLaw_variation (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (hr : 1/2 ≤ r) (hr1 : r < 1)
    (hx : ∀ e ∈ edges, 0 ≤ x e) (hends : ∀ e ∈ edges, (ends e).card = 2)
    (hpairs : ∀ e ∈ edges, ends e = {(vertices e).1, (vertices e).2})
    (hdegree : ∀ v, (∑ e ∈ incident ends edges v, x e) ≤ r*(1-r))
    (L B : ℕ) (topGrid neighborGrid : CoinFrame edges V → ChoiceGrid) (edgeGrid : E → ChoiceGrid)
    (order : List E) (hnodup : order.Nodup) (h : order.toFinset ⊆ edges) :
    let law := binaryShearerLaw ends vertices edges x r (2*L) B topGrid neighborGrid edgeGrid order h
    IsProbability (matchings ends edges) law ∧
    variation (matchings ends edges) (mass ends order.toFinset x) law ≤
      order.length*(2*(4*r*(1-r))^L + (8*L+1)*((2:ℝ)^B)⁻¹) := by
  let states := matchings ends edges
  let steps := binaryShearerSchedule ends vertices edges x r (2*L) B topGrid neighborGrid edgeGrid order h
  let initial := pointMass (∅ : Finset E)
  have hInit : IsProbability states initial := pointMass_probability states ∅ (empty_mem_matchings ends edges)
  have hK := binaryShearerSchedule_kernels ends vertices edges x r hr hr1 hx hends hpairs hdegree
    L B topGrid neighborGrid edgeGrid order h
  change IsProbability states (applySchedule states initial (steps.map Prod.snd)) ∧ _
  constructor
  · apply applySchedule_probability states initial hInit (steps.map Prod.snd)
    intro k hk
    obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hk
    exact (hK j hj).2.1
  · have hr0 : 0 < r := by linarith
    have hTV := variation_applySchedule states initial hInit steps _ hK
    have hEq (A : Finset E) (hA : A ∈ states) :
        applySchedule states initial (steps.map Prod.fst) A = mass ends order.toFinset x A := by
      dsimp only [steps]
      rw [binaryShearerSchedule_ideal]
      exact idealSchedule_eq_mass ends vertices edges x r hr0 hr1.le hx hends hdegree (2*L) order hnodup h A hA
    unfold variation at hTV ⊢
    have hSum :
        (∑ s ∈ states, |applySchedule states initial (steps.map Prod.fst) s -
            applySchedule states initial (steps.map Prod.snd) s|) =
        ∑ s ∈ states, |mass ends order.toFinset x s - applySchedule states initial (steps.map Prod.snd) s| :=
      Finset.sum_congr rfl (fun s hs => by rw [hEq s hs])
    rw [hSum, show steps.length = order.length from
      binaryShearerSchedule_length ends vertices edges x r (2*L) B topGrid neighborGrid edgeGrid order h] at hTV
    exact hTV

end SubmodularMatching.ShearerSampler
