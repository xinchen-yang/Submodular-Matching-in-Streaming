import SubmodularMatching.NumericalCertificate
import Mathlib.Algebra.Order.BigOperators.Group.Finset

open scoped BigOperators

namespace SubmodularMatching.FiniteError

/-- Keeping the best singleton absorbs the additive finite-precision error. -/
theorem absorb_additive (Y B allowance target : ℝ)
    (ha : 0 ≤ allowance) (hbest : B ≤ Y)
    (hbound : target ≤ Y + allowance * B) :
    target ≤ (1 + allowance) * Y := by
  have h := mul_le_mul_of_nonneg_left hbest ha
  nlinarith

/-- A finite expectation is at least a lower bound times the mass of a good
event, provided outcomes outside that event are nonnegative. -/
theorem expectation_from_good_event {α : Type*}
    (s : Finset α) (mass value : α → ℝ) (good : α → Prop) [DecidablePred good]
    (lower : ℝ) (hmass : ∀ i ∈ s, 0 ≤ mass i)
    (hvalue : ∀ i ∈ s, 0 ≤ value i)
    (hgood : ∀ i ∈ s, good i → lower ≤ value i) :
    lower * (∑ i ∈ s, if good i then mass i else 0) ≤
      ∑ i ∈ s, mass i * value i := by
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i hi
  by_cases hg : good i
  · simp only [hg, ↓reduceIte]
    nlinarith [mul_le_mul_of_nonneg_left (hgood i hi hg) (hmass i hi)]
  · simp only [hg, ↓reduceIte, mul_zero]
    exact mul_nonneg (hmass i hi) (hvalue i hi)

open NumericalCertificate

/-- The finite-error wrapper in Appendix K.4, specialized to Appendix L's
checked constants. `value i` is the conditional expected rounding output for
transcript `i`. The hypotheses expose the still-separate algorithmic accuracy
and rounding guarantees; this is not an existence theorem for a streaming
algorithm. It proves their exact implication for the finite output expectation. -/
theorem finite_expected_guarantee {α : Type*}
    (s : Finset α) (mass value best : α → ℝ)
    (good : α → Prop) [DecidablePred good] (opt : ℝ) (hopt : 0 ≤ opt)
    (hmass : ∀ i ∈ s, 0 ≤ mass i)
    (hvalue : ∀ i ∈ s, 0 ≤ value i)
    (hprob : 1 - finiteError ≤ ∑ i ∈ s, if good i then mass i else 0)
    (hbest : ∀ i ∈ s, good i → best i ≤ value i)
    (haccuracy : ∀ i ∈ s, good i →
      theta * min sigma beta * opt ≤ value i + 5 * finiteError * best i) :
    opt / targetFactor ≤ ∑ i ∈ s, mass i * value i := by
  let lower := theta * min sigma beta * opt / (1 + 5 * finiteError)
  have ha : 0 ≤ 5 * finiteError := by norm_num [finiteError]
  have hd : 0 < 1 + 5 * finiteError := by norm_num [finiteError]
  have hlower : 0 ≤ lower := by
    dsimp [lower]
    apply div_nonneg _ hd.le
    apply mul_nonneg _ hopt
    norm_num [theta, roundingError, sigma, beta]
  have hgood : ∀ i ∈ s, good i → lower ≤ value i := by
    intro i hi hg
    apply (div_le_iff₀ hd).2
    simpa only [mul_comm (value i)] using
      absorb_additive (value i) (best i) (5 * finiteError)
        (theta * min sigma beta * opt) ha (hbest i hi hg) (haccuracy i hi hg)
  have hmean := expectation_from_good_event s mass value good lower hmass hvalue hgood
  have hp := mul_le_mul_of_nonneg_left hprob hlower
  apply finite_bound_implies_stated_factor opt _ hopt
  calc
    ((1 - finiteError) * theta * min sigma beta / (1 + 5 * finiteError)) * opt =
        lower * (1 - finiteError) := by dsimp [lower]; ring
    _ ≤ lower * (∑ i ∈ s, if good i then mass i else 0) := hp
    _ ≤ ∑ i ∈ s, mass i * value i := hmean

end SubmodularMatching.FiniteError
