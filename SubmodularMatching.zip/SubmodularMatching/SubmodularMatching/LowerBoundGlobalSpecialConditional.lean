import SubmodularMatching.LowerBoundGlobalFresh

/-! # The conditional rare-edge estimate for the actual mixed stream -/

namespace SubmodularMatching.LowerBoundGlobal

open LowerBoundAssembly Information LowerBoundInformation
open scoped BigOperators

noncomputable section

variable {p N P t H : ℕ} {C State : Type*} [Fintype C] [DecidableEq C]
  [Sub C] [Fintype State] [Nonempty State] [Nonempty (Fin t)]

def phaseSpecialCount (b : BlueprintExpansion N P t H) (stage : Fin p) (phase : Fin P)
    (draw : HardDraw p N P t C) (output : Finset (HardEdge p N C)) : ℝ :=
  let J := (draw.1 stage).1
  (((phaseProjection stage (b.phases J phase) output).filter
    (fun e => specialBase (b.canonical J) (CloneLift.basePair e))).card : ℝ)

theorem actual_phase_special_count_le
    (b : BlueprintExpansion N P t H) (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (m : Machine (HardEdge p N C) State) (unit : ℝ)
    (ctx : PhaseContext p N P t C)
    (hpast : 0 < pastPhaseLaw b q ctx.phase ctx.history)
    (hlegal : ∀ S next, 0 < phaseRetainedMass b q
        (representative ctx.phase ctx.history.1) ctx.phase S →
      0 < nextPhaseLaw b q ctx.phase ctx.history.1 next →
      let draw := ctx.combine S next
      m.legal (hardOracle unit draw) (hardStream b draw) ∧
        HardMatching (m.output (hardOracle unit draw) (hardStream b draw)))
    (s : ℕ) (hstates : Fintype.card State ≤ 2 ^ s) :
    (∑ S, phaseRetainedMass b q (representative ctx.phase ctx.history.1) ctx.phase S *
      ∑ next, nextPhaseLaw b q ctx.phase ctx.history.1 next *
        phaseSpecialCount b ctx.stage ctx.phase (ctx.combine S next)
          (m.output (hardOracle unit (ctx.combine S next)) (hardStream b (ctx.combine S next)))) ≤
      (Fintype.card C : ℝ) * ((P : ℝ) / t * (s / Real.logb 2 (1 / q))) := by
  classical
  let J := representative ctx.phase ctx.history.1
  let U := ctx.oldUniverse b
  let k := retainedSize q U.card
  let μ := uniformSubsetMass U k
  let ν := nextPhaseLaw b q ctx.phase ctx.history.1
  let Jnew := fun next : ctx.Draw => mergeTuple ctx.phase ctx.history.1 next.1
  let special := fun next : ctx.Draw => fun e : Fin N × Fin N =>
    e ∈ U ∧ specialBase (b.canonical (Jnew next)) e
  let oracle := mixedOracle unit hardPublicLabel ctx.clones
  let state := fun S => m.boundary oracle m.initial (ctx.before b ++ ctx.block S)
  let projectOutput := fun y next =>
    phaseProjection ctx.stage U (m.outputFrom oracle y (ctx.after b next))
  let output := fun y next =>
    if 0 < ν next ∧ CloneLift.IsMatching (projectOutput y next)
        then projectOutput y next else ∅

  have hphase (next : ctx.Draw) : b.phases (Jnew next) ctx.phase = U :=
    b.prefix_invariance _ _ _ (mergeTuple_mem_prefix ctx.phase ctx.history.1 next.1)
  have hobs (S : PhaseSample N) (next : ctx.Draw) :
      phaseSpecialCount b ctx.stage ctx.phase (ctx.combine S next)
        (m.output (hardOracle unit (ctx.combine S next)) (hardStream b (ctx.combine S next))) =
      (((projectOutput (state S) next).filter
        (fun e => specialBase (b.canonical (Jnew next)) (CloneLift.basePair e))).card : ℝ) := by
    unfold phaseSpecialCount
    rw [ctx.baseDraw_eq S next]
    change (((phaseProjection ctx.stage (b.phases (Jnew next) ctx.phase)
      (m.output (hardOracle unit (ctx.combine S next)) (hardStream b (ctx.combine S next)))).filter
        (fun e => specialBase (b.canonical (Jnew next)) (CloneLift.basePair e))).card : ℝ) = _
    rw [hphase next, ctx.stream_eq b S next, m.output_append]
    rfl
  by_cases hU0 : U.card = 0
  · have hempty : U = ∅ := Finset.card_eq_zero.mp hU0
    simp_rw [hobs]
    have hz (S : PhaseSample N) (next : ctx.Draw) : projectOutput (state S) next = ∅ := by
      ext e
      simp [projectOutput, mem_phaseProjection, hempty]
    simp only [hz, Finset.filter_empty, Finset.card_empty, Nat.cast_zero, mul_zero,
      Finset.sum_const_zero]
    have hlog : 0 < Real.logb 2 (1 / q) :=
      Real.logb_pos (by norm_num : (1 : ℝ) < 2) ((one_lt_div hq0).2 hq1)
    exact mul_nonneg (Nat.cast_nonneg _) (mul_nonneg (by positivity) (by positivity))
  have hU : 0 < U.card := Nat.pos_of_ne_zero hU0
  have hk : k ≤ U.card := retainedSize_le hq0.le hq1.le _
  have hqr : ((k : ℝ) / U.card) ≤ q := by
    have hpos : (0 : ℝ) < U.card := by exact_mod_cast hU
    apply (div_le_iff₀ hpos).2
    exact Nat.floor_le (by positivity)
  have hactual (S : PhaseSample N) (next : ctx.Draw) :
      projectOutput (state S) next = phaseProjection ctx.stage U
        (m.output (hardOracle unit (ctx.combine S next)) (hardStream b (ctx.combine S next))) := by
    rw [ctx.stream_eq b S next, m.output_append]
    rfl
  have hactive (S : PhaseSample N) (next : ctx.Draw) (hS : 0 < μ S) (hn : 0 < ν next) :
      output (state S) next = projectOutput (state S) next := by
    have hm := (hlegal S next hS hn).2
    have hm' : CloneLift.IsMatching (projectOutput (state S) next) := by
      rw [hactual S next]
      exact phaseProjection_matching hm
    simp only [output, if_pos (And.intro hn hm')]
  have hv : ∀ S, 0 < μ S → ∀ next, (output (state S) next).image CloneLift.basePair ⊆ S := by
    intro S hS next
    by_cases hn : 0 < ν next
    · rw [hactive S next hS hn, hactual S next]
      have hsup : m.output (hardOracle unit (ctx.combine S next)) (hardStream b (ctx.combine S next)) ⊆
          (ctx.before b ++ ctx.block S ++ ctx.after b next).toFinset := by
        rw [← ctx.stream_eq b S next]
        exact (hlegal S next hS hn).1.2.2
      exact phaseProjection_subset_of_legal_output ctx.stage U S (ctx.before b) (ctx.after b next)
        (ctx.clones ctx.stage).1 _ (ctx.before_fresh b q hpast)
        (ctx.after_fresh b q next hn) hsup
    · simp only [output, hn, false_and, if_false, Finset.image_empty, Finset.empty_subset]
  have hmatching (y : State) (next : ctx.Draw) : CloneLift.IsMatching (output y next) := by
    unfold output
    split_ifs with h
    · exact h.2
    · simp [CloneLift.IsMatching, Set.InjOn]
  have hbound := expected_special_clone_edges_le μ id state ν special output ((P : ℝ) / t) q s
    (uniformSubsetMass_nonneg U k) (sum_uniformSubsetMass U k hk)
    (nextPhaseLaw_nonneg b q ctx.phase ctx.history.1) (by positivity) hq0 hq1
    (fun A => (uniformSubsetMass_inclusion_le U A k hU hk).trans
      (pow_le_pow_left₀ (by positivity) hqr A.card)) hstates
    (nextPhaseLaw_rarity b q hq0.le hq1.le ctx.phase ctx.history.1) hmatching hv
  calc
    _ = ∑ S, μ S * ∑ next, ν next *
      (((output (state S) next).filter (fun e => special next (CloneLift.basePair e))).card : ℝ) := by
      apply Finset.sum_congr rfl
      intro S _
      change μ S * _ = μ S * _
      by_cases hS : 0 < μ S
      · congr 1
        apply Finset.sum_congr rfl
        intro next _
        by_cases hn : 0 < ν next
        · rw [hobs, hactive S next hS hn]
          congr 3
          ext e
          simp only [Finset.mem_filter, special]
          constructor
          · rintro ⟨he, hs⟩
            exact ⟨he, (mem_phaseProjection.mp he).2, hs⟩
          · rintro ⟨he, _, hs⟩
            exact ⟨he, hs⟩
        · have hz := le_antisymm (not_lt.mp hn) (nextPhaseLaw_nonneg b q ctx.phase ctx.history.1 next)
          change ν next * _ = ν next * _
          simp only [hz, zero_mul]
      · have hz := le_antisymm (not_lt.mp hS) (uniformSubsetMass_nonneg U k S)
        simp only [hz, zero_mul]
    _ ≤ _ := hbound

end

end SubmodularMatching.LowerBoundGlobal
