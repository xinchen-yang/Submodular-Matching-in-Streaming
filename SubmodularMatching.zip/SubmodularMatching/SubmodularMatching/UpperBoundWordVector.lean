import SubmodularMatching.UpperBoundWordSelector

/-! # The finite-word law of an arbitrary inclusion vector -/

namespace SubmodularMatching.Streaming

open MeasureTheory

noncomputable section

variable {E : Type*} [DecidableEq E]

/-- This natural index just expresses a floor. Every floating-scale
quantity fed to the algorithm is on an exact rational grid. -/
def realWordThreshold (p : ℝ) (bits : ℕ) : ℕ := ⌊(2 : ℝ) ^ bits * p⌋.toNat

theorem realWordThreshold_le (p : ℝ) (hp : p ≤ 1) (bits : ℕ) :
    realWordThreshold p bits ≤ 2 ^ bits := by
  unfold realWordThreshold
  apply Int.toNat_le.mpr
  have h := (Int.floor_le ((2 : ℝ) ^ bits * p)).trans
    ((mul_le_mul_of_nonneg_left hp (by positivity : 0 ≤ (2 : ℝ) ^ bits)).trans_eq (mul_one _))
  exact_mod_cast h

theorem realWordThreshold_probability (p : ℝ) (hp : 0 ≤ p) (bits : ℕ) :
    (realWordThreshold p bits : ℝ) / ((2 ^ bits : ℕ) : ℝ) = bitProbability p bits := by
  unfold realWordThreshold bitProbability
  have hh : 0 ≤ ⌊(2 : ℝ) ^ bits * p⌋ := Int.floor_nonneg.2 (mul_nonneg (by positivity) hp)
  have he : ((⌊(2 : ℝ) ^ bits * p⌋.toNat : ℕ) : ℝ) = (⌊(2 : ℝ) ^ bits * p⌋ : ℤ) := by
    exact_mod_cast Int.toNat_of_nonneg hh
  rw [he]
  push_cast <;> rfl

theorem rational_threshold_exact (p : ℚ) (bits : ℕ) :
    realWordThreshold p bits = dyadicThreshold p bits := by
  unfold realWordThreshold dyadicThreshold
  have h := Rat.floor_cast (α := ℝ) ((2 : ℚ) ^ bits * p)
  push_cast at h
  rw [h]

def selectWordVector (edges : ℕ → E) (q : ℕ → ℝ) (n bits : ℕ)
    (draw : Fin n → Fin (2 ^ bits)) : Finset E :=
  selectThresholdWords edges (finiteWord (2 ^ bits) n draw) (fun i => realWordThreshold (q i) bits) n

/-- Counting the independent finite words recovers the normalized product
law of the downward-rounded probabilities. -/
theorem selectWordVector_expectation (edges : ℕ → E) (q : ℕ → ℝ)
    (n bits : ℕ) (hq : ∀ i, 0 ≤ q i ∧ q i ≤ 1) (F : Finset E → ℝ) :
    (∫ ω, F (selectWordVector edges q n bits ω) ∂wordLaw n bits) =
      bernoulliExpectation edges (fun i => bitProbability (q i) bits) F n := by
  rw [marginal_wordLaw_eq_uniform]
  unfold selectWordVector
  rw [exact_thresholdWord_expectation edges (2 ^ bits) n _ (by positivity)
    (fun i _ => realWordThreshold_le (q i) (hq i).2 bits)]
  simp_rw [realWordThreshold_probability _ (hq _).1]

end

end SubmodularMatching.Streaming
