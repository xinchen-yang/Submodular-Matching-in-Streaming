import SubmodularMatching.AppendixMNumericalLogCheck
namespace SubmodularMatching.AppendixM
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
theorem logBlock01 : logBlock 9 8 = true := by decide +kernel
end SubmodularMatching.AppendixM
