import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull003_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 567, 119, 0x46e1fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull003_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 251, 253, 2, 0x3f47e0fb⟩ (by decide +kernel)

private def hull003_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 251, 256, 2, 0x4007e0fb⟩ (by decide +kernel)

private def hull003_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 52, 17, 0x1a0330640c41802f05c0b41602b0540a41402704c09412023⟩ (by decide +kernel)

private def hull003_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 247, 251, 2, 0x3ec7d0f7⟩ (by decide +kernel)

private def hull003_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 39, 4, 0x2704c09412023⟩ (by decide +kernel)

private def hull003_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 247, 249, 2, 0x3e47c0f7⟩ (by decide +kernel)

private def hull003_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 39, 41, 2, 0xa414027⟩ (by decide +kernel)

private def hull003_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 249, 251, 2, 0x3ec7d0f9⟩ (by decide +kernel)

private def hull003_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 41, 43, 2, 0xac15029⟩ (by decide +kernel)

private def hull003_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 43, 52, 9, 0x1a0330640c41802f05c0b41602b⟩ (by decide +kernel)

private def hull003_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 70, 61, 0x2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull003_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 212, 229, 11, 0x1ca390718e21c237c6d8da1b23586a8d4⟩ (by decide +kernel)

private def hull003_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 229, 247, 2, 0x3dc750e5⟩ (by decide +kernel)

private def hull003_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 229, 238, 3, 0x1dc3b4750e5⟩ (by decide +kernel)

private def hull003_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 238, 242, 3, 0x1e43c0778ee⟩ (by decide +kernel)

private def hull003_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 242, 247, 1, 0x7b8f2⟩ (by decide +kernel)

private def hull003_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 242, 244, 1, 0x7a0f2⟩ (by decide +kernel)

private def hull003_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 244, 245, 1, 0x7a8f4⟩ (by decide +kernel)

private def hull003_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 245, 247, 2, 0x3dc7b0f5⟩ (by decide +kernel)

private def hull003_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 39, 43, 4, 0x2b0540a414027⟩ (by decide +kernel)

private def hull003_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 37, 2, 0x9412023⟩ (by decide +kernel)

private def hull003_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 37, 39, 2, 0x9c13025⟩ (by decide +kernel)

private def hull003_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 242, 243, 1, 0x798f2⟩ (by decide +kernel)

private def hull003_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 243, 244, 1, 0x7a0f3⟩ (by decide +kernel)

private def hull003_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 244, 247, 1, 0x7b8f4⟩ (by decide +kernel)

private def hull003_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 238, 247, 2, 0x3dc778ee⟩ (by decide +kernel)

private def hull003_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 17, 8, 0x1102003c0700d01802001800⟩ (by decide +kernel)

private def hull003_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 26, 9, 0xd01903005c0b01502804c09011⟩ (by decide +kernel)

private def hull003_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 26, 30, 4, 0x1e03a0700d81a⟩ (by decide +kernel)

private def hull003_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 30, 35, 5, 0x118220420800f81e⟩ (by decide +kernel)

private def hull003_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 238, 240, 2, 0x3c0778ee⟩ (by decide +kernel)

private def hull003_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 240, 241, 1, 0x788f0⟩ (by decide +kernel)

private def hull003_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 241, 242, 1, 0x790f1⟩ (by decide +kernel)

private def hull003_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 35, 18, 0x8c1102104007c0f01d03806c0d01903005c0b01502804c09011⟩ (by decide +kernel)

private def hull003_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 21, 4, 0x1502804c09011⟩ (by decide +kernel)

private def hull003_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 21, 26, 5, 0xd01903005c0b015⟩ (by decide +kernel)

private def hull003_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 26, 35, 9, 0x118220420800f81e03a0700d81a⟩ (by decide +kernel)

private def hull003_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 229, 233, 1, 0x748e5⟩ (by decide +kernel)

private def hull003_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 233, 238, 3, 0x1dc3b4750e9⟩ (by decide +kernel)

private def hull003_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 233, 235, 2, 0x3ac750e9⟩ (by decide +kernel)

private def hull003_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 21, 23, 2, 0x5c0b015⟩ (by decide +kernel)

private def hull003_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 235, 238, 2, 0x3b8768eb⟩ (by decide +kernel)

private def hull003_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 23, 26, 3, 0x340640c017⟩ (by decide +kernel)

private def hull003_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 235, 236, 1, 0x760eb⟩ (by decide +kernel)

private def hull003_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 236, 238, 2, 0x3b8768ec⟩ (by decide +kernel)

private def hull003_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 141, 283, 24, 0x11b1522a0530a51462885009f13a2704d89913025c4b09512824c4909112023c4708d⟩ (by decide +kernel)

private def hull003_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 35, 26, 0x8c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull003_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 229, 231, 1, 0x738e5⟩ (by decide +kernel)

private def hull003_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 231, 233, 2, 0x3a4740e7⟩ (by decide +kernel)

private def supportedCone0384 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 30, 29, 31⟩, ⟨890944115, 29450357, 1605927162, 55162689, 253394072838, 391140221⟩⟩
    hull003_000 21 (by decide +kernel)

private def supportedCone0385 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨251, 253, 252, 251, 253⟩, ⟨1189561748, 1010553767, 1313582947, 1117032827, 1032536792320, 545939363127⟩⟩
    hull003_001 1 (by decide +kernel)

private def supportedCone0386 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 29, 28, 30⟩, ⟨1119836040, 35468747, 890944115, 29450357, 252503128723, 361689864⟩⟩
    hull003_000 20 (by decide +kernel)

private def supportedCone0387 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨251, 256, 252, 251, 256⟩, ⟨1189561748, 1010553767, 4957093636, 4215242861, 1032536792320, 545939363127⟩⟩
    hull003_002 1 (by decide +kernel)

private def supportedCone0388 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 40, 39, 41⟩, ⟨912885189, 53518492, 1466867611, 87366046, 265912885189, 963567077⟩⟩
    hull003_000 31 (by decide +kernel)

private def supportedCone0389 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 28, 27, 29⟩, ⟨1383292683, 42240405, 1119836040, 35468747, 251383292683, 326221117⟩⟩
    hull003_000 19 (by decide +kernel)

private def supportedCone0390 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 41, 40, 42⟩, ⟨1466867611, 87366046, 821856399, 51327005, 267379752800, 1050933123⟩⟩
    hull003_003 6 (by decide +kernel)

private def supportedCone0391 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 52, 40, 39, 41⟩, ⟨912885189, 53518492, 1466867611, 87366046, 265912885189, 963567077⟩⟩
    hull003_003 5 (by decide +kernel)

private def supportedCone0392 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 251, 247, 247, 250⟩, ⟨0, 0, 3606858820, 3067192395, 1026393141180, 540715712245⟩⟩
    hull003_004 0 (by decide +kernel)

private def supportedCone0393 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 39, 39, 38, 39⟩, ⟨1225499220, 67598571, 0, 0, 265000000000, 910048585⟩⟩
    hull003_005 4 (by decide +kernel)

private def supportedCone0394 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 249, 247, 247, 248⟩, ⟨0, 0, 1195078655, 1016282853, 1026393141180, 540715712245⟩⟩
    hull003_006 0 (by decide +kernel)

private def supportedCone0395 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨39, 41, 40, 39, 41⟩, ⟨912885189, 53518492, 1466867611, 87366046, 265912885189, 963567077⟩⟩
    hull003_007 1 (by decide +kernel)

private def supportedCone0396 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨249, 251, 249, 249, 250⟩, ⟨0, 0, 1129164190, 960141142, 1028870835810, 542822763498⟩⟩
    hull003_008 0 (by decide +kernel)

private def supportedCone0397 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨41, 43, 41, 41, 42⟩, ⟨0, 0, 821856399, 51327005, 267379752800, 1050933123⟩⟩
    hull003_009 0 (by decide +kernel)

private def supportedCone0398 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨43, 52, 43, 43, 44⟩, ⟨0, 0, 1265352162, 86554930, 270000000000, 1218562464⟩⟩
    hull003_010 0 (by decide +kernel)

private def supportedCone0399 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨247, 249, 248, 247, 249⟩, ⟨1195078655, 1016282853, 1282615975, 1090768400, 1027588219835, 541731995098⟩⟩
    hull003_006 1 (by decide +kernel)

private def supportedCone0400 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 39, 38, 40⟩, ⟨1225499220, 67598571, 912885189, 53518492, 265000000000, 910048585⟩⟩
    hull003_011 30 (by decide +kernel)

private def supportedCone0401 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 0, 0, 3⟩, ⟨0, 0, 200000000000, 0, 0, 0⟩⟩
    hull003_011 0 (by decide +kernel)

private def supportedCone0402 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 38, 37, 39⟩, ⟨1099837485, 58486581, 1225499220, 67598571, 263774500780, 842450014⟩⟩
    hull003_011 29 (by decide +kernel)

private def supportedCone0403 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 25, 24, 26⟩, ⟨1142765542, 29098135, 1603882869, 43246842, 247550653691, 216274335⟩⟩
    hull003_000 16 (by decide +kernel)

private def supportedCone0404 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 226, 225, 227⟩, ⟨5000000000, 4252000554, 5000000000, 4266024948, 960000000000, 484257119887⟩⟩
    hull003_012 8 (by decide +kernel)

private def supportedCone0405 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 247, 247, 234, 247⟩, ⟨20070091977, 17065328395, 0, 0, 1026393141180, 540715712245⟩⟩
    hull003_013 2 (by decide +kernel)

private def supportedCone0406 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 238, 237, 234, 238⟩, ⟨3676950797, 3126742212, 1200961509, 1021540591, 1010000000000, 526777126062⟩⟩
    hull003_014 2 (by decide +kernel)

private def supportedCone0407 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨238, 242, 242, 240, 242⟩, ⟨6279494768, 5339977089, 0, 0, 1020000000000, 535280520789⟩⟩
    hull003_015 3 (by decide +kernel)

private def supportedCone0408 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨242, 247, 247, 242, 247⟩, ⟨6393141180, 5435191456, 0, 0, 1026393141180, 540715712245⟩⟩
    hull003_016 1 (by decide +kernel)

private def supportedCone0409 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨242, 244, 244, 242, 244⟩, ⟨2489549281, 2116523424, 0, 0, 1022489549281, 537397044213⟩⟩
    hull003_017 1 (by decide +kernel)

private def supportedCone0410 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 39, 37, 36, 38⟩, ⟨1418082341, 71124003, 1099837485, 58486581, 262674663295, 783963433⟩⟩
    hull003_005 2 (by decide +kernel)

private def supportedCone0411 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨244, 245, 244, 244, 245⟩, ⟨0, 0, 1251428064, 1064444556, 1022489549281, 537397044213⟩⟩
    hull003_018 0 (by decide +kernel)

private def supportedCone0412 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨245, 247, 246, 245, 247⟩, ⟨1259022655, 1069932782, 1393141180, 1184290694, 1025000000000, 539531421551⟩⟩
    hull003_019 1 (by decide +kernel)

private def supportedCone0413 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨39, 43, 39, 39, 40⟩, ⟨0, 0, 912885189, 53518492, 265000000000, 910048585⟩⟩
    hull003_020 0 (by decide +kernel)

private def supportedCone0414 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨242, 247, 242, 242, 247⟩, ⟨0, 0, 6393141180, 5435191456, 1020000000000, 535280520789⟩⟩
    hull003_016 0 (by decide +kernel)

private def supportedCone0415 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 37, 36, 38⟩, ⟨1418082341, 71124003, 1099837485, 58486581, 262674663295, 783963433⟩⟩
    hull003_011 28 (by decide +kernel)

def appendixHullConeBlock0012 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0384,
    supportedCone0385,
    supportedCone0386,
    supportedCone0387,
    supportedCone0388,
    supportedCone0389,
    supportedCone0390,
    supportedCone0391,
    supportedCone0392,
    supportedCone0393,
    supportedCone0394,
    supportedCone0395,
    supportedCone0396,
    supportedCone0397,
    supportedCone0398,
    supportedCone0399,
    supportedCone0400,
    supportedCone0401,
    supportedCone0402,
    supportedCone0403,
    supportedCone0404,
    supportedCone0405,
    supportedCone0406,
    supportedCone0407,
    supportedCone0408,
    supportedCone0409,
    supportedCone0410,
    supportedCone0411,
    supportedCone0412,
    supportedCone0413,
    supportedCone0414,
    supportedCone0415,
  ], rfl⟩

private def supportedCone0416 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 223, 219, 225⟩, ⟨20000000000, 17007995800, 10000000000, 8503999700, 945000000000, 471501119633⟩⟩
    hull003_012 6 (by decide +kernel)

private def supportedCone0417 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 218, 217, 219⟩, ⟨5000000000, 4251996308, 25000000000, 21259991261, 900000000000, 433233132572⟩⟩
    hull003_012 4 (by decide +kernel)

private def supportedCone0418 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 217, 214, 218⟩, ⟨15000000000, 12755971591, 5000000000, 4251996308, 895000000000, 428981136264⟩⟩
    hull003_012 3 (by decide +kernel)

private def supportedCone0419 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 214, 213, 217⟩, ⟨10000000000, 8503978949, 15000000000, 12755971591, 880000000000, 416225164673⟩⟩
    hull003_012 2 (by decide +kernel)

private def supportedCone0420 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 213, 212, 214⟩, ⟨5000000000, 4251984710, 10000000000, 8503978949, 870000000000, 407721185724⟩⟩
    hull003_012 1 (by decide +kernel)

private def supportedCone0421 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 212, 212, 213⟩, ⟨0, 0, 5000000000, 4251984710, 865000000000, 403469201014⟩⟩
    hull003_012 0 (by decide +kernel)

private def supportedCone0422 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨245, 247, 245, 245, 246⟩, ⟨0, 0, 1259022655, 1069932782, 1023740977345, 538461488769⟩⟩
    hull003_019 0 (by decide +kernel)

private def supportedCone0423 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 39, 36, 35, 37⟩, ⟨1256580954, 61153129, 1418082341, 71124003, 261256580954, 712839430⟩⟩
    hull003_005 1 (by decide +kernel)

private def supportedCone0424 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 36, 35, 37⟩, ⟨1256580954, 61153129, 1418082341, 71124003, 261256580954, 712839430⟩⟩
    hull003_011 27 (by decide +kernel)

private def supportedCone0425 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 37, 36, 35, 37⟩, ⟨1256580954, 61153129, 1418082341, 71124003, 261256580954, 712839430⟩⟩
    hull003_021 1 (by decide +kernel)

private def supportedCone0426 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨37, 39, 37, 37, 38⟩, ⟨0, 0, 1099837485, 58486581, 262674663295, 783963433⟩⟩
    hull003_022 0 (by decide +kernel)

private def supportedCone0427 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 219, 218, 223⟩, ⟨25000000000, 21259991261, 20000000000, 17007995800, 925000000000, 454493123833⟩⟩
    hull003_012 5 (by decide +kernel)

private def supportedCone0428 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 225, 223, 226⟩, ⟨10000000000, 8503999700, 5000000000, 4252000554, 955000000000, 480005119333⟩⟩
    hull003_012 7 (by decide +kernel)

private def supportedCone0429 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 35, 34, 36⟩, ⟨1503327172, 68709630, 1256580954, 61153129, 260000000000, 651686301⟩⟩
    hull003_011 26 (by decide +kernel)

private def supportedCone0430 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 34, 33, 35⟩, ⟨827221629, 34669607, 1503327172, 68709630, 258496672828, 582976671⟩⟩
    hull003_011 25 (by decide +kernel)

private def supportedCone0431 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨242, 243, 242, 242, 243⟩, ⟨0, 0, 1309115591, 1113391372, 1020000000000, 535280520789⟩⟩
    hull003_023 0 (by decide +kernel)

private def supportedCone0432 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨243, 244, 243, 243, 244⟩, ⟨0, 0, 1180433690, 1003132052, 1021309115591, 536393912161⟩⟩
    hull003_024 0 (by decide +kernel)

private def supportedCone0433 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨242, 244, 242, 242, 244⟩, ⟨0, 0, 2489549281, 2116523424, 1020000000000, 535280520789⟩⟩
    hull003_017 0 (by decide +kernel)

private def supportedCone0434 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨244, 247, 244, 244, 247⟩, ⟨0, 0, 3903591899, 3318668032, 1022489549281, 537397044213⟩⟩
    hull003_025 0 (by decide +kernel)

private def supportedCone0435 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨243, 244, 244, 243, 244⟩, ⟨1180433690, 1003132052, 0, 0, 1022489549281, 537397044213⟩⟩
    hull003_024 1 (by decide +kernel)

private def supportedCone0436 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 33, 32, 34⟩, ⟨1263823080, 49116029, 827221629, 34669607, 257669451199, 548307064⟩⟩
    hull003_011 24 (by decide +kernel)

private def supportedCone0437 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 32, 31, 33⟩, ⟨1405628119, 52888125, 1263823080, 49116029, 256405628119, 499191035⟩⟩
    hull003_000 23 (by decide +kernel)

private def supportedCone0438 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 23, 22, 24⟩, ⟨929323095, 19209070, 1407888149, 33953019, 245000000000, 153223181⟩⟩
    hull003_000 14 (by decide +kernel)

private def supportedCone0439 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨238, 247, 247, 239, 247⟩, ⟨13882766151, 11804186786, 0, 0, 1026393141180, 540715712245⟩⟩
    hull003_026 2 (by decide +kernel)

private def supportedCone0440 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨238, 247, 239, 238, 247⟩, ⟨1309413520, 1112858806, 13882766151, 11804186786, 1012510375029, 528911525459⟩⟩
    hull003_026 1 (by decide +kernel)

private def supportedCone0441 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 17, 17, 16, 17⟩, ⟨1516608462, 14915504, 0, 0, 237415209672, 37965431⟩⟩
    hull003_027 8 (by decide +kernel)

private def supportedCone0442 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 26, 26, 25, 26⟩, ⟨1603882869, 43246842, 0, 0, 249154536560, 259521177⟩⟩
    hull003_028 9 (by decide +kernel)

private def supportedCone0443 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨26, 30, 30, 29, 30⟩, ⟨890944115, 29450357, 0, 0, 253394072838, 391140221⟩⟩
    hull003_029 4 (by decide +kernel)

private def supportedCone0444 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨30, 35, 33, 32, 34⟩, ⟨1263823080, 49116029, 827221629, 34669607, 257669451199, 548307064⟩⟩
    hull003_030 3 (by decide +kernel)

private def supportedCone0445 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨30, 35, 30, 30, 31⟩, ⟨0, 0, 1605927162, 55162689, 253394072838, 391140221⟩⟩
    hull003_030 0 (by decide +kernel)

private def supportedCone0446 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 247, 229, 229, 234⟩, ⟨0, 0, 31323049203, 26575777936, 975000000000, 497074605914⟩⟩
    hull003_013 0 (by decide +kernel)

private def supportedCone0447 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨30, 35, 32, 31, 33⟩, ⟨1405628119, 52888125, 1263823080, 49116029, 256405628119, 499191035⟩⟩
    hull003_030 2 (by decide +kernel)

def appendixHullConeBlock0013 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0416,
    supportedCone0417,
    supportedCone0418,
    supportedCone0419,
    supportedCone0420,
    supportedCone0421,
    supportedCone0422,
    supportedCone0423,
    supportedCone0424,
    supportedCone0425,
    supportedCone0426,
    supportedCone0427,
    supportedCone0428,
    supportedCone0429,
    supportedCone0430,
    supportedCone0431,
    supportedCone0432,
    supportedCone0433,
    supportedCone0434,
    supportedCone0435,
    supportedCone0436,
    supportedCone0437,
    supportedCone0438,
    supportedCone0439,
    supportedCone0440,
    supportedCone0441,
    supportedCone0442,
    supportedCone0443,
    supportedCone0444,
    supportedCone0445,
    supportedCone0446,
    supportedCone0447,
  ], rfl⟩

private def supportedCone0448 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 32, 31, 33⟩, ⟨1405628119, 52888125, 1263823080, 49116029, 256405628119, 499191035⟩⟩
    hull003_011 23 (by decide +kernel)

private def supportedCone0449 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨238, 242, 240, 239, 242⟩, ⟨1210130203, 1029018241, 6279494768, 5339977089, 1013720505232, 529940543700⟩⟩
    hull003_015 2 (by decide +kernel)

private def supportedCone0450 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨238, 240, 240, 239, 240⟩, ⟨1210130203, 1029018241, 0, 0, 1013720505232, 529940543700⟩⟩
    hull003_031 2 (by decide +kernel)

private def supportedCone0451 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨240, 241, 240, 240, 241⟩, ⟨0, 0, 4958466658, 4216662586, 1013720505232, 529940543700⟩⟩
    hull003_032 0 (by decide +kernel)

private def supportedCone0452 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨241, 242, 241, 241, 242⟩, ⟨0, 0, 1321028110, 1123314503, 1018678971890, 534157206286⟩⟩
    hull003_033 0 (by decide +kernel)

private def supportedCone0453 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨240, 241, 241, 240, 241⟩, ⟨4958466658, 4216662586, 0, 0, 1018678971890, 534157206286⟩⟩
    hull003_032 1 (by decide +kernel)

private def supportedCone0454 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 247, 234, 229, 247⟩, ⟨31323049203, 26575777936, 20070091977, 17065328395, 1006323049203, 523650383850⟩⟩
    hull003_013 1 (by decide +kernel)

private def supportedCone0455 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 31, 30, 32⟩, ⟨1605927162, 55162689, 1405628119, 52888125, 255000000000, 446302910⟩⟩
    hull003_011 22 (by decide +kernel)

private def supportedCone0456 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 30, 29, 31⟩, ⟨890944115, 29450357, 1605927162, 55162689, 253394072838, 391140221⟩⟩
    hull003_034 13 (by decide +kernel)

private def supportedCone0457 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 17, 17, 18⟩, ⟨0, 0, 1385503170, 16446452, 237415209672, 37965431⟩⟩
    hull003_034 0 (by decide +kernel)

private def supportedCone0458 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 28, 27, 29⟩, ⟨1383292683, 42240405, 1119836040, 35468747, 251383292683, 326221117⟩⟩
    hull003_034 11 (by decide +kernel)

private def supportedCone0459 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 27, 26, 28⟩, ⟨845463440, 24459535, 1383292683, 42240405, 250000000000, 283980712⟩⟩
    hull003_034 10 (by decide +kernel)

private def supportedCone0460 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 27, 26, 28⟩, ⟨845463440, 24459535, 1383292683, 42240405, 250000000000, 283980712⟩⟩
    hull003_000 18 (by decide +kernel)

private def supportedCone0461 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 26, 25, 27⟩, ⟨1603882869, 43246842, 845463440, 24459535, 249154536560, 259521177⟩⟩
    hull003_000 17 (by decide +kernel)

private def supportedCone0462 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 26, 25, 27⟩, ⟨1603882869, 43246842, 845463440, 24459535, 249154536560, 259521177⟩⟩
    hull003_034 9 (by decide +kernel)

private def supportedCone0463 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 25, 24, 26⟩, ⟨1142765542, 29098135, 1603882869, 43246842, 247550653691, 216274335⟩⟩
    hull003_034 8 (by decide +kernel)

private def supportedCone0464 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨238, 247, 238, 238, 239⟩, ⟨0, 0, 1309413520, 1112858806, 1011200961509, 527798666653⟩⟩
    hull003_026 0 (by decide +kernel)

private def supportedCone0465 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 24, 23, 25⟩, ⟨1407888149, 33953019, 1142765542, 29098135, 246407888149, 187176200⟩⟩
    hull003_034 7 (by decide +kernel)

private def supportedCone0466 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 24, 23, 25⟩, ⟨1407888149, 33953019, 1142765542, 29098135, 246407888149, 187176200⟩⟩
    hull003_000 15 (by decide +kernel)

private def supportedCone0467 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 21, 21, 20, 21⟩, ⟨1970044404, 29103683, 0, 0, 242625893577, 107379951⟩⟩
    hull003_035 4 (by decide +kernel)

private def supportedCone0468 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨21, 26, 24, 23, 25⟩, ⟨1407888149, 33953019, 1142765542, 29098135, 246407888149, 187176200⟩⟩
    hull003_036 3 (by decide +kernel)

private def supportedCone0469 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨21, 26, 23, 22, 24⟩, ⟨929323095, 19209070, 1407888149, 33953019, 245000000000, 153223181⟩⟩
    hull003_036 2 (by decide +kernel)

private def supportedCone0470 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨26, 35, 26, 26, 27⟩, ⟨0, 0, 845463440, 24459535, 249154536560, 259521177⟩⟩
    hull003_037 0 (by decide +kernel)

private def supportedCone0471 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 21, 20, 22⟩, ⟨1970044404, 29103683, 1444783328, 26634160, 242625893577, 107379951⟩⟩
    hull003_000 12 (by decide +kernel)

private def supportedCone0472 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 18, 17, 19⟩, ⟨1385503170, 16446452, 1199287158, 15058052, 238800712842, 54411883⟩⟩
    hull003_000 9 (by decide +kernel)

private def supportedCone0473 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 23, 22, 24⟩, ⟨929323095, 19209070, 1407888149, 33953019, 245000000000, 153223181⟩⟩
    hull003_034 6 (by decide +kernel)

private def supportedCone0474 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 22, 21, 23⟩, ⟨1444783328, 26634160, 929323095, 19209070, 244070676905, 134014111⟩⟩
    hull003_000 13 (by decide +kernel)

private def supportedCone0475 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 238, 234, 229, 237⟩, ⟨31323049203, 26575777936, 3676950797, 3126742212, 1006323049203, 523650383850⟩⟩
    hull003_014 1 (by decide +kernel)

private def supportedCone0476 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 233, 233, 229, 233⟩, ⟨30000000000, 25454225697, 0, 0, 1005000000000, 522528831611⟩⟩
    hull003_038 1 (by decide +kernel)

private def supportedCone0477 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨233, 238, 237, 234, 238⟩, ⟨3676950797, 3126742212, 1200961509, 1021540591, 1010000000000, 526777126062⟩⟩
    hull003_039 2 (by decide +kernel)

private def supportedCone0478 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨233, 235, 235, 234, 235⟩, ⟨1182693326, 1005773493, 0, 0, 1007505742529, 524656157343⟩⟩
    hull003_040 2 (by decide +kernel)

private def supportedCone0479 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨21, 23, 22, 21, 23⟩, ⟨1444783328, 26634160, 929323095, 19209070, 244070676905, 134014111⟩⟩
    hull003_041 1 (by decide +kernel)

def appendixHullConeBlock0014 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0448,
    supportedCone0449,
    supportedCone0450,
    supportedCone0451,
    supportedCone0452,
    supportedCone0453,
    supportedCone0454,
    supportedCone0455,
    supportedCone0456,
    supportedCone0457,
    supportedCone0458,
    supportedCone0459,
    supportedCone0460,
    supportedCone0461,
    supportedCone0462,
    supportedCone0463,
    supportedCone0464,
    supportedCone0465,
    supportedCone0466,
    supportedCone0467,
    supportedCone0468,
    supportedCone0469,
    supportedCone0470,
    supportedCone0471,
    supportedCone0472,
    supportedCone0473,
    supportedCone0474,
    supportedCone0475,
    supportedCone0476,
    supportedCone0477,
    supportedCone0478,
    supportedCone0479,
  ], rfl⟩

private def supportedCone0480 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨235, 238, 237, 235, 238⟩, ⟨2494257471, 2120968719, 1200961509, 1021540591, 1010000000000, 526777126062⟩⟩
    hull003_042 1 (by decide +kernel)

private def supportedCone0481 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨23, 26, 23, 23, 24⟩, ⟨0, 0, 1407888149, 33953019, 245000000000, 153223181⟩⟩
    hull003_043 0 (by decide +kernel)

private def supportedCone0482 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨233, 238, 233, 233, 234⟩, ⟨0, 0, 1323049203, 1121552239, 1005000000000, 522528831611⟩⟩
    hull003_039 0 (by decide +kernel)

private def supportedCone0483 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨235, 238, 235, 235, 237⟩, ⟨0, 0, 2494257471, 2120968719, 1007505742529, 524656157343⟩⟩
    hull003_042 0 (by decide +kernel)

private def supportedCone0484 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨235, 236, 235, 235, 236⟩, ⟨0, 0, 1156317306, 983400038, 1007505742529, 524656157343⟩⟩
    hull003_044 0 (by decide +kernel)

private def supportedCone0485 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨236, 238, 236, 236, 237⟩, ⟨0, 0, 1337940165, 1137568681, 1008662059835, 525639557381⟩⟩
    hull003_045 0 (by decide +kernel)

private def supportedCone0486 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨233, 235, 234, 233, 235⟩, ⟨1323049203, 1121552239, 1182693326, 1005773493, 1006323049203, 523650383850⟩⟩
    hull003_040 1 (by decide +kernel)

private def supportedCone0487 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 35, 22, 21, 23⟩, ⟨1444783328, 26634160, 929323095, 19209070, 244070676905, 134014111⟩⟩
    hull003_034 5 (by decide +kernel)

private def supportedCone0488 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 26, 22, 21, 23⟩, ⟨1444783328, 26634160, 929323095, 19209070, 244070676905, 134014111⟩⟩
    hull003_028 5 (by decide +kernel)

private def supportedCone0489 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 26, 17, 17, 18⟩, ⟨0, 0, 1385503170, 16446452, 237415209672, 37965431⟩⟩
    hull003_028 0 (by decide +kernel)

private def supportedCone0490 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨141, 283, 169, 168, 283⟩, ⟨5000000000, 4251799793, 470000000000, 399670430879, 605000000000, 182369607198⟩⟩
    hull003_046 23 (by decide +kernel)

private def supportedCone0491 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 22, 21, 23⟩, ⟨1444783328, 26634160, 929323095, 19209070, 244070676905, 134014111⟩⟩
    hull003_047 13 (by decide +kernel)

private def supportedCone0492 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 0, 0, 3⟩, ⟨0, 0, 200000000000, 0, 0, 0⟩⟩
    hull003_047 0 (by decide +kernel)

private def supportedCone0493 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 21, 20, 22⟩, ⟨1970044404, 29103683, 1444783328, 26634160, 242625893577, 107379951⟩⟩
    hull003_047 12 (by decide +kernel)

private def supportedCone0494 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 20, 19, 21⟩, ⟨655849173, 8806333, 1970044404, 29103683, 240655849173, 78276268⟩⟩
    hull003_000 11 (by decide +kernel)

private def supportedCone0495 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 19, 18, 20⟩, ⟨1199287158, 15058052, 655849173, 8806333, 240000000000, 69469935⟩⟩
    hull003_000 10 (by decide +kernel)

private def supportedCone0496 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 19, 18, 20⟩, ⟨1199287158, 15058052, 655849173, 8806333, 240000000000, 69469935⟩⟩
    hull003_047 10 (by decide +kernel)

private def supportedCone0497 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 18, 17, 19⟩, ⟨1385503170, 16446452, 1199287158, 15058052, 238800712842, 54411883⟩⟩
    hull003_047 9 (by decide +kernel)

private def supportedCone0498 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 17, 16, 18⟩, ⟨1516608462, 14915504, 1385503170, 16446452, 237415209672, 37965431⟩⟩
    hull003_000 8 (by decide +kernel)

private def supportedCone0499 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 231, 229, 229, 231⟩, ⟨0, 0, 26148712609, 22353128939, 975000000000, 497074605914⟩⟩
    hull003_048 0 (by decide +kernel)

private def supportedCone0500 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨231, 233, 233, 232, 233⟩, ⟨3077315270, 2477941685, 0, 0, 1005000000000, 522528831611⟩⟩
    hull003_049 2 (by decide +kernel)

private def supportedCone0501 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 16, 15, 17⟩, ⟨898601210, 7551393, 1516608462, 14915504, 235898601210, 23049927⟩⟩
    hull003_000 7 (by decide +kernel)

private def supportedCone0502 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 15, 14, 16⟩, ⟨830797927, 5172745, 898601210, 7551393, 235000000000, 15498534⟩⟩
    hull003_000 6 (by decide +kernel)

private def supportedCone0503 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 14, 13, 15⟩, ⟨1662166960, 7812264, 830797927, 5172745, 234169202073, 10325789⟩⟩
    hull003_000 5 (by decide +kernel)

private def supportedCone0504 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 16, 15, 17⟩, ⟨898601210, 7551393, 1516608462, 14915504, 235898601210, 23049927⟩⟩
    hull003_047 7 (by decide +kernel)

private def supportedCone0505 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 15, 14, 16⟩, ⟨830797927, 5172745, 898601210, 7551393, 235000000000, 15498534⟩⟩
    hull003_047 6 (by decide +kernel)

private def supportedCone0506 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 233, 229, 229, 233⟩, ⟨0, 0, 30000000000, 25454225697, 975000000000, 497074605914⟩⟩
    hull003_038 0 (by decide +kernel)

private def supportedCone0507 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨231, 233, 231, 231, 232⟩, ⟨0, 0, 773972121, 623155073, 1001148712609, 519427734853⟩⟩
    hull003_049 0 (by decide +kernel)

private def supportedCone0508 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 14, 13, 15⟩, ⟨1662166960, 7812264, 830797927, 5172745, 234169202073, 10325789⟩⟩
    hull003_047 5 (by decide +kernel)

private def supportedCone0509 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨231, 233, 232, 231, 233⟩, ⟨773972121, 623155073, 3077315270, 2477941685, 1001922684730, 520050889926⟩⟩
    hull003_049 1 (by decide +kernel)

private def supportedCone0510 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 227, 226, 228⟩, ⟨5000000000, 4266024948, 5000000000, 4266665735, 965000000000, 488523144835⟩⟩
    hull003_012 9 (by decide +kernel)

private def supportedCone0511 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 228, 227, 229⟩, ⟨5000000000, 4266665735, 5000000000, 4284795344, 970000000000, 492789810570⟩⟩
    hull003_012 10 (by decide +kernel)

def appendixHullConeBlock0015 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0480,
    supportedCone0481,
    supportedCone0482,
    supportedCone0483,
    supportedCone0484,
    supportedCone0485,
    supportedCone0486,
    supportedCone0487,
    supportedCone0488,
    supportedCone0489,
    supportedCone0490,
    supportedCone0491,
    supportedCone0492,
    supportedCone0493,
    supportedCone0494,
    supportedCone0495,
    supportedCone0496,
    supportedCone0497,
    supportedCone0498,
    supportedCone0499,
    supportedCone0500,
    supportedCone0501,
    supportedCone0502,
    supportedCone0503,
    supportedCone0504,
    supportedCone0505,
    supportedCone0506,
    supportedCone0507,
    supportedCone0508,
    supportedCone0509,
    supportedCone0510,
    supportedCone0511,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
