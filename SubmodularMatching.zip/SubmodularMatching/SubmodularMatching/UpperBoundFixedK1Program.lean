import SubmodularMatching.UpperBoundFixedK1Parameters
import SubmodularMatching.UpperBoundK1FactorSpecialization
import SubmodularMatching.UpperBoundFixedK1Family
import SubmodularMatching.ReplayUncoveredMiddle.Result

/-! # Theorem 1.1 on the finite, sparse program for real oracle replies -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler NumericalCertificate SourceCertificate

noncomputable section

/-- The fixed Appendix L rates and accuracies, with the complete price proof. -/
def fixedArchiveParameters : K1Parameters :=
  fixedK1Parameters Replay.UncoveredMiddle.checked

/-- The comparison precision and trial schedule for the stated factor. -/
def fixedArchiveConfidence : K1Confidence fixedArchiveParameters :=
  fixedK1Confidence Replay.UncoveredMiddle.checked

namespace SimpleEdgeStream

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- The one-pass real value-oracle program attains the fixed expectation
factor and the same factor with any positive failure budget. -/
theorem theorem1_1_real_verified (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, f M ≤ f O)
    (δ : ℝ) (hδ : 0 < δ) :
    let p := S.k1ArchivedExpectedOutput fixedArchiveParameters f hf hm
    let q := S.k1ArchivedAmplifiedOutput fixedArchiveParameters f hf hm fixedArchiveConfidence δ
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / targetFactor ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤ δ := by
  have hle : fixedArchiveParameters.expectedFactor ≤ fixedArchiveConfidence.target := by
    change (fixedK1Parameters Replay.UncoveredMiddle.checked).expectedFactor ≤ targetFactor
    rw [fixedK1Parameters_expectedFactor]
    exact finite_factor_lt_target.le
  exact S.k1Archived_guarantees_of_expectedFactor_le
    fixedArchiveParameters fixedArchiveConfidence hle f hf hm h0 O hO hopt δ hδ

/-- The finite real value-oracle program has the manuscript's confidence
guarantee for every fixed positive exponent. -/
theorem theorem1_1_real_confidence_verified (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : 0 ≤ f ∅)
    (O : Finset E) (hO : O ∈ S.matchings) (hopt : ∀ M ∈ S.matchings, f M ≤ f O)
    (hn : 1 ≤ Fintype.card V) (c : ℝ) (hc : 0 < c) :
    let n := Fintype.card V
    let δ := ((((max 2 n : ℕ) : ℝ) ^ ⌈c⌉₊)⁻¹)
    let q := S.k1ArchivedAmplifiedOutput fixedArchiveParameters f hf hm fixedArchiveConfidence δ
    q.outcomes ⊆ S.matchings ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤
        (n : ℝ) ^ (-c) := by
  have h := S.theoremK1_archived_confidence
    fixedArchiveParameters f hf hm h0 O hO hopt fixedArchiveConfidence c
  have hn' : (0 : ℝ) < Fintype.card V := by
    exact_mod_cast Nat.zero_lt_one.trans_le hn
  have hmax : (Fintype.card V : ℝ) ≤ (max 2 (Fintype.card V) : ℕ) := by
    exact_mod_cast le_max_right 2 (Fintype.card V)
  exact ⟨h.1, h.2.trans (Real.rpow_le_rpow_of_nonpos hn' hmax (neg_nonpos.mpr hc.le))⟩

end SimpleEdgeStream

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- The same real value-oracle program attains every fixed factor strictly
above the limit in Corollary L.1. -/
theorem approximationFamily_real_corollary_verified (ratio : ℝ)
    (hr : (45246551 : ℝ) / 10000000 < ratio) :
    ∃ b : K1Parameters, ∃ C : K1Confidence b, C.target = ratio ∧ b.expectedFactor < ratio ∧
      ∀ (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
        (hf : IsSubmodular f) (hm : IsMonotone f) (_h0 : 0 ≤ f ∅)
        (O : Finset E) (_hO : O ∈ S.matchings) (_hopt : ∀ M ∈ S.matchings, f M ≤ f O)
        (δ : ℝ) (_hδ : 0 < δ),
        let p := S.k1ArchivedExpectedOutput b f hf hm
        let q := S.k1ArchivedAmplifiedOutput b f hf hm C δ
        p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
          f O / ratio ≤ expected p.outcomes p.mass f ∧
          expected q.outcomes q.mass (fun M => if f O / ratio ≤ f M then 0 else 1) ≤ δ :=
  approximationFamily_archived_corollary_of_next_band ratio hr Replay.UncoveredMiddle.checked

end

end SubmodularMatching.UpperBoundAssembly
