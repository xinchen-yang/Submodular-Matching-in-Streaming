import SubmodularMatching.NonmonotoneFiniteGibbs
import SubmodularMatching.GibbsSpectralGridWalk

namespace SubmodularMatching.GibbsSampler
open GibbsMatching
noncomputable section
variable {C : Type*} [LinearOrder C]

/-- A common grid of nonnegative altered coordinates gives a physical
word-level sampler with reciprocal-integer variation error. -/
theorem signed_grid_variation {n : ℕ} (ep : C → Fin n × Fin n) (S : Finset C)
    (k Q D : ℕ) (hk : 0 < k) (hQ : 0 < Q) (hD : 0 < D)
    (num : C → ℕ) (stored : List C) (hs : stored.toFinset = S) (hd : stored.Nodup)
    (hDistinct : ∀ e ∈ S, (ep e).1 ≠ (ep e).2)
    (hLoad : ∀ v, gridLoadNumerator (TwoStage.pairEnds ep) S num v ≤ Q)
    (hCoord : ∀ e ∈ S, (num e:ℝ)/Q ≤ signedRoundingCap (1/k)) :
    variation (matchings (TwoStage.pairEnds ep) S)
      (gridGibbsWalkLaw ep (8*k-1) (8*k) Q num stored D)
      (probability (TwoStage.pairEnds ep) S (calibratedActivity (TwoStage.pairEnds ep) S
        (fun e => (num e:ℝ)/Q) (signedRoundingGamma (1/k)))) ≤ 1/(D:ℝ) := by
  let ends := TwoStage.pairEnds ep
  let x := fun e => (num e:ℝ)/Q
  have hends : ∀ e ∈ S, (ends e).card = 2 := fun e he => Finset.card_pair (hDistinct e he)
  have hdeg (v) : vertexLoad ends S x v ≤ 1 := by
    have hEq : vertexLoad ends S x v = (gridLoadNumerator ends S num v : ℝ)/Q := by
      unfold vertexLoad gridLoadNumerator
      simp [x, Finset.sum_div]
    rw [hEq]
    exact (div_le_one (by exact_mod_cast hQ)).2 (by exact_mod_cast hLoad v)
  have hr := reciprocal_gamma k hk
  rw [hr]
  convert gridGibbsWalkLaw_variation ends ep (fun _ => rfl) S (8*k-1) (8*k) Q (by omega)
    hQ num stored hs hd hDistinct hLoad (fun e he => ?_) D hD using 1
  · push_cast
    rfl
  · have hb := signed_calibratedActivity_bounds (1/k) (by positivity) ends S x
      (fun e _ => by dsimp [x]; positivity) hdeg hends hCoord e he
    rw [hr] at hb
    simpa only [Nat.cast_mul,Nat.cast_ofNat] using hb

end
end SubmodularMatching.GibbsSampler
