import SubmodularMatching.NonmonotoneOptimizerGradientWords
import SubmodularMatching.NonmonotoneActionRound

/-! The product subsets for all three actual optimizer query families can be
read with integer comparisons against rationally computed thresholds. -/
namespace SubmodularMatching.NonmonotoneOptimizer.BlockData
open Streaming
variable {E : Type*} [DecidableEq E] {n N : ℕ} [NeZero n] (B : BlockData E n N)

def nonlinearProbQ (r : Vec N) (i : ℕ) : ℚ := max 0 (min 1 (B.actRat r (Fin.ofNat n i)))

def chainProbQ (r : Vec N) (flag : Bool) (v : Fin n) (i : ℕ) : ℚ :=
  if i=v.val then 0 else if i<v.val then B.nonlinearProbQ r i else if flag then 1 else 0

def queryProbQ (r : Vec N) (m : ℕ) (hist : ℕ→ℚ) (key : ActionKey n) (i : ℕ) : ℚ :=
  if i<keySize m n key then
    if i<m then hist i else
      match key with
      | .inl (flag,v) => B.chainProbQ r flag v (i-m)
      | .inr true => B.nonlinearProbQ r (i-m)
      | .inr false => 0
  else 0

theorem nonlinearProbQ_cast (r : Vec N) (i : ℕ) : (B.nonlinearProbQ r i:ℝ)=B.clippedAction r i := by
  simp [nonlinearProbQ,clippedAction,actRat,orderedU,action]
theorem chainProbQ_cast (r : Vec N) (flag : Bool) (v : Fin n) (i : ℕ) :
    (B.chainProbQ r flag v i:ℝ)=B.chainProb r flag v i := by
  by_cases eq : i=v.val
  · subst i; simp [chainProbQ,chainProb,omitProb]
  · simp only [chainProbQ,if_neg eq,chainProb,omitProb,Function.update_of_ne eq,chain]
    split_ifs <;> simp [nonlinearProbQ_cast]

theorem query_thresholds (r : Vec N) (m : ℕ) (hist : ℕ→ℚ) (h : ℕ→E) (F : Finset E→ℝ)
    (hp : ∀ i<m,0≤(hist i:ℝ) ∧ (hist i:ℝ)≤1) (key : ActionKey n) (i bits : ℕ) :
    let Q := B.keyQuery r h (fun j => (hist j:ℝ)) F hp key
    realWordThreshold (Q.extendedProb i) bits = dyadicThreshold (B.queryProbQ r m hist key i) bits ∧
      dyadicThreshold (B.queryProbQ r m hist key i) bits ≤ 2^bits := by
  intro Q
  have eq : Q.extendedProb i = (B.queryProbQ r m hist key i:ℝ) := by
    unfold OracleQuery.extendedProb queryProbQ
    rw [show Q.size = _ from B.keyQuery_size r h (fun j => (hist j:ℝ)) F hp key]
    split_ifs with hi hj
    · rcases key with ⟨flag,v⟩|s
      · simp [Q,keyQuery,chainQuery,concatQuery,concatCoordinates,hj]
      · cases s <;> simp [Q,keyQuery,baseQuery,actionQuery,concatQuery,concatCoordinates,hj]
    · rcases key with ⟨flag,v⟩|s
      · simp [Q,keyQuery,chainQuery,concatQuery,concatCoordinates,hj,chainProbQ_cast]
      · cases s
        · exact False.elim (hj hi)
        · simp [Q,keyQuery,actionQuery,concatQuery,concatCoordinates,hj,nonlinearProbQ_cast]
    · simp
  have rep : realWordThreshold (Q.extendedProb i) bits=dyadicThreshold (B.queryProbQ r m hist key i) bits := by
    rw [eq,rational_threshold_exact]
  exact ⟨rep,rep ▸ realWordThreshold_le _ (Q.extendedProb_bounds i).2 bits⟩

theorem actual_word_query (r : Vec N) (m : ℕ) (hist : ℕ→ℚ) (h : ℕ→E) (F : Finset E→ℝ)
    (hp : ∀ i<m,0≤(hist i:ℝ) ∧ (hist i:ℝ)≤1) (key : ActionKey n) (bits : ℕ) :
    let Q := B.keyQuery r h (fun j => (hist j:ℝ)) F hp key
    ∀ w : Fin Q.size→Fin (2^bits), Q.wordValue bits w =
      Q.evaluate (selectThresholdWords Q.edges (finiteWord (2^bits) Q.size w)
        (fun i => dyadicThreshold (B.queryProbQ r m hist key i) bits) Q.size) := by
  intro Q w
  unfold OracleQuery.wordValue selectWordVector
  apply congrArg Q.evaluate
  apply congrArg (fun threshold => selectThresholdWords Q.edges (finiteWord (2^bits) Q.size w) threshold Q.size)
  funext i
  exact (B.query_thresholds r m hist h F hp key i bits).1

end SubmodularMatching.NonmonotoneOptimizer.BlockData
