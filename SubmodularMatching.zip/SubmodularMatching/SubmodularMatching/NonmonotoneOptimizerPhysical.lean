import SubmodularMatching.NonmonotoneOptimizerOrder

/-! Permanent packing columns, the time-dependent sorted query order and the
rational gradient supplied to the finite optimizer. -/

namespace SubmodularMatching.NonmonotoneOptimizer

open GibbsMatching

variable {E : Type*} [DecidableEq E] {n N : ℕ}

structure BlockData (E : Type*) (n N : ℕ) where
  columns : (Fin n ⊕ Fin n) ≃ Fin N
  label : Fin n ↪ E
  frozen : Fin n → ℚ
  c : ℚ
  β : ℚ

structure ChainEstimates (n N : ℕ) where
  lower : ℕ → Vec N → Fin n → ℚ
  upper : ℕ → Vec N → Fin n → ℚ
  score : ℕ → Vec N → ℚ

namespace BlockData

variable (B : BlockData E n N)

def nonlinear (r : Vec N) (i : Fin n) : ℚ := atRat r (B.columns (.inr i))

def order (r : Vec N) : Equiv.Perm (Fin n) :=
  chainOrder (fun i => B.nonlinear r i * (1-B.nonlinear r i))

def layout (r : Vec N) : (Fin n ⊕ Fin n) ≃ Fin N :=
  (Equiv.sumCongr (Equiv.refl _) (B.order r)).trans B.columns

def orderedCoord (r : Vec N) (j : Fin n) : ℚ := B.nonlinear r ((B.order r) j)

def orderedEdge [NeZero n] (r : Vec N) (j : ℕ) : E := B.label (B.order r (Fin.ofNat n j))

def orderedU [NeZero n] (r : Vec N) (j : ℕ) : ℝ := B.orderedCoord r (Fin.ofNat n j)

def linearValue (z : Fin N → ℝ) : ℝ := ∑ i, (B.frozen i:ℝ) * z (B.columns (.inl i))

def actRat (r : Vec N) (i : Fin n) : ℚ := B.orderedCoord r i/(B.c+B.orderedCoord r i)

def observed (A : ChainEstimates n N) (t : ℕ) (r : Vec N) (i : Fin n) : ℚ :=
  (1-B.actRat r i)*A.lower t r i + B.actRat r i*A.upper t r i

def gradient (A : ChainEstimates n N) (t : ℕ) (r : Vec N) : Vec N :=
  Vector.ofFn fun j => Sum.elim B.frozen (fun i => B.β*B.observed A t r i) ((B.layout r).symm j)

@[simp] theorem fin_ofNat_coe [NeZero n] (i : Fin n) : Fin.ofNat n i.val = i := by
  apply Fin.ext
  exact Nat.mod_eq_of_lt i.isLt

theorem ordered_cover [NeZero n] (r : Vec N) (O : Finset E) (hO : ∀ e ∈ O, ∃ i, B.label i = e) :
    O ⊆ replacementPrefix (B.orderedEdge r) n := by
  intro e he
  obtain ⟨i,rfl⟩ := hO e he
  let j := (B.order r).symm i
  apply Finset.mem_image.mpr
  exact ⟨j.val,Finset.mem_range.mpr j.isLt,by simp [orderedEdge,j]⟩

theorem ordered_inj [NeZero n] (r : Vec N) :
    ∀ i < n, ∀ j < n, B.orderedEdge r i = B.orderedEdge r j → i = j := by
  intro i hi j hj h
  have hh := congrArg Fin.val ((B.order r).injective (B.label.injective h))
  simpa only [Fin.val_ofNat,Nat.mod_eq_of_lt hi,Nat.mod_eq_of_lt hj] using hh

theorem ordered_weights [NeZero n] (r : Vec N) (hc : 0 < B.c) :
    ∀ i < n, ∀ j < n, i ≤ j → weight B.c (B.orderedU r i) ≤ weight B.c (B.orderedU r j) := by
  intro i hi j hj hij
  have h : Fin.ofNat n i ≤ Fin.ofNat n j := by
    change i%n ≤ j%n; simpa only [Nat.mod_eq_of_lt hi,Nat.mod_eq_of_lt hj] using hij
  exact chainOrder_weight (B.nonlinear r) B.c (by exact_mod_cast hc) h

theorem gradient_eq (A : ChainEstimates n N) (t : ℕ) (r : Vec N) :
    coordinates (B.gradient A t r) = jointGradient (B.layout r) (fun i => (B.frozen i:ℝ))
      (fun i => (B.observed A t r i:ℝ)) B.β := by
  funext j
  simp only [coordinates,atRat,gradient,Vector.getElem_ofFn,jointGradient]
  cases h : (B.layout r).symm j <;> simp [h]

theorem action_cast [NeZero n] (r : Vec N) (i : Fin n) :
    (B.actRat r i:ℝ) = action B.c (B.orderedU r i.val) := by simp [actRat,action,orderedU]

theorem observed_error [NeZero n] (A : ChainEstimates n N) (t : ℕ) (r : Vec N)
    (f : Finset E → ℝ) (δ : ℝ) (hc : 0 < B.c) (hu : ∀ i, 0 ≤ B.orderedCoord r i)
    (hA : ∀ i : Fin n, |(A.lower t r i:ℝ)-slope (B.orderedEdge r)
      (chain (fun j => action B.c (B.orderedU r j)) (fun _ => 0) i) f n i| ≤ δ)
    (hC : ∀ i : Fin n, |(A.upper t r i:ℝ)-slope (B.orderedEdge r)
      (chain (fun j => action B.c (B.orderedU r j)) (fun _ => 1) i) f n i| ≤ δ) (i : Fin n) :
    |(B.observed A t r i:ℝ)-queriedPayoff (B.orderedEdge r) n f B.c (B.orderedU r) i| ≤ δ := by
  have h : 0 ≤ B.orderedU r i.val := by simp only [orderedU,fin_ofNat_coe]; exact_mod_cast hu i
  have ha := action_bounds (by exact_mod_cast hc : 0 < (B.c:ℝ)) h
  have hh := payoff_error _ _ _ _ _ _ ha.1 ha.2 (hA i) (hC i)
  simpa only [observed,Rat.cast_add,Rat.cast_mul,Rat.cast_sub,Rat.cast_one,action_cast,queriedPayoff,payoff] using hh

theorem observed_bound (A : ChainEstimates n N) (t : ℕ) (r : Vec N) (P : ℝ)
    (hc : 0 < B.c) (hu : ∀ i, 0 ≤ B.orderedCoord r i)
    (hA : ∀ i, |(A.lower t r i:ℝ)| ≤ P) (hC : ∀ i, |(A.upper t r i:ℝ)| ≤ P) (i : Fin n) :
    |(B.observed A t r i:ℝ)| ≤ P := by
  have ha : 0 ≤ B.actRat r i ∧ B.actRat r i ≤ 1 :=
    ⟨div_nonneg (hu i) (add_pos_of_pos_of_nonneg hc (hu i)).le,
      (div_le_one (add_pos_of_pos_of_nonneg hc (hu i))).mpr (by linarith)⟩
  have ha0 : 0 ≤ (B.actRat r i:ℝ) := by exact_mod_cast ha.1
  have ha1 : (B.actRat r i:ℝ) ≤ 1 := by exact_mod_cast ha.2
  have hh := payoff_error (B.actRat r i) 0 0 (A.lower t r i) (A.upper t r i) P ha0 ha1
    (by simpa using hA i) (by simpa using hC i)
  simpa [observed, payoff] using hh

end BlockData

end SubmodularMatching.NonmonotoneOptimizer
