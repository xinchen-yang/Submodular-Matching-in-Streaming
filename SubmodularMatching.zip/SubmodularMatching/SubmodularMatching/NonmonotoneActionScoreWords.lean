import SubmodularMatching.NonmonotoneActionScoreQueries

/-! # Physical word answers to chain-gradient and value requests -/

namespace SubmodularMatching.NonmonotoneOptimizer
open Streaming
open scoped BigOperators
noncomputable section

variable {E : Type*} [DecidableEq E]
variable {m n N s bits : ℕ} [NeZero n]

/-- Addresses in the random transcript. Each query reads its own word batch;
state arguments select the history-dependent query. -/
structure OptimizerWords (m n N s bits : ℕ) where
  chain : ℕ → Vec N → Bool → Fin n → WordBatch s (m+n) bits
  active : ℕ → Vec N → WordBatch s (m+n) bits
  base : ℕ → Vec N → WordBatch s m bits

def wordMean (Q : OracleQuery E) (d : ℚ) (w : WordBatch s Q.size bits) : ℚ :=
  snappedRat d (fun k => Q.wordValue bits (w k))

def wordGood (Q : OracleQuery E) (d : ℚ) (w : WordBatch s Q.size bits) : Prop :=
  Q.target-d ≤ sourceAverage d (fun k => Q.wordValue bits (w k)) ∧
    sourceAverage d (fun k => Q.wordValue bits (w k)) ≤ Q.target+d

theorem wordGood_error (Q : OracleQuery E) (d : ℚ) (w : WordBatch s Q.size bits)
    (good : wordGood Q d w) : |(wordMean Q d w : ℝ)-Q.target| ≤ d := by
  rw [wordMean,snappedRat_cast,abs_le]
  obtain ⟨lo,hi⟩ := good
  constructor <;> linarith

def clipAnswer (P : ℕ) (v : ℚ) : ℚ := max (-(P:ℚ)) (min P v)

theorem clipAnswer_bound (P : ℕ) (v : ℚ) : |(clipAnswer P v : ℝ)| ≤ P := by
  unfold clipAnswer
  push_cast
  exact abs_le.mpr ⟨le_max_left _ _,max_le (by linarith only [Nat.cast_nonneg (α := ℝ) P]) (min_le_left _ _)⟩

theorem clipAnswer_error (P : ℕ) (v : ℚ) (x δ : ℝ) (hx : |x| ≤ P)
    (he : |(v:ℝ)-x| ≤ δ) : |(clipAnswer P v : ℝ)-x| ≤ δ := by
  rw [abs_le] at hx he ⊢
  unfold clipAnswer
  push_cast
  have hd : 0 ≤ δ := by linarith
  constructor
  · have l : x-δ ≤ min (P:ℝ) (v:ℝ) := le_min (by linarith only [hx.2,hd]) (by linarith only [he.1])
    linarith only [l.trans (le_max_right (-(P:ℝ)) _)]
  · exact sub_le_iff_le_add.mpr (max_le (by linarith only [hx.1,hd]) (min_le_of_right_le (by linarith only [he.2])))

theorem target_range (Q : OracleQuery E) (lo hi : ℝ)
    (hb : ∀ A ⊆ (Finset.range Q.size).image Q.edges, lo ≤ Q.evaluate A ∧ Q.evaluate A ≤ hi) :
    lo ≤ Q.target ∧ Q.target ≤ hi := by
  let G := (Finset.range Q.size).image Q.edges
  let C := fun A => Q.evaluate (A∩G)
  have ht : bernoulliExpectation Q.edges Q.prob C Q.size = Q.target :=
    product_restrict_support _ _ _ _ (fun j hj => Finset.mem_image_of_mem _ (Finset.mem_range.mpr hj)) Q.evaluate
  rw [← ht]
  constructor
  · simpa using bernoulliExpectation_mono Q.edges Q.prob (fun _ => lo) C Q.size Q.unitProb
      (fun A => (hb (A∩G) Finset.inter_subset_right).1)
  · simpa using bernoulliExpectation_mono Q.edges Q.prob C (fun _ => hi) Q.size Q.unitProb
      (fun A => (hb (A∩G) Finset.inter_subset_right).2)

namespace BlockData
variable (B : BlockData E n N)

def readEstimates (h : ℕ → E) (p : ℕ → ℝ) (F : Finset E → ℝ)
    (hp : ∀ j < m, 0 ≤ p j ∧ p j ≤ 1) (γ d : ℚ) (P : ℕ)
    (W : OptimizerWords m n N s bits) : ChainEstimates n N where
  lower t r k := clipAnswer P (wordMean (B.chainQuery r h p m F hp false k) d (W.chain t r false k))
  upper t r k := clipAnswer P (wordMean (B.chainQuery r h p m F hp true k) d (W.chain t r true k))
  score t r := B.estimateScore r γ d (fun a => (B.actionQuery r h p m F hp).wordValue bits (W.active t r a))
    (fun a => (baseQuery h p m F hp).wordValue bits (W.base t r a))

theorem observedBounds (h : ℕ → E) (p : ℕ → ℝ) (F : Finset E → ℝ)
    (hp : ∀ j < m, 0 ≤ p j ∧ p j ≤ 1) (γ d : ℚ) (P : ℕ) (W : OptimizerWords m n N s bits)
    (t : ℕ) (r : Vec N) (k : Fin n) :
    let A := B.readEstimates h p F hp γ d P W
    |(A.lower t r k:ℝ)| ≤ P ∧ |(A.upper t r k:ℝ)| ≤ P :=
  ⟨clipAnswer_bound _ _,clipAnswer_bound _ _⟩

theorem readScoreAccurate (h : ℕ → E) (p : ℕ → ℝ) (F : Finset E → ℝ)
    (hp : ∀ j < m, 0 ≤ p j ∧ p j ≤ 1) (γ d : ℚ) (P : ℕ) (W : OptimizerWords m n N s bits)
    (t : ℕ) (r : Vec N) (hc : 0 < B.c) (hu : ∀ j < n, 0 ≤ B.orderedU r j)
    (hγ : 0 ≤ γ) (good : wordGood (B.actionQuery r h p m F hp) d (W.active t r) ∧
      wordGood (baseQuery h p m F hp) d (W.base t r)) :
    |((B.readEstimates h p F hp γ d P W).score t r:ℝ)-B.candidateScore (historyMean h p m F) γ r|
      ≤ 2*(γ:ℝ)*d := by
  apply B.estimateScore_accuracy r h p m F hp hc hu γ d hγ
  · simpa only [wordMean,snappedRat_cast] using wordGood_error _ _ _ good.1
  · simpa only [wordMean,snappedRat_cast] using wordGood_error _ _ _ good.2

theorem readChainAccurate (h : ℕ → E) (p : ℕ → ℝ) (F : Finset E → ℝ)
    (hp : ∀ j < m, 0 ≤ p j ∧ p j ≤ 1) (γ d : ℚ) (P : ℕ) (W : OptimizerWords m n N s bits)
    (t : ℕ) (r : Vec N) (hc : 0 < B.c) (hu : ∀ j < n, 0 ≤ B.orderedU r j)
    (bound : ∀ flag k, |(B.chainQuery r h p m F hp flag k).target| ≤ P)
    (good : ∀ flag k, wordGood (B.chainQuery r h p m F hp flag k) d (W.chain t r flag k)) :
    B.queryAccurate (B.readEstimates h p F hp γ d P W) (historyMean h p m F) d t r := by
  have each (flag : Bool) (k : Fin n) :=
    clipAnswer_error P _ _ _ (bound flag k) (wordGood_error _ _ _ (good flag k))
  constructor
  · intro k
    simpa only [B.chainQuery_exact _ _ _ _ _ _ hc hu, Bool.false_eq_true, ↓reduceIte] using each false k
  · intro k
    simpa only [B.chainQuery_exact _ _ _ _ _ _ hc hu, ↓reduceIte] using each true k

end BlockData
end
end SubmodularMatching.NonmonotoneOptimizer
