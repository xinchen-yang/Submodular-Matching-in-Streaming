import SubmodularMatching.NonmonotoneAugmentation
import SubmodularMatching.MarginalComparison

/-! Recovery of the recorded value for a nonnegative submodular objective,
Appendix M.2. Stored edges are distinct and have nonnegative true arrival weights. -/

namespace SubmodularMatching

open scoped BigOperators

variable {E : Type*} [DecidableEq E]

private theorem absent_prefix_erase (edges : ℕ → E) (q : ℕ → ℝ) (f : Finset E → ℝ)
    (i : ℕ) (hnew : ∀ j < i, edges j ≠ edges i) :
    bernoulliExpectation edges q (fun A => f (A.erase (edges i))) i =
      bernoulliExpectation edges q f i :=
  NonmonotoneOptimizer.expectation_erase _ _ _ _ _ (fun j hj he => (hnew j hj he).elim)

private theorem signed_conditional_le (edges : ℕ → E) (p : ℝ) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hp : 0 ≤ p) (hp1 : p ≤ 1) (T : Finset E) (i : ℕ)
    (hnew : ∀ j < i, edges j ≠ edges i) (hw : 0 ≤ arrivalWeight edges p f i) :
    conditionalArrivalWeight edges p f T i ≤ arrivalWeight edges p f i := by
  by_cases he : edges i ∈ T
  · have hz (A : Finset E) : marginal f (edges i) (T ∪ A) = 0 := by
      have hmem : edges i ∈ T ∪ A := Finset.mem_union_left _ he
      simp [marginal, Finset.union_eq_left.mpr (Finset.singleton_subset_iff.mpr hmem)]
    simpa only [conditionalArrivalWeight, hz, bernoulliExpectation_const] using hw
  · unfold conditionalArrivalWeight arrivalWeight
    rw [← absent_prefix_erase edges (fun _ => p) (fun A => marginal f (edges i) (T ∪ A)) i hnew,
      ← absent_prefix_erase edges (fun _ => p) (marginal f (edges i)) i hnew]
    apply bernoulliExpectation_mono _ _ _ _ _ (fun _ _ => ⟨hp, hp1⟩)
    intro A
    exact diminishing_returns _ hf _ _ _ Finset.subset_union_right (by simp [he])

/-- The signed history bound includes the empty-set value. The weight bound is
only required on the stored list on which the diffuse vector is defined. -/
theorem signed_history_recovery (edges : ℕ → E) (p : ℝ) (z wh : ℕ → ℝ)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hp : 0 ≤ p) (hp1 : p ≤ 1)
    (n : ℕ) (T : Finset E) (hinj : ∀ i < n, ∀ j < n, edges i = edges j → i = j)
    (hz : ∀ i < n, 0 ≤ z i ∧ z i ≤ p)
    (hw : ∀ i < n, 0 ≤ wh i ∧ wh i ≤ arrivalWeight edges p f i) :
    f ∅ + residualValue edges p f n T + (∑ i ∈ Finset.range n, wh i * z i) ≤
      bernoulliExpectation edges z (fun A => f (T ∪ A)) n := by
  let g := fun A : Finset E => f (T ∪ A)
  have hg : IsSubmodular g := by
    simpa only [g, Finset.union_comm T] using submodular_union_fixed f hf T
  have hnew (i : ℕ) (hi : i < n) (j : ℕ) (hj : j < i) : edges j ≠ edges i :=
    fun he => (ne_of_lt hj) (hinj j (hj.trans hi) i hi he)
  have harg (e : E) : marginal g e = fun A => marginal f e (T ∪ A) := by
    funext A
    exact marginal_union_conditioning f T A e
  have hterm (i : ℕ) (hi : i < n) :
      conditionalArrivalWeight edges p f T i ≤
        bernoulliExpectation edges z (marginal g (edges i)) i := by
    have h := bernoulliExpectation_antitone_probabilities edges z (fun _ => p)
      (fun A => marginal g (edges i) (A.erase (edges i))) i
      (fun j hj => ⟨(hz j (hj.trans hi)).1, (hz j (hj.trans hi)).2, hp1⟩)
      (fun A B hab => diminishing_returns g hg _ _ _ (Finset.erase_subset_erase _ hab)
        (Finset.notMem_erase _ _))
    rw [absent_prefix_erase _ _ _ _ (hnew i hi), absent_prefix_erase _ _ _ _ (hnew i hi)] at h
    simpa only [conditionalArrivalWeight, harg] using h
  have hsum : (∑ i ∈ Finset.range n, wh i * z i) +
      (∑ i ∈ Finset.range n, p * conditionalArrivalWeight edges p f T i) ≤
      (∑ i ∈ Finset.range n, p * arrivalWeight edges p f i) +
      ∑ i ∈ Finset.range n, z i * bernoulliExpectation edges z (marginal g (edges i)) i := by
    rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro i hi
    have h := Finset.mem_range.mp hi
    have hcond := signed_conditional_le edges p f hf hp hp1 T i (hnew i h)
      ((hw i h).1.trans (hw i h).2)
    have hdiff := mul_nonneg (sub_nonneg.mpr (hz i h).2) (sub_nonneg.mpr hcond)
    nlinarith only [hdiff, mul_le_mul_of_nonneg_left (hterm i h) (hz i h).1,
      mul_le_mul_of_nonneg_right (hw i h).2 (hz i h).1]
  have hbase := expected_arrival_value edges p f n
  rw [Finset.mul_sum] at hbase
  have heval (q : ℕ → ℝ) := bernoulliExpectation_telescoping edges q g n
  have hshift := heval (fun _ => p)
  change bernoulliExpectation edges (fun _ => p) g n = g ∅ +
    ∑ i ∈ Finset.range n, p * bernoulliExpectation edges (fun _ => p) (marginal g (edges i)) i at hshift
  simp only [harg] at hshift
  unfold residualValue
  rw [bernoulliExpectation_sub]
  change f ∅ + (bernoulliExpectation edges (fun _ => p) g n -
    bernoulliExpectation edges (fun _ => p) f n) + _ ≤ bernoulliExpectation edges z g n
  change bernoulliExpectation edges (fun _ => p) g n = g ∅ +
    ∑ i ∈ Finset.range n, p * conditionalArrivalWeight edges p f T i at hshift
  linarith only [hbase, hsum, hshift, heval z]

end SubmodularMatching
