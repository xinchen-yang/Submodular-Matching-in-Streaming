import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step128 : ProjectedGoal ⟨54972, 55079, 0, 70, 1064, 1068⟩ :=
  projectedGoal_chunk _ (.y (.leaf 0xd727d6bc3a35294400cab049) (.m (.y (.m (.leaf 0xd6d6d6bc0746a52880cae836) (.leaf 0xd6f1d6d7e8d4a51000cae049)) (.m (.m (.m (.m (.leaf 0xd6bfd6bc0000000000cad191) (.m (.leaf 0xd6c1d6c00000000000cad191) (.leaf 0xd6c2d6c20000000000cad191))) (.m (.m (.m (.leaf 0xd6c3d6c30000000000cad191) (.leaf 0xd6c4d6c40000000000cad191)) (.m (.leaf 0xd6c5d6c50000000000cad191) (.leaf 0xd6c6d6c60000000000cad191))) (.x (.x (.x (.leaf 0xd6c9d6c7e8d4a51000caf3b8) (.m (.m (.leaf 0xd6c7d6c70000000000cad4f7) (.leaf 0xd6c8d6c80000000000cad4f7)) (.leaf 0xd6c9d6c90000000000cad4f7))) (.leaf 0xd6c9d6c70000000000cad1c9)) (.leaf 0xd6c9d6c70000000000cad17f)))) (.m (.m (.m (.leaf 0xd6cbd6ca0000000000cad191) (.leaf 0xd6cdd6cc03a3529440cafca0)) (.leaf 0xd6d0d6ce0746a52880caf836)) (.leaf 0xd6d6d6d10e8d4a5100caf192))) (.leaf 0xd6f1d6d71d1a94a200cafcaa))) (.leaf 0xd727d6f2e8d4a51000cb0049))) (by decide +kernel)

private theorem step129 : ProjectedGoal ⟨54972, 54985, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.m (.m (.leaf 0xd6bfd6bc0000000000ca5191) (.m (.leaf 0xd6c1d6c00000000000ca5191) (.leaf 0xd6c2d6c20000000000ca5191))) (.m (.m (.m (.leaf 0xd6c3d6c30000000000ca5191) (.leaf 0xd6c4d6c40000000000ca5191)) (.m (.leaf 0xd6c5d6c50000000000ca5191) (.leaf 0xd6c6d6c60000000000ca5191))) (.x (.x (.m (.m (.leaf 0xd6c7d6c70000000000ca5500) (.leaf 0xd6c8d6c80000000000ca5500)) (.leaf 0xd6c9d6c90000000000ca5500)) (.leaf 0xd6c9d6c70000000000ca51c9)) (.leaf 0xd6c9d6c70000000000ca517f)))) (by decide +kernel)

private theorem step130 : ProjectedGoal ⟨54986, 54998, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0xd6cbd6ca0000000000ca5191) (.leaf 0xd6cdd6cc00001d1a94ca5207)) (.m (.leaf 0xd6cfd6ce00001d1a94ca5207) (.leaf 0xd6d0d6d00000246139ca5207))) (.m (.x (.x (.m (.m (.leaf 0xd6d1d6d100001d1a94ca5503) (.y (.leaf 0xd6d2d6d200002ba7decb1503) (.leaf 0xd6d2d6d20000000000cb2500))) (.leaf 0xd6d3d6d30000246139ca5503)) (.leaf 0xd6d3d6d10000000000ca51c9)) (.leaf 0xd6d3d6d10000000000ca517f)) (.m (.x (.x (.y (.leaf 0xd6d5d6d400002ba7decb1503) (.leaf 0xd6d5d6d40000000000cb2500)) (.leaf 0xd6d5d6d40000000000ca51c9)) (.leaf 0xd6d5d6d40000000000ca517f)) (.x (.x (.y (.leaf 0xd6d6d6d600002ba7decb1503) (.leaf 0xd6d6d6d60000000000cb2500)) (.leaf 0xd6d6d6d60000000000ca51c9)) (.leaf 0xd6d6d6d60000000000ca517f))))) (by decide +kernel)

private theorem step131 : ProjectedGoal ⟨54972, 54998, 0, 70, 1068, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54985 (by decide) (by decide) (step129 rates cones) (step130 rates cones)

private theorem step132 : ProjectedGoal ⟨54999, 55005, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.leaf 0xd6d7d6d70000246139ca5207) (.x (.x (.y (.leaf 0xd6d8d6d800002ba7decb1503) (.leaf 0xd6d8d6d80000000000cb2500)) (.leaf 0xd6d8d6d80000000000ca51c9)) (.leaf 0xd6d8d6d80000000000ca517f))) (.m (.leaf 0xd6d9d6d90000254a0eca5207) (.x (.x (.y (.leaf 0xd6dad6da00002ba7decb1503) (.leaf 0xd6dad6da0000000000cb2500)) (.leaf 0xd6dad6da0000000000ca51c9)) (.leaf 0xd6dad6da0000000000ca517f)))) (.x (.x (.m (.m (.y (.leaf 0xd6dbd6db00002ba7decb1503) (.leaf 0xd6dbd6db0000000000cb2500)) (.y (.leaf 0xd6dcd6dc00002ba7decb1503) (.leaf 0xd6dcd6dc0000000000cb2500))) (.y (.leaf 0xd6ddd6dd00002ba7decb1503) (.leaf 0xd6ddd6dd0000000000cb2500))) (.leaf 0xd6ddd6db0000000000ca51c9)) (.leaf 0xd6ddd6db0000000000ca517f))) (by decide +kernel)

private theorem step133 : ProjectedGoal ⟨55006, 55012, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.m (.m (.x (.x (.y (.leaf 0xd6dfd6de00002f4b31cb3503) (.leaf 0xd6dfd6de0000000000cb2500)) (.leaf 0xd6dfd6de0000000000ca51c9)) (.leaf 0xd6dfd6de0000000000ca517f)) (.x (.x (.y (.leaf 0xd6e1d6e000002f4b31cb3503) (.leaf 0xd6e1d6e00000000000cb2500)) (.leaf 0xd6e1d6e00000000000ca51c9)) (.leaf 0xd6e1d6e00000000000ca517f))) (.m (.x (.x (.y (.leaf 0xd6e3d6e2000032ee84cb3503) (.leaf 0xd6e3d6e20000000000cb2500)) (.leaf 0xd6e3d6e20000000000ca51c9)) (.leaf 0xd6e3d6e20000000000ca517f)) (.x (.x (.y (.leaf 0xd6e4d6e4000032ee84cb3503) (.leaf 0xd6e4d6e40000000000cb2500)) (.leaf 0xd6e4d6e40000000000ca51c9)) (.leaf 0xd6e4d6e40000000000ca517f)))) (by decide +kernel)

private theorem step134 : ProjectedGoal ⟨54999, 55012, 0, 70, 1068, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55005 (by decide) (by decide) (step132 rates cones) (step133 rates cones)

private theorem step135 : ProjectedGoal ⟨55013, 55019, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.x (.x (.y (.leaf 0xd6e5d6e500003a3529cb3503) (.leaf 0xd6e5d6e50000000000cb2500)) (.leaf 0xd6e5d6e50000000000ca51c9)) (.leaf 0xd6e5d6e50000000000ca517f)) (.x (.x (.y (.leaf 0xd6e6d6e600003a3529cb3503) (.leaf 0xd6e6d6e60000000000cb2500)) (.leaf 0xd6e6d6e60000000000ca51c9)) (.leaf 0xd6e6d6e60000000000ca517f))) (.m (.x (.x (.y (.leaf 0xd6e7d6e700003a3529cb3503) (.leaf 0xd6e7d6e70000000000cb2500)) (.leaf 0xd6e7d6e70000000000ca51c9)) (.leaf 0xd6e7d6e70000000000ca517f)) (.x (.x (.y (.leaf 0xd6e8d6e800003a3529cb3503) (.leaf 0xd6e8d6e80000000000cb2500)) (.leaf 0xd6e8d6e80000000000ca51c9)) (.leaf 0xd6e8d6e80000000000ca517f)))) (.x (.x (.m (.m (.y (.leaf 0xd6e9d6e90000746a52cb3503) (.leaf 0xd6e9d6e90000000000cb2500)) (.y (.leaf 0xd6ead6ea0000746a52cb3503) (.leaf 0xd6ead6ea0000000000cb2500))) (.y (.leaf 0xd6ebd6eb01d1a94a20cb350a) (.leaf 0xd6ebd6eb0000000000cb2500))) (.leaf 0xd6ebd6e90000000000ca51c9)) (.leaf 0xd6ebd6e90000000000ca517f))) (by decide +kernel)

private theorem step136 : ProjectedGoal ⟨55020, 55025, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.m (.m (.y (.leaf 0xd6edd6ec01d1a94a20cb3662) (.leaf 0xd6edd6ec0000000000cb2191)) (.y (.leaf 0xd6eed6ee03a3529440cb3ca0) (.leaf 0xd6eed6ee00001d1a94cb2207))) (.y (.leaf 0xd6f1d6ef0746a52880cb3836) (.x (.x (.m (.m (.leaf 0xd6efd6ef00001d1a94cb2503) (.leaf 0xd6f0d6f000001d1a94cb2503)) (.leaf 0xd6f1d6f100001d1a94cb2503)) (.leaf 0xd6f1d6ef0000000000cb21c9)) (.leaf 0xd6f1d6ef0000000000cb217f)))) (by decide +kernel)

private theorem step137 : ProjectedGoal ⟨55013, 55025, 0, 70, 1068, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55019 (by decide) (by decide) (step135 rates cones) (step136 rates cones)

private theorem step138 : ProjectedGoal ⟨54999, 55025, 0, 70, 1068, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55012 (by decide) (by decide) (step134 rates cones) (step137 rates cones)

private theorem step139 : ProjectedGoal ⟨54972, 55025, 0, 70, 1068, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54998 (by decide) (by decide) (step131 rates cones) (step138 rates cones)

private theorem step140 : ProjectedGoal ⟨55026, 55039, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.y (.leaf 0xd6f3d6f20e8d4a5100cb3192) (.leaf 0xd6f3d6f200001d1a94cb2207)) (.y (.leaf 0xd6f5d6f40e8d4a5100cb3192) (.leaf 0xd6f5d6f400001d1a94cb2207))) (.m (.y (.leaf 0xd6f7d6f60e8d4a5100cb3192) (.leaf 0xd6f7d6f60000246139cb4207)) (.y (.leaf 0xd6f8d6f81d1a94a200cb3caa) (.leaf 0xd6f8d6f80000246139cb4207)))) (.m (.m (.m (.y (.leaf 0xd6f9d6f91d1a94a200cb3caa) (.leaf 0xd6f9d6f900001d1a94cb2207)) (.y (.leaf 0xd6fad6fa1d1a94a200cb3caa) (.leaf 0xd6fad6fa0000246139cb4207))) (.m (.leaf 0xd6fbd6fb00002abf0acb5207) (.y (.leaf 0xd6fcd6fc1d1a94a200cb3caa) (.leaf 0xd6fcd6fc0000246139cb4207)))) (.y (.leaf 0xd6ffd6fd3a35294400cb3049) (.y (.leaf 0xd6ffd6fd0746a52880cb6836) (.x (.x (.m (.m (.leaf 0xd6fdd6fd0000000000cb7500) (.leaf 0xd6fed6fe00001d1a94cb7503)) (.leaf 0xd6ffd6ff00001d1a94cb7503)) (.leaf 0xd6ffd6fd0000000000cb71c9)) (.leaf 0xd6ffd6fd0000000000cb717f)))))) (by decide +kernel)

private theorem step141 : ProjectedGoal ⟨55040, 55052, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.m (.m (.m (.y (.leaf 0xd701d7003a35294400cb3049) (.leaf 0xd701d7000000246139cb4207)) (.y (.leaf 0xd703d702746a528800cb3049) (.leaf 0xd703d7020000246139cb4207))) (.m (.leaf 0xd705d70400002ba7deca5207) (.leaf 0xd706d70600002ba7deca5207))) (.m (.y (.leaf 0xd709d707e8d4a51000cb3049) (.y (.leaf 0xd709d7071d1a94a200cb6caa) (.m (.m (.leaf 0xd707d7070000746a52cb8207) (.leaf 0xd708d70800003a3529cb8207)) (.leaf 0xd709d70901d1a94a20cb8662)))) (.leaf 0xd70cd70a00e8d4a510cb5203))) (by decide +kernel)

private theorem step142 : ProjectedGoal ⟨55026, 55052, 0, 70, 1068, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55039 (by decide) (by decide) (step140 rates cones) (step141 rates cones)

private theorem step143 : ProjectedGoal ⟨55053, 55079, 0, 70, 1068, 1072⟩ :=
  projectedGoal_chunk _ (.leaf 0xd727d70d0746a52880cb5836) (by decide +kernel)

private theorem step144 : ProjectedGoal ⟨55026, 55079, 0, 70, 1068, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55052 (by decide) (by decide) (step142 rates cones) (step143 rates cones)

private theorem step145 : ProjectedGoal ⟨54972, 55079, 0, 70, 1068, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55025 (by decide) (by decide) (step139 rates cones) (step144 rates cones)

private theorem step146 : ProjectedGoal ⟨54972, 55079, 0, 70, 1064, 1072⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1068 (by decide) (by decide) (step128 rates cones) (step145 rates cones)

theorem Part00015 : ProjectedGoal ⟨54972, 55079, 0, 70, 1064, 1072⟩ := step146

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
