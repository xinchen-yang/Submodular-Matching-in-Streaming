import SubmodularMatching.UpperBoundAssignment
import SubmodularMatching.StreamingOnlineStochastic

/-! # Support of finite algorithms supplied with uniform words -/

namespace SubmodularMatching.UpperBoundAssembly.CandidateLaw

open GibbsSampler Streaming MeasureTheory
open scoped BigOperators ENNReal

noncomputable section

variable {A B : Type*}

def PositiveOnSupport (q : CandidateLaw A) : Prop :=
  ∀ a ∈ q.outcomes, 0 < q.mass a

theorem pure_positiveOnSupport (a : A) : (pure a).PositiveOnSupport := by
  classical
  intro b hb
  have h : b = a := Finset.mem_singleton.mp hb
  subst b
  simp [pure]

theorem bind_positiveOnSupport [DecidableEq B] (q : CandidateLaw A) (r : A → CandidateLaw B)
    (hq : q.PositiveOnSupport) (hr : ∀ a ∈ q.outcomes, (r a).PositiveOnSupport) :
    (q.bind r).PositiveOnSupport := by
  intro b hb
  obtain ⟨a, ha, hbr⟩ := (mem_bind q r b).1 hb
  have hterm : 0 < q.mass a * (r a).restrictedMass b := by
    exact mul_pos (hq a ha) (by simpa only [restrictedMass, if_pos hbr] using hr a ha b hbr)
  apply hterm.trans_le
  exact Finset.single_le_sum (fun t ht => mul_nonneg (q.probability.nonnegative t ht)
    ((r t).restrictedMass_nonneg b)) ha

theorem execute_positiveOnSupport (step : ℕ → A → CandidateLaw A)
    (hstep : ∀ t a, (step t a).PositiveOnSupport) (n j : ℕ) (initial : A) :
    (execute step n j initial).PositiveOnSupport := by
  classical
  induction n generalizing j initial with
  | zero => exact pure_positiveOnSupport initial
  | succ n ih =>
    exact bind_positiveOnSupport (step j initial) (execute step n (j + 1))
      (hstep j initial) (fun a _ => ih (j + 1) a)

theorem map_positiveOnSupport [DecidableEq B] (q : CandidateLaw A) (convert : A → B)
    (hq : q.PositiveOnSupport) : (q.map convert).PositiveOnSupport := by
  classical
  intro b hb
  obtain ⟨a, ha, hEq⟩ : ∃ a ∈ q.outcomes, convert a = b := Finset.mem_image.mp hb
  let contribution : A → ℝ := fun t =>
    @ite ℝ (convert t = b) (Classical.propDecidable (convert t = b)) (q.mass t) 0
  have hterm : 0 < contribution a := by
    simpa only [contribution, if_pos hEq] using hq a ha
  have hnonneg (t : A) (ht : t ∈ q.outcomes) : 0 ≤ contribution t := by
    dsimp only [contribution]
    split_ifs
    · exact q.probability.nonnegative t ht
    · exact le_rfl
  change 0 < ∑ t ∈ q.outcomes, contribution t
  exact hterm.trans_le (Finset.single_le_sum hnonneg ha)

theorem assign_positiveOnSupport {F : ℕ → Type*} (choices : ∀ j, CandidateLaw (F j))
    (hchoices : ∀ j, (choices j).PositiveOnSupport) (is : List ℕ) (initial : ∀ j, F j) :
    (assign choices is initial).PositiveOnSupport := by
  classical
  induction is generalizing initial with
  | nil => exact pure_positiveOnSupport initial
  | cons j is ih =>
    exact bind_positiveOnSupport (choices j) (fun a => assign choices is (Function.update initial j a))
      (hchoices j) (fun a _ => ih (Function.update initial j a))

private theorem wordLaw_singleton_positive (length bits : ℕ)
    (w : Fin length → Fin (2 ^ bits)) : 0 < ((wordLaw length bits) {w}).toReal := by
  classical
  have h := marginal_wordLaw_eq_uniform length bits
    (Set.indicator {w} (1 : (Fin length → Fin (2 ^ bits)) → ℝ))
  rw [integral_indicator_one (measurableSet_singleton _)] at h
  simp only [Set.indicator_apply, Set.mem_singleton_iff, Pi.one_apply, Finset.sum_ite_eq',
    Finset.mem_univ, if_true] at h
  change ((wordLaw length bits) {w}).toReal = _ at h
  rw [h]
  positivity

theorem wordLaw_positiveOnSupport (length bits : ℕ) :
    (ofMeasure (wordLaw length bits)).PositiveOnSupport := by
  intro w _
  exact wordLaw_singleton_positive length bits w

/-- Every possible block of uniform words has strictly positive mass. -/
theorem wordBatchLaw_positiveOnSupport (count length bits : ℕ) :
    (ofMeasure (wordBatchLaw count length bits)).PositiveOnSupport := by
  intro draw _
  change 0 < ((wordBatchLaw count length bits) {draw}).toReal
  rw [wordBatchLaw, Measure.pi_singleton, ENNReal.toReal_prod]
  exact Finset.prod_pos fun i _ => wordLaw_singleton_positive length bits (draw i)

/-- Equality of all finite observables transports every positive-mass
state to a genuinely attained state of the comparison law. -/
theorem mem_image_of_expected_eq (q : CandidateLaw A) (r : CandidateLaw B) (f : B → A)
    (heq : ∀ test : A → ℝ, expected q.outcomes q.mass test =
      expected r.outcomes r.mass (test ∘ f)) (s : A) (hs : s ∈ q.outcomes)
    (hpos : 0 < q.mass s) : ∃ t ∈ r.outcomes, f t = s := by
  classical
  by_contra hn
  push_neg at hn
  let test : A → ℝ := fun a => if a = s then 1 else 0
  have hr : expected r.outcomes r.mass (test ∘ f) = 0 := by
    unfold expected
    exact Finset.sum_eq_zero (fun t ht => by simp [test, hn t ht])
  have hq : q.mass s ≤ expected q.outcomes q.mass test := by
    unfold expected
    have hsum := Finset.single_le_sum (f := fun a => q.mass a * test a)
      (fun a ha => mul_nonneg (q.probability.nonnegative a ha) (by dsimp [test]; split <;> norm_num)) hs
    simpa [test] using hsum
  exact (hpos.trans_le hq).ne' ((heq test).trans hr)

end

end SubmodularMatching.UpperBoundAssembly.CandidateLaw
