import SubmodularMatching.UpperBoundOptimizerBudget
import SubmodularMatching.StreamingSourceTape

/-! # Joint finite law of streaming estimates and derivative batches -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler Streaming
open NumericalCertificate (finiteError)

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable {Ns Ng : ℕ}

structure PreparedTape (P : ScheduledSource E V) (Ns Ng : ℕ) where
  stream : ℕ → Fin Ns → ℝ
  optimizer : OptimizerFamily P stream Ng

/-- The optimizer's draws are attached to the actual stored instance
sizes, conditional on the completed source execution. -/
def preparationLaw (P : ScheduledSource E V) (source : CandidateLaw (ℕ → Fin Ns → ℝ))
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k) :
    CandidateLaw (PreparedTape P Ns Ng) := by
  classical
  exact source.bind fun b => (finalOptimizerLaw P b hunique).map (PreparedTape.mk b)

def preparedGood (P : ScheduledSource E V) (t : PreparedTape P Ns Ng) : Prop :=
  goodStreamingBatches P t.stream ∧ optimizerFamilyGood P t.stream t.optimizer

theorem preparationLaw_support (P : ScheduledSource E V) (source : CandidateLaw (ℕ → Fin Ns → ℝ))
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (t : PreparedTape P Ns Ng) (ht : t ∈ (preparationLaw P source hunique).outcomes) :
    t.stream ∈ source.outcomes ∧ t.optimizer ∈ (finalOptimizerLaw P t.stream hunique).outcomes := by
  classical
  obtain ⟨b, hb, hat⟩ := (source.mem_bind
    (fun b => (finalOptimizerLaw P b hunique).map (PreparedTape.mk b)) t).mp ht
  obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp hat
  exact ⟨hb, ha⟩

def preparationFailure (P : ScheduledSource E V) (t : PreparedTape P Ns Ng) : ℝ := by
  classical
  exact if preparedGood P t then 0 else 1

theorem preparationLaw_failure (P : ScheduledSource E V) (source : CandidateLaw (ℕ → Fin Ns → ℝ))
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (harrived : ∀ e, e ∈ arrivedEdges P.edges P.arrivals)
    (hB : 0 < singletonMaximum P.value P.arrivals)
    (ω : ℝ) (hω : 0 < ω) (hω1 : ω ≤ 1)
    (hsource : expected source.outcomes source.mass (sourceFailureIndicator P) ≤ ω / 2) :
    let Ng := gradientSamples (P.vertices ^ 2) (P.span + 1) ω
    let q := preparationLaw (Ng := Ng) P source hunique
    expected q.outcomes q.mass (preparationFailure P) ≤ ω := by
  classical
  dsimp only
  let Ng := gradientSamples (P.vertices ^ 2) (P.span + 1) ω
  unfold preparationLaw
  rw [CandidateLaw.bind_expected]
  simp_rw [CandidateLaw.map_expected]
  have hrow (b : ℕ → Fin Ns → ℝ) :
      let r := finalOptimizerLaw (Ng := Ng) P b hunique
      expected r.outcomes r.mass (preparationFailure P ∘ PreparedTape.mk b) ≤
        sourceFailureIndicator P b + ω / 2 := by
    let r := finalOptimizerLaw (Ng := Ng) P b hunique
    let test := optimizerFamilyFailure (Ng := Ng) P b
    have hopt := finalOptimizerLaw_failure P b hunique harrived hB ω hω hω1
    have hmono (a : OptimizerFamily P b Ng) :
        preparationFailure P ⟨b, a⟩ ≤ sourceFailureIndicator P b + test a := by
      by_cases hb : goodStreamingBatches P b <;> by_cases ha : optimizerFamilyGood P b a <;>
        simp [preparationFailure, preparedGood, sourceFailureIndicator, test, optimizerFamilyFailure, hb, ha]
    calc
      _ ≤ expected r.outcomes r.mass (fun a => sourceFailureIndicator P b + test a) :=
        r.expected_le _ _ (fun a _ => hmono a)
      _ = sourceFailureIndicator P b + expected r.outcomes r.mass test := by
        rw [CandidateLaw.expected_add, CandidateLaw.expected_const]
      _ ≤ _ := add_le_add le_rfl hopt
  apply (source.expected_le _ _ (fun b _ => hrow b)).trans
  rw [CandidateLaw.expected_add, CandidateLaw.expected_const]
  linarith only [hsource]

end

end SubmodularMatching.UpperBoundAssembly
