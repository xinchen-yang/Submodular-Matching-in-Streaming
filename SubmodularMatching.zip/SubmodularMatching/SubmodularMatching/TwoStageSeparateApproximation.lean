import SubmodularMatching.TwoStageSeparateLaw
import SubmodularMatching.GibbsSpectralIntegerBudget

/-!
# Finite Gibbs implementation with separate supports

The explicit integer Gibbs budgets supply the conditional error for the
actual altered vector. An arbitrary first sampler within its variation
budget can be substituted without changing the feasible-union bound.
-/

namespace SubmodularMatching.TwoStage

open GibbsMatching GibbsSampler
open scoped BigOperators

variable {E V : Type*} [DecidableEq V]

theorem separateSecondActivity_unit_bounds [DecidableEq E] [Fintype E] [Finite V] (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (A S : Finset E) (x y : E → ℝ) (p D r εA εG : ℝ)
    (hp : 0 ≤ p) (hr0 : 0 < r) (hr1 : r ≤ 1) (hDr : D = r*(1-r))
    (hgap : meanAllowance p D < εA) (hG0 : 0 < εG) (hG1 : εG < 1)
    (hcap : p ≤ εG^5/5120) (hFeas : SeparateFeasible ends A S x y p D)
    (T : Finset E) (e : E) (he : e ∈ S) :
    0 ≤ separateSecondActivity ends A S x y εA εG T e ∧
      separateSecondActivity ends A S x y εA εG T e ≤ 1 := by
  let γ := 1-εG/4
  have hγ0 : 0 < γ := by dsimp [γ]; linarith
  have hγ1 : γ < 1 := by dsimp [γ]; linarith
  refine ⟨separateSecondActivity_nonnegative ends hloop hsimple A S x y p D r εA εG hp hr0 hr1 hDr
    hgap hG0 hG1 hFeas T e he,?_⟩
  have hz := separate_alteration_correct ends hloop hsimple A S x y p D r εA hp hr0 hr1 hDr hgap hFeas
  have h := calibratedActivity_cap (pairEnds ends) S (separateAltered ends A S x y εA T)
    (fun d _ => (hz.1 T d).1) (hz.2.1 T) (fun d _ => by simp [pairEnds,Finset.card_pair (hloop d)])
    γ p hγ0 hγ1 (fun d _ => (hz.1 T d).2) e he
  refine h.trans ?_
  have hden : 0 < (1-γ)^2 := sq_pos_of_pos (sub_pos.mpr hγ1)
  rw [div_mul_eq_mul_div,div_le_iff₀ hden,one_mul]
  have h₁ : γ*p ≤ p := by simpa only [one_mul] using mul_le_mul_of_nonneg_right hγ1.le hp
  have h₂ : εG^5 ≤ εG^2 := by
    calc
      εG^5 = εG^3*εG^2 := by ring
      _ ≤ 1*εG^2 := mul_le_mul_of_nonneg_right (pow_le_one₀ hG0.le hG1.le) (sq_nonneg _)
      _ = εG^2 := one_mul _
  dsimp [γ] at h₁ ⊢
  nlinarith only [h₁,h₂,hcap,sq_nonneg εG]

/-- The composed sampler with the integer Gibbs budgets instantiated on
its conditional positive support. -/
noncomputable def separateLowActivityMass [LinearOrder E] [Fintype E] [Fintype V]
    (ends : E → V × V) (A S : Finset E) (x y : E → ℝ) (εA εG : ℝ)
    (first : Finset E → ℝ) (denominator : ℕ) : Finset E × Finset E → ℝ :=
  jointLaw first (fun T => lowActivityGibbsLaw (pairEnds ends) S
    (separateSecondActivity ends A S x y εA εG T) denominator)

set_option maxHeartbeats 850000 in
theorem separate_low_activity_variation [LinearOrder E] [Fintype E] [Fintype V]
    (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (A S : Finset E)
    (x y : E → ℝ) (εA εG ε₁ : ℝ) (first : Finset E → ℝ)
    (denominator : ℕ) (hDen : 0 < denominator)
    (hFirst : IsProbability (matchings (pairEnds ends) A) first)
    (hε₁ : variation (matchings (pairEnds ends) A) (Shearer.mass (pairEnds ends) A y) first ≤ ε₁)
    (ha : ∀ T ∈ matchings (pairEnds ends) A, ∀ e ∈ S,
      0 ≤ separateSecondActivity ends A S x y εA εG T e ∧
        separateSecondActivity ends A S x y εA εG T e ≤ 1) :
    let B := pairEnds ends
    let states := (matchings B A) ×ˢ (matchings B S)
    let mass := separateLowActivityMass ends A S x y εA εG first denominator
    IsProbability states mass ∧
      (∀ pair ∈ states, 0 < mass pair → Streaming.IsMatchingOn B (pair.1 ∪ pair.2)) ∧
      variation states (separateTwoStageMass ends A S x y εA εG) mass ≤ ε₁+1/(denominator:ℝ) := by
  let B := pairEnds ends
  let R := matchings B A
  let U := matchings B S
  let a := separateSecondActivity ends A S x y εA εG
  let approx := fun T => lowActivityGibbsLaw B S (a T) denominator
  let ideal := fun T => probability B S (a T)
  have hApprox (T : Finset E) (_ : T ∈ R) : IsProbability U (approx T) :=
    lowActivityGibbsLaw_probability B S (a T) denominator
  have hIdeal (T : Finset E) (hT : T ∈ R) : IsProbability U (ideal T) := by
    refine ⟨fun N _ => probability_nonnegative B S (a T) (fun e he => (ha T hT e he).1) N,?_⟩
    exact probability_total B S (a T) (fun e he => (ha T hT e he).1)
  refine ⟨jointLaw_probability R U first approx hFirst hApprox,?_,?_⟩
  · intro pair hPair hPos
    have hT := (Finset.mem_product.mp hPair).1
    have hN : 0 < approx pair.1 pair.2 := by
      by_contra! h
      exact (not_lt_of_ge (mul_nonpos_of_nonneg_of_nonpos (hFirst.nonnegative pair.1 hT) h)) hPos
    let m := (positiveEdges S (a pair.1)).card
    let t := lowActivitySteps (Fintype.card V) m (lowActivityPrecision denominator)
    let b := lowActivityBits t m denominator
    change 0 < supportedGibbsLaw B S (a pair.1) b t pair.2 at hN
    exact separate_supported_union_matching ends A S x y εA εG pair.1 pair.2 b t hT
      (fun e he => (ha pair.1 hT e he).1) hN
  · change variation (R ×ˢ U) (jointLaw (Shearer.mass B A y) ideal) (jointLaw first approx) ≤ _
    refine (variation_joint R U _ _ ideal approx hFirst hIdeal (1/(denominator:ℝ)) ?_).trans
      (add_le_add hε₁ le_rfl)
    intro T hT
    have hTV := lowActivityGibbsLaw_variation B S (a T) (ha T hT)
      (fun e _ => by simp [B,pairEnds,Finset.card_pair (hloop e)]) denominator hDen
    have hsym : variation U (ideal T) (approx T) = variation U (approx T) (ideal T) := by
      unfold variation
      simp only [abs_sub_comm (ideal T _) (approx T _)]
    rwa [hsym]

/-- For an observable bounded on matchings, the pair-law errors transfer
without bounding its value on infeasible unions. -/
theorem separate_low_activity_value_error [LinearOrder E] [Fintype E] [Fintype V]
    (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (A S : Finset E)
    (x y : E → ℝ) (εA εG ε₁ M : ℝ) (first : Finset E → ℝ)
    (denominator : ℕ) (hDen : 0 < denominator)
    (hIdeal : IsProbability (matchings (pairEnds ends) A) (Shearer.mass (pairEnds ends) A y))
    (hFirst : IsProbability (matchings (pairEnds ends) A) first)
    (hε₁ : variation (matchings (pairEnds ends) A) (Shearer.mass (pairEnds ends) A y) first ≤ ε₁)
    (ha : ∀ T ∈ matchings (pairEnds ends) A, ∀ e ∈ S,
      0 ≤ separateSecondActivity ends A S x y εA εG T e ∧
        separateSecondActivity ends A S x y εA εG T e ≤ 1)
    (f : Finset E → ℝ) (hM : 0 ≤ M)
    (hf : ∀ K, Streaming.IsMatchingOn (pairEnds ends) K → 0 ≤ f K ∧ f K ≤ M) :
    let B := pairEnds ends
    let states := (matchings B A) ×ˢ (matchings B S)
    let mass := separateLowActivityMass ends A S x y εA εG first denominator
    |separateTwoStageValue ends A S x y εA εG f -
      expected states mass (fun pair => f (pair.1 ∪ pair.2))| ≤ (ε₁+1/(denominator:ℝ))*M := by
  classical
  dsimp only
  let B := pairEnds ends
  let states := (matchings B A) ×ˢ (matchings B S)
  let ideal := separateTwoStageMass ends A S x y εA εG
  let approx := separateLowActivityMass ends A S x y εA εG first denominator
  let F := fun pair : Finset E × Finset E => f (pair.1 ∪ pair.2)
  let test := fun pair : Finset E × Finset E =>
    if Streaming.IsMatchingOn B (pair.1 ∪ pair.2) then F pair else 0
  have hBound (pair : Finset E × Finset E) (_ : pair ∈ states) : 0 ≤ test pair ∧ test pair ≤ M := by
    by_cases h : Streaming.IsMatchingOn B (pair.1 ∪ pair.2)
    · simpa only [test,if_pos h] using hf (pair.1 ∪ pair.2) h
    · simpa only [test,if_neg h] using And.intro (le_refl (0:ℝ)) hM
  have hIdealP : IsProbability states ideal :=
    separateTwoStageMass_probability ends A S x y εA εG hIdeal (fun T hT e he => (ha T hT e he).1)
  have hApp := separate_low_activity_variation ends hloop A S x y εA εG ε₁ first denominator hDen hFirst hε₁ ha
  have hFeasible (mass : Finset E × Finset E → ℝ) (hP : IsProbability states mass)
      (hMatch : ∀ pair ∈ states, 0 < mass pair → Streaming.IsMatchingOn B (pair.1 ∪ pair.2)) :
      expected states mass test = expected states mass F := by
    unfold expected
    apply Finset.sum_congr rfl
    intro pair hPair
    by_cases h : Streaming.IsMatchingOn B (pair.1 ∪ pair.2)
    · rw [show test pair = F pair from if_pos h]
    · have hZero : mass pair = 0 := le_antisymm (le_of_not_gt (fun hp => h (hMatch pair hPair hp)))
        (hP.nonnegative pair hPair)
      rw [hZero,zero_mul,zero_mul]
  have hIdealFeas : ∀ pair ∈ states, 0 < ideal pair → Streaming.IsMatchingOn B (pair.1 ∪ pair.2) := by
    intro pair hPair hPos
    rcases Finset.mem_product.mp hPair with ⟨hT,hN⟩
    have hY : 0 ≤ Shearer.mass B A y pair.1 := hIdeal.nonnegative pair.1 hT
    have hZ : 0 ≤ probability B S (separateSecondActivity ends A S x y εA εG pair.1) pair.2 :=
      probability_nonnegative B S _ (fun e he => (ha pair.1 hT e he).1) pair.2
    change 0 < Shearer.mass B A y pair.1 * probability B S
      (separateSecondActivity ends A S x y εA εG pair.1) pair.2 at hPos
    exact separate_two_stage_positive_union_matching ends A S x y εA εG _ _
      (pos_of_mul_pos_left hPos hZ) (pos_of_mul_pos_right hPos hY)
  have hDiff := expected_abs_difference_le states ideal approx test hIdealP hApp.1 M hBound
  rw [hFeasible ideal hIdealP hIdealFeas,hFeasible approx hApp.1 hApp.2.1] at hDiff
  rw [← separateTwoStageMass_value ends A S x y εA εG f]
  exact hDiff.trans (mul_le_mul_of_nonneg_right hApp.2.2 hM)

end SubmodularMatching.TwoStage
