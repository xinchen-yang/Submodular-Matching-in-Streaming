import SubmodularMatching.UpperBoundGradientParameters

/-! # One derivative sample count valid for every surviving instance -/

namespace SubmodularMatching.UpperBoundAssembly

open NumericalCertificate

noncomputable section

theorem gradientSamples_spec (m mmax L : ℕ) (hm : 0 < m) (hmmax : m ≤ mmax) (hL : 0 < L)
    (ω : ℝ) (hω : 0 < ω) (hω1 : ω ≤ 1) :
    let δ := ω / (2 * (L : ℝ))
    let ξ := FiniteGreedy.accuracy degree m finiteError
    let K := FiniteGreedy.stages degree m finiteError
    0 < gradientSamples mmax L ω ∧
      8 / ξ ^ 2 * Real.log (2 / (δ / ((K : ℝ) * m))) ≤ gradientSamples mmax L ω := by
  dsimp only
  refine ⟨Nat.succ_pos _, ?_⟩
  let K := FiniteGreedy.stages degree m finiteError
  let H := FiniteGreedy.stages degree mmax finiteError
  let ξ := FiniteGreedy.accuracy degree m finiteError
  let η := FiniteGreedy.accuracy degree mmax finiteError
  let δ := ω / (2 * (L : ℝ))
  have hL' : (1 : ℝ) ≤ L := by exact_mod_cast hL
  have hL0 : (0 : ℝ) < L := zero_lt_one.trans_le hL'
  have hm' : (1 : ℝ) ≤ m := by exact_mod_cast hm
  have hmmax' : (m : ℝ) ≤ mmax := by exact_mod_cast hmmax
  have hK : (1 : ℝ) ≤ K := by exact_mod_cast (FiniteGreedy.stages_positive degree m finiteError)
  have hKH : (K : ℝ) ≤ H := by exact_mod_cast grad_stages_mono hmmax
  have hδ : 0 < δ := by positivity
  have hξ : 0 < ξ := appendix_accuracy_pos hm
  have hη : 0 < η := appendix_accuracy_pos (hm.trans_le hmmax)
  have hξ' : η ≤ ξ := grad_accuracy_antitone hm hmmax
  have hlogarg : 2 / (δ / ((K : ℝ) * m)) = 4 * L * (K : ℝ) * m / ω := by
    dsimp [δ]
    field_simp
    ring
  have hlocal : (1 : ℝ) ≤ 4 * L * (K : ℝ) * m / ω := by
    apply (le_div_iff₀ hω).2
    have hprod : (1 : ℝ) ≤ (L : ℝ) * K * m := by
      calc
        (1 : ℝ) = 1 * 1 * 1 := by norm_num
        _ ≤ _ := by gcongr
    nlinarith only [hω1, hprod]
  have hglobal : 4 * L * (K : ℝ) * m / ω ≤ 4 * L * (H : ℝ) * mmax / ω := by
    gcongr
  have hlog := (Real.log_le_log (zero_lt_one.trans_le hlocal) hglobal).trans
    (binaryBudget_log _ (zero_lt_one.trans_le (hlocal.trans hglobal)))
  have hfirst : 8 / ξ ^ 2 ≤ 8 / η ^ 2 := by
    apply div_le_div_of_nonneg_left (by norm_num) (by positivity)
    gcongr
  have hnonneg := Real.log_nonneg hlocal
  change 8 / ξ ^ 2 * Real.log (2 / (δ / ((K : ℝ) * m))) ≤ gradientSamples mmax L ω
  rw [hlogarg]
  refine (mul_le_mul hfirst hlog hnonneg (by positivity)).trans ?_
  unfold gradientSamples
  push_cast
  exact (Nat.le_ceil _).trans (le_add_of_nonneg_right (by norm_num))

end

end SubmodularMatching.UpperBoundAssembly
