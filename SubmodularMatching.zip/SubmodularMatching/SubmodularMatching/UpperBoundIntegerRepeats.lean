import SubmodularMatching.UpperBoundOutcomeLaw
import SubmodularMatching.UpperBoundSamplingParameters

/-! # Implementing high-probability amplification by integer doubling -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler NumericalCertificate ProbabilityAmplification

noncomputable section

variable {A T : Type*}

/-- A safe repetition count requiring only a binary-width routine. -/
def appendixTrials (delta : ℝ) : ℕ := 359988611 * binaryBudget (2 / delta)

theorem appendixTrials_ge (delta : ℝ) (hδ : 0 < delta) : trials delta ≤ appendixTrials delta := by
  unfold trials appendixTrials
  apply Nat.ceil_le.mpr
  have h := binaryBudget_log (2 / delta) (by positivity)
  push_cast
  exact mul_le_mul_of_nonneg_left h (by norm_num)

theorem conditional_repetitions_more (q : CandidateLaw A) (value : A → ℝ)
    (opt delta : ℝ) (hopt : 0 < opt) (hδ : 0 < delta)
    (hval : ∀ a ∈ q.outcomes, value a ≤ opt)
    (hmean : opt / conservativeFactor ≤ expected q.outcomes q.mass value)
    (count : ℕ) (hcount : trials delta ≤ count) :
    repeatedFailure q.outcomes q.mass value (opt / hpFactor) count ≤ delta / 2 := by
  have hp := conditional_repetitions q.outcomes q.mass value opt delta hopt hδ
    q.probability.nonnegative q.probability.total hval hmean
  apply le_trans _ hp
  rw [repeatedFailure_eq_pow _ _ _ _ q.probability.total,
    repeatedFailure_eq_pow _ _ _ _ q.probability.total]
  obtain ⟨hn, hu⟩ := successMass_bounds q.outcomes q.mass value (opt / hpFactor)
    q.probability.nonnegative q.probability.total
  exact pow_le_pow_of_le_one (sub_nonneg.mpr hu) (sub_le_self _ hn) hcount

/-- Any sufficient integer round count has the advertised final guarantee
for the actual grid comparison and the full finite transcript law. -/
theorem program_high_probability_at_count (prep : CandidateLaw T)
    (good : T → Prop) [DecidablePred good] (s : Finset A) (value : A → ℝ)
    (qs : T → List (CandidateLaw A)) (initial : A) (opt B delta : ℝ)
    (hopt : 0 < opt) (hB : 0 < B) (hBopt : B ≤ opt) (hδ : 0 < delta)
    (hinit : initial ∈ s) (hsupport : ∀ t, ∀ q ∈ qs t, q.outcomes ⊆ s)
    (hrange : ∀ a ∈ s, value a ≤ opt)
    (hbad : (∑ t ∈ prep.outcomes, if good t then 0 else prep.mass t) ≤ delta / 2)
    (hgood : ∀ t ∈ prep.outcomes, good t →
      let y := scanExpectation value (finiteError * B / 2) value (qs t) initial
      B ≤ y ∧ theta * min sigma beta * opt ≤ y + 5 * finiteError * B)
    (count : ℕ) (hcount : trials delta ≤ count) :
    let law := amplifiedOutputLaw prep s value (finiteError * B / 2) qs initial hinit hsupport count
    expected law.outcomes law.mass (fun a => if opt / targetFactor ≤ value a then 0 else 1) ≤ delta := by
  classical
  dsimp only
  rw [amplifiedOutputLaw_value]
  let step := finiteError * B / 2
  let test := fun a : A => if opt / targetFactor ≤ value a then (0 : ℝ) else 1
  let Y := fun t => selectionExpectation s (scanMass value step (qs t) initial) value step test count initial
  have hy (t : T) (ht : t ∈ prep.outcomes) :
      prep.mass t * Y t ≤ prep.mass t * (delta / 2) + if good t then 0 else prep.mass t := by
    let q := oneTrialLaw s value step (qs t) initial hinit (hsupport t)
    by_cases hg : good t
    · have hm := conditional_trial_expectation opt B _ hopt.le (hgood t ht hg).1 (hgood t ht hg).2
      have hmean : opt / conservativeFactor ≤ expected q.outcomes q.mass value := by
        change _ ≤ expected s (scanMass value step (qs t) initial) value
        rw [scanMass_expected s value value step (qs t) initial hinit (hsupport t)]
        exact hm
      have hpart := selection_failure_le_repetitions s q.mass value opt B hopt.le hB hBopt
        q.probability.nonnegative q.probability.total count initial
      have hbound := hpart.trans (conditional_repetitions_more q value opt delta hopt hδ hrange hmean count hcount)
      simpa only [if_pos hg, add_zero] using mul_le_mul_of_nonneg_left hbound (prep.probability.nonnegative t ht)
    · have hpart := selectionExpectation_mono s q.mass value step test (fun _ => 1)
        q.probability.nonnegative (fun a => by unfold test; split_ifs <;> norm_num) count initial
      have htotal : s.sum q.mass = 1 := q.probability.total
      rw [selectionExpectation_const s q.mass value step 1 htotal count initial] at hpart
      rw [if_neg hg]
      exact (mul_le_mul_of_nonneg_left hpart (prep.probability.nonnegative t ht)).trans
        (by rw [mul_one]; exact le_add_of_nonneg_left (by positivity [prep.probability.nonnegative t ht]))
  calc
    _ ≤ ∑ t ∈ prep.outcomes, (prep.mass t * (delta / 2) + if good t then 0 else prep.mass t) :=
      Finset.sum_le_sum hy
    _ ≤ delta := by
      rw [Finset.sum_add_distrib, ← Finset.sum_mul, prep.probability.total, one_mul]
      linarith only [hbad]

end

end SubmodularMatching.UpperBoundAssembly
