import SubmodularMatching.CapacitySignedSamplerResources
import SubmodularMatching.NonmonotoneAmplification
import SubmodularMatching.CapacityIndexCursor

/-! A common graph-size bound for live compact rounding storage,
dyadic choice words, and independent final repetitions. -/
namespace SubmodularMatching.Capacity
open Streaming AppendixM UpperBoundAssembly ShearerSampler GibbsSampler ShearerCappedSampler Finset
noncomputable section

private theorem graph_log_bound (n D C d : ℕ) (h : D ≤ C*(n+1)^d) :
    Nat.clog 2 D ≤ (d+C.log2+1)*((n+1).log2+1) :=
  Nat.clog_le_of_le_pow (polynomial_index_word_bound h).le

theorem inverse_polynomial_repetitions (q : ℕ) :
    postprocessCount (((2:ℝ)^q)⁻¹) ≤ ⌈1/trialSuccess⌉₊*(q+1) := by
  unfold postprocessCount
  apply Nat.ceil_le.mpr
  push_cast
  have h2 : Real.log 2 ≤ 1 := by linarith only [Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)]
  have he : Real.log (2/(((2:ℝ)^q)⁻¹)) = ((q:ℝ)+1)*Real.log 2 := by
    rw [Real.log_div (by norm_num) (by positivity),Real.log_inv,Real.log_pow]
    ring
  rw [he]
  have h := Nat.le_ceil (1/trialSuccess)
  have hp : 0 < (q:ℝ)+1 := by positivity
  calc
    _ ≤ ((q:ℝ)+1)/trialSuccess := div_le_div_of_nonneg_right
      (by simpa using mul_le_mul_of_nonneg_left h2 hp.le) trialSuccess_pos.le
    _ = (1/trialSuccess)*((q:ℝ)+1) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right h hp.le

/-- The edge, stop and neighbor rejection words for either concrete layer
fit this many bits, uniformly over the slot labels and their activities. -/
theorem physical_choice_words {E : Type*} (num den : E → ℕ) (D n C d : ℕ)
    (hD : 0<D) (hd : D ≤ C*(n+1)^d) :
    let c := ShearerCappedSampler.discretize num den D hD
    let bits := (d+(2601*C).log2+1)*((n+1).log2+1)
    c.edgeGrid.bits ≤ bits ∧ c.stopGrid.bits ≤ bits ∧ c.neighborGrid.bits ≤ bits := by
  intro c bits
  have hbig := graph_log_bound n (2601*D) (2601*C) d (by
    simpa only [Nat.mul_assoc] using Nat.mul_le_mul_left 2601 hd)
  have hstop : 100 ≤ 2601*D := by omega
  have hnei : D*(51*(100-51)) ≤ 2601*D := by omega
  change Nat.clog 2 (D*51^2) ≤ bits ∧ Nat.clog 2 100 ≤ bits ∧ Nat.clog 2 (D*51*(100-51)) ≤ bits
  exact ⟨by simpa only [show (51:ℕ)^2=2601 by decide,Nat.mul_comm D 2601] using hbig,
    (Nat.clog_mono_right 2 hstop).trans hbig,
    (Nat.clog_mono_right 2 (by simpa only [Nat.mul_assoc] using hnei)).trans hbig⟩

/-- An end-to-end dimension substitution for the live reserve of an indexed
two-layer rounding. The retained input contributes s labels; m can count every
virtual slot pair. Its logarithm and the error precision fit input-size words. -/
theorem reserve_graph_bound (s m D n C d : ℕ) (hs : s≤n^2) (hm : m≤s*n^2)
    (hd : D≤C*(n+1)^d) :
    let w := (n+1).log2+1
    let q := Nat.clog 2 D
    let K := 2*s+q+1
    let L := samplerFuel (51/100) (((2:ℝ)^q)⁻¹) m
    let T := d+C.log2+1
    2*K + 2*L ≤ 4*s + (5000*(7+T)+2*T+4)*w := by
  intro w q K L T
  have hw : 1≤w := by dsimp [w]; omega
  have hq : q≤T*w := graph_log_bound n D C d hd
  have hm' : m≤n^4 := (hm.trans (Nat.mul_le_mul_right _ hs)).trans_eq (by ring)
  have hpoly : m+1≤1*(n+1)^4 := (Nat.add_le_add_right hm' 1).trans (by ring_nf; omega)
  have hlog : Nat.clog 2 (m+1) ≤ 5*w := by
    simpa only [show (4+(1:ℕ).log2+1)=5 by decide] using graph_log_bound n (m+1) 1 4 hpoly
  have hf : L ≤ 2500*(2+Nat.clog 2 (m+1)+q)+1 := (physical_sampler_limits m q).1
  dsimp only [K]
  nlinarith only [hf,hlog,hq,hw]

end
end SubmodularMatching.Capacity
