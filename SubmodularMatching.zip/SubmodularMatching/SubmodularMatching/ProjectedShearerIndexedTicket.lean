import SubmodularMatching.FiniteShearerTapeAcceptance

/-! # Implicit index scans for the finite-word slot sampler

Each ticket is resolved by an index cursor, its remaining visit count and
remaining ticket. The prefix, occupied-slot filter, vertex exclusion and
recursive exclusion stack are tested on the current edge. -/

namespace SubmodularMatching.ShearerCappedSampler
open GibbsMatching GibbsSampler ShearerSampler

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Mathematical list denoted by an implicit interval of edge indices. -/
def indexedList (get : ℕ → Option E) (start : ℕ) : ℕ → List E
  | 0 => []
  | n+1 => (get start).elim (indexedList get (start+1) n) (fun e => e :: indexedList get (start+1) n)

/-- Runtime scan. No list of potential slot edges is constructed. -/
def indexedTicket (get : ℕ → Option E) (cells : ℕ → E → ℕ) (start : ℕ) : ℕ → ℕ → Option E
  | 0, _ => none
  | n+1, ticket => match get start with
    | none => indexedTicket get cells (start+1) n ticket
    | some e => if ticket < cells start e then some e else indexedTicket get cells (start+1) n (ticket-cells start e)

theorem indexedTicket_eq (get : ℕ → Option E) (cells : ℕ → E → ℕ) (weight : E → ℕ) (start n ticket : ℕ)
    (agree : ∀ j, start ≤ j → j < start+n → ∀ e, get j = some e → cells j e = weight e) :
    indexedTicket get cells start n ticket = scanTicket weight (indexedList get start n) ticket := by
  induction n generalizing start ticket with
  | zero => rfl
  | succ n ih =>
    have tail := ih (start+1)
    cases hget : get start with
    | none =>
      simp only [indexedTicket,indexedList,hget,Option.elim_none]
      exact tail _ (fun j hj hlt e he => agree j (by omega) (by omega) e he)
    | some e =>
      have he := agree start le_rfl (by omega) e hget
      simp only [indexedTicket,indexedList,hget,Option.elim_some,he,scanTicket]
      split_ifs
      · rfl
      · exact tail _ (fun j hj hlt e he => agree j (by omega) (by omega) e he)

/-- Residual membership is decided from the prefix cursor, the actual
partial matching and at most one extra excluded vertex. -/
def sparseEligible (ends : E → Finset V) (cut j : ℕ) (A : Finset E) (extra : Option V) (e : E) : Bool :=
  decide (cut ≤ j ∧ e ∉ A ∧ (∀ a ∈ A, Disjoint (ends a) (ends e)) ∧ extra.all (fun v => v ∉ ends e))

/-- This finite set is used only in the reference semantics. -/
def referenceBase (ends : E → Finset V) (P A : Finset E) (extra : Option V) :=
  extra.elim (compactResidualEdges ends P A) (fun v => deleteVertex ends (compactResidualEdges ends P A) v)

private theorem sparseEligible_spec (ends : E → Finset V) (cut j : ℕ) (A P : Finset E) (extra : Option V) (e : E)
    (hr : e ∈ P ↔ cut ≤ j) : sparseEligible ends cut j A extra e = true ↔ e ∈ referenceBase ends P A extra := by
  cases extra <;> simp [sparseEligible,referenceBase,compactResidualEdges,deleteVertex,hr,and_assoc]

def indexedNeighbor (c : RationalShearerInput E) (ends : E → Finset V) (get : ℕ → Option E) (N cut : ℕ)
    (A : Finset E) (extra : Option V) (v : V) (stack : List V) (B : ℕ) (tape : NeighborWordTape c B) : Option E :=
  (c.neighborGrid.wordDraw B tape).bind (fun w => indexedTicket get (fun j e =>
    if sparseEligible ends cut j A extra e && decide (v ∈ ends e) && stack.all (fun u => u ∉ ends e)
    then c.edgeCells e else 0) 0 N w.val)

private theorem indexedNeighbor_eq (c : RationalShearerInput E) (ends : E → Finset V) (get : ℕ → Option E)
    (N cut : ℕ) (A P : Finset E) (extra : Option V) (v : V) (stack : List V) (B : ℕ) (tape : NeighborWordTape c B)
    (hr : ∀ j < N, ∀ e, get j = some e → (e ∈ P ↔ cut ≤ j)) :
    indexedNeighbor c ends get N cut A extra v stack B tape = compactNeighborDraw c ends
      (referenceBase ends P A extra) (indexedList get 0 N) v stack B tape := by
  unfold indexedNeighbor compactNeighborDraw
  cases hh : c.neighborGrid.wordDraw B tape with
  | none => rfl
  | some w =>
    apply indexedTicket_eq
    intro j _ hj e he
    have eqb := sparseEligible_spec ends cut j A P extra e (hr j (by simpa using hj) e he)
    simp only [Bool.and_eq_true,decide_eq_true_eq,compactNeighborCells,eqb,and_assoc]

def indexedCoinNext (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V)
    (get : ℕ → Option E) (N cut : ℕ) (A : Finset E) (extra : Option V)
    (v : V) (stack : List V) (B : ℕ) (w : CoinWordBlock c B) : Option (List V) :=
  match c.stopGrid.wordDraw B w.1 with
  | none => none
  | some u => if u.val < c.a then some stack else
      (indexedNeighbor c ends get N cut A extra v stack B w.2).map (fun e => endpointFromPair ep e v :: v :: stack)

private theorem indexedCoinNext_eq (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V)
    (get : ℕ → Option E) (N cut : ℕ) (A P : Finset E) (extra : Option V) (v : V) (stack : List V) (B : ℕ) (w : CoinWordBlock c B)
    (hr : ∀ j < N, ∀ e, get j = some e → (e ∈ P ↔ cut ≤ j)) :
    indexedCoinNext c ends ep get N cut A extra v stack B w =
    compactCoinNext c ends ep (referenceBase ends P A extra) (indexedList get 0 N) B v stack w := by
  unfold indexedCoinNext compactCoinNext
  rw [indexedNeighbor_eq c ends get N cut A P extra v stack B w.2 hr]
  cases c.stopGrid.wordDraw B w.1 <;> rfl

def indexedCoin (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V) (get : ℕ → Option E)
    (N cut : ℕ) (A : Finset E) (extra : Option V) (B : ℕ) : (fuel : ℕ) → List V → FullCoinWordTape c B fuel → Bool
  | _, [], _ => true
  | 0, _ :: _, _ => false
  | fuel+1, v::stack, tape => (indexedCoinNext c ends ep get N cut A extra v stack B (tape 0)).elim false
      (fun u => indexedCoin c ends ep get N cut A extra B fuel u (Fin.tail tape))

private theorem indexedCoin_eq (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V)
    (get : ℕ → Option E) (N cut : ℕ) (A P : Finset E) (extra : Option V) (B fuel : ℕ) (stack : List V) (tape : FullCoinWordTape c B fuel)
    (hr : ∀ j < N, ∀ e, get j = some e → (e ∈ P ↔ cut ≤ j)) :
    indexedCoin c ends ep get N cut A extra B fuel stack tape =
    compactCoinRun c ends ep (referenceBase ends P A extra) (indexedList get 0 N) B fuel stack tape := by
  induction fuel generalizing stack with
  | zero => cases stack <;> rfl
  | succ fuel ih =>
    cases stack with
    | nil => rfl
    | cons v stack =>
      rw [indexedCoin,compactCoinRun_succ,indexedCoinNext_eq c ends ep get N cut A P extra v stack B _ hr]
      cases compactCoinNext c ends ep (referenceBase ends P A extra) (indexedList get 0 N) B v stack (tape 0) with
      | none => rfl
      | some next => exact ih next (Fin.tail tape)

/-- A genuinely implicit acceptance: the full rejection graph and the
list denoted by the indexer are never materialized in this computation. -/
def indexedDecision (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V) (get : ℕ → Option E)
    (N cut : ℕ) (A : Finset E) (e : E) (B fuel : ℕ) (tape : AcceptanceWordTape c B fuel) : Finset E :=
  let ok := decide (∀ d ∈ A, d ≠ e ∧ Disjoint (ends e) (ends d))
  let u := (ep e).1
  let v := (ep e).2
  let accepted := ok && edgeWordAccept c e B tape.1 && indexedCoin c ends ep get N cut A none B fuel [u] tape.2.1 &&
    indexedCoin c ends ep get N cut A (some u) B fuel [v] tape.2.2
  if accepted then insert e A else A

theorem indexedDecision_eq (c : RationalShearerInput E) (ends : E → Finset V) (ep : E → V×V)
    (get : ℕ → Option E) (N cut : ℕ) (A P : Finset E) (e : E) (B fuel : ℕ) (tape : AcceptanceWordTape c B fuel)
    (hA : A ⊆ P) (hr : ∀ j < N, ∀ e, get j = some e → (e ∈ P ↔ cut ≤ j)) :
    indexedDecision c ends ep get N cut A e B fuel tape =
    compactMatchingDecision c ends ep (indexedList get 0 N) B fuel P A e tape := by
  have hgate : (∀ d ∈ A, d ∈ P ∧ d ≠ e ∧ Disjoint (ends e) (ends d)) ↔
      ∀ d ∈ A, d ≠ e ∧ Disjoint (ends e) (ends d) :=
    ⟨fun h d hd => (h d hd).2,fun h d hd => ⟨hA hd,h d hd⟩⟩
  unfold indexedDecision compactMatchingDecision compactEdgeAccept compactCompatible
  dsimp only
  rw [indexedCoin_eq c ends ep get N cut A P none _ _ _ _ hr,
    indexedCoin_eq c ends ep get N cut A P (some (ep e).1) _ _ _ _ hr]
  simp only [referenceBase,Option.elim_none,Option.elim_some,hgate,Bool.and_assoc,decide_eq_true_eq]
  split_ifs <;> simp_all

end SubmodularMatching.ShearerCappedSampler
