import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextInterior

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step159 : ProjectedGoal ⟨540, 553, 0, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.leaf 0x229021c00e8d4a5105b33b8) (.y (.y (.y (.leaf 0x229021ce8d4a5100059d59c) (.y (.y (.leaf 0x229021c03a35294405b64f9) (.m (.y (.y (.m (.m (.m (.leaf 0x21c021c00e61a27205c04fb) (.leaf 0x21d021d00e8d4a5105bf4fb)) (.m (.leaf 0x21e021e00e61a27205c04fb) (.leaf 0x21f021f00e8d4a5105bf4fb))) (.m (.m (.leaf 0x220022000e61a27205c04fb) (.leaf 0x221022100e8d4a5105bf4fb)) (.leaf 0x222022200e61a27205c04fb))) (.leaf 0x222021c00000000005bc4f7)) (.leaf 0x222021c00000000005bd4f7)) (.y (.y (.m (.m (.m (.leaf 0x223022300e8d4a5105bf4fb) (.leaf 0x224022400e61a27205c04fb)) (.m (.leaf 0x225022500e8d4a5105bf4fb) (.leaf 0x226022600e61a27205c04fb))) (.m (.m (.leaf 0x227022700e8d4a5105bf4fb) (.leaf 0x228022800e61a27205c04fb)) (.leaf 0x229022900e8d4a5105bf4fb))) (.leaf 0x229022300000000005bc4f7)) (.leaf 0x229022300000000005bd4f7)))) (.leaf 0x229021c00000000005a74f7))) (.leaf 0x229021c00000000005b04f7)) (.leaf 0x229021c00000000005b14f7))) (.leaf 0x229021c00000000005b21c9)) (.leaf 0x229021c00000000005b217f)) (by decide +kernel)

private theorem step160 : ProjectedGoal ⟨554, 566, 0, 17, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.leaf 0x236022a00e8d4a5105b33b8) (.y (.y (.y (.leaf 0x236022ae8d4a5100059d59c) (.y (.y (.leaf 0x236022a03a35294405b64f9) (.y (.m (.y (.m (.m (.y (.leaf 0x22b022a01d1a94a205ba4fb) (.m (.leaf 0x22a022a00e531527b5bb4fc) (.leaf 0x22b022b00e8d4a5105c14fb))) (.y (.leaf 0x22d022c01d1a94a205ba4fb) (.m (.leaf 0x22c022c00e531527b5bb4fc) (.leaf 0x22d022d00e8d4a5105c14fb)))) (.m (.y (.leaf 0x22f022e01d1a94a205ba4fb) (.m (.leaf 0x22e022e00e531527b5bb4fc) (.leaf 0x22f022f00e8d4a5105c14fb))) (.leaf 0x230023000e702fbc55bf4fb))) (.leaf 0x230022a00000000005bc4f7)) (.m (.y (.y (.leaf 0x233023101d1a94a205ba4fb) (.m (.m (.leaf 0x231023100e8d4a5105c14fb) (.leaf 0x232023200e531527b5bb4fc)) (.leaf 0x233023300e8d4a5105c14fb))) (.leaf 0x233023100000000005bc4f7)) (.y (.y (.leaf 0x236023401d1a94a205ba4fb) (.m (.m (.leaf 0x234023400e531527b5bb4fc) (.leaf 0x235023500e8d4a5105c14fb)) (.leaf 0x236023600e531527b5bb4fc))) (.leaf 0x236023400000000005bc4f7)))) (.leaf 0x236022a00000000005bd4f7))) (.leaf 0x236022a00000000005a74f7))) (.leaf 0x236022a00000000005b04f7)) (.leaf 0x236022a00000000005b14f7))) (by decide +kernel)

private theorem step161 : ProjectedGoal ⟨554, 566, 17, 35, 567, 851⟩ :=
  projectedGoal_chunk _ (.leaf 0x236022a00000000005b21c9) (by decide +kernel)

private theorem step162 : ProjectedGoal ⟨554, 566, 0, 35, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 17 (by decide) (by decide) (step160 rates cones) (step161 rates cones)

private theorem step163 : ProjectedGoal ⟨554, 566, 35, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.leaf 0x236022a00000000005b217f) (by decide +kernel)

private theorem step164 : ProjectedGoal ⟨554, 566, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 35 (by decide) (by decide) (step162 rates cones) (step163 rates cones)

private theorem step165 : ProjectedGoal ⟨540, 566, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 553 (by decide) (by decide) (step159 rates cones) (step164 rates cones)

private theorem step166 : ProjectedGoal ⟨567, 573, 0, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.leaf 0x23d023700e8d4a5105b33b8) (.y (.y (.y (.leaf 0x23d0237e8d4a5100059d59c) (.y (.y (.leaf 0x23d02370746a528805b659c) (.y (.m (.y (.y (.leaf 0x23a023701d1a94a205ba4fb) (.m (.m (.leaf 0x237023700e8d4a5105c14fb) (.leaf 0x238023800e531527b5bb4fc)) (.m (.leaf 0x239023900e8d4a5105c14fb) (.leaf 0x23a023a00e531527b5bb4fc)))) (.leaf 0x23a023700000000005bc4f7)) (.y (.y (.leaf 0x23d023b01d1a94a205ba4fb) (.m (.m (.leaf 0x23b023b00e8d4a5105c14fb) (.leaf 0x23c023c00e531527b5bb4fc)) (.leaf 0x23d023d00e8d4a5105c14fb))) (.leaf 0x23d023b00000000005bc4f7))) (.leaf 0x23d023700000000005bd4f7))) (.leaf 0x23d023700000000005a74f7))) (.leaf 0x23d023700000000005b04f7)) (.leaf 0x23d023700000000005b14f7))) (.leaf 0x23d023700000000005b21c9)) (.leaf 0x23d023700000000005b217f)) (by decide +kernel)

private theorem step167 : ProjectedGoal ⟨574, 580, 0, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.leaf 0x244023e00e8d4a5105b33b8) (.y (.y (.y (.leaf 0x244023ee8d4a5100059d59c) (.y (.y (.leaf 0x244023e0746a528805b659c) (.y (.m (.m (.y (.y (.leaf 0x23f023e01d1a94a205ba4fb) (.m (.leaf 0x23e023e00e531527b5bb4fc) (.leaf 0x23f023f00e8d4a5105c14fb))) (.leaf 0x23f023e00000000005bc4f7)) (.y (.y (.leaf 0x241024001d1a94a205ba4fb) (.m (.leaf 0x240024000e702fbc55c14fb) (.leaf 0x241024100e8d4a5105c14fb))) (.leaf 0x241024000000000005bc4f7))) (.m (.y (.m (.leaf 0x242024200e702fbc55bf4fb) (.leaf 0x243024300e8d4a5105bf4fb)) (.leaf 0x243024200000000005bc4f7)) (.y (.leaf 0x244024400e702fbc55bf4fb) (.leaf 0x244024400000000005bc4f7)))) (.leaf 0x244023e00000000005bd4f7))) (.leaf 0x244023e00000000005a74f7))) (.leaf 0x244023e00000000005b04f7)) (.leaf 0x244023e00000000005b14f7))) (.leaf 0x244023e00000000005b21c9)) (.leaf 0x244023e00000000005b217f)) (by decide +kernel)

private theorem step168 : ProjectedGoal ⟨567, 580, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 573 (by decide) (by decide) (step166 rates cones) (step167 rates cones)

private theorem step169 : ProjectedGoal ⟨581, 593, 0, 17, 567, 851⟩ :=
  projectedGoal_chunk _ (.x (.leaf 0x251024500e8d4a5105b33b8) (.y (.y (.y (.leaf 0x2510245e8d4a5100059d59c) (.y (.m (.y (.leaf 0x24b02450746a528805b659c) (.y (.m (.m (.m (.leaf 0x245024500e531527b5c24fc) (.y (.leaf 0x246024600e702fbc55bf4fb) (.leaf 0x246024600cbba106e5bc4fc))) (.m (.leaf 0x247024700e531527b5c24fc) (.y (.leaf 0x248024800e702fbc55bf4fb) (.leaf 0x248024800da475abf5bc4fc)))) (.m (.m (.leaf 0x249024900e531527b5c24fc) (.y (.leaf 0x24a024a00e702fbc55bf4fb) (.leaf 0x24a024a00da475abf5bc4fc))) (.leaf 0x24b024b00e531527b5c24fc))) (.leaf 0x24b024500000000005bd4f7))) (.y (.leaf 0x251024c0e8d4a51005b659c) (.y (.m (.m (.m (.y (.leaf 0x24c024c00e702fbc55bf4fb) (.leaf 0x24c024c00e18dffe75bc4fc)) (.leaf 0x24d024d00e531527b5c24fc)) (.y (.leaf 0x24e024e00e702fbc55bf4fb) (.leaf 0x24e024e00e18dffe75bc4fc))) (.m (.m (.leaf 0x24f024f00e8d4a5105be4fb) (.y (.leaf 0x250025000e8d4a5105bf4fb) (.leaf 0x250025000e18dffe75bc4fc))) (.leaf 0x251025100e8d4a5105be4fb))) (.leaf 0x251024c00000000005bd4f7)))) (.leaf 0x251024500000000005a74f7))) (.leaf 0x251024500000000005b04f7)) (.leaf 0x251024500000000005b14f7))) (by decide +kernel)

private theorem step170 : ProjectedGoal ⟨581, 593, 17, 35, 567, 851⟩ :=
  projectedGoal_chunk _ (.leaf 0x251024500000000005b21c9) (by decide +kernel)

private theorem step171 : ProjectedGoal ⟨581, 593, 0, 35, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 17 (by decide) (by decide) (step169 rates cones) (step170 rates cones)

private theorem step172 : ProjectedGoal ⟨581, 593, 35, 70, 567, 851⟩ :=
  projectedGoal_chunk _ (.leaf 0x251024500000000005b217f) (by decide +kernel)

private theorem step173 : ProjectedGoal ⟨581, 593, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 35 (by decide) (by decide) (step171 rates cones) (step172 rates cones)

private theorem step174 : ProjectedGoal ⟨567, 593, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 580 (by decide) (by decide) (step168 rates cones) (step173 rates cones)

private theorem step175 : ProjectedGoal ⟨540, 593, 0, 70, 567, 851⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 566 (by decide) (by decide) (step165 rates cones) (step174 rates cones)

theorem Part00013 : ProjectedGoal ⟨540, 593, 0, 70, 567, 851⟩ := step175

end SubmodularMatching.SourceCertificate.Replay.HardNextInterior
