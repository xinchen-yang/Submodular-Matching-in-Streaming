import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step78 : ProjectedGoal ⟨54864, 55079, 0, 141, 993, 1028⟩ :=
  projectedGoal_chunk _ (.leaf 0xd7ffd4a0e8d4a51000c380a5) (by decide +kernel)

theorem Part00009 : ProjectedGoal ⟨54864, 55079, 0, 141, 993, 1028⟩ := step78

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
