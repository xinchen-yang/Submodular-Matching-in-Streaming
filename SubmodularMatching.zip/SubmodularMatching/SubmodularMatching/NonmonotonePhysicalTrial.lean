import SubmodularMatching.NonmonotoneBinaryCandidate
import SubmodularMatching.NonmonotoneMarkedPriority
import SubmodularMatching.NonmonotonePhysicalMarkedGrid
import SubmodularMatching.NonmonotoneTrialFeasibility

/-! # A complete postprocessing law on the original b-matching output -/

namespace SubmodularMatching.NonmonotoneCandidate
open GibbsMatching GibbsSampler UpperBoundAssembly TwoStage TwoLayerDiffuse VarianceBound Shearer ShearerCappedSampler Capacity AppendixM
open scoped BigOperators
noncomputable section

variable {I C L V : Type*} [LinearOrder I] [Fintype I] [LinearOrder C] [DecidableEq L] [DecidableEq V]

private theorem symm_dist {A : Type*} (s : Finset A) (x y : A → ℝ) : variation s x y = variation s y x := by
  unfold variation
  simp only [abs_sub_comm (x _) (y _)]

theorem physical_binary_pair_variation {V' : Type*} [DecidableEq V'] (base : C → Finset V') (S : Finset C)
    (I J : Input base S) (δ : ℝ) (hδ : 0<δ ∧ δ≤1)
    (r₁ r₂ a b t : ℕ) (ha : 0<a) (hb : 0<b) (hend : ∀ e∈S, (base e).Nonempty)
    (x y : C → ℝ) (hx : InteriorLaw base S x) (e₁ e₂ : ℝ)
    (h₁ : variation Finset.univ (Shearer.probability base S x) (outcomeLaw I δ hδ r₁).mass ≤ e₁)
    (h₂ : variation Finset.univ (Shearer.probability base S y) (outcomeLaw J δ hδ r₂).mass ≤ e₂) :
    variation Finset.univ (binaryPair I J δ hδ r₁ r₂ a b t ha hb hend).mass
      (nativeMarkedPair base S a b x y) ≤ e₁+e₂+2*((2:ℝ)^t)⁻¹ := by
  let f := fun k (w : C → ℝ) => Shearer.probability (cloneEnds base) (timedSupport S k) (fun i => w i.1/k)
  have step (K k r : ℕ) (hk : 0<k) (J : Input base S) (z : C→ℝ) (ε : ℝ)
      (hz : variation Finset.univ (Shearer.probability base S z) (outcomeLaw J δ hδ r).mass ≤ ε) :
      variation Finset.univ (binaryLayer J δ hδ r k K hk hend).mass (f k z) ≤ ε+((2:ℝ)^K)⁻¹ := by
    let q := outcomeLaw J δ hδ r
    let lift := markedCandidate base S k hk hend q
    have hq : q.restrictedMass = q.mass := by funext c; simp [q,CandidateLaw.restrictedMass]
    have hv := marked_variation base S z k hk hend q
    rw [hq,symm_dist Finset.univ q.mass _] at hv
    have hm := binaryMarked_variation base S k K hk hend q
    have ht := variation_triangle Finset.univ (binaryLayer J δ hδ r k K hk hend).mass lift.mass (f k z)
    rw [symm_dist Finset.univ (binaryLayer J δ hδ r k K hk hend).mass lift.mass] at ht
    change variation Finset.univ lift.mass (binaryLayer J δ hδ r k K hk hend).mass ≤ _ at hm
    change variation Finset.univ lift.mass (f k z) = variation Finset.univ _ q.mass at hv
    change variation Finset.univ _ q.mass ≤ _ at hz
    linarith only [ht,hv,hm,hz]
  have hp : IsProbability Finset.univ (f a x) := by
    refine ⟨?_,probability_total _ _ _⟩
    intro z _
    dsimp only [f]
    rw [←mark_mass_native base S x a ha hend]
    exact div_nonneg (hx.nonneg _ (forgetMark z).property) (by positivity)
  let p := binaryLayer I δ hδ r₁ a t ha hend
  let q := binaryLayer J δ hδ r₂ b t hb hend
  have ht := variation_joint Finset.univ Finset.univ p.mass (f a x) (fun _ => q.mass) (fun _ => f b y)
    hp (fun _ _ => q.probability) _ (fun _ _ => step t b r₂ hb J y e₂ h₂)
  rw [Finset.univ_product_univ] at ht
  exact ht.trans ((add_le_add_left (step t a r₁ ha I x e₁ h₁) _).trans_eq (by ring))

theorem compact_load {W : Type*} [DecidableEq W] {n : ℕ} (slot : Fin n ↪ W) (ep : I → Fin n × Fin n)
    (physical : I → W×W) (geom : ∀ i, physical i=(slot (ep i).1,slot (ep i).2))
    (num : I → ℕ) (v : Fin n) :
    gridLoadNumerator (pairEnds ep) Finset.univ num v = gridLoadNumerator (pairEnds physical) Finset.univ num (slot v) := by
  unfold gridLoadNumerator
  congr 1
  ext e
  simp [incident,pairEnds,geom]

/-- The same finite law satisfies original feasibility and the rounding
inequality. The numerical hypotheses are the upstream coordinate/priority
certificates; no expected output or conditional Gibbs inequality is assumed. -/
theorem physical_trial {cap : V → ℕ} (base : C → Finset (Slots cap)) (active : Finset C)
    (orig : L → V×V) (lab : C → L) (copy : I → C) (label : I ↪ L) (hlabel : ∀ i, lab (copy i)=label i)
    {v : ℕ} (slot : Fin v ↪ Slots cap) (ep : I → Fin v × Fin v) (geom : ∀ i,
      base (copy i)=pairEnds (fun j => (slot (ep j).1,slot (ep j).2)) i)
    (hgeom : ∀ c ∈ active ∪ Finset.univ.image copy, ∀ j, touches orig j (lab c) → ∃ w ∈ base c, w.1=j)
    (one two : Input base active) (δ : ℝ) (hδ : 0<δ ∧ δ≤1) (r₁ r₂ a b t : ℕ) (ha : 0<a) (hb : 0<b)
    (hend : ∀ e∈active,(base e).Nonempty) (y₁ y₂ : C→ℝ) (hy₁ : InteriorLaw base active y₁)
    (hy₂ : InteriorLaw base active y₂) (e₁ e₂ : ℝ)
    (h₁ : variation Finset.univ (Shearer.probability base active y₁) (outcomeLaw one δ hδ r₁).mass ≤ e₁)
    (h₂ : variation Finset.univ (Shearer.probability base active y₂) (outcomeLaw two δ hδ r₂).mass ≤ e₂)
    (k Q D : ℕ) (hk : 0<k) (hQ : 0<Q) (hD : 0<D)
    (order : ℕ → I) (m : ℕ) (cover : (Finset.univ:Finset I) ⊆ replacementPrefix order m)
    (hi : ∀ j<m,∀ l<m,order j=order l→j=l)
    (loop : ∀ i, (ep i).1 ≠ (ep i).2) (simple : Function.Injective (pairEnds ep))
    (f : Finset L→ℝ) (hf : IsSubmodular f) (hn : ∀ U,0≤f U) (B : ℝ) (hB : 0≤B)
    (p G F : ℝ) (hp : 0≤p) (hp1 : p≤1) (hpc : p ≤ signedRoundingCap (1/k))
    (wh : ℕ → ℝ) (x : I → ℝ) (hw : ∀ i<m,0≤wh i ∧ wh i ≤ arrivalWeight (fun j => label (order j)) p f i)
    (hlin : ∑ i∈Finset.range m, wh i*x (order i) ≤ G)
    (h : Finset L→ℝ) (estimate : Finset (C×ℕ) → C×ℕ → ℝ)
    (num : (Marked base active a × Marked base active b) → I → ℕ) (η ρ : ℝ)
    (hc : ∀ z i, (num z i:ℝ)/Q ≤ p)
    (hl : ∀ z w, gridLoadNumerator (pairEnds (fun i => (slot (ep i).1,slot (ep i).2))) Finset.univ (num z) w ≤ Q)
    (hs : ∀ z i, num z i ≠ 0 → vacant base active (slot (ep i).1) (forgetMark z.1,forgetMark z.2)=1 ∧
      vacant base active (slot (ep i).2) (forgetMark z.1,forgetMark z.2)=1)
    (ha' : ∀ i, (1-1/(k:ℝ))*x i-η ≤ finiteMean (nativeMarkedPair base active a b y₁ y₂) (fun z => (num z i:ℝ)/Q))
    (hp' : gamma*F-ρ ≤ finiteMean (nativeMarkedPair base active a b y₁ y₂) (fun z =>
      residualValue (fun j => label (order j)) p f m
        ((estimatedOutput base lab h estimate z.1.val z.2.val).image (binLabel lab))))
    (upper : ∀ z : Marked base active a × Marked base active b, ∀ N ∈ matchings (pairEnds ep) Finset.univ,
      f (((estimatedOutput base lab h estimate z.1.val z.2.val).image (binLabel lab)) ∪ N.image label) ≤ B) :
    let first := binaryPair one two δ hδ r₁ r₂ a b t ha hb hend
    let T := fun z : Marked base active a × Marked base active b =>
      (estimatedOutput base lab h estimate z.1.val z.2.val).image (binLabel lab)
    let out := trial first ep Finset.univ num k Q D T label
    let ξ := 1/(k:ℝ)
    let Lval := ∑ i ∈ Finset.range m, wh i*x (order i)
    let loss := (1-ξ)*(ρ+η*∑ i∈Finset.range m,wh i) + B/D + (e₁+e₂+2*((2:ℝ)^t)⁻¹)*B
    (∀ M∈out.outcomes, Capacity.feasible orig cap M) ∧
      (1-ξ)*(f ∅+Lval+gamma*F-ξ*G)-loss ≤ expected out.outcomes out.mass f := by
  intro first T out ξ Lval loss
  let μ := nativeMarkedPair base active a b y₁ y₂
  have hμ := nativeMarkedPair_probability base active a b ha hb hend y₁ y₂ hy₁ hy₂
  have hload (z) (w : Fin v) : gridLoadNumerator (pairEnds ep) Finset.univ (num z) w ≤ Q :=
    (compact_load slot ep _ (fun _ => rfl) (num z) w).trans_le (hl z (slot w))
  constructor
  · let TF := fun z : Marked base active a × Marked base active b =>
      (estimatedOutput base lab h estimate z.1.val z.2.val).image Prod.fst
    have ht (z) : T z = (TF z).image lab := by dsimp only [T,TF]; rw [Finset.image_image]; rfl
    have te : T = fun z => (TF z).image lab := funext ht
    dsimp only [out]
    rw [te]
    exact trial_feasible cap base active orig lab first ep Finset.univ slot copy label hlabel geom hgeom
      k Q D hk hQ num Finset.univ.toList (Finset.toList_toFinset _) (Finset.nodup_toList _)
      (fun i _ => loop i) hload (fun z => (forgetMark z.1,forgetMark z.2)) TF (fun z i _ => hs z i)
      (fun z => estimated_unmarked_support base lab h estimate z.1.val z.2.val)
  · have ideal := hround ep Finset.univ μ hμ k Q D hk hQ hD num (fun i _ => loop i) simple.injOn hload
      label order m (fun _ _ => Finset.mem_univ _) cover hi T f hf hn B upper p G gamma F η ρ hp hp1 hpc
      wh (fun i => x (order i)) hw (fun z i _ => hc z i) hlin (fun i _ => ha' (order i)) hp'
    have pert := trial_perturbation ep Finset.univ μ hμ first rfl num k Q D T label f B _ hB
      (fun z N hN => ⟨hn _,upper z N hN⟩) (physical_binary_pair_variation base active one two δ hδ r₁ r₂ a b t ha hb hend y₁ y₂ hy₁ e₁ e₂ h₁ h₂)
    dsimp only at ideal pert
    dsimp only [out,ξ,Lval,loss]
    linarith only [ideal,pert]

end
end SubmodularMatching.NonmonotoneCandidate
