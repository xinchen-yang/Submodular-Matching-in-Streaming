import SubmodularMatching.StreamingK1Source
import SubmodularMatching.StreamingSchedulerStorage
import SubmodularMatching.UpperBoundParametricSampleResources

/-! # Source archive bounds for arbitrary fixed Appendix K rate tables -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming
open scoped BigOperators

noncomputable section

/-- Take the logarithm of any positive constant times the vertex count
and bound the result by a constant times the number of size bits. -/
theorem log_scale_le_wordWidth (a : ℝ) (ha : 0 < a) (n : ℕ) (hn : 0 < n) :
    Real.log (a * (n : ℝ)) ≤
      (max 0 (Real.log a) + Real.log 2) * ((n + 1).log2 + 1 : ℕ) := by
  let w := (n + 1).log2 + 1
  have h1 : (1 : ℝ) ≤ w := by exact_mod_cast (show 1 ≤ w by dsimp [w]; omega)
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have hb : n ≤ 2 ^ w := (Nat.le_succ n).trans (Nat.lt_log2_self (n := n + 1)).le
  have hbR : (n : ℝ) ≤ 2 ^ w := by exact_mod_cast hb
  have hlog := Real.log_le_log hnR hbR
  rw [Real.log_pow] at hlog
  rw [Real.log_mul ha.ne' hnR.ne']
  calc
    _ ≤ max 0 (Real.log a) + (w : ℝ) * Real.log 2 :=
      add_le_add (le_max_right _ _) hlog
    _ ≤ max 0 (Real.log a) * (w : ℝ) + (w : ℝ) * Real.log 2 :=
      add_le_add (by simpa only [mul_one] using
        mul_le_mul_of_nonneg_left h1 (le_max_left 0 (Real.log a))) le_rfl
    _ = _ := by ring

/-- A shared linear cap-to-seed ratio is enough for a uniform logarithmic
stored-incidence budget in any fixed-rate family. -/
theorem incidenceLimit_of_linear_ratio (C : PotentialConfig) (a : ℝ) (ha : 0 < a)
    (n : ℕ) (hn : 0 < n) (hscale : C.cap / C.seed = a * (n : ℝ)) :
    C.incidenceLimit ≤
      ⌈1 + (2 / (C.kappa * C.p)) * (max 0 (Real.log a) + Real.log 2)⌉₊ *
        ((n + 1).log2 + 1) := by
  let w := (n + 1).log2 + 1
  let A := 2 / (C.kappa * C.p)
  let hi := max 0 (Real.log a) + Real.log 2
  have hA : 0 ≤ A := by dsimp [A]; positivity [C.kappa_pos, C.p_pos]
  have hw : (1 : ℝ) ≤ w := by exact_mod_cast (show 1 ≤ w by dsimp [w]; omega)
  have hlog := log_scale_le_wordWidth a ha n hn
  have hh : 1 + A * Real.log (C.cap / C.seed) ≤
      ((⌈1 + A * hi⌉₊ * w : ℕ) : ℝ) := by
    rw [hscale]
    calc
      _ ≤ (w : ℝ) + A * (hi * (w : ℝ)) :=
        add_le_add hw (mul_le_mul_of_nonneg_left hlog hA)
      _ = (1 + A * hi) * (w : ℝ) := by ring
      _ ≤ _ := by
        push_cast
        exact mul_le_mul_of_nonneg_right (Nat.le_ceil _) (Nat.cast_nonneg _)
  exact (Nat.floor_le_floor hh).trans_eq (Nat.floor_natCast _)

open SourceCertificate

variable (R : SourceRateTable) (k : ℕ) (hk : 8 < k)
variable (p : ℚ) (hp : 0 < p) (minimum : ℝ) (hmin : 0 < minimum)
variable (hlow : ∀ i < R.count, minimum ≤ (R.low i : ℝ))
variable (hgrowth : minimum * (p : ℝ) ≤ 1)

private def k1Reference :=
  k1GuessConfig R 2 k (by decide) hk p hp minimum hmin hlow hgrowth 1

private def k1Ratio :=
  let C := k1Reference R k hk p hp minimum hmin hlow hgrowth
  (1 + (C.maxRate + 1) * C.p) / (C.minLow * C.p * k1Epsilon k)

/-- The constant is fixed with the rate table, step and accuracy. -/
def k1IncidenceBound : ℕ :=
  let C := k1Reference R k hk p hp minimum hmin hlow hgrowth
  ⌈1 + (2 / (C.kappa * C.p)) *
    (max 0 (Real.log (k1Ratio R k hk p hp minimum hmin hlow hgrowth)) + Real.log 2)⌉₊

/-- Every active K.1 potential instance has logarithmically many stored
incidences at each vertex for arbitrary fixed rates. -/
theorem k1GuessConfig_incidence_le (n : ℕ) (hn : 2 ≤ n) (tau : ℝ) (ht : 0 < tau) :
    (k1GuessConfig R n k hn hk p hp minimum hmin hlow hgrowth tau).incidenceLimit ≤
      k1IncidenceBound R k hk p hp minimum hmin hlow hgrowth * ((n + 1).log2 + 1) := by
  let C := k1GuessConfig R n k hn hk p hp minimum hmin hlow hgrowth tau
  let C0 := k1Reference R k hk p hp minimum hmin hlow hgrowth
  let a := k1Ratio R k hk p hp minimum hmin hlow hgrowth
  have hn' : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
  have he := (k1Epsilon_bounds k hk).1
  have ha : 0 < a := by
    have hr := C0.minLow_pos.le.trans (C0.base_bounds.2.2.1.trans C0.base_bounds.2.2.2)
    change 0 < (1 + (C0.maxRate + 1) * C0.p) / (C0.minLow * C0.p * k1Epsilon k)
    exact div_pos (by positivity [C0.p_pos]) (by positivity [C0.minLow_pos, C0.p_pos])
  obtain ⟨htau, htheta, _, _⟩ := k1GuessConfig_spec R n k hn hk p hp minimum hmin hlow hgrowth tau ht
  have hscale : C.cap / C.seed = a * (n : ℝ) := by
    have hT : C.tau = tau := htau
    have hθ : C.theta = k1Epsilon k * tau / (n : ℝ) := htheta
    have hP : C.p = C0.p := rfl
    have hminL : C.minLow = C0.minLow := rfl
    have hmaxR : C.maxRate = C0.maxRate := rfl
    unfold PotentialConfig.cap PotentialConfig.seed
    change (1 + (C.maxRate + 1) * C.p) * C.tau / (C.minLow * C.p * C.theta) = _
    rw [hT, hθ, hP, hminL, hmaxR]
    change _ = ((1 + (C0.maxRate + 1) * C0.p) / (C0.minLow * C0.p * k1Epsilon k)) * (n : ℝ)
    field_simp [hn'.ne', ht.ne', C0.minLow_pos.ne', C0.p_pos.ne', he.ne']
  exact incidenceLimit_of_linear_ratio C a ha n (by omega) hscale

/-- The source window has a logarithmic number of guesses at any fixed
choice of the manuscript's reciprocal accuracy. -/
theorem k1GuessSpan_le (n k : ℕ) :
    Nat.clog 2 ((n * k + 1) / 2) + 1 ≤ (3 + k.log2) * ((n + 1).log2 + 1) := by
  let w := (n + 1).log2 + 1
  have hrange : (n * k + 1) / 2 ≤ n * k := by omega
  have hsize : n * k ≤ k * (n + 1) ^ 1 := by
    rw [pow_one, Nat.mul_comm n]
    exact Nat.mul_le_mul_left k (Nat.le_succ _)
  have hpow := polynomial_index_word_bound hsize
  have hlog := Nat.clog_le_of_le_pow hpow.le
  have hw : 1 ≤ w := by dsimp [w]; omega
  calc
    _ ≤ (1 + k.log2 + 1) * w + 1 :=
      Nat.add_le_add_right ((Nat.clog_mono_right 2 hrange).trans hlog) 1
    _ ≤ (1 + k.log2 + 1) * w + w := Nat.add_le_add_left hw _
    _ = _ := by ring

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- On every admissible source history, the sum of live archive rows has
the claimed quadratic logarithmic bound for arbitrary fixed input rates. -/
theorem k1ScheduledSource_totalStored_le (edges : ℕ → E) (ends : E → V × V)
    (f : Finset E → ℝ) (n arrivals : ℕ) (hn : 2 ≤ n) (ha : arrivals ≤ n ^ 2)
    (hp1 : (p : ℝ) ≤ 1) (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : f ∅ = 0)
    (initialLength : ℕ) {N : ℕ} (hN : 0 < N) (history : SourceBatchHistory N)
    (allEdges M : Finset E) (hin : ∀ i < initialLength, edges i ∈ allEdges)
    (hloop : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet ends) A → A.card ≤ M.card)
    (hraw : ∀ i < initialLength, ∀ j s, ∃ A, history (i, j) s = marginal f (edges i) A) :
    let P := k1ScheduledSource R edges ends f n arrivals k hn ha hk p hp hp1 minimum hmin hlow hgrowth
      hf hm h0
    let I := k1IncidenceBound R k hk p hp minimum hmin hlow hgrowth
    let w := (n + 1).log2 + 1
    ∑ j ∈ activeGuessIndices P.width (guessAnchor P.width P.value initialLength)
      (singletonMaximum P.value initialLength) P.span, (P.snapshot history initialLength j).stored.card ≤
        (2 * I * (3 + k.log2)) * M.card * w ^ 2 := by
  intro P I w
  have h := P.snapshot_edges_card_le history initialLength hN (I * w) allEdges M
    hin hloop hMsub hM hmax (k1GuessConfig_incidence_le R k hk p hp minimum hmin hlow hgrowth n hn)
    hraw
  have hs : P.span + 1 ≤ (3 + k.log2) * w := k1GuessSpan_le n k
  calc
    _ ≤ 2 * M.card * (I * w) * (P.span + 1) := h
    _ ≤ 2 * M.card * (I * w) * ((3 + k.log2) * w) := Nat.mul_le_mul_left _ hs
    _ = _ := by ring

private theorem ceil_half_nat (x : ℕ) : ⌈(x : ℝ) / 2⌉₊ = (x + 1) / 2 := by
  apply le_antisymm
  · apply Nat.ceil_le.mpr
    apply (div_le_iff₀ (by norm_num : (0 : ℝ) < 2)).2
    have h : x ≤ ((x + 1) / 2) * 2 := by omega
    exact_mod_cast h
  · by_contra! h
    have hh : 2 * ⌈(x : ℝ) / 2⌉₊ < x := by omega
    have hR : (2 : ℝ) * (⌈(x : ℝ) / 2⌉₊ : ℝ) < (x : ℝ) := by exact_mod_cast hh
    linarith only [hR, Nat.le_ceil ((x : ℝ) / 2)]

omit [DecidableEq V] in
/-- At every permitted Appendix K accuracy, the sample count itself
uses natural arithmetic. The exponent is the existing binary budget. -/
theorem k1SourceSamples_integer (P : ScheduledSource E V) (k : ℕ) (hk : 8 < k)
    (he : P.epsilon = k1Epsilon k) (ω : ℝ) :
    k1SourceSamples P ω =
      (P.vertices ^ 4 * sourceSampleExponent P.vertices (P.span + 1) ω * k ^ 2 + 1) / 2 + 1 := by
  have hkR : (k : ℝ) ≠ 0 := by exact_mod_cast (show k ≠ 0 by omega)
  unfold k1SourceSamples
  rw [he, k1Epsilon]
  congr 1
  rw [← ceil_half_nat]
  congr 1
  push_cast
  field_simp [hkR]

omit [DecidableEq V] in
/-- For inverse-polynomial failure targets, the exact generic source
sample allocation grows as the fourth power of the announced size
times a logarithm. The rate table does not affect this argument. -/
theorem k1SourceSamples_polynomial (P : ScheduledSource E V) (k : ℕ) (hk : 8 < k)
    (he : P.epsilon = k1Epsilon k) (ω : ℝ) (hω : 0 < ω) (CL Cω c : ℕ)
    (hL : P.span + 1 ≤ CL * (P.vertices + 1))
    (hωcap : ω⁻¹ ≤ ((Cω * (P.vertices + 1) ^ c : ℕ) : ℝ)) :
    let n := P.vertices
    let w := (n + 1).log2 + 1
    let C := (2 * k ^ 2) * (c + 3 + (4 * CL * Cω).log2 + 1) + 1
    k1SourceSamples P ω ≤ C * (n + 1) ^ 4 * w := by
  dsimp only
  have hk' : 0 < k := by omega
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk'
  have hN : k1SourceSamples P ω ≤
      parametricSourceSamples (1 / (k : ℝ)) P.vertices (P.span + 1) ω := by
    unfold k1SourceSamples parametricSourceSamples
    rw [he, k1Epsilon]
    apply Nat.add_le_add_right
    apply Nat.ceil_mono
    apply div_le_div_of_nonneg_left (by positivity) (by positivity)
    exact pow_le_pow_left₀ (by positivity)
      ((div_le_div_iff_of_pos_right hkR).2 (by norm_num)) 2
  exact hN.trans (parametricSampleCounts_polynomial k hk' P.vertices_pos hL ω hω hωcap).1

/-- Exponent computed by rational ceiling and natural binary bit counts. -/
def rationalBinaryBudget (x : ℚ) : ℕ := Nat.clog 2 x.ceil.toNat

theorem rationalBinaryBudget_eq (x : ℚ) :
    rationalBinaryBudget x = binaryBudget (x : ℝ) := by
  unfold rationalBinaryBudget binaryBudget
  rw [← Int.ceil_toNat, Rat.ceil_cast]
  have h : ⌈x⌉ = x.ceil := by
    rw [Rat.ceil_eq_neg_floor_neg]
    rfl
  rw [h]

/-- A rational confidence parameter makes the entire K.1 sample
allocation an exact rational-ceiling and integer computation. -/
theorem k1SourceSamples_rational (P : ScheduledSource E V) (k : ℕ) (hk : 8 < k)
    (he : P.epsilon = k1Epsilon k) (ω : ℚ) :
    k1SourceSamples P (ω : ℝ) = (P.vertices ^ 4 *
      rationalBinaryBudget (4 * (P.vertices : ℚ) ^ 2 * (P.span + 1 : ℕ) / ω) * k ^ 2 + 1) / 2 + 1 := by
  rw [k1SourceSamples_integer P k hk he, rationalBinaryBudget_eq, sourceSampleExponent]
  push_cast
  rfl

end

end SubmodularMatching.UpperBoundAssembly
