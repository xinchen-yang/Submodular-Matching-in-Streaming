import SubmodularMatching.StreamingK1Space
import SubmodularMatching.StreamingK1RealTapeSupport
import SubmodularMatching.StreamingOnlineResources
import SubmodularMatching.UpperBoundVertexPeak
import SubmodularMatching.UpperBoundVertexSamplerBudget

/-! # Source workspace and integer widths for arbitrary Appendix K parameters -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming SourceCertificate
open scoped BigOperators

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

variable (R : SourceRateTable) (k : ℕ) (hk : 8 < k)
variable (p : ℚ) (hp : 0 < p) (minimum : ℝ) (hmin : 0 < minimum)
variable (hlow : ∀ i < R.count, minimum ≤ (R.low i : ℝ))
variable (hgrowth : minimum * (p : ℝ) ≤ 1)

/-- The simultaneous archive rows, scratch for one compressed graph, and
the single retained incumbent have a quadratic logarithmic word bound. -/
theorem k1ScheduledSource_workspace_le (edges : ℕ → E) (ends : E → V × V)
    (f : Finset E → ℝ) (n arrivals : ℕ) (hn : 2 ≤ n) (ha : arrivals ≤ n ^ 2)
    (hp1 : (p : ℝ) ≤ 1) (hf : IsSubmodular f) (hm : IsMonotone f) (h0 : f ∅ = 0)
    (initialLength : ℕ) {N : ℕ} (hN : 0 < N) (batches : ℕ → Fin N → ℝ)
    (allEdges M : Finset E)
    (hin : ∀ i < initialLength, edges i ∈ allEdges)
    (hloop : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet ends) A →
      A.card ≤ M.card)
    {m : ℕ} (storedEnds : Fin m → V × V) (current : ℕ) :
    let P := k1ScheduledSource R edges ends f n arrivals k hn ha hk p hp hp1 minimum hmin hlow hgrowth
      hf hm h0
    let hist := P.history batches P.calls.length
    let active := activeGuessIndices P.width (guessAnchor P.width P.value initialLength)
      (singletonMaximum P.value initialLength) P.span
    let len := fun j => (P.snapshot hist initialLength j).stored.card
    let I := k1IncidenceBound R k hk p hp minimum hmin hlow hgrowth
    let L := 3 + k.log2
    let w := (n + 1).log2 + 1
    batches ∈ (sourceRealWordTape P N p).outcomes → current ∈ active → m = len current →
      sequentialWorkspace active len
        (sequentialGuessScratch (Fintype.card (IncidentVertex storedEnds)) m) M.card ≤
        (96 * I * L + 8 * L + 50) * (M.card + 1) * w ^ 2 := by
  intro P hist active len I L w hb hcurrent hlen
  have hw : 1 ≤ w := by dsimp [w]; omega
  have hL : P.span + 1 ≤ L * w := k1GuessSpan_le n k
  have hA : active.card ≤ L * w := by
    by_cases hpos : 0 < singletonMaximum P.value initialLength
    · exact (activeGuessIndices_card_le P.width P.value P.span initialLength P.width_bound hpos).trans hL
    · have hz : singletonMaximum P.value initialLength = 0 :=
        le_antisymm (le_of_not_gt hpos) (singletonMaximum_nonneg _ _)
      have hzero : active = ∅ := by
        dsimp only [active]
        rw [hz, activeGuessIndices_eq_empty_of_zero]
      simp [hzero]
  have hstores : ∑ j ∈ active, len j ≤ 2 * M.card * I * w * (L * w) := by
    rw [show 2 * M.card * I * w * (L * w) = (2 * I * L) * M.card * w ^ 2 by ring]
    exact k1ScheduledSource_totalStored_le R k hk p hp minimum hmin hlow hgrowth
      edges ends f n arrivals hn ha hp1 hf hm h0 initialLength hN hist allEdges M hin hloop
      hMsub hM hmax (fun i _ j r =>
        sourceRealWordTape_history_marginal P N p batches hb _ le_rfl i j r)
  have hs : sequentialGuessScratch (Fintype.card (IncidentVertex storedEnds)) m ≤
      32 * (len current + 1) := hlen ▸ sequentialGuessScratch_le storedEnds
  exact sequentialWorkspace_le active len current hcurrent M.card I L w _ hw hA hstores hs

/-- The potential cap divided by the normalized grid spacing has a
fixed coefficient, independently of the guessed value's magnitude. -/
def k1PotentialIndexConstant : ℕ :=
  let C := k1GuessConfig R 2 k (by decide) hk p hp minimum hmin hlow hgrowth 1
  ⌈(1 + (C.maxRate + 1) * C.p) / (C.p * k1Epsilon k ^ 2)⌉₊

theorem k1GuessConfig_indices (n : ℕ) (hn : 2 ≤ n) (τ : ℝ) (hτ : 0 < τ) :
    let C := k1GuessConfig R n k hn hk p hp minimum hmin hlow hgrowth τ
    C.tau / C.gap = (k : ℝ) * (n : ℝ) ^ 2 / 2 ∧
      C.cap / C.grid ≤ ((k1PotentialIndexConstant R k hk p hp minimum hmin hlow hgrowth * n ^ 4 : ℕ) : ℝ) := by
  intro C
  let C0 := k1GuessConfig R 2 k (by decide) hk p hp minimum hmin hlow hgrowth 1
  have hr : C.maxRate = C0.maxRate := rfl
  have hp' : C.p = C0.p := rfl
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast (show n ≠ 0 by omega)
  have hk' : (k : ℝ) ≠ 0 := by exact_mod_cast (show k ≠ 0 by omega)
  have he := (k1Epsilon_bounds k hk).1
  obtain ⟨ht, _, hd, hg⟩ := k1GuessConfig_spec R n k hn hk p hp minimum hmin hlow hgrowth τ hτ
  constructor
  · rw [ht, hd, k1Epsilon]
    field_simp [hn', hk', hτ.ne']
  · have hg' : C.grid = C.p * k1Epsilon k ^ 2 * τ / (n : ℝ) ^ 4 := hg
    rw [PotentialConfig.cap, hg', ht, hp', hr]
    push_cast
    calc
      _ = (1 + (C0.maxRate + 1) * C0.p) / (C0.p * k1Epsilon k ^ 2) * (n : ℝ) ^ 4 := by
        field_simp [hn', hτ.ne', C0.p_pos.ne', he.ne']
      _ ≤ _ := mul_le_mul_of_nonneg_right (Nat.le_ceil _) (pow_nonneg (Nat.cast_nonneg _) _)

/-- Sparse potential and frozen weight records have logarithmic widths
even if the stream's accuracy event fails. -/
theorem k1OnlineRecordWidths (n : ℕ) (hn : 2 ≤ n) (τ : ℝ) (hτ : 0 < τ)
    (ends : E → V × V) (input : ℕ → E × ℕ) (len : ℕ) (v : V)
    {N : ℕ} (hN : 0 < N) (samples : Fin N → ℝ)
    (hs : ∀ j, 0 ≤ samples j ∧ samples j ≤ τ) :
    let C := k1GuessConfig R n k hn hk p hp minimum hmin hlow hgrowth τ
    let G := k1OnlineGrid R n k p
    let I := k1PotentialIndexConstant R k hk p hp minimum hmin hlow hgrowth
    let w := (n + 1).log2 + 1
    (∀ i < len, C.gap * (input i).2 ≤ C.tau) →
      (indexAt (runOnlineInstance G ends input len).vertices v).log2 + 1 ≤
        (4 + I.log2 + 1) * w ∧
      (sourceWeightIndex N (sourceIndex C.gap samples)).log2 + 1 ≤
        (2 + k.log2 + 1) * w := by
  intro C G I w hin
  have h := k1GuessConfig_indices R k hk p hp minimum hmin hlow hgrowth n hn τ hτ
  have ht : C.tau = τ :=
    (k1GuessConfig_spec R n k hn hk p hp minimum hmin hlow hgrowth τ hτ).1
  obtain ⟨_, _, hd0, _⟩ := k1GuessConfig_spec R n k hn hk p hp minimum hmin hlow hgrowth τ hτ
  have hd : 0 < C.gap := by
    rw [hd0]
    exact div_pos (mul_pos (k1Epsilon_bounds k hk).1 hτ)
      (pow_pos (by exact_mod_cast (show 0 < n by omega)) 2)
  have hG : G.Matches C := k1OnlineGrid_matches R n k hn hk p hp minimum hmin hlow hgrowth τ hτ
  have hpbound := (runOnlineInstance_index_le G C hG hd ends input len hin v).trans h.2
  have hwbound := sourceWeightIndex_le C.gap τ samples hd hN hs
  rw [← ht, h.1] at hwbound
  have hpNat : indexAt (runOnlineInstance G ends input len).vertices v ≤ I * n ^ 4 := by
    exact_mod_cast hpbound
  have hwReal : (sourceWeightIndex N (sourceIndex C.gap samples) : ℝ) ≤
      (k : ℝ) * (n : ℝ) ^ 2 := hwbound.trans (div_le_self (by positivity) (by norm_num))
  have hwNat : sourceWeightIndex N (sourceIndex C.gap samples) ≤ k * n ^ 2 := by
    exact_mod_cast hwReal
  exact ⟨log2_width_of_polynomial (hpNat.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (Nat.le_succ n) _))),
    log2_width_of_polynomial (hwNat.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (Nat.le_succ n) _)))⟩

/-- The estimator's running integer sum has logarithmic width for the
real-oracle model, including all incomplete prefixes of an estimate. -/
theorem k1OnlineAccumulatorWidth (n : ℕ) (hn : 2 ≤ n) (τ : ℝ) (hτ : 0 < τ)
    {N Cn d : ℕ} (hN : N ≤ Cn * (n + 1) ^ d) (samples : Fin N → ℝ)
    (hs : ∀ j, 0 ≤ samples j ∧ samples j ≤ τ) :
    let C := k1GuessConfig R n k hn hk p hp minimum hmin hlow hgrowth τ
    let w := (n + 1).log2 + 1
    (sourceIndex C.gap samples).toNat.log2 + 1 ≤ (d + 2 + (4 * k * Cn).log2 + 1) * w := by
  intro C w
  have h := k1GuessConfig_indices R k hk p hp minimum hmin hlow hgrowth n hn τ hτ
  have ht : C.tau = τ :=
    (k1GuessConfig_spec R n k hn hk p hp minimum hmin hlow hgrowth τ hτ).1
  obtain ⟨_, _, hd0, _⟩ := k1GuessConfig_spec R n k hn hk p hp minimum hmin hlow hgrowth τ hτ
  have hd : 0 < C.gap := by
    rw [hd0]
    exact div_pos (mul_pos (k1Epsilon_bounds k hk).1 hτ)
      (pow_pos (by exact_mod_cast (show 0 < n by omega)) 2)
  obtain ⟨hnonneg, hbound⟩ := sourceAccumulator_interval C.gap τ samples hd hs
  rw [show 4 * τ / C.gap = 4 * (C.tau / C.gap) by rw [ht]; ring, h.1] at hbound
  have hNat : (sourceIndex C.gap samples).toNat ≤ N * (4 * k * n ^ 2) := by
    have hR : (((sourceIndex C.gap samples).toNat : ℕ) : ℝ) ≤ (N : ℝ) * (4 * k * (n : ℝ) ^ 2) := by
      rw [← Int.cast_natCast, Int.toNat_of_nonneg hnonneg]
      have hnn : (0 : ℝ) ≤ (N : ℝ) * (k : ℝ) * (n : ℝ) ^ 2 := by positivity
      linarith only [hbound, hnn]
    exact_mod_cast hR
  apply log2_width_of_polynomial
  calc
    _ ≤ N * (4 * k * n ^ 2) := hNat
    _ ≤ (Cn * (n + 1) ^ d) * (4 * k * (n + 1) ^ 2) :=
      Nat.mul_le_mul hN
        (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (Nat.le_succ n) _))
    _ = (4 * k * Cn) * (n + 1) ^ (d + 2) := by rw [pow_add]; ring

end

end SubmodularMatching.UpperBoundAssembly
