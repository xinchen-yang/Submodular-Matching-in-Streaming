import SubmodularMatching.TwoStageSeparateSupport
import SubmodularMatching.GibbsPositiveSupport

/-!
# The joint probability law on separate supports

The state spaces for the two stages are the matchings of `A` and of `S`,
respectively. Rounding the second transition on its positive support
retains compatibility with the first matching.
-/

namespace SubmodularMatching.TwoStage

open GibbsMatching GibbsSampler
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Calibration of the actual second-stage coordinates on the stored support. -/
noncomputable def separateSecondActivity [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (εA εG : ℝ) (T : Finset E) : E → ℝ :=
  calibratedActivity (pairEnds ends) S (separateAltered ends A S x y εA T) (1-εG/4)

/-- The exact two matching draws, with their separate edge supports. -/
noncomputable def separateTwoStageMass [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (εA εG : ℝ) : Finset E × Finset E → ℝ :=
  jointLaw (Shearer.mass (pairEnds ends) A y)
    (fun T => probability (pairEnds ends) S (separateSecondActivity ends A S x y εA εG T))

theorem separateSecondActivity_nonnegative [Fintype E] [Finite V] (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (A S : Finset E) (x y : E → ℝ) (p D r εA εG : ℝ)
    (hp : 0 ≤ p) (hr0 : 0 < r) (hr1 : r ≤ 1) (hDr : D = r*(1-r))
    (hgap : meanAllowance p D < εA) (hG0 : 0 < εG) (hG1 : εG < 1)
    (hFeas : SeparateFeasible ends A S x y p D) (T : Finset E) (e : E) (he : e ∈ S) :
    0 ≤ separateSecondActivity ends A S x y εA εG T e := by
  have hCorrect := separate_alteration_correct ends hloop hsimple A S x y p D r εA
    hp hr0 hr1 hDr hgap hFeas
  exact calibratedActivity_nonnegative (pairEnds ends) S (separateAltered ends A S x y εA T)
    (fun d _ => (hCorrect.1 T d).1) (hCorrect.2.1 T) (1-εG/4) (by linarith) (by linarith) e he

theorem separateFirstLaw_probability (ends : E → V × V) (A : Finset E) (y : E → ℝ)
    (r : ℝ) (hr0 : 0 < r) (hr1 : r ≤ 1) (hy : ∀ e ∈ A, 0 ≤ y e)
    (hloop : ∀ e ∈ A, (ends e).1 ≠ (ends e).2)
    (hdegree : ∀ v, vertexLoad (pairEnds ends) A y v ≤ r*(1-r)) :
    IsProbability (matchings (pairEnds ends) A) (Shearer.mass (pairEnds ends) A y) := by
  refine ⟨fun T _ => Shearer.mass_nonnegative (pairEnds ends) A y r hr0 hr1 hy ?_ hdegree T,?_⟩
  · intro e he
    simp [pairEnds,Finset.card_pair (hloop e he)]
  · simpa only [Shearer.expectation,mul_one] using Shearer.expectation_const (pairEnds ends) A y 1

theorem separateTwoStageMass_probability [Fintype E] (ends : E → V × V)
    (A S : Finset E) (x y : E → ℝ) (εA εG : ℝ)
    (hFirst : IsProbability (matchings (pairEnds ends) A) (Shearer.mass (pairEnds ends) A y))
    (hactivity : ∀ T ∈ matchings (pairEnds ends) A, ∀ e ∈ S,
      0 ≤ separateSecondActivity ends A S x y εA εG T e) :
    IsProbability ((matchings (pairEnds ends) A) ×ˢ (matchings (pairEnds ends) S))
      (separateTwoStageMass ends A S x y εA εG) := by
  apply jointLaw_probability _ _ _ _ hFirst
  intro T hT
  exact ⟨fun N _ => probability_nonnegative _ _ _ (hactivity T hT) N,
    probability_total _ _ _ (hactivity T hT)⟩

theorem separateTwoStageMass_value [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (εA εG : ℝ) (f : Finset E → ℝ) :
    expected ((matchings (pairEnds ends) A) ×ˢ (matchings (pairEnds ends) S))
      (separateTwoStageMass ends A S x y εA εG) (fun pair => f (pair.1 ∪ pair.2)) =
      separateTwoStageValue ends A S x y εA εG f := by
  unfold expected separateTwoStageMass jointLaw separateTwoStageValue Shearer.expectation
  rw [Finset.sum_product]
  apply Finset.sum_congr rfl
  intro T _
  rw [conditionalValue,expectation_eq_probability_sum,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro N _
  simp only [separateSecondActivity,mul_assoc]

/-- A positive-mass second outcome stays disjoint from the first draw,
including a first outcome with zero mass in the exact first law. -/
theorem separate_supported_union_matching [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (εA εG : ℝ) (T N : Finset E) (bits steps : ℕ)
    (hT : T ∈ matchings (pairEnds ends) A)
    (ha : ∀ e ∈ S, 0 ≤ separateSecondActivity ends A S x y εA εG T e)
    (hN : 0 < supportedGibbsLaw (pairEnds ends) S
      (separateSecondActivity ends A S x y εA εG T) bits steps N) :
    Streaming.IsMatchingOn (pairEnds ends) (T ∪ N) := by
  classical
  let B := pairEnds ends
  let a := separateSecondActivity ends A S x y εA εG T
  let R := positiveEdges S a
  have hNR : N ∈ matchings B R := by
    by_contra h
    simp [supportedGibbsLaw,B,R,a,h] at hN
  apply positive_probability_union_matching B S T N
    (separateAltered ends A S x y εA T) (1-εG/4) ((mem_matchings B A T).mp hT).2
  · intro e _ he
    rw [separateAltered_eq ends A S x y εA] at he
    exact altered_avoids_matching ends (fun M : Finset E => M)
      (compensatedEdge ends (zeroOutside S x) (zeroOutside A y)) εA T e he
  · change 0 < probability B S a N
    rw [← probability_positiveEdges B S a ha]
    change 0 < probability B R a N
    simp only [probability,hNR,↓reduceIte]
    have hm := (mem_matchings B R N).mp hNR
    exact div_pos (Finset.prod_pos (fun e he => (Finset.mem_filter.mp (hm.1 he)).2))
      (partition_positive B R a (fun e he => (Finset.mem_filter.mp he).2.le))

/-- Pair-state variation combines first and conditional binary Gibbs
errors while retaining feasible support on the actual two universes. -/
theorem separate_two_stage_variation [Fintype E] (ends : E → V × V) (A S : Finset E)
    (x y : E → ℝ) (εA εG ε₁ ε₂ : ℝ) (first : Finset E → ℝ)
    (bits steps : Finset E → ℕ)
    (hFirst : IsProbability (matchings (pairEnds ends) A) first)
    (ha : ∀ T ∈ matchings (pairEnds ends) A, ∀ e ∈ S,
      0 ≤ separateSecondActivity ends A S x y εA εG T e)
    (hε₁ : variation (matchings (pairEnds ends) A) (Shearer.mass (pairEnds ends) A y) first ≤ ε₁)
    (hε₂ : ∀ T ∈ matchings (pairEnds ends) A,
      let B := pairEnds ends
      let a := separateSecondActivity ends A S x y εA εG T
      let R := positiveEdges S a
      let states := matchings B R
      variation states (iterateKernel states (roundedTransition B R a (bits T))
        (pointMass ∅) (steps T)) (probability B R a) ≤ ε₂) :
    let B := pairEnds ends
    let states := (matchings B A) ×ˢ (matchings B S)
    let second := fun T => supportedGibbsLaw B S (separateSecondActivity ends A S x y εA εG T)
      (bits T) (steps T)
    IsProbability states (jointLaw first second) ∧
      (∀ pair ∈ states, 0 < jointLaw first second pair → Streaming.IsMatchingOn B (pair.1 ∪ pair.2)) ∧
      variation states (separateTwoStageMass ends A S x y εA εG) (jointLaw first second) ≤ ε₁+ε₂ := by
  dsimp only
  let B := pairEnds ends
  let firstStates := matchings B A
  let secondStates := matchings B S
  let a := separateSecondActivity ends A S x y εA εG
  let second := fun T => supportedGibbsLaw B S (a T) (bits T) (steps T)
  let idealSecond := fun T => probability B S (a T)
  have hSecond (T : Finset E) (_ : T ∈ firstStates) : IsProbability secondStates (second T) :=
    supportedGibbsLaw_probability B S (a T) (bits T) (steps T)
  have hIdealSecond (T : Finset E) (hT : T ∈ firstStates) : IsProbability secondStates (idealSecond T) :=
    ⟨fun N _ => probability_nonnegative _ _ _ (ha T hT) N,probability_total _ _ _ (ha T hT)⟩
  refine ⟨jointLaw_probability firstStates secondStates first second hFirst hSecond,?_,?_⟩
  · intro pair hpair hpos
    have hT := (Finset.mem_product.mp hpair).1
    have hPositive : 0 < second pair.1 pair.2 := by
      by_contra! h
      exact (not_lt_of_ge (mul_nonpos_of_nonneg_of_nonpos (hFirst.nonnegative pair.1 hT) h)) hpos
    exact separate_supported_union_matching ends A S x y εA εG _ _ _ _ hT (ha pair.1 hT) hPositive
  · change variation (firstStates ×ˢ secondStates)
      (jointLaw (Shearer.mass B A y) idealSecond) (jointLaw first second) ≤ ε₁+ε₂
    refine (variation_joint firstStates secondStates _ _ _ _ hFirst hIdealSecond ε₂ ?_).trans
      (add_le_add hε₁ le_rfl)
    intro T hT
    have hEq := supportedGibbsLaw_variation B S (a T) (ha T hT) (bits T) (steps T)
    have hsym : variation secondStates (idealSecond T) (second T) =
        variation secondStates (second T) (idealSecond T) := by
      unfold variation
      simp only [abs_sub_comm (idealSecond T _) (second T _)]
    rw [hsym]
    exact hEq.le.trans (hε₂ T hT)

end SubmodularMatching.TwoStage
