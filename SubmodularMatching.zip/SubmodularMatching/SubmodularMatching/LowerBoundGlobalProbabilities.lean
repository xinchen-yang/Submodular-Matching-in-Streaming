import SubmodularMatching.LowerBoundGlobalInstanceFacts

/-! # Direct probability and expectation statements for the optimum -/

namespace SubmodularMatching.LowerBoundGlobal

open Filter LowerBoundAssembly LowerBoundSoundness
open scoped BigOperators Topology

noncomputable section

variable {p N P t H : ℕ} {C : Type*}
  [Fintype C] [DecidableEq C] [AddCommGroup C] [Nonempty (Fin t)]

omit [Nonempty (Fin t)] in
theorem hardOptimum_nonneg (b : BlueprintExpansion N P t H) (d : HardDraw p N P t C) :
    0 ≤ hardOptimum b d := by
  have he := value_le_hardOptimum b d ∅ (by simp [HardFeasible, HardMatching])
  simpa only [(hardOracle_axioms (H := H) d).1] using he

theorem hardOptimum_probability_and_mean
    (b : BlueprintExpansion N P t H) (qb ql : ℝ)
    (hqb0 : 0 ≤ qb) (hqb1 : qb ≤ 1) (hql0 : 0 ≤ ql) (hql1 : ql ≤ 1)
    (ξ : ℝ) (hM : 0 < hardNormalizer C N H) :
    let mass := hardDrawMass (p := p) (C := C) b qb ql
    let target := (p : ℝ) * (1 - ξ)
    let fail := eventMass mass (fun d => ¬hardComplete b ξ d)
    1 - fail ≤ eventMass mass (fun d => target ≤ hardOptimum b d) ∧
      target * (1 - fail) ≤ ∑ d, mass d * hardOptimum b d := by
  classical
  intro mass target fail
  have hnorm : ∑ d, mass d = 1 := hardDrawMass_total b qb ql hqb0 hqb1 hql0 hql1
  have ht (d : HardDraw p N P t C) (hd : hardComplete b ξ d) :
      target ≤ hardOptimum b d := hardComplete_le_hardOptimum b d ξ hM hd
  constructor
  · calc
      _ = eventMass mass (hardComplete b ξ) := by
        unfold fail eventMass
        rw [← hnorm, ← Finset.sum_sub_distrib]
        apply Finset.sum_congr rfl
        intro d _
        by_cases hd : hardComplete b ξ d <;> simp [hd]
      _ ≤ _ := by
        unfold eventMass
        apply Finset.sum_le_sum
        intro d _
        by_cases hd : hardComplete b ξ d
        · simp [hd, ht d hd]
        · simp only [if_neg hd]
          split_ifs
          · exact hardDrawMass_nonneg b qb ql d
          · exact le_rfl
  · calc
      _ = ∑ d, if hardComplete b ξ d then mass d * target else 0 := by
        unfold fail eventMass
        rw [← hnorm, ← Finset.sum_sub_distrib, Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro d _
        by_cases hd : hardComplete b ξ d <;> simp [hd, mul_comm]
      _ ≤ _ := by
        apply Finset.sum_le_sum
        intro d _
        by_cases hd : hardComplete b ξ d
        · rw [if_pos hd]
          exact mul_le_mul_of_nonneg_left (ht d hd) (hardDrawMass_nonneg b qb ql d)
        · rw [if_neg hd]
          exact mul_nonneg (hardDrawMass_nonneg b qb ql d) (hardOptimum_nonneg b d)

omit [Fintype C] [DecidableEq C] [AddCommGroup C] [Nonempty (Fin t)] in
/-- A sequence of nonnegative recovery errors with vanishing expected
value also vanishes in probability. -/
theorem recovery_error_tends_to_zero_in_probability
    {ι : Type*} {l : Filter ι} {Ω : ι → Type*} [∀ i, Fintype (Ω i)]
    (μ : (i : ι) → Ω i → ℝ) (err : (i : ι) → Ω i → ℝ)
    (hμ : ∀ i w, 0 ≤ μ i w) (herr : ∀ i w, 0 ≤ err i w)
    (hmean : Tendsto (fun i => ∑ w, μ i w * err i w) l (𝓝 0))
    {δ : ℝ} (hδ : 0 < δ) :
    Tendsto (fun i => eventMass (μ i) (fun w => δ ≤ err i w)) l (𝓝 0) := by
  refine squeeze_zero' (.of_forall fun i => ?_) (.of_forall fun i => ?_)
    (by simpa using hmean.div_const δ)
  · unfold eventMass
    exact Finset.sum_nonneg fun w _ => by
      split_ifs
      · exact hμ i w
      · exact le_rfl
  · simpa [eventMass] using event_le_exception_add_markov (μ i) (err i)
      (fun _ => True) (fun w => δ ≤ err i w) δ (hμ i) (herr i) hδ (fun _ _ h => h)

end

end SubmodularMatching.LowerBoundGlobal
