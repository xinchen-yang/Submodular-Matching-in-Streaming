import SubmodularMatching.CertificatePricePartition

/-!
# Midpoint encoding of a price partition

Each split is determined by the current box. The verifier computes the
shared price midpoint and separates successive discrete modes.
-/

namespace SubmodularMatching.SourceCertificate

inductive MidpointPartition (W : Type)
  | leaf (w : W)
  | m (lo hi : MidpointPartition W)
  | x (lo hi : MidpointPartition W)
  | y (lo hi : MidpointPartition W)

def MidpointPartition.expand {W : Type} : MidpointPartition W → PriceBox → PricePartition W
  | .leaf w, _ => .leaf w
  | .m left right, box =>
    let mid := (box.modeLo + box.modeHi) / 2
    .splitMode mid (left.expand {box with modeHi := mid})
      (right.expand {box with modeLo := mid + 1})
  | .x left right, box =>
    let mid := (box.xLo + box.xHi) / 2
    .splitX mid (left.expand {box with xHi := mid})
      (right.expand {box with xLo := mid})
  | .y left right, box =>
    let mid := (box.yLo + box.yHi) / 2
    .splitY mid (left.expand {box with yHi := mid})
      (right.expand {box with yLo := mid})

def MidpointPartition.check {W : Type} (leafCheck : PriceBox → W → Bool)
    (tree : MidpointPartition W) (box : PriceBox) : Bool :=
  (tree.expand box).check leafCheck box

theorem MidpointPartition.sound {W : Type} (leafCheck : PriceBox → W → Bool)
    (modes knots : ℕ) (knot : ℕ → ℝ) (objective : ℕ → ℝ → ℝ → Prop)
    (leafSound : ∀ box w, box.IsValid modes knots → leafCheck box w = true →
      ∀ mode a d, box.Contains knot mode a d → objective mode a d)
    (tree : MidpointPartition W) (box : PriceBox)
    (valid : box.IsValid modes knots) (checked : tree.check leafCheck box = true)
    (mode : ℕ) (a d : ℝ) (hx : box.Contains knot mode a d) :
    objective mode a d :=
  PricePartition.sound leafCheck modes knots knot objective leafSound (tree.expand box)
    box valid checked mode a d hx

/-- Numerator of the multiplier and the two minimizing knot indices. -/
structure BoxMinimumWitness where
  t : ℕ
  ix : ℕ
  iy : ℕ

/-- The proof-side tree root for both endpoints of all 27,648 rate intervals
and the two full 1,136-knot source tables. -/
def appendixPriceRoot : PriceBox := ⟨0, 55295, 0, 1135, 0, 1135⟩

theorem appendixPriceRoot_valid : appendixPriceRoot.IsValid 55296 1135 := by
  norm_num [appendixPriceRoot, PriceBox.IsValid]

end SubmodularMatching.SourceCertificate
