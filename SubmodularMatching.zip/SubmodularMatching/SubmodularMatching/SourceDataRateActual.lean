import SubmodularMatching.SourceDataRateLiteral0
import SubmodularMatching.SourceDataRateLiteral1
import SubmodularMatching.SourceDataRateLiteral2

/-!
# The actual source rate table

The three literal blocks contain the 27,648 rate pairs. Their checks use the
next block's first boundary and the last block ends at ratio one.
-/

namespace SubmodularMatching.SourceCertificate

open Streaming

set_option maxRecDepth 65536

def appendixRateRows : List RawSourceMode :=
  sourceRateBlock0 ++ sourceRateBlock1 ++ sourceRateBlock2

theorem appendixRateRows_length : appendixRateRows.length = 27648 := by
  rw [appendixRateRows, sourceRateBlock0, sourceRateBlock1, sourceRateBlock2]
  simp only [List.length_append]
  have len0 : sourceRates00000.length = 1024 := rfl
  have len1 : sourceRates01024.length = 1024 := rfl
  have len2 : sourceRates02048.length = 1024 := rfl
  have len3 : sourceRates03072.length = 1024 := rfl
  have len4 : sourceRates04096.length = 1024 := rfl
  have len5 : sourceRates05120.length = 1024 := rfl
  have len6 : sourceRates06144.length = 1024 := rfl
  have len7 : sourceRates07168.length = 1024 := rfl
  have len8 : sourceRates08192.length = 1024 := rfl
  have len9 : sourceRates09216.length = 1024 := rfl
  have len10 : sourceRates10240.length = 1024 := rfl
  have len11 : sourceRates11264.length = 1024 := rfl
  have len12 : sourceRates12288.length = 1024 := rfl
  have len13 : sourceRates13312.length = 1024 := rfl
  have len14 : sourceRates14336.length = 1024 := rfl
  have len15 : sourceRates15360.length = 1024 := rfl
  have len16 : sourceRates16384.length = 1024 := rfl
  have len17 : sourceRates17408.length = 1024 := rfl
  have len18 : sourceRates18432.length = 1024 := rfl
  have len19 : sourceRates19456.length = 1024 := rfl
  have len20 : sourceRates20480.length = 1024 := rfl
  have len21 : sourceRates21504.length = 1024 := rfl
  have len22 : sourceRates22528.length = 1024 := rfl
  have len23 : sourceRates23552.length = 1024 := rfl
  have len24 : sourceRates24576.length = 1024 := rfl
  have len25 : sourceRates25600.length = 1024 := rfl
  have len26 : sourceRates26624.length = 1024 := rfl
  norm_num only [len0, len1, len2, len3, len4, len5, len6, len7, len8,
    len9, len10, len11, len12, len13, len14, len15, len16, len17,
    len18, len19, len20, len21, len22, len23, len24, len25, len26]

theorem appendixRateRows_valid :
    checkRawModes sourceScale 1956743857272 appendixRateRows true = true := by
  unfold appendixRateRows
  simp only [checkRawModes_append]
  change (checkRawModes 802691061482 1956743857272 sourceRateBlock0 true &&
    checkRawModes 922044254567 1956743857272 sourceRateBlock1 false &&
    checkRawModes 1000000000000 1956743857272 sourceRateBlock2 false) = true
  simp only [sourceRateBlock0_accepted, sourceRateBlock1_accepted, sourceRateBlock2_accepted,
    Bool.true_and]

def appendixRateTable : SourceRateTable :=
  SourceRateTable.ofRows appendixRateRows 1956743857272
    (by rw [appendixRateRows_length]; decide) (by rfl) appendixRateRows_valid

theorem appendixRateTable_count : appendixRateTable.count = 27648 := appendixRateRows_length

theorem appendixRateTable_maxTotal :
    appendixRateTable.maxTotal = SourceRateTable.appendixCmax := by
  change (1956743857272 : ℚ) / sourceScale = 244592982159 / 125000000000
  norm_num [sourceScale]

end SubmodularMatching.SourceCertificate
