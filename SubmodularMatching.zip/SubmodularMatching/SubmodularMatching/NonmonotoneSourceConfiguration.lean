import SubmodularMatching.NonmonotoneSourceComparator
import SubmodularMatching.AppendixMNumericalEnvelope
import SubmodularMatching.SourceDataConfig

/-! Map the real local inequality (26) to the actual streaming update
and the two distinct coefficients of (25). -/

namespace SubmodularMatching.AppendixM
open SourceCertificate MeasureTheory Set Streaming
noncomputable section

def gainCoeff : ℝ := alpha + 1/1000000

theorem gainCoeff_pos : 0 < gainCoeff := by
  unfold gainCoeff
  linarith [limiting_factor.2.2.1]

theorem vertex_coeff_bounds (i : Bool) : 1/2 < vertexCoeff i ∧ vertexCoeff i ≤ 1 := by
  rw [vertexCoeff_formula]
  cases i <;> norm_num [layerOne, degree, bit]

theorem edge_coeff_bounds (i j : Bool) : 0 < edgeCoeff i j ∧ edgeCoeff i j ≤ 1 := by
  rw [edgeCoeff_formula]
  cases i <;> cases j <;> norm_num [layerOne, degree, bit]

def sourceShape : Asymmetric.Shape where
  vertex := vertexCoeff
  edge := edgeCoeff
  flag := fun i => (beta / gainCoeff) * unmatched i
  vertex_nonneg := fun i => (by norm_num : (0:ℝ) ≤ 1/2).trans (vertex_coeff_bounds i).1.le
  edge_nonneg := fun i j => (edge_coeff_bounds i j).1.le
  symmetric := fun i j => by rw [edgeCoeff_formula, edgeCoeff_formula j i, add_comm (bit i) (bit j)]

theorem flag_weight (i : Bool) : gainCoeff * sourceShape.flag i = beta * unmatched i := by
  change gainCoeff * ((beta / gainCoeff) * unmatched i) = _
  field_simp [gainCoeff_pos.ne']

theorem source_conditions_of_equation26 (R : SourceRateTable) (C : PotentialConfig)
    (hb : C.base = R.stage 0) (hs : C.stages = R.stages)
    (hbudget : ∀ i, (∫ a in Ioi (0:ℝ), profile.value i a / a^2) ≤ 1/(1 + C.p * R.maxTotal))
    (h26 : ∀ m < R.count, ∀ i j c, (R.boundary m : ℝ) ≤ c → c ≤ (R.boundary (m+1) : ℝ) →
      ∀ a d, 0 ≤ a → 0 ≤ d →
        localTarget i j (R.high m) (R.low m) ≤ localValue i j (R.high m) (R.low m) c a d) :
    Asymmetric.RunSourceConditions profile.sourceFunction C sourceShape gainCoeff R.maxTotal := by
  refine ⟨by exact_mod_cast R.maxTotal_nonnegative, ?_, hbudget⟩
  intro i j
  have ht (m : ℕ) : gainCoeff * (1 + sourceShape.flag i * (R.high m : ℝ) +
      sourceShape.flag j * (R.low m : ℝ)) = localTarget i j (R.high m) (R.low m) := by
    rw [mul_add, mul_add, mul_one, ← mul_assoc, flag_weight, ← mul_assoc, flag_weight]
    unfold gainCoeff localTarget
    ring
  have hlocal (m : ℕ) (hm : m < R.count) :
      RateLocal (profile.sourceFunction i) (profile.sourceFunction j) (sourceShape.vertex i)
        (sourceShape.vertex j) (sourceShape.edge i j) gainCoeff (sourceShape.flag i)
        (sourceShape.flag j) (R.stage m) (R.boundary m) (R.boundary (m+1)) := by
    intro a d ha hd
    have hbound : (R.boundary m : ℝ) ≤ (R.boundary (m+1) : ℝ) := by
      exact_mod_cast R.ordered_boundaries m hm
    have atc (c : ℝ) (hlo : (R.boundary m : ℝ) ≤ c) (hhi : c ≤ (R.boundary (m+1) : ℝ)) :=
      h26 m hm i j c hlo hhi a d ha hd
    change gainCoeff * (1 + sourceShape.flag i * ↑(R.high m) + sourceShape.flag j * ↑(R.low m)) ≤ _ ∧
      gainCoeff * (1 + sourceShape.flag i * ↑(R.high m) + sourceShape.flag j * ↑(R.low m)) ≤ _
    rw [ht]
    exact ⟨atc _ le_rfl hbound, atc _ hbound le_rfl⟩
  rw [hb, hs, SourceRateTable.stages, ← Rat.cast_one, ← R.end_boundary,
    ← Nat.sub_add_cancel R.positive_count]
  convert R.mode_chain _ _ _ _ _ _ hlocal (R.count-1) (Nat.sub_lt R.positive_count Nat.one_pos) using 1

end
end SubmodularMatching.AppendixM
