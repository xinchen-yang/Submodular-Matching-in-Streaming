import SubmodularMatching.NonmonotoneOptimizerMarginals
import Mathlib.Tactic.FieldSimp

/-! The two coordinate chains for inequality (27) in Appendix M.3. -/

namespace SubmodularMatching.NonmonotoneOptimizer

open scoped BigOperators

noncomputable section

variable {E : Type*} [DecidableEq E]

def action (c u : ℝ) : ℝ := u / (c + u)

def weight (c u : ℝ) : ℝ := u * (1 - u) / c

def chain (a start : ℕ → ℝ) (k i : ℕ) : ℝ := if i < k then a i else start i

def payoff (a lower upper : ℝ) : ℝ := (1 - a) * lower + a * upper

theorem action_bounds {c u : ℝ} (hc : 0 < c) (hu : 0 ≤ u) :
    0 ≤ action c u ∧ action c u ≤ 1 := by
  have hd : 0 < c + u := by linarith
  exact ⟨div_nonneg hu hd.le, (div_le_one hd).2 (by linarith)⟩

theorem weight_bounds {c u : ℝ} (hc : 0 < c) (hu : 0 ≤ u) (hu1 : u ≤ 1) :
    0 ≤ weight c u ∧ weight c u ≤ 1 / (4 * c) := by
  constructor
  · exact div_nonneg (mul_nonneg hu (sub_nonneg.mpr hu1)) hc.le
  · unfold weight
    rw [div_le_div_iff₀ hc (by linarith : 0 < 4 * c)]
    have h : u * (1 - u) * 4 ≤ 1 := by nlinarith [sq_nonneg (2 * u - 1)]
    nlinarith only [mul_nonneg (sub_nonneg.mpr h) hc.le]

theorem weighted_chain_sum (U w : ℕ → ℝ) (n : ℕ) (K : ℝ)
    (hU : ∀ i ≤ n, 0 ≤ U i) (hK : 0 ≤ K)
    (hw : ∀ i < n, 0 ≤ w i ∧ w i ≤ K)
    (hsorted : ∀ i < n, ∀ j < n, i ≤ j → w i ≤ w j) :
    ∑ i ∈ Finset.range n, w i * (U (i + 1) - U i) ≤ K * U n := by
  induction n generalizing K with
  | zero =>
    simpa using mul_nonneg hK (hU 0 le_rfl)
  | succ n ih =>
    have hn := hw n (Nat.lt_succ_self n)
    have hp := ih (w n) (fun i hi => hU i (Nat.le_succ_of_le hi)) hn.1
      (fun i hi => ⟨(hw i (Nat.lt_succ_of_lt hi)).1,
        hsorted i (Nat.lt_succ_of_lt hi) n (Nat.lt_succ_self n) hi.le⟩)
      (fun i hi j hj => hsorted i (Nat.lt_succ_of_lt hi) j (Nat.lt_succ_of_lt hj))
    rw [Finset.sum_range_succ]
    have hb := mul_le_mul_of_nonneg_right hn.2 (hU (n+1) le_rfl)
    linarith

private theorem chain_succ (a start : ℕ → ℝ) (k : ℕ) :
    chain a start (k+1) = Function.update (chain a start k) k (a k) := by
  funext i
  by_cases he : i = k
  · subst i
    simp [chain]
  · by_cases hi : i < k
    · simp [chain, hi, Nat.lt_succ_of_lt hi, Function.update_of_ne he]
    · have hn : ¬ i < k + 1 := by omega
      simp [chain, hi, hn, Function.update_of_ne he]

private theorem chain_step (edges : ℕ → E) (f : Finset E → ℝ) (a start : ℕ → ℝ)
    (n k : ℕ) (hk : k < n) :
    bernoulliExpectation edges (chain a start (k+1)) f n -
      bernoulliExpectation edges (chain a start k) f n =
        (a k - start k) * slope edges (chain a start k) f n k := by
  rw [chain_succ, expectation_update edges _ f n k hk]
  simp [chain]

private theorem scalar_step {c u o A D C : ℝ} (hc : 0 < c) (hu : 0 ≤ u)
    (ho : 0 ≤ o) (ho1 : o ≤ 1) (hDA : D ≤ A) (hCD : C ≤ D) :
    let a := action c u
    (o - a) * D ≤ payoff a A C * (o - u) + c * (a * A) +
      weight c u * ((a - 1) * C) := by
  intro a
  have ha : 0 ≤ a ∧ a ≤ 1 := action_bounds hc hu
  have hd : c + u ≠ 0 := ne_of_gt (by linarith)
  have h₁ : (1 - a) * u = c * a := by
    change (1 - u / (c+u)) * u = c * (u / (c+u))
    field_simp
    ring
  have h₂ : a * (1-u) = weight c u * (1-a) := by
    change u / (c+u) * (1-u) = (u * (1-u) / c) * (1 - u / (c+u))
    field_simp [hc.ne']
    ring
  calc
    (o - a) * D = (1-a)*o*D - a*(1-o)*D := by ring
    _ ≤ (1-a)*o*A - a*(1-o)*C :=
      sub_le_sub (mul_le_mul_of_nonneg_left hDA (mul_nonneg (sub_nonneg.mpr ha.2) ho))
        (mul_le_mul_of_nonneg_left hCD (mul_nonneg ha.1 (sub_nonneg.mpr ho1)))
    _ = _ := by
      unfold payoff
      linear_combination A * h₁ - C * h₂

private theorem telescope (F : ℕ → ℝ) (n : ℕ) :
    ∑ i ∈ Finset.range n, (F (i+1) - F i) = F n - F 0 := by
  induction n with
  | zero => simp
  | succ n ih => rw [Finset.sum_range_succ, ih]; ring

/-- Equation (27), for an enumeration in increasing order of the manuscript weights.
The three chains and their marginal queries are formed from the original objective. -/
theorem multilinear_chain_comparison (edges : ℕ → E) (n : ℕ)
    (huniq : ∀ i < n, ∀ j < n, edges i = edges j → i = j)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hnon : ∀ A, 0 ≤ f A)
    (c : ℝ) (hc : 0 < c) (u o : ℕ → ℝ)
    (hu : ∀ i < n, 0 ≤ u i ∧ u i ≤ 1) (ho : ∀ i < n, 0 ≤ o i ∧ o i ≤ 1)
    (hsorted : ∀ i < n, ∀ j < n, i ≤ j → weight c (u i) ≤ weight c (u j)) :
    let a := fun i => action c (u i)
    let A := fun i => slope edges (chain a (fun _ => 0) i) f n i
    let C := fun i => slope edges (chain a (fun _ => 1) i) f n i
    bernoulliExpectation edges o f n + c * f ∅ ≤
      (1 + c + 1 / (4 * c)) * bernoulliExpectation edges a f n +
        ∑ i ∈ Finset.range n, payoff (a i) (A i) (C i) * (o i - u i) := by
  intro a A C
  let H := fun q => bernoulliExpectation edges q f n
  let L := fun k => H (chain a (fun _ => 0) k)
  let U := fun k => H (chain a (fun _ => 1) k)
  let V := fun k => H (chain a o k)
  let w := fun k => weight c (u k)
  let q := fun k => payoff (a k) (A k) (C k) * (o k - u k)
  have ha (i : ℕ) (hi : i < n) : 0 ≤ a i ∧ a i ≤ 1 := action_bounds hc (hu i hi).1
  have hstep (i : ℕ) (hi : i < n) : V i - V (i+1) ≤ q i + c * (L (i+1) - L i) +
      w i * (U (i+1) - U i) := by
    let D := slope edges (chain a o i) f n i
    have hDA : D ≤ A i := by
      apply slope_antitone _ _ _ hi huniq _ _ _ hf
      intro j hj
      by_cases hji : j < i
      · simpa [chain, hji] using ha j hj
      · simpa [chain, hji] using ho j hj
    have hCD : C i ≤ D := by
      apply slope_antitone _ _ _ hi huniq _ _ _ hf
      intro j hj
      by_cases hji : j < i
      · simpa [chain, hji] using ha j hj
      · simpa [chain, hji] using ho j hj
    have hv : V (i+1) - V i = (a i - o i) * D := chain_step _ _ _ _ _ _ hi
    have hl : L (i+1) - L i = a i * A i := by
      simpa only [sub_zero] using chain_step edges f a (fun _ => 0) n i hi
    have hr : U (i+1) - U i = (a i - 1) * C i := chain_step _ _ _ _ _ _ hi
    rw [hl, hr, show V i - V (i+1) = (o i - a i) * D by linarith only [hv]]
    exact scalar_step hc (hu i hi).1 (ho i hi).1 (ho i hi).2 hDA hCD
  have hU (i : ℕ) (_hi : i ≤ n) : 0 ≤ U i := by
    apply bernoulliExpectation_nonnegative _ _ _ _ _ hnon
    intro j hj
    by_cases hji : j < i
    · simpa [chain, hji] using ha j hj
    · simp [chain, hji]
  have hw := weighted_chain_sum U w n (1 / (4*c)) hU (by positivity)
    (fun i hi => weight_bounds hc (hu i hi).1 (hu i hi).2) hsorted
  have hs := Finset.sum_le_sum (s := Finset.range n) (fun i hi => hstep i (Finset.mem_range.mp hi))
  have hvsum : ∑ i ∈ Finset.range n, (V i - V (i+1)) = V 0 - V n := by
    calc
      _ = -(∑ i ∈ Finset.range n, (V (i+1) - V i)) := by
        rw [← Finset.sum_neg_distrib]
        exact Finset.sum_congr rfl (fun i _ => by ring)
      _ = _ := by rw [telescope]; ring
  have hsum : V 0 - V n ≤ (∑ i ∈ Finset.range n, q i) + c * (L n - L 0) +
      ∑ i ∈ Finset.range n, w i * (U (i+1) - U i) := by
    simpa only [hvsum, Finset.sum_add_distrib, ← Finset.mul_sum, telescope] using hs
  have hend (z : ℕ → ℝ) : H (chain a z n) = H a :=
    expectation_congr _ _ _ _ _ (fun i hi => by simp [chain, hi])
  have hzero (m : ℕ) (g : Finset E → ℝ) :
      bernoulliExpectation edges (fun _ => 0) g m = g ∅ := by
    induction m with
    | zero => rfl
    | succ m ih => simp only [bernoulliExpectation_succ, sub_zero, one_mul, zero_mul, add_zero, ih]
  have hV0 : V 0 = H o := by
    apply congrArg H
    funext i
    simp [chain]
  have hL0 : L 0 = f ∅ := by simpa [L, H, chain] using hzero n f
  have hV : V n = H a := hend o
  have hL : L n = H a := hend _
  have hU' : U n = H a := hend _
  rw [hV0, hV, hL, hL0] at hsum
  rw [hU'] at hw
  change H o + c * f ∅ ≤ (1 + c + 1 / (4*c)) * H a + ∑ i ∈ Finset.range n, q i
  linarith

end

end SubmodularMatching.NonmonotoneOptimizer
