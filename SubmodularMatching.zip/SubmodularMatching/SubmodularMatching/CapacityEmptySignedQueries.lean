import SubmodularMatching.CapacityPublicQueryWork

/-! Degenerate inputs for the same public query theorem. A stream consisting
entirely of rejected capacity tests consumes no singleton queries. -/
namespace SubmodularMatching.AppendixM
open Capacity Capacity.RealOracle UpperBoundAssembly Streaming GibbsSampler
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

theorem countedSignedArrivalBank_no_admissible (S : SimpleEdgeStream E V) (b : V → ℕ)
    (f : Finset E → ℝ) (δ : ℝ) (xs : List E)
    (he : ¬ Nonempty (Admissible S b)) (z : CountedSourceState (Admissible S b) V (effectiveCapacity b))
    (hz : z ∈ (countedSignedArrivalBank S b f δ xs).outcomes) :
    z.2=1 ∧ z.1.1.states.length ≤ guessSpan ((Fintype.card V)^2)+1 := by
  classical
  have hh : xs.filterMap (keepPositive S.ends (clipped b))=[] :=
    List.eq_nil_iff_forall_not_mem.mpr (fun e _ => he ⟨e⟩)
  unfold countedSignedArrivalBank at hz
  rw [CandidateLaw.onFilteredArrivals_eq,hh,CandidateLaw.onArrivals] at hz
  change z ∈ ({_} : Finset (CountedSourceState (Admissible S b) V (effectiveCapacity b))) at hz
  obtain rfl := Finset.mem_singleton.mp hz
  exact ⟨rfl,RealOracle.GuessBank.state_count _ _ _ _ _ _⟩

end
end SubmodularMatching.AppendixM

namespace SubmodularMatching.Capacity
open AppendixM RealOracle UpperBoundAssembly Streaming Streaming.OracleQuery GibbsSampler
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

theorem nonmonotone_query_budget (S : SimpleEdgeStream E V) (b : V → ℕ)
    (f : Finset E → ℝ) (c : ℝ) (amp : Bool)
    (z : Finset E × ℕ) (hz : z∈(nonmonotoneQueryBudgeted S b f c amp).outcomes) :
    z.2≤paperPublicQueryBudget (Fintype.card V) c := by
  classical
  by_cases h : Nonempty (Admissible S b)
  · exact nonmonotoneQueryBudgeted_bound S b f c amp (Classical.choice h) z hz
  · let n := Fintype.card V
    let v := n^2
    let δ := confidenceTarget n c
    let F := fun a => f (originalLabels S b a)
    let R := max 1 (⌈1/trialSuccess⌉₊*(Nat.clog 2 (max 1 n)*⌈c⌉₊+1))
    let G := signedGuessCountConstant*(v+2)
    let J := sourceFailureBudget δ
    let Jmax := 2000000000+2*(max 1 n)^⌈c⌉₊
    unfold nonmonotoneQueryBudgeted at hz
    obtain ⟨s,hs,hzmap⟩ := (CandidateLaw.mem_bind _ _ _).mp hz
    obtain ⟨q,hq,rfl⟩ := Finset.mem_image.mp hzmap
    have hc := countedSignedArrivalBank_no_admissible S b f δ S.arrivals h s hs
    have exactCost := countedAfterSignedPass_work F δ amp (paperRounding S b f) s.1 q hq
    have hg : s.1.1.states.length ≤ G := hc.2.trans
      ((signedGuessCount_le v).trans (Nat.mul_le_mul_left _ (Nat.succ_le_succ (Nat.log2_le_self _))))
    have hR : (if amp then postprocessCount δ else 1)≤R := by
      split <;> first | exact (postprocessCount_logarithmic n c).trans (le_max_right ..) | exact le_max_left ..
    have hJ : J≤Jmax := sourceFailureBudget_polynomial n c
    have hw : paperOracleWork n J≤paperOracleWork n Jmax := by dsimp [paperOracleWork]; gcongr
    have hT := exactCost.1.trans (Nat.mul_le_mul hR hg)
    have hC := exactCost.2.trans (Nat.mul_le_mul hR (Nat.succ_le_succ hg))
    change s.2+q.2.trials*paperOracleWork n J+2*q.2.comparisons ≤ paperPublicQueryBudget n c
    rw [hc.1]
    dsimp only [paperPublicQueryBudget]
    exact Nat.add_le_add
      (Nat.add_le_add (Nat.le_add_right 1 _) (Nat.mul_le_mul hT hw))
      (Nat.mul_le_mul_left _ hC)

end
end SubmodularMatching.Capacity
