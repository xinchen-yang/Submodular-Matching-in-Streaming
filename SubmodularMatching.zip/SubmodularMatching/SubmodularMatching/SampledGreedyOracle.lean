import SubmodularMatching.SampledGreedy
import SubmodularMatching.ResidualObjective
import SubmodularMatching.StreamingEstimator

/-!
# The value queries that estimate the distorted gradient

The residual derivative is the mean of the difference of two value calls on
the union of two independent Bernoulli samples, with the differentiated
coordinate omitted in the second sample. The executable formula uses only
those two calls per sample. The expectation identity is finite.
-/

open scoped BigOperators

namespace SubmodularMatching.Multilinear

noncomputable section

variable {E : Type*} [DecidableEq E]

/-- Omit one Bernoulli decision. -/
def omitCoordinate (q : ℕ → ℝ) (k i : ℕ) : ℝ := if i = k then 0 else q i

private theorem expectation_congr_probabilities (edges : ℕ → E) (q r : ℕ → ℝ)
    (F : Finset E → ℝ) (n : ℕ) (h : ∀ i < n, q i = r i) :
    bernoulliExpectation edges q F n = bernoulliExpectation edges r F n := by
  induction n generalizing F with
  | zero => rfl
  | succ n ih =>
    simp only [bernoulliExpectation_succ, h n (Nat.lt_succ_self n),
      ih _ (fun i hi => h i (Nat.lt_succ_of_lt hi))]

/-- A partial derivative samples every position except its own, then takes
the marginal of its edge against that sample. -/
theorem coordinateDerivative_eq_expected_marginal (edges : ℕ → E) (q : ℕ → ℝ)
    (F : Finset E → ℝ) (n k : ℕ) (hk : k < n) :
    coordinateDerivative edges q F n k =
      bernoulliExpectation edges (omitCoordinate q k) (marginal F (edges k)) n := by
  induction n generalizing F with
  | zero => omega
  | succ n ih =>
    rcases eq_or_lt_of_le (Nat.le_of_lt_succ hk) with heq | hlt
    · subst k
      have hz (G : Finset E → ℝ) : first edges q (basis n) G n = 0 := by
        rw [first_congr_direction edges q (basis n) (fun _ => 0) G n
          (fun i hi => by simp [basis, ne_of_lt hi]), first_zero_direction]
      have he (H : Finset E → ℝ) :
          bernoulliExpectation edges (omitCoordinate q n) H n =
            bernoulliExpectation edges q H n :=
        expectation_congr_probabilities edges _ _ H n (fun i hi => by
          simp [omitCoordinate, ne_of_lt hi])
      rw [coordinateDerivative, first, hz, hz]
      simp only [basis, if_true, mul_zero, add_zero, zero_add, one_mul]
      rw [bernoulliExpectation_succ, show omitCoordinate q n n = 0 by simp [omitCoordinate]]
      simp only [sub_zero, one_mul, zero_mul, add_zero, he]
      change _ = bernoulliExpectation edges q (fun A => F (A ∪ {edges n}) - F A) n
      rw [bernoulliExpectation_sub]
    · rw [coordinateDerivative, first, bernoulliExpectation_succ]
      simp only [basis, ne_of_gt hlt, ↓reduceIte, zero_mul, add_zero,
        omitCoordinate]
      rw [← coordinateDerivative, ← coordinateDerivative, ih F hlt,
        ih (fun A => F (A ∪ {edges n})) hlt]
      have hshift : marginal (fun A => F (A ∪ {edges n})) (edges k) =
          fun A => marginal F (edges k) (A ∪ {edges n}) :=
        funext (marginal_shift F (edges k) (edges n))
      rw [hshift]

/-- The two oracle calls for a single gradient sample. -/
def derivativeSample (f : Finset E → ℝ) (e : E) (R Z : Finset E) : ℝ :=
  marginal f e (Z ∪ R)

/-- Evaluating a residual derivative only requires two oracle calls per
sample. The outer recursion is the draw of `Z`, and the inner recursion
is an independent draw of `R`. -/
theorem residualDerivative_eq_expected_sample (edges : ℕ → E) (p : ℝ) (q : ℕ → ℝ)
    (f : Finset E → ℝ) (n k : ℕ) (hk : k < n) :
    coordinateDerivative edges q (residualValue edges p f n) n k =
      bernoulliExpectation edges (omitCoordinate q k)
        (fun Z => bernoulliExpectation edges (fun _ => p)
          (fun R => derivativeSample f (edges k) R Z) n) n := by
  rw [coordinateDerivative_eq_expected_marginal _ _ _ _ _ hk]
  congr 1
  funext Z
  simp only [marginal, residualValue, ← bernoulliExpectation_sub, derivativeSample]
  congr 1
  funext R
  simp [Finset.union_left_comm, Finset.union_comm]

end

end SubmodularMatching.Multilinear

namespace SubmodularMatching.Joint

noncomputable section

/-- The integer recurrence that avoids storing exact powers of the discount. -/
def discountIndex (base : ℝ) (Q : ℕ) : ℕ → ℤ
  | 0 => Q
  | k + 1 => ⌊base * (discountIndex base Q k : ℝ)⌋

theorem discountIndex_bounds (base : ℝ) (Q k : ℕ)
    (hbase : 0 ≤ base) (hbase1 : base ≤ 1) :
    0 ≤ (discountIndex base Q k : ℝ) ∧
      (discountIndex base Q k : ℝ) ≤ (Q : ℝ) * base ^ k ∧
      (Q : ℝ) * base ^ k - (discountIndex base Q k : ℝ) ≤ k := by
  induction k with
  | zero => simp [discountIndex]
  | succ k ih =>
    constructor
    · exact_mod_cast Int.floor_nonneg.mpr (mul_nonneg hbase ih.1)
    · constructor
      · simp only [discountIndex, pow_succ]
        exact (Int.floor_le _).trans (by
          simpa only [mul_left_comm, mul_comm, mul_assoc] using
            mul_le_mul_of_nonneg_left ih.2.1 hbase)
      · have hloss := Int.lt_floor_add_one (base * (discountIndex base Q k : ℝ))
        have hk := mul_le_mul_of_nonneg_left ih.2.2 hbase
        have hb : base * (k : ℝ) ≤ k := by
          simpa only [one_mul] using
            mul_le_mul_of_nonneg_right hbase1 (Nat.cast_nonneg k : (0 : ℝ) ≤ k)
        simp only [Nat.cast_succ, discountIndex, pow_succ]
        linarith

/-- Discount used at stage `j`, with indices bounded by `Q`. -/
def roundedWeight (D : ℝ) (K j Q : ℕ) : ℝ :=
  (discountIndex (1 - D / K) Q (K - j) : ℝ) / Q

theorem roundedWeight_bounds (D : ℝ) (K j Q : ℕ) (hD : 0 ≤ D) (hDK : D ≤ K)
    (hK : 0 < K) (hQ : 0 < Q) :
    0 ≤ roundedWeight D K j Q ∧
      roundedWeight D K j Q ≤ FiniteGreedy.weight D K j ∧
      FiniteGreedy.weight D K j - roundedWeight D K j Q ≤ ((K - j : ℕ) : ℝ) / Q := by
  have hk : (0 : ℝ) < K := by exact_mod_cast hK
  have hq : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hs := discountIndex_bounds (1 - D / K) Q (K - j)
    (sub_nonneg.mpr ((div_le_one hk).mpr hDK))
    (sub_le_self _ (div_nonneg hD hk.le))
  refine ⟨div_nonneg hs.1 hq.le, (div_le_iff₀ hq).mpr ?_, ?_⟩
  · simpa only [FiniteGreedy.weight, mul_comm] using hs.2.1
  · unfold roundedWeight FiniteGreedy.weight
    rw [sub_div' hq.ne']
    apply (div_le_div_iff_of_pos_right hq).mpr
    simpa only [mul_comm] using hs.2.2

variable {m N : ℕ}

/-- The actual stage coefficient formed by quantizing and averaging two-call
samples, then multiplying by the rounded time-dependent weight. `draw`
provides the two thresholded subsets at the actual current point. -/
def oracleCoefficient (D tau epsilon : ℝ) (Q : ℕ) (f : Finset (Fin m) → ℝ)
    (draw : ℕ → (Fin m ⊕ Fin m → ℝ) → Fin m → Fin N → Finset (Fin m) × Finset (Fin m))
    (j : ℕ) (t : Fin m ⊕ Fin m → ℝ) (e : Fin m) : ℝ :=
  roundedWeight D (FiniteGreedy.stages D m epsilon) (j + 1) Q *
    Streaming.sourceAverage (FiniteGreedy.accuracy D m epsilon * tau / 2)
      (fun sample => Multilinear.derivativeSample f e (draw j t e sample).1 (draw j t e sample).2)

/-- The two allowances of half the coefficient precision imply the accuracy
event needed by the finite greedy theorem. -/
theorem oracleCoefficient_accuracy (D tau epsilon : ℝ) (Q : ℕ)
    (f : Finset (Fin m) → ℝ)
    (draw : ℕ → (Fin m ⊕ Fin m → ℝ) → Fin m → Fin N → Finset (Fin m) × Finset (Fin m))
    (j : ℕ) (t : Fin m ⊕ Fin m → ℝ) (e : Fin m) (gradient : ℝ)
    (hD : 0 ≤ D) (hD1 : D ≤ 1) (hQ : 0 < Q) (hgradient : 0 ≤ gradient ∧ gradient ≤ tau)
    (hgrid : (FiniteGreedy.stages D m epsilon : ℝ) / Q ≤ FiniteGreedy.accuracy D m epsilon / 2)
    (hmean : |Streaming.sourceAverage (FiniteGreedy.accuracy D m epsilon * tau / 2)
      (fun sample => Multilinear.derivativeSample f e (draw j t e sample).1
        (draw j t e sample).2) - gradient| ≤ FiniteGreedy.accuracy D m epsilon * tau / 2) :
    |oracleCoefficient D tau epsilon Q f draw j t e -
      FiniteGreedy.weight D (FiniteGreedy.stages D m epsilon) (j + 1) * gradient| ≤
      FiniteGreedy.accuracy D m epsilon * tau := by
  let K := FiniteGreedy.stages D m epsilon
  let ξ := FiniteGreedy.accuracy D m epsilon
  let a := FiniteGreedy.weight D K (j + 1)
  let b := roundedWeight D K (j + 1) Q
  let s := Streaming.sourceAverage (ξ * tau / 2)
    (fun sample => Multilinear.derivativeSample f e (draw j t e sample).1 (draw j t e sample).2)
  have hK := FiniteGreedy.stages_positive D m epsilon
  have hDK : D ≤ (K : ℝ) := hD1.trans (by exact_mod_cast hK)
  have hb := roundedWeight_bounds D K (j + 1) Q hD hDK hK hQ
  have ha := FiniteGreedy.weight_bounds (j := j + 1) hD hDK
  have hba : |b - a| ≤ ξ / 2 := by
    rw [abs_of_nonpos (sub_nonpos.mpr hb.2.1), neg_sub]
    apply hb.2.2.trans
    refine (div_le_div_of_nonneg_right ?_ (Nat.cast_nonneg Q : (0 : ℝ) ≤ Q)).trans hgrid
    exact_mod_cast Nat.sub_le K (j + 1)
  have hτ : 0 ≤ tau := hgradient.1.trans hgradient.2
  change |b * s - a * gradient| ≤ ξ * tau
  rw [show b * s - a * gradient = b * (s - gradient) + (b - a) * gradient by ring]
  refine (abs_add_le _ _).trans ?_
  rw [abs_mul, abs_mul, abs_of_nonneg hb.1, abs_of_nonneg hgradient.1]
  have hfirst := mul_le_mul_of_nonneg_left hmean hb.1
  have hsecond := mul_le_mul_of_nonneg_right hba hgradient.1
  have hξ : 0 ≤ ξ / 2 := by
    have := (abs_nonneg _).trans hba
    exact this
  change b * |s - gradient| ≤ b * (ξ * tau / 2) at hfirst
  have hscale : 0 ≤ ξ * tau / 2 := by linarith only [mul_nonneg hξ hτ]
  have hbf : b * (ξ * tau / 2) ≤ ξ * tau / 2 := by
    simpa only [one_mul] using mul_le_mul_of_nonneg_right (hb.2.1.trans ha.2) hscale
  exact (add_le_add (hfirst.trans hbf)
    (hsecond.trans (mul_le_mul_of_nonneg_left hgradient.2 hξ))).trans_eq (by ring)

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- The finite direction sequence driven by the paper's two-call samples
satisfies (JF3) on an accurate empirical transcript. The draw interface
permits the distribution of each sample to depend on the preceding iterates. -/
theorem oracle_greedy_solution (hm : 0 < m) (p D tau epsilon : ℝ) (Q : ℕ)
    (ends : Fin m → V × V) (f : Finset (Fin m) → ℝ) (w : Fin m → ℝ)
    (draw : ℕ → (Fin m ⊕ Fin m → ℝ) → Fin m → Fin N → Finset (Fin m) × Finset (Fin m))
    (hf : IsSubmodular f) (hmono : IsMonotone f) (hzero : f ∅ = 0)
    (hp : 0 < p) (hp1 : p ≤ 1) (hD : 0 < D) (hD2 : 2 * D ≤ 1)
    (htau : 0 < tau) (heps : 0 < epsilon) (heps1 : epsilon ≤ 1)
    (hQ : 0 < Q) (hw : ∀ e, 0 ≤ w e ∧ w e ≤ tau) (hfτ : ∀ e, f {e} ≤ tau)
    (hgrid : (FiniteGreedy.stages D m epsilon : ℝ) / Q ≤ FiniteGreedy.accuracy D m epsilon / 2)
    (hmean : ∀ j < FiniteGreedy.stages D m epsilon, ∀ e,
      let t := sampledPoint p D tau epsilon ends w (oracleCoefficient D tau epsilon Q f draw) j
      let g := residualValue (enumerateEdge hm) p f m
      |Streaming.sourceAverage (FiniteGreedy.accuracy D m epsilon * tau / 2)
        (fun sample => Multilinear.derivativeSample f e (draw j t e sample).1
          (draw j t e sample).2) - exactGradient hm D g t e| ≤
        FiniteGreedy.accuracy D m epsilon * tau / 2) :
    let K := FiniteGreedy.stages D m epsilon
    let t := sampledPoint p D tau epsilon ends w (oracleCoefficient D tau epsilon Q f draw) K
    let g := residualValue (enumerateEdge hm) p f m
    Feasible p D ends ends (fun e => p * t (.inl e)) (fun e => D * t (.inr e)) ∧
      ∀ (z : Fin m → ℝ) (O : Finset (Fin m)),
        Feasible p D ends ends z (fun e => D * edgeIndicator O e) →
        (∑ e, w e * z e) + (1 - Real.exp (-D)) * g O - epsilon * tau / 2 ≤
          (∑ e, w e * (p * t (.inl e))) +
            bernoulliExpectation (enumerateEdge hm) (physicalY hm D t) g m := by
  let g := residualValue (enumerateEdge hm) p f m
  have hnorm := residualValue_empty (enumerateEdge hm) p f m
  have hg := residualValue_submodular (enumerateEdge hm) p f hf hp.le hp1 m
  have hgm := residualValue_monotone (enumerateEdge hm) p f hmono hp.le hp1 m
  have hsingleton (e : Fin m) : g {e} ≤ tau := by
    rw [← bernoulliExpectation_const (enumerateEdge hm) (fun _ => p) tau m]
    exact bernoulliExpectation_mono (enumerateEdge hm) (fun _ => p)
      (fun A => f ({e} ∪ A) - f A) (fun _ => tau) m
      (fun _ _ => ⟨hp.le, hp1⟩)
      (fun A => by
        simpa only [marginal, Finset.union_comm] using
          (Multilinear.submodular_marginal_bound f hf hmono hzero hfτ e A).2)
  apply sampled_greedy_solution hm p D tau epsilon ends g w _ hg hgm hnorm hp hp1 hD hD2
    htau heps heps1 hw hsingleton
  intro j hj e
  dsimp only
  intro hbounded
  exact oracleCoefficient_accuracy D tau epsilon Q f draw j _ e _ hD.le (by linarith)
    hQ hbounded hgrid (hmean j hj e)

end

end SubmodularMatching.Joint
