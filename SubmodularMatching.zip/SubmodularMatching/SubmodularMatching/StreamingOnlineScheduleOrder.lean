import SubmodularMatching.StreamingOnlinePointwise

/-!
# The order of the actual online estimate calls

The program obtains its calls from active guess lists, one arrival at a
time. The lexicographic list constructed with the complete stream is just
a proof object for that chronological order.
-/

namespace SubmodularMatching.Streaming

theorem OnlineEpoch.active_sorted (st : OnlineEpoch) (W : ℚ) (span : ℕ) :
    (st.active W span).SortedLT := by
  unfold OnlineEpoch.active
  split
  · apply List.Pairwise.sortedLT
    apply List.Pairwise.filter
    rw [List.pairwise_map]
    exact List.pairwise_lt_range.imp (fun h => Nat.add_lt_add_left h _)
  · exact List.Pairwise.nil.sortedLT

/-- Proof-side enumeration of the calls issued by the executable epochs. -/
def onlineEstimateOrder (W : ℚ) (span : ℕ) (value : ℕ → ℚ) : ℕ → List (Lex (ℕ × ℕ))
  | 0 => []
  | k + 1 => onlineEstimateOrder W span value k ++
      ((runOnlineEpoch W span value (k + 1)).active W span).map (fun j => toLex (k, j))

theorem mem_onlineEstimateOrder (W : ℚ) (span : ℕ) (value : ℕ → ℚ) (k a j : ℕ) :
    toLex (a, j) ∈ onlineEstimateOrder W span value k ↔
      a < k ∧ j ∈ (runOnlineEpoch W span value (a + 1)).active W span := by
  induction k with
  | zero => simp [onlineEstimateOrder]
  | succ k ih =>
    rw [onlineEstimateOrder, List.mem_append, ih, List.mem_map]
    constructor
    · rintro (⟨h, hj⟩ | ⟨j', hj', he⟩)
      · exact ⟨Nat.lt_succ_of_lt h, hj⟩
      · obtain ⟨rfl, rfl⟩ := Prod.mk.inj (toLex.injective he)
        exact ⟨Nat.lt_succ_self _, hj'⟩
    · rintro ⟨h, hj⟩
      by_cases ha : a = k
      · exact Or.inr ⟨j, ha ▸ hj, congrArg (fun i => toLex (i, j)) ha.symm⟩
      · exact Or.inl ⟨by omega, hj⟩

theorem onlineEstimateOrder_sorted (W : ℚ) (span : ℕ) (value : ℕ → ℚ) (k : ℕ) :
    (onlineEstimateOrder W span value k).SortedLT := by
  induction k with
  | zero => exact List.Pairwise.nil.sortedLT
  | succ k ih =>
    apply List.Pairwise.sortedLT
    rw [onlineEstimateOrder, List.pairwise_append, List.pairwise_map]
    refine ⟨ih.pairwise, ?_, ?_⟩
    · apply ((runOnlineEpoch W span value (k + 1)).active_sorted W span).pairwise.imp
      intro i j h
      exact Prod.Lex.lt_iff.2 (Or.inr ⟨rfl, h⟩)
    · intro z hz y hy
      obtain ⟨j, -, rfl⟩ := List.mem_map.1 hy
      let a := (ofLex z).1
      let i := (ofLex z).2
      have hcz : toLex (a, i) = z := toLex_ofLex z
      have hm : toLex (a, i) ∈ onlineEstimateOrder W span value k := hcz ▸ hz
      change z < toLex (k, j)
      rw [← hcz]
      exact Prod.Lex.lt_iff.2 (Or.inl ((mem_onlineEstimateOrder W span value k a i).1 hm).1)

theorem onlineEstimateOrder_eq_reference (W : ℚ) (span : ℕ) (value : ℕ → ℚ)
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ span) (k : ℕ) :
    onlineEstimateOrder W span value k = sourceScheduleList W (fun i => (value i : ℝ)) span k := by
  let v := fun i => (value i : ℝ)
  have hw : (W : ℝ) ≤ 2 ^ span := by exact_mod_cast hspan
  have hsorted := onlineEstimateOrder_sorted W span value k
  have hsorted' := sourceScheduleList_sorted W v span k
  have hp := (List.perm_ext_iff_of_nodup hsorted.nodup hsorted'.nodup).2
  apply List.Perm.eq_of_sortedLE hsorted.sortedLE hsorted'.sortedLE
  apply hp
  intro z
  let a := (ofLex z).1
  let j := (ofLex z).2
  have hcz : toLex (a, j) = z := toLex_ofLex z
  rw [← hcz, mem_onlineEstimateOrder, mem_sourceScheduleList,
    runOnlineEpoch_active_iff W span value hW hspan (a + 1) j]
  let B := singletonMaximum v (a + 1)
  let A := guessAnchor W v (a + 1)
  by_cases hB : 0 < B
  · rw [mem_activeGuessIndices W A B span j
      (guessAnchor_pos _ _ _ hB) (guessAnchor_le _ _ _) hw]
  · have hz : B = 0 := (le_of_not_gt hB).antisymm (singletonMaximum_nonneg _ _)
    change (a < k ∧ guessActive W A B j) ↔ a < k ∧ j ∈ activeGuessIndices W A B span
    rw [hz]
    simp only [guessActive, lt_self_iff_false, false_and, and_false,
      activeGuessIndices_eq_empty_of_zero, Finset.notMem_empty]

end SubmodularMatching.Streaming
