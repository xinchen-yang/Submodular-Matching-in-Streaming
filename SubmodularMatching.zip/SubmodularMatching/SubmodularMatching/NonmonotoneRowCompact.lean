import SubmodularMatching.NonmonotoneLayersSourceGeometry
import Mathlib.Data.List.Dedup
import Mathlib.Data.List.Nodup

/-! Dense indices for the endpoints of the actual assigned diffuse copies.
Their construction uses a scan of retained labels, without scanning unused
capacities or allocating a `sum b(v)` mate array. -/

namespace SubmodularMatching.NonmonotoneCandidate

open Capacity UpperBoundAssembly TwoStage

variable {I W : Type*} [DecidableEq W]

def assignedSlots (seq : List I) (pair : I → W × W) : List W :=
  (seq.flatMap (fun i => [(pair i).1,(pair i).2])).dedup

theorem assignedSlots_size (seq : List I) (pair : I → W × W) :
    (assignedSlots seq pair).length ≤ 2*seq.length := by
  apply (List.dedup_sublist _).length_le.trans
  induction seq with
  | nil => simp
  | cons i seq ih => simp only [List.flatMap_cons,List.cons_append,List.nil_append,List.length_cons]; omega

def compactSlot (seq : List I) (pair : I → W × W) : Fin (assignedSlots seq pair).length ↪ W :=
  ⟨(assignedSlots seq pair).get,fun _ _ h => (List.nodup_dedup _).get_inj_iff.mp h⟩

def compactPoint (seq : List I) (pair : I → W × W) (u : W) (hu : u ∈ assignedSlots seq pair) :
    Fin (assignedSlots seq pair).length :=
  ⟨(assignedSlots seq pair).idxOf u,List.idxOf_lt_length_iff.mpr hu⟩

theorem compactPoint_value (seq : List I) (pair : I → W × W) (u : W) (hu : u ∈ assignedSlots seq pair) :
    compactSlot seq pair (compactPoint seq pair u hu) = u := List.idxOf_get _

def compactPair (seq : List I) (pair : I → W × W) (cover : ∀ i, i ∈ seq) (i : I) :
    Fin (assignedSlots seq pair).length × Fin (assignedSlots seq pair).length :=
  let mem (u : W) (h : u ∈ [(pair i).1,(pair i).2]) : u ∈ assignedSlots seq pair :=
    List.mem_dedup.mpr (List.mem_flatMap.mpr ⟨i,cover i,h⟩)
  (compactPoint seq pair (pair i).1 (mem _ (by simp)),compactPoint seq pair (pair i).2 (mem _ (by simp)))

theorem compactPair_values (seq : List I) (pair : I → W × W) (cover : ∀ i, i ∈ seq) (i : I) :
    let ep := compactPair seq pair cover
    let slot := compactSlot seq pair
    slot (ep i).1=(pair i).1 ∧ slot (ep i).2=(pair i).2 := by simp [compactPair,compactPoint_value]

theorem compactPair_loopless (seq : List I) (pair : I → W × W) (cover : ∀ i, i ∈ seq)
    (hl : ∀ i, (pair i).1 ≠ (pair i).2) (i : I) :
    (compactPair seq pair cover i).1 ≠ (compactPair seq pair cover i).2 := by
  let h := compactPair_values seq pair cover i
  exact fun eq => hl i (h.1.symm.trans ((congrArg (compactSlot seq pair) eq).trans h.2))

theorem compactPair_simple (seq : List I) (pair : I → W × W) (cover : ∀ i, i ∈ seq)
    (hs : Function.Injective (pairEnds pair)) : Function.Injective (pairEnds (compactPair seq pair cover)) := by
  let slot := compactSlot seq pair
  have h (i : I) : ((pairEnds (compactPair seq pair cover) i).image slot) = pairEnds pair i := by
    have hh := compactPair_values seq pair cover i
    simp [pairEnds,slot,hh.1,hh.2]
  intro a b he
  exact hs ((h a).symm.trans ((congrArg (Finset.image slot) he).trans (h b)))

end SubmodularMatching.NonmonotoneCandidate
