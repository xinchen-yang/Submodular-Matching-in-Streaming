import SubmodularMatching.LowerBoundWitnessGeometry
import SubmodularMatching.RecursiveObjectiveCompleteness

/-! # Objective value of the actual matching witness -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

variable {p N P t H : ℕ} {C : Type*} [Fintype C] [DecidableEq C] [AddCommGroup C]

/-- The normalization in the actual lower-bound instance. -/
def hardNormalizer (C : Type*) [Fintype C] (N H : ℕ) : ℕ :=
  Fintype.card C * (H + 2 * (N - H))

/-- Every stage retains a large subset of its hidden-label witness. -/
def hardComplete (b : BlueprintExpansion N P t H) (ξ : ℝ)
    (draw : HardDraw p N P t C) : Prop :=
  ∀ i : Fin p, (1 - ξ) * (hardNormalizer C N H : ℝ) ≤
    ((witnessStage b (draw.1 i) (draw.2 i)).card : ℝ)

theorem hardWitness_stageMass_true (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) (unit : ℝ) (i : Fin p) :
    RecursiveObjective.stageMass unit (fun e => e.1.val) (stageLabel hardPublicLabel draw.2)
      i.val true (hardWitness b draw) =
    ((witnessStage b (draw.1 i) (draw.2 i)).card : ℝ) * unit := by
  have heq :
      (hardWitness b draw).filter (fun e => e.1.val = i.val ∧
        stageLabel hardPublicLabel draw.2 e = true) =
        (hardWitness b draw).filter (fun e => e.1 = i) := by
    ext e
    simp only [Finset.mem_filter]
    constructor
    · rintro ⟨he, htag, _⟩
      exact ⟨he, Fin.ext htag⟩
    · rintro ⟨he, rfl⟩
      exact ⟨he, rfl, hardWitness_good_label b draw _ he⟩
  rw [RecursiveObjective.stageMass, heq, Finset.sum_const, nsmul_eq_mul, hardWitness_stage_card]

theorem hardWitness_stageMass_false (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) (unit : ℝ) (i : ℕ) :
    RecursiveObjective.stageMass unit (fun e => e.1.val) (stageLabel hardPublicLabel draw.2)
      i false (hardWitness b draw) = 0 := by
  have heq :
      (hardWitness b draw).filter (fun e => e.1.val = i ∧
        stageLabel hardPublicLabel draw.2 e = false) = ∅ := by
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro e he
    have hf := Finset.mem_filter.mp he
    rw [hardWitness_good_label b draw _ hf.1] at hf
    simp at hf
  rw [RecursiveObjective.stageMass, heq, Finset.sum_empty]

/-- When all stage counts survive, the actual objective is at least
`p(1-ξ)` on the feasible matching witness. -/
theorem hardWitness_value_lower (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) (ξ : ℝ)
    (hscale : 0 < hardNormalizer C N H) (hcomplete : hardComplete b ξ draw) :
    (p : ℝ) * (1 - ξ) ≤ hardOracle (1 / (hardNormalizer C N H : ℝ)) draw (hardWitness b draw) := by
  have hM : 0 < (hardNormalizer C N H : ℝ) := by exact_mod_cast hscale
  unfold hardOracle mixedOracle
  apply RecursiveObjective.objective_good_only_lower_bound _ (by positivity) _ _ _ _
    (hardWitness b draw) ξ
  · intro i _ _
    exact hardWitness_stageMass_false b draw _ i
  · intro i _ hi
    have hi' : i < p := by simpa using hi
    let stage : Fin p := ⟨i, hi'⟩
    change 1 - ξ ≤ RecursiveObjective.stageMass (1 / (hardNormalizer C N H : ℝ))
      (fun e => e.1.val) (stageLabel hardPublicLabel draw.2) stage.val true (hardWitness b draw) ∧ _
    rw [hardWitness_stageMass_true b draw]
    rw [mul_one_div]
    exact ⟨(le_div_iff₀ hM).mpr (hcomplete stage), (div_le_one hM).mpr (by
      exact_mod_cast witnessStage_card_le b (draw.1 stage) (draw.2 stage))⟩

/-- Whether or not the count threshold holds, the witness is an arrived
matching feasible for the actual oracle objective. -/
theorem hardComplete_feasible_value (b : BlueprintExpansion N P t H)
    (draw : HardDraw p N P t C) (ξ : ℝ)
    (hscale : 0 < hardNormalizer C N H) (hcomplete : hardComplete b ξ draw) :
    ∃ W : Finset (HardEdge p N C),
      HardMatching W ∧ (∀ e ∈ W, e ∈ hardStream b draw) ∧
        (p : ℝ) * (1 - ξ) ≤ hardOracle (1 / (hardNormalizer C N H : ℝ)) draw W :=
  ⟨hardWitness b draw, hardWitness_matching b draw, fun _ he => hardWitness_arrived b draw he,
    hardWitness_value_lower b draw ξ hscale hcomplete⟩

end

end SubmodularMatching.LowerBoundGlobal
