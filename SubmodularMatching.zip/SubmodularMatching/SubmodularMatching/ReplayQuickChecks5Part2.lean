import SubmodularMatching.ReplayQuickRate

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 16000
set_option maxHeartbeats 5000000

theorem quick17408 : allIndexed compareQuick 17408 sourceRates17408 = true := by decide +kernel

end SubmodularMatching.SourceCertificate.Replay
