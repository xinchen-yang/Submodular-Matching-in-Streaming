import SubmodularMatching.CapacityLift
import Mathlib.Data.List.Nodup

/-! # The streaming slot allocation in Proposition 5.2 -/

namespace SubmodularMatching.Capacity
open Finset

variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable (ends : E → V × V) (cap : V → ℕ)

def emptyAllocation : Allocation E V := ⟨∅, fun _ _ => 0⟩

def room (a : Allocation E V) (e : E) : Prop :=
  (incidences ends a.kept (ends e).1).card < cap (ends e).1 ∧
  (incidences ends a.kept (ends e).2).card < cap (ends e).2

instance (a : Allocation E V) (e : E) : Decidable (room ends cap a e) :=
  inferInstanceAs (Decidable (_ ∧ _))

def keep (a : Allocation E V) (e : E) : Allocation E V :=
  ⟨insert e a.kept, fun v x => if x = e then (incidences ends a.kept v).card else a.slot v x⟩

def step (a : Allocation E V) (e : E) : Allocation E V :=
  if room ends cap a e then keep ends a e else a

def final (a : Allocation E V) (stream : List E) : Allocation E V :=
  stream.foldl (step ends cap) a

def block (a : Allocation E V) (e : E) : List (Copy E) :=
  if room ends cap a e then [designated ends (keep ends a e) e] else
    ((List.range (cap (ends e).1)) ×ˢ (List.range (cap (ends e).2))).map fun ij => ⟨e,ij.1,ij.2⟩

def emitted (a : Allocation E V) : List E → List (Copy E)
  | [] => []
  | e :: rest => block ends cap a e ++ emitted (step ends cap a e) rest

theorem incidences_insert (s : Finset E) (e : E) (v : V) :
    incidences ends (insert e s) v =
      if touches ends v e then insert e (incidences ends s v) else incidences ends s v := by
  exact filter_insert _ _ _

theorem empty_consistent : Consistent ends cap (emptyAllocation : Allocation E V) := by
  constructor
  · intro v
    simp [emptyAllocation, incidences]
  · simp [emptyAllocation, incidences]
  · intro v
    simp [emptyAllocation, incidences]

theorem keep_consistent (a : Allocation E V) (ha : Consistent ends cap a)
    (e : E) (he : e ∉ a.kept) (hr : room ends cap a e) : Consistent ends cap (keep ends a e) := by
  have hnot (v : V) : e ∉ incidences ends a.kept v := fun hm => he (mem_filter.mp hm).1
  have bound (v : V) (ht : touches ends v e) : (incidences ends a.kept v).card < cap v := by
    rcases ht with rfl | rfl
    · exact hr.1
    · exact hr.2
  have hinc (v : V) := incidences_insert ends a.kept e v
  constructor
  · intro v
    change (incidences ends (insert e a.kept) v).card ≤ cap v
    rw [hinc v]
    split
    next ht => simpa [card_insert_of_notMem (hnot v)] using Nat.succ_le_of_lt (bound v ht)
    next => exact ha.capacity v
  · intro v x hx
    change x ∈ incidences ends (insert e a.kept) v at hx
    change (if x = e then _ else _) < (incidences ends (insert e a.kept) v).card
    rw [hinc v] at hx ⊢
    by_cases ht : touches ends v e
    · simp only [if_pos ht, mem_insert] at hx
      simp only [if_pos ht, card_insert_of_notMem (hnot v)]
      rcases hx with rfl | hx
      · simp
      · rw [if_neg (fun (h : x = e) => hnot v (h ▸ hx))]
        exact Nat.lt_succ_of_lt (ha.bounded v x hx)
    · simp only [if_neg ht] at hx ⊢
      rw [if_neg (fun (h : x = e) => hnot v (h ▸ hx))]
      exact ha.bounded v x hx
  · intro v x hx y hy hxy
    change x ∈ incidences ends (insert e a.kept) v at hx
    change y ∈ incidences ends (insert e a.kept) v at hy
    change (if x = e then _ else _) = (if y = e then _ else _) at hxy
    have old (z : E) (hz : z ∈ incidences ends (insert e a.kept) v) (hne : z ≠ e) :
        z ∈ incidences ends a.kept v := by
      obtain ⟨hs,ht⟩ := mem_filter.mp hz
      exact mem_filter.mpr ⟨(mem_insert.mp hs).resolve_left hne,ht⟩
    by_cases hxe : x = e <;> by_cases hye : y = e
    · exact hxe.trans hye.symm
    · rw [if_pos hxe, if_neg hye] at hxy
      exact False.elim ((ha.bounded v y (old y hy hye)).ne hxy.symm)
    · rw [if_neg hxe, if_pos hye] at hxy
      exact False.elim ((ha.bounded v x (old x hx hxe)).ne hxy)
    · rw [if_neg hxe, if_neg hye] at hxy
      exact ha.injective v (old x hx hxe) (old y hy hye) hxy

theorem step_consistent (a : Allocation E V) (ha : Consistent ends cap a)
    (e : E) (he : e ∉ a.kept) : Consistent ends cap (step ends cap a e) := by
  unfold step
  split
  next h => exact keep_consistent ends cap a ha e he h
  next => exact ha

theorem step_mem (a : Allocation E V) (e x : E) :
    x ∈ (step ends cap a e).kept ↔ x ∈ a.kept ∨ x = e ∧ room ends cap a e := by
  by_cases h : room ends cap a e <;> simp [step, keep, h, or_comm]

theorem step_fixed (a : Allocation E V) (e x : E) (hx : x ≠ e) (v : V) :
    (step ends cap a e).slot v x = a.slot v x := by
  by_cases h : room ends cap a e <;> simp [step, keep, h, hx]

theorem final_preserves (a : Allocation E V) (s : List E) :
    a.kept ⊆ (final ends cap a s).kept := by
  induction s generalizing a with
  | nil => exact fun _ h => h
  | cons e s ih =>
    exact (fun x hx => ih (step ends cap a e) ((step_mem ends cap a e x).2 (Or.inl hx)))

theorem final_outside (a : Allocation E V) (s : List E) (x : E) (hx : x ∉ s) :
    (x ∈ (final ends cap a s).kept ↔ x ∈ a.kept) ∧
    ∀ v, (final ends cap a s).slot v x = a.slot v x := by
  induction s generalizing a with
  | nil => exact ⟨Iff.rfl, fun _ => rfl⟩
  | cons e s ih =>
    have hne : x ≠ e := fun h => hx (List.mem_cons.mpr (Or.inl h))
    have hns : x ∉ s := fun h => hx (List.mem_cons.mpr (Or.inr h))
    obtain ⟨hm,hs⟩ := ih (step ends cap a e) hns
    exact ⟨hm.trans (by simp [step_mem, hne]), fun v => (hs v).trans (step_fixed ends cap a e x hne v)⟩

theorem final_consistent (a : Allocation E V) (ha : Consistent ends cap a)
    (s : List E) (hn : s.Nodup) (hf : ∀ e ∈ s, e ∉ a.kept) :
    Consistent ends cap (final ends cap a s) := by
  induction s generalizing a with
  | nil => exact ha
  | cons e s ih =>
    apply ih (step ends cap a e) (step_consistent ends cap a ha e (hf e (by simp))) (List.nodup_cons.mp hn).2
    intro x hx h
    rcases (step_mem ends cap a e x).mp h with hk | ⟨rfl,_⟩
    · exact hf x (by simp [hx]) hk
    · exact (List.nodup_cons.mp hn).1 hx

end SubmodularMatching.Capacity
