import SubmodularMatching.FiniteShearerTapeRetained

/-!
# Executable alteration on the retained compensated grid

After the first draw, the degree tests use integer masked-load sums.
The retained coordinates for the second draw are formed directly on the
common altered grid.
-/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsMatching TwoStage NumericalCertificate ShearerSampler
open scoped BigOperators

variable {m : ℕ} {V : Type*} [DecidableEq V]

/-- A compact vertex is free exactly when no first-stage edge uses it. -/
def gridFree (ends : Fin m → V × V) (first : Finset (Fin m)) : V → Bool :=
  let used := first.biUnion (pairEnds ends)
  fun v => decide (v ∉ used)

private theorem gridFree_eq_unmatched (ends : Fin m → V × V) (first : Finset (Fin m)) (v : V) :
    gridFree ends first v = true ↔ unmatched (pairEnds ends) v first = 1 := by
  unfold gridFree unmatched
  by_cases hv : v ∈ first.biUnion (pairEnds ends) <;> simp [hv]

/-- For a requested vertex, read the opposite endpoint's free bit. -/
def gridOppositeFree (ends : Fin m → V × V) (first : Finset (Fin m)) : V → Fin m → Bool :=
  let free := gridFree ends first
  fun v e => if v = (ends e).1 then free (ends e).2
    else if v = (ends e).2 then free (ends e).1 else false

private theorem gridOppositeFree_value (ends : Fin m → V × V) (first : Finset (Fin m)) (v : V)
    (e : Fin m) :
    (if gridOppositeFree ends first v e then (1:ℝ) else 0) =
      opposite ends (fun u T => unmatched (pairEnds ends) u T) v e first := by
  have hf (u : V) : (if gridFree ends first u then (1:ℝ) else 0) =
      unmatched (pairEnds ends) u first := by
    unfold gridFree unmatched
    by_cases hu : u ∈ first.biUnion (pairEnds ends) <;> simp [hu]
  unfold gridOppositeFree opposite
  by_cases hu : v = (ends e).1
  · simp only [if_pos hu]
    exact hf _
  · rw [if_neg hu,if_neg hu]
    by_cases hv : v = (ends e).2
    · simp only [if_pos hv]
      exact hf _
    · simp [hv]

/-- Masked vertex load on the common compensated denominator. -/
def gridMaskedLoad (ends : Fin m → V × V) (a : Fin m → ℕ)
    (first : Finset (Fin m)) : V → ℕ :=
  let opposite := gridOppositeFree ends first
  fun v => ∑ e, if opposite v e then a e else 0

private theorem gridMaskedLoad_decode (ends : Fin m → V × V) (a : Fin m → ℕ)
    (first : Finset (Fin m)) (v : V) :
    ((gridMaskedLoad ends a first v : ℕ):ℝ)/appendixCompensatedDenominator m =
      load ends (fun e => (a e:ℝ)/appendixCompensatedDenominator m)
        (fun u T => unmatched (pairEnds ends) u T) v first := by
  unfold gridMaskedLoad load
  rw [Nat.cast_sum,Finset.sum_div]
  apply Finset.sum_congr rfl
  intro e _
  rw [← gridOppositeFree_value ends first v e]
  cases gridOppositeFree ends first v e <;> simp

/-- The actual integer altered numerator, with both free tests and
the two integer load comparisons. -/
def gridAlteredNumerator (ends : Fin m → V × V) (a : Fin m → ℕ)
    (first : Finset (Fin m)) : Fin m → ℕ :=
  let free := gridFree ends first
  let maskedLoad := gridMaskedLoad ends a first
  fun e =>
    let u := (ends e).1
    let v := (ends e).2
    if free u = true ∧ free v = true ∧
        400000000*maskedLoad u ≤ 400000001*appendixCompensatedDenominator m ∧
        400000000*maskedLoad v ≤ 400000001*appendixCompensatedDenominator m
    then 400000000*a e else 0

/-- Reading the integer numerator on the altered grid gives exactly GJ8. -/
theorem gridAlteredNumerator_decode (hm : 0 < m) (ends : Fin m → V × V)
    (a : Fin m → ℕ) (first : Finset (Fin m)) (e : Fin m) :
    (gridAlteredNumerator ends a first e : ℝ)/appendixAlteredDenominator m =
      altered ends (fun e => (a e:ℝ)/appendixCompensatedDenominator m)
        (fun u T => unmatched (pairEnds ends) u T) (roundingError/4) first e := by
  let B := appendixCompensatedDenominator m
  have hB : 0 < B := Nat.mul_pos (by decide) hm
  have hB' : 0 < (B:ℝ) := by exact_mod_cast hB
  have hε : (1:ℝ)+roundingError/4 = 400000001/400000000 := by norm_num [roundingError]
  have hCompare (v : V) :
      400000000*gridMaskedLoad ends a first v ≤ 400000001*appendixCompensatedDenominator m ↔
        load ends (fun d => (a d:ℝ)/appendixCompensatedDenominator m)
          (fun u T => unmatched (pairEnds ends) u T) v first ≤ 1+roundingError/4 := by
    rw [← gridMaskedLoad_decode ends a first v,hε,div_le_div_iff₀ hB' (by norm_num)]
    rw [mul_comm (gridMaskedLoad ends a first v : ℝ) (400000000:ℝ)]
    exact_mod_cast Iff.rfl
  simp only [gridAlteredNumerator,gridFree_eq_unmatched,hCompare,altered]
  split_ifs
  · simp only [appendixAlteredDenominator,Nat.cast_mul,Nat.cast_ofNat,hε]
    field_simp
  · simp


/-- Materialize the altered coordinate words once per first-stage
matching, before the local chain repeatedly reads them. -/
def gridAlteredTable (ends : Fin m → V × V) (a : Fin m → ℕ) (first : Finset (Fin m)) : Array ℕ :=
  Array.ofFn (gridAlteredNumerator ends a first)

@[simp] theorem gridAlteredTable_size (ends : Fin m → V × V) (a : Fin m → ℕ)
    (first : Finset (Fin m)) : (gridAlteredTable ends a first).size = m := by
  simp [gridAlteredTable]

def gridAlteredWords (ends : Fin m → V × V) (a : Fin m → ℕ) (first : Finset (Fin m)) : Fin m → ℕ :=
  let table := gridAlteredTable ends a first
  fun e => table[e.val]'(by rw [gridAlteredTable_size]; exact e.isLt)

@[simp] theorem gridAlteredWords_value (ends : Fin m → V × V) (a : Fin m → ℕ)
    (first : Finset (Fin m)) (e : Fin m) :
    gridAlteredWords ends a first e = gridAlteredNumerator ends a first e := by
  simp [gridAlteredWords,gridAlteredTable]

end SubmodularMatching.UpperBoundAssembly
