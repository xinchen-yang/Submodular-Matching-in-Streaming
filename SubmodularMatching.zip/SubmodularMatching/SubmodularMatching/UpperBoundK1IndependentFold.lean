import SubmodularMatching.UpperBoundFiniteExecution
import Mathlib.MeasureTheory.Integral.Prod

/-! # A product of fresh draws can be consumed with a fold -/

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler MeasureTheory ProbabilityTheory

noncomputable section
variable {A X : Type*}

/-- Fold over a product input. This definition is only used to state the
equivalence with the analytic product distribution. -/
def independentFold (step : ℕ → A → X → A) : (n : ℕ) → ℕ → A → (Fin n → X) → A
  | 0, _, s, _ => s
  | n + 1, j, s, draws =>
    independentFold step n (j + 1) (step j s (draws 0)) (Fin.tail draws)

variable [Fintype X] [MeasurableSpace X] [MeasurableSingletonClass X]

/-- At a step, draw one new input and retain only the updated state. -/
def independentFoldStep (μ : Measure X) [IsProbabilityMeasure μ]
    (step : ℕ → A → X → A) (j : ℕ) (s : A) : CandidateLaw A := by
  classical
  exact (CandidateLaw.ofMeasure μ).map (step j s)

/-- Sequentially consuming independent finite samples gives the same
observables as folding the full product draw. -/
theorem independentFold_expected (μ : Measure X) [IsProbabilityMeasure μ]
    (step : ℕ → A → X → A) (n j : ℕ) (s : A) (test : A → ℝ) :
    let q := CandidateLaw.execute (independentFoldStep μ step) n j s
    expected q.outcomes q.mass test =
      ∫ w : Fin n → X, test (independentFold step n j s w) ∂(Measure.pi fun _ => μ) := by
  classical
  dsimp only
  induction n generalizing j s with
  | zero => simp [CandidateLaw.execute, independentFold]
  | succ n ih =>
    rw [CandidateLaw.execute_expected]
    rw [show independentFoldStep μ step j s = (CandidateLaw.ofMeasure μ).map (step j s) from rfl,
      CandidateLaw.map_expected, CandidateLaw.ofMeasure_expected]
    simp only [Function.comp_apply, ih]
    let split := (measurePreserving_piFinSuccAbove (fun _ : Fin (n + 1) => μ) 0).symm
    rw [← split.integral_comp']
    simp only [MeasurableEquiv.piFinSuccAbove_symm_apply, Fin.insertNthEquiv,
      Fin.insertNth_zero', Equiv.coe_fn_mk, Function.comp_apply, independentFold,
      Fin.cons_zero, Fin.tail_cons]
    rw [integral_prod _ Integrable.of_finite]

end

end SubmodularMatching.UpperBoundAssembly
