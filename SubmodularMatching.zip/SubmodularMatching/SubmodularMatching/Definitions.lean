import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Lattice.Basic
import Mathlib.Data.Finset.Union
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Tauto

namespace SubmodularMatching

def IsSubmodular
    {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ) : Prop :=
  ∀ A B : Finset E,
    f (A ∪ B) + f (A ∩ B) ≤ f A + f B

def IsMonotone
    {E : Type*} [DecidableEq E]
    (f : Finset E → ℝ) : Prop :=
  ∀ A B : Finset E,
    A ⊆ B → f A ≤ f B

end SubmodularMatching
