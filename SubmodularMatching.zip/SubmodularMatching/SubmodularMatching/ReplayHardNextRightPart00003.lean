import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step49 : ProjectedGoal ⟨54972, 55025, 141, 212, 0, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd6f1d6bce8d4a510002050a6) (by decide +kernel)

private theorem step50 : ProjectedGoal ⟨54972, 54998, 212, 247, 0, 70⟩ :=
  projectedGoal_chunk _ (.x (.leaf 0xd6d6d6bce8d4a51000203204) (.x (.x (.x (.m (.x (.leaf 0xd6c9d6bce8d4a51000203208) (.m (.m (.leaf 0xd6bfd6bccbba106e00207209) (.leaf 0xd6c2d6c0cbba106e00207209)) (.m (.m (.leaf 0xd6c4d6c3cbba106e00207209) (.leaf 0xd6c6d6c5cbba106e00207209)) (.leaf 0xd6c9d6c7cbba106e00207209)))) (.x (.leaf 0xd6d6d6cae8d4a51000203208) (.m (.m (.leaf 0xd6cdd6cacbba106e00207209) (.leaf 0xd6d0d6cecbba106e00207209)) (.m (.leaf 0xd6d3d6d1cbba106e00207209) (.leaf 0xd6d6d6d4cbba106e00207209))))) (.leaf 0xd6d6d6bc00000000001911fb)) (.leaf 0xd6d6d6bc00000000001911e2)) (.leaf 0xd6d6d6bc00000000001911d0))) (by decide +kernel)

private theorem step51 : ProjectedGoal ⟨54999, 55025, 212, 247, 0, 70⟩ :=
  projectedGoal_chunk _ (.x (.m (.leaf 0xd6e4d6d7e8d4a51000203204) (.leaf 0xd6f1d6e5e8d4a51000207204)) (.x (.x (.x (.m (.x (.leaf 0xd6e4d6d7e8d4a51000203208) (.m (.m (.leaf 0xd6dad6d7c9e86723e0207209) (.leaf 0xd6ddd6dbcbba106e00207209)) (.m (.leaf 0xd6e1d6decbba106e00207209) (.leaf 0xd6e4d6e2cbba106e00207209)))) (.x (.leaf 0xd6f1d6e5e8d4a51000207208) (.m (.m (.leaf 0xd6e8d6e5cbba106e00207209) (.leaf 0xd6ebd6e9cbba106e00207209)) (.m (.leaf 0xd6eed6eccbba106e00207209) (.leaf 0xd6f1d6efcbba106e00207209))))) (.leaf 0xd6f1d6d700000000001911fb)) (.leaf 0xd6f1d6d700000000001911e2)) (.leaf 0xd6f1d6d700000000001911d0))) (by decide +kernel)

private theorem step52 : ProjectedGoal ⟨54972, 55025, 212, 247, 0, 70⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54998 (by decide) (by decide) (step50 rates cones) (step51 rates cones)

private theorem step53 : ProjectedGoal ⟨54972, 55025, 212, 247, 70, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd6f1d6bce8d4a510000e80a8) (by decide +kernel)

private theorem step54 : ProjectedGoal ⟨54972, 55025, 212, 247, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 70 (by decide) (by decide) (step52 rates cones) (step53 rates cones)

private theorem step55 : ProjectedGoal ⟨54972, 55025, 247, 283, 0, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd6f1d6bc000000000020610e) (by decide +kernel)

private theorem step56 : ProjectedGoal ⟨54972, 55025, 212, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 247 (by decide) (by decide) (step54 rates cones) (step55 rates cones)

private theorem step57 : ProjectedGoal ⟨54972, 55025, 141, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 212 (by decide) (by decide) (step49 rates cones) (step56 rates cones)

private theorem step58 : ProjectedGoal ⟨55026, 55079, 141, 212, 0, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd727d6f2e8d4a5100020a0a6) (by decide +kernel)

private theorem step59 : ProjectedGoal ⟨55026, 55052, 212, 247, 0, 70⟩ :=
  projectedGoal_chunk _ (.x (.m (.leaf 0xd6ffd6f2e8d4a51000207204) (.leaf 0xd70cd700e8d4a51000207204)) (.x (.x (.x (.m (.x (.leaf 0xd6ffd6f2e8d4a51000207208) (.m (.m (.leaf 0xd6f5d6f2cbba106e00207209) (.leaf 0xd6f8d6f6cbba106e00207209)) (.m (.leaf 0xd6fcd6f9cbba106e00207209) (.leaf 0xd6ffd6fdcbba106e00207209)))) (.x (.leaf 0xd70cd700e8d4a51000207208) (.m (.m (.leaf 0xd703d700cbba106e00207209) (.leaf 0xd706d704cbba106e00207209)) (.m (.leaf 0xd709d707cbba106e00207209) (.leaf 0xd70cd70acbba106e00207209))))) (.leaf 0xd70cd6f200000000001911fb)) (.leaf 0xd70cd6f200000000001911e2)) (.leaf 0xd70cd6f200000000001911d0))) (by decide +kernel)

private theorem step60 : ProjectedGoal ⟨55053, 55079, 212, 247, 0, 70⟩ :=
  projectedGoal_chunk _ (.x (.m (.leaf 0xd71ad70de8d4a51000207204) (.leaf 0xd727d71be8d4a51000207204)) (.x (.x (.x (.m (.x (.leaf 0xd71ad70de8d4a51000207208) (.m (.m (.leaf 0xd710d70dcbba106e00207209) (.leaf 0xd713d711cbba106e00207209)) (.m (.leaf 0xd717d714cbba106e00207209) (.leaf 0xd71ad718cbba106e00207209)))) (.x (.leaf 0xd727d71be8d4a51000207208) (.m (.m (.leaf 0xd71ed71bcbba106e00207209) (.leaf 0xd721d71fcbba106e00207209)) (.leaf 0xd727d722cbba106e00207209)))) (.leaf 0xd727d70d00000000001911fb)) (.leaf 0xd727d70d00000000001911e2)) (.leaf 0xd727d70d00000000001911d0))) (by decide +kernel)

private theorem step61 : ProjectedGoal ⟨55026, 55079, 212, 247, 0, 70⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55052 (by decide) (by decide) (step59 rates cones) (step60 rates cones)

private theorem step62 : ProjectedGoal ⟨55026, 55079, 212, 247, 70, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd727d6f2e8d4a510000e80a8) (by decide +kernel)

private theorem step63 : ProjectedGoal ⟨55026, 55079, 212, 247, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 70 (by decide) (by decide) (step61 rates cones) (step62 rates cones)

private theorem step64 : ProjectedGoal ⟨55026, 55079, 247, 283, 0, 141⟩ :=
  projectedGoal_chunk _ (.leaf 0xd727d6f2000000000020610e) (by decide +kernel)

private theorem step65 : ProjectedGoal ⟨55026, 55079, 212, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 247 (by decide) (by decide) (step63 rates cones) (step64 rates cones)

private theorem step66 : ProjectedGoal ⟨55026, 55079, 141, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 212 (by decide) (by decide) (step58 rates cones) (step65 rates cones)

private theorem step67 : ProjectedGoal ⟨54972, 55079, 141, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 55025 (by decide) (by decide) (step57 rates cones) (step66 rates cones)

theorem Part00003 : ProjectedGoal ⟨54972, 55079, 141, 283, 0, 141⟩ := step67

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
