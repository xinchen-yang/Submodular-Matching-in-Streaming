import SubmodularMatching.UpperBoundParametricCoefficients
import SubmodularMatching.UpperBoundVertexShearerWords

/-! # Fixed logarithmic word widths at arbitrary family accuracy -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint Streaming NumericalCertificate LinearPacking ShearerSampler

noncomputable section

variable {m N : ℕ} {V : Type*} [DecidableEq V]

/-- In the actual integer solver, the dual scale times the clipping
radius has degree five in the stored size. The accumulator has the
separate degree-eight iteration bound. -/
theorem parametricPacking_dual_scale_le (K : ℕ) (hK : 0 < K) (p : ℚ) (hm : 0 < m) (ends : Fin m → V × V) :
    let M := Fintype.card (IncidentVertex ends ⊕ IncidentVertex ends ⊕ Fin m)
    let L := Fintype.card (Fin m ⊕ Fin m)
    let b := (8 * K)
    let a := parametricPackingMatrixDenominator p
    let P := 2 * b * M * L ^ 2 * a
    let R := Nat.ceil (4 * (L : ℝ) ^ 2 / ((1 / (K : ℝ)) / 8))
    P * R ≤ (800 * b ^ 2 * a) * (m + 1) ^ 5 := by
  intro M L b a P R
  have hdim := compactPacking_dimensions ends
  have hM : M ≤ 5 * (m + 1) := hdim.1.trans (Nat.mul_le_mul_left _ (Nat.le_succ _))
  have hL : L ≤ 2 * (m + 1) := hdim.2.le.trans (Nat.mul_le_mul_left _ (Nat.le_succ _))
  have hP : P ≤ (40 * b * a) * (m + 1) ^ 3 := by
    dsimp only [P]
    calc
      _ ≤ 2 * b * (5 * (m + 1)) * (2 * (m + 1)) ^ 2 * a :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul (Nat.mul_le_mul_left _ hM) (Nat.pow_le_pow_left hL _))
      _ = _ := by ring
  have hR : R ≤ (20 * b) * (m + 1) ^ 2 := (parametricPacking_loop_bounds K hK hm ends).1
  calc
    _ ≤ ((40 * b * a) * (m + 1) ^ 3) * ((20 * b) * (m + 1) ^ 2) := Nat.mul_le_mul hP hR
    _ = _ := by ring

/-- At every Euler prefix the actual normalized point uses the same
short common grid, even for inaccurate samples. -/
theorem parametricNormalizedPoint_grid (hm : 0 < m) (K : ℕ) (hK : 0 < K)
    (p : ℚ) (hp : 0 < p) (hp1 : (p : ℝ) ≤ 1) (he1 : (1 : ℝ) / K ≤ 1) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (j : ℕ) (hj : j ≤ FiniteGreedy.stages NumericalCertificate.degree m (1 / (K : ℝ)))
    (i : Fin m ⊕ Fin m) :
    let ep := restrictEnds ends
    let c := oracleCoefficient NumericalCertificate.degree tau (1 / (K : ℝ)) Q f draw
    let t := sampledPoint (p : ℝ) NumericalCertificate.degree tau (1 / (K : ℝ)) ep w c j i
    let M := Fintype.card (IncidentVertex ends ⊕ IncidentVertex ends ⊕ Fin m)
    let L := Fintype.card (Fin m ⊕ Fin m)
    let T := FiniteGreedy.stages NumericalCertificate.degree m (1 / (K : ℝ))
    let d := T * rationalOutputDenominator M L 1 (8 * K)
    ∃ k : ℕ, k ≤ d ∧ t = (k : ℝ) / d := by
  intro ep c t M L T d
  have hM : 0 < M := by dsimp [M]; simp only [Fintype.card_sum, Fintype.card_fin]; omega
  have hL : 0 < L := by dsimp [L]; simp only [Fintype.card_sum, Fintype.card_fin]; omega
  have he : (1 / (K : ℝ)) / 8 = ((1 : ℕ) : ℝ) / ((8 * K : ℕ) : ℝ) := by
    rw [div_div, Nat.cast_mul, Nat.cast_one, Nat.cast_ofNat, mul_comm (K : ℝ)]
  have hg : OnGrid d t := by
    dsimp only [t, sampledPoint]
    rw [he]
    exact iterate_rational_output_grid _ _ _ _ T j (by decide) (by omega) (by omega) hM hL i
  have hD2 : 2 * NumericalCertificate.degree ≤ 1 := by linarith [degree_bounds.2]
  have hp' : 0 < (p : ℝ) := by exact_mod_cast hp
  have hxy := sampledPoint_feasible hm (p : ℝ) NumericalCertificate.degree tau (1 / (K : ℝ)) ep w c
    hp'.le hp1 degree_bounds.1.le hD2 (by positivity) he1 j hj
  have hbox := (Joint.packing_of_feasible (p : ℝ) NumericalCertificate.degree ep ep
    hp' degree_bounds.1 _ hxy).1 i
  have hdBase := parametricShearerDenominator_pos (Fintype.card (IncidentVertex ends)) m K hm hK
  have hd : 0 < d := by
    have hde : 0 < 62500000000000000000000 * d := by
      simpa only [d, T, M, L, parametricShearerDenominator, Fintype.card_sum, Fintype.card_fin] using hdBase
    by_contra! hzero
    rw [Nat.eq_zero_of_le_zero hzero, mul_zero] at hde
    exact (Nat.lt_irrefl 0) hde
  exact naturalRatio_of_grid hd hg hbox.1 hbox.2

/-- A common upper bound for all rounding grid denominators, independent
of the matching outcome and the samples. -/
def parametricRoundingDenominatorConstant (K : ℕ) : ℕ :=
  let b := (8 * K)
  let A := 62500000000000000000000 * (2 * K + 1) * ((160000 * b ^ 4 + 1) * (5 * b))
  A ^ 2 * (8 * K) + (8 * K) * (4 * K + 1)

theorem parametricRoundingDenominators_width (K : ℕ) (hK : 0 < K) (hm : 0 < m) (ends : Fin m → V × V) :
    let d := parametricShearerDenominator (Fintype.card (IncidentVertex ends)) m K
    let b := parametricCompensatedDenominator m K
    let a := parametricAlteredDenominator m K
    let w := (m + 1).log2 + 1
    let q := 2 ^ ((23 + (parametricRoundingDenominatorConstant K).log2 + 1) * w)
    d < q ∧ d ^ 2 * b < q ∧ b < q ∧ d ^ 2 < q ∧ a < q := by
  intro d b a w q
  let D := 62500000000000000000000 * (2 * K + 1) *
    ((160000 * (8 * K) ^ 4 + 1) * (5 * (8 * K)))
  have hd := parametricShearerDenominator_pos (Fintype.card (IncidentVertex ends)) m K hm hK
  have hb : 0 < b := by dsimp [b, parametricCompensatedDenominator]; positivity
  have hD : d ≤ D * (m + 1) ^ 11 := parametricShearerDenominator_le K hK hm ends
  have hb' : b ≤ (8 * K) * (m + 1) := by
    have hh : b = (8 * K) * m := by dsimp [b, parametricCompensatedDenominator]; ring
    rw [hh]
    exact Nat.mul_le_mul_left _ (Nat.le_succ _)
  have ha' : a ≤ ((8 * K) * (4 * K + 1)) * (m + 1) := by
    dsimp only [a, parametricAlteredDenominator]
    calc
      _ ≤ ((8 * K) * (m + 1)) * (4 * K + 1) := Nat.mul_le_mul_right _ hb'
      _ = _ := by ring
  have hsum : d ^ 2 * b + a ≤ parametricRoundingDenominatorConstant K * (m + 1) ^ 23 := by
    have hx : d ^ 2 * b ≤ (D ^ 2 * (8 * K)) * (m + 1) ^ 23 := by
      calc
        _ ≤ (D * (m + 1) ^ 11) ^ 2 * ((8 * K) * (m + 1)) :=
          Nat.mul_le_mul (Nat.pow_le_pow_left hD _) hb'
        _ = _ := by ring
    have ha'' : a ≤ ((8 * K) * (4 * K + 1)) * (m + 1) ^ 23 :=
      ha'.trans (Nat.mul_le_mul_left _ (by
        nth_rw 1 [← pow_one (m + 1)]
        exact Nat.pow_le_pow_right (by omega) (by decide)))
    calc
      _ ≤ (D ^ 2 * (8 * K)) * (m + 1) ^ 23 + ((8 * K) * (4 * K + 1)) * (m + 1) ^ 23 :=
        Nat.add_le_add hx ha''
      _ = _ := by dsimp only [parametricRoundingDenominatorConstant, D]; ring
  have hq : d ^ 2 * b + a < q := polynomial_index_word_bound hsum
  have hprod : d ^ 2 * b < q := (Nat.le_add_right _ _).trans_lt hq
  have hds : d ^ 2 ≤ d ^ 2 * b := Nat.le_mul_of_pos_right _ hb
  have hbq : b ≤ d ^ 2 * b := Nat.le_mul_of_pos_left _ (pow_pos hd _)
  have hdd : d ≤ d ^ 2 := by rw [pow_two]; exact Nat.le_mul_of_pos_right _ hd
  exact ⟨hdd.trans_lt (hds.trans_lt hprod), hprod, hbq.trans_lt hprod, hds.trans_lt hprod,
    (Nat.le_add_left _ _).trans_lt hq⟩


private theorem familyChoiceGrid_wordWidths {E : Type*} (c : RationalShearerInput E) :
    c.stopGrid.bits = Nat.clog 2 c.stopGrid.denominator ∧
      c.neighborGrid.bits = Nat.clog 2 c.neighborGrid.denominator ∧
      c.edgeGrid.bits = Nat.clog 2 c.edgeGrid.denominator :=
  ⟨rfl, rfl, rfl⟩

/-- The three exact binary primitive choices use a logarithmic number of
bits in the compact graph size. This is separate from the cap on retries. -/
theorem parametricShearer_primitiveBits (K : ℕ) (hK : 0 < K) (hm : 0 < m) (ends : Fin m → V × V)
    (num : Fin m → ℕ) :
    let vertices := Fintype.card (IncidentVertex ends)
    let Q := parametricShearerDenominator vertices m K
    let c := appendixShearerInput Q (parametricShearerDenominator_pos vertices m K hm hK) num
    let b := (8 * K)
    let C := (250000000000 : ℕ) ^ 2 *
      (62500000000000000000000 * (2 * K + 1) * ((160000 * b ^ 4 + 1) * (5 * b)))
    let W := (11 + C.log2 + 1) * ((m + 1).log2 + 1)
    c.stopGrid.bits ≤ W ∧ c.neighborGrid.bits ≤ W ∧ c.edgeGrid.bits ≤ W := by
  intro vertices Q c b C W
  have hd := appendixShearer_primitiveDenominators Q (parametricShearerDenominator_pos vertices m K hm hK) num
  have hQ := parametricShearerDenominator_le K hK hm ends
  have hC : Q * (250000000000 : ℕ) ^ 2 ≤ C * (m + 1) ^ 11 := by
    calc
      _ ≤ (62500000000000000000000 * (2 * K + 1) * ((160000 * b ^ 4 + 1) * (5 * b)) *
          (m + 1) ^ 11) * (250000000000 : ℕ) ^ 2 := Nat.mul_le_mul_right _ hQ
      _ = _ := by dsimp only [C]; ring
  have hword (d : ℕ) (h : d ≤ Q * (250000000000 : ℕ) ^ 2) : Nat.clog 2 d ≤ W :=
    Nat.clog_le_of_le_pow (polynomial_index_word_bound (h.trans hC)).le
  change c.stopGrid.denominator ≤ Q * (250000000000 : ℕ) ^ 2 ∧
    c.neighborGrid.denominator ≤ Q * (250000000000 : ℕ) ^ 2 ∧
    c.edgeGrid.denominator ≤ Q * (250000000000 : ℕ) ^ 2 at hd
  obtain ⟨hs, hn, he⟩ := familyChoiceGrid_wordWidths c
  exact ⟨hs.trans_le (hword c.stopGrid.denominator hd.1),
    hn.trans_le (hword c.neighborGrid.denominator hd.2.1),
    he.trans_le (hword c.edgeGrid.denominator hd.2.2)⟩



end

end SubmodularMatching.UpperBoundAssembly
