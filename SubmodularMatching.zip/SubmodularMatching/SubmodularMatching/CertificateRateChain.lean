import SubmodularMatching.CertificateChecks
import SubmodularMatching.SourcePath

/-!
# The finite checker premises for the actual rounded streaming run

The recursive hypotheses use the same static geometry tests as the source
checker. The analytic inequality in each rate interval follows from the
finite endpoint tests and requires no universal inequalities in the prices.
-/

namespace SubmodularMatching.SourceCertificate

open Streaming

noncomputable section

/-- The common grid of the two potential functions. The count is the number
of intervals, so finite data consist of entries 0 through count. -/
structure SourceKnots where
  count : ℕ
  knot : ℕ → ℝ
  first : knot 0 = 0
  nonnegative : ∀ i ≤ count, 0 ≤ knot i

def SourceKnots.PiecewiseAffine (K : SourceKnots) (F : ℝ → ℝ) : Prop :=
  (∀ i < K.count, ∃ slope intercept,
      ∀ z, K.knot i ≤ z → z ≤ K.knot (i + 1) → F z = slope * z + intercept) ∧
    (∀ z, K.knot K.count ≤ z → F z = F (K.knot K.count))

theorem SourceKnots.zero_mem_clip (K : SourceKnots) {bound : ℝ} (hb : 0 ≤ bound) :
    (0 : ℝ) ∈ clippedKnots K.knot K.count bound := by
  apply Finset.mem_insert_of_mem
  exact Finset.mem_filter.mpr ⟨Finset.mem_image.mpr
    ⟨0, Finset.mem_range.mpr (Nat.succ_pos _), K.first⟩, hb⟩

def SourceKnots.EndpointChecks (K : SourceKnots) (U V : ℝ → ℝ)
    (k c target : ℝ) : Prop :=
  0 < c ∧ c ≤ 1 ∧
  if hc : c < 1 then
    let gx := clippedKnots K.knot K.count (1 / c)
    let gy := clippedKnots K.knot K.count (1 / (1 - c))
    (∀ a ∈ gx, ∀ ha : c * a ≤ 1,
      let hzero := K.zero_mem_clip (bound := 1 / (1 - c))
        (div_nonneg zero_le_one (sub_nonneg.mpr hc.le))
      target ≤ U a - k * c * a +
        (rowTerms gy V k c a).min' (rowTerms_nonempty gy V k c a hzero ha) + k) ∧
    (∀ a ∈ gx, c * a ≤ 1 → target ≤ U a + V ((1 - c * a) / (1 - c))) ∧
    (∀ d ∈ gy, (1 - c) * d ≤ 1 → target ≤ U ((1 - (1 - c) * d) / c) + V d)
  else
    (∀ a ∈ (Finset.range (K.count + 1)).image K.knot, a ≤ 1 →
      target ≤ U a + V 0 + k * (1 - a)) ∧ target ≤ U 1 + V 0

theorem SourceKnots.endpoint_checks_sound (K : SourceKnots) (U V : ℝ → ℝ) (k c target : ℝ)
    (hU : Monotone U) (hV : Monotone V)
    (hu : K.PiecewiseAffine U) (hv : K.PiecewiseAffine V)
    (hcheck : K.EndpointChecks U V k c target)
    (a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d) :
    target ≤ gridValue U V k c a d := by
  obtain ⟨hc, hc1, he⟩ := hcheck
  by_cases hc' : c = 1
  · subst c
    simp only [lt_self_iff_false, dite_false] at he
    apply grid_checks_sound_at_one U V (clippedKnots K.knot K.count 1) k target
      hU hV (clippedKnots_cover _ _ _ _ K.first hu.1 hu.2) _ _ a d ha hd
    · intro x hx hx1
      rw [clippedKnots, Finset.mem_insert] at hx
      rw [gridValue, one_mul, sub_self, zero_mul, sub_zero, max_eq_left (sub_nonneg.mpr hx1)]
      rcases hx with rfl | hx
      · simpa only [sub_self, mul_zero, add_zero] using he.2
      · exact he.1 x (Finset.mem_filter.mp hx).1 hx1
    · simpa [gridValue] using he.2
  · have hclt := lt_of_le_of_ne hc1 hc'
    have hxa : 0 ≤ 1 / c := div_nonneg zero_le_one hc.le
    have hya : 0 ≤ 1 / (1 - c) := div_nonneg zero_le_one (sub_nonneg.mpr hc1)
    rw [dif_pos hclt] at he
    apply finite_endpoint_checks U V _ _ k c target hc hclt hU hV
      (clippedKnots_cover _ _ _ _ K.first hu.1 hu.2)
      (clippedKnots_cover _ _ _ _ K.first hv.1 hv.2)
      (K.zero_mem_clip hya) he.1 he.2.1 he.2.2
      (clippedKnots_nonnegative _ _ _ hxa K.nonnegative)
      (clippedKnots_nonnegative _ _ _ hya K.nonnegative) a d ha hd

theorem SourceKnots.piecewiseAffine_mul {K : SourceKnots} {F : ℝ → ℝ}
    (hF : K.PiecewiseAffine F) (s : ℝ) : K.PiecewiseAffine (fun z => s * F z) := by
  constructor
  · intro i hi
    obtain ⟨m, b, hlin⟩ := hF.1 i hi
    refine ⟨s * m, s * b, fun z hz hz' => ?_⟩
    dsimp only
    rw [hlin z hz hz']
    ring
  · intro z hz
    dsimp only
    rw [hF.2 z hz]

def SourceKnots.RateCheck (K : SourceKnots) (H J : SourceFunction)
    (sH sL k sigma mH mL : ℝ) (rate : PotentialStage) (ratio : ℝ) : Prop :=
  K.EndpointChecks (fun a => sH * rate.highRate * H.value a)
    (fun d => sL * rate.lowRate * J.value d) k ratio
    (sigma * (1 + mH * rate.highRate + mL * rate.lowRate))

theorem SourceKnots.rateLocal_of_checks (K : SourceKnots) (H J : SourceFunction)
    (sH sL k sigma mH mL : ℝ) (rate : PotentialStage) (lo hi : ℝ)
    (hsH : 0 ≤ sH * rate.highRate) (hsL : 0 ≤ sL * rate.lowRate)
    (hmH : Monotone H.value) (hmJ : Monotone J.value)
    (hH : K.PiecewiseAffine H.value) (hJ : K.PiecewiseAffine J.value)
    (hl : K.RateCheck H J sH sL k sigma mH mL rate lo)
    (hh : K.RateCheck H J sH sL k sigma mH mL rate hi) :
    RateLocal H J sH sL k sigma mH mL rate lo hi := by
  intro a d ha hd
  constructor
  · exact K.endpoint_checks_sound _ _ k lo _
      (fun _ _ h => mul_le_mul_of_nonneg_left (hmH h) hsH)
      (fun _ _ h => mul_le_mul_of_nonneg_left (hmJ h) hsL)
      (K.piecewiseAffine_mul hH _) (K.piecewiseAffine_mul hJ _) hl a d ha hd
  · exact K.endpoint_checks_sound _ _ k hi _
      (fun _ _ h => mul_le_mul_of_nonneg_left (hmH h) hsH)
      (fun _ _ h => mul_le_mul_of_nonneg_left (hmJ h) hsL)
      (K.piecewiseAffine_mul hH _) (K.piecewiseAffine_mul hJ _) hh a d ha hd

/-- The numerical conditions mirror the decreasing sequence of rate
intervals in the actual streaming procedure. At each boundary only the
sparse grid checks are required. -/
def SourceKnots.CheckedRateChain (K : SourceKnots) (H J : SourceFunction)
    (sH sL k sigma mH mL Cmax : ℝ) (base : PotentialStage) : List PotentialStage → ℝ → Prop
  | [], upper => (1 / 2 : ℝ) ≤ upper ∧ base.highRate = base.lowRate ∧
      0 < base.lowRate ∧ base.highRate + base.lowRate ≤ Cmax ∧
      K.RateCheck H J sH sL k sigma mH mL base (1 / 2) ∧
      K.RateCheck H J sH sL k sigma mH mL base upper
  | r :: rs, upper => (1 / 2 : ℝ) ≤ r.boundary ∧ r.boundary ≤ upper ∧
      r.lowRate ≤ r.highRate ∧ 0 < r.lowRate ∧
      r.highRate < r.boundary * (r.highRate + r.lowRate) ∧
      r.highRate + r.lowRate ≤ Cmax ∧
      K.RateCheck H J sH sL k sigma mH mL r r.boundary ∧
      K.RateCheck H J sH sL k sigma mH mL r upper ∧
      K.CheckedRateChain H J sH sL k sigma mH mL Cmax base rs r.boundary

theorem SourceKnots.rateChain_of_checks (K : SourceKnots) (H J : SourceFunction)
    (sH sL k sigma mH mL Cmax : ℝ) (hsH : 0 ≤ sH) (hsL : 0 ≤ sL)
    (hmH : Monotone H.value) (hmJ : Monotone J.value)
    (hH : K.PiecewiseAffine H.value) (hJ : K.PiecewiseAffine J.value)
    (base : PotentialStage) (rs : List PotentialStage) (upper : ℝ)
    (checks : K.CheckedRateChain H J sH sL k sigma mH mL Cmax base rs upper) :
    RateChain H J sH sL k sigma mH mL Cmax base rs upper := by
  induction rs generalizing upper with
  | nil =>
    obtain ⟨hb, hbal, hp, hcap, hlo, hhi⟩ := checks
    have hh : 0 ≤ base.highRate := by rw [hbal]; exact hp.le
    exact ⟨hb, hbal, hp, hcap, K.rateLocal_of_checks H J sH sL k sigma mH mL
      base (1 / 2) upper (mul_nonneg hsH hh) (mul_nonneg hsL hp.le)
      hmH hmJ hH hJ hlo hhi⟩
  | cons r rs ih =>
    obtain ⟨hb, hbound, hbalance, hp, hdrift, hcap, hlo, hhi, htail⟩ := checks
    exact ⟨hb, hbound, hbalance, hp, hdrift, hcap,
      K.rateLocal_of_checks H J sH sL k sigma mH mL r r.boundary upper
        (mul_nonneg hsH (hp.le.trans hbalance)) (mul_nonneg hsL hp.le) hmH hmJ hH hJ hlo hhi,
      ih r.boundary htail⟩

end

end SubmodularMatching.SourceCertificate
