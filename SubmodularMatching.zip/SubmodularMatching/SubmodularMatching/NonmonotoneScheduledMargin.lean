import SubmodularMatching.NonmonotoneScheduledRow
import SubmodularMatching.NonmonotoneTrialRange
import SubmodularMatching.NonmonotoneStreamingCharge

/-! Conditional guarantee of the fixed finite schedule on a normalized physical action. -/
namespace SubmodularMatching.NonmonotoneCandidate
open GibbsMatching GibbsSampler UpperBoundAssembly TwoStage TwoLayerDiffuse VarianceBound Shearer ShearerCappedSampler Capacity AppendixM Streaming
open scoped BigOperators
noncomputable section

variable {I C V : Type*} [LinearOrder I] [Fintype I] [LinearOrder C] [Fintype V] [DecidableEq V]

theorem frozen_sum_bound (seq : ℕ→I) (m : ℕ) (p : ℝ) (hp : 0≤p ∧ p≤1) (f : Finset I→ℝ)
    (hf : IsSubmodular f) (hn : ∀ U, 0≤f U) (τ : ℝ) (hs : ∀ i, f {i}≤τ)
    (wh : ℕ→ℝ) (hw : ∀ i<m, wh i≤arrivalWeight seq p f i) :
    ∑ i∈Finset.range m, wh i ≤ (m:ℝ)*τ := by
  have h (i : ℕ) : arrivalWeight seq p f i ≤ τ := by
    unfold arrivalWeight
    have hτ := (hn {seq i}).trans (hs _)
    have htop (A : Finset I) : marginal f (seq i) A≤τ := by
      by_cases he : seq i ∈ A
      · simpa [marginal,Finset.union_eq_left.mpr (Finset.singleton_subset_iff.mpr he)] using hτ
      · have h := signed_disjoint_singleton_charge f hf (hn ∅) A {seq i} (Finset.disjoint_singleton_right.mpr he)
        simp only [Finset.sum_singleton] at h
        unfold marginal
        linarith only [h,hs (seq i)]
    exact (bernoulliExpectation_mono seq (fun _=>p) _ (fun _=>τ) i (fun _ _ => hp) htop).trans_eq (bernoulliExpectation_const _ _ _ _)
  simpa only [Finset.sum_const,Finset.card_range,nsmul_eq_mul] using
    Finset.sum_le_sum (s:=Finset.range m) (fun i hi => (hw i (Finset.mem_range.mp hi)).trans (h i))

/-- Quantities depending only on the public dimension/guess tuple. -/
def priorityRange (n : ℕ) (τ : ℝ) : ℝ := ((n:ℝ)+1)*τ
def diffuseError (K vertices : ℕ) : ℝ := 3*(sourceProbability:ℝ)*(2*((vertices:ℝ)/pairScanGrid K))+2/assignedGrid K
def slotSamplerError (K slotCount : ℕ) : ℝ := (slotCount:ℝ)/layerGrid K+layerTolerance K+layerTolerance K

theorem scheduled_margin {cap : V → ℕ} (base : C → Finset (Slots cap)) (active : Finset C)
    (orig : I → V×V) (lab : C → I) (copy : I → C) (hlabel : ∀ i, lab (copy i)=i)
    {v : ℕ} (slot : Fin v ↪ Slots cap) (ep : I → Fin v×Fin v) (geom : ∀ i,
      base (copy i)=pairEnds (fun j => (slot (ep j).1,slot (ep j).2)) i)
    (hgeom : ∀ c ∈ active ∪ Finset.univ.image copy, ∀ j, touches orig j (lab c) → ∃ w ∈ base c, w.1=j)
    (one two : Input base active) (hend : ∀ e∈active,(base e).Nonempty)
    (y₁ y₂ : C→ℝ) (hy₁ : InteriorLaw base active y₁) (hy₂ : InteriorLaw base active y₂)
    (order : ℕ→I) (m : ℕ) (hm : m=Fintype.card I) (cover : (Finset.univ:Finset I) ⊆ replacementPrefix order m)
    (hi : ∀ j<m,∀ l<m,order j=order l→j=l) (loop : ∀ i, (ep i).1 ≠ (ep i).2) (simple : Function.Injective (pairEnds ep))
    (f : Finset I→ℝ) (hf : IsSubmodular f) (hn : ∀ U,0≤f U) (τ opt : ℝ) (ht : 0<τ) (hto : τ≤2*opt)
    (hzero : f ∅≤τ) (hsingle : ∀ i, f {i}≤τ)
    (G P res h₀ F : ℝ) (wh : ℕ→ℝ) (x : I→ℝ) (hG : 0≤G)
    (hw : ∀ i<m,0≤wh i ∧ wh i≤arrivalWeight order sourceProbability f i)
    (hlin : ∑ i∈Finset.range m,wh i*x (order i) ≤ G)
    (hbase : h₀≤f ∅+G+3*(streamTolerance:ℝ)*τ)
    (hcharge : (1-(sourceProbability:ℝ))*opt ≤ f ∅+G+P+res+6*(streamTolerance:ℝ)*τ)
    (hact : (alpha+1/1000000)*G+beta*P+beta*res-(alpha-beta)*h₀-implementationUnit*opt/2 ≤
      (∑ i∈Finset.range m,wh i*x (order i))+gamma*F) :
    let K := trialScale active.card (Fintype.card I) (Fintype.card V)
    let a := firstBins K
    let b := secondBins K
    let H := priorityRange (Fintype.card I) τ
    let loss := priorityLossBudget active.card (Fintype.card I) (trialTimeGrid K) H (oracleTolerance K τ) 0
    ∀ num : Marked base active a × Marked base active b → I → ℕ,
    (variation Finset.univ (Shearer.probability base active y₁) (outcomeLaw one (layerTolerance K)
      (scheduledRow base active one two (Fintype.card I) (Fintype.card V) τ hend num).hδ (layerSampleCap (Fintype.card I) K)).mass ≤ 1/(K:ℝ)^2) →
    (variation Finset.univ (Shearer.probability base active y₂) (outcomeLaw two (layerTolerance K)
      (scheduledRow base active one two (Fintype.card I) (Fintype.card V) τ hend num).hδ (layerSampleCap (Fintype.card I) K)).mass ≤ 1/(K:ℝ)^2) →
    (∀ z i, (num z i:ℝ)/(assignedGrid K) ≤ sourceProbability) →
    (∀ z w, gridLoadNumerator (pairEnds (fun i => (slot (ep i).1,slot (ep i).2))) Finset.univ (num z) w ≤ assignedGrid K) →
    (∀ z i, num z i ≠ 0 → vacant base active (slot (ep i).1) (forgetMark z.1,forgetMark z.2)=1 ∧
      vacant base active (slot (ep i).2) (forgetMark z.1,forgetMark z.2)=1) →
    (∀ i, (1-roundingTolerance)*x i-diffuseError K (Fintype.card V) ≤
      finiteMean (nativeMarkedPair base active a b y₁ y₂) (fun z => (num z i:ℝ)/assignedGrid K)) →
    (∀ estimate : PriorityEstimate C, (∀ A e, |estimate A e-
      marginal (shiftResidual order sourceProbability f m) (binLabel lab e) (A.image (binLabel lab))|≤ oracleTolerance K τ) →
      gamma*F-loss ≤ finiteMean (nativeMarkedPair base active a b y₁ y₂) (fun z =>
        residualValue order sourceProbability f m (priorityLabels base active a b lab (shiftResidual order sourceProbability f m) estimate z))) →
    let row := scheduledRow base active one two (Fintype.card I) (Fintype.card V) τ hend num
    let out := row.run ep Finset.univ (Function.Embedding.refl I) lab order m sourceProbability (by norm_num [sourceProbability]) f
    (∀ M∈out.outcomes, Capacity.feasible orig cap M) ∧
      (1000/4727+3*implementationUnit)*opt ≤ expected out.outcomes out.mass f := by
  intro K a b H loss num h₁ h₂ hc hl hs hr hprio row out
  have hh := trialScale_bounds active.card (Fintype.card I) (Fintype.card V)
  have hk : 2000000000≤K := hh.1
  have hk0 : 0<K := by omega
  have hk' : 1≤(K:ℝ) := by exact_mod_cast hk0
  have hsK : active.card≤K := hh.2.1
  have hvK : Fintype.card V≤K := hh.2.2.2
  have h2n : 2*(Fintype.card I+1)≤K := hh.2.2.1
  have hnK : Fintype.card I≤K := by omega
  have hmK : m≤K := hm ▸ hnK
  have H0 : 0<H := by dsimp [H,priorityRange]; positivity
  have ho : 0≤opt := by linarith only [hto,ht]
  have hτs : (Fintype.card I:ℝ)+1≤K := by exact_mod_cast (show Fintype.card I+1≤K by omega)
  have hms : (m:ℝ)+1≤K := hm ▸ hτs
  have htH : H≤(K:ℝ)*τ := mul_le_mul_of_nonneg_right hτs ht.le
  have hoH : H≤(K:ℝ)*opt := by
    have hNc : 2*((Fintype.card I:ℝ)+1)≤K := by exact_mod_cast h2n
    have a := mul_le_mul_of_nonneg_left hto (by positivity : 0≤(Fintype.card I:ℝ)+1)
    have b := mul_le_mul_of_nonneg_right hNc ho
    dsimp [H,priorityRange]
    nlinarith only [a,b]
  have hprecision := trial_score_precision K active.card m hk hsK hmK τ opt H ht hto H0 htH hoH
  have hp : 0≤(sourceProbability:ℝ) ∧ (sourceProbability:ℝ)≤1 := by norm_num [sourceProbability]
  have scale := trial_grid_widths K active.card (Fintype.card V) hk0 hsK hvK sourceProbability hp.1 hp.2
  have range := trial_value_range order sourceProbability m hp.1 hp.2 f hf hn τ hzero hsingle
  have hW := frozen_sum_bound order m sourceProbability hp f hf hn τ hsingle wh (fun i hi => (hw i hi).2)
  have hWH : (m:ℝ)*τ≤H := by
    dsimp [H,priorityRange]; rw [hm]; nlinarith only [ht]
  have hx : (1:ℝ)/((2^30:ℕ):ℝ)=roundingTolerance := by norm_num [roundingTolerance]
  have time := trial_time_widths K
  have hb₁ (est : PriorityEstimate C) (z : Marked base active a × Marked base active b)
      (M : Finset I) (_hM : M∈matchings (pairEnds ep) Finset.univ) :
      f (priorityLabels base active a b lab (shiftResidual order sourceProbability f m) est z ∪ M.image (Function.Embedding.refl I))≤H :=
    (range.1 _).2
  have cut := parameter_cutoffs
  apply physical_word_trial_margin base active orig lab copy (Function.Embedding.refl I) hlabel slot ep geom hgeom
    one two (layerTolerance K) row.hδ (layerSampleCap (Fintype.card I) K) (layerSampleCap (Fintype.card I) K) a b
    (layerTapeLength K) time.2.2.1 time.2.2.2.1 hend y₁ y₂ hy₁ hy₂ _ _ h₁ h₂
    (2^30) (assignedGrid K) (trialGibbsDivisor K) (by positivity) (by dsimp [assignedGrid]; positivity)
    (by dsimp [trialGibbsDivisor]; positivity) order m cover hi loop simple f hf hn H H0.le
    sourceProbability G F hp.1 hp.2 (hx.symm ▸ cut.2.2.1) wh x hw hlin (oracleTolerance K τ) H hprecision.1
    (fun U => (range.1 U).2) (oracleReads K) (oracleWidth K) hprecision.2.1 hprecision.2.2.2.1 num
    (diffuseError K (Fintype.card V)) loss hc hl hs (hx.symm ▸ hr) hprio hb₁ opt P res h₀
    ((alpha+1/1000000)*G+beta*P) (6*(streamTolerance:ℝ)*τ) (implementationUnit*opt/2) (3*(streamTolerance:ℝ)*τ)
    K 0 (trialTimeGrid K) (Fintype.card I) ho hG cut.2.1 (hx.symm ▸ cut.2.2.2.2.2)
    hbase hcharge le_rfl hact (error_allocation opt τ _ ho ht.le hto le_rfl)
    (by exact_mod_cast hk) H0.le (by exact_mod_cast hsK) (by exact_mod_cast hnK) hoH hoH (hW.trans (hWH.trans hoH))
    (by exact_mod_cast time.1) (by simp [trialGibbsDivisor]) hprecision.2.2.1 (by positivity)
    scale.1 le_rfl le_rfl scale.2.2 rfl hprecision.2.2.2.2

end
end SubmodularMatching.NonmonotoneCandidate
