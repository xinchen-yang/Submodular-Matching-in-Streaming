import SubmodularMatching.UpperBoundVertexCandidate
import SubmodularMatching.UpperBoundInput
import SubmodularMatching.GreedyResources
import SubmodularMatching.StreamingOnlineSample

/-! # Oracle locality before and after the stream ends -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming TwoStage GibbsSampler Joint

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable {m N K : ℕ}

omit [DecidableEq V] in
/-- The incoming estimate uses only records already present and the
current edge. Even the positive member of its pair of value queries
stays within the arrived prefix. -/
theorem concreteSourceTrial_queries_arrived (st : OnlineInstance E V) (edges : ℕ → E) (k : ℕ)
    (coins : ℕ → ℕ) (threshold : ℕ)
    (hprefix : (st.edges.map Prod.fst).toFinset ⊆ arrivedEdges edges k) :
    let e := edges k
    let s := selectDyadic (fun i => (st.edges.getD i (e, 0)).1) coins threshold st.edges.length
    s ⊆ arrivedEdges edges k ∧ insert e s ⊆ arrivedEdges edges (k + 1) := by
  intro e s
  have hs : s ⊆ arrivedEdges edges k := by
    apply (selectDyadic_subset _ _ _ _).trans
    intro b hb
    obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hb
    apply hprefix
    rw [List.getD_eq_getElem st.edges _ (Finset.mem_range.mp hi), List.mem_toFinset]
    exact List.mem_map.mpr ⟨st.edges[i]'(Finset.mem_range.mp hi),
      List.getElem_mem (Finset.mem_range.mp hi), rfl⟩
  refine ⟨hs, Finset.insert_subset_iff.mpr ⟨?_, ?_⟩⟩
  · exact Finset.mem_image.mpr ⟨k, Finset.mem_range.mpr (Nat.lt_succ_self _), rfl⟩
  · exact hs.trans (Finset.image_subset_image (Finset.range_subset_range.mpr (Nat.le_succ _)))

/-- The bound applies to every prefix of the executable sparse instance,
without any assumptions on the numeric sample estimates. -/
theorem runOnlineInstance_queries_arrived (R : GridUpdateParameters) (C : PotentialConfig)
    (hR : R.Matches C) (hd : 0 < C.gap) (ends : E → V × V) (edges : ℕ → E)
    (index : ℕ → ℕ) (k : ℕ) (coins : ℕ → ℕ) (threshold : ℕ) :
    let st := runOnlineInstance R ends (fun i => (edges i, index i)) k
    let e := edges k
    let s := selectDyadic (fun i => (st.edges.getD i (e, 0)).1) coins threshold st.edges.length
    s ⊆ arrivedEdges edges k ∧ insert e s ⊆ arrivedEdges edges (k + 1) := by
  intro st e s
  refine concreteSourceTrial_queries_arrived st edges k coins threshold ?_
  have hr := (runOnlineInstance_represents R C hR hd ends (fun i => (edges i, index i)) k).1.stored
  change (st.edges.map Prod.fst).toFinset =
    (runPotential C ends (fun i => (edges i, C.gap * index i)) k).stored at hr
  rw [hr]
  exact runPotential_stored_subset C ends _ _ k
    (fun i hi => Finset.mem_image.mpr ⟨i, Finset.mem_range.mpr hi, rfl⟩)

omit [DecidableEq E] in
/-- Each of the two derivative queries maps back to the stored edges.
Thus an optimizer execution on a final guess never accesses earlier
unstored edges or queries elements outside the arrived graph. -/
theorem compactDerivativeQuery_arrived (emb : Fin m ↪ E) (draw : Fin K → DerivativeSamples m N)
    (arrived : Finset E) (h : Finset.univ.map emb ⊆ arrived)
    (call : Fin K × Fin m × Fin N × Fin 2) :
    (derivativeQuery draw call).map emb ⊆ arrived :=
  (Finset.map_subset_map.mpr (Finset.subset_univ _)).trans h

private def localGuessCandidate (hm : 0 < m) (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N) : CandidateLaw (Finset (Fin m)) :=
  let ep := restrictEnds ends
  let t := appendixRoundedPoint ep tau w f Q draw
  let hlo := restrictEnds_loopless ends hloop
  let hv := incidentVertex_card_pos hm ends
  let hfeas := appendixRoundedPoint_feasible hm ep hlo tau w f Q draw
  let hgrid := appendixRoundedPoint_y_grid hm ep tau w f Q draw
  appendixRoundingCandidate hm ep hlo hv t.1 t.2 hfeas hgrid

private theorem localGuessCandidate_congr (hm : 0 < m) (ends ends' : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hloop' : ∀ e, (ends' e).1 ≠ (ends' e).2)
    (tau : ℝ) (w w' : Fin m → ℝ) (f f' : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (he : ends = ends') (hw : w = w') (hf : f = f') :
    localGuessCandidate hm ends hloop tau w f Q draw =
      localGuessCandidate hm ends' hloop' tau w' f' Q draw := by
  cases he
  cases hw
  cases hf
  rfl

/-- Once the stream ends, every candidate is determined by stored
endpoints, frozen weights, and value queries restricted to stored edges.
Changing data outside the stored edge set has no effect on the law. -/
theorem compactAppendixGuessCandidate_local (hm : 0 < m) (emb : Fin m ↪ E)
    (ends ends' : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hloop' : ∀ e, (ends' e).1 ≠ (ends' e).2) (tau : ℝ) (w w' : E → ℝ)
    (f f' : Finset E → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (he : ∀ i, ends (emb i) = ends' (emb i)) (hw : ∀ i, w (emb i) = w' (emb i))
    (hf : ∀ S : Finset E, S ⊆ Finset.univ.map emb → f S = f' S) :
    compactAppendixGuessCandidate hm emb ends hloop tau w f Q draw =
      compactAppendixGuessCandidate hm emb ends' hloop' tau w' f' Q draw := by
  have hEq := localGuessCandidate_congr hm (ends ∘ emb) (ends' ∘ emb)
    (fun i => hloop (emb i)) (fun i => hloop' (emb i)) tau (w ∘ emb) (w' ∘ emb)
    (reindexedObjective emb f) (reindexedObjective emb f') Q draw
    (funext he) (funext hw) (funext (fun S => hf (S.map emb)
      (Finset.map_subset_map.mpr (Finset.subset_univ _))))
  exact congrArg (fun q => q.map (Finset.map emb)) hEq

end

end SubmodularMatching.UpperBoundAssembly
