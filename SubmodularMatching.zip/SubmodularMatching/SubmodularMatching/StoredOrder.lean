import SubmodularMatching.StreamingTrace
import Mathlib.Data.List.GetD
import Mathlib.Data.List.Nodup

/-!
# Stored arrival order

The accepted arrival sequence is the compact representation of the
zero-or-p sampling mask induced by the streaming state. The theorem below
connects both the recorded marginals and the final residual objective to
this order, including when rejected arrivals occur between stored ones.
-/

namespace SubmodularMatching

variable {E : Type*} [DecidableEq E]

/-- A finite Bernoulli expectation depends only on its first `n` positions. -/
theorem bernoulliExpectation_edge_prefix (e d : ℕ → E) (q : ℕ → ℝ)
    (F : Finset E → ℝ) (n : ℕ) (h : ∀ i < n, e i = d i) :
    bernoulliExpectation e q F n = bernoulliExpectation d q F n := by
  induction n generalizing F with
  | zero => rfl
  | succ n ih =>
    rw [bernoulliExpectation_succ, bernoulliExpectation_succ, h n (Nat.lt_succ_self n)]
    rw [ih F (fun i hi => h i (Nat.lt_succ_of_lt hi)),
      ih _ (fun i hi => h i (Nat.lt_succ_of_lt hi))]

namespace Streaming

variable {V : Type*} [DecidableEq V]

/-- The chronological list of accepted edges produced by the actual run. -/
noncomputable def acceptedOrder (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) : ℕ → List E
  | 0 => []
  | n + 1 => by
      classical
      exact if acceptedAt C ends input n then
        acceptedOrder C ends input n ++ [(input n).1]
      else acceptedOrder C ends input n

theorem acceptedOrder_succ (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (n : ℕ) :
    acceptedOrder C ends input (n + 1) = (by
      classical
      exact if acceptedAt C ends input n then
        acceptedOrder C ends input n ++ [(input n).1]
      else acceptedOrder C ends input n) := rfl

/-- Compacting preserves the exact order and the membership of the stored set. -/
theorem acceptedOrder_toFinset (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (n : ℕ) :
    (acceptedOrder C ends input n).toFinset = (runPotential C ends input n).stored := by
  classical
  induction n with
  | zero => simp [acceptedOrder, runPotential, emptyPotentialState]
  | succ n ih =>
    by_cases h : acceptedAt C ends input n
    · rw [acceptedOrder_succ, if_pos h]
      simp only [List.toFinset_append, List.toFinset_cons, List.toFinset_nil, ih]
      unfold acceptedAt at h
      rw [runPotential, processPotential, if_pos h]
      simp [acceptPotential, Finset.union_comm]
    · rw [acceptedOrder_succ, if_neg h, ih]
      unfold acceptedAt at h
      rw [runPotential, processPotential, if_neg h]

/-- Sampling directly from the compact stored order is equivalent to using
the zero-or-p mask on the entire arrival sequence. -/
theorem expectation_acceptedOrder (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (defaultEdge : E) (n : ℕ) (F : Finset E → ℝ) :
    bernoulliExpectation (fun i => (input i).1) (traceProbability C ends input) F n =
      bernoulliExpectation (fun i => (acceptedOrder C ends input n).getD i defaultEdge)
        (fun _ => C.p) F (acceptedOrder C ends input n).length := by
  classical
  induction n generalizing F with
  | zero => rfl
  | succ n ih =>
    rw [bernoulliExpectation_succ, acceptedOrder_succ]
    by_cases h : acceptedAt C ends input n
    · rw [if_pos h]
      have hget : ∀ i < (acceptedOrder C ends input n).length,
          (acceptedOrder C ends input n ++ [(input n).1]).getD i defaultEdge =
            (acceptedOrder C ends input n).getD i defaultEdge :=
        fun i hi => List.getD_append _ _ _ _ hi
      have hlast : (acceptedOrder C ends input n ++ [(input n).1]).getD
          (acceptedOrder C ends input n).length defaultEdge = (input n).1 := by
        rw [List.getD_append_right _ _ _ _ le_rfl, Nat.sub_self]
        rfl
      simp only [List.length_append, List.length_singleton, bernoulliExpectation_succ,
        hlast, traceProbability, h, ↓reduceIte]
      rw [bernoulliExpectation_edge_prefix _ _ _ F _ hget,
        bernoulliExpectation_edge_prefix _ _ _ (fun A => F (A ∪ {(input n).1})) _ hget,
        ← ih F, ← ih (fun A => F (A ∪ {(input n).1}))]
    · rw [if_neg h]
      simpa [traceProbability, h] using ih F

/-- A frozen arrival weight may be compared to the marginal sampled directly
from the corresponding compact prefix. -/
theorem traceWeight_acceptedOrder (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (defaultEdge : E) (f : Finset E → ℝ) (n : ℕ) :
    traceWeight C ends input f n =
      bernoulliExpectation (fun i => (acceptedOrder C ends input n).getD i defaultEdge)
        (fun _ => C.p) (fun A => marginal f (input n).1 A)
        (acceptedOrder C ends input n).length :=
  expectation_acceptedOrder C ends input defaultEdge n _

/-- The streaming residual is exactly the residual objective on the compact
stored order. -/
theorem traceResidual_acceptedOrder (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (defaultEdge : E) (f : Finset E → ℝ) (n : ℕ) (T : Finset E) :
    traceResidual C ends input f n T =
      residualValue (fun i => (acceptedOrder C ends input n).getD i defaultEdge)
        C.p f (acceptedOrder C ends input n).length T :=
  expectation_acceptedOrder C ends input defaultEdge n _

theorem acceptedOrder_prefix (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (i n : ℕ) (hi : i ≤ n) :
    ∃ tail, acceptedOrder C ends input n = acceptedOrder C ends input i ++ tail := by
  classical
  induction n with
  | zero =>
    have : i = 0 := Nat.eq_zero_of_le_zero hi
    subst i
    exact ⟨[], by simp⟩
  | succ n ih =>
    by_cases h : i = n + 1
    · subst i
      exact ⟨[], by simp⟩
    · obtain ⟨tail, htail⟩ := ih (by omega)
      rw [acceptedOrder_succ]
      split_ifs
      · exact ⟨tail ++ [(input n).1], by rw [htail, List.append_assoc]⟩
      · exact ⟨tail, htail⟩

/-- At an accepted arrival, the actual transcript marginal is the arrival
weight in the final ordered graph at the edge's compact index. -/
theorem traceWeight_eq_final_arrivalWeight (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (defaultEdge : E) (f : Finset E → ℝ)
    (i n : ℕ) (hi : i < n) (ha : acceptedAt C ends input i) :
    let k := (acceptedOrder C ends input i).length
    let ordered := fun j => (acceptedOrder C ends input n).getD j defaultEdge
    ordered k = (input i).1 ∧ k < (acceptedOrder C ends input n).length ∧
      traceWeight C ends input f i = arrivalWeight ordered C.p f k := by
  classical
  dsimp only
  obtain ⟨tail, htail⟩ := acceptedOrder_prefix C ends input (i + 1) n (by omega)
  rw [acceptedOrder_succ, if_pos ha, List.append_assoc] at htail
  simp only [List.singleton_append] at htail
  have hlast : (acceptedOrder C ends input n).getD (acceptedOrder C ends input i).length
      defaultEdge = (input i).1 := by
    rw [htail, List.getD_append_right _ _ _ _ le_rfl, Nat.sub_self]
    rfl
  refine ⟨hlast, ?_, ?_⟩
  · simp [htail]
  · rw [traceWeight_acceptedOrder C ends input defaultEdge f i]
    unfold arrivalWeight
    dsimp only
    rw [hlast]
    apply bernoulliExpectation_edge_prefix
    intro j hj
    rw [htail, List.getD_append _ _ _ _ hj]

/-- Every compact position comes from an accepted arrival, and the compact
index counts precisely the accepted arrivals that preceded it. -/
theorem accepted_at_compact_index (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (n k : ℕ) (hk : k < (acceptedOrder C ends input n).length) :
    ∃ i < n, acceptedAt C ends input i ∧ k = (acceptedOrder C ends input i).length := by
  classical
  induction n with
  | zero => simp [acceptedOrder] at hk
  | succ n ih =>
    rw [acceptedOrder_succ] at hk
    by_cases hn : acceptedAt C ends input n
    · rw [if_pos hn, List.length_append, List.length_singleton] at hk
      by_cases hk' : k = (acceptedOrder C ends input n).length
      · exact ⟨n, Nat.lt_succ_self n, hn, hk'⟩
      · obtain ⟨i, hi, hacc, heq⟩ := ih (by omega)
        exact ⟨i, Nat.lt_succ_of_lt hi, hacc, heq⟩
    · rw [if_neg hn] at hk
      obtain ⟨i, hi, hacc, heq⟩ := ih hk
      exact ⟨i, Nat.lt_succ_of_lt hi, hacc, heq⟩

/-- Conservative arrival estimates remain conservative for the compact
stored graph. The weights refer to the original arrival of each edge. -/
theorem compact_weights_conservative (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (defaultEdge : E) (f : Finset E → ℝ)
    (n : ℕ) (weight : E → ℝ)
    (hrecord : ∀ i < n, (input i).2 = weight (input i).1)
    (haccurate : ∀ i < n, (input i).2 ≤ traceWeight C ends input f i) :
    let ordered := fun j => (acceptedOrder C ends input n).getD j defaultEdge
    ∀ k < (acceptedOrder C ends input n).length,
      weight (ordered k) ≤ arrivalWeight ordered C.p f k := by
  dsimp only
  intro k hk
  obtain ⟨i, hi, ha, heq⟩ := accepted_at_compact_index C ends input n k hk
  subst k
  obtain ⟨hget, _, hweight⟩ := traceWeight_eq_final_arrivalWeight C ends input
    defaultEdge f i n hi ha
  dsimp only at hget
  rw [hget, ← hweight, ← hrecord i hi]
  exact haccurate i hi

end Streaming

end SubmodularMatching
