import SubmodularMatching.CapacityActiveStorage

/-! Storage bound for every real execution of every live sparse capacity guess. -/
namespace SubmodularMatching.Capacity
open Streaming AppendixM
variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

theorem active_payload_storage (ends : E → V × V) (cap : V → ℕ)
    (hpos : ∀ e, 0<cap (ends e).1 ∧ 0<cap (ends e).2)
    (hnoloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (v N bits : ℕ) (hv : 2≤v) (hN : 0<N) (oracle : Finset E → ℚ)
    (hf : IsSubmodular (fun A => (oracle A:ℝ))) (hn : ∀ A, 0 ≤ (oracle A:ℝ))
    (edges : ℕ → E) (draw : ℕ → ℕ → ℕ → ℕ → ℕ) (k j : ℕ)
    (hinj : ∀ i<k, ∀ l<k, edges i = edges l → i=l)
    (Z : Finset E) (hz : feasible ends cap Z) (hm : ∀ t, feasible ends cap t → t.card≤Z.card) :
    let W := guessWidth v
    let ep := runOnlineEpoch W (guessSpan v) (edgeClock edges oracle)
    j ∈ (ep (k+1)).active W (guessSpan v) →
    ∃ st, (forwardBank ends cap hpos v N bits oracle edges draw k).lookup j = some st ∧
      st.assigned.length = st.machine.edges.length ∧
      st.machine.edges.length ≤ (1+2*(incidenceConstant*((v+1).log2+1)))*Z.card ∧
      st.machine.vertices.length ≤ 2*st.machine.edges.length := by
  intro W ep hj
  let value := edgeClock edges oracle
  let q := fun i => (value i:ℝ)
  obtain ⟨hw,hw'⟩ := guessWidth_bounds v hv
  have ha := (runOnlineEpoch_active_iff W (guessSpan v) value (le_trans (by norm_num) hw)
    hw' (k+1) j).mp hj
  let endτ := (ep (k+1)).scale j
  have he : (endτ:ℝ) = guessAnchor W q (k+1)*2^j := by
    dsimp only [endτ,OnlineEpoch.scale,ep]; push_cast
    rw [(runOnlineEpoch_real _ _ _ _).2]
  have hτ : 0<endτ := by
    apply (Rat.cast_pos (K := ℝ)).mp
    exact (ha.1.trans_le ha.2.1).trans_eq he.symm
  let C := signedConfig v hv endτ (by exact_mod_cast hτ)
  let b := guessBirth W q j (k+1)-1
  have hb : b≤k := by have h := guessBirth_lt W q j k; dsimp [b]; omega
  let w (i : ℕ) (st : SparseSlots E cap) :=
    slotWeight v N bits oracle ((ep (i+2)).scale j) (edges i) st (draw i j)
  let F (i : ℕ) (st : SparseSlots E cap) := sparseStep ends cap hpos (wordGrid v) st (edges i) (w i st)
  let run := suffixRun (sparseEmpty cap) F b
  let idx (i : ℕ) := (edges (b+i),w (b+i) (run i))
  have hrep := suffixRun_sparse ends cap hpos (wordGrid v) edges w b (k-b)
  change run (k-b) = sparseRun ends cap hpos (wordGrid v) idx (k-b) at hrep
  have hq : q = seededScale (oracle ∅) (fun i => (oracle {edges i}:ℝ)) := by
    funext i; cases i <;> rfl
  have har := ha
  change guessActive W (guessAnchor W q (k+1)) (singletonMaximum q (k+1)) j at har
  rw [hq] at har
  have hlook := forwardBank_suffix ends cap hpos v N bits hv oracle edges draw k j har
  change (forwardBank ends cap hpos v N bits oracle edges draw k).lookup j =
    some (suffixRun (sparseEmpty cap) F (signedBirth W (oracle ∅) (fun i => (oracle {edges i}:ℝ)) j k)
      (k-signedBirth W (oracle ∅) (fun i => (oracle {edges i}:ℝ)) j k)) at hlook
  have hb' : signedBirth W (oracle ∅) (fun i => (oracle {edges i}:ℝ)) j k = b := by
    dsimp only [b,signedBirth]; rw [hq]
  rw [hb'] at hlook
  refine ⟨run (k-b),hlook,?_⟩
  have hgap : 0<C.gap := by
    change 0<(streamTolerance:ℝ)*(endτ:ℝ)/(v:ℝ)^2
    positivity [show (0:ℝ)<v by exact_mod_cast (show 0<v by omega),
      show (0:ℝ)<streamTolerance by norm_num [streamTolerance]]
  have hinj' : ∀ i<k-b, ∀ l<k-b, (idx i).1=(idx l).1 → i=l := by
    intro i hi l hl h
    have hij := hinj (b+i) (by omega) (b+l) (by omega) h
    omega
  have hbox (i : ℕ) (hi : i<k-b) : C.gap*(idx i).2 ≤ C.tau := by
    have hsi : guessBirth W q j (k+1) < b+i+2 := by dsimp only [b]; omega
    have hsc := active_tick_scale W (guessSpan v) value j (k+1) (b+i+2) ha hsi (by omega)
    have hi' := active_edge_value W (guessSpan v) edges oracle j k ha (b+i) (by omega)
    have hx := slotWeight_le cap v N bits hv hN oracle hf hn endτ hτ (edges (b+i)) hi'
      (run i) (draw (b+i) j)
    change C.gap*(slotWeight v N bits oracle ((ep (b+i+2)).scale j) _ _ _) ≤ _
    rw [show (ep (b+i+2)).scale j = endτ from hsc]
    convert hx using 2
    push_cast
    rfl
  have hs := sparseRun_storage ends cap hpos (wordGrid v) C (wordGrid_matches v hv endτ _) hgap idx
    (k-b) hinj' hbox hnoloop Z hz hm
  rw [hrep]
  exact ⟨hs.1,hs.2.1.trans (Nat.mul_le_mul_right _ (Nat.add_le_add_left (Nat.mul_le_mul_left _
    (signedConfig_incidenceLimit_le v hv endτ _)) _)),hs.2.2⟩

end SubmodularMatching.Capacity
