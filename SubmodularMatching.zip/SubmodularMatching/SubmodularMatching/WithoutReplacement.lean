import SubmodularMatching.EntropyBound
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Nat.Choose.Basic

/-!
# Uniform fixed-size sampling without replacement

This module supplies the actual inclusion-probability hypothesis required by
the entropy argument, using the uniform distribution on `k`-element subsets
of a finite universe. The combinatorial count and the power bound are proved.
-/

open scoped BigOperators

namespace SubmodularMatching.Information

/-- Every successive without-replacement selection ratio is at most its
initial ratio. -/
theorem remaining_fraction_le (n k a : ℕ) (hn : 0 < n) (hkn : k ≤ n) (ha : a < k) :
    ((k - a : ℕ) : ℝ) / ((n - a : ℕ) : ℝ) ≤ (k : ℝ) / n := by
  have han : a < n := ha.trans_le hkn
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hna : (0 : ℝ) < (n - a : ℕ) := by exact_mod_cast Nat.sub_pos_of_lt han
  rw [div_le_div_iff₀ hna hn']
  rw [Nat.cast_sub ha.le, Nat.cast_sub han.le]
  have hkn' : (k : ℝ) ≤ n := by exact_mod_cast hkn
  nlinarith [mul_le_mul_of_nonneg_left hkn' (Nat.cast_nonneg a : (0 : ℝ) ≤ _)]

/-- Falling-factorial form of the without-replacement inclusion bound. -/
theorem descFactorial_ratio_le_pow (n k a : ℕ) (hn : 0 < n) (hkn : k ≤ n)
    (ha : a ≤ k) :
    (k.descFactorial a : ℝ) / n.descFactorial a ≤ ((k : ℝ) / n) ^ a := by
  induction a with
  | zero => simp
  | succ a ih =>
      have hak : a < k := ha
      have hak' : a ≤ k := Nat.le_of_lt hak
      have hremain := remaining_fraction_le n k a hn hkn hak
      have hprev := ih hak'
      rw [Nat.descFactorial_succ, Nat.descFactorial_succ]
      push_cast
      rw [mul_div_mul_comm]
      apply (mul_le_mul hremain hprev (by positivity) (by positivity)).trans_eq
      exact (pow_succ' _ _).symm

/-- Choosing an `a`-subset among `k` items has the expected falling-ratio bound. -/
theorem choose_ratio_le_pow (n k a : ℕ) (hn : 0 < n) (hkn : k ≤ n) (ha : a ≤ k) :
    (k.choose a : ℝ) / n.choose a ≤ ((k : ℝ) / n) ^ a := by
  have hfac : (a.factorial : ℝ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero a
  have h := descFactorial_ratio_le_pow n k a hn hkn ha
  rw [Nat.descFactorial_eq_factorial_mul_choose,
    Nat.descFactorial_eq_factorial_mul_choose] at h
  push_cast at h
  simpa [mul_div_mul_left _ _ hfac] using h

variable {E : Type*} [DecidableEq E]

/-- `k`-subsets containing `A` correspond bijectively to `(k-|A|)`-subsets
of the complement of `A`. -/
theorem card_supersets_fixed_size (U A : Finset E) (k : ℕ)
    (hAU : A ⊆ U) (hAk : A.card ≤ k) :
    ((U.powersetCard k).filter (A ⊆ ·)).card =
      (U.card - A.card).choose (k - A.card) := by
  classical
  rw [← Finset.card_sdiff_of_subset hAU, ← Finset.card_powersetCard]
  apply Finset.card_bij (fun S _ => S \ A)
  · intro S hS
    rcases Finset.mem_filter.mp hS with ⟨hS, hAS⟩
    rcases Finset.mem_powersetCard.mp hS with ⟨hSU, hSc⟩
    apply Finset.mem_powersetCard.mpr
    constructor
    · exact Finset.sdiff_subset_sdiff hSU (Finset.Subset.refl _)
    · rw [Finset.card_sdiff_of_subset hAS, hSc]
  · intro S hS T hT heq
    have hAS := (Finset.mem_filter.mp hS).2
    have hAT := (Finset.mem_filter.mp hT).2
    calc
      S = A ∪ (S \ A) := (Finset.union_sdiff_of_subset hAS).symm
      _ = A ∪ (T \ A) := by rw [heq]
      _ = T := Finset.union_sdiff_of_subset hAT
  · intro T hT
    rcases Finset.mem_powersetCard.mp hT with ⟨hTU, hTc⟩
    have hdisj : Disjoint A T := by
      apply Finset.disjoint_left.mpr
      intro e heA heT
      exact (Finset.mem_sdiff.mp (hTU heT)).2 heA
    refine ⟨A ∪ T, ?_, ?_⟩
    · apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_powersetCard.mpr ⟨?_, ?_⟩, Finset.subset_union_left⟩
      · exact Finset.union_subset hAU (hTU.trans Finset.sdiff_subset)
      · rw [Finset.card_union_of_disjoint hdisj, hTc]
        exact Nat.add_sub_of_le hAk
    · exact Finset.union_sdiff_cancel_left hdisj

/-- Probability mass on all finite subsets, supported exactly on `k`-subsets of `U`. -/
noncomputable def uniformSubsetMass (U : Finset E) (k : ℕ) (S : Finset E) : ℝ :=
  if S ∈ U.powersetCard k then (U.card.choose k : ℝ)⁻¹ else 0


/-- Nonnegativity of the uniform fixed-size mass function. -/
theorem uniformSubsetMass_nonneg (U : Finset E) (k : ℕ) (S : Finset E) :
    0 ≤ uniformSubsetMass U k S := by
  unfold uniformSubsetMass
  split_ifs <;> positivity

variable [Fintype E]

/-- The fixed-size sampling mass is normalized. -/
theorem sum_uniformSubsetMass (U : Finset E) (k : ℕ) (hk : k ≤ U.card) :
    (∑ S : Finset E, uniformSubsetMass U k S) = 1 := by
  have hc : (U.card.choose k : ℝ) ≠ 0 := by exact_mod_cast Nat.choose_ne_zero hk
  simp only [uniformSubsetMass]
  rw [← Finset.sum_filter]
  have heq : (Finset.univ.filter (fun S : Finset E => S ∈ U.powersetCard k)) =
      U.powersetCard k := by
    ext S
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  rw [heq]
  simp [hc, Finset.card_powersetCard]

/-- Exact inclusion probability as a ratio of finite family cardinalities. -/
theorem uniformSubsetMass_inclusion_eq (U A : Finset E) (k : ℕ) :
    (∑ S : Finset E, if A ⊆ S then uniformSubsetMass U k S else 0) =
      (((U.powersetCard k).filter (A ⊆ ·)).card : ℝ) / U.card.choose k := by
  classical
  have h (S : Finset E) :
      (if A ⊆ S then uniformSubsetMass U k S else 0) =
        if S ∈ (U.powersetCard k).filter (A ⊆ ·) then (U.card.choose k : ℝ)⁻¹ else 0 := by
    unfold uniformSubsetMass
    by_cases hAS : A ⊆ S <;> by_cases hS : S ∈ U.powersetCard k <;> simp [hAS, hS]
  simp_rw [h]
  rw [← Finset.sum_filter]
  have heq : (Finset.univ.filter (fun S : Finset E =>
      S ∈ (U.powersetCard k).filter (A ⊆ ·))) = (U.powersetCard k).filter (A ⊆ ·) := by
    ext S
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  rw [heq]
  simp [div_eq_mul_inv]

/-- The exact without-replacement containment bound, including requirements
outside the universe and requirements larger than the sample size. -/
theorem uniformSubsetMass_inclusion_le (U A : Finset E) (k : ℕ)
    (hU : 0 < U.card) (hk : k ≤ U.card) :
    (∑ S : Finset E, if A ⊆ S then uniformSubsetMass U k S else 0) ≤
      ((k : ℝ) / U.card) ^ A.card := by
  rw [uniformSubsetMass_inclusion_eq]
  by_cases hAU : A ⊆ U
  · by_cases hAk : A.card ≤ k
    · rw [card_supersets_fixed_size U A k hAU hAk]
      have hnk : (U.card.choose k : ℝ) ≠ 0 := by exact_mod_cast Nat.choose_ne_zero hk
      have hna : (U.card.choose A.card : ℝ) ≠ 0 := by
        exact_mod_cast Nat.choose_ne_zero (hAk.trans hk)
      have hratio : ((U.card - A.card).choose (k - A.card) : ℝ) / U.card.choose k =
          (k.choose A.card : ℝ) / U.card.choose A.card := by
        apply (div_eq_div_iff hnk hna).2
        have hc := Nat.choose_mul (n := U.card) hAk
        exact_mod_cast (show (U.card - A.card).choose (k - A.card) *
          U.card.choose A.card = k.choose A.card * U.card.choose k by nlinarith [hc])
      rw [hratio]
      exact choose_ratio_le_pow U.card k A.card hU hk hAk
    · have hempty : (U.powersetCard k).filter (A ⊆ ·) = ∅ := by
        apply Finset.filter_eq_empty_iff.mpr
        intro S hS hAS
        have hc := Finset.card_le_card hAS
        rw [(Finset.mem_powersetCard.mp hS).2] at hc
        exact hAk hc
      rw [hempty, Finset.card_empty, Nat.cast_zero, zero_div]
      positivity
  · have hempty : (U.powersetCard k).filter (A ⊆ ·) = ∅ := by
      apply Finset.filter_eq_empty_iff.mpr
      intro S hS hAS
      exact hAU (hAS.trans (Finset.mem_powersetCard.mp hS).1)
    rw [hempty, Finset.card_empty, Nat.cast_zero, zero_div]
    positivity


/-- Exact inclusion probability expressed by the ratio of binomial coefficients
on the number of specified elements. This also covers `|A| > k`. -/
theorem uniformSubsetMass_inclusion_choose_ratio (U A : Finset E) (k : ℕ)
    (hAU : A ⊆ U) (hk : k ≤ U.card) :
    (∑ S : Finset E, if A ⊆ S then uniformSubsetMass U k S else 0) =
      (k.choose A.card : ℝ) / U.card.choose A.card := by
  rw [uniformSubsetMass_inclusion_eq]
  by_cases hAk : A.card ≤ k
  · rw [card_supersets_fixed_size U A k hAU hAk]
    have hnk : (U.card.choose k : ℝ) ≠ 0 := by exact_mod_cast Nat.choose_ne_zero hk
    have hna : (U.card.choose A.card : ℝ) ≠ 0 := by
      exact_mod_cast Nat.choose_ne_zero (Finset.card_le_card hAU)
    apply (div_eq_div_iff hnk hna).2
    have hc := Nat.choose_mul (n := U.card) hAk
    exact_mod_cast (show (U.card - A.card).choose (k - A.card) *
      U.card.choose A.card = k.choose A.card * U.card.choose k by nlinarith [hc])
  · have hempty : (U.powersetCard k).filter (A ⊆ ·) = ∅ := by
      apply Finset.filter_eq_empty_iff.mpr
      intro S hS hAS
      have hc := Finset.card_le_card hAS
      rw [(Finset.mem_powersetCard.mp hS).2] at hc
      exact hAk hc
    rw [hempty, Finset.card_empty, Nat.cast_zero, zero_div,
      Nat.choose_eq_zero_of_lt (Nat.lt_of_not_ge hAk), Nat.cast_zero, zero_div]

/-- The entropy/certainty theorem instantiated for actual uniform fixed-size
sampling, with no inclusion-probability assumption remaining. -/
theorem uniformSubset_certainty_entropy_bound {Y : Type*}
    [Fintype Y] [Nonempty Y] (U : Finset E) (k s : ℕ)
    (state : Finset E → Y) (hk0 : 0 < k) (hk1 : k < U.card)
    (hstates : Fintype.card Y ≤ 2 ^ s) :
    (∑ S : Finset E, uniformSubsetMass U k S *
      (certainty (uniformSubsetMass U k) id state (state S)).card) ≤
      s / Real.logb 2 (1 / ((k : ℝ) / U.card)) := by
  have hn : (0 : ℝ) < U.card := by exact_mod_cast hk0.trans hk1
  apply certainty_entropy_bound_on_samples (uniformSubsetMass U k) id state
    ((k : ℝ) / U.card) s (uniformSubsetMass_nonneg U k)
    (sum_uniformSubsetMass U k hk1.le) _ _ _ hstates
  · exact div_pos (by exact_mod_cast hk0) hn
  · exact (div_lt_one hn).2 (by exact_mod_cast hk1)
  · intro A
    exact uniformSubsetMass_inclusion_le U A k (hk0.trans hk1) hk1.le

end SubmodularMatching.Information
