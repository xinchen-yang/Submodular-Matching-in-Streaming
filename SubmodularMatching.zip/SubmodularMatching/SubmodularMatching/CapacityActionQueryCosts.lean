import SubmodularMatching.NonmonotoneAdaptiveOptimizer
import SubmodularMatching.NonmonotoneActionWordCost
import SubmodularMatching.CapacitySignedCommonResources

/-! Original-oracle requests for the actual signed action gradient and score. -/
namespace SubmodularMatching.NonmonotoneOptimizer
open Streaming Finset
noncomputable section
variable {E : Type*} [DecidableEq E] {n l m bits : ℕ} [NeZero n]

def keyCalls : ActionKey n → ℕ
  | .inl _ => 2
  | .inr _ => 1

/-- Evaluate one oracle query and count its original oracle requests. -/
def countedActionEvaluation (B : BlockData E n l) (r : Vec l) (F : Finset E→ℝ)
    (A : Finset E) : ActionKey n → ℝ × ℕ
  | .inl (_,i) => (F (A∪{B.orderedEdge r i})-F A,2)
  | .inr _ => (F A,1)

theorem countedActionEvaluation_exact (B : BlockData E n l) (r : Vec l) (h : ℕ→E) (p : ℕ→ℝ)
    (F : Finset E→ℝ) (hp : ∀ i < m, 0≤p i ∧ p i≤1) (A : Finset E) (j : ActionKey n) :
    countedActionEvaluation B r F A j = ((B.keyQuery r h p F hp j).evaluate A,keyCalls j) := by
  rcases j with ⟨flag,i⟩|v
  · rfl
  · cases v <;> rfl

def countedBatch (eval : (Fin n→Fin (2^bits)) → ℝ × ℕ) (d : ℚ) :
    (N : ℕ) → WordBatch N n bits → ℤ → ℕ → (ℤ × ℕ)
  | 0,_,z,c => (z,c)
  | N+1,w,z,c =>
      let ans := eval (w 0)
      countedBatch eval d N (Fin.tail w) (z+⌊4*ans.1/(d:ℝ)⌋) (c+ans.2)

omit [NeZero n] in
theorem countedBatch_exact (eval : (Fin n→Fin (2^bits)) → ℝ × ℕ) (d : ℚ) (v : ℕ)
    (hc : ∀ w, (eval w).2=v) (N : ℕ) (w : WordBatch N n bits) (z : ℤ) (c : ℕ) :
    countedBatch eval d N w z c = (z+sourceIndex d (fun r => (eval (w r)).1),c+N*v) := by
  induction N generalizing z c with
  | zero => simp [countedBatch,sourceIndex]
  | succ n ih =>
    rw [countedBatch,ih,hc]
    simp only [sourceIndex]
    rw [Fin.sum_univ_succ (f := fun r : Fin (n+1) => ⌊4*(eval (w r)).1/(d:ℝ)⌋)]
    simp only [Fin.tail,sourceIndex,Nat.succ_mul]
    congr 1 <;> ring

theorem counted_word_batch (B : BlockData E n l) (r : Vec l) (h : ℕ→E) (p : ℕ→ℝ)
    (F : Finset E→ℝ) (hp : ∀ i < m, 0≤p i ∧ p i≤1) (d : ℚ) (j : ActionKey n) (N : ℕ) :
    let Q := B.keyQuery r h p F hp j
    let eval := fun w => countedActionEvaluation B r F
      (selectWordVector Q.edges Q.extendedProb Q.size bits w) j
    ∀ w : WordBatch N Q.size bits,
      countedBatch eval d N w 0 0 = (sourceIndex d (fun i => Q.wordValue bits (w i)),N*keyCalls j) := by
  intro Q eval w
  have he (u : Fin Q.size→Fin (2^bits)) : eval u = (Q.wordValue bits u,keyCalls j) :=
    countedActionEvaluation_exact B r h p F hp _ j
  rw [countedBatch_exact eval d (keyCalls j) (fun u => congrArg Prod.snd (he u))]
  simp only [he,zero_add]

theorem action_oracle_calls (n l J : ℕ) :
    let N := actionBatch l J
    let T := ascentFuel (paperExponent l)
    (∑ j : ActionKey n, N*keyCalls j)*T = (4*n+2)*N*T ∧
      (4*n+2)*N*T ≤ (4*n+2)*(4*8^4*J*(2^37*(l+1))^40+1)*(2^37*(l+1))^8 := by
  intro N T
  constructor
  · rw [Fintype.sum_sum_type,Fintype.sum_prod_type]
    simp [keyCalls]
    ring_nf <;> simp
  · have ht : T ≤ (2^37*(l+1))^8 := Nat.pow_le_pow_left (paperScale_bounds l).2.2 _
    exact Nat.mul_le_mul (Nat.mul_le_mul_left _ (action_batch_polynomial l J)) ht

end
end SubmodularMatching.NonmonotoneOptimizer
