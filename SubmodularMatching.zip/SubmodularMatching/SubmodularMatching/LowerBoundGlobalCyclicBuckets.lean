import SubmodularMatching.LowerBoundGlobalAJXHosts
import Mathlib.Data.ZMod.Basic

/-! # Buffered colors on a cyclic coordinate group

Using a cyclic coordinate group in the ERS construction keeps every
translated edge inside the vertex universe. The buffer between color
intervals prevents a small cross-group shift from changing a color.
-/

namespace SubmodularMatching.LowerBoundGlobal.AJX

noncomputable section

variable {C B W : ℕ} [NeZero (C * (B + W))]

abbrev BufferedRing (C B W : ℕ) := ZMod (C * (B + W))

omit [NeZero (C * (B + W))] in
private theorem period_pos (hQ : C * (B + W) ≠ 0) : 0 < B + W := by
  apply Nat.pos_of_ne_zero
  intro h
  exact hQ (by rw [h, Nat.mul_zero])

def bufferedColor (z : BufferedRing C B W) : Option (Fin C) :=
  if z.val % (B + W) < B then
    some ⟨z.val / (B + W), (Nat.div_lt_iff_lt_mul (period_pos (C := C) (NeZero.ne _))).mpr (ZMod.val_lt z)⟩
  else none

theorem bufferedColor_iff (z : BufferedRing C B W) (a : Fin C) :
    bufferedColor z = some a ↔ a.val * (B + W) ≤ z.val ∧ z.val < a.val * (B + W) + B := by
  have hdecomp := Nat.mod_add_div z.val (B + W)
  constructor
  · intro h
    unfold bufferedColor at h
    split_ifs at h with hrem
    have ha : z.val / (B + W) = a.val := congrArg Fin.val (Option.some.inj h)
    rw [ha, Nat.mul_comm (B + W)] at hdecomp
    omega
  · rintro ⟨hl, hr⟩
    have hv : z.val / (B + W) = a.val := Nat.div_eq_of_lt_le hl (by
      rw [Nat.add_mul, Nat.one_mul]
      omega)
    rw [hv, Nat.mul_comm (B + W)] at hdecomp
    have hh : z.val % (B + W) < B := by omega
    unfold bufferedColor
    rw [if_pos hh, Option.some_inj]
    exact Fin.ext hv

omit [NeZero (C * (B + W))] in
private theorem residue_in_range (a : Fin C) {offset : ℕ} (hoff : offset < B + W) :
    a.val * (B + W) + offset < C * (B + W) := calc
  _ < a.val * (B + W) + (B + W) := Nat.add_lt_add_left hoff _
  _ = (a.val + 1) * (B + W) := by ring
  _ ≤ _ := Nat.mul_le_mul_right _ a.isLt

/-- Every nonempty buffered color has exactly the same number of residues. -/
def bufferedColorEquiv (a : Fin C) : Fin B ≃ {z : BufferedRing C B W // bufferedColor z = some a} where
  toFun r :=
    ⟨((a.val * (B + W) + r.val : ℕ) : BufferedRing C B W), by
      apply (bufferedColor_iff _ a).mpr
      rw [ZMod.val_natCast_of_lt (residue_in_range a (by omega))]
      omega⟩
  invFun z :=
    ⟨z.val.val - a.val * (B + W), by
      obtain ⟨hl, hr⟩ := (bufferedColor_iff z.val a).mp z.property
      omega⟩
  left_inv := by
    intro r
    apply Fin.ext
    change (((a.val * (B + W) + r.val : ℕ) : BufferedRing C B W).val - a.val * (B + W)) = r.val
    rw [ZMod.val_natCast_of_lt (residue_in_range a (by omega)), Nat.add_sub_cancel_left]
  right_inv := by
    intro z
    apply Subtype.ext
    change (((a.val * (B + W) + (z.val.val - a.val * (B + W)) : ℕ) :
      BufferedRing C B W)) = z.val
    rw [Nat.add_sub_of_le ((bufferedColor_iff z.val a).mp z.property).1, ZMod.natCast_zmod_val]

theorem bufferedColor_shift_to (z : BufferedRing C B W) {a b : Fin C} {shift : ℕ}
    (ha : bufferedColor z = some a)
    (hs : (a.val * (B + W) + shift) % (C * (B + W)) = b.val * (B + W)) :
    bufferedColor (z + (shift : BufferedRing C B W)) = some b := by
  obtain ⟨hl, hr⟩ := (bufferedColor_iff z a).mp ha
  let offset := z.val - a.val * (B + W)
  have hoff : offset < B := by dsimp [offset]; omega
  have hz : z = ((a.val * (B + W) + offset : ℕ) : BufferedRing C B W) := by
    dsimp [offset]
    rw [Nat.add_sub_of_le hl, ZMod.natCast_zmod_val]
  have hmod : b.val * (B + W) < C * (B + W) := by
    simpa only [Nat.add_zero] using residue_in_range b (offset := 0) (period_pos (C := C) (NeZero.ne _))
  have hcast : ((a.val * (B + W) + shift : ℕ) : BufferedRing C B W) =
      ((b.val * (B + W) : ℕ) : BufferedRing C B W) := by
    apply ZMod.val_injective _
    rw [ZMod.val_natCast, hs, ZMod.val_natCast_of_lt hmod]
  have heq : z + (shift : BufferedRing C B W) =
      ((b.val * (B + W) + offset : ℕ) : BufferedRing C B W) := by
    simp only [Nat.cast_add] at hcast
    rw [hz, Nat.cast_add, Nat.cast_add, ← hcast]
    ring
  apply (bufferedColor_iff _ b).mpr
  rw [heq, ZMod.val_natCast_of_lt (residue_in_range b (by omega))]
  omega

/-- A shift smaller than the gap may enter an uncolored interval, but
two colored endpoints retain the same label. -/
theorem bufferedColor_small_shift (z : BufferedRing C B W) {a b : Fin C} {shift : ℕ}
    (ha : bufferedColor z = some a)
    (hb : bufferedColor (z + (shift : BufferedRing C B W)) = some b)
    (hs : shift < W) : a = b := by
  obtain ⟨hl, hr⟩ := (bufferedColor_iff z a).mp ha
  have hu : z.val + shift < (a.val + 1) * (B + W) := by
    rw [Nat.add_mul, Nat.one_mul]
    omega
  have hrange : z.val + shift < C * (B + W) := hu.trans_le (Nat.mul_le_mul_right (B + W) a.isLt)
  have hval : (z + (shift : BufferedRing C B W)).val = z.val + shift := by
    have hshift : shift < C * (B + W) := by omega
    have hcast : (shift : BufferedRing C B W).val = shift := ZMod.val_natCast_of_lt hshift
    calc
      _ = z.val + (shift : BufferedRing C B W).val :=
        ZMod.val_add_of_lt (by rw [hcast]; exact hrange)
      _ = _ := by rw [hcast]
  have ha' : (z.val + shift) / (B + W) = a.val := Nat.div_eq_of_lt_le (by omega) hu
  obtain ⟨hl', hr'⟩ := (bufferedColor_iff _ b).mp hb
  rw [hval] at hl' hr'
  have hb' : (z.val + shift) / (B + W) = b.val :=
    Nat.div_eq_of_lt_le hl' (by rw [Nat.add_mul, Nat.one_mul]; omega)
  exact Fin.ext (ha'.symm.trans hb')

end

end SubmodularMatching.LowerBoundGlobal.AJX
