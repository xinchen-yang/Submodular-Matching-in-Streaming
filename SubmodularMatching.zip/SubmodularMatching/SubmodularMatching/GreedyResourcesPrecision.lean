import SubmodularMatching.GreedyResources

/-!
# Bounded indices for the actual finite gradient estimator

Each stage stores counts for the snapped derivative samples and a rounded
discount. Dividing by the guessed value cancels its precision in the
normalized packing coefficients.
-/

open scoped BigOperators

namespace SubmodularMatching.Joint

noncomputable section

variable {m N : ℕ}

/-- The current rounded discount always has a nonnegative index at most
the largest grid index. -/
theorem discountIndex_word_bound (base : ℝ) (Q k : ℕ)
    (hbase : 0 ≤ base) (hbase1 : base ≤ 1) :
    (discountIndex base Q k).natAbs < 2 ^ (Q.log2 + 1) := by
  have h := discountIndex_bounds base Q k hbase hbase1
  have h0 : (0 : ℤ) ≤ discountIndex base Q k := by exact_mod_cast h.1
  have hreal : (discountIndex base Q k : ℝ) ≤ Q :=
    h.2.1.trans (by
      simpa only [mul_one] using mul_le_mul_of_nonneg_left
        (pow_le_one₀ (n := k) hbase hbase1) (Nat.cast_nonneg Q : (0 : ℝ) ≤ Q))
  have hZ : discountIndex base Q k ≤ (Q : ℤ) := by exact_mod_cast hreal
  have hNat : (discountIndex base Q k).natAbs ≤ Q := by
    have hcast := Int.natAbs_of_nonneg h0
    exact_mod_cast (show ((discountIndex base Q k).natAbs : ℤ) ≤ (Q : ℤ) from hcast ▸ hZ)
  exact hNat.trans_lt Nat.lt_log2_self

/-- The integer accumulator sums at most one bounded floor per derivative
sample. This bound is valid on every transcript. -/
theorem derivative_accumulator_index_bound (ξ τ : ℝ) (hξ : 0 < ξ) (hτ : 0 < τ)
    (samples : Fin N → ℝ) (hs : ∀ i, 0 ≤ samples i ∧ samples i ≤ τ) :
    0 ≤ (Streaming.sourceIndex (ξ * τ / 2) samples : ℝ) ∧
      (Streaming.sourceIndex (ξ * τ / 2) samples : ℝ) ≤ (N : ℝ) * (8 / ξ) := by
  unfold Streaming.sourceIndex
  push_cast
  have hden : 0 < ξ * τ / 2 := by positivity
  constructor
  · apply Finset.sum_nonneg
    intro i _
    exact_mod_cast Int.floor_nonneg.mpr (by have := (hs i).1; positivity : 0 ≤ 4 * samples i / (ξ * τ / 2))
  · calc
      _ ≤ ∑ _ : Fin N, 8 / ξ := by
        apply Finset.sum_le_sum
        intro i _
        apply (Int.floor_le _).trans
        calc
          _ ≤ 4 * τ / (ξ * τ / 2) := div_le_div_of_nonneg_right (by linarith [(hs i).2]) hden.le
          _ = _ := by field_simp; ring
      _ = _ := by simp

/-- Accumulate snapped derivatives in one pass over the sample indices.
Only the current integer sum and the current pair of samples are needed
if `draw` supplies each pair on demand. -/
def foldDerivativeIndex (d : ℝ) (draw : Fin N → Finset (Fin m) × Finset (Fin m))
    (f : Finset (Fin m) → ℝ) (e : Fin m) : ℤ :=
  (Finset.univ : Finset (Fin N)).toList.foldl
    (fun total i => total + ⌊4 * Multilinear.derivativeSample f e (draw i).1 (draw i).2 / d⌋) 0

theorem foldDerivativeIndex_eq (d : ℝ) (draw : Fin N → Finset (Fin m) × Finset (Fin m))
    (f : Finset (Fin m) → ℝ) (e : Fin m) :
    foldDerivativeIndex d draw f e = Streaming.sourceIndex d
      (fun i => Multilinear.derivativeSample f e (draw i).1 (draw i).2) := by
  let sampleIndex (i : Fin N) := ⌊4 * Multilinear.derivativeSample f e (draw i).1 (draw i).2 / d⌋
  have h (indices : List (Fin N)) (total : ℤ) :
      indices.foldl (fun acc i => acc + sampleIndex i) total =
        total + (indices.map sampleIndex).sum := by
    induction indices generalizing total with
    | nil => simp
    | cons i indices ih =>
      rw [List.foldl_cons, ih, List.map_cons, List.sum_cons]
      exact add_assoc _ _ _
  change (Finset.univ : Finset (Fin N)).toList.foldl
    (fun total i => total + sampleIndex i) 0 = ∑ i, sampleIndex i
  rw [h, zero_add]
  have hs := List.sum_toFinset sampleIndex (Finset.univ : Finset (Fin N)).nodup_toList
  simpa only [Finset.toList_toFinset] using hs.symm

/-- The normalized empirical coefficient has a rational grid determined
before any draw. Here `a/b` is the rational derivative precision. -/
theorem oracleCoefficient_normalized_grid (D τ epsilon : ℝ) (Q a b : ℕ)
    (hτ : 0 < τ) (hQ : 0 < Q) (hb : 0 < b) (hN : 0 < N)
    (hξ : FiniteGreedy.accuracy D m epsilon = (a : ℝ) / b)
    (f : Finset (Fin m) → ℝ) (draw : ℕ → (Fin m ⊕ Fin m → ℝ) → DerivativeSamples m N)
    (j : ℕ) (t : Fin m ⊕ Fin m → ℝ) (e : Fin m) :
    LinearPacking.OnGrid (Q * 8 * N * b)
      (oracleCoefficient D τ epsilon Q f draw j t e / τ) := by
  unfold LinearPacking.OnGrid oracleCoefficient roundedWeight Streaming.sourceAverage
  rw [hξ]
  let d := discountIndex (1 - D / (FiniteGreedy.stages D m epsilon : ℝ)) Q
      (FiniteGreedy.stages D m epsilon - (j + 1))
  let s := Streaming.sourceIndex ((a : ℝ) / b * τ / 2)
    (fun i => Multilinear.derivativeSample f e (draw j t e i).1 (draw j t e i).2)
  refine ⟨d * s * a, ?_⟩
  change ((Q * 8 * N * b : ℕ) : ℝ) *
    ((d : ℝ) / Q * (((a : ℝ) / b * τ / 2) * (s : ℝ) / (4 * N)) / τ) =
      ↑(d * s * a)
  have hQ' : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hb' : (0 : ℝ) < b := by exact_mod_cast hb
  have hN' : (0 : ℝ) < N := by exact_mod_cast hN
  push_cast
  field_simp
  ring

/-- For fixed fractional degree and accuracy the Euler stage count is
quadratic in the number of stored edges. -/
theorem stages_polynomial (D epsilon : ℝ) (m : ℕ)
    (hD : 0 ≤ D) (hD1 : D ≤ 1) (he : 0 < epsilon) :
    (FiniteGreedy.stages D m epsilon : ℝ) ≤ 2 * (m : ℝ) ^ 2 / epsilon + 1 := by
  unfold FiniteGreedy.stages
  rw [Nat.cast_max, Nat.cast_one, max_le_iff]
  constructor
  · linarith only [show 0 ≤ 2 * (m : ℝ) ^ 2 / epsilon by positivity]
  · apply (Nat.ceil_lt_add_one (by positivity : 0 ≤ 2 * D ^ 2 * (m : ℝ) ^ 2 / epsilon)).le.trans
    apply add_le_add_left
    have hD2 : D ^ 2 ≤ 1 := pow_le_one₀ hD hD1
    gcongr
    simpa using hD2

end

end SubmodularMatching.Joint
