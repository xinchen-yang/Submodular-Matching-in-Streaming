import SubmodularMatching.UpperBoundAppendixExtendedMargins
import SubmodularMatching.UpperBoundGraphConfidence
import SubmodularMatching.UpperBoundParametricGraph

/-! # The upper bounds with the remaining middle endpoint box isolated -/

namespace SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream

open SourceCertificate NumericalCertificate GibbsSampler

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype E] [Fintype V]

/-- The fixed approximation factor, given the remaining uncovered-price
box for the middle 27,216 rate modes. -/
theorem theorem1_1_of_extended_margins (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (h0 : 0 ≤ f ∅)
    (middle : AppendixBoxGoal false false ⟨432, 54863, 0, 1135, 0, 1135⟩)
    (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (delta : ℝ) (hδ : 0 < delta) :
    let p := S.expectedOutput f hf hmono
    let q := S.amplifiedOutput f hf hmono delta
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / targetFactor ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤ delta :=
  S.theorem1_1_value f hf hmono h0 (fun hn =>
    appendixSourceObligation_of_extendedMargins (Fintype.card V) hn middle) O hO hopt delta hδ

/-- The same remaining endpoint box suffices for confidence (1-n^{-c}). -/
theorem theorem1_1_confidence_of_extended_margins (S : SimpleEdgeStream E V) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (h0 : 0 ≤ f ∅)
    (middle : AppendixBoxGoal false false ⟨432, 54863, 0, 1135, 0, 1135⟩)
    (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (hn : 1 ≤ Fintype.card V) (c : ℝ) :
    let n := Fintype.card V
    let delta := (((n : ℝ) ^ ⌈c⌉₊)⁻¹)
    let q := S.amplifiedOutput f hf hmono delta
    q.outcomes ⊆ S.matchings ∧
      expected q.outcomes q.mass (fun M => if f O / targetFactor ≤ f M then 0 else 1) ≤
        (n : ℝ) ^ (-c) :=
  S.theorem1_1_confidence f hf hmono h0 (fun hn =>
    appendixSourceObligation_of_extendedMargins (Fintype.card V) hn middle) O hO hopt hn c

/-- Corollary L.1 has the same remaining numerical premise. -/
theorem approximationFamily_of_extended_margins (S : SimpleEdgeStream E V) {slack : ℝ}
    (a : FamilyParameters slack) (hslack : 0 < slack)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f) (h0 : 0 ≤ f ∅)
    (middle : AppendixBoxGoal false false ⟨432, 54863, 0, 1135, 0, 1135⟩)
    (O : Finset E) (hO : O ∈ S.matchings)
    (hopt : ∀ M ∈ S.matchings, f M ≤ f O) (delta : ℝ) (hδ : 0 < delta) :
    let p := S.familyExpectedOutput a f hf hmono
    let q := S.familyAmplifiedOutput a f hf hmono delta
    p.outcomes ⊆ S.matchings ∧ q.outcomes ⊆ S.matchings ∧
      f O / a.target ≤ expected p.outcomes p.mass f ∧
      expected q.outcomes q.mass (fun M => if f O / a.target ≤ f M then 0 else 1) ≤ delta :=
  S.approximationFamily_value a hslack f hf hmono h0 (fun hn =>
    appendixSourceObligation_of_extendedMargins (Fintype.card V) hn middle) O hO hopt delta hδ

end

end SubmodularMatching.UpperBoundAssembly.SimpleEdgeStream
