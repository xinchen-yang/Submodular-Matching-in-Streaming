import SubmodularMatching.FiniteShearerTapeSchedule
import SubmodularMatching.UpperBoundAppendixSamplers

/-!
# The executable Appendix sampler

For reciprocal-integer error targets, both caps are computed with
natural logarithms base two in the sense of integer ceiling logarithms.
The independent tapes then have exactly the checkpoint's first-stage law.
-/

namespace SubmodularMatching.UpperBoundAssembly

open Joint TwoStage GibbsSampler NumericalCertificate ShearerSampler
open scoped BigOperators

/-- Compilation of the bounded coin depth directly from the rational
error target `1 / D`. -/
def appendixTapeFuel (m D : ℕ) : ℕ := 2048 * Nat.clog 2 (4*(m+1)*D)

/-- Compilation of the bounded rejection attempts using integers. -/
def appendixTapeAttempts (m L D : ℕ) : ℕ := Nat.clog 2 (2*(m+1)*(8*L+1)*D)

theorem appendixTapeFuel_eq (m D : ℕ) :
    appendixTapeFuel m D = appendixShearerFuel m (1/(D:ℝ)) := by
  unfold appendixTapeFuel appendixShearerFuel binaryBudget
  rw [div_div_eq_mul_div,div_one]
  have h : 4*((m:ℝ)+1)*(D:ℝ) = ((4*(m+1)*D:ℕ):ℝ) := by push_cast; rfl
  rw [h,Nat.ceil_natCast]

theorem appendixTapeAttempts_eq (m L D : ℕ) :
    appendixTapeAttempts m L D = appendixShearerAttempts m L (1/(D:ℝ)) := by
  unfold appendixTapeAttempts appendixShearerAttempts binaryBudget
  rw [div_div_eq_mul_div,div_one]
  have h : 2*((m:ℝ)+1)*(8*(L:ℝ)+1)*(D:ℝ) = ((2*(m+1)*(8*L+1)*D:ℕ):ℝ) := by
    push_cast
    rfl
  rw [h,Nat.ceil_natCast]

variable {m : ℕ} {V : Type*} [DecidableEq V]

noncomputable def appendixFirstTapeLaw (c : RationalShearerInput (Fin m)) (ends : Fin m → V × V)
    (D : ℕ) : Finset (Fin m) → ℝ :=
  let L := appendixTapeFuel m D
  let B := appendixTapeAttempts m L D
  let stored := List.finRange m
  compactShearerLaw c (pairEnds ends) ends stored B (2*L) stored

theorem appendixFirstTapeLaw_eq (c : RationalShearerInput (Fin m)) (ends : Fin m → V × V)
    (hDistinct : ∀ e, (ends e).1 ≠ (ends e).2) (hr : 1/2 ≤ c.stop)
    (hDegree : ∀ v, Joint.degree ends c.x v ≤ c.stop*(1-c.stop)) (D : ℕ) :
    appendixFirstTapeLaw c ends D = appendixFirstLaw c ends (1/(D:ℝ)) := by
  let edges := (Finset.univ : Finset (Fin m))
  let stored := List.finRange m
  have hs : stored.toFinset = edges := by ext e; simp [stored,edges]
  have hDeg (v : V) :
      ∑ e ∈ GibbsMatching.incident (pairEnds ends) edges v, c.x e ≤ c.stop*(1-c.stop) := by
    change Shearer.vertexDegree (pairEnds ends) Finset.univ c.x v ≤ _
    rw [vertexDegree_pairEnds]
    exact hDegree v
  unfold appendixFirstTapeLaw appendixFirstLaw
  simp only [List.length_finRange,appendixTapeFuel_eq,appendixTapeAttempts_eq]
  exact compactShearerLaw_eq c (pairEnds ends) ends edges stored hs (List.nodup_finRange m)
    (fun _ _ => rfl) (fun e _ => hDistinct e) hDeg hr _ _ stored (Finset.subset_univ _)

/-- On the paper's rational input, the actual word-level first sampler
inherits normalization and its prescribed TV guarantee. -/
theorem appendixFirstTapeLaw_correct [Fintype V] (Q : ℕ) (hQ : 0 < Q) (num : Fin m → ℕ)
    (ends : Fin m → V × V) (hDistinct : ∀ e, (ends e).1 ≠ (ends e).2)
    (D : ℕ) (hD : 0 < D)
    (hDegree : ∀ v, Joint.degree ends (appendixShearerInput Q hQ num).x v ≤ degree) :
    let c := appendixShearerInput Q hQ num
    let law := appendixFirstTapeLaw c ends D
    let S := GibbsMatching.matchings (pairEnds ends) Finset.univ
    IsProbability S law ∧ variation S (Shearer.mass (pairEnds ends) Finset.univ c.x) law ≤ 1/(D:ℝ) := by
  let c := appendixShearerInput Q hQ num
  have hs : c.stop = sampler := rfl
  have hReal : 0 < (D:ℝ) := by exact_mod_cast hD
  have hOne : (1:ℝ) ≤ D := by exact_mod_cast hD
  have hErr : 0 < 1/(D:ℝ) ∧ 1/(D:ℝ) ≤ 1 :=
    ⟨one_div_pos.mpr hReal,(div_le_one hReal).mpr hOne⟩
  have hEq := appendixFirstTapeLaw_eq c ends hDistinct (hs.symm ▸ sampler_bounds.1.le)
    (fun v => by simpa only [hs] using hDegree v) D
  dsimp only
  rw [hEq]
  exact appendixFirstLaw_correct Q hQ num ends hDistinct (1/(D:ℝ)) hErr hDegree

/-- Number of bits when every reserved primitive tape is fully supplied. -/
def appendixTapeBits (c : RationalShearerInput (Fin m)) (D : ℕ) : ℕ :=
  let L := appendixTapeFuel m D
  let B := appendixTapeAttempts m L D
  m * (B*c.edgeGrid.bits + 2*(2*L)*(B*(c.stopGrid.bits+c.neighborGrid.bits)))

theorem appendixTapeBits_le (c : RationalShearerInput (Fin m)) (D : ℕ) :
    let L := appendixTapeFuel m D
    let B := appendixTapeAttempts m L D
    appendixTapeBits c D ≤ m*B*(8*L+1) *
      max c.edgeGrid.bits (max c.stopGrid.bits c.neighborGrid.bits) := by
  dsimp only [appendixTapeBits]
  let L := appendixTapeFuel m D
  let B := appendixTapeAttempts m L D
  let q := max c.edgeGrid.bits (max c.stopGrid.bits c.neighborGrid.bits)
  have he : c.edgeGrid.bits ≤ q := le_max_left _ _
  have hs : c.stopGrid.bits ≤ q := (le_max_left _ _).trans (le_max_right _ _)
  have hn : c.neighborGrid.bits ≤ q := (le_max_right _ _).trans (le_max_right _ _)
  calc
    _ ≤ m*(B*q + 2*(2*L)*(B*(q+q))) := by gcongr
    _ = _ := by ring

end SubmodularMatching.UpperBoundAssembly
