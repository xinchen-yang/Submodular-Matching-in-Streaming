import SubmodularMatching.GibbsSamplerGrid

/-!
# Executing a quantized Gibbs row by scanning stored edges

A draw is carried as one residual word. Each stored edge claims the next
block of cells, and the unclaimed suffix is the holding transition.
The scanner makes at most one cell computation per stored edge.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching
open scoped BigOperators

variable {E A V : Type*}

/-- Return the first item whose cells contain the residual word. -/
def scanTicket (cells : E → ℕ) : List E → ℕ → Option E
  | [], _ => none
  | e :: rest, word =>
      if word < cells e then some e else scanTicket cells rest (word - cells e)

/-- Number of items visited by this draw. -/
def scanTicketVisits (cells : E → ℕ) : List E → ℕ → ℕ
  | [], _ => 0
  | e :: rest, word =>
      1 + if word < cells e then 0 else scanTicketVisits cells rest (word-cells e)

theorem scanTicketVisits_le (cells : E → ℕ) (items : List E) (word : ℕ) :
    scanTicketVisits cells items word ≤ items.length := by
  induction items generalizing word with
  | nil => simp [scanTicketVisits]
  | cons e rest ih =>
    simp only [scanTicketVisits,List.length_cons]
    split
    · omega
    · have h := ih (word-cells e)
      omega

/-- Exact occurrence count under a uniform word. The mapper supplies both
the destination of each selected item and the default holding outcome. -/
theorem scanTicket_count [DecidableEq A] (cells : E → ℕ) (items : List E)
    (result : Option E → A) (target : A) (q : ℕ) (hq : (items.map cells).sum ≤ q) :
    (∑ w ∈ Finset.range q, if result (scanTicket cells items w) = target then 1 else 0) =
      (items.map (fun e => if result (some e) = target then cells e else 0)).sum +
        (if result none = target then q - (items.map cells).sum else 0) := by
  induction items generalizing q with
  | nil =>
    by_cases h : result none = target <;> simp [scanTicket,h]
  | cons e rest ih =>
    let a := cells e
    let r := q - a
    have hBound : a + (rest.map cells).sum ≤ q := hq
    have ha : a ≤ q := by omega
    have hr : (rest.map cells).sum ≤ r := by omega
    have hSplit : q = a+r := (Nat.add_sub_of_le ha).symm
    rw [hSplit,Finset.sum_range_add]
    have hHead :
        (∑ w ∈ Finset.range a, if result (scanTicket cells (e::rest) w) = target then 1 else 0) =
          if result (some e) = target then a else 0 := by
      calc
        _ = ∑ _ ∈ Finset.range a, (if result (some e) = target then (1:ℕ) else 0) := by
          apply Finset.sum_congr rfl
          intro w hw
          have hlt : w < cells e := Finset.mem_range.mp hw
          simp [scanTicket,hlt]
        _ = _ := by split <;> simp
    have hRest :
        (∑ w ∈ Finset.range r,
           if result (scanTicket cells (e::rest) (a+w)) = target then 1 else 0) =
          ∑ w ∈ Finset.range r, if result (scanTicket cells rest w) = target then 1 else 0 := by
      apply Finset.sum_congr rfl
      intro w _
      simp [scanTicket,show cells e = a from rfl]
    rw [hHead,hRest,ih r hr]
    simp only [List.map_cons,List.sum_cons,show cells e = a from rfl,Nat.add_sub_add_left]
    omega

private theorem list_sum_eq_finset_sum [DecidableEq E] (cells : E → ℕ)
    (items : List E) (hItems : items.Nodup) :
    (items.map cells).sum = ∑ e ∈ items.toFinset, cells e := by
  induction items with
  | nil => simp
  | cons e rest ih =>
    have he : e ∉ rest.toFinset := by simpa using (List.nodup_cons.mp hItems).1
    simp only [List.map_cons,List.sum_cons,List.toFinset_cons,Finset.sum_insert he]
    rw [ih (List.nodup_cons.mp hItems).2]

variable [DecidableEq E] [DecidableEq V]

/-- Scan the stored list with exact dyadic cell counts and realize the
selected proposal, or keep the current matching if no cell is selected. -/
def scanGibbsTransition (ends : E → Finset V) (M : Finset E) (cells : E → ℕ)
    (stored : List E) (word : ℕ) : Finset E :=
  (scanTicket cells stored word).elim M (proposal ends M)

/-- The scan computes the same row as the compensated dyadic kernel.
This identity uses neither a dense table of states nor a state-space scan. -/
theorem scanGibbsTransition_law (ends : E → Finset V) (edges : Finset E)
    (activity : E → ℝ) (ha : ∀ e ∈ edges, 0 ≤ activity e) (b : ℕ)
    (M N : Finset E) (hM : M ∈ matchings ends edges) (hN : N ∈ matchings ends edges)
    (stored : List E) (hs : stored.toFinset = edges) (hd : stored.Nodup) :
    (((∑ w ∈ Finset.range (2^b), if
        scanGibbsTransition ends M (fun e => moveCells ends edges activity b M (proposal ends M e))
          stored w = N then (1:ℕ) else 0) : ℕ) : ℝ) / (2:ℝ)^b =
      roundedTransition ends edges activity b M N := by
  classical
  let cells := fun e => moveCells ends edges activity b M (proposal ends M e)
  let q : ℕ := 2^b
  let moved := ∑ B ∈ matchings ends edges, moveCells ends edges activity b M B
  have hMoves : ∑ e ∈ edges, cells e = moved :=
    (moveCells_sum_proposals ends edges activity b M hM).symm
  have hTotal : (stored.map cells).sum = moved := by
    rw [list_sum_eq_finset_sum cells stored hd,hs,hMoves]
  have hq : 0 < (q:ℝ) := by dsimp [q]; positivity
  have hSum :
      (∑ B ∈ matchings ends edges, roundedMove ends edges activity b M B) =
        (moved:ℝ) / (q:ℝ) := by
    simp only [moved,roundedMove,q,Nat.cast_pow,Nat.cast_ofNat,Nat.cast_sum,Finset.sum_div]
  have hLe : moved ≤ q := by
    have h₁ := Finset.sum_le_sum (fun B hB => (roundedMove_bounds ends edges activity b M B
      (offDiagonal_bounds ends edges activity ha M B hM hB).1).2.1)
    rw [hSum] at h₁
    have h₂ := offDiagonal_outgoing_le_half ends edges activity ha M hM
    have hRatio : (moved:ℝ) / (q:ℝ) ≤ 1 := h₁.trans (h₂.trans (by norm_num))
    exact_mod_cast (div_le_one hq).mp hRatio
  let result : Option E → Finset E := fun chosen => chosen.elim M (proposal ends M)
  have hCount := scanTicket_count cells stored result N q (hTotal ▸ hLe)
  change (∑ w ∈ Finset.range q, if scanGibbsTransition ends M cells stored w = N then (1:ℕ) else 0) =
    (stored.map (fun e => if proposal ends M e = N then cells e else 0)).sum +
      (if M = N then q - (stored.map cells).sum else 0) at hCount
  rw [list_sum_eq_finset_sum _ stored hd,hs,hTotal] at hCount
  have hQC : (q:ℝ) = (2:ℝ)^b := by simp [q]
  rw [← hQC]
  change ((↑(∑ w ∈ Finset.range q, if scanGibbsTransition ends M cells stored w = N then (1:ℕ) else 0):ℝ)
      / (q:ℝ)) = roundedTransition ends edges activity b M N
  rw [hCount,roundedTransition]
  by_cases hEq : M = N
  · subst N
    rw [if_pos rfl,if_pos rfl,hSum]
    have hNone : (∑ e ∈ edges, if proposal ends M e = M then cells e else 0) = 0 := by
      apply Finset.sum_eq_zero
      intro e _
      split
      · rename_i he
        simp [cells,he,moveCells,offDiagonal_self]
      · rfl
    rw [hNone,zero_add,Nat.cast_sub hLe,sub_div,div_self hq.ne']
  · rw [if_neg hEq,if_neg hEq,add_zero]
    by_cases hAdj : Adjacent ends M N
    · obtain ⟨e,he,hp⟩ := adjacent_has_proposal ends edges M N hM hN hAdj
      have hOnly : (∑ d ∈ edges, if proposal ends M d = N then cells d else 0) = cells e := by
        rw [← Finset.sum_erase_add _ _ he, if_pos hp]
        have hZero : (∑ d ∈ edges.erase e, if proposal ends M d = N then cells d else 0) = 0 := by
          apply Finset.sum_eq_zero
          intro d hd'
          have hNe : proposal ends M d ≠ N := fun h =>
            (Finset.mem_erase.mp hd').1 (proposal_unique ends M N d e h hp hEq)
          rw [if_neg hNe]
        rw [hZero,zero_add]
      rw [hOnly]
      simp [cells,hp,roundedMove,q]
    · have hZero : moveCells ends edges activity b M N = 0 := by simp [moveCells,offDiagonal,hAdj]
      have hNone : (∑ e ∈ edges, if proposal ends M e = N then cells e else 0) = 0 := by
        apply Finset.sum_eq_zero
        intro e _
        split
        · rename_i he
          simp [cells,he,hZero]
        · rfl
      rw [hNone,Nat.cast_zero,zero_div,roundedMove,hZero,Nat.cast_zero,zero_div]

end SubmodularMatching.GibbsSampler
