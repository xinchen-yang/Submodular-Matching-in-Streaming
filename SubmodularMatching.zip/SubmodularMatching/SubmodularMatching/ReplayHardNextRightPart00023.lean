import SubmodularMatching.ReplaySubinterval
import SubmodularMatching.ReplayHardNextRightPart00000
import SubmodularMatching.ReplayHardNextRightPart00001
import SubmodularMatching.ReplayHardNextRightPart00002
import SubmodularMatching.ReplayHardNextRightPart00003
import SubmodularMatching.ReplayHardNextRightPart00004
import SubmodularMatching.ReplayHardNextRightPart00005
import SubmodularMatching.ReplayHardNextRightPart00006
import SubmodularMatching.ReplayHardNextRightPart00007
import SubmodularMatching.ReplayHardNextRightPart00008
import SubmodularMatching.ReplayHardNextRightPart00009
import SubmodularMatching.ReplayHardNextRightPart00010
import SubmodularMatching.ReplayHardNextRightPart00011
import SubmodularMatching.ReplayHardNextRightPart00012
import SubmodularMatching.ReplayHardNextRightPart00013
import SubmodularMatching.ReplayHardNextRightPart00014
import SubmodularMatching.ReplayHardNextRightPart00015
import SubmodularMatching.ReplayHardNextRightPart00016
import SubmodularMatching.ReplayHardNextRightPart00017
import SubmodularMatching.ReplayHardNextRightPart00018
import SubmodularMatching.ReplayHardNextRightPart00019
import SubmodularMatching.ReplayHardNextRightPart00020
import SubmodularMatching.ReplayHardNextRightPart00021
import SubmodularMatching.ReplayHardNextRightPart00022

namespace SubmodularMatching.SourceCertificate.Replay.HardNextRight

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step48 : ProjectedGoal ⟨54864, 54971, 141, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54917 (by decide) (by decide) (Part00001 rates cones) (Part00002 rates cones)

private theorem step68 : ProjectedGoal ⟨54864, 55079, 141, 283, 0, 141⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54971 (by decide) (by decide) (step48 rates cones) (Part00003 rates cones)

private theorem step70 : ProjectedGoal ⟨54864, 55079, 141, 283, 0, 283⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 141 (by decide) (by decide) (step68 rates cones) (Part00004 rates cones)

private theorem step72 : ProjectedGoal ⟨54864, 55079, 141, 283, 0, 567⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 283 (by decide) (by decide) (step70 rates cones) (Part00005 rates cones)

private theorem step73 : ProjectedGoal ⟨54864, 55079, 0, 283, 0, 567⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 141 (by decide) (by decide) (Part00000 rates cones) (step72 rates cones)

private theorem step75 : ProjectedGoal ⟨54864, 55079, 0, 567, 0, 567⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 283 (by decide) (by decide) (step73 rates cones) (Part00006 rates cones)

private theorem step107 : ProjectedGoal ⟨54864, 54917, 0, 141, 1028, 1064⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54890 (by decide) (by decide) (Part00010 rates cones) (Part00011 rates cones)

private theorem step109 : ProjectedGoal ⟨54864, 54971, 0, 141, 1028, 1064⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54917 (by decide) (by decide) (step107 rates cones) (Part00012 rates cones)

private theorem step111 : ProjectedGoal ⟨54864, 55079, 0, 141, 1028, 1064⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54971 (by decide) (by decide) (step109 rates cones) (Part00013 rates cones)

private theorem step112 : ProjectedGoal ⟨54864, 55079, 0, 141, 993, 1064⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1028 (by decide) (by decide) (Part00009 rates cones) (step111 rates cones)

private theorem step162 : ProjectedGoal ⟨54972, 55079, 0, 70, 1064, 1081⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1072 (by decide) (by decide) (Part00015 rates cones) (Part00016 rates cones)

private theorem step174 : ProjectedGoal ⟨54972, 55079, 0, 70, 1064, 1099⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1081 (by decide) (by decide) (step162 rates cones) (Part00017 rates cones)

private theorem step175 : ProjectedGoal ⟨54864, 55079, 0, 70, 1064, 1099⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitMode _ 54971 (by decide) (by decide) (Part00014 rates cones) (step174 rates cones)

private theorem step187 : ProjectedGoal ⟨54864, 55079, 0, 70, 1064, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1099 (by decide) (by decide) (step175 rates cones) (Part00018 rates cones)

private theorem step189 : ProjectedGoal ⟨54864, 55079, 0, 141, 1064, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 70 (by decide) (by decide) (step187 rates cones) (Part00019 rates cones)

private theorem step190 : ProjectedGoal ⟨54864, 55079, 0, 141, 993, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 1064 (by decide) (by decide) (step112 rates cones) (step189 rates cones)

private theorem step192 : ProjectedGoal ⟨54864, 55079, 0, 283, 993, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 141 (by decide) (by decide) (step190 rates cones) (Part00020 rates cones)

private theorem step193 : ProjectedGoal ⟨54864, 55079, 0, 283, 851, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 993 (by decide) (by decide) (Part00008 rates cones) (step192 rates cones)

private theorem step194 : ProjectedGoal ⟨54864, 55079, 0, 283, 567, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 851 (by decide) (by decide) (Part00007 rates cones) (step193 rates cones)

private theorem step196 : ProjectedGoal ⟨54864, 55079, 0, 567, 567, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 283 (by decide) (by decide) (step194 rates cones) (Part00021 rates cones)

private theorem step197 : ProjectedGoal ⟨54864, 55079, 0, 567, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitY _ 567 (by decide) (by decide) (step75 rates cones) (step196 rates cones)

private theorem step199 : ProjectedGoal ⟨54864, 55079, 0, 1135, 0, 1135⟩ :=
  by
  intro rates cones
  exact AppendixBoxGoal.splitX _ 567 (by decide) (by decide) (step197 rates cones) (Part00022 rates cones)

theorem Part00023 : ProjectedGoal ⟨54864, 55079, 0, 1135, 0, 1135⟩ := step199

end SubmodularMatching.SourceCertificate.Replay.HardNextRight
