import SubmodularMatching.FiniteShearerTapeAppendix
import SubmodularMatching.UpperBoundVertexCandidate
import SubmodularMatching.UpperBoundVertexGibbsWords

/-!
# Both executable samplers in the compact Appendix candidate

An independent first-stage tape produces a matching. Its output selects
the altered grid and the conditional Gibbs word budget. The union
pushforward is the one used by the candidate guarantee.
-/

namespace SubmodularMatching.UpperBoundAssembly

open ShearerSampler GibbsSampler GibbsMatching Joint TwoStage NumericalCertificate
open scoped BigOperators

noncomputable section

variable {m N : ℕ} {V : Type*} [DecidableEq V]

/-- Output mass of the conditional word sampler before embedding edge IDs. -/
def compactPointTapeOutcomeMass (hm : 0 < m) (ends : Fin m → V × V)
    (t : (Fin m → ℝ) × (Fin m → ℝ)) (M : Finset (Fin m)) : ℝ :=
  let ep := restrictEnds ends
  let n := Fintype.card (IncidentVertex ends)
  let mesh := appendixShearerDenominator n m
  let c := appendixShearerInput mesh (appendixShearerDenominator_pos n m hm)
    (appendixRoundedNumerators t.2 n)
  let D := appendixGibbsDenominator n
  let first := appendixFirstTapeLaw c ep D
  let second := fun T =>
    let z := shearerAltered ep t.1 t.2 (roundingError / 4) T
    gridGibbsWalkLaw (numberedEnds ends) 799999999 800000000 (appendixAlteredDenominator m)
      (fun e => appendixAlteredIndex m (z e)) (List.finRange m) D
  let states := matchings (pairEnds ep) (Finset.univ : Finset (Fin m))
  ∑ pair ∈ states ×ˢ states,
    if compactRoundingOutcome ep pair = M then first pair.1 * second pair.1 pair.2 else 0

/-- Evaluate the rounded-point word law for one optimizer draw. -/
def compactAppendixTapeOutcomeMass (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (M : Finset (Fin m)) : ℝ :=
  compactPointTapeOutcomeMass hm ends (appendixRoundedPoint (restrictEnds ends) tau w f Q draw) M

set_option maxHeartbeats 750000 in
/-- The candidate used in the expected approximation theorem is exactly
the law of the two compact executable word samplers. -/
theorem compactAppendixTapeOutcomeMass_eq (hm : 0 < m) (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds ends))
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (M : Finset (Fin m)) :
    let ep := restrictEnds ends
    let t := appendixRoundedPoint ep tau w f Q draw
    let hlo := restrictEnds_loopless ends hloop
    let hFeas := appendixRoundedPoint_feasible hm ep hlo tau w f Q draw
    let hGrid := appendixRoundedPoint_y_grid hm ep tau w f Q draw
    compactAppendixTapeOutcomeMass hm ends tau w f Q draw M =
      (appendixRoundingCandidate hm ep hlo (incidentVertex_card_pos hm ends) t.1 t.2 hFeas hGrid).mass M := by
  classical
  dsimp only
  let ep := restrictEnds ends
  let n := Fintype.card (IncidentVertex ends)
  let t := appendixRoundedPoint ep tau w f Q draw
  let D := appendixGibbsDenominator n
  let mesh := appendixShearerDenominator n m
  let c := appendixShearerInput mesh (appendixShearerDenominator_pos n m hm)
    (appendixRoundedNumerators t.2 n)
  let hlo := restrictEnds_loopless ends hloop
  let hFeas := appendixRoundedPoint_feasible hm ep hlo tau w f Q draw
  let hGrid := appendixRoundedPoint_y_grid hm ep tau w f Q draw
  let second := fun T =>
    let z := shearerAltered ep t.1 t.2 (roundingError / 4) T
    gridGibbsWalkLaw (numberedEnds ends) 799999999 800000000 (appendixAlteredDenominator m)
      (fun e => appendixAlteredIndex m (z e)) (List.finRange m) D
  let S := matchings (pairEnds ep) (Finset.univ : Finset (Fin m))
  have hc : c.x = t.2 := appendixRoundedNumerators_exact t.2 n hm hFeas.y_nonneg hGrid
  have hFirst : appendixFirstTapeLaw c ep D = appendixFirstLaw c ep (appendixSamplerError n) := by
    rw [← appendixGibbsDenominator_error n]
    apply appendixFirstTapeLaw_eq c ep hlo
    · exact sampler_bounds.1.le
    · intro v
      rw [hc]
      exact hFeas.y_degree v
  have hSecond (T : Finset (Fin m)) : second T =
      supportedGibbsLaw (pairEnds ep) Finset.univ
        (secondActivity ep t.1 c.x (roundingError / 4) (roundingError / 2) T)
        (appendixGibbsBits ep t.1 c.x T) (appendixGibbsSteps ep t.1 c.x T) := by
    rw [hc]
    exact compactAppendixGibbs_gridWalk_eq hm ends hloop hsimple tau w f Q draw T
  change (∑ pair ∈ S ×ˢ S,
    if compactRoundingOutcome ep pair = M then appendixFirstTapeLaw c ep D pair.1 * second pair.1 pair.2 else 0) =
      (appendixRoundingCandidate hm ep hlo (incidentVertex_card_pos hm ends) t.1 t.2 hFeas hGrid).mass M
  unfold appendixRoundingCandidate finiteRoundingCandidate CandidateLaw.map CandidateLaw.imageMass
    roundingJointCandidate jointLaw
  dsimp only
  apply Finset.sum_congr rfl
  intro pair _
  rw [hFirst,hSecond pair.1]
  by_cases h : compactRoundingOutcome ep pair = M
  · simp only [h,ite_true]
    rfl
  · simp only [h,ite_false]

/-- The same word execution, followed by the original edge-identifier
conversion, gives the streaming candidate's formal output mass. -/
theorem compactAppendixGuessCandidate_tape_mass {E : Type*} [DecidableEq E]
    (hm : 0 < m) (embedding : Fin m ↪ E) (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (hsimple : Function.Injective (pairEnds (ends ∘ embedding)))
    (tau : ℝ) (w : E → ℝ) (f : Finset E → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (M : Finset E) :
    let original := ends ∘ embedding
    let ep := restrictEnds original
    let objective := reindexedObjective embedding f
    let t := appendixRoundedPoint ep tau (w ∘ embedding) objective Q draw
    let hlo := restrictEnds_loopless original (fun i => hloop (embedding i))
    let hFeas := appendixRoundedPoint_feasible hm ep hlo tau (w ∘ embedding) objective Q draw
    let hGrid := appendixRoundedPoint_y_grid hm ep tau (w ∘ embedding) objective Q draw
    let q := appendixRoundingCandidate hm ep hlo (incidentVertex_card_pos hm original) t.1 t.2 hFeas hGrid
    (compactAppendixGuessCandidate hm embedding ends hloop tau w f Q draw).mass M =
      ∑ A ∈ q.outcomes, if A.map embedding = M then
        compactAppendixTapeOutcomeMass hm original tau (w ∘ embedding) objective Q draw A else 0 := by
  dsimp only
  unfold compactAppendixGuessCandidate CandidateLaw.map CandidateLaw.imageMass
  dsimp only
  apply Finset.sum_congr rfl
  intro A _
  rw [compactAppendixTapeOutcomeMass_eq hm (ends ∘ embedding) (fun i => hloop (embedding i))
    hsimple tau (w ∘ embedding) (reindexedObjective embedding f) Q draw A]
  by_cases h : A.map embedding = M <;> simp only [h,ite_true,ite_false]

end

end SubmodularMatching.UpperBoundAssembly
