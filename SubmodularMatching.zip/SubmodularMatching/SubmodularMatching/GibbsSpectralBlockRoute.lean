import SubmodularMatching.GibbsSpectralFrontier

/-!
# Moving between the two colors of one conflict component

Insert blue edges in frontier order, first deleting their red blockers.
Every move changes one edge, and the complement of either larger endpoint
state becomes a matching after deleting at most four recorded red edges.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- A step in which a red edge is removed or a blue edge is added. The
complement of the larger endpoint can have only bounded matching defects. -/
structure LocalMatchingMove (ends : E → Finset V) (red blue M N : Finset E) : Prop where
  left : M ∈ matchings ends (red ∪ blue)
  right : N ∈ matchings ends (red ∪ blue)
  change_edge :
    (∃ e ∈ red, e ∈ M ∧ N = M.erase e) ∨
    (∃ e ∈ blue, e ∉ M ∧ N = insert e M)
  defect : ∃ D : Finset E, D.card ≤ 4 ∧ D ⊆ (red ∪ blue) \ (M ∪ N) ∧
    Streaming.IsMatchingOn ends (((red ∪ blue) \ (M ∪ N)) \ D)

noncomputable def blockState (ends : E → Finset V) (red processed pending : Finset E) : Finset E :=
  (red \ (redNeighbors ends red processed ∪ pending)) ∪ processed

omit [DecidableEq V] in
@[simp] theorem mem_blockState (ends : E → Finset V) (red processed pending : Finset E) (e : E) :
    e ∈ blockState ends red processed pending ↔
      (e ∈ red ∧ e ∉ redNeighbors ends red processed ∧ e ∉ pending) ∨ e ∈ processed := by
  simp [blockState, not_or]

theorem blockState_mem_matchings (ends : E → Finset V) (red blue processed pending : Finset E)
    (hred : Streaming.IsMatchingOn ends red) (hblue : Streaming.IsMatchingOn ends blue)
    (hp : processed ⊆ blue) :
    blockState ends red processed pending ∈ matchings ends (red ∪ blue) := by
  apply (mem_matchings ..).2
  constructor
  · intro e he
    rcases (mem_blockState ..).1 he with h | h
    · exact Finset.mem_union_left _ h.1
    · exact Finset.mem_union_right _ (hp h)
  · intro a ha b hb hab
    rcases (mem_blockState ..).1 ha with ha | ha <;> rcases (mem_blockState ..).1 hb with hb | hb
    · exact hred ha.1 hb.1 hab
    · by_contra hc
      exact ha.2.1 ((mem_redNeighbors ..).2 ⟨ha.1,b,hb,hc⟩)
    · by_contra hc
      exact hb.2.1 ((mem_redNeighbors ..).2 ⟨hb.1,a,ha,conflicts_symm ends hc⟩)
    · exact hblue (hp ha) (hp hb) hab

omit [DecidableEq V] in
theorem blockState_erase (ends : E → Finset V) (red processed pending : Finset E)
    (d : E) (hd : d ∉ processed) :
    (blockState ends red processed pending).erase d =
      blockState ends red processed (insert d pending) := by
  ext e
  simp only [Finset.mem_erase, mem_blockState, Finset.mem_insert, not_or]
  have h : e ∈ processed → e ≠ d := fun he hEq => hd (hEq ▸ he)
  tauto

/-- The red frontier accounts for defects during accepted insertions.
During the preceding removals, pending deleted edges also need recording. -/
theorem blockState_has_small_defect (ends : E → Finset V)
    (red blue processed pending : Finset E) (hd : Disjoint red blue)
    (hred : Streaming.IsMatchingOn ends red) (hblue : Streaming.IsMatchingOn ends blue)
    (hp : processed ⊆ blue) (hPending : pending ⊆ red)
    (hFront : (redFrontier ends red blue processed).card ≤ 2)
    (hPendCard : pending.card ≤ 2) :
    ∃ D : Finset E, D.card ≤ 4 ∧ D ⊆ (red ∪ blue) \ blockState ends red processed pending ∧
      Streaming.IsMatchingOn ends (((red ∪ blue) \ blockState ends red processed pending) \ D) := by
  let D := redFrontier ends red blue processed ∪ pending
  have hCard : D.card ≤ 4 :=
    (Finset.card_union_le _ _).trans (by omega)
  have hDisj (e : E) (h : e ∈ red) : e ∉ processed :=
    fun he => Finset.disjoint_left.mp hd h (hp he)
  have hSub (e : E) (he : e ∈ D) : e ∈ (red ∪ blue) \ blockState ends red processed pending := by
    rcases Finset.mem_union.mp he with h | h
    · have h₁ := Finset.mem_inter.mp h
      have h₂ := (mem_redNeighbors ..).1 h₁.1
      refine Finset.mem_sdiff.mpr ⟨Finset.mem_union_left _ h₂.1,?_⟩
      intro hm
      rcases (mem_blockState ..).1 hm with hm | hm
      · exact hm.2.1 h₁.1
      · exact hDisj e h₂.1 hm
    · refine Finset.mem_sdiff.mpr ⟨Finset.mem_union_left _ (hPending h),?_⟩
      intro hm
      rcases (mem_blockState ..).1 hm with hm | hm
      · exact hm.2.2 h
      · exact hDisj e (hPending h) hm
  refine ⟨D,hCard,hSub,?_⟩
  intro a ha b hb hne
  have hCross {e g : E} (he : e ∈ red) (hg : g ∈ blue)
      (he' : e ∈ ((red ∪ blue) \ blockState ends red processed pending) \ D)
      (hg' : g ∈ ((red ∪ blue) \ blockState ends red processed pending) \ D) :
      Disjoint (ends e) (ends g) := by
    have heM := (Finset.mem_sdiff.mp (Finset.mem_sdiff.mp he').1).2
    have hgM := (Finset.mem_sdiff.mp (Finset.mem_sdiff.mp hg').1).2
    have heD := (Finset.mem_sdiff.mp he').2
    have heP : e ∉ pending := fun h => heD (Finset.mem_union_right _ h)
    have heR : e ∈ redNeighbors ends red processed := by
      by_contra hn
      exact heM ((mem_blockState ..).2 (Or.inl ⟨he,hn,heP⟩))
    have hgP : g ∉ processed := fun h => hgM ((mem_blockState ..).2 (Or.inr h))
    by_contra hc
    have hF : e ∈ redFrontier ends red blue processed :=
      Finset.mem_inter.mpr ⟨heR,(mem_redNeighbors ..).2 ⟨he,g,Finset.mem_sdiff.mpr ⟨hg,hgP⟩,hc⟩⟩
    exact heD (Finset.mem_union_left _ hF)
  rcases Finset.mem_union.mp (Finset.mem_sdiff.mp (Finset.mem_sdiff.mp ha).1).1 with haR | haB <;>
    rcases Finset.mem_union.mp (Finset.mem_sdiff.mp (Finset.mem_sdiff.mp hb).1).1 with hbR | hbB
  · exact hred haR hbR hne
  · exact hCross haR hbB ha hb
  · exact (hCross hbR haB hb ha).symm
  · exact hblue haB hbB hne

private theorem blockState_deletion_route (ends : E → Finset V)
    (red blue processed target initial : Finset E) (hd : Disjoint red blue)
    (hred : Streaming.IsMatchingOn ends red) (hblue : Streaming.IsMatchingOn ends blue)
    (hp : processed ⊆ blue) (ht : target ⊆ red \ redNeighbors ends red processed)
    (hi : initial ⊆ target)
    (hDef : ∀ pending ⊆ target,
      ∃ D : Finset E, D.card ≤ 4 ∧ D ⊆ (red ∪ blue) \ blockState ends red processed pending ∧
        Streaming.IsMatchingOn ends (((red ∪ blue) \ blockState ends red processed pending) \ D)) :
    Relation.ReflTransGen (LocalMatchingMove ends red blue)
      (blockState ends red processed initial) (blockState ends red processed target) := by
  classical
  generalize hMeasure : (target \ initial).card = n
  induction n using Nat.strong_induction_on generalizing initial with
  | h n ih =>
    by_cases hSub : target ⊆ initial
    · rw [Finset.Subset.antisymm hi hSub]
    · obtain ⟨d,hdT,hdI⟩ := Finset.not_subset.mp hSub
      have hd' := Finset.mem_sdiff.mp (ht hdT)
      have hdP : d ∉ processed := fun hg => Finset.disjoint_left.mp hd hd'.1 (hp hg)
      let next := insert d initial
      have hNext : next ⊆ target := Finset.insert_subset_iff.mpr ⟨hdT,hi⟩
      have hErase := blockState_erase ends red processed initial d hdP
      have hMove : LocalMatchingMove ends red blue (blockState ends red processed initial)
          (blockState ends red processed next) := by
        have hMem : d ∈ blockState ends red processed initial :=
          (mem_blockState ..).2 (Or.inl ⟨hd'.1,hd'.2,hdI⟩)
        have hUnion : blockState ends red processed initial ∪ blockState ends red processed next =
            blockState ends red processed initial := by
          dsimp only [next]
          rw [← hErase]
          exact Finset.union_eq_left.mpr (Finset.erase_subset _ _)
        refine ⟨blockState_mem_matchings ends red blue processed initial hred hblue hp,
          blockState_mem_matchings ends red blue processed next hred hblue hp,
          Or.inl ⟨d,hd'.1,hMem,hErase.symm⟩,?_⟩
        simpa only [hUnion] using hDef initial hi
      have hEq : target \ next = (target \ initial).erase d := by
        ext e
        simp only [next,Finset.mem_sdiff,Finset.mem_insert,not_or,Finset.mem_erase]
        tauto
      have hSmaller : (target \ next).card < n := by
        rw [hEq,←hMeasure]
        exact Finset.card_erase_lt_of_mem (Finset.mem_sdiff.mpr ⟨hdT,hdI⟩)
      exact Relation.ReflTransGen.head hMove (ih _ hSmaller next hNext rfl)

private theorem blockState_insert_change (ends : E → Finset V)
    (red processed : Finset E) (d : E) :
    insert d (blockState ends red processed
      (conflictNeighbors ends red d \ redNeighbors ends red processed)) =
      blockState ends red (insert d processed) ∅ := by
  ext e
  simp only [Finset.mem_insert,mem_blockState,redNeighbors_insert,Finset.mem_union,not_or,
    Finset.mem_sdiff,Finset.notMem_empty]
  tauto

theorem process_blue_step (ends : E → Finset V) (red blue processed : Finset E)
    (hd : Disjoint red blue)
    (hred : Streaming.IsMatchingOn ends red) (hblue : Streaming.IsMatchingOn ends blue)
    (hp : processed ⊆ blue) (hFront : (redFrontier ends red blue processed).card ≤ 2)
    (d : E) (hD : d ∈ blue \ processed) (hD₂ : (ends d).card = 2)
    (hNextFront : (redFrontier ends red blue (insert d processed)).card ≤ 2) :
    Relation.ReflTransGen (LocalMatchingMove ends red blue)
      (blockState ends red processed ∅) (blockState ends red (insert d processed) ∅) := by
  let target := conflictNeighbors ends red d \ redNeighbors ends red processed
  have ht : target ⊆ red \ redNeighbors ends red processed := by
    intro e he
    obtain ⟨heN,heNot⟩ := Finset.mem_sdiff.mp he
    exact Finset.mem_sdiff.mpr ⟨((mem_conflictNeighbors ..).1 heN).1,heNot⟩
  have hCard : target.card ≤ 2 :=
    (Finset.card_le_card (Finset.sdiff_subset : target ⊆ conflictNeighbors ends red d)).trans
      (conflictNeighbors_card_le_two ends red d hred hD₂)
  have hSweep := blockState_deletion_route ends red blue processed target ∅ hd hred hblue hp ht
    (Finset.empty_subset _) (fun pending hsub => blockState_has_small_defect ends red blue processed
      pending hd hred hblue hp (hsub.trans (ht.trans Finset.sdiff_subset)) hFront
      ((Finset.card_le_card hsub).trans hCard))
  apply Relation.ReflTransGen.tail hSweep
  have hChanged := blockState_insert_change ends red processed d
  have hNot : d ∉ blockState ends red processed target := by
    intro h
    rcases (mem_blockState ..).1 h with h | h
    · exact Finset.disjoint_left.mp hd h.1 (Finset.mem_sdiff.mp hD).1
    · exact (Finset.mem_sdiff.mp hD).2 h
  have hps : insert d processed ⊆ blue := Finset.insert_subset_iff.mpr ⟨(Finset.mem_sdiff.mp hD).1,hp⟩
  have hUnion : blockState ends red processed target ∪ blockState ends red (insert d processed) ∅ =
      blockState ends red (insert d processed) ∅ := by
    rw [Finset.union_eq_right]
    rw [← hChanged]
    exact Finset.subset_insert _ _
  refine ⟨blockState_mem_matchings ends red blue processed target hred hblue hp,
    blockState_mem_matchings ends red blue (insert d processed) ∅ hred hblue hps,
    Or.inr ⟨d,(Finset.mem_sdiff.mp hD).1,hNot,hChanged.symm⟩,?_⟩
  rw [hUnion]
  exact blockState_has_small_defect ends red blue (insert d processed) ∅ hd hred hblue hps
    (Finset.empty_subset _) hNextFront (by simp)

theorem route_conflict_block (ends : E → Finset V) (red blue : Finset E)
    (hd : Disjoint red blue)
    (hred : Streaming.IsMatchingOn ends red) (hblue : Streaming.IsMatchingOn ends blue)
    (hEnds : ∀ e ∈ red∪blue, (ends e).card = 2)
    (hConn : ∀ e ∈ red ∪ blue, ∀ d ∈ red ∪ blue, connectedConflict ends (red ∪ blue) e d) :
    Relation.ReflTransGen (LocalMatchingMove ends red blue) red blue := by
  classical
  have hLoop (processed : Finset E) (hp : processed ⊆ blue)
      (hFront : (redFrontier ends red blue processed).card ≤ 2) :
      Relation.ReflTransGen (LocalMatchingMove ends red blue)
        (blockState ends red processed ∅) (blockState ends red blue ∅) := by
    generalize hMeasure : (blue \ processed).card = n
    induction n using Nat.strong_induction_on generalizing processed with
    | h n ih =>
      by_cases hR : (blue \ processed).Nonempty
      · have hNext : ∃ d ∈ blue \ processed,
            (redFrontier ends red blue (insert d processed)).card ≤ 2 := by
          by_cases hP : processed.Nonempty
          · obtain ⟨a,ha,d,hdR,hdC⟩ := frontier_next_of_connected ends red blue processed hred hblue hd
              hConn hp hP hR
            exact ⟨d,hdR,(frontier_le_of_shared ends red blue processed hred hblue hp a d ha hdR hdC
              (hEnds a (Finset.mem_union_left _ ((mem_redFrontier ..).1 ha).1))
              (hEnds d (Finset.mem_union_right _ (Finset.mem_sdiff.mp hdR).1))).trans hFront⟩
          · obtain ⟨d,hdR⟩ := hR
            have he := Finset.not_nonempty_iff_eq_empty.mp hP
            rewrite [he]
            exact ⟨d,he ▸ hdR,frontier_first_le_two ends red blue d hred
              (hEnds d (Finset.mem_union_right _ (Finset.mem_sdiff.mp hdR).1))⟩
        obtain ⟨d,hdR,hNext⟩ := hNext
        have hps : insert d processed ⊆ blue := Finset.insert_subset_iff.mpr
          ⟨(Finset.mem_sdiff.mp hdR).1,hp⟩
        have hEq : blue \ insert d processed = (blue \ processed).erase d := by
          ext e
          simp only [Finset.mem_sdiff,Finset.mem_insert,not_or,Finset.mem_erase]
          tauto
        have hSmall : (blue \ insert d processed).card < n := by
          rw [hEq,← hMeasure]
          exact Finset.card_erase_lt_of_mem hdR
        exact (process_blue_step ends red blue processed hd hred hblue hp hFront d hdR
          (hEnds d (Finset.mem_union_right _ (Finset.mem_sdiff.mp hdR).1)) hNext).trans
          (ih _ hSmall _ hps hNext rfl)
      · have hEq : processed = blue := Finset.Subset.antisymm hp (by
          intro d hd
          by_contra hn
          exact hR ⟨d,Finset.mem_sdiff.mpr ⟨hd,hn⟩⟩)
        rw [hEq]
  let target := red \ redNeighbors ends red blue
  have hSweep := blockState_deletion_route ends red blue blue target ∅ hd hred hblue
    (Finset.Subset.refl _) (Finset.Subset.refl _) (Finset.empty_subset _) (by
      intro pending _
      refine ⟨∅,by simp,Finset.empty_subset _,?_⟩
      intro a ha b hb hne
      have hRed {e : E} (he : e ∈ ((red ∪ blue) \ blockState ends red blue pending) \ ∅) : e ∈ red := by
        obtain ⟨heU,heM⟩ := Finset.mem_sdiff.mp (Finset.mem_sdiff.mp he).1
        exact (Finset.mem_union.mp heU).resolve_right (fun hb => heM ((mem_blockState ..).2 (Or.inr hb)))
      exact hred (hRed ha) (hRed hb) hne)
  have hStart : blockState ends red ∅ ∅ = red := by simp [blockState]
  have hStop : blockState ends red blue target = blue := by
    ext e
    simp only [mem_blockState,target,Finset.mem_sdiff]
    tauto
  have hInit : (redFrontier ends red blue ∅).card ≤ 2 := by simp [redFrontier]
  have hFirst := hLoop ∅ (Finset.empty_subset _) hInit
  rw [hStart] at hFirst
  rw [hStop] at hSweep
  exact hFirst.trans hSweep

end SubmodularMatching.GibbsSampler
