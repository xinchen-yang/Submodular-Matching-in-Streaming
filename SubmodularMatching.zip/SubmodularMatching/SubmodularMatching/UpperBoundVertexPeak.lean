import SubmodularMatching.UpperBoundVertexWorkspace
import SubmodularMatching.UpperBoundVertexSourceSpace

/-! # Peak postprocessing storage on the actual active schedule -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming NumericalCertificate
open scoped BigOperators

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The simultaneous guess records, working copy, and incumbent all sit
within the same quadratic logarithmic cell bound on every transcript.
The working copy is one currently processed stored graph. -/
theorem appendixSourceWorkspace_le (edges : ℕ → E) (ends : E → V × V)
    (f : Finset E → ℝ) (n arrivals : ℕ) (hn : 2 ≤ n) (ha : arrivals ≤ n ^ 2)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (hzero : f ∅ = 0)
    (k : ℕ) {N : ℕ} (hN : 0 < N) (hist : SourceBatchHistory N) (allEdges M : Finset E)
    (hin : ∀ i < k, edges i ∈ allEdges)
    (hloop : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet ends) A →
      A.card ≤ M.card)
    (hraw : ∀ i < k, ∀ j r, ∃ A, hist (i, j) r = marginal f (edges i) A)
    {m : ℕ} (storedEnds : Fin m → V × V) (current : ℕ) :
    let P := appendixScheduledSource edges ends f n arrivals hn ha hf hmono hzero
    let active := activeGuessIndices P.width (guessAnchor P.width P.value k)
        (singletonMaximum P.value k) P.span
    let len := fun j => (P.snapshot hist k j).stored.card
    current ∈ active → m = len current →
      sequentialWorkspace active len
        (sequentialGuessScratch (Fintype.card (IncidentVertex storedEnds)) m) M.card ≤
        (96 * appendixIncidenceConstant * appendixGuessCountConstant +
          8 * appendixGuessCountConstant + 50) * (M.card + 1) * ((n + 1).log2 + 1) ^ 2 := by
  intro P active len hcurrent hlen
  let w := (n + 1).log2 + 1
  have hw : 1 ≤ w := by dsimp [w]; omega
  have hL : P.span + 1 ≤ appendixGuessCountConstant * w := appendixGuessCount_le n
  have hA : active.card ≤ appendixGuessCountConstant * w := by
    by_cases hpos : 0 < singletonMaximum P.value k
    · exact (activeGuessIndices_card_le P.width P.value P.span k P.width_bound hpos).trans hL
    · have hz : singletonMaximum P.value k = 0 :=
        le_antisymm (le_of_not_gt hpos) (singletonMaximum_nonneg _ _)
      have hzero : active = ∅ := by
        dsimp only [active]
        rw [hz, activeGuessIndices_eq_empty_of_zero]
      simp [hzero]
  have hstores := appendixSource_totalStored_le edges ends f n arrivals hn ha hf hmono hzero k hN hist
    allEdges M hin hloop hMsub hM hmax hraw
  have hs : sequentialGuessScratch (Fintype.card (IncidentVertex storedEnds)) m ≤
      32 * (len current + 1) := hlen ▸ sequentialGuessScratch_le storedEnds
  exact sequentialWorkspace_le active len current hcurrent M.card appendixIncidenceConstant
    appendixGuessCountConstant w _ hw hA hstores hs

/-- Multiplying the fixed per-cell word allocation by the word width
turns the cell bound into the stated cubic logarithmic bit bound. -/
theorem sequentialWorkspace_bitCapacity {cells ν logWidth constant wordsPerCell : ℕ}
    (h : cells ≤ constant * (ν + 1) * logWidth ^ 2) :
    cells * wordsPerCell * logWidth ≤ (constant * wordsPerCell) * (ν + 1) * logWidth ^ 3 := by
  calc
    _ ≤ (constant * (ν + 1) * logWidth ^ 2) * wordsPerCell * logWidth :=
      Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ h)
    _ = _ := by ring

end

end SubmodularMatching.UpperBoundAssembly
