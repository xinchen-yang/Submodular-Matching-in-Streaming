import SubmodularMatching.NonmonotoneJointOutputs

/-! The public output law consumes the original stream through an endpoint
filter and samples only from the retained bank. -/
namespace SubmodularMatching.AppendixM
open Capacity Capacity.RealOracle Streaming Streaming.OracleQuery UpperBoundAssembly GibbsSampler Finset
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

def signedStreamOutput (S : SimpleEdgeStream E V) (b : V → ℕ)
    (f : Finset E → ℝ) (δ : ℝ) (amp : Bool)
    (rounding : ℕ → ℝ → SparseSlots (Admissible S b) (effectiveCapacity b) → CandidateLaw (Finset (Admissible S b))) :
    CandidateLaw (Finset E) := by
  classical
  let F := fun a => f (originalLabels S b a)
  let R := admissibleStream S b
  let cap := effectiveCapacity b
  let v := (Fintype.card V)^2
  let K := sourceWordScale v (v^2)
  let N := batchCount K (sourceFailureBudget δ)
  let bits := batchBits K
  let hpos := fun e => (show 0<cap (R.ends e).1 ∧ 0<cap (R.ends e).2 from
    ⟨effectiveCapacity_pos b _,effectiveCapacity_pos b _⟩)
  let step := fun i st e => jointStateStep R.ends cap hpos v N bits F (fun _ => e) i st
  let seed : RealOracle.GuessBank (SparseSlots (Admissible S b) cap) :=
    RealOracle.GuessBank.empty.advance (sparseEmpty cap) (guessWidth v) (guessSpan v) (F ∅)
    (fun _ _ st => st)
  let q := (CandidateLaw.onFilteredArrivals (keepPositive S.ends (clipped b)) step 0 (seed,(none,F ∅)) S.arrivals).bind
    (afterSignedPass F δ amp rounding)
  exact q.map (originalLabels S b)

theorem signedStreamOutput_eq (S : SimpleEdgeStream E V) (b : V → ℕ) (f : Finset E → ℝ)
    (δ : ℝ) (amp : Bool)
    (rounding : ℕ → ℝ → SparseSlots (Admissible S b) (effectiveCapacity b) → CandidateLaw (Finset (Admissible S b))) :
    signedStreamOutput S b f δ amp rounding =
      (jointOutput (admissibleStream S b) (effectiveCapacity b) (effectiveCapacity_pos b)
        (fun a => f (originalLabels S b a)) δ amp rounding).map (originalLabels S b) := by
  unfold signedStreamOutput jointOutput
  dsimp only
  rw [CandidateLaw.onFilteredArrivals_eq]
  rfl

private theorem literal_stream_observe (S : SimpleEdgeStream E V) (b : V → ℕ) (f test : Finset E → ℝ)
    (δ : ℝ) (amp : Bool)
    (rounding : ℕ → ℝ → SparseSlots (Admissible S b) (effectiveCapacity b) → CandidateLaw (Finset (Admissible S b))) :
    let q := signedStreamOutput S b f δ amp rounding
    let p := signedOriginalOutputs S b f δ rounding
    let p' := if amp then p.2 else p.1
    expected q.outcomes q.mass test = expected p'.outcomes p'.mass test := by
  have H := jointOutput_observe (admissibleStream S b) (effectiveCapacity b) (effectiveCapacity_pos b)
    (fun a => f (originalLabels S b a)) (fun a => test (originalLabels S b a)) δ amp rounding
  cases amp <;>
    simpa only [signedStreamOutput_eq,signedOriginalOutputs,CandidateLaw.map_expected,Function.comp_apply,
      Bool.false_eq_true,if_false,if_true] using H

theorem signed_stream_numerical (S : SimpleEdgeStream E V) (b : V → ℕ)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hn : ∀ a,0≤f a) (M : Finset E)
    (hM : Capacity.feasible S.ends b M) (hmax : ∀ a, Capacity.feasible S.ends b a → f a≤f M)
    (δ : ℝ) (hd : 0<δ)
    (rounding : ℕ → ℝ → SparseSlots (Admissible S b) (effectiveCapacity b) →
      CandidateLaw (Finset (Admissible S b)))
    (hfeasible : ∀ J τ st, ∀ a∈(rounding J τ st).outcomes,
      Capacity.feasible (admissibleStream S b).ends (effectiveCapacity b) a)
    (hquality : ∀ C : Finset (Admissible S b), originalLabels S b C = M →
      RoundingGuarantee (admissibleStream S b) (effectiveCapacity b)
        (fun a => f (originalLabels S b a)) C (sourceFailureBudget δ) rounding) :
    let p := signedStreamOutput S b f δ false rounding
    let q := signedStreamOutput S b f δ true rounding
    f M/(4727/1000) ≤ expected p.outcomes p.mass f ∧ failureMass q f (f M/(4727/1000)) ≤ δ := by
  have h := signed_original_quality S b f hf hn M hM hmax δ hd rounding hfeasible hquality
  have first := literal_stream_observe S b f f δ false rounding
  have second := literal_stream_observe S b f (fun a => if f M/(4727/1000)≤f a then 0 else 1) δ true rounding
  exact ⟨h.2.2.1.trans_eq first.symm,second.trans_le h.2.2.2⟩

end
end SubmodularMatching.AppendixM
