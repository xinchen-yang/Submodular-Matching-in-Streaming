import SubmodularMatching.NonmonotoneStreamOutput

/-! Every supported stream outcome is feasible, including failed estimates. -/
namespace SubmodularMatching.AppendixM
open Capacity Capacity.RealOracle Streaming Streaming.OracleQuery UpperBoundAssembly GibbsSampler Finset
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

theorem afterSignedPass_feasible {b : V→ℕ} (ends : E→V×V) (f : Finset E→ℝ) (δ : ℝ) (amp : Bool)
    (rounding : ℕ→ℝ→SparseSlots E b→CandidateLaw (Finset E))
    (legal : ∀ J τ st, ∀ x∈(rounding J τ st).outcomes, Capacity.feasible ends b x)
    (st : RealOracle.GuessBank (SparseSlots E b) × (Option E × ℝ))
    (hinit : Capacity.feasible ends b (incumbentSet st.2.1)) :
    ∀ a∈(afterSignedPass f δ amp rounding st).outcomes, Capacity.feasible ends b a := by
  classical
  let states := (univ : Finset (Finset E)).filter (Capacity.feasible ends b)
  let q := bankCandidates (fun _ => rounding (sourceFailureBudget δ)) st.1
  let a := incumbentSet st.2.1
  have hi : a∈states := mem_filter.mpr ⟨mem_univ _,hinit⟩
  have hs : ∀ p∈q, p.outcomes⊆states := by
    intro p hp s hmem
    change p ∈ st.1.states.map (fun data => rounding (sourceFailureBudget δ) (st.1.epoch.scale data.1) data.2) at hp
    obtain ⟨data,_,rfl⟩ := List.mem_map.mp hp
    exact mem_filter.mpr ⟨mem_univ _,legal _ _ _ _ hmem⟩
  intro x hx
  unfold afterSignedPass at hx
  dsimp only at hx
  split at hx
  · exact (by simpa [CandidateLaw.pure] using hx : x=a) ▸ hinit
  · cases amp with
    | false =>
      simp only [Bool.false_eq_true,if_false] at hx
      exact (mem_filter.mp (incumbentScan_invariant f _ q states a hi hs hx)).2
    | true =>
      simp only [if_true,incumbentRepeat_law] at hx
      apply (mem_filter.mp (incumbentScan_invariant f _ _ states a hi ?_ hx)).2
      intro p hp
      obtain ⟨_,rfl⟩ := List.mem_replicate.mp hp
      exact incumbentScan_invariant f _ q states a hi hs

theorem jointOutput_feasible (S : SimpleEdgeStream E V) (b : V → ℕ) (hb : ∀ v, 0<b v)
    (f : Finset E→ℝ) (δ : ℝ) (amp : Bool)
    (rounding : ℕ→ℝ→SparseSlots E b→CandidateLaw (Finset E))
    (legal : ∀ J τ st, ∀ x∈(rounding J τ st).outcomes, Capacity.feasible S.ends b x) :
    ∀ a∈(jointOutput S b hb f δ amp rounding).outcomes, Capacity.feasible S.ends b a := by
  classical
  intro a ha
  by_cases ne : Nonempty E
  · let edges := S.edgeAt (Classical.choice ne)
    let v := (Fintype.card V)^2
    let K := sourceWordScale v (v^2)
    let N := batchCount K (sourceFailureBudget δ)
    let bits := batchBits K
    let pos : ∀ e, 0<b (S.ends e).1 ∧ 0<b (S.ends e).2 := fun _ => ⟨hb _,hb _⟩
    let base := bankWithTape S.ends b pos v N bits f edges (fun _ _ _ => 0) 0
    let init := (base,realIncumbent f edges 0)
    let step := fun i st e => jointStateStep S.ends b pos v N bits f (fun _ => e) i st
    unfold jointOutput at ha
    obtain ⟨t, ht, hq⟩ := (CandidateLaw.mem_bind _ _ a).mp ha
    change t ∈ (CandidateLaw.onArrivals step 0 init S.arrivals).outcomes at ht
    rw [CandidateLaw.onArrivals_execute step 0 init S.arrivals (Classical.choice ne) edges (by
      intro i _
      simp [edges,SimpleEdgeStream.edgeAt])] at ht
    have same := jointPass_incumbent S.ends b pos v N bits f edges base 0 S.arrivals.length t ht
    apply afterSignedPass_feasible S.ends f δ amp rounding legal t _ a hq
    rw [same,Nat.zero_add]
    exact realIncumbent_feasible S.ends b pos f edges S.arrivals.length
  · have he : a=∅ := eq_empty_iff_forall_notMem.mpr (fun e _ => ne ⟨e⟩)
    subst a
    intro v
    simp [Capacity.incidences]

theorem signedStreamOutput_feasible (S : SimpleEdgeStream E V) (b : V → ℕ) (f : Finset E→ℝ)
    (δ : ℝ) (amp : Bool)
    (rounding : ℕ→ℝ→SparseSlots (Admissible S b) (effectiveCapacity b)→CandidateLaw (Finset (Admissible S b)))
    (legal : ∀ J τ st, ∀ x∈(rounding J τ st).outcomes,
      Capacity.feasible (admissibleStream S b).ends (effectiveCapacity b) x) :
    ∀ a∈(signedStreamOutput S b f δ amp rounding).outcomes, Capacity.feasible S.ends b a := by
  intro a ha
  rw [signedStreamOutput_eq] at ha
  obtain ⟨s,hs,rfl⟩ := mem_image.mp ha
  exact (effective_feasible_iff S b s).mp (jointOutput_feasible (admissibleStream S b)
    (effectiveCapacity b) (effectiveCapacity_pos b) _ δ amp rounding legal s hs)

end
end SubmodularMatching.AppendixM
