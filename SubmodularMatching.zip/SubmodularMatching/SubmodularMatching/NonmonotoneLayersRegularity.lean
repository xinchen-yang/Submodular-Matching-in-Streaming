import SubmodularMatching.NonmonotoneLayersCapacity
import SubmodularMatching.NonmonotoneLayersSlotGraph

/-! Range and Lipschitz estimates for the two actual projected layers on a
complete bipartite slot fiber, throughout the entire decoder interval. -/

namespace SubmodularMatching.NonmonotoneLayers

open Set Shearer GibbsMatching

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem unionMass_lipschitz (ends : E → Finset V) (F : Finset E) (a b : E → ℝ) (d : ℝ)
    (ha : ∀ e ∈ F, 0 ≤ a e) (hb : ∀ e ∈ F, 0 ≤ b e)
    (hnorm : (∑ e ∈ F, a e) + (∑ e ∈ F, b e) = 1)
    (h₁ : ∀ t ∈ Icc 0 d, InteriorLaw ends F (fun e => t*a e))
    (h₂ : ∀ t ∈ Icc 0 d, InteriorLaw ends F (fun e => t*b e))
    (x y : ℝ) (hx : x ∈ Icc 0 d) (hy : y ∈ Icc 0 d) (hxy : x ≤ y) :
    0 ≤ unionMass ends F a b y - unionMass ends F a b x ∧
      unionMass ends F a b y - unionMass ends F a b x ≤ y-x := by
  let m := unionMass ends F a b
  let Z := fiberZ ends F
  let D := fiberSlope ends F
  let m' := fun t => D a t*Z b t + Z a t*D b t
  have hdv (t : ℝ) : HasDerivAt m (m' t) t := by
    convert (hasDerivAt_const t (1:ℝ)).sub ((fiberZ_hasDerivAt ends F a t).mul (fiberZ_hasDerivAt ends F b t)) using 1
    dsimp [m',D,Z]; ring
  have hbound (t : ℝ) (ht : t ∈ Icc 0 d) : 0 ≤ m' t ∧ m' t ≤ 1 := by
    obtain ⟨az,az1,ad0,ad1⟩ := fiber_bounds ends F a t (h₁ t ht) ha
    obtain ⟨bz,bz1,bd0,bd1⟩ := fiber_bounds ends F b t (h₂ t ht) hb
    have aa := Finset.sum_nonneg ha
    have bb := Finset.sum_nonneg hb
    have ap := (mul_nonneg aa az).trans ad0
    have bp := (mul_nonneg bb bz).trans bd0
    refine ⟨add_nonneg (mul_nonneg ap bz) (mul_nonneg az bp),?_⟩
    have hab := mul_le_mul ad1 bz1 bz aa
    have hba := mul_le_mul az1 bd1 bp zero_le_one
    change fiberSlope ends F a t * fiberZ ends F b t + fiberZ ends F a t * fiberSlope ends F b t ≤ 1
    linarith only [hab,hba,hnorm]
  have hcont : ContinuousOn m (Icc 0 d) := fun t _ => (hdv t).continuousAt.continuousWithinAt
  have hdiff : DifferentiableOn ℝ m (interior (Icc 0 d)) := fun t _ => (hdv t).differentiableAt.differentiableWithinAt
  have hmon : MonotoneOn m (Icc 0 d) := monotoneOn_of_deriv_nonneg (convex_Icc _ _) hcont hdiff
    (fun t ht => (hdv t).deriv ▸ (hbound t (interior_subset ht)).1)
  refine ⟨sub_nonneg.mpr (hmon hx hy hxy), ?_⟩
  have hh := (convex_Icc (0:ℝ) d).image_sub_le_mul_sub_of_deriv_le (C := (1:ℝ)) hcont hdiff
    (fun t ht => by rw [(hdv t).deriv]; exact (hbound t (interior_subset ht)).2) x hx y hy hxy
  change m y-m x ≤ y-x
  linarith only [hh]

def pairMass (a b : ℕ) (θ₁ θ₂ y : ℝ) : ℝ :=
  1-slotPolynomial a b (y*θ₁/((a:ℝ)*b))*slotPolynomial a b (y*θ₂/((a:ℝ)*b))

/-- Numerical data for the capacitated label. The result gives the two actual
avoidance probabilities, the monotone 1-Lipschitz bound, and the unique
feasible solution to the optimizer's requested marginal. -/
theorem pairMass_bounds (a b : ℕ) (ha : 0 < a) (hb : 0 < b) (θ₁ θ₂ d u : ℝ)
    (h₁ : 0 ≤ θ₁) (h₂ : 0 ≤ θ₂) (hθ : θ₁+θ₂=1) (hd : 0 < d) (hd1 : d < 1)
    (hcap₁ : d*θ₁ ≤ 1/4) (hcap₂ : d*θ₂ ≤ 1/4) (hu : 0 ≤ u) (hu1 : u ≤ 1) :
    (∀ t ∈ Icc 0 d, ∀ θ ∈ ({θ₁,θ₂} : Finset ℝ),
      slotPolynomial a b (t*θ/((a:ℝ)*b)) ∈ Icc 0 1) ∧
    (∀ x ∈ Icc 0 d, ∀ y ∈ Icc 0 d, x ≤ y →
      0 ≤ pairMass a b θ₁ θ₂ y - pairMass a b θ₁ θ₂ x ∧ pairMass a b θ₁ θ₂ y - pairMass a b θ₁ θ₂ x ≤ y-x) ∧
    ∃! y : ℝ, y ∈ Icc 0 (d*u) ∧ pairMass a b θ₁ θ₂ y = NonmonotoneOptimizer.action (1/d) u := by
  classical
  let F := (Finset.univ : Finset (Fin a)) ×ˢ (Finset.univ : Finset (Fin b))
  let rate := fun (θ : ℝ) (_e : Fin a × Fin b) => θ/((a:ℝ)*b)
  have hcard : F.card = a*b := by simp [F]
  have hden : 0 < (a:ℝ)*b := mul_pos (by exact_mod_cast ha) (by exact_mod_cast hb)
  have hends (e : Fin a × Fin b) (_ : e ∈ F) : (slotEnds e).card = 2 := by simp [slotEnds]
  have hsum (θ : ℝ) : (∑ e ∈ F, rate θ e) = θ := by
    simp only [rate,Finset.sum_const,nsmul_eq_mul,hcard,Nat.cast_mul]; field_simp
  have heq (θ t : ℝ) : fiberZ slotEnds F (rate θ) t = slotPolynomial a b (t*θ/((a:ℝ)*b)) := by
    unfold fiberZ
    have H := slotGraph_polynomial (Finset.univ : Finset (Fin a)) (Finset.univ : Finset (Fin b)) (t*(θ/((a:ℝ)*b)))
    simpa [F,rate,mul_div_assoc] using H
  have law (θ : ℝ) (hθ0 : 0 ≤ θ) (hcap : d*θ ≤ 1/4) (t : ℝ) (ht : t ∈ Icc 0 d) :
      InteriorLaw slotEnds F (fun e => t*rate θ e) := by
    have hr : ∀ e ∈ F, 0 ≤ t*rate θ e := fun _ _ => mul_nonneg ht.1 (div_nonneg hθ0 hden.le)
    apply interiorLaw_of_degree (1/2) (by norm_num) (by norm_num) hr hends
    intro v
    have hsub : incident slotEnds F v ⊆ F := Finset.filter_subset _ _
    have h := Finset.sum_le_sum_of_subset_of_nonneg (f := fun e => t*rate θ e) hsub (fun e he _ => hr e he)
    have hsum' : (∑ e ∈ F, t*rate θ e)=t*θ := by rw [←Finset.mul_sum,hsum]
    change (∑ e ∈ incident slotEnds F v, t*rate θ e) ≤ ∑ e ∈ F, t*rate θ e at h
    rw [hsum'] at h
    nlinarith only [h,hcap,mul_le_mul_of_nonneg_right ht.2 hθ0]
  have hmodel : unionMass slotEnds F (rate θ₁) (rate θ₂) = pairMass a b θ₁ θ₂ := by
    funext t; simp only [unionMass,pairMass,heq]
  have hr (θ : ℝ) (h : 0 ≤ θ) (e : Fin a × Fin b) (_ : e ∈ F) : 0 ≤ rate θ e := div_nonneg h hden.le
  have hn : (∑ e ∈ F, rate θ₁ e)+(∑ e ∈ F, rate θ₂ e) = 1 := by rw [hsum,hsum,hθ]
  refine ⟨?_,?_,?_⟩
  · intro t ht θ hmem
    have hp (θ : ℝ) (h : 0 ≤ θ) (hc : d*θ ≤ 1/4) := fiber_bounds slotEnds F (rate θ) t (law θ h hc t ht) (hr θ h)
    rcases Finset.mem_insert.mp hmem with rfl | h
    · rw [← heq]; exact ⟨(hp _ h₁ hcap₁).1,(hp _ h₁ hcap₁).2.1⟩
    · obtain rfl := Finset.mem_singleton.mp h
      rw [← heq]; exact ⟨(hp _ h₂ hcap₂).1,(hp _ h₂ hcap₂).2.1⟩
  · rw [←hmodel]
    exact fun x hx y hy => unionMass_lipschitz slotEnds F _ _ d (hr _ h₁) (hr _ h₂) hn
      (law _ h₁ hcap₁) (law _ h₂ hcap₂) x y hx hy
  · rw [←hmodel]
    exact decode_fiber slotEnds F _ _ (hr _ h₁) (hr _ h₂) hn d u hd hd1 hu hu1 (law _ h₁ hcap₁) (law _ h₂ hcap₂)

end

end SubmodularMatching.NonmonotoneLayers
