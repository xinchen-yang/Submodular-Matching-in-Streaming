import SubmodularMatching.CertificateCells
import Mathlib.Data.Finset.Basic

/-!
# Finite grid conditions for local source inequalities

The local objective is piecewise affine in two variables plus one positive
part. This module reduces its universal inequality to surviving grid points
and intersections with the kink. A separate branch handles ratio one.
-/

namespace SubmodularMatching.SourceCertificate

/-- Cells with endpoints in the supplied grid cover every argument needed by
the checker up to the indicated axis intercept. -/
def GridCovers (grid : Finset ℝ) (F : ℝ → ℝ) (bound : ℝ) : Prop :=
  ∀ x, 0 ≤ x → x ≤ bound →
    ∃ l ∈ grid, ∃ r ∈ grid, l ≤ x ∧ x ≤ r ∧
      ∃ slope intercept, ∀ z, l ≤ z → z ≤ r → F z = slope * z + intercept

noncomputable section

/-- The objective on the nonnegative half-plane used in the checker. -/
def gridValue (U V : ℝ → ℝ) (k c a d : ℝ) : ℝ :=
  U a + V d + k * max (1 - c * a - (1 - c) * d) 0

/-- The three checks are the feasible grid pairs and the kink intersections for
each of the two grids. Their conclusion covers the unbounded quadrant. -/
theorem grid_checks_sound (U V : ℝ → ℝ) (gx gy : Finset ℝ) (k c target : ℝ)
    (hc : 0 < c) (hc1 : c < 1) (hU : Monotone U) (hV : Monotone V)
    (hux : GridCovers gx U (1 / c)) (hvy : GridCovers gy V (1 / (1 - c)))
    (hgrid : ∀ a ∈ gx, ∀ d ∈ gy, 0 ≤ a → 0 ≤ d → c * a + (1 - c) * d ≤ 1 →
      target ≤ gridValue U V k c a d)
    (hxcut : ∀ a ∈ gx, ∀ d, 0 ≤ a → 0 ≤ d → c * a + (1 - c) * d = 1 →
      target ≤ gridValue U V k c a d)
    (hycut : ∀ d ∈ gy, ∀ a, 0 ≤ a → 0 ≤ d → c * a + (1 - c) * d = 1 →
      target ≤ gridValue U V k c a d)
    (hgx : ∀ a ∈ gx, 0 ≤ a) (hgy : ∀ d ∈ gy, 0 ≤ d)
    (a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d) :
    target ≤ gridValue U V k c a d := by
  have hb : 0 < 1 - c := sub_pos.mpr hc1
  have hbelow (x y : ℝ) (hx : 0 ≤ x) (hy : 0 ≤ y) (hhalf : c * x + (1 - c) * y ≤ 1) :
      target ≤ gridValue U V k c x y := by
    have hxb : x ≤ 1 / c := (le_div_iff₀ hc).2 (by
      linarith only [hhalf, mul_nonneg hb.le hy])
    have hyb : y ≤ 1 / (1 - c) := (le_div_iff₀ hb).2 (by
      linarith only [hhalf, mul_nonneg hc.le hx])
    obtain ⟨xl, hxlK, xu, hxuK, hxl, hxu, sU, bU, haffU⟩ := hux x hx hxb
    obtain ⟨yl, hylK, yu, hyuK, hyl, hyu, sV, bV, haffV⟩ := hvy y hy hyb
    have hid (a d : ℝ) (hal : xl ≤ a) (hau : a ≤ xu) (hdl : yl ≤ d) (hdu : d ≤ yu)
        (hh : c * a + (1 - c) * d ≤ 1) :
        gridValue U V k c a d = (sU - k * c) * a + (sV - k * (1 - c)) * d +
          (bU + bV + k) := by
      rw [gridValue, max_eq_left (by linarith), haffU a hal hau, haffV d hdl hdu]
      ring
    rw [hid x y hxl hxu hyl hyu hhalf]
    apply affine_on_clipped_cell c (1 - c) xl xu yl yu _ _ _ target hc hb _ x y hxl hxu hyl hyu hhalf
    intro a d h
    obtain ⟨hal, hau, hdl, hdu, hh, hcheck⟩ := h
    rw [← hid a d hal hau hdl hdu hh]
    have hna := (hgx xl hxlK).trans hal
    have hnd := (hgy yl hylK).trans hdl
    have hxmem : a = xl ∨ a = xu → a ∈ gx := by
      rintro (rfl | rfl)
      · exact hxlK
      · exact hxuK
    have hymem : d = yl ∨ d = yu → d ∈ gy := by
      rintro (rfl | rfl)
      · exact hylK
      · exact hyuK
    rcases hcheck with ⟨ha, hd⟩ | ⟨heq, ha | hd⟩
    · exact hgrid a (hxmem ha) d (hymem hd) hna hnd hh
    · exact hxcut a (hxmem ha) d hna hnd heq
    · exact hycut d (hymem hd) a hna hnd heq
  by_cases hhalf : c * a + (1 - c) * d ≤ 1
  · exact hbelow a d ha hd hhalf
  · let s := c * a + (1 - c) * d
    have hs : 1 < s := lt_of_not_ge hhalf
    have hs0 : 0 < s := by linarith
    have hnal := div_nonneg ha hs0.le
    have hndl := div_nonneg hd hs0.le
    have hscale : c * (a / s) + (1 - c) * (d / s) = 1 := by
      calc
        _ = s / s := by dsimp only [s]; ring
        _ = 1 := div_self hs0.ne'
    have hlower := hbelow (a / s) (d / s) hnal hndl hscale.le
    have h1 : a / s ≤ a := (div_le_iff₀ hs0).2 (by
      linarith only [mul_le_mul_of_nonneg_left hs.le ha, mul_one a])
    have h2 : d / s ≤ d := (div_le_iff₀ hs0).2 (by
      linarith only [mul_le_mul_of_nonneg_left hs.le hd, mul_one d])
    have h0l : 1 - c * (a / s) - (1 - c) * (d / s) ≤ 0 := by linarith only [hscale]
    have h0 : 1 - c * a - (1 - c) * d ≤ 0 := by linarith only [le_of_not_ge hhalf]
    rw [gridValue, max_eq_right h0l, mul_zero, add_zero] at hlower
    rw [gridValue, max_eq_right h0, mul_zero, add_zero]
    exact hlower.trans (add_le_add (hU h1) (hV h2))

/-- At ratio one the second coordinate affects only its monotone additive
term. The one-dimensional checks are grid positions through one and the
additional interpolation point at one. -/
theorem grid_checks_sound_at_one (U V : ℝ → ℝ) (gx : Finset ℝ) (k target : ℝ)
    (hU : Monotone U) (hV : Monotone V) (hcover : GridCovers gx U 1)
    (hgrid : ∀ a ∈ gx, a ≤ 1 → target ≤ gridValue U V k 1 a 0)
    (hone : target ≤ gridValue U V k 1 1 0)
    (a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d) :
    target ≤ gridValue U V k 1 a d := by
  have h0 : target ≤ gridValue U V k 1 a 0 := by
    by_cases hab : a ≤ 1
    · obtain ⟨l, hlK, r, hrK, hl, hr, slope, intercept, hlin⟩ := hcover a ha hab
      let u := min r 1
      have hau : a ≤ u := le_min hr hab
      have hid (x : ℝ) (hxl : l ≤ x) (hxr : x ≤ r) (hx : x ≤ 1) :
          gridValue U V k 1 x 0 = (slope - k) * x + (intercept + V 0 + k) := by
        rw [gridValue, one_mul, sub_self, zero_mul, sub_zero, max_eq_left (sub_nonneg.mpr hx),
          hlin x hxl hxr]
        ring
      have hL := hgrid l hlK (hl.trans hab)
      have hR : target ≤ gridValue U V k 1 u 0 := by
        rcases min_choice r (1 : ℝ) with hr' | h1'
        · rw [show u = r from hr']
          exact hgrid r hrK (hr' ▸ min_le_right r 1)
        · rw [show u = 1 from h1']
          exact hone
      rw [hid l le_rfl (hl.trans hr) (hl.trans hab)] at hL
      rw [hid u (hl.trans hau) (min_le_left _ _) (min_le_right _ _)] at hR
      rw [hid a hl hr hab]
      exact affine_lower_of_endpoints _ _ _ _ _ _ hl hau hL hR
    · have h1a : 1 ≤ a := le_of_lt (lt_of_not_ge hab)
      simp only [gridValue, one_mul, sub_self, max_self, mul_zero, add_zero] at hone
      rw [gridValue, one_mul, sub_self, zero_mul, sub_zero,
        max_eq_right (sub_nonpos.mpr h1a), mul_zero, add_zero]
      exact hone.trans (add_le_add (hU h1a) le_rfl)
  simp only [gridValue, one_mul, sub_self, zero_mul, sub_zero] at h0 ⊢
  exact h0.trans (add_le_add (add_le_add le_rfl (hV hd)) le_rfl)

end

end SubmodularMatching.SourceCertificate
