import SubmodularMatching.UpperBoundParametricOptimizer
import SubmodularMatching.UpperBoundParametricSchedule
import SubmodularMatching.UpperBoundParametricFinalTrial
import SubmodularMatching.UpperBoundPreprocessing

/-! # Joint finite source and adaptive optimization law for Appendix L.1 -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint Streaming GibbsSampler TwoStage
open NumericalCertificate

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable {Ns Ng : ℕ} (cfg : FamilyOptimizerSettings)

def parametricFinalDiscountGrid (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ) : ℕ → ℕ :=
  fun j => parametricGradientDiscountGrid cfg.error (finalGuessCount P batches j)

def parametricFinalOptimizerChoice (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (j : ℕ) : CandidateLaw (OptimizerTape (finalGuessCount P batches j) Ng) :=
  let m := finalGuessCount P batches j
  let emb := finalGuessEmbedding P batches hunique j
  if hm : 0 < m then
    parametricOptimizerTapeLaw cfg hm (restrictEnds (P.ends ∘ emb)) (finalGuessConfig P j).tau
      (finalGuessFrozen P batches j ∘ emb) (reindexedObjective emb P.objective)
      (parametricGradientDiscountGrid cfg.error m) (parametricGradientCoordinateBits cfg.error m)
  else CandidateLaw.pure (OptimizerTape.empty m Ng)

/-- The schedule samples only the active guesses. The family records their
outcomes for analysis of the accuracy event. -/
def parametricFinalOptimizerLaw (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k) :
    CandidateLaw (OptimizerFamily P batches Ng) :=
  CandidateLaw.assign (parametricFinalOptimizerChoice cfg P batches hunique) ((finalGuessIndices P).sort (· ≤ ·))
    (fun j => OptimizerTape.empty (finalGuessCount P batches j) Ng)

theorem parametricOptimizerFamilyGood_accurate (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (tapes : OptimizerFamily P batches Ng)
    (ht : tapes ∈ (parametricFinalOptimizerLaw cfg P batches hunique).outcomes)
    (hg : optimizerFamilyGood P batches tapes)
    (K : ℕ) (he : cfg.error = 1 / (K : ℝ)) (hp : ∀ j, cfg.p = (finalGuessConfig P j).p) :
    parametricGoodFinalOptimizers P K batches hunique (parametricFinalDiscountGrid cfg P batches)
      (fun j => (tapes j).draw) := by
  intro j hj hm
  let m := finalGuessCount P batches j
  let emb := finalGuessEmbedding P batches hunique j
  have hnd := (finalGuessIndices P).sort_nodup (· ≤ ·)
  have hs := CandidateLaw.assign_support (parametricFinalOptimizerChoice cfg P batches hunique)
    ((finalGuessIndices P).sort (· ≤ ·)) hnd (fun j => OptimizerTape.empty _ Ng) tapes ht j
    ((Finset.mem_sort (· ≤ ·)).2 hj)
  simp only [parametricFinalOptimizerChoice, dif_pos hm] at hs
  have hgrid := parametricGradientDiscountGrid_spec cfg.error cfg.error_pos m hm
  have ha := parametricOptimizerTape_accurate cfg hm (restrictEnds (P.ends ∘ emb))
    (finalGuessConfig P j).tau (finalGuessFrozen P batches j ∘ emb) (reindexedObjective emb P.objective)
    (parametricGradientDiscountGrid cfg.error m) (parametricGradientCoordinateBits cfg.error m) (tapes j) hs (hg j hj)
  refine ⟨hgrid.1, ?_, ?_⟩
  · simpa only [← he] using hgrid.2
  · intro k hk i
    have hk' : k < FiniteGreedy.stages NumericalCertificate.degree m cfg.error := by simpa only [he] using hk
    simpa only [OptimizerTape.draw, parametricOptimizerPoint, parametricFinalDiscountGrid, snappedCoordinate, hp j, he] using ha k hk' i


theorem parametricFinalOptimizerLaw_failure (P : ScheduledSource E V) (batches : ℕ → Fin Ns → ℝ)
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (harrived : ∀ e, e ∈ arrivedEdges P.edges P.arrivals)
    (hB : 0 < singletonMaximum P.value P.arrivals)
    (ω : ℝ) (hω : 0 < ω) (hω1 : ω ≤ 1) :
    let L := P.span + 1
    let N := parametricGradientSamples cfg.error (P.vertices ^ 2) L ω
    let q := parametricFinalOptimizerLaw (Ng := N) cfg P batches hunique
    expected q.outcomes q.mass (optimizerFamilyFailure P batches) ≤ ω / 2 := by
  classical
  dsimp only
  let L := P.span + 1
  let N := parametricGradientSamples cfg.error (P.vertices ^ 2) L ω
  let δ := ω / (2 * (L : ℝ))
  let is := (finalGuessIndices P).sort (· ≤ ·)
  have hL : 0 < L := Nat.succ_pos _
  have hL' : (0 : ℝ) < L := by exact_mod_cast hL
  have hδ : 0 < δ := by dsimp [δ]; positivity
  have hnd := (finalGuessIndices P).sort_nodup (· ≤ ·)
  have hbound (j : ℕ) (hj : j ∈ is) :
      let a := parametricFinalOptimizerChoice (Ng := N) cfg P batches hunique j
      expected a.outcomes a.mass optimizerTapeFailureIndicator ≤ δ := by
    dsimp only
    let m := finalGuessCount P batches j
    let emb := finalGuessEmbedding P batches hunique j
    by_cases hm : 0 < m
    · have hcfg : j ∈ finalGuessIndices P := (Finset.mem_sort (· ≤ ·)).1 hj
      have ha : finalGuessActive P j :=
        (mem_activeGuessIndices _ _ _ _ _ (guessAnchor_pos _ _ _ hB)
          (guessAnchor_le _ _ _) P.width_bound).1 hcfg
      have hscale : 0 < finalGuessScale P j := hB.trans_le ha.2.1
      have ht := P.config_tau (finalGuessScale P j) hscale
      have ht' : 0 < (finalGuessConfig P j).tau := ht.symm ▸ hscale
      have hcount : m ≤ P.vertices ^ 2 :=
        (finalGuessCount_le_arrivals P batches hunique j).trans P.arrivals_bound
      have hparams := parametricGradientSamples_spec cfg.error cfg.error_pos m (P.vertices ^ 2) L hm hcount hL ω hω hω1
      let F := reindexedObjective emb P.objective
      have hsing (e : Fin m) : F {e} ≤ (finalGuessConfig P j).tau := by
        obtain ⟨i, hi, he⟩ := Finset.mem_image.mp (harrived (emb e))
        change P.objective {emb e} ≤ _
        rw [← he]
        exact (singleton_le_maximum P.value (Finset.mem_range.mp hi)).trans (ht.symm ▸ ha.2.1)
      have hm' : 0 < finalGuessCount P batches j := hm
      simpa only [parametricFinalOptimizerChoice, dif_pos hm'] using
        parametricOptimizerTape_failure_le (N := N) cfg hm (restrictEnds (P.ends ∘ emb))
          (finalGuessConfig P j).tau (finalGuessFrozen P batches j ∘ emb) F
          (parametricGradientDiscountGrid cfg.error m) (parametricGradientCoordinateBits cfg.error m)
          (reindexedObjective_submodular emb P.objective P.submodular)
          (reindexedObjective_monotone emb P.objective P.monotone)
          (by simpa [F, reindexedObjective] using P.normalized)
          ht' hsing hparams.1 δ hδ (parametricGradientCoordinateBits_spec cfg.error cfg.error_pos m hm) hparams.2
    · simp [parametricFinalOptimizerChoice, show ¬0 < finalGuessCount P batches j from hm,
        optimizerTapeFailureIndicator, OptimizerTape.empty, hδ.le]
  let base : OptimizerFamily P batches N := fun j => OptimizerTape.empty _ N
  have h := CandidateLaw.assign_failure_le (parametricFinalOptimizerChoice cfg P batches hunique) is hnd base
    (fun _ t => t.good = true) δ hbound
  have hlength : is.length ≤ L := by
    dsimp only [is]
    rw [Finset.length_sort]
    exact activeGuessIndices_card_le P.width P.value P.span P.arrivals P.width_bound hB
  have hlength' : (is.length : ℝ) ≤ L := by exact_mod_cast hlength
  have hcap : (L : ℝ) * δ = ω / 2 := by dsimp [δ]; field_simp
  have hh : (is.length : ℝ) * δ ≤ ω / 2 := (mul_le_mul_of_nonneg_right hlength' hδ.le).trans_eq hcap
  have htest : optimizerFamilyFailure (Ng := N) P batches =
      (fun r => if ∀ j ∈ is, (r j).good = true then 0 else 1) := by
    funext r
    unfold optimizerFamilyFailure optimizerFamilyGood
    have heq : (∀ j ∈ finalGuessIndices P, (r j).good = true) ↔
        (∀ j ∈ is, (r j).good = true) := by
      simp only [is, Finset.mem_sort]
    by_cases hr : ∀ j ∈ finalGuessIndices P, (r j).good = true
    · rw [if_pos hr, if_pos (heq.mp hr)]
    · rw [if_neg hr, if_neg (mt heq.mpr hr)]
  rw [htest]
  exact h.trans hh


/-- The optimizer's draws are attached to the actual stored instance
sizes, conditional on the completed source execution. -/
def parametricPreparationLaw (P : ScheduledSource E V) (source : CandidateLaw (ℕ → Fin Ns → ℝ))
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k) :
    CandidateLaw (PreparedTape P Ns Ng) := by
  classical
  exact source.bind fun b => (parametricFinalOptimizerLaw cfg P b hunique).map (PreparedTape.mk b)

theorem parametricPreparationLaw_support (P : ScheduledSource E V) (source : CandidateLaw (ℕ → Fin Ns → ℝ))
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (t : PreparedTape P Ns Ng) (ht : t ∈ (parametricPreparationLaw cfg P source hunique).outcomes) :
    t.stream ∈ source.outcomes ∧ t.optimizer ∈ (parametricFinalOptimizerLaw cfg P t.stream hunique).outcomes := by
  classical
  obtain ⟨b, hb, hat⟩ := (source.mem_bind
    (fun b => (parametricFinalOptimizerLaw cfg P b hunique).map (PreparedTape.mk b)) t).mp ht
  obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp hat
  exact ⟨hb, ha⟩

theorem parametricPreparationLaw_failure (P : ScheduledSource E V) (source : CandidateLaw (ℕ → Fin Ns → ℝ))
    (hunique : ∀ i < P.arrivals, ∀ k < P.arrivals, P.edges i = P.edges k → i = k)
    (harrived : ∀ e, e ∈ arrivedEdges P.edges P.arrivals)
    (hB : 0 < singletonMaximum P.value P.arrivals)
    (ω : ℝ) (hω : 0 < ω) (hω1 : ω ≤ 1)
    (hsource : expected source.outcomes source.mass (sourceFailureIndicator P) ≤ ω / 2) :
    let Ng := parametricGradientSamples cfg.error (P.vertices ^ 2) (P.span + 1) ω
    let q := parametricPreparationLaw (Ng := Ng) cfg P source hunique
    expected q.outcomes q.mass (preparationFailure P) ≤ ω := by
  classical
  dsimp only
  let Ng := parametricGradientSamples cfg.error (P.vertices ^ 2) (P.span + 1) ω
  unfold parametricPreparationLaw
  rw [CandidateLaw.bind_expected]
  simp_rw [CandidateLaw.map_expected]
  have hrow (b : ℕ → Fin Ns → ℝ) :
      let r := parametricFinalOptimizerLaw (Ng := Ng) cfg P b hunique
      expected r.outcomes r.mass (preparationFailure P ∘ PreparedTape.mk b) ≤
        sourceFailureIndicator P b + ω / 2 := by
    let r := parametricFinalOptimizerLaw (Ng := Ng) cfg P b hunique
    let test := optimizerFamilyFailure (Ng := Ng) P b
    have hopt := parametricFinalOptimizerLaw_failure cfg P b hunique harrived hB ω hω hω1
    have hmono (a : OptimizerFamily P b Ng) :
        preparationFailure P ⟨b, a⟩ ≤ sourceFailureIndicator P b + test a := by
      by_cases hb : goodStreamingBatches P b <;> by_cases ha : optimizerFamilyGood P b a <;>
        simp [preparationFailure, preparedGood, sourceFailureIndicator, test, optimizerFamilyFailure, hb, ha]
    calc
      _ ≤ expected r.outcomes r.mass (fun a => sourceFailureIndicator P b + test a) :=
        r.expected_le _ _ (fun a _ => hmono a)
      _ = sourceFailureIndicator P b + expected r.outcomes r.mass test := by
        rw [CandidateLaw.expected_add, CandidateLaw.expected_const]
      _ ≤ _ := add_le_add le_rfl hopt
  apply (source.expected_le _ _ (fun b _ => hrow b)).trans
  rw [CandidateLaw.expected_add, CandidateLaw.expected_const]
  linarith only [hsource]


end

end SubmodularMatching.UpperBoundAssembly
