import SubmodularMatching.ProjectedShearerDecodedInput

/-! Both bounded, indexed slot samplers for the same returned packing state. -/

namespace SubmodularMatching.AppendixM
open Capacity NonmonotoneLayers NonmonotoneOptimizer UpperBoundAssembly Shearer ShearerCappedSampler
open GibbsSampler GibbsMatching TwoLayerDiffuse
open scoped BigOperators
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

def layerShare (R : ℕ) : ℝ := 1/(4*(R:ℝ)^2)
def layerCells (N R : ℕ) : ℕ := (N+1)*4*R^2

theorem layerShare_range (R : ℕ) (hr : 0<R) : 0<layerShare R ∧ layerShare R≤1 := by
  have h : (1:ℝ)≤R := by exact_mod_cast hr
  unfold layerShare
  constructor
  · positivity
  · apply (div_le_one (by positivity)).mpr
    nlinarith [sq_nonneg ((R:ℝ)-1)]

private theorem gridShare (N R : ℕ) (hr : 0<R) : (N:ℝ)/layerCells N R ≤ layerShare R := by
  unfold layerCells layerShare
  push_cast
  have hR : (0:ℝ)<R := by exact_mod_cast hr
  apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
  nlinarith only [sq_nonneg (R:ℝ)]

/-- The physical law carries both the true interior distribution and the
variation certificate for the finite word output. -/
structure DeliveredLayer {C U : Type*} [DecidableEq C] [DecidableEq U] (base : C→Finset U) (active : Finset C)
    (x : C→ℝ) (δ : ℝ) (hδ : 0<δ ∧ δ≤1) (K : ℕ) (variationBudget : ℝ) where
  input : Input base active
  interior : InteriorLaw base active x
  distance : variation Finset.univ (Shearer.probability base active x) (outcomeLaw input δ hδ K).mass ≤ variationBudget

def decodedBestLayer (S : SimpleEdgeStream E V) (b : V→ℕ) (hb : ∀ v, 0<b v) (rank : Slots b ↪ ℕ)
    (k q T : ℕ) (hT : 0<T) (w : E→ℚ) (u : E→ℕ) (hu : ∀ e, w e=(u e:ℚ)/T)
    (R : ℕ) (hr : 0<R) (K : ℕ) (θn θd : ℕ)
    (θ : ℝ) (hθ : θ=(θn:ℝ)/θd) (hθ1 : θ≤1) (hθd : θ*degree≤layerOne)
    (hsize : (Fintype.card E:ℝ)+Real.log (1/layerShare R) ≤ K*Real.log 2) :
    let Y := fun e => (decodedCoordinate S b k q w e:ℝ)
    (∀ v, Capacity.slotLoad S.ends b Y v ≤ degree) → (∀ e, 0 ≤ Y e ∧ Y e ≤ degree) →
    DeliveredLayer pairVertices (layerSupport S b rank) (fun p => slotWeight b (labelTable S.ends Y) θ p.1 p.2)
      (layerShare R) (layerShare_range R hr) K (1/(R:ℝ)^2) := by
  intro Y hdeg bounds
  let nums := decodedNum S b k q T u
  let d := decodedDen T k
  let P := layerSupport S b rank
  let D := layerCells P.card R
  have Dpos : 0<D := by dsimp [D,layerCells]; positivity
  have θpos : 0≤θ := by rw [hθ]; positivity
  have wo : (fun e => (u e:ℚ)/T) = w := (funext hu).symm
  have eq : (fun e => (nums e:ℝ)/d) = Y := by
    funext e
    simpa only [nums,d,Y,wo] using decoded_number S b k q T u hT e
  have small (v) : ((θn:ℝ)/θd)*Capacity.slotLoad S.ends b (fun e=>(nums e:ℝ)/d) v ≤ layerOne := by
    rw [eq,←hθ]
    exact (mul_le_mul_of_nonneg_left (hdeg v) θpos).trans hθd
  let I := physicalLayerInput S b hb rank nums d θn θd D Dpos small
  have θsum : θ*(∑ e, Y e) ≤ Fintype.card E := by
    have hs : ∑ e, Y e ≤ ∑ _ : E, (1:ℝ) := Finset.sum_le_sum fun e _ => (bounds e).2.trans (by norm_num [degree])
    simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one] at hs
    exact (mul_le_of_le_one_left (Finset.sum_nonneg fun e _ => (bounds e).1) hθ1).trans hs
  have hk : ((θn:ℝ)/θd)*(∑ e, (nums e:ℝ)/d)+Real.log (1/layerShare R) ≤ K*Real.log 2 := by
    simpa only [←hθ,eq] using (add_le_add θsum (le_refl (Real.log (1/layerShare R)))).trans hsize
  refine ⟨I,?_,?_⟩
  · apply interiorLaw_of_degree (51/100) (by norm_num) (by norm_num)
    · intro e _
      exact div_nonneg (mul_nonneg θpos (labelTable_nonneg _ _ (fun i => (bounds i).1) _ _)) (by positivity)
    · intro e he
      exact orderedPairs_card_two rank e (Finset.mem_filter.mpr ⟨Finset.mem_univ _,(Finset.mem_filter.mp he).2⟩)
    · intro i
      have dg := retained_slot_degree b hb rank (Finset.univ.image S.ends) (labelTable S.ends Y)
        (labelTable_symm S.ends Y) (labelTable_diag S.ends S.loopless Y) (labelTable_support S.ends Y) θ i
      rw [labelTable_load S.ends S.loopless] at dg
      exact dg.le.trans ((mul_le_mul_of_nonneg_left (hdeg i.1) θpos).trans (hθd.trans (by norm_num [layerOne])))
  · have tv := physicalLayer_original_budget S b hb rank nums d θn θd D Dpos small (layerShare R) (layerShare R)
      (layerShare_range R hr) (layerShare_range R hr).1 K hk
    rw [eq,←hθ] at tv
    apply tv.trans
    have g := gridShare P.card R hr
    change (P.card:ℝ)/D+layerShare R+layerShare R ≤ _
    change (P.card:ℝ)/D ≤ layerShare R at g
    have u : 4*(layerShare R) = 1/(R:ℝ)^2 := by dsimp [layerShare]; ring
    linarith only [g,u,(layerShare_range R hr).1]

/-- Instantiate the two independent laws for the actual common-denominator
packing coordinates. Only the single physical action supplies their degree
and mass bounds. Both use the same global accuracy, grid size, and size cap. -/
def decoded_best_pair (S : SimpleEdgeStream E V) (b : V→ℕ) (hb : ∀ v, 0<b v) (rank : Slots b ↪ ℕ)
    (k q T : ℕ) (hT : 0<T) (w : E→ℚ) (u : E→ℕ) (hu : ∀ e, w e=(u e:ℚ)/T)
    (R : ℕ) (hr : 0<R) (K : ℕ) (hsize : (Fintype.card E:ℝ)+Real.log (1/layerShare R) ≤ K*Real.log 2)
    (pair : E→ BSlot b × BSlot b) (x : E→ℝ) (p Av Bv Ae Be : ℝ) :
    let Y := fun e => (decodedCoordinate S b k q w e:ℝ)
    let law θ := DeliveredLayer pairVertices (layerSupport S b rank) (fun e => slotWeight b (labelTable S.ends Y) θ e.1 e.2)
      (layerShare R) (layerShare_range R hr) K (1/(R:ℝ)^2)
    PhysicalAction S.ends b pair p degree Av Bv Ae Be x Y → law firstProportion × law secondProportion := by
  intro Y law act
  have rate := physical_rate_integers
  have one := decodedBestLayer S b hb rank k q T hT w u hu R hr K _ _ firstProportion rate.1
    (by norm_num [firstProportion,degree,layerOne]) (by norm_num [firstProportion,degree,layerOne]) hsize act.degree act.y_bounded
  have two := decodedBestLayer S b hb rank k q T hT w u hu R hr K _ _ secondProportion rate.2
    (by norm_num [secondProportion,firstProportion,degree,layerOne]) (by norm_num [secondProportion,firstProportion,degree,layerOne]) hsize act.degree act.y_bounded
  exact ⟨one,two⟩

end
end SubmodularMatching.AppendixM
