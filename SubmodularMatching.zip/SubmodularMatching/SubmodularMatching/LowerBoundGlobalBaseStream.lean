import SubmodularMatching.LowerBoundGlobalBaseLaw
import SubmodularMatching.LowerBoundGlobalStream

/-! # The blueprint base order with its expansion phases and private leaves -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

variable {N P t H : ℕ}

abbrev PaddedPair (N : ℕ) := PaddedVertex N × PaddedVertex N

def expansionBlock (sample : PhaseSample N) : List (PaddedPair N) :=
  sample.toList.map embedBase

/-- An explicit base-edge order for a whole stage, after the hidden tuple
and all phase samples have been drawn. The private-leaf block comes last. -/
def blueprintBaseOrder (b : BlueprintExpansion N P t H) (J : Fin P → Fin t)
    (samples : Fin P → PhaseSample N) : List (PaddedPair N) :=
  (List.finRange P).flatMap (fun i => expansionBlock (samples i)) ++
    (privateLeaves (b.canonical J)).toList

theorem phaseRetainedMass_supported (b : BlueprintExpansion N P t H) (q : ℝ)
    (J : Fin P → Fin t) (i : Fin P) (S : PhaseSample N)
    (h : 0 < phaseRetainedMass b q J i S) :
    S ⊆ b.phases J i ∧ S.card = retainedSize q (b.phaseSize i) := by
  unfold phaseRetainedMass uniformSubsetMass at h
  split_ifs at h with hmem
  · obtain ⟨hsub, hcard⟩ := Finset.mem_powersetCard.mp hmem
    refine ⟨hsub, ?_⟩
    simpa only [b.phase_card J i] using hcard
  · exact (lt_irrefl _ h).elim

theorem blueprintBaseOrder_length (b : BlueprintExpansion N P t H) (J : Fin P → Fin t)
    (samples : Fin P → PhaseSample N) (q : ℝ)
    (h : ∀ i, 0 < phaseRetainedMass b q J i (samples i)) :
    (blueprintBaseOrder b J samples).length =
      ((List.finRange P).map fun i => retainedSize q (b.phaseSize i)).sum + 2 * (N - H) := by
  have hl (i : Fin P) : (expansionBlock (samples i)).length = retainedSize q (b.phaseSize i) := by
    simpa [expansionBlock] using (phaseRetainedMass_supported b q J i _ (h i)).2
  simp only [blueprintBaseOrder, List.length_append, List.length_flatMap, hl,
    Finset.length_toList, privateLeaves_card _ (b.canonical_matching J), b.canonical_card J]

/-- The phase cut in the sequential base list leaves all private leaves
in the future and exposes only the earlier retained expansion blocks. -/
theorem blueprintBaseOrder_cut (b : BlueprintExpansion N P t H) (J : Fin P → Fin t)
    (samples : Fin P → PhaseSample N) (i : Fin P) :
    ∃ before after : List (Fin P),
      (∀ j ∈ before, j < i) ∧ (∀ j ∈ after, i < j) ∧
      blueprintBaseOrder b J samples =
        (before.flatMap fun j => expansionBlock (samples j)) ++
        expansionBlock (samples i) ++
        (after.flatMap fun j => expansionBlock (samples j)) ++
        (privateLeaves (b.canonical J)).toList := by
  obtain ⟨before, after, horder, hb, ha⟩ := finRange_cut i
  exact ⟨before, after, hb, ha, by simp [blueprintBaseOrder, horder, List.append_assoc]⟩

/-- An occurrence in a different phase or the private-leaf suffix cannot
imitate an edge from the currently sampled phase. -/
theorem blueprint_phase_disjoint_others (b : BlueprintExpansion N P t H)
    (i : Fin P) (J : Fin P → Fin t) (J' : prefixTuples i J)
    (j : Fin P) (hne : j ≠ i) (S : PhaseSample N)
    (hsub : S ⊆ b.phases J' j) :
    Disjoint ((b.phases J i).map embedBase) (S.map embedBase) := by
  rw [← b.prefix_invariance i J J' J'.property]
  rw [Finset.disjoint_left]
  intro e he hf
  obtain ⟨x, hx, hxe⟩ := Finset.mem_map.mp he
  obtain ⟨y, hy, hye⟩ := Finset.mem_map.mp hf
  have hxy := embedBase.injective (hxe.trans hye.symm)
  exact (Finset.disjoint_left.mp (b.phases_disjoint J' hne.symm)) hx (hxy.symm ▸ hsub hy)

theorem blueprint_phase_disjoint_leaves (b : BlueprintExpansion N P t H)
    (i : Fin P) (J : Fin P → Fin t) (J' : prefixTuples i J) :
    Disjoint ((b.phases J i).map embedBase) (privateLeaves (b.canonical J')) :=
  embedBase_disjoint_privateLeaves _ _

end

end SubmodularMatching.LowerBoundGlobal
