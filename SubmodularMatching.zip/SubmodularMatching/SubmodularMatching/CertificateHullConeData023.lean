import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull023_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 979, 984, 1, 0x1ec3d3⟩ (by decide +kernel)

private def hull023_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 975, 984, 1, 0x1ec3cf⟩ (by decide +kernel)

private def hull023_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 984, 988, 1, 0x1ee3d8⟩ (by decide +kernel)

private def hull023_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 988, 993, 1, 0x1f0bdc⟩ (by decide +kernel)

private def hull023_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 984, 986, 1, 0x1ed3d8⟩ (by decide +kernel)

private def hull023_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 986, 988, 1, 0x1ee3da⟩ (by decide +kernel)

private def hull023_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 984, 985, 1, 0x1ecbd8⟩ (by decide +kernel)

private def hull023_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 985, 986, 1, 0x1ed3d9⟩ (by decide +kernel)

private def hull023_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 986, 987, 1, 0x1edbda⟩ (by decide +kernel)

private def hull023_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 987, 988, 1, 0x1ee3db⟩ (by decide +kernel)

private def hull023_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 988, 989, 1, 0x1eebdc⟩ (by decide +kernel)

private def hull023_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 989, 990, 1, 0x1ef3dd⟩ (by decide +kernel)

private def hull023_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 990, 993, 1, 0x1f0bde⟩ (by decide +kernel)

private def hull023_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 988, 990, 1, 0x1ef3dc⟩ (by decide +kernel)

private def hull023_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 283, 156, 0x11b1522a0530a51462885009f13a2704d89913025c4b09512824c4909112023c4708d11822c4508911021c4308510820c410811001fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull023_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 990, 991, 1, 0x1efbde⟩ (by decide +kernel)

private def hull023_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 991, 993, 1, 0x1f0bdf⟩ (by decide +kernel)

private def hull023_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 991, 992, 1, 0x1f03df⟩ (by decide +kernel)

private def hull023_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 992, 993, 1, 0x1f0be0⟩ (by decide +kernel)

private def hull023_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 32, 33, 1, 0x10820⟩ (by decide +kernel)

private def hull023_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 33, 35, 2, 0x8c11021⟩ (by decide +kernel)

private def hull023_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 984, 993, 1, 0x1f0bd8⟩ (by decide +kernel)

private def hull023_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 975, 993, 1, 0x1f0bcf⟩ (by decide +kernel)

private def hull023_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 957, 993, 1, 0x1f0bbd⟩ (by decide +kernel)

private def hull023_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 922, 993, 1, 0x1f0b9a⟩ (by decide +kernel)

private def hull023_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 993, 1064, 2, 0x10a213be1⟩ (by decide +kernel)

private def hull023_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 993, 1028, 1, 0x2023e1⟩ (by decide +kernel)

private def hull023_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1028, 1064, 3, 0x85109e12404⟩ (by decide +kernel)

private def hull023_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 993, 1010, 1, 0x1f93e1⟩ (by decide +kernel)

private def hull023_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1010, 1028, 1, 0x2023f2⟩ (by decide +kernel)

private def hull023_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 993, 1001, 1, 0x1f4be1⟩ (by decide +kernel)

private def hull023_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1001, 1010, 1, 0x1f93e9⟩ (by decide +kernel)

private def hull023_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 993, 997, 1, 0x1f2be1⟩ (by decide +kernel)

private def hull023_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 997, 1001, 2, 0xfa5f43e5⟩ (by decide +kernel)

private def hull023_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 993, 995, 1, 0x1f1be1⟩ (by decide +kernel)

private def hull023_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 995, 997, 1, 0x1f2be3⟩ (by decide +kernel)

private def hull023_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 993, 994, 1, 0x1f13e1⟩ (by decide +kernel)

private def hull023_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 994, 995, 1, 0x1f1be2⟩ (by decide +kernel)

private def hull023_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 995, 996, 1, 0x1f23e3⟩ (by decide +kernel)

private def hull023_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 996, 997, 1, 0x1f2be4⟩ (by decide +kernel)

private def hull023_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 997, 998, 1, 0x1f33e5⟩ (by decide +kernel)

private def hull023_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 998, 999, 1, 0x1f3be6⟩ (by decide +kernel)

private def hull023_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 999, 1001, 2, 0xfa5f43e7⟩ (by decide +kernel)

private def hull023_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 997, 999, 1, 0x1f3be5⟩ (by decide +kernel)

private def hull023_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1001, 1005, 2, 0xfb5f63e9⟩ (by decide +kernel)

private def hull023_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1005, 1010, 1, 0x1f93ed⟩ (by decide +kernel)

private def hull023_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1001, 1002, 1, 0x1f53e9⟩ (by decide +kernel)

private def hull023_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1002, 1003, 1, 0x1f5bea⟩ (by decide +kernel)

private def hull023_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1003, 1005, 2, 0xfb5f63eb⟩ (by decide +kernel)

private def hull023_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1001, 1003, 1, 0x1f5be9⟩ (by decide +kernel)

private def hull023_050 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1005, 1007, 1, 0x1f7bed⟩ (by decide +kernel)

private def hull023_051 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1007, 1010, 1, 0x1f93ef⟩ (by decide +kernel)

private def hull023_052 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1005, 1006, 1, 0x1f73ed⟩ (by decide +kernel)

private def hull023_053 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1006, 1007, 1, 0x1f7bee⟩ (by decide +kernel)

private def hull023_054 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1007, 1008, 1, 0x1f83ef⟩ (by decide +kernel)

private def hull023_055 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1008, 1010, 2, 0xfc9f8bf0⟩ (by decide +kernel)

private def hull023_056 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1008, 1009, 1, 0x1f8bf0⟩ (by decide +kernel)

private def hull023_057 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1009, 1010, 1, 0x1f93f1⟩ (by decide +kernel)

private def hull023_058 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1010, 1019, 1, 0x1fdbf2⟩ (by decide +kernel)

private def hull023_059 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1019, 1028, 1, 0x2023fb⟩ (by decide +kernel)

private def hull023_060 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1010, 1014, 1, 0x1fb3f2⟩ (by decide +kernel)

private def hull023_061 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1014, 1019, 1, 0x1fdbf6⟩ (by decide +kernel)

private def hull023_062 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1010, 1012, 1, 0x1fa3f2⟩ (by decide +kernel)

private def hull023_063 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1012, 1014, 1, 0x1fb3f4⟩ (by decide +kernel)

private def hull023_064 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1010, 1011, 1, 0x1f9bf2⟩ (by decide +kernel)

private def hull023_065 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1011, 1012, 1, 0x1fa3f3⟩ (by decide +kernel)

private def hull023_066 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1064, 1135, 1, 0x237c28⟩ (by decide +kernel)

private def hull023_067 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1012, 1013, 1, 0x1fabf4⟩ (by decide +kernel)

private def hull023_068 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1013, 1014, 1, 0x1fb3f5⟩ (by decide +kernel)

private def hull023_069 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1014, 1015, 1, 0x1fbbf6⟩ (by decide +kernel)

private def hull023_070 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1015, 1016, 1, 0x1fc3f7⟩ (by decide +kernel)

private def hull023_071 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1016, 1019, 1, 0x1fdbf8⟩ (by decide +kernel)

private def hull023_072 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1014, 1016, 1, 0x1fc3f6⟩ (by decide +kernel)

private def hull023_073 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 1016, 1017, 1, 0x1fcbf8⟩ (by decide +kernel)

private def supportedCone2944 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨979, 984, 984, 979, 984⟩, ⟨2907681102284, 8539103351, 0, 0, 26737528144012, 968361589590⟩⟩
    hull023_000 1 (by decide +kernel)

private def supportedCone2945 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 984, 984, 975, 984⟩, ⟨5499154612488, 17884191629, 0, 0, 26737528144012, 968361589590⟩⟩
    hull023_001 1 (by decide +kernel)

private def supportedCone2946 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨984, 988, 984, 984, 988⟩, ⟨0, 0, 3174953131828, 7499919740, 26737528144012, 968361589590⟩⟩
    hull023_002 0 (by decide +kernel)

private def supportedCone2947 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨988, 993, 988, 988, 993⟩, ⟨0, 0, 3748072353219, 7263956634, 29912481275840, 975861509330⟩⟩
    hull023_003 0 (by decide +kernel)

private def supportedCone2948 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨984, 986, 984, 984, 986⟩, ⟨0, 0, 1584298144566, 3890280356, 26737528144012, 968361589590⟩⟩
    hull023_004 0 (by decide +kernel)

private def supportedCone2949 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨986, 988, 986, 986, 988⟩, ⟨0, 0, 1590654987262, 3609639384, 28321826288578, 972251869946⟩⟩
    hull023_005 0 (by decide +kernel)

private def supportedCone2950 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨984, 985, 985, 984, 985⟩, ⟨206068463268, 555454522, 0, 0, 26943596607280, 968917044112⟩⟩
    hull023_006 1 (by decide +kernel)

private def supportedCone2951 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨985, 986, 985, 985, 986⟩, ⟨0, 0, 1378229681298, 3334825834, 26943596607280, 968917044112⟩⟩
    hull023_007 0 (by decide +kernel)

private def supportedCone2952 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨985, 986, 986, 985, 986⟩, ⟨1378229681298, 3334825834, 0, 0, 28321826288578, 972251869946⟩⟩
    hull023_007 1 (by decide +kernel)

private def supportedCone2953 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨984, 985, 984, 984, 985⟩, ⟨0, 0, 206068463268, 555454522, 26737528144012, 968361589590⟩⟩
    hull023_006 0 (by decide +kernel)

private def supportedCone2954 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨986, 987, 986, 986, 987⟩, ⟨0, 0, 445294750692, 1108907376, 28321826288578, 972251869946⟩⟩
    hull023_008 0 (by decide +kernel)

private def supportedCone2955 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨987, 988, 987, 987, 988⟩, ⟨0, 0, 1145360236570, 2500732008, 28767121039270, 973360777322⟩⟩
    hull023_009 0 (by decide +kernel)

private def supportedCone2956 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨984, 986, 986, 984, 986⟩, ⟨1584298144566, 3890280356, 0, 0, 28321826288578, 972251869946⟩⟩
    hull023_004 1 (by decide +kernel)

private def supportedCone2957 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨986, 987, 987, 986, 987⟩, ⟨445294750692, 1108907376, 0, 0, 28767121039270, 973360777322⟩⟩
    hull023_008 1 (by decide +kernel)

private def supportedCone2958 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨987, 988, 988, 987, 988⟩, ⟨1145360236570, 2500732008, 0, 0, 29912481275840, 975861509330⟩⟩
    hull023_009 1 (by decide +kernel)

private def supportedCone2959 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨986, 988, 988, 986, 988⟩, ⟨1590654987262, 3609639384, 0, 0, 29912481275840, 975861509330⟩⟩
    hull023_005 1 (by decide +kernel)

private def supportedCone2960 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨988, 989, 988, 988, 989⟩, ⟨0, 0, 87518724160, 202854613, 29912481275840, 975861509330⟩⟩
    hull023_010 0 (by decide +kernel)

private def supportedCone2961 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨989, 990, 989, 989, 990⟩, ⟨0, 0, 1489619033800, 3066401248, 30000000000000, 976064363943⟩⟩
    hull023_011 0 (by decide +kernel)

private def supportedCone2962 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨990, 993, 990, 990, 993⟩, ⟨0, 0, 2170934595259, 3994700773, 31489619033800, 979130765191⟩⟩
    hull023_012 0 (by decide +kernel)

private def supportedCone2963 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨988, 990, 988, 988, 990⟩, ⟨0, 0, 1577137757960, 3269255861, 29912481275840, 975861509330⟩⟩
    hull023_013 0 (by decide +kernel)

private def supportedCone2964 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨984, 988, 988, 984, 988⟩, ⟨3174953131828, 7499919740, 0, 0, 29912481275840, 975861509330⟩⟩
    hull023_002 1 (by decide +kernel)

private def supportedCone2965 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨988, 989, 989, 988, 989⟩, ⟨87518724160, 202854613, 0, 0, 30000000000000, 976064363943⟩⟩
    hull023_010 1 (by decide +kernel)

private def supportedCone2966 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨989, 990, 990, 989, 990⟩, ⟨1489619033800, 3066401248, 0, 0, 31489619033800, 979130765191⟩⟩
    hull023_011 1 (by decide +kernel)

private def supportedCone2967 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨988, 990, 990, 988, 990⟩, ⟨1577137757960, 3269255861, 0, 0, 31489619033800, 979130765191⟩⟩
    hull023_013 1 (by decide +kernel)

private def supportedCone2968 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 32, 31, 33⟩, ⟨1405628119, 52888125, 1263823080, 49116029, 256405628119, 499191035⟩⟩
    hull023_014 23 (by decide +kernel)

private def supportedCone2969 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨990, 991, 990, 990, 991⟩, ⟨0, 0, 287992721519, 562266816, 31489619033800, 979130765191⟩⟩
    hull023_015 0 (by decide +kernel)

private def supportedCone2970 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨991, 993, 991, 991, 993⟩, ⟨0, 0, 1882941873740, 3432433957, 31777611755319, 979693032007⟩⟩
    hull023_016 0 (by decide +kernel)

private def supportedCone2971 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨990, 991, 991, 990, 991⟩, ⟨287992721519, 562266816, 0, 0, 31777611755319, 979693032007⟩⟩
    hull023_015 1 (by decide +kernel)

private def supportedCone2972 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨991, 992, 991, 991, 992⟩, ⟨0, 0, 1430892258441, 2632644152, 31777611755319, 979693032007⟩⟩
    hull023_017 0 (by decide +kernel)

private def supportedCone2973 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨992, 993, 992, 992, 993⟩, ⟨0, 0, 452049615299, 799789805, 33208504013760, 982325676159⟩⟩
    hull023_018 0 (by decide +kernel)

private def supportedCone2974 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨991, 992, 992, 991, 992⟩, ⟨1430892258441, 2632644152, 0, 0, 33208504013760, 982325676159⟩⟩
    hull023_017 1 (by decide +kernel)

private def supportedCone2975 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨991, 993, 993, 991, 993⟩, ⟨1882941873740, 3432433957, 0, 0, 33660553629059, 983125465964⟩⟩
    hull023_016 1 (by decide +kernel)

def appendixHullConeBlock0092 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2944,
    supportedCone2945,
    supportedCone2946,
    supportedCone2947,
    supportedCone2948,
    supportedCone2949,
    supportedCone2950,
    supportedCone2951,
    supportedCone2952,
    supportedCone2953,
    supportedCone2954,
    supportedCone2955,
    supportedCone2956,
    supportedCone2957,
    supportedCone2958,
    supportedCone2959,
    supportedCone2960,
    supportedCone2961,
    supportedCone2962,
    supportedCone2963,
    supportedCone2964,
    supportedCone2965,
    supportedCone2966,
    supportedCone2967,
    supportedCone2968,
    supportedCone2969,
    supportedCone2970,
    supportedCone2971,
    supportedCone2972,
    supportedCone2973,
    supportedCone2974,
    supportedCone2975,
  ], rfl⟩

private def supportedCone2976 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨32, 33, 33, 32, 33⟩, ⟨1263823080, 49116029, 0, 0, 257669451199, 548307064⟩⟩
    hull023_019 1 (by decide +kernel)

private def supportedCone2977 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨33, 35, 34, 33, 35⟩, ⟨827221629, 34669607, 1503327172, 68709630, 258496672828, 582976671⟩⟩
    hull023_020 1 (by decide +kernel)

private def supportedCone2978 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨33, 35, 33, 33, 34⟩, ⟨0, 0, 827221629, 34669607, 257669451199, 548307064⟩⟩
    hull023_020 0 (by decide +kernel)

private def supportedCone2979 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨992, 993, 993, 992, 993⟩, ⟨452049615299, 799789805, 0, 0, 33660553629059, 983125465964⟩⟩
    hull023_018 1 (by decide +kernel)

private def supportedCone2980 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨990, 993, 993, 990, 993⟩, ⟨2170934595259, 3994700773, 0, 0, 33660553629059, 983125465964⟩⟩
    hull023_012 1 (by decide +kernel)

private def supportedCone2981 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨988, 993, 993, 988, 993⟩, ⟨3748072353219, 7263956634, 0, 0, 33660553629059, 983125465964⟩⟩
    hull023_003 1 (by decide +kernel)

private def supportedCone2982 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨984, 993, 993, 984, 993⟩, ⟨6923025485047, 14763876374, 0, 0, 33660553629059, 983125465964⟩⟩
    hull023_021 1 (by decide +kernel)

private def supportedCone2983 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨975, 993, 993, 975, 993⟩, ⟨12422180097535, 32648068003, 0, 0, 33660553629059, 983125465964⟩⟩
    hull023_022 1 (by decide +kernel)

private def supportedCone2984 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨957, 993, 993, 957, 993⟩, ⟨20698391078079, 82524572042, 0, 0, 33660553629059, 983125465964⟩⟩
    hull023_023 1 (by decide +kernel)

private def supportedCone2985 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨922, 993, 993, 922, 993⟩, ⟨28499394021229, 225474891532, 0, 0, 33660553629059, 983125465964⟩⟩
    hull023_024 1 (by decide +kernel)

private def supportedCone2986 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 1064, 993, 993, 1063⟩, ⟨0, 0, 469339446370941, 78724971962, 33660553629059, 983125465964⟩⟩
    hull023_025 0 (by decide +kernel)

private def supportedCone2987 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 1028, 993, 993, 1028⟩, ⟨0, 0, 66829078118289, 41514198640, 33660553629059, 983125465964⟩⟩
    hull023_026 0 (by decide +kernel)

private def supportedCone2988 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1028, 1064, 1028, 1028, 1060⟩, ⟨0, 0, 323271631639478, 29448388002, 100489631747348, 1024639664604⟩⟩
    hull023_027 0 (by decide +kernel)

private def supportedCone2989 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 1010, 993, 993, 1010⟩, ⟨0, 0, 20513762978661, 22966219156, 33660553629059, 983125465964⟩⟩
    hull023_028 0 (by decide +kernel)

private def supportedCone2990 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1028, 1010, 1010, 1028⟩, ⟨0, 0, 46315315139628, 18547979484, 54174316607720, 1006091685120⟩⟩
    hull023_029 0 (by decide +kernel)

private def supportedCone2991 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 1001, 993, 993, 1001⟩, ⟨0, 0, 7642334785591, 11103476318, 33660553629059, 983125465964⟩⟩
    hull023_030 0 (by decide +kernel)

private def supportedCone2992 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1001, 1010, 1001, 1001, 1010⟩, ⟨0, 0, 12871428193070, 11862742838, 41302888414650, 994228942282⟩⟩
    hull023_031 0 (by decide +kernel)

private def supportedCone2993 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 997, 993, 993, 997⟩, ⟨0, 0, 4071410959671, 6424390088, 33660553629059, 983125465964⟩⟩
    hull023_032 0 (by decide +kernel)

private def supportedCone2994 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨997, 1001, 997, 997, 1000⟩, ⟨0, 0, 3198158991500, 4176501894, 37731964588730, 989549856052⟩⟩
    hull023_033 0 (by decide +kernel)

private def supportedCone2995 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 995, 993, 993, 995⟩, ⟨0, 0, 1994513194052, 3261989918, 33660553629059, 983125465964⟩⟩
    hull023_034 0 (by decide +kernel)

private def supportedCone2996 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨995, 997, 995, 995, 997⟩, ⟨0, 0, 2076897765619, 3162400170, 35655066823111, 986387455882⟩⟩
    hull023_035 0 (by decide +kernel)

private def supportedCone2997 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 994, 993, 993, 994⟩, ⟨0, 0, 809218495161, 1426270648, 33660553629059, 983125465964⟩⟩
    hull023_036 0 (by decide +kernel)

private def supportedCone2998 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨994, 995, 994, 994, 995⟩, ⟨0, 0, 1185294698891, 1835719270, 34469772124220, 984551736612⟩⟩
    hull023_037 0 (by decide +kernel)

private def supportedCone2999 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 994, 994, 993, 994⟩, ⟨809218495161, 1426270648, 0, 0, 34469772124220, 984551736612⟩⟩
    hull023_036 1 (by decide +kernel)

private def supportedCone3000 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨994, 995, 995, 994, 995⟩, ⟨1185294698891, 1835719270, 0, 0, 35655066823111, 986387455882⟩⟩
    hull023_037 1 (by decide +kernel)

private def supportedCone3001 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 995, 995, 993, 995⟩, ⟨1994513194052, 3261989918, 0, 0, 35655066823111, 986387455882⟩⟩
    hull023_034 1 (by decide +kernel)

private def supportedCone3002 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨995, 996, 995, 995, 996⟩, ⟨0, 0, 1212644974579, 1877556368, 35655066823111, 986387455882⟩⟩
    hull023_038 0 (by decide +kernel)

private def supportedCone3003 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨996, 997, 996, 996, 997⟩, ⟨0, 0, 864252791040, 1284843802, 36867711797690, 988265012250⟩⟩
    hull023_039 0 (by decide +kernel)

private def supportedCone3004 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨995, 996, 996, 995, 996⟩, ⟨1212644974579, 1877556368, 0, 0, 36867711797690, 988265012250⟩⟩
    hull023_038 1 (by decide +kernel)

private def supportedCone3005 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨996, 997, 997, 996, 997⟩, ⟨864252791040, 1284843802, 0, 0, 37731964588730, 989549856052⟩⟩
    hull023_039 1 (by decide +kernel)

private def supportedCone3006 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨995, 997, 997, 995, 997⟩, ⟨2076897765619, 3162400170, 0, 0, 37731964588730, 989549856052⟩⟩
    hull023_035 1 (by decide +kernel)

private def supportedCone3007 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 997, 997, 993, 997⟩, ⟨4071410959671, 6424390088, 0, 0, 37731964588730, 989549856052⟩⟩
    hull023_032 1 (by decide +kernel)

def appendixHullConeBlock0093 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2976,
    supportedCone2977,
    supportedCone2978,
    supportedCone2979,
    supportedCone2980,
    supportedCone2981,
    supportedCone2982,
    supportedCone2983,
    supportedCone2984,
    supportedCone2985,
    supportedCone2986,
    supportedCone2987,
    supportedCone2988,
    supportedCone2989,
    supportedCone2990,
    supportedCone2991,
    supportedCone2992,
    supportedCone2993,
    supportedCone2994,
    supportedCone2995,
    supportedCone2996,
    supportedCone2997,
    supportedCone2998,
    supportedCone2999,
    supportedCone3000,
    supportedCone3001,
    supportedCone3002,
    supportedCone3003,
    supportedCone3004,
    supportedCone3005,
    supportedCone3006,
    supportedCone3007,
  ], rfl⟩

private def supportedCone3008 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨997, 998, 998, 997, 998⟩, ⟨35797765095, 54375592, 0, 0, 37767762353825, 989604231644⟩⟩
    hull023_040 1 (by decide +kernel)

private def supportedCone3009 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨998, 999, 998, 998, 999⟩, ⟨0, 0, 2237880611075, 2917756657, 37767762353825, 989604231644⟩⟩
    hull023_041 0 (by decide +kernel)

private def supportedCone3010 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨999, 1001, 999, 999, 1000⟩, ⟨0, 0, 924480615330, 1204369645, 40005642964900, 992521988301⟩⟩
    hull023_042 0 (by decide +kernel)

private def supportedCone3011 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨998, 999, 999, 998, 999⟩, ⟨2237880611075, 2917756657, 0, 0, 40005642964900, 992521988301⟩⟩
    hull023_041 1 (by decide +kernel)

private def supportedCone3012 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨997, 1001, 1000, 997, 1001⟩, ⟨3198158991500, 4176501894, 372764834420, 502584336, 40930123580230, 993726357946⟩⟩
    hull023_033 1 (by decide +kernel)

private def supportedCone3013 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨997, 999, 999, 997, 999⟩, ⟨2273678376170, 2972132249, 0, 0, 40005642964900, 992521988301⟩⟩
    hull023_043 1 (by decide +kernel)

private def supportedCone3014 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨999, 1001, 1000, 999, 1001⟩, ⟨924480615330, 1204369645, 372764834420, 502584336, 40930123580230, 993726357946⟩⟩
    hull023_042 1 (by decide +kernel)

private def supportedCone3015 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨997, 1001, 1001, 1000, 1001⟩, ⟨372764834420, 502584336, 0, 0, 41302888414650, 994228942282⟩⟩
    hull023_033 2 (by decide +kernel)

private def supportedCone3016 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 1001, 1001, 993, 1001⟩, ⟨7642334785591, 11103476318, 0, 0, 41302888414650, 994228942282⟩⟩
    hull023_030 1 (by decide +kernel)

private def supportedCone3017 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1001, 1005, 1001, 1001, 1004⟩, ⟨0, 0, 3908873283620, 4232178978, 41302888414650, 994228942282⟩⟩
    hull023_044 0 (by decide +kernel)

private def supportedCone3018 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1005, 1010, 1005, 1005, 1010⟩, ⟨0, 0, 8734148650290, 7302615108, 45440167957430, 998789070012⟩⟩
    hull023_045 0 (by decide +kernel)

private def supportedCone3019 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1001, 1002, 1001, 1001, 1002⟩, ⟨0, 0, 1073237924033, 1174187097, 41302888414650, 994228942282⟩⟩
    hull023_046 0 (by decide +kernel)

private def supportedCone3020 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1002, 1003, 1002, 1002, 1003⟩, ⟨0, 0, 2510943344150, 2708670365, 42376126338683, 995403129379⟩⟩
    hull023_047 0 (by decide +kernel)

private def supportedCone3021 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1003, 1005, 1003, 1003, 1004⟩, ⟨0, 0, 324692015437, 349321516, 44887069682833, 998111799744⟩⟩
    hull023_048 0 (by decide +kernel)

private def supportedCone3022 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1001, 1005, 1004, 1001, 1005⟩, ⟨3908873283620, 4232178978, 228406259160, 327948752, 45211761698270, 998461121260⟩⟩
    hull023_044 1 (by decide +kernel)

private def supportedCone3023 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1001, 1003, 1001, 1001, 1003⟩, ⟨0, 0, 3584181268183, 3882857462, 41302888414650, 994228942282⟩⟩
    hull023_049 0 (by decide +kernel)

private def supportedCone3024 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1001, 1002, 1002, 1001, 1002⟩, ⟨1073237924033, 1174187097, 0, 0, 42376126338683, 995403129379⟩⟩
    hull023_046 1 (by decide +kernel)

private def supportedCone3025 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1002, 1003, 1003, 1002, 1003⟩, ⟨2510943344150, 2708670365, 0, 0, 44887069682833, 998111799744⟩⟩
    hull023_047 1 (by decide +kernel)

private def supportedCone3026 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1001, 1003, 1003, 1001, 1003⟩, ⟨3584181268183, 3882857462, 0, 0, 44887069682833, 998111799744⟩⟩
    hull023_049 1 (by decide +kernel)

private def supportedCone3027 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1003, 1005, 1004, 1003, 1005⟩, ⟨324692015437, 349321516, 228406259160, 327948752, 45211761698270, 998461121260⟩⟩
    hull023_048 1 (by decide +kernel)

private def supportedCone3028 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1001, 1005, 1005, 1004, 1005⟩, ⟨228406259160, 327948752, 0, 0, 45440167957430, 998789070012⟩⟩
    hull023_044 2 (by decide +kernel)

private def supportedCone3029 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1005, 1007, 1005, 1005, 1007⟩, ⟨0, 0, 4923952586247, 4401202554, 45440167957430, 998789070012⟩⟩
    hull023_050 0 (by decide +kernel)

private def supportedCone3030 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1007, 1010, 1007, 1007, 1010⟩, ⟨0, 0, 3810196064043, 2901412554, 50364120543677, 1003190272566⟩⟩
    hull023_051 0 (by decide +kernel)

private def supportedCone3031 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1005, 1006, 1005, 1005, 1006⟩, ⟨0, 0, 2106627816403, 1893005471, 45440167957430, 998789070012⟩⟩
    hull023_052 0 (by decide +kernel)

private def supportedCone3032 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1006, 1007, 1006, 1006, 1007⟩, ⟨0, 0, 2817324769844, 2508197083, 47546795773833, 1000682075483⟩⟩
    hull023_053 0 (by decide +kernel)

private def supportedCone3033 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1005, 1006, 1006, 1005, 1006⟩, ⟨2106627816403, 1893005471, 0, 0, 47546795773833, 1000682075483⟩⟩
    hull023_052 1 (by decide +kernel)

private def supportedCone3034 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1006, 1007, 1007, 1006, 1007⟩, ⟨2817324769844, 2508197083, 0, 0, 50364120543677, 1003190272566⟩⟩
    hull023_053 1 (by decide +kernel)

private def supportedCone3035 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1005, 1007, 1007, 1005, 1007⟩, ⟨4923952586247, 4401202554, 0, 0, 50364120543677, 1003190272566⟩⟩
    hull023_050 1 (by decide +kernel)

private def supportedCone3036 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1007, 1008, 1007, 1007, 1008⟩, ⟨0, 0, 83048518773, 136194851, 50364120543677, 1003190272566⟩⟩
    hull023_054 0 (by decide +kernel)

private def supportedCone3037 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1008, 1010, 1008, 1008, 1009⟩, ⟨0, 0, 2901213238718, 2149445395, 50447169062450, 1003326467417⟩⟩
    hull023_055 0 (by decide +kernel)

private def supportedCone3038 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1008, 1010, 1009, 1008, 1010⟩, ⟨2901213238718, 2149445395, 825934306552, 615772308, 53348382301168, 1005475912812⟩⟩
    hull023_055 1 (by decide +kernel)

private def supportedCone3039 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1008, 1010, 1010, 1009, 1010⟩, ⟨825934306552, 615772308, 0, 0, 54174316607720, 1006091685120⟩⟩
    hull023_055 2 (by decide +kernel)

def appendixHullConeBlock0094 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone3008,
    supportedCone3009,
    supportedCone3010,
    supportedCone3011,
    supportedCone3012,
    supportedCone3013,
    supportedCone3014,
    supportedCone3015,
    supportedCone3016,
    supportedCone3017,
    supportedCone3018,
    supportedCone3019,
    supportedCone3020,
    supportedCone3021,
    supportedCone3022,
    supportedCone3023,
    supportedCone3024,
    supportedCone3025,
    supportedCone3026,
    supportedCone3027,
    supportedCone3028,
    supportedCone3029,
    supportedCone3030,
    supportedCone3031,
    supportedCone3032,
    supportedCone3033,
    supportedCone3034,
    supportedCone3035,
    supportedCone3036,
    supportedCone3037,
    supportedCone3038,
    supportedCone3039,
  ], rfl⟩

private def supportedCone3040 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1008, 1009, 1009, 1008, 1009⟩, ⟨2901213238718, 2149445395, 0, 0, 53348382301168, 1005475912812⟩⟩
    hull023_056 1 (by decide +kernel)

private def supportedCone3041 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1009, 1010, 1009, 1009, 1010⟩, ⟨0, 0, 825934306552, 615772308, 53348382301168, 1005475912812⟩⟩
    hull023_057 0 (by decide +kernel)

private def supportedCone3042 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1007, 1008, 1008, 1007, 1008⟩, ⟨83048518773, 136194851, 0, 0, 50447169062450, 1003326467417⟩⟩
    hull023_054 1 (by decide +kernel)

private def supportedCone3043 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1007, 1010, 1010, 1007, 1010⟩, ⟨3810196064043, 2901412554, 0, 0, 54174316607720, 1006091685120⟩⟩
    hull023_051 1 (by decide +kernel)

private def supportedCone3044 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1005, 1010, 1010, 1005, 1010⟩, ⟨8734148650290, 7302615108, 0, 0, 54174316607720, 1006091685120⟩⟩
    hull023_045 1 (by decide +kernel)

private def supportedCone3045 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1001, 1010, 1010, 1001, 1010⟩, ⟨12871428193070, 11862742838, 0, 0, 54174316607720, 1006091685120⟩⟩
    hull023_031 1 (by decide +kernel)

private def supportedCone3046 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨993, 1010, 1010, 993, 1010⟩, ⟨20513762978661, 22966219156, 0, 0, 54174316607720, 1006091685120⟩⟩
    hull023_028 1 (by decide +kernel)

private def supportedCone3047 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1019, 1010, 1010, 1019⟩, ⟨0, 0, 16966894562130, 9510597105, 54174316607720, 1006091685120⟩⟩
    hull023_058 0 (by decide +kernel)

private def supportedCone3048 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1019, 1028, 1019, 1019, 1028⟩, ⟨0, 0, 29348420577498, 9037382379, 71141211169850, 1015602282225⟩⟩
    hull023_059 0 (by decide +kernel)

private def supportedCone3049 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1014, 1010, 1010, 1014⟩, ⟨0, 0, 5683552841346, 3740849469, 54174316607720, 1006091685120⟩⟩
    hull023_060 0 (by decide +kernel)

private def supportedCone3050 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1014, 1019, 1014, 1014, 1019⟩, ⟨0, 0, 11283341720784, 5769747636, 59857869449066, 1009832534589⟩⟩
    hull023_061 0 (by decide +kernel)

private def supportedCone3051 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1012, 1010, 1010, 1012⟩, ⟨0, 0, 2335156076974, 1672893484, 54174316607720, 1006091685120⟩⟩
    hull023_062 0 (by decide +kernel)

private def supportedCone3052 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1012, 1014, 1012, 1012, 1014⟩, ⟨0, 0, 3348396764372, 2067955985, 56509472684694, 1007764578604⟩⟩
    hull023_063 0 (by decide +kernel)

private def supportedCone3053 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1012, 1012, 1010, 1012⟩, ⟨2335156076974, 1672893484, 0, 0, 56509472684694, 1007764578604⟩⟩
    hull023_062 1 (by decide +kernel)

private def supportedCone3054 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1011, 1010, 1010, 1011⟩, ⟨0, 0, 1831569391650, 1318889570, 54174316607720, 1006091685120⟩⟩
    hull023_064 0 (by decide +kernel)

private def supportedCone3055 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1011, 1012, 1011, 1011, 1012⟩, ⟨0, 0, 503586685324, 354003914, 56005885999370, 1007410574690⟩⟩
    hull023_065 0 (by decide +kernel)

private def supportedCone3056 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1011, 1011, 1010, 1011⟩, ⟨1831569391650, 1318889570, 0, 0, 56005885999370, 1007410574690⟩⟩
    hull023_064 1 (by decide +kernel)

private def supportedCone3057 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1064, 1135, 1064, 1064, 1135⟩, ⟨0, 0, 1999999999496358794563232, 48937940396932, 503641205436768, 1062059603068⟩⟩
    hull023_066 0 (by decide +kernel)

private def supportedCone3058 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1012, 1014, 1014, 1012, 1014⟩, ⟨3348396764372, 2067955985, 0, 0, 59857869449066, 1009832534589⟩⟩
    hull023_063 1 (by decide +kernel)

private def supportedCone3059 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1012, 1013, 1012, 1012, 1013⟩, ⟨0, 0, 2791859174846, 1725585201, 56509472684694, 1007764578604⟩⟩
    hull023_067 0 (by decide +kernel)

private def supportedCone3060 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1013, 1014, 1013, 1013, 1014⟩, ⟨0, 0, 556537589526, 342370784, 59301331859540, 1009490163805⟩⟩
    hull023_068 0 (by decide +kernel)

private def supportedCone3061 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1012, 1013, 1013, 1012, 1013⟩, ⟨2791859174846, 1725585201, 0, 0, 59301331859540, 1009490163805⟩⟩
    hull023_067 1 (by decide +kernel)

private def supportedCone3062 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1013, 1014, 1014, 1013, 1014⟩, ⟨556537589526, 342370784, 0, 0, 59857869449066, 1009832534589⟩⟩
    hull023_068 1 (by decide +kernel)

private def supportedCone3063 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1010, 1014, 1014, 1010, 1014⟩, ⟨5683552841346, 3740849469, 0, 0, 59857869449066, 1009832534589⟩⟩
    hull023_060 1 (by decide +kernel)

private def supportedCone3064 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1014, 1015, 1014, 1014, 1015⟩, ⟨0, 0, 2319242267374, 1392254050, 59857869449066, 1009832534589⟩⟩
    hull023_069 0 (by decide +kernel)

private def supportedCone3065 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1015, 1016, 1015, 1015, 1016⟩, ⟨0, 0, 1227559478659, 673719235, 62177111716440, 1011224788639⟩⟩
    hull023_070 0 (by decide +kernel)

private def supportedCone3066 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1016, 1019, 1016, 1016, 1019⟩, ⟨0, 0, 7736539974751, 3703774351, 63404671195099, 1011898507874⟩⟩
    hull023_071 0 (by decide +kernel)

private def supportedCone3067 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1014, 1016, 1014, 1014, 1016⟩, ⟨0, 0, 3546801746033, 2065973285, 59857869449066, 1009832534589⟩⟩
    hull023_072 0 (by decide +kernel)

private def supportedCone3068 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1014, 1015, 1015, 1014, 1015⟩, ⟨2319242267374, 1392254050, 0, 0, 62177111716440, 1011224788639⟩⟩
    hull023_069 1 (by decide +kernel)

private def supportedCone3069 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1015, 1016, 1016, 1015, 1016⟩, ⟨1227559478659, 673719235, 0, 0, 63404671195099, 1011898507874⟩⟩
    hull023_070 1 (by decide +kernel)

private def supportedCone3070 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1014, 1016, 1016, 1014, 1016⟩, ⟨3546801746033, 2065973285, 0, 0, 63404671195099, 1011898507874⟩⟩
    hull023_072 1 (by decide +kernel)

private def supportedCone3071 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨1016, 1017, 1016, 1016, 1017⟩, ⟨0, 0, 3756962961951, 1856841090, 63404671195099, 1011898507874⟩⟩
    hull023_073 0 (by decide +kernel)

def appendixHullConeBlock0095 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone3040,
    supportedCone3041,
    supportedCone3042,
    supportedCone3043,
    supportedCone3044,
    supportedCone3045,
    supportedCone3046,
    supportedCone3047,
    supportedCone3048,
    supportedCone3049,
    supportedCone3050,
    supportedCone3051,
    supportedCone3052,
    supportedCone3053,
    supportedCone3054,
    supportedCone3055,
    supportedCone3056,
    supportedCone3057,
    supportedCone3058,
    supportedCone3059,
    supportedCone3060,
    supportedCone3061,
    supportedCone3062,
    supportedCone3063,
    supportedCone3064,
    supportedCone3065,
    supportedCone3066,
    supportedCone3067,
    supportedCone3068,
    supportedCone3069,
    supportedCone3070,
    supportedCone3071,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
