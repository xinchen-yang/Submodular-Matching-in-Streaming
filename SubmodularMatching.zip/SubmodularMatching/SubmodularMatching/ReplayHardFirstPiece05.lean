import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardFirst

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000
theorem chunk39 : ProjectedGoal ⟨0,215,0,283,283,567⟩ :=
  projectedGoal_chunk _ (.leaf 0xd7f0000574fbde600061022) (by decide +kernel)
theorem chunk41 : ProjectedGoal ⟨0,215,283,567,0,567⟩ :=
  projectedGoal_chunk _ (.y (.x (.x (.leaf 0x1aff0000e8d4a5100004820d) (.y (.leaf 0x1aff0000e8d4a5100039d39c) (.leaf 0x6bff0000000000000004e4e0))) (.leaf 0x6bf00001d1a94a2004e24e1)) (.leaf 0x6bff0000000000000000f00f)) (by decide +kernel)
theorem chunk43 : ProjectedGoal ⟨0,215,0,567,567,1135⟩ :=
  projectedGoal_chunk _ (.x (.x (.x (.y (.x (.x (.y (.y (.leaf 0xd70000000000000059a500) (.leaf 0x1af000000000000005b0500)) (.leaf 0x1af000000000000005b1500)) (.leaf 0x1af000000000000005b21c9)) (.leaf 0x1af000000000000005b217f)) (.leaf 0x1aff00000000000000730191)) (.leaf 0x1aff000000000000000240e8)) (.leaf 0x35ff0000000000000002404e)) (.leaf 0xd7ff0000000000000002400f)) (by decide +kernel)
theorem chunk45 : ProjectedGoal ⟨0,215,567,1135,0,1135⟩ :=
  projectedGoal_chunk _ (.x (.y (.x (.x (.y (.y (.y (.y (.y (.leaf 0xd70000000000000050059a) (.leaf 0x1af000000000000001c959a)) (.leaf 0x1af0000000000000017f59a)) (.leaf 0x1af000000000000000e859a)) (.leaf 0x1af0000000000000004e59a)) (.leaf 0x1af0000000000000000f59a)) (.leaf 0x1af000000000000000445b0)) (.leaf 0x1af000000000000000445b1)) (.leaf 0x1af000000000000000245b2)) (.leaf 0x1af00000000000000047730)) (by decide +kernel)
end SubmodularMatching.SourceCertificate.Replay.HardFirst
