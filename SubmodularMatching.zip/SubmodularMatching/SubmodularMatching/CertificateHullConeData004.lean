import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull004_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 35, 26, 0x8c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull004_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 567, 119, 0x46e1fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull004_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 229, 231, 1, 0x738e5⟩ (by decide +kernel)

private def hull004_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 70, 61, 0x2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull004_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 212, 229, 11, 0x1ca390718e21c237c6d8da1b23586a8d4⟩ (by decide +kernel)

private def hull004_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 141, 132, 0x8d11822c4508911021c4308510820c410811001fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull004_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 229, 230, 1, 0x730e5⟩ (by decide +kernel)

private def hull004_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 230, 231, 1, 0x738e6⟩ (by decide +kernel)

private def hull004_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 283, 354, 1, 0xb111b⟩ (by decide +kernel)

private def hull004_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 283, 156, 0x11b1522a0530a51462885009f13a2704d89913025c4b09512824c4909112023c4708d11822c4508911021c4308510820c410811001fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull004_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 283, 318, 1, 0x9f11b⟩ (by decide +kernel)

private def hull004_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 318, 354, 1, 0xb113e⟩ (by decide +kernel)

private def hull004_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 318, 336, 1, 0xa813e⟩ (by decide +kernel)

private def hull004_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 336, 354, 1, 0xb1150⟩ (by decide +kernel)

private def hull004_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 336, 345, 1, 0xac950⟩ (by decide +kernel)

private def hull004_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 345, 354, 1, 0xb1159⟩ (by decide +kernel)

private def hull004_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 345, 349, 1, 0xae959⟩ (by decide +kernel)

private def hull004_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 349, 354, 1, 0xb115d⟩ (by decide +kernel)

private def hull004_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 349, 351, 1, 0xaf95d⟩ (by decide +kernel)

private def hull004_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 351, 354, 1, 0xb115f⟩ (by decide +kernel)

private def hull004_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 351, 352, 1, 0xb015f⟩ (by decide +kernel)

private def hull004_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 352, 353, 1, 0xb0960⟩ (by decide +kernel)

private def hull004_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 353, 354, 1, 0xb1161⟩ (by decide +kernel)

private def hull004_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 352, 354, 1, 0xb1160⟩ (by decide +kernel)

private def hull004_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 349, 350, 1, 0xaf15d⟩ (by decide +kernel)

private def hull004_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 350, 351, 1, 0xaf95e⟩ (by decide +kernel)

private def hull004_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 70, 35, 0x8c114220430841042003f07c0f41e03b0740e41c03706c0d41a0330640c41802f05c0b41602b0540a41402704c09412023⟩ (by decide +kernel)

private def hull004_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 345, 347, 1, 0xad959⟩ (by decide +kernel)

private def hull004_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 347, 349, 2, 0x574ae15b⟩ (by decide +kernel)

private def hull004_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 345, 346, 1, 0xad159⟩ (by decide +kernel)

private def hull004_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 346, 347, 1, 0xad95a⟩ (by decide +kernel)

private def hull004_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 336, 340, 1, 0xaa150⟩ (by decide +kernel)

private def hull004_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 340, 345, 1, 0xac954⟩ (by decide +kernel)

private def hull004_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 340, 342, 1, 0xab154⟩ (by decide +kernel)

private def hull004_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 342, 345, 1, 0xac956⟩ (by decide +kernel)

private def hull004_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 342, 343, 1, 0xab956⟩ (by decide +kernel)

private def hull004_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 343, 345, 1, 0xac957⟩ (by decide +kernel)

private def hull004_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 343, 344, 1, 0xac157⟩ (by decide +kernel)

private def hull004_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 344, 345, 1, 0xac958⟩ (by decide +kernel)

private def hull004_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 340, 341, 1, 0xaa954⟩ (by decide +kernel)

private def hull004_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 341, 342, 1, 0xab155⟩ (by decide +kernel)

private def hull004_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 336, 338, 1, 0xa9150⟩ (by decide +kernel)

private def hull004_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 338, 340, 1, 0xaa152⟩ (by decide +kernel)

private def hull004_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 318, 327, 1, 0xa393e⟩ (by decide +kernel)

private def hull004_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 327, 336, 1, 0xa8147⟩ (by decide +kernel)

private def supportedCone0512 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 13, 12, 14⟩, ⟨1256305925, 2513501, 1662166960, 7812264, 232507035113, 2513525⟩⟩
    hull004_000 4 (by decide +kernel)

private def supportedCone0513 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 567, 13, 12, 14⟩, ⟨1256305925, 2513501, 1662166960, 7812264, 232507035113, 2513525⟩⟩
    hull004_001 4 (by decide +kernel)

private def supportedCone0514 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 231, 231, 229, 231⟩, ⟨26148712609, 22353128939, 0, 0, 1001148712609, 519427734853⟩⟩
    hull004_002 1 (by decide +kernel)

private def supportedCone0515 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 13, 12, 14⟩, ⟨1256305925, 2513501, 1662166960, 7812264, 232507035113, 2513525⟩⟩
    hull004_003 4 (by decide +kernel)

private def supportedCone0516 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨212, 229, 229, 228, 229⟩, ⟨5000000000, 4284795344, 0, 0, 975000000000, 497074605914⟩⟩
    hull004_004 11 (by decide +kernel)

private def supportedCone0517 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 13, 12, 14⟩, ⟨1256305925, 2513501, 1662166960, 7812264, 232507035113, 2513525⟩⟩
    hull004_005 4 (by decide +kernel)

private def supportedCone0518 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 0, 0, 3⟩, ⟨0, 0, 200000000000, 0, 0, 0⟩⟩
    hull004_005 0 (by decide +kernel)

private def supportedCone0519 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 12, 8, 13⟩, ⟨10010735298, 11, 1256305925, 2513501, 231250729188, 24⟩⟩
    hull004_003 3 (by decide +kernel)

private def supportedCone0520 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 230, 230, 229, 230⟩, ⟨25000000000, 21497421725, 0, 0, 1000000000000, 518572027639⟩⟩
    hull004_006 1 (by decide +kernel)

private def supportedCone0521 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨230, 231, 231, 230, 231⟩, ⟨1148712609, 855707214, 0, 0, 1001148712609, 519427734853⟩⟩
    hull004_007 1 (by decide +kernel)

private def supportedCone0522 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 12, 8, 13⟩, ⟨10010735298, 11, 1256305925, 2513501, 231250729188, 24⟩⟩
    hull004_005 3 (by decide +kernel)

private def supportedCone0523 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨230, 231, 230, 230, 231⟩, ⟨0, 0, 1148712609, 855707214, 1000000000000, 518572027639⟩⟩
    hull004_007 0 (by decide +kernel)

private def supportedCone0524 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨229, 230, 229, 229, 230⟩, ⟨0, 0, 25000000000, 21497421725, 975000000000, 497074605914⟩⟩
    hull004_006 0 (by decide +kernel)

private def supportedCone0525 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨283, 354, 283, 283, 354⟩, ⟨0, 0, 114065615359, 73376528022, 1075000000000, 582040038077⟩⟩
    hull004_008 0 (by decide +kernel)

private def supportedCone0526 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨283, 354, 354, 283, 354⟩, ⟨114065615359, 73376528022, 0, 0, 1189065615359, 655416566099⟩⟩
    hull004_008 1 (by decide +kernel)

private def supportedCone0527 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 120, 119, 121⟩, ⟨5000000000, 1740937257, 5000000000, 1915304082, 385000000000, 21618443649⟩⟩
    hull004_009 111 (by decide +kernel)

private def supportedCone0528 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 117, 116, 118⟩, ⟨2000000000, 568905856, 5000000000, 1510122574, 370000000000, 16730506372⟩⟩
    hull004_009 108 (by decide +kernel)

private def supportedCone0529 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 116, 115, 117⟩, ⟨3000000000, 816594518, 2000000000, 568905856, 368000000000, 16161600516⟩⟩
    hull004_009 107 (by decide +kernel)

private def supportedCone0530 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 115, 114, 116⟩, ⟨5000000000, 1247777599, 3000000000, 816594518, 365000000000, 15345005998⟩⟩
    hull004_009 106 (by decide +kernel)

private def supportedCone0531 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨283, 318, 318, 283, 318⟩, ⟨67615634324, 53815575299, 0, 0, 1142615634324, 635855613376⟩⟩
    hull004_010 1 (by decide +kernel)

private def supportedCone0532 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 114, 113, 115⟩, ⟨4000000000, 899992776, 5000000000, 1247777599, 360000000000, 14097228399⟩⟩
    hull004_009 105 (by decide +kernel)

private def supportedCone0533 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨318, 354, 354, 318, 354⟩, ⟨46449981035, 19560952723, 0, 0, 1189065615359, 655416566099⟩⟩
    hull004_011 1 (by decide +kernel)

private def supportedCone0534 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 108, 107, 109⟩, ⟨340966835, 62134021, 3276468983, 611626172, 345000000000, 11035220762⟩⟩
    hull004_009 99 (by decide +kernel)

private def supportedCone0535 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 78, 77, 79⟩, ⟨533410203, 71498734, 1466589797, 202807584, 308533410203, 5175822883⟩⟩
    hull004_009 69 (by decide +kernel)

private def supportedCone0536 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 84, 83, 85⟩, ⟨2299062825, 341881567, 688266536, 104459411, 317299062825, 6429454254⟩⟩
    hull004_009 75 (by decide +kernel)

private def supportedCone0537 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 83, 82, 84⟩, ⟨1037050256, 147472754, 2299062825, 341881567, 315000000000, 6087572687⟩⟩
    hull004_009 74 (by decide +kernel)

private def supportedCone0538 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 113, 112, 114⟩, ⟨1000000000, 215262097, 4000000000, 899992776, 356000000000, 13197235623⟩⟩
    hull004_009 104 (by decide +kernel)

private def supportedCone0539 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 77, 76, 78⟩, ⟨1131446969, 149646262, 533410203, 71498734, 308000000000, 5104324149⟩⟩
    hull004_009 68 (by decide +kernel)

private def supportedCone0540 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 71, 70, 72⟩, ⟨1100936837, 136798566, 636743267, 80627777, 302503725233, 4384582617⟩⟩
    hull004_009 62 (by decide +kernel)

private def supportedCone0541 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 67, 66, 68⟩, ⟨1435880651, 168084187, 2033732112, 247366307, 297966267888, 3827290161⟩⟩
    hull004_009 58 (by decide +kernel)

private def supportedCone0542 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨318, 336, 336, 318, 336⟩, ⟨22384365676, 11228863341, 0, 0, 1165000000000, 647084476717⟩⟩
    hull004_012 1 (by decide +kernel)

private def supportedCone0543 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨336, 354, 354, 336, 354⟩, ⟨24065615359, 8332089382, 0, 0, 1189065615359, 655416566099⟩⟩
    hull004_013 1 (by decide +kernel)

def appendixHullConeBlock0016 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0512,
    supportedCone0513,
    supportedCone0514,
    supportedCone0515,
    supportedCone0516,
    supportedCone0517,
    supportedCone0518,
    supportedCone0519,
    supportedCone0520,
    supportedCone0521,
    supportedCone0522,
    supportedCone0523,
    supportedCone0524,
    supportedCone0525,
    supportedCone0526,
    supportedCone0527,
    supportedCone0528,
    supportedCone0529,
    supportedCone0530,
    supportedCone0531,
    supportedCone0532,
    supportedCone0533,
    supportedCone0534,
    supportedCone0535,
    supportedCone0536,
    supportedCone0537,
    supportedCone0538,
    supportedCone0539,
    supportedCone0540,
    supportedCone0541,
    supportedCone0542,
    supportedCone0543,
  ], rfl⟩

private def supportedCone0544 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 60, 59, 61⟩, ⟨1135985046, 115441792, 1317712249, 141660608, 290000000000, 2937838851⟩⟩
    hull004_009 51 (by decide +kernel)

private def supportedCone0545 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 57, 56, 58⟩, ⟨717147340, 69057165, 1502580336, 149488808, 285717147340, 2506063620⟩⟩
    hull004_009 48 (by decide +kernel)

private def supportedCone0546 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨336, 345, 345, 336, 345⟩, ⟨11490795528, 4414777482, 0, 0, 1176490795528, 651499254199⟩⟩
    hull004_014 1 (by decide +kernel)

private def supportedCone0547 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨345, 354, 354, 345, 354⟩, ⟨12574819831, 3917311900, 0, 0, 1189065615359, 655416566099⟩⟩
    hull004_015 1 (by decide +kernel)

private def supportedCone0548 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 54, 53, 55⟩, ⟨2001185206, 173452311, 1998814794, 184328284, 282001185206, 2158314778⟩⟩
    hull004_009 45 (by decide +kernel)

private def supportedCone0549 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 55, 54, 56⟩, ⟨1998814794, 184328284, 1000000000, 94363393, 284000000000, 2342643062⟩⟩
    hull004_009 46 (by decide +kernel)

private def supportedCone0550 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 65, 64, 66⟩, ⟨1000000000, 115603912, 530387237, 62004387, 296000000000, 3597201587⟩⟩
    hull004_009 56 (by decide +kernel)

private def supportedCone0551 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨345, 349, 349, 345, 349⟩, ⟨6339428809, 2034671692, 0, 0, 1182830224337, 653533925891⟩⟩
    hull004_016 1 (by decide +kernel)

private def supportedCone0552 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨349, 354, 354, 349, 354⟩, ⟨6235391022, 1882640208, 0, 0, 1189065615359, 655416566099⟩⟩
    hull004_017 1 (by decide +kernel)

private def supportedCone0553 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 52, 51, 53⟩, ⟨2329787335, 195916729, 501910433, 43066537, 279498089567, 1941795930⟩⟩
    hull004_009 43 (by decide +kernel)

private def supportedCone0554 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨349, 351, 351, 349, 351⟩, ⟨2169775663, 673532216, 0, 0, 1185000000000, 654207458107⟩⟩
    hull004_018 1 (by decide +kernel)

private def supportedCone0555 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨351, 354, 354, 351, 354⟩, ⟨4065615359, 1209107992, 0, 0, 1189065615359, 655416566099⟩⟩
    hull004_019 1 (by decide +kernel)

private def supportedCone0556 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨351, 352, 352, 351, 352⟩, ⟨1513334845, 461917336, 0, 0, 1186513334845, 654669375443⟩⟩
    hull004_020 1 (by decide +kernel)

private def supportedCone0557 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨352, 353, 353, 352, 353⟩, ⟨1248379719, 378715799, 0, 0, 1187761714564, 655048091242⟩⟩
    hull004_021 1 (by decide +kernel)

private def supportedCone0558 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨353, 354, 354, 353, 354⟩, ⟨1303900795, 368474857, 0, 0, 1189065615359, 655416566099⟩⟩
    hull004_022 1 (by decide +kernel)

private def supportedCone0559 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 50, 49, 51⟩, ⟨888204788, 69012269, 1280097444, 102309752, 275888204788, 1643569449⟩⟩
    hull004_009 41 (by decide +kernel)

private def supportedCone0560 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 64, 63, 65⟩, ⟨1700024979, 186483787, 1000000000, 115603912, 295000000000, 3481597675⟩⟩
    hull004_009 55 (by decide +kernel)

private def supportedCone0561 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨352, 354, 354, 352, 354⟩, ⟨2552280514, 747190656, 0, 0, 1189065615359, 655416566099⟩⟩
    hull004_023 1 (by decide +kernel)

private def supportedCone0562 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 53, 52, 54⟩, ⟨501910433, 43066537, 2001185206, 173452311, 280000000000, 1984862467⟩⟩
    hull004_009 44 (by decide +kernel)

private def supportedCone0563 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨351, 354, 351, 351, 354⟩, ⟨0, 0, 4065615359, 1209107992, 1185000000000, 654207458107⟩⟩
    hull004_019 0 (by decide +kernel)

private def supportedCone0564 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨353, 354, 353, 353, 354⟩, ⟨0, 0, 1303900795, 368474857, 1187761714564, 655048091242⟩⟩
    hull004_022 0 (by decide +kernel)

private def supportedCone0565 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 58, 57, 59⟩, ⟨1502580336, 149488808, 1644287278, 166844631, 287219727676, 2655552428⟩⟩
    hull004_009 49 (by decide +kernel)

private def supportedCone0566 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨352, 353, 352, 352, 353⟩, ⟨0, 0, 1248379719, 378715799, 1186513334845, 654669375443⟩⟩
    hull004_021 0 (by decide +kernel)

private def supportedCone0567 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 46, 45, 47⟩, ⟨412549723, 29103357, 1084869137, 78356954, 272412549723, 1385121505⟩⟩
    hull004_009 37 (by decide +kernel)

private def supportedCone0568 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨349, 351, 349, 349, 351⟩, ⟨0, 0, 2169775663, 673532216, 1182830224337, 653533925891⟩⟩
    hull004_018 0 (by decide +kernel)

private def supportedCone0569 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨351, 352, 351, 351, 352⟩, ⟨0, 0, 1513334845, 461917336, 1185000000000, 654207458107⟩⟩
    hull004_020 0 (by decide +kernel)

private def supportedCone0570 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨352, 354, 352, 352, 354⟩, ⟨0, 0, 2552280514, 747190656, 1186513334845, 654669375443⟩⟩
    hull004_023 0 (by decide +kernel)

private def supportedCone0571 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 99, 98, 100⟩, ⟨134225639, 23083035, 994909235, 171180590, 334005090765, 9103087745⟩⟩
    hull004_009 90 (by decide +kernel)

private def supportedCone0572 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨349, 350, 349, 349, 350⟩, ⟨0, 0, 982006866, 305463355, 1182830224337, 653533925891⟩⟩
    hull004_024 0 (by decide +kernel)

private def supportedCone0573 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨350, 351, 350, 350, 351⟩, ⟨0, 0, 1187768797, 368068861, 1183812231203, 653839389246⟩⟩
    hull004_025 0 (by decide +kernel)

private def supportedCone0574 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨349, 350, 350, 349, 350⟩, ⟨982006866, 305463355, 0, 0, 1183812231203, 653839389246⟩⟩
    hull004_024 1 (by decide +kernel)

private def supportedCone0575 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 54, 53, 55⟩, ⟨2001185206, 173452311, 1998814794, 184328284, 282001185206, 2158314778⟩⟩
    hull004_026 19 (by decide +kernel)

def appendixHullConeBlock0017 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0544,
    supportedCone0545,
    supportedCone0546,
    supportedCone0547,
    supportedCone0548,
    supportedCone0549,
    supportedCone0550,
    supportedCone0551,
    supportedCone0552,
    supportedCone0553,
    supportedCone0554,
    supportedCone0555,
    supportedCone0556,
    supportedCone0557,
    supportedCone0558,
    supportedCone0559,
    supportedCone0560,
    supportedCone0561,
    supportedCone0562,
    supportedCone0563,
    supportedCone0564,
    supportedCone0565,
    supportedCone0566,
    supportedCone0567,
    supportedCone0568,
    supportedCone0569,
    supportedCone0570,
    supportedCone0571,
    supportedCone0572,
    supportedCone0573,
    supportedCone0574,
    supportedCone0575,
  ], rfl⟩

private def supportedCone0576 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 49, 48, 50⟩, ⟨1183935478, 87538993, 888204788, 69012269, 275000000000, 1574557180⟩⟩
    hull004_009 40 (by decide +kernel)

private def supportedCone0577 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨345, 347, 347, 345, 347⟩, ⟨3509204472, 1153214516, 0, 0, 1180000000000, 652652468715⟩⟩
    hull004_027 1 (by decide +kernel)

private def supportedCone0578 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨347, 349, 349, 348, 349⟩, ⟨1246269519, 389252530, 0, 0, 1182830224337, 653533925891⟩⟩
    hull004_028 2 (by decide +kernel)

private def supportedCone0579 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 70, 50, 49, 51⟩, ⟨888204788, 69012269, 1280097444, 102309752, 275888204788, 1643569449⟩⟩
    hull004_026 15 (by decide +kernel)

private def supportedCone0580 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨347, 349, 347, 347, 348⟩, ⟨0, 0, 1583954818, 492204646, 1180000000000, 652652468715⟩⟩
    hull004_028 0 (by decide +kernel)

private def supportedCone0581 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨347, 349, 348, 347, 349⟩, ⟨1583954818, 492204646, 1246269519, 389252530, 1181583954818, 653144673361⟩⟩
    hull004_028 1 (by decide +kernel)

private def supportedCone0582 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 39, 38, 40⟩, ⟨1225499220, 67598571, 912885189, 53518492, 265000000000, 910048585⟩⟩
    hull004_009 30 (by decide +kernel)

private def supportedCone0583 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨349, 354, 349, 349, 354⟩, ⟨0, 0, 6235391022, 1882640208, 1182830224337, 653533925891⟩⟩
    hull004_017 0 (by decide +kernel)

private def supportedCone0584 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 97, 96, 98⟩, ⟨260218803, 43430717, 1870865126, 318998994, 332000000000, 8761005716⟩⟩
    hull004_009 88 (by decide +kernel)

private def supportedCone0585 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 45, 44, 46⟩, ⟨734647838, 50900754, 412549723, 29103357, 272000000000, 1356018148⟩⟩
    hull004_009 36 (by decide +kernel)

private def supportedCone0586 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨345, 346, 346, 345, 346⟩, ⟨1461230523, 501340669, 0, 0, 1177952026051, 652000594868⟩⟩
    hull004_029 1 (by decide +kernel)

private def supportedCone0587 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨346, 347, 347, 346, 347⟩, ⟨2047973949, 651873847, 0, 0, 1180000000000, 652652468715⟩⟩
    hull004_030 1 (by decide +kernel)

private def supportedCone0588 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨346, 347, 346, 346, 347⟩, ⟨0, 0, 2047973949, 651873847, 1177952026051, 652000594868⟩⟩
    hull004_030 0 (by decide +kernel)

private def supportedCone0589 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 64, 63, 65⟩, ⟨1700024979, 186483787, 1000000000, 115603912, 295000000000, 3481597675⟩⟩
    hull004_005 55 (by decide +kernel)

private def supportedCone0590 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 60, 59, 61⟩, ⟨1135985046, 115441792, 1317712249, 141660608, 290000000000, 2937838851⟩⟩
    hull004_005 51 (by decide +kernel)

private def supportedCone0591 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 57, 56, 58⟩, ⟨717147340, 69057165, 1502580336, 149488808, 285717147340, 2506063620⟩⟩
    hull004_005 48 (by decide +kernel)

private def supportedCone0592 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 54, 53, 55⟩, ⟨2001185206, 173452311, 1998814794, 184328284, 282001185206, 2158314778⟩⟩
    hull004_005 45 (by decide +kernel)

private def supportedCone0593 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 53, 52, 54⟩, ⟨501910433, 43066537, 2001185206, 173452311, 280000000000, 1984862467⟩⟩
    hull004_005 44 (by decide +kernel)

private def supportedCone0594 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 51, 50, 52⟩, ⟨1280097444, 102309752, 2329787335, 195916729, 277168302232, 1745879201⟩⟩
    hull004_005 42 (by decide +kernel)

private def supportedCone0595 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 52, 51, 53⟩, ⟨2329787335, 195916729, 501910433, 43066537, 279498089567, 1941795930⟩⟩
    hull004_005 43 (by decide +kernel)

private def supportedCone0596 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 39, 38, 40⟩, ⟨1225499220, 67598571, 912885189, 53518492, 265000000000, 910048585⟩⟩
    hull004_005 30 (by decide +kernel)

private def supportedCone0597 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 56, 55, 57⟩, ⟨1000000000, 94363393, 717147340, 69057165, 285000000000, 2437006455⟩⟩
    hull004_005 47 (by decide +kernel)

private def supportedCone0598 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 49, 48, 50⟩, ⟨1183935478, 87538993, 888204788, 69012269, 275000000000, 1574557180⟩⟩
    hull004_005 40 (by decide +kernel)

private def supportedCone0599 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 45, 44, 46⟩, ⟨734647838, 50900754, 412549723, 29103357, 272000000000, 1356018148⟩⟩
    hull004_005 36 (by decide +kernel)

private def supportedCone0600 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨345, 346, 345, 345, 346⟩, ⟨0, 0, 1461230523, 501340669, 1176490795528, 651499254199⟩⟩
    hull004_029 0 (by decide +kernel)

private def supportedCone0601 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨336, 354, 336, 336, 354⟩, ⟨0, 0, 24065615359, 8332089382, 1165000000000, 647084476717⟩⟩
    hull004_013 0 (by decide +kernel)

private def supportedCone0602 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 96, 95, 97⟩, ⟨777470382, 128040679, 260218803, 43430717, 331739781197, 8717574999⟩⟩
    hull004_009 87 (by decide +kernel)

private def supportedCone0603 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨336, 340, 340, 336, 340⟩, ⟨5000000000, 1984751604, 0, 0, 1170000000000, 649069228321⟩⟩
    hull004_031 1 (by decide +kernel)

private def supportedCone0604 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨340, 345, 345, 340, 345⟩, ⟨6490795528, 2430025878, 0, 0, 1176490795528, 651499254199⟩⟩
    hull004_032 1 (by decide +kernel)

private def supportedCone0605 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 58, 57, 59⟩, ⟨1502580336, 149488808, 1644287278, 166844631, 287219727676, 2655552428⟩⟩
    hull004_005 49 (by decide +kernel)

private def supportedCone0606 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨340, 342, 342, 340, 342⟩, ⟨2631603835, 991851896, 0, 0, 1172631603835, 650061080217⟩⟩
    hull004_033 1 (by decide +kernel)

private def supportedCone0607 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨342, 345, 345, 342, 345⟩, ⟨3859191693, 1438173982, 0, 0, 1176490795528, 651499254199⟩⟩
    hull004_034 1 (by decide +kernel)

def appendixHullConeBlock0018 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0576,
    supportedCone0577,
    supportedCone0578,
    supportedCone0579,
    supportedCone0580,
    supportedCone0581,
    supportedCone0582,
    supportedCone0583,
    supportedCone0584,
    supportedCone0585,
    supportedCone0586,
    supportedCone0587,
    supportedCone0588,
    supportedCone0589,
    supportedCone0590,
    supportedCone0591,
    supportedCone0592,
    supportedCone0593,
    supportedCone0594,
    supportedCone0595,
    supportedCone0596,
    supportedCone0597,
    supportedCone0598,
    supportedCone0599,
    supportedCone0600,
    supportedCone0601,
    supportedCone0602,
    supportedCone0603,
    supportedCone0604,
    supportedCone0605,
    supportedCone0606,
    supportedCone0607,
  ], rfl⟩

private def supportedCone0608 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨342, 343, 343, 342, 343⟩, ⟨1031531489, 397624336, 0, 0, 1173663135324, 650458704553⟩⟩
    hull004_035 1 (by decide +kernel)

private def supportedCone0609 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨343, 345, 345, 343, 345⟩, ⟨2827660204, 1040549646, 0, 0, 1176490795528, 651499254199⟩⟩
    hull004_036 1 (by decide +kernel)

private def supportedCone0610 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨343, 344, 344, 343, 344⟩, ⟨1336864676, 514305523, 0, 0, 1175000000000, 650973010076⟩⟩
    hull004_037 1 (by decide +kernel)

private def supportedCone0611 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨344, 345, 345, 344, 345⟩, ⟨1490795528, 526244123, 0, 0, 1176490795528, 651499254199⟩⟩
    hull004_038 1 (by decide +kernel)

private def supportedCone0612 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨344, 345, 344, 344, 345⟩, ⟨0, 0, 1490795528, 526244123, 1175000000000, 650973010076⟩⟩
    hull004_038 0 (by decide +kernel)

private def supportedCone0613 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨343, 344, 343, 343, 344⟩, ⟨0, 0, 1336864676, 514305523, 1173663135324, 650458704553⟩⟩
    hull004_037 0 (by decide +kernel)

private def supportedCone0614 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨345, 349, 345, 345, 349⟩, ⟨0, 0, 6339428809, 2034671692, 1176490795528, 651499254199⟩⟩
    hull004_016 0 (by decide +kernel)

private def supportedCone0615 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨345, 347, 345, 345, 347⟩, ⟨0, 0, 3509204472, 1153214516, 1176490795528, 651499254199⟩⟩
    hull004_027 0 (by decide +kernel)

private def supportedCone0616 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨345, 354, 345, 345, 354⟩, ⟨0, 0, 12574819831, 3917311900, 1176490795528, 651499254199⟩⟩
    hull004_015 0 (by decide +kernel)

private def supportedCone0617 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 61, 60, 62⟩, ⟨1317712249, 141660608, 1493154549, 162160382, 291317712249, 3079499459⟩⟩
    hull004_009 52 (by decide +kernel)

private def supportedCone0618 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 59, 58, 60⟩, ⟨1644287278, 166844631, 1135985046, 115441792, 288864014954, 2822397059⟩⟩
    hull004_009 50 (by decide +kernel)

private def supportedCone0619 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨342, 343, 342, 342, 343⟩, ⟨0, 0, 1031531489, 397624336, 1172631603835, 650061080217⟩⟩
    hull004_035 0 (by decide +kernel)

private def supportedCone0620 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨343, 345, 343, 343, 345⟩, ⟨0, 0, 2827660204, 1040549646, 1173663135324, 650458704553⟩⟩
    hull004_036 0 (by decide +kernel)

private def supportedCone0621 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 44, 43, 45⟩, ⟨1265352162, 86554930, 734647838, 50900754, 271265352162, 1305117394⟩⟩
    hull004_009 35 (by decide +kernel)

private def supportedCone0622 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 70, 69, 71⟩, ⟨840721629, 103780683, 1100936837, 136798566, 301402788396, 4247784051⟩⟩
    hull004_009 61 (by decide +kernel)

private def supportedCone0623 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨342, 345, 342, 342, 345⟩, ⟨0, 0, 3859191693, 1438173982, 1172631603835, 650061080217⟩⟩
    hull004_034 0 (by decide +kernel)

private def supportedCone0624 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨340, 341, 341, 340, 341⟩, ⟨1432773253, 541275864, 0, 0, 1171432773253, 649610504185⟩⟩
    hull004_039 1 (by decide +kernel)

private def supportedCone0625 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨341, 342, 342, 341, 342⟩, ⟨1198830582, 450576032, 0, 0, 1172631603835, 650061080217⟩⟩
    hull004_040 1 (by decide +kernel)

private def supportedCone0626 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 56, 55, 57⟩, ⟨1000000000, 94363393, 717147340, 69057165, 285000000000, 2437006455⟩⟩
    hull004_009 47 (by decide +kernel)

private def supportedCone0627 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨341, 342, 341, 341, 342⟩, ⟨0, 0, 1198830582, 450576032, 1171432773253, 649610504185⟩⟩
    hull004_040 0 (by decide +kernel)

private def supportedCone0628 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 38, 37, 39⟩, ⟨1099837485, 58486581, 1225499220, 67598571, 263774500780, 842450014⟩⟩
    hull004_009 29 (by decide +kernel)

private def supportedCone0629 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 63, 62, 64⟩, ⟨489108223, 53454047, 1700024979, 186483787, 293299975021, 3295113888⟩⟩
    hull004_009 54 (by decide +kernel)

private def supportedCone0630 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨340, 345, 340, 340, 345⟩, ⟨0, 0, 6490795528, 2430025878, 1170000000000, 649069228321⟩⟩
    hull004_032 0 (by decide +kernel)

private def supportedCone0631 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨336, 338, 338, 336, 338⟩, ⟨2679463609, 1087380850, 0, 0, 1167679463609, 648171857567⟩⟩
    hull004_041 1 (by decide +kernel)

private def supportedCone0632 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨338, 340, 340, 338, 340⟩, ⟨2320536391, 897370754, 0, 0, 1170000000000, 649069228321⟩⟩
    hull004_042 1 (by decide +kernel)

private def supportedCone0633 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨340, 341, 340, 340, 341⟩, ⟨0, 0, 1432773253, 541275864, 1170000000000, 649069228321⟩⟩
    hull004_039 0 (by decide +kernel)

private def supportedCone0634 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 76, 75, 77⟩, ⟨1269209378, 167658005, 1131446969, 149646262, 306868553031, 4954677887⟩⟩
    hull004_009 67 (by decide +kernel)

private def supportedCone0635 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 73, 72, 74⟩, ⟨659997516, 85802185, 1199533984, 156935366, 303800466016, 4551012579⟩⟩
    hull004_009 64 (by decide +kernel)

private def supportedCone0636 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 75, 74, 76⟩, ⟨599343653, 79071937, 1269209378, 167658005, 305599343653, 4787019882⟩⟩
    hull004_009 66 (by decide +kernel)

private def supportedCone0637 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨318, 327, 327, 318, 327⟩, ⟨11586549766, 6319182727, 0, 0, 1154202184090, 642174796103⟩⟩
    hull004_043 1 (by decide +kernel)

private def supportedCone0638 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨327, 336, 336, 327, 336⟩, ⟨10797815910, 4909680614, 0, 0, 1165000000000, 647084476717⟩⟩
    hull004_044 1 (by decide +kernel)

private def supportedCone0639 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 283, 68, 67, 69⟩, ⟨2033732112, 247366307, 562066767, 69346900, 300000000000, 4074656468⟩⟩
    hull004_009 59 (by decide +kernel)

def appendixHullConeBlock0019 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone0608,
    supportedCone0609,
    supportedCone0610,
    supportedCone0611,
    supportedCone0612,
    supportedCone0613,
    supportedCone0614,
    supportedCone0615,
    supportedCone0616,
    supportedCone0617,
    supportedCone0618,
    supportedCone0619,
    supportedCone0620,
    supportedCone0621,
    supportedCone0622,
    supportedCone0623,
    supportedCone0624,
    supportedCone0625,
    supportedCone0626,
    supportedCone0627,
    supportedCone0628,
    supportedCone0629,
    supportedCone0630,
    supportedCone0631,
    supportedCone0632,
    supportedCone0633,
    supportedCone0634,
    supportedCone0635,
    supportedCone0636,
    supportedCone0637,
    supportedCone0638,
    supportedCone0639,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
