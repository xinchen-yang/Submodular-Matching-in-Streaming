import SubmodularMatching.LowerBoundGlobalAverage
import Mathlib.Algebra.BigOperators.Group.Finset.Piecewise
import Mathlib.Logic.Equiv.Prod

/-! # Factoring the independent blocks at a stream boundary -/

namespace SubmodularMatching.LowerBoundGlobal

open scoped BigOperators

noncomputable section

/-- Separate one independent block from all other blocks in the full product
law. A block can represent all sampled pairs of a stage or one base phase. -/
theorem mass_split_at {I A : Type*} [Fintype I] [DecidableEq I]
    (law : I → A → ℝ) (i : I) (samples : I → A) :
    (∏ j, law j (samples j)) = law i (samples i) *
      (∏ j : { j // j ≠ i }, law j (samples j)) := by
  rw [Fintype.prod_eq_mul_prod_compl i]
  rw [Finset.prod_subtype (p := fun j => j ≠ i) ({i}ᶜ : Finset I) (by simp) (fun j => law j (samples j))]

/-- The full fixed-size sampling law can be summed by holding the other
blocks fixed. The output may depend arbitrarily on the other blocks. -/
theorem expectation_split_at {I A : Type*}
    [Fintype I] [DecidableEq I] [Fintype A]
    (law : I → A → ℝ) (f : (I → A) → ℝ) (i : I) :
    (∑ samples : I → A, (∏ j, law j (samples j)) * f samples) =
      ∑ other : { j // j ≠ i } → A,
        (∏ j : { j // j ≠ i }, law j (other j)) *
          (∑ x, law i x * f ((Equiv.funSplitAt i A).symm (x, other))) := by
  let split := Equiv.funSplitAt i A
  rw [← split.symm.sum_comp (fun S => (∏ j, law j (S j)) * f S)]
  rw [Fintype.sum_prod_type, Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro other _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x _
  rw [mass_split_at law i]
  have h1 : split.symm (x, other) i = x := congrArg Prod.fst (split.apply_symm_apply (x, other))
  have h2 (j : { j // j ≠ i }) : split.symm (x, other) j = other j :=
    congrFun (congrArg Prod.snd (split.apply_symm_apply (x, other))) j
  simp only [h1, h2]
  ring

/-- Correct factorization for a prefix-conditioned tuple. The uniform
tuple may be exposed one coordinate at a time, so every suffix is still
uniform after fixing the prefix. -/
theorem independent_prefix_split {I A : Type*}
    [Fintype I] [Fintype A]
    (keep : I → Prop) [DecidablePred keep] (law : I → A → ℝ) (samples : I → A) :
    (∏ j, law j (samples j)) =
      (∏ j : {j // keep j}, law j (samples j)) *
        (∏ j : {j // ¬keep j}, law j (samples j)) :=
  (Fintype.prod_subtype_mul_prod_subtype keep (fun j => law j (samples j))).symm

/-- Integrate a per-coordinate estimate over the other blocks and over
prior side information. The latter can determine every block's law. -/
theorem average_independent_coordinate {I A Z : Type*}
    [Fintype I] [DecidableEq I] [Fintype A] [Fintype Z]
    (sideLaw : Z → ℝ) (hside0 : ∀ z, 0 ≤ sideLaw z) (hside : ∑ z, sideLaw z = 1)
    (law : Z → I → A → ℝ) (hlaw0 : ∀ z j a, 0 ≤ law z j a)
    (hlaw : ∀ z j, ∑ a, law z j a = 1)
    (f : Z → (I → A) → ℝ) (i : I) (bound : ℝ)
    (hcoordinate : ∀ z (other : {j // j ≠ i} → A),
      0 < sideLaw z → 0 < (∏ j : {j // j ≠ i}, law z j (other j)) →
      (∑ x, law z i x * f z ((Equiv.funSplitAt i A).symm (x, other))) ≤ bound) :
    (∑ input : Z × (I → A), sideLaw input.1 * (∏ j, law input.1 j (input.2 j)) *
      f input.1 input.2) ≤ bound := by
  rw [Fintype.sum_prod_type]
  simp only [mul_assoc, ← Finset.mul_sum]
  calc
    _ ≤ ∑ z, sideLaw z * bound := by
      apply Finset.sum_le_sum
      intro z _
      by_cases hz : 0 < sideLaw z
      · apply mul_le_mul_of_nonneg_left _ (hside0 z)
        rw [expectation_split_at (law z) (f z) i]
        have hout : (∑ other : {j // j ≠ i} → A,
            ∏ j : {j // j ≠ i}, law z j (other j)) = 1 := by
          rw [← Fintype.prod_sum]
          simp [hlaw]
        calc
          _ ≤ ∑ other : {j // j ≠ i} → A, (∏ j : {j // j ≠ i}, law z j (other j)) * bound := by
            apply Finset.sum_le_sum
            intro other _
            have hnonneg : 0 ≤ ∏ j : {j // j ≠ i}, law z j (other j) :=
              Finset.prod_nonneg (fun j _ => hlaw0 z j (other j))
            by_cases ho : 0 < ∏ j : {j // j ≠ i}, law z j (other j)
            · exact mul_le_mul_of_nonneg_left (hcoordinate z other hz ho) hnonneg
            · simp [le_antisymm (le_of_not_gt ho) hnonneg]
          _ = _ := by rw [← Finset.sum_mul, hout, one_mul]
      · simp [le_antisymm (le_of_not_gt hz) (hside0 z)]
    _ = _ := by rw [← Finset.sum_mul, hside, one_mul]

end

end SubmodularMatching.LowerBoundGlobal
