import SubmodularMatching.ReplaySubinterval

namespace SubmodularMatching.SourceCertificate.Replay.HardNextLeft

set_option maxRecDepth 5000
set_option maxHeartbeats 10000000

private theorem step75 : ProjectedGoal ⟨216, 431, 0, 17, 709, 851⟩ :=
  projectedGoal_chunk _ (.leaf 0x1af000000000000005b1500) (by decide +kernel)

theorem Part00011 : ProjectedGoal ⟨216, 431, 0, 17, 709, 851⟩ := step75

end SubmodularMatching.SourceCertificate.Replay.HardNextLeft
