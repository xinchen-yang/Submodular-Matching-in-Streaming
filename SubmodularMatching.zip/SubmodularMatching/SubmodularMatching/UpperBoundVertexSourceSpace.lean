import SubmodularMatching.UpperBoundSourceProgram
import SubmodularMatching.UpperBoundVertexResources
import SubmodularMatching.StreamingSchedulerStorage

/-! # The appendix's deterministic simultaneous record bound -/

namespace SubmodularMatching.UpperBoundAssembly

open Streaming NumericalCertificate
open scoped BigOperators

noncomputable section

private def referenceGuess : PotentialConfig := appendixGuessConfig 2 (by decide) 1

private def potentialRatioConstant : ℝ :=
  (1 + (referenceGuess.maxRate + 1) * referenceGuess.p) /
    (referenceGuess.minLow * referenceGuess.p * finiteError)

/-- Uniform constant in the per-vertex incidence bound for the fixed
appendix rates. It is independent of input sizes and active guess scales. -/
def appendixIncidenceConstant : ℕ :=
  ⌈1 + (2 / (referenceGuess.kappa * referenceGuess.p)) *
    (max 0 (Real.log potentialRatioConstant) + Real.log 2)⌉₊

/-- Bound the cap-to-seed ratio before taking its logarithm. -/
theorem appendixGuessConfig_cap_seed (n : ℕ) (hn : 2 ≤ n) (τ : ℝ) (hτ : 0 < τ) :
    let C := appendixGuessConfig n hn τ
    C.cap / C.seed = potentialRatioConstant * (n : ℝ) := by
  intro C
  obtain ⟨hTau, hθ, _, _⟩ := appendixGuessConfig_spec n hn τ hτ
  have hp : C.p = referenceGuess.p := rfl
  have hl : C.minLow = referenceGuess.minLow := rfl
  have hr : C.maxRate = referenceGuess.maxRate := rfl
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast (show n ≠ 0 by omega)
  have hτ' : C.tau = τ := hTau
  have hθ' : C.theta = finiteError * τ / (n : ℝ) := hθ
  unfold PotentialConfig.cap PotentialConfig.seed potentialRatioConstant
  rw [hp, hl, hr, hτ', hθ']
  field_simp [hn', hτ.ne', referenceGuess.minLow_pos.ne', referenceGuess.p_pos.ne', error_bounds.2.2.1.ne']

/-- Every positive-scale instance has logarithmically many incidences at
one stored vertex, whether or not its estimates were accurate. -/
theorem appendixGuessConfig_incidenceLimit_le (n : ℕ) (hn : 2 ≤ n) (τ : ℝ) (hτ : 0 < τ) :
    (appendixGuessConfig n hn τ).incidenceLimit ≤ appendixIncidenceConstant * ((n + 1).log2 + 1) := by
  let C := appendixGuessConfig n hn τ
  let w := (n + 1).log2 + 1
  let A := 2 / (referenceGuess.kappa * referenceGuess.p)
  let L := max 0 (Real.log potentialRatioConstant)
  have hp : C.p = referenceGuess.p := rfl
  have hk : C.kappa = referenceGuess.kappa := rfl
  have hA : 0 ≤ A := by dsimp [A]; positivity [referenceGuess.kappa_pos, referenceGuess.p_pos]
  have hL : 0 ≤ L := le_max_left _ _
  have hw : (1 : ℝ) ≤ w := by exact_mod_cast (show 1 ≤ w by dsimp [w]; omega)
  have hn' : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
  have hpowN : n ≤ 2 ^ w := (Nat.le_succ n).trans (Nat.lt_log2_self (n := n + 1)).le
  have hpowR : (n : ℝ) ≤ (2 : ℝ) ^ w := by exact_mod_cast hpowN
  have hlog := Real.log_le_log hn' hpowR
  rw [Real.log_pow] at hlog
  have hR : 0 < potentialRatioConstant := by
    unfold potentialRatioConstant
    have hr : 0 ≤ referenceGuess.maxRate := referenceGuess.minLow_pos.le.trans
      (referenceGuess.base_bounds.2.2.1.trans referenceGuess.base_bounds.2.2.2)
    positivity [referenceGuess.minLow_pos, referenceGuess.p_pos, error_bounds.2.2.1]
  have hlog' : Real.log (C.cap / C.seed) ≤ (L + Real.log 2) * (w : ℝ) := by
    rw [appendixGuessConfig_cap_seed n hn τ hτ]
    rw [Real.log_mul hR.ne' hn'.ne']
    calc
      _ ≤ L + (w : ℝ) * Real.log 2 := add_le_add (le_max_right _ _) hlog
      _ ≤ L * (w : ℝ) + (w : ℝ) * Real.log 2 := by
        exact add_le_add (by simpa only [mul_one] using mul_le_mul_of_nonneg_left hw hL) le_rfl
      _ = _ := by ring
  have hbound : 1 + 2 / (C.kappa * C.p) * Real.log (C.cap / C.seed) ≤
      ((appendixIncidenceConstant * w : ℕ) : ℝ) := by
    rw [hp, hk]
    change 1 + A * Real.log (C.cap / C.seed) ≤ _
    calc
      _ ≤ (w : ℝ) + A * ((L + Real.log 2) * (w : ℝ)) :=
        add_le_add hw (mul_le_mul_of_nonneg_left hlog' hA)
      _ = (1 + A * (L + Real.log 2)) * (w : ℝ) := by ring
      _ ≤ _ := by
        push_cast
        exact mul_le_mul_of_nonneg_right (Nat.le_ceil _) (Nat.cast_nonneg w)
  exact (Nat.floor_le_floor hbound).trans_eq (Nat.floor_natCast _)

/-- A fixed logarithmic bound on the number of dyadic guesses. -/
def appendixGuessCountConstant : ℕ := 3 + (10000000000 : ℕ).log2

theorem appendixGuessCount_le (n : ℕ) :
    Nat.clog 2 (n * 10000000000) + 1 ≤ appendixGuessCountConstant * ((n + 1).log2 + 1) := by
  let w := (n + 1).log2 + 1
  have h : n * 10000000000 ≤ 10000000000 * (n + 1) ^ 1 := by
    rw [pow_one, Nat.mul_comm n]
    exact Nat.mul_le_mul_left _ (Nat.le_succ _)
  have hp := polynomial_index_word_bound h
  have hclog := Nat.clog_le_of_le_pow hp.le
  have hw : 1 ≤ w := by dsimp [w]; omega
  calc
    _ ≤ (1 + (10000000000 : ℕ).log2 + 1) * w + 1 := Nat.add_le_add_right hclog _
    _ ≤ (1 + (10000000000 : ℕ).log2 + 1) * w + w := Nat.add_le_add_left hw _
    _ = _ := by unfold appendixGuessCountConstant; ring

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The actual active records, summed over all live guesses, have the
quadratic logarithmic bound at every prefix of the stream. -/
theorem appendixSource_totalStored_le (edges : ℕ → E) (ends : E → V × V)
    (f : Finset E → ℝ) (n arrivals : ℕ) (hn : 2 ≤ n) (ha : arrivals ≤ n ^ 2)
    (hf : IsSubmodular f) (hmono : IsMonotone f) (hzero : f ∅ = 0)
    (k : ℕ) {N : ℕ} (hN : 0 < N) (hist : SourceBatchHistory N) (allEdges M : Finset E)
    (hin : ∀ i < k, edges i ∈ allEdges)
    (hloop : ∀ e ∈ allEdges, (ends e).1 ≠ (ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet ends) A →
      A.card ≤ M.card)
    (hraw : ∀ i < k, ∀ j r, ∃ A, hist (i, j) r = marginal f (edges i) A) :
    let P := appendixScheduledSource edges ends f n arrivals hn ha hf hmono hzero
    ∑ j ∈ activeGuessIndices P.width (guessAnchor P.width P.value k)
        (singletonMaximum P.value k) P.span, (P.snapshot hist k j).stored.card ≤
      2 * M.card * appendixIncidenceConstant * ((n + 1).log2 + 1) *
        (appendixGuessCountConstant * ((n + 1).log2 + 1)) := by
  intro P
  let w := (n + 1).log2 + 1
  have hl : P.span + 1 ≤ appendixGuessCountConstant * w := appendixGuessCount_le n
  have h := P.snapshot_edges_card_le hist k hN (appendixIncidenceConstant * w)
    allEdges M hin hloop hMsub hM hmax (appendixGuessConfig_incidenceLimit_le n hn) hraw
  calc
    _ ≤ 2 * M.card * (appendixIncidenceConstant * w) * (P.span + 1) := h
    _ ≤ 2 * M.card * (appendixIncidenceConstant * w) * (appendixGuessCountConstant * w) :=
      Nat.mul_le_mul_left _ hl
    _ = _ := by ring

end

end SubmodularMatching.UpperBoundAssembly
