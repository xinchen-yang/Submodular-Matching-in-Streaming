import SubmodularMatching.NonmonotoneOptimizerMarginals
import Mathlib.Tactic.FieldSimp

/-! Signed submodular objectives under independent sampling, Appendix M. -/

namespace SubmodularMatching

noncomputable section

variable {E : Type*} [DecidableEq E]

theorem submodular_union_fixed (f : Finset E → ℝ) (hf : IsSubmodular f) (T : Finset E) :
    IsSubmodular (fun A => f (A ∪ T)) := by
  intro A B
  have h := hf (A ∪ T) (B ∪ T)
  have hu : (A ∪ T) ∪ (B ∪ T) = (A ∪ B) ∪ T := by ext e; simp; tauto
  have hi : (A ∪ T) ∩ (B ∪ T) = (A ∩ B) ∪ T := by ext e; simp; tauto
  rwa [hu, hi] at h

private theorem signed_mix_step (t x y a b c d : ℝ)
    (ht : 0 ≤ t) (ht1 : t ≤ 1) (hxy : x ≤ y) (hs : d - b ≤ c - a) :
    (1-t)*((1-x)*a+x*c) + t*((1-y)*b+y*d) ≤
      (1-((1-t)*x+t*y))*((1-t)*a+t*b) + ((1-t)*x+t*y)*((1-t)*c+t*d) := by
  have h := mul_nonneg (mul_nonneg (mul_nonneg ht (sub_nonneg.mpr ht1))
    (sub_nonneg.mpr hxy)) (sub_nonneg.mpr hs)
  linarith only [show 0 ≤ t*(1-t)*(y-x)*((c-a)-(d-b)) from h]

/-- The finite multilinear extension is concave on every segment between
coordinatewise comparable points, including objectives with signed marginals. -/
theorem bernoulli_comparable_concavity (edges : ℕ → E) (x y : ℕ → ℝ)
    (f : Finset E → ℝ) (n : ℕ) (hf : IsSubmodular f)
    (hinj : ∀ i < n, ∀ j < n, edges i = edges j → i = j)
    (hxy : ∀ i < n, 0 ≤ x i ∧ x i ≤ y i ∧ y i ≤ 1)
    (t : ℝ) (ht : 0 ≤ t) (ht1 : t ≤ 1) :
    (1-t) * bernoulliExpectation edges x f n + t * bernoulliExpectation edges y f n ≤
      bernoulliExpectation edges (fun i => (1-t)*x i+t*y i) f n := by
  induction n generalizing f with
  | zero => simp; linarith
  | succ n ih =>
    let e := edges n
    let f' := fun A : Finset E => f (A ∪ {e})
    have hinj' := fun i (hi : i < n) j (hj : j < n) =>
      hinj i (Nat.lt_succ_of_lt hi) j (Nat.lt_succ_of_lt hj)
    have hxy' := fun i (hi : i < n) => hxy i (Nat.lt_succ_of_lt hi)
    have hb := hxy n (Nat.lt_succ_self n)
    have h0 := ih f hf hinj' hxy'
    have h1 := ih f' (submodular_union_fixed f hf {e}) hinj' hxy'
    have hne (i : ℕ) (hi : i < n) (he : edges i = e) : False :=
      (ne_of_lt hi) (hinj i (Nat.lt_succ_of_lt hi) n (Nat.lt_succ_self n) he)
    have hs := bernoulliExpectation_antitone_probabilities edges x y
      (fun A => marginal f e (A.erase e)) n hxy' (fun A B hAB =>
        diminishing_returns f hf _ _ e (Finset.erase_subset_erase e hAB) (Finset.notMem_erase _ _))
    rw [NonmonotoneOptimizer.expectation_erase edges y e (marginal f e) n
      (fun i hi he => (hne i hi he).elim),
      NonmonotoneOptimizer.expectation_erase edges x e (marginal f e) n
      (fun i hi he => (hne i hi he).elim)] at hs
    change bernoulliExpectation edges y (fun A => f' A - f A) n ≤
      bernoulliExpectation edges x (fun A => f' A - f A) n at hs
    rw [bernoulliExpectation_sub, bernoulliExpectation_sub] at hs
    have hm : 0 ≤ (1-t)*x n+t*y n :=
      add_nonneg (mul_nonneg (sub_nonneg.mpr ht1) hb.1) (mul_nonneg ht (hb.1.trans hb.2.1))
    have hm1 : 0 ≤ 1-((1-t)*x n+t*y n) := by
      nlinarith only [mul_nonneg (sub_nonneg.mpr ht1) (sub_nonneg.mpr (hb.2.1.trans hb.2.2)),
        mul_nonneg ht (sub_nonneg.mpr hb.2.2)]
    simp only [bernoulliExpectation_succ]
    exact (signed_mix_step t (x n) (y n) _ _ _ _ ht ht1 hb.2.1 hs).trans
      (add_le_add (mul_le_mul_of_nonneg_left h0 hm1) (mul_le_mul_of_nonneg_left h1 hm))

private theorem bernoulli_zero_coordinates (edges : ℕ → E) (f : Finset E → ℝ) (n : ℕ) :
    bernoulliExpectation edges (fun _ => 0) f n = f ∅ := by
  induction n with
  | zero => rfl
  | succ n ih => simp [bernoulliExpectation_succ, ih]

theorem nonmonotone_bernoulli_scaling (edges : ℕ → E) (q : ℕ → ℝ) (f : Finset E → ℝ)
    (n : ℕ) (hf : IsSubmodular f) (hf0 : 0 ≤ f ∅)
    (hinj : ∀ i < n, ∀ j < n, edges i = edges j → i = j)
    (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1) (t : ℝ) (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    t * bernoulliExpectation edges q f n ≤ bernoulliExpectation edges (fun i => t*q i) f n := by
  have h := bernoulli_comparable_concavity edges (fun _ => 0) q f n hf hinj
    (fun i hi => ⟨le_rfl, hq i hi⟩) t ht0 ht1
  simp only [bernoulli_zero_coordinates, mul_zero, zero_add] at h
  linarith only [h, mul_nonneg (sub_nonneg.mpr ht1) hf0]

/-- Adding independent elements with inclusion probabilities at most p
preserves at least a (1-p) fraction of any fixed base value. -/
theorem signed_augmentation_of_sparse_product (edges : ℕ → E) (q : ℕ → ℝ)
    (f : Finset E → ℝ) (T : Finset E) (n : ℕ) (hf : IsSubmodular f)
    (hpos : ∀ A, 0 ≤ f A) (hinj : ∀ i < n, ∀ j < n, edges i = edges j → i = j)
    (p : ℝ) (hp : 0 < p) (hp1 : p ≤ 1) (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ p) :
    (1-p)*f T ≤ bernoulliExpectation edges q (fun A => f (A ∪ T)) n := by
  let r := fun i => q i / p
  have hr (i : ℕ) (hi : i < n) : 0 ≤ r i ∧ r i ≤ 1 := by
    exact ⟨div_nonneg (hq i hi).1 hp.le, (div_le_one hp).2 (hq i hi).2⟩
  have hc := bernoulli_comparable_concavity edges (fun _ => 0) r
    (fun A => f (A ∪ T)) n (submodular_union_fixed f hf T) hinj
    (fun i hi => ⟨le_rfl, hr i hi⟩) p hp.le hp1
  have hnon := bernoulliExpectation_nonnegative edges r (fun A => f (A ∪ T)) n hr
    (fun A => hpos (A ∪ T))
  have hid := NonmonotoneOptimizer.expectation_congr edges (fun i => p*r i) q
    (fun A => f (A ∪ T)) n (fun i _ => by dsimp [r]; field_simp [hp.ne'])
  simp only [bernoulli_zero_coordinates, Finset.empty_union, mul_zero, zero_add] at hc
  rw [hid] at hc
  linarith only [hc, mul_nonneg hp.le hnon]

/-- Bounded extra inclusion probabilities preserve a fraction of the independent
value, even when the submodular function has negative marginals. -/
theorem nonmonotone_bernoulli_calibration (edges : ℕ → E) (q m : ℕ → ℝ)
    (f : Finset E → ℝ) (n : ℕ) (hf : IsSubmodular f) (hpos : ∀ A, 0 ≤ f A)
    (hinj : ∀ i < n, ∀ j < n, edges i = edges j → i = j)
    (hq : ∀ i < n, 0 ≤ q i ∧ q i ≤ 1) (t h : ℝ) (ht0 : 0 ≤ t) (ht1 : t ≤ 1)
    (hh0 : 0 ≤ h) (hh1 : h < 1)
    (hcoord : ∀ i < n, t*q i ≤ m i ∧ m i ≤ h) :
    (1-h)*t*bernoulliExpectation edges q f n ≤ bernoulliExpectation edges m f n := by
  let x := fun i => t*q i
  have hx (i : ℕ) (hi : i < n) : 0 ≤ x i := mul_nonneg ht0 (hq i hi).1
  have hscale := nonmonotone_bernoulli_scaling edges q f n hf (hpos ∅) hinj hq t ht0 ht1
  rcases hh0.eq_or_lt with hh | hh
  · subst h
    have hident := NonmonotoneOptimizer.expectation_congr edges x m f n (fun i hi =>
      le_antisymm (hcoord i hi).1 ((hcoord i hi).2.trans (hx i hi)))
    simpa only [sub_zero, one_mul] using hscale.trans hident.le
  · let y := fun i => x i + (m i - x i) / h
    have hbounds (i : ℕ) (hi : i < n) : 0 ≤ x i ∧ x i ≤ y i ∧ y i ≤ 1 := by
      have hxm := (hcoord i hi).1
      change x i ≤ m i at hxm
      refine ⟨hx i hi, le_add_of_nonneg_right (div_nonneg (sub_nonneg.mpr hxm) hh.le), ?_⟩
      change x i + (m i - x i) / h ≤ 1
      have hdiv : (m i - x i) / h ≤ 1 - x i := (div_le_iff₀ hh).2 (by
        nlinarith only [(hcoord i hi).2, mul_nonneg (hx i hi) (sub_nonneg.mpr hh1.le)])
      linarith
    have hmix := bernoulli_comparable_concavity edges x y f n hf hinj hbounds h hh.le hh1.le
    have hid := NonmonotoneOptimizer.expectation_congr edges
      (fun i => (1-h)*x i+h*y i) m f n (fun i _ => by dsimp [y]; field_simp [hh.ne']; ring)
    rw [hid] at hmix
    have hfy := bernoulliExpectation_nonnegative edges y f n
      (fun i hi => ⟨(hx i hi).trans (hbounds i hi).2.1, (hbounds i hi).2.2⟩) hpos
    have hs := mul_le_mul_of_nonneg_left hscale (sub_nonneg.mpr hh1.le)
    change (1-h)*(t*bernoulliExpectation edges q f n) ≤ (1-h)*bernoulliExpectation edges x f n at hs
    rw [mul_assoc]
    exact hs.trans ((le_add_of_nonneg_right (mul_nonneg hh.le hfy)).trans hmix)

end
end SubmodularMatching
