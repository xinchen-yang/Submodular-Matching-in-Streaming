import SubmodularMatching.NonmonotoneArrivalBankSupport
import SubmodularMatching.CapacitySignedWorkspace
import SubmodularMatching.CapacityArrivalCache

/-! Empty admissible streams keep just the initialized headers, even when
the original stream visits edges incident to zero-capacity vertices. -/
namespace SubmodularMatching.Capacity
open AppendixM RealOracle UpperBoundAssembly Streaming
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

theorem nonmonotone_empty_prefix_workspace (S : SimpleEdgeStream E V) (b : V → ℕ)
    (f : Finset E → ℝ) (δ : ℝ) (xs : List E) (he : ¬ Nonempty (Admissible S b))
    (cache : CapacityCache V) (hc : CacheValid b cache)
    (z : RealOracle.GuessBank (SparseSlots (Admissible S b) (effectiveCapacity b)) ×
      (Option (Admissible S b) × ℝ))
    (hz : z ∈ (signedArrivalBank S b f δ xs).outcomes) :
    let n := Fintype.card V
    2*cache.length≤2*n ∧
    RealOracle.bankCells z.1 + frozenCells (effectiveCapacity b) z.1 + 16 ≤
      (20+3*signedGuessCountConstant)*((n+1).log2+1) := by
  classical
  intro n
  let cap := effectiveCapacity b
  let v := n^2
  let span := guessSpan v
  let F := fun a => f (originalLabels S b a)
  let fresh : SparseSlots (Admissible S b) cap := sparseEmpty cap
  let seed := RealOracle.GuessBank.empty.advance fresh (guessWidth v) span (F ∅) (fun _ _ st => st)
  have hh : xs.filterMap (keepPositive S.ends (clipped b))=[] :=
    List.eq_nil_iff_forall_not_mem.mpr (fun e _ => he ⟨e⟩)
  unfold signedArrivalBank at hz
  rw [CandidateLaw.onFilteredArrivals_eq,hh,CandidateLaw.onArrivals] at hz
  change z ∈ ({(seed,(none,F ∅))} : Finset _) at hz
  obtain rfl := Finset.mem_singleton.mp hz
  let ep := RealSource.OnlineEpoch.empty.step (guessWidth v) span (F ∅)
  have hstates : seed.states = (ep.active (guessWidth v) span).map (fun j => (j,fresh)) := by
    dsimp only [seed,RealOracle.GuessBank.advance,ep]
    congr 1
    funext j
    congr 1
    split <;> rfl
  have hp : payloadCells fresh=1 := rfl
  have ht := RealOracle.GuessBank.state_count (RealOracle.GuessBank.empty : RealOracle.GuessBank (SparseSlots (Admissible S b) cap))
    fresh (guessWidth v) span (F ∅) (fun _ _ st => st)
  change seed.states.length≤span+1 at ht
  rw [hstates,List.length_map] at ht
  have frozen : frozenCells cap seed=0 := by
    simp [frozenCells,hstates,List.map_map,Function.comp_def,fresh,sparseEmpty,OnlineInstance.empty]
  have header : RealOracle.bankCells seed=4+(ep.active (guessWidth v) span).length := by
    simp [RealOracle.bankCells,hstates,List.map_map,Function.comp_def,hp]
  have hG := (ht.trans (signedGuessCount_le v)).trans
    (Nat.mul_le_mul_left signedGuessCountConstant (squared_log_width n))
  have hw : 1≤(n+1).log2+1 := Nat.le_add_left _ _
  refine ⟨capacityCache_words b cache hc,?_⟩
  rw [header,frozen]
  nlinarith only [hG,hw]

end
end SubmodularMatching.Capacity
