import SubmodularMatching.PrefixOracle
import SubmodularMatching.MemoryRecovery
import SubmodularMatching.CloneLiftRecovery
import SubmodularMatching.WithoutReplacement
import SubmodularMatching.BlockSampling

/-!
# Information bounds with the actual oracle and simple clone graph

These theorems connect the structural lower-bound components: adaptive prefix
queries, hidden public labels, arbitrary finite memory, fixed-size sampling,
indistinguishability, rarity, and clone matching multiplicity.
-/

namespace SubmodularMatching.LowerBoundInformation

open scoped BigOperators

noncomputable section

/-- Vary the current stage's hidden label while fixing every earlier label. -/
def markLabel {E L : Type*} [DecidableEq L]
    (stage : E → ℕ) (cutoff : ℕ) (earlier : E → Bool) (publicLabel : E → L)
    (hidden : L) (e : E) : Bool :=
  if stage e = cutoff then decide (publicLabel e = hidden) else earlier e

theorem markLabel_earlier {E L : Type*} [DecidableEq L]
    (stage : E → ℕ) (cutoff : ℕ) (earlier : E → Bool) (publicLabel : E → L)
    (l₁ l₂ : L) (e : E) (he : stage e < cutoff) :
    markLabel stage cutoff earlier publicLabel l₁ e =
      markLabel stage cutoff earlier publicLabel l₂ e := by
  simp only [markLabel, if_neg (Nat.ne_of_lt he)]

/-- The actual memory state produced by an arbitrary adaptive prefix program. -/
def prefixState {Ω E L Y : Type*} [DecidableEq L]
    (unit : ℝ) (stage : E → ℕ) (cutoff start count : ℕ)
    (earlier : E → Bool) (publicLabel : E → L)
    (program : Ω → PrefixOracle.Program (PrefixOracle.Query stage cutoff) Y)
    (hidden : L) (ω : Ω) : Y :=
  PrefixOracle.Program.run
    (PrefixOracle.oracle unit stage (markLabel stage cutoff earlier publicLabel hidden)
      start count cutoff)
    (program ω)

/-- The entire adaptive memory state, not merely its explicit retained edges,
is independent of the current stage's hidden label. -/
theorem prefixState_invariant {Ω E L Y : Type*} [DecidableEq L]
    (unit : ℝ) (hunit : 0 ≤ unit) (stage : E → ℕ) (cutoff start count : ℕ)
    (earlier : E → Bool) (publicLabel : E → L)
    (program : Ω → PrefixOracle.Program (PrefixOracle.Query stage cutoff) Y)
    (l₁ l₂ : L) (ω : Ω) :
    prefixState unit stage cutoff start count earlier publicLabel program l₁ ω =
      prefixState unit stage cutoff start count earlier publicLabel program l₂ ω := by
  exact PrefixOracle.adaptive_state_label_invariance unit hunit stage _ _ start count cutoff
    (markLabel_earlier stage cutoff earlier publicLabel l₁ l₂) (program ω)

/-- The expected distinguished output bound with label independence derived
from the actual recursive oracle and arbitrary adaptive prefix computations. -/
theorem adaptive_distinguished_recovery_le {Ω E L Y : Type*}
    [Fintype Ω] [Finite E] [DecidableEq E] [Fintype L] [DecidableEq L]
    [Fintype Y] [Nonempty Y]
    (μ : Ω → ℝ) (X : Ω → Finset E)
    (unit : ℝ) (hunit : 0 ≤ unit) (stage : E → ℕ) (cutoff start count : ℕ)
    (earlier : E → Bool) (publicLabel : E → L)
    (program : Ω → PrefixOracle.Program (PrefixOracle.Query stage cutoff) Y)
    (reference : L) (continuation : Y → L → Finset E)
    (q : ℝ) (s : ℕ) (hμ : ∀ ω, 0 ≤ μ ω) (hμsum : ∑ ω, μ ω = 1)
    (hq0 : 0 < q) (hq1 : q < 1)
    (hinclusion : ∀ A : Finset E,
      (∑ ω, if A ⊆ X ω then μ ω else 0) ≤ q ^ A.card)
    (hstates : Fintype.card Y ≤ 2 ^ s)
    (hvalid : ∀ ω, 0 < μ ω → ∀ l,
      continuation (prefixState unit stage cutoff start count earlier publicLabel program l ω)
        l ⊆ X ω) :
    (∑ ω, μ ω * ((∑ l,
      (((continuation (prefixState unit stage cutoff start count earlier publicLabel program l ω)
        l).filter (fun e => publicLabel e = l)).card : ℝ)) / Fintype.card L)) ≤
      s / ((Fintype.card L : ℝ) * Real.logb 2 (1 / q)) := by
  letI : Nonempty L := ⟨reference⟩
  have hi := prefixState_invariant unit hunit stage cutoff start count earlier publicLabel program
  have hv : ∀ ω, 0 < μ ω → ∀ l,
      continuation (prefixState unit stage cutoff start count earlier publicLabel program
        reference ω)
        l ⊆ X ω := by
    intro ω hω l
    simpa only [hi l reference ω] using hvalid ω hω l
  simp_rw [hi _ reference]
  exact Information.expected_distinguished_recovery_le μ X _ publicLabel continuation q s
    hμ hμsum hq0 hq1 hinclusion hstates hv

/-- Actual uniform fixed-size sampling gives the preceding adaptive bound
without an assumed inclusion-probability inequality. -/
theorem uniform_adaptive_distinguished_recovery_le {E L Y : Type*}
    [Fintype E] [DecidableEq E] [Fintype L] [DecidableEq L]
    [Fintype Y] [Nonempty Y]
    (U : Finset E) (k : ℕ) (hk0 : 0 < k) (hk1 : k < U.card)
    (unit : ℝ) (hunit : 0 ≤ unit) (stage : E → ℕ) (cutoff start count : ℕ)
    (earlier : E → Bool) (publicLabel : E → L)
    (program : Finset E → PrefixOracle.Program (PrefixOracle.Query stage cutoff) Y)
    (reference : L) (continuation : Y → L → Finset E) (s : ℕ)
    (hstates : Fintype.card Y ≤ 2 ^ s)
    (hvalid : ∀ S, 0 < Information.uniformSubsetMass U k S → ∀ l,
      continuation (prefixState unit stage cutoff start count earlier publicLabel program l S)
        l ⊆ S) :
    (∑ S, Information.uniformSubsetMass U k S * ((∑ l,
      (((continuation (prefixState unit stage cutoff start count earlier publicLabel program l S)
        l).filter (fun e => publicLabel e = l)).card : ℝ)) / Fintype.card L)) ≤
      s / ((Fintype.card L : ℝ) * Real.logb 2 (1 / ((k : ℝ) / U.card))) := by
  have hU : 0 < U.card := hk0.trans hk1
  have hUR : (0 : ℝ) < U.card := by exact_mod_cast hU
  exact adaptive_distinguished_recovery_le (Information.uniformSubsetMass U k) id
    unit hunit stage cutoff start count earlier publicLabel program reference continuation
    ((k : ℝ) / U.card) s (Information.uniformSubsetMass_nonneg U k)
    (Information.sum_uniformSubsetMass U k hk1.le)
    (div_pos (by exact_mod_cast hk0) hUR)
    ((div_lt_one hUR).2 (by exact_mod_cast hk1))
    (fun A => Information.uniformSubsetMass_inclusion_le U A k hU hk1.le) hstates hvalid

/-- Independent fixed-size edge blocks, as used for the clone samples. This
full adaptive bound has no assumed inclusion estimate or label-independence
condition: both are proved from the product distribution and recursive oracle. -/
theorem block_adaptive_distinguished_recovery_le {I E L Y : Type*}
    [Fintype I] [DecidableEq I] [Fintype E] [DecidableEq E]
    [Fintype L] [DecidableEq L] [Fintype Y] [Nonempty Y]
    (U : I → Finset E) (k : I → ℕ) (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (hU : ∀ i, 0 < (U i).card) (hk : ∀ i, k i ≤ (U i).card)
    (hrate : ∀ i, (k i : ℝ) / (U i).card ≤ q)
    (unit : ℝ) (hunit : 0 ≤ unit) (stage : I × E → ℕ) (cutoff start count : ℕ)
    (earlier : I × E → Bool) (publicLabel : I × E → L)
    (program : (I → Finset E) → PrefixOracle.Program (PrefixOracle.Query stage cutoff) Y)
    (reference : L) (continuation : Y → L → Finset (I × E)) (s : ℕ)
    (hstates : Fintype.card Y ≤ 2 ^ s)
    (hvalid : ∀ S, 0 < Information.independentSubsetMass U k S → ∀ l,
      continuation (prefixState unit stage cutoff start count earlier publicLabel program l S)
        l ⊆ Information.taggedSample S) :
    (∑ S, Information.independentSubsetMass U k S * ((∑ l,
      (((continuation (prefixState unit stage cutoff start count earlier publicLabel program l S)
        l).filter (fun e => publicLabel e = l)).card : ℝ)) / Fintype.card L)) ≤
      s / ((Fintype.card L : ℝ) * Real.logb 2 (1 / q)) := by
  exact adaptive_distinguished_recovery_le (Information.independentSubsetMass U k)
    Information.taggedSample unit hunit stage cutoff start count earlier publicLabel
    program reference continuation q s (Information.independentSubsetMass_nonneg U k)
    (Information.sum_independentSubsetMass U k hk) hq0 hq1
    (Information.independentSubsetMass_inclusion_le U k q hU hk hrate) hstates hvalid

/-- The rare-base-pair bound for an actual clone matching: multiplicity is
proved from matching feasibility and equals at most the number of clones. -/
theorem expected_special_clone_edges_le {Ω Y H L R C : Type*}
    [Fintype Ω] [Fintype Y] [Nonempty Y] [Fintype H]
    [Finite L] [Finite R] [DecidableEq L] [DecidableEq R]
    [Fintype C]
    (μ : Ω → ℝ) (X : Ω → Finset (L × R)) (state : Ω → Y)
    (ν : H → ℝ) (special : H → L × R → Prop) [∀ h, DecidablePred (special h)]
    (output : Y → H → Finset ((L × C) × (R × C))) (ρ q : ℝ) (s : ℕ)
    (hμ : ∀ ω, 0 ≤ μ ω) (hμsum : ∑ ω, μ ω = 1)
    (hν : ∀ h, 0 ≤ ν h) (hρ : 0 ≤ ρ)
    (hq0 : 0 < q) (hq1 : q < 1)
    (hinclusion : ∀ A : Finset (L × R),
      (∑ ω, if A ⊆ X ω then μ ω else 0) ≤ q ^ A.card)
    (hstates : Fintype.card Y ≤ 2 ^ s)
    (hrarity : ∀ e, (∑ h, if special h e then ν h else 0) ≤ ρ)
    (hmatching : ∀ y h, CloneLift.IsMatching (output y h))
    (hvalid : ∀ ω, 0 < μ ω → ∀ h,
      (output (state ω) h).image CloneLift.basePair ⊆ X ω) :
    (∑ ω, μ ω * (∑ h, ν h *
      (((output (state ω) h).filter (fun e => special h (CloneLift.basePair e))).card : ℝ))) ≤
        Fintype.card C * (ρ * (s / Real.logb 2 (1 / q))) := by
  have hbase := Information.expected_rare_recovery_le μ X state ν special
    (fun y h => (output y h).image CloneLift.basePair) ρ q s
    hμ hμsum hν hρ hq0 hq1 hinclusion hstates hrarity hvalid
  calc
    _ ≤ ∑ ω, μ ω * (∑ h, ν h * (Fintype.card C *
      ((((output (state ω) h).image CloneLift.basePair).filter (special h)).card : ℝ))) := by
      apply Finset.sum_le_sum
      intro ω _
      apply mul_le_mul_of_nonneg_left _ (hμ ω)
      apply Finset.sum_le_sum
      intro h _
      apply mul_le_mul_of_nonneg_left _ (hν h)
      exact_mod_cast CloneLift.matching_special_card_le (output (state ω) h)
        (hmatching (state ω) h) (special h)
    _ = Fintype.card C * (∑ ω, μ ω * (∑ h, ν h *
      ((((output (state ω) h).image CloneLift.basePair).filter (special h)).card : ℝ))) := by
      simp only [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro ω _
      apply Finset.sum_congr rfl
      intro h _
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hbase (Nat.cast_nonneg _)

end

end SubmodularMatching.LowerBoundInformation
