import SubmodularMatching.ProjectedShearerThinning
import SubmodularMatching.ProjectedShearerCappedSampler

/-! # Downward dyadic quantization of implicit slot marginals -/

namespace SubmodularMatching.Shearer
open GibbsMatching GibbsSampler
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

private theorem thin_nonneg (p : E → ℝ) (hp : ∀ e, p e ∈ Set.Icc 0 1) (f : Finset E → ℝ)
    (h0 : ∀ A, 0 ≤ f A) (es : List E) (A : Finset E) : 0 ≤ thinList p es f A := by
  induction es generalizing A with
  | nil => exact h0 _
  | cons e es ih => exact add_nonneg (mul_nonneg (sub_nonneg.mpr (hp e).2) (ih _)) (mul_nonneg (hp e).1 (ih _))

private theorem thin_event_loss (p : E → ℝ) (hp : ∀ e, p e ∈ Set.Icc 0 1)
    (f : Finset E → ℝ) (hf : ∀ A, f A ∈ Set.Icc 0 1) (es : List E) (hn : es.Nodup) (A : Finset E) :
    f A ≤ thinList p es f A + ∑ e ∈ es.toFinset, if e ∈ A then 1-p e else 0 := by
  induction es generalizing A with
  | nil => simp [thinList]
  | cons e es ih =>
    let err (A : Finset E) := ∑ j ∈ es.toFinset, if j ∈ A then 1-p j else 0
    have htail : f A ≤ thinList p es f A + err A := ih (List.nodup_cons.mp hn).2 A
    have hi := (List.nodup_cons.mp hn).1
    have he : e ∉ es.toFinset := by simpa using hi
    rw [List.toFinset_cons,Finset.sum_insert he]
    by_cases hem : e ∈ A
    · have he0 : 0 ≤ err A := Finset.sum_nonneg (fun a _ => by split_ifs; exact sub_nonneg.mpr (hp a).2; exact le_rfl)
      have one : (1-p e)*f A ≤ (1-p e)*1 := mul_le_mul_of_nonneg_left (hf A).2 (sub_nonneg.mpr (hp e).2)
      have tail := mul_le_mul_of_nonneg_left htail (hp e).1
      have cerr := mul_le_mul_of_nonneg_right (hp e).2 he0
      have hdel := mul_nonneg (sub_nonneg.mpr (hp e).2) (thin_nonneg p hp f (fun M => (hf M).1) es (A.erase e))
      rw [if_pos hem]
      change f A ≤ (1-p e)*thinList p es f (A.erase e) + p e*thinList p es f A + ((1-p e)+err A)
      linarith only [one,tail,cerr,hdel]
    · rw [if_neg hem]
      change f A ≤ (1-p e)*thinList p es f (A.erase e) + p e*thinList p es f A + (0+err A)
      rw [Finset.erase_eq_of_notMem hem]
      linarith only [htail]

/-- Coordinate-wise thinning loses at most the expected number of erased
coordinates, directly in total variation for the actual finite law. -/
theorem thinning_variation (ends : E → Finset V) (S : Finset E) (x : E → ℝ) (hx : InteriorLaw ends S x)
    (p : E → ℝ) (hp : ∀ e, p e ∈ Set.Icc 0 1) (hy : InteriorLaw ends S (fun e => p e*x e)) :
    variation Finset.univ (Shearer.probability ends S x) (Shearer.probability ends S (fun e => p e*x e)) ≤
      ∑ e ∈ S, (1-p e)*x e := by
  let y := fun e => p e*x e
  let P := mass ends S x
  let R := mass ends S y
  let event (M : Finset E) := if R M ≤ P M then (1:ℝ) else 0
  let U := matchings ends S
  have iP : IsProbability U P := ⟨hx.nonneg,mass_total ends S x⟩
  have iR : IsProbability U R := ⟨hy.nonneg,mass_total ends S y⟩
  have ev (M : Finset E) : event M ∈ Set.Icc 0 1 := by unfold event; split_ifs <;> norm_num
  have hvar := variation_eq_event_difference U P R iP iR
  have hpoint (M : Finset E) := thin_event_loss p hp event ev S.toList S.nodup_toList M
  have he := hx.expectation_le (fun M _ => hpoint M)
  have hp_sum : expectation ends S x (fun M => ∑ e ∈ S, if e ∈ M then 1-p e else 0) = ∑ e ∈ S, (1-p e)*x e := by
    rw [expectation_sum ends S x S (fun e M => if e ∈ M then 1-p e else 0)]
    apply Finset.sum_congr rfl
    intro e heS
    rw [expectation_present ends S x e heS (fun _ => 1-p e),expectation_const,mul_comm]
  have hslist : S.toList.toFinset = S := by ext; simp
  simp only [hslist,expectation_add,hp_sum,thinSupport_law] at he
  change expectation ends S x event ≤ expectation ends S y event + _ at he
  have hs : variation U P R ≤ ∑ e ∈ S, (1-p e)*x e := by
    change variation U P R = expectation ends S x event - expectation ends S y event at hvar
    linarith only [hvar,he]
  unfold variation at hs ⊢
  have eqsum := Finset.sum_coe_sort U (fun M => |P M - R M|)
  exact (div_le_div_of_nonneg_right eqsum.le (by norm_num : (0:ℝ)≤2)).trans hs

end SubmodularMatching.Shearer
