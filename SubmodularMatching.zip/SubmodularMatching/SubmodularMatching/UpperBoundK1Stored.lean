import SubmodularMatching.UpperBoundK1Settings
import SubmodularMatching.UpperBoundK1OptimizerGrid
import SubmodularMatching.UpperBoundK1Sampled
import SubmodularMatching.UpperBoundReindex

/-! # Generic optimization and finite rounding on a recorded guess -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint Streaming TwoStage SourceCertificate GibbsSampler LinearPacking
open scoped BigOperators

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]
variable {m N : ℕ}

namespace K1Parameters

variable (a : K1Parameters)

def rationalDegree : ℚ := a.r * (1 - a.r)

theorem rationalDegree_cast : (a.rationalDegree : ℝ) = a.degree := by
  unfold rationalDegree
  push_cast
  rfl

def eulerDenominator (m vertices : ℕ) : ℕ :=
  k1EulerDenominator a.p a.rationalDegree a.k m vertices

theorem eulerDenominator_pos (hm : 0 < m) (vertices : ℕ) :
    0 < a.eulerDenominator m vertices :=
  k1EulerDenominator_pos _ _ _ a.k_large hm _

theorem physicalPoint_grid {W : Type*} [Fintype W] [DecidableEq W] (hm : 0 < m)
    (tau : ℝ) (ends : Fin m → W × W) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ)
    (Q : ℕ) (draw : AppendixDraw m N) (i : Fin m) :
    let d := a.eulerDenominator m (Fintype.card W)
    let t := k1PhysicalPoint a.optimizerSettings tau ends w f Q draw
    OnGrid d (t.1 i) ∧ OnGrid d (t.2 i) := by
  have h := k1EulerPoint_grid a.p a.rationalDegree a.k a.k_large hm tau ends w f Q draw
    (FiniteGreedy.stages (a.rationalDegree : ℝ) m a.error) i
  dsimp only at h
  dsimp only [eulerDenominator, k1PhysicalPoint, k1PhysicalOfNormalizedPoint, optimizerSettings]
  rw [a.rationalDegree_cast] at h
  exact h

end K1Parameters

omit [DecidableEq E] in
theorem k1_restrictEnds_simple (emb : Fin m ↪ E) (ends : E → V × V)
    (hsimple : Function.Injective (pairEnds ends)) :
    Function.Injective (pairEnds (restrictEnds (ends ∘ emb))) :=
  (restrictEnds_pairEnds_injective_iff (ends ∘ emb)).mpr (fun _ _ h => emb.injective (hsimple h))

/-- Work on the incident vertices of the actual stored edges and map the
selected matching back to its original edge identifiers. -/
def k1CompactGuessFromPoint (a : K1Parameters) (hm : 0 < m) (emb : Fin m ↪ E)
    (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends))
    (point : Fin m ⊕ Fin m → ℝ) :
    CandidateLaw (Finset E) :=
  let d := a.eulerDenominator m (Fintype.card (IncidentVertex (ends ∘ emb)))
  let hd := a.eulerDenominator_pos hm (Fintype.card (IncidentVertex (ends ∘ emb)))
  (k1CandidateFromPoint a.optimizerSettings a.roundingSettings hm (restrictEnds (ends ∘ emb))
    (restrictEnds_loopless (ends ∘ emb) (fun i => hloop (emb i)))
    (k1_restrictEnds_simple emb ends hsimple) a.roundingSettings_cap
    (k1PhysicalOfNormalizedPoint a.optimizerSettings point) d d hd hd).map (Finset.map emb)

def k1CompactGuessCandidate (a : K1Parameters) (hm : 0 < m) (tau : ℝ) (emb : Fin m ↪ E)
    (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends))
    (w : E → ℝ) (f : Finset E → ℝ) (Q : ℕ) (draw : AppendixDraw m N) :
    CandidateLaw (Finset E) :=
  let point := sampledPoint (a.p : ℝ) a.degree tau a.error (restrictEnds (ends ∘ emb)) (w ∘ emb)
    (oracleCoefficient a.degree tau a.error Q (reindexedObjective emb f) draw)
    (FiniteGreedy.stages a.degree m a.error)
  k1CompactGuessFromPoint a hm emb ends hloop hsimple point

theorem k1CompactGuessFromPoint_feasible (a : K1Parameters) (hm : 0 < m)
    (emb : Fin m ↪ E) (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends))
    (point : Fin m ⊕ Fin m → ℝ)
    (edges : Finset E) (he : Finset.univ.map emb ⊆ edges) :
    (k1CompactGuessFromPoint a hm emb ends hloop hsimple point).outcomes ⊆
      GibbsMatching.matchings (endpointSet ends) edges := by
  intro M hM
  unfold k1CompactGuessFromPoint CandidateLaw.map at hM
  obtain ⟨A, hA, rfl⟩ := Finset.mem_image.mp hM
  let d := a.eulerDenominator m (Fintype.card (IncidentVertex (ends ∘ emb)))
  let hd := a.eulerDenominator_pos hm (Fintype.card (IncidentVertex (ends ∘ emb)))
  have ha : IsMatchingOn (pairEnds (ends ∘ emb)) A :=
    (restrictEnds_isMatchingOn_iff (ends ∘ emb) A).mp
      (k1CandidateFromPoint_feasible a.optimizerSettings a.roundingSettings hm
        (restrictEnds (ends ∘ emb)) (restrictEnds_loopless (ends ∘ emb) (fun i => hloop (emb i)))
        (k1_restrictEnds_simple emb ends hsimple) a.roundingSettings_cap
        (k1PhysicalOfNormalizedPoint a.optimizerSettings point) d d hd hd A hA)
  apply (GibbsMatching.mem_matchings _ _ _).2
  refine ⟨(Finset.map_subset_map.mpr (Finset.subset_univ _)).trans he, ?_⟩
  intro e he d hd hne
  obtain ⟨i, hi, rfl⟩ := Finset.mem_map.mp he
  obtain ⟨j, hj, rfl⟩ := Finset.mem_map.mp hd
  exact ha hi hj (fun hij => hne (congrArg emb hij))

theorem k1CompactGuessCandidate_feasible (a : K1Parameters) (hm : 0 < m) (tau : ℝ)
    (emb : Fin m ↪ E) (ends : E → V × V) (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends))
    (w : E → ℝ) (f : Finset E → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (edges : Finset E) (he : Finset.univ.map emb ⊆ edges) :
    (k1CompactGuessCandidate a hm tau emb ends hloop hsimple w f Q draw).outcomes ⊆
      GibbsMatching.matchings (endpointSet ends) edges :=
  k1CompactGuessFromPoint_feasible a hm emb ends hloop hsimple _ edges he

variable [Fintype E] [Fintype V]

/-- FJ4 and FJ6 apply to the same compressed stored order and conservative
weights, which are then consumed by the exact finite word samplers. -/
theorem k1CompactGuessCandidate_value (a : K1Parameters) (C : PotentialConfig)
    (cert : RunSourceConditions a.source C a.degree a.sigma (a.rates.maxTotal : ℝ))
    (hprob : C.p = (a.p : ℝ)) (ends : E → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends)) (hv : 0 < Fintype.card V)
    (hE : 0 < Fintype.card E)
    (input : ℕ → E × ℝ) (n : ℕ)
    (hunique : ∀ i < n, ∀ j < n, (input i).1 = (input j).1 → i = j)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hmf : IsMonotone f) (hzero : f ∅ = 0)
    (B : ℝ) (hB : 0 ≤ B) (hBtau : B ≤ C.tau) (hsingle : ∀ e, f {e} ≤ B)
    (w : E → ℝ) (hw : ∀ e, 0 ≤ w e ∧ w e ≤ C.tau)
    (hrecord : ∀ i < n, (input i).2 = w (input i).1)
    (haccurate : ∀ i < n, (input i).2 ≤ traceWeight C ends input f i)
    (hm : 0 < m) (emb : Fin m ↪ E)
    (hS : Finset.univ.map emb = (runPotential C ends input n).stored)
    (hcount : m = (acceptedOrder C ends input n).length)
    (horder : ∀ i < m, emb (enumerateEdge hm i) =
      (acceptedOrder C ends input n).getD i (input 0).1)
    (O : Finset (Fin m)) (hO : IsMatchingOn (pairEnds (ends ∘ emb)) O)
    (I : V → Bool) (hI : ∀ v, bit (I v) = coveredIndicator (ends ∘ emb) O v)
    (Q : ℕ) (hQ : 0 < Q) (draw : AppendixDraw m N)
    (hgrid : (FiniteGreedy.stages a.degree m a.error : ℝ) / Q ≤
      FiniteGreedy.accuracy a.degree m a.error / 2)
    (hmean : k1OptimizerAccurate a.optimizerSettings hm C.tau (restrictEnds (ends ∘ emb))
      (w ∘ emb) (reindexedObjective emb f) Q draw) :
    let X := C.p * ((runPotential C ends input n).stored.sum w) +
      ∑ v, unmatched (I v) * idealPotential C ends input n v
    let g := traceResidual C ends input f n (O.map emb)
    let q := k1CompactGuessCandidate a hm C.tau emb ends hloop hsimple w f Q draw
    a.theta * (a.sigma * X + (a.beta : ℝ) * g - (5 / 8) * a.error * C.tau) - a.error * B / 4 ≤
      expected q.outcomes q.mass f := by
  intro X g q
  let ep := restrictEnds (ends ∘ emb)
  let F := reindexedObjective emb f
  let w' := w ∘ emb
  let d := a.eulerDenominator m (Fintype.card (IncidentVertex (ends ∘ emb)))
  let hd := a.eulerDenominator_pos hm (Fintype.card (IncidentVertex (ends ∘ emb)))
  have hD2 : 2 * a.degree < 1 := by linarith only [a.degree_lt_quarter]
  have hpD : C.p ≤ 1 - a.degree := hprob ▸ a.probability_le_one_sub_degree
  have hlo : ∀ i, (ep i).1 ≠ (ep i).2 :=
    restrictEnds_loopless (ends ∘ emb) (fun i => hloop (emb i))
  have hsi : Function.Injective (pairEnds ep) := k1_restrictEnds_simple emb ends hsimple
  have hOc : IsMatchingOn (pairEnds ep) O := (restrictEnds_isMatchingOn_iff (ends ∘ emb) O).mpr hO
  obtain ⟨hsource, hwCompact, hres⟩ := fixed_guess_comparator_and_weights C a.source a.degree
    a.sigma a.rates.maxTotal cert a.degree_pos.le hD2 hpD hv hE ends hloop input n hunique
    f w hw hrecord haccurate hm emb hS hcount horder O hO I hI
  have hsrc : a.sigma * X ≤ sSup (comparisonValues a.optimizerSettings.p a.degree ep w' O) := by
    change _ ≤ sSup (comparisonValues (a.p : ℝ) a.degree (restrictEnds (ends ∘ emb)) w' O)
    rw [← hprob, comparisonValues_restrictEnds C.p a.degree a.degree_pos.le]
    exact hsource
  rw [hprob] at hwCompact hres
  have hf0 : F ∅ = 0 := by simp [F, reindexedObjective, hzero]
  have hs : ∀ e, F {e} ≤ B := fun e => by simpa [F, reindexedObjective] using hsingle (emb e)
  have hgrids (i : Fin m) :=
    a.physicalPoint_grid hm C.tau ep w' F Q draw i
  have h := k1SampledCandidate_value a.optimizerSettings a.roundingSettings a.roundingSettings_degree
    a.roundingSettings_epsilon hm C.tau a.beta (a.sigma * X) B a.probability_pos
    (C.theta_pos.trans_le C.theta_le_tau) hB hBtau ep hlo hsi a.roundingSettings_cap w'
    (fun i => hw (emb i)) F (reindexedObjective_submodular emb f hf)
    (reindexedObjective_monotone emb f hmf) hf0 hs hwCompact O hOc hsrc a.beta_le Q hQ draw
    hgrid hmean d d hd hd (fun i => (hgrids i).1) (fun i => (hgrids i).2)
  dsimp only at h
  rw [a.roundingSettings_error] at h
  change a.theta * (a.sigma * X + (a.beta : ℝ) *
    residualValue (enumerateEdge hm) (a.p : ℝ) F m O - (5 / 8) * a.error * C.tau) -
      a.error * B / 4 ≤ _ at h
  rw [hres] at h
  dsimp only [q, k1CompactGuessCandidate, k1CompactGuessFromPoint]
  rw [CandidateLaw.map_expected]
  exact h

end

end SubmodularMatching.UpperBoundAssembly
