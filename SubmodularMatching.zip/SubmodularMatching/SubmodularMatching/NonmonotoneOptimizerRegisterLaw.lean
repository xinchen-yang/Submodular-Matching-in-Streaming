import SubmodularMatching.NonmonotoneOptimizerRoundExecution
import SubmodularMatching.UpperBoundFiniteExecution

/-! The finite optimizer distribution can be run with fresh round words and two iterate registers. -/
namespace SubmodularMatching.NonmonotoneOptimizer.BlockData
open Streaming MeasureTheory UpperBoundAssembly GibbsSampler
noncomputable section
variable {E : Type*} [DecidableEq E] {m n l rows s bits : ℕ} [NeZero n] (B : BlockData E n l)
variable (G : PackingGrid rows l) (h : ℕ → E) (p : ℕ → ℝ) (hp : ∀ j<m, 0≤p j ∧ p j≤1)
variable (F : Finset E → ℝ) (τ : ℝ)

private theorem executeRounds_congr (t u : ℕ → ActionRound m n s bits) (i : ℕ)
    (eq : ∀ j < i, t j=u j) : B.executeRounds G h p hp F τ t i = B.executeRounds G h p hp F τ u i := by
  induction i with
  | zero => rfl
  | succ i ih =>
    simp only [executeRounds]
    rw [ih (fun j hj => eq j (Nat.lt_succ_of_lt hj)),eq i (Nat.lt_succ_self i)]

private theorem executeRounds_update (t : ℕ → ActionRound m n s bits) (i : ℕ) (w : ActionRound m n s bits) :
    B.executeRounds G h p hp F τ (Function.update t i w) (i+1) =
      some (B.physicalRoundStep G h p hp F τ (B.executeRounds G h p hp F τ t i) w) := by
  rw [executeRounds,Function.update_self,B.executeRounds_congr G h p hp F τ _ t i]
  exact fun j hj => Function.update_of_ne hj.ne _ _

def freshRegisterStep (s bits : ℕ) (_ : ℕ) (r : Option (Registers l)) : CandidateLaw (Option (Registers l)) := by
  classical
  exact (CandidateLaw.ofMeasure (roundLaw m n s bits)).map (fun w => some (B.physicalRoundStep G h p hp F τ r w))

theorem register_expectation (left i : ℕ) (t : ℕ → ActionRound m n s bits) (test : Option (Registers l) → ℝ) :
    let q := actionTapeLaw (roundLaw m n s bits) left i t
    let u := CandidateLaw.execute (B.freshRegisterStep G h p hp F τ s bits) left i
      (B.executeRounds G h p hp F τ t i)
    expected q.outcomes q.mass (fun t' => test (B.executeRounds G h p hp F τ t' (i+left))) =
      expected u.outcomes u.mass test := by
  classical
  induction left generalizing i t with
  | zero => simp [actionTapeLaw,CandidateLaw.execute,CandidateLaw.pure_expected]
  | succ left ih =>
    dsimp only [actionTapeLaw]
    rw [CandidateLaw.bind_expected,CandidateLaw.execute_expected]
    unfold freshRegisterStep
    rw [CandidateLaw.map_expected]
    apply congrArg (expected _ _)
    funext w
    have he := ih (i+1) (Function.update t i w)
    rw [B.executeRounds_update] at he
    simpa only [Function.comp_apply,Nat.succ_add,Nat.add_succ] using he

private theorem register_expectation_zero (t : ℕ) (tape : ℕ → ActionRound m n s bits)
    (test : Option (Registers l) → ℝ) :
    let q := actionTapeLaw (roundLaw m n s bits) (t+1) 0 tape
    let u := CandidateLaw.execute (B.freshRegisterStep G h p hp F τ s bits) (t+1) 0 none
    expected q.outcomes q.mass (fun w => test (some (B.candidateRun G (paperExponent l)
      (B.paperAnswers h p m F τ hp (roundWords w)) (t+1)))) = expected u.outcomes u.mass test := by
  intro q u
  have e := B.register_expectation G h p hp F τ (t+1) 0 tape test
  simp only [Nat.zero_add] at e
  apply Eq.trans _ e
  apply congrArg (expected q.outcomes q.mass)
  funext w
  rw [B.executeRounds_correct]

/-- Every statistic of the proof's flagged optimizer, with the flag discarded,
   agrees with fresh draws and the register-only ascent program. -/
theorem marked_register_expectation (J : ℕ) (test : Option (Registers l) → ℝ) :
    let k := paperExponent l
    let T := ascentFuel k
    let q := B.markedOptimizerLaw G h p hp F τ J
    let u := CandidateLaw.execute (B.freshRegisterStep G h p hp F τ (actionBatch l J) (actionBits l)) T 0 none
    expected q.outcomes q.mass (fun a => test (some (B.candidateRun G k (B.paperAnswers h p m F τ hp a.1) T))) =
      expected u.outcomes u.mass test := by
  classical
  intro k T q u
  let obs := fun W : OptimizerWords m n l (actionBatch l J) (actionBits l) =>
    test (some (B.candidateRun G k (B.paperAnswers h p m F τ hp W) T))
  have e := B.markedOptimizer_observable G h p hp F τ J obs
  apply e.trans
  let tape : ℕ → ActionRound m n (actionBatch l J) (actionBits l) := fun _ _ _ _ => 0
  have ht : 0<T := by dsimp only [T,k,ascentFuel,scale]; positivity
  change expected (actionTapeLaw _ T 0 tape).outcomes (actionTapeLaw _ T 0 tape).mass
    (fun w => test (some (B.candidateRun G (paperExponent l) (B.paperAnswers h p m F τ hp (roundWords w)) T))) =
    expected (CandidateLaw.execute (B.freshRegisterStep G h p hp F τ (actionBatch l J) (actionBits l)) T 0 none).outcomes
      (CandidateLaw.execute (B.freshRegisterStep G h p hp F τ (actionBatch l J) (actionBits l)) T 0 none).mass test
  obtain ⟨t,eq⟩ := Nat.exists_eq_succ_of_ne_zero ht.ne'
  rw [eq]
  exact B.register_expectation_zero G h p hp F τ t tape test

end
end SubmodularMatching.NonmonotoneOptimizer.BlockData
