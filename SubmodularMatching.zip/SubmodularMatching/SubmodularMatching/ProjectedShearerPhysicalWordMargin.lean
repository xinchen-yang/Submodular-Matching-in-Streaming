import SubmodularMatching.ProjectedShearerWordHround

/-! The sparse word-trial margin including the finite signed priority oracle. -/

namespace SubmodularMatching.NonmonotoneCandidate
open GibbsMatching GibbsSampler UpperBoundAssembly TwoStage TwoLayerDiffuse VarianceBound Shearer ShearerCappedSampler Capacity AppendixM
open scoped BigOperators
noncomputable section
variable {I C L V : Type*} [LinearOrder I] [Fintype I] [LinearOrder C] [DecidableEq L] [DecidableEq V]

theorem physical_word_trial_margin {cap : V → ℕ} (base : C → Finset (Slots cap)) (active : Finset C)
    (orig : L → V×V) (lab : C → L) (copy : I → C) (label : I ↪ L) (hlabel : ∀ i, lab (copy i)=label i)
    {v : ℕ} (slot : Fin v ↪ Slots cap) (ep : I → Fin v × Fin v) (geom : ∀ i,
      base (copy i)=pairEnds (fun j => (slot (ep j).1,slot (ep j).2)) i)
    (hgeom : ∀ c ∈ active ∪ Finset.univ.image copy, ∀ j, touches orig j (lab c) → ∃ w ∈ base c, w.1=j)
    (one two : Input base active) (δ : ℝ) (hδ : 0<δ ∧ δ≤1) (r₁ r₂ a b t : ℕ) (ha : 0<a) (hb : 0<b)
    (hend : ∀ e∈active,(base e).Nonempty) (y₁ y₂ : C→ℝ) (hy₁ : InteriorLaw base active y₁)
    (hy₂ : InteriorLaw base active y₂) (e₁ e₂ : ℝ)
    (h₁ : variation Finset.univ (Shearer.probability base active y₁) (outcomeLaw one δ hδ r₁).mass ≤ e₁)
    (h₂ : variation Finset.univ (Shearer.probability base active y₂) (outcomeLaw two δ hδ r₂).mass ≤ e₂)
    (k Q D : ℕ) (hk : 0<k) (hQ : 0<Q) (hD : 0<D)
    (order : ℕ → I) (m : ℕ) (cover : (Finset.univ:Finset I) ⊆ replacementPrefix order m)
    (hi : ∀ j<m,∀ l<m,order j=order l→j=l)
    (loop : ∀ i, (ep i).1 ≠ (ep i).2) (simple : Function.Injective (pairEnds ep))
    (f : Finset L→ℝ) (hf : IsSubmodular f) (hn : ∀ U,0≤f U) (B : ℝ) (hB : 0≤B)
    (p G F : ℝ) (hp : 0≤p) (hp1 : p≤1) (hpc : p ≤ signedRoundingCap (1/k))
    (wh : ℕ → ℝ) (x : I → ℝ) (hw : ∀ i<m,0≤wh i ∧ wh i ≤ arrivalWeight (fun j => label (order j)) p f i)
    (hlin : ∑ i∈Finset.range m, wh i*x (order i) ≤ G)
    (ε H : ℝ) (hε : 0<ε) (upperF : ∀ U,f U≤H) (samples bits : ℕ) (hsamples : 0<samples)
    (hbits : m*(1/(2:ℝ)^bits)*(H-(-H))≤ ε/64)
    (num : (Marked base active a × Marked base active b) → I → ℕ) (η ρ : ℝ)
    (hc : ∀ z i, (num z i:ℝ)/Q ≤ p)
    (hl : ∀ z w, gridLoadNumerator (pairEnds (fun i => (slot (ep i).1,slot (ep i).2))) Finset.univ (num z) w ≤ Q)
    (hs : ∀ z i, num z i ≠ 0 → vacant base active (slot (ep i).1) (forgetMark z.1,forgetMark z.2)=1 ∧
      vacant base active (slot (ep i).2) (forgetMark z.1,forgetMark z.2)=1)
    (ha' : ∀ i, (1-1/(k:ℝ))*x i-η ≤ finiteMean (nativeMarkedPair base active a b y₁ y₂) (fun z => (num z i:ℝ)/Q))
    (hp' : ∀ estimate : PriorityEstimate C, (∀ A e, |estimate A e-
      marginal (shiftResidual (fun j => label (order j)) p f m) (binLabel lab e) (A.image (binLabel lab))|≤ ε) →
      gamma*F-ρ ≤ finiteMean (nativeMarkedPair base active a b y₁ y₂) (fun z =>
        residualValue (fun j => label (order j)) p f m
          (priorityLabels base active a b lab (shiftResidual (fun j => label (order j)) p f m) estimate z)))
    (upper : ∀ estimate : PriorityEstimate C, ∀ z : Marked base active a × Marked base active b,
      ∀ N ∈ matchings (pairEnds ep) Finset.univ, f
        (priorityLabels base active a b lab (shiftResidual (fun j => label (order j)) p f m) estimate z ∪ N.image label) ≤ B)
    (opt P residual h0 W chargeLoss optLoss baseLoss scale α : ℝ) (Qtime r : ℕ)
    (hopt : 0≤opt) (hG : 0≤G) (hpU : p≤ implementationUnit)
    (hξU : 1/(k:ℝ)≤ implementationUnit) (hbase : h0≤f ∅+G+baseLoss)
    (hcharge : (1-p)*opt ≤ f ∅+G+P+residual+chargeLoss)
    (hlinear : (AppendixM.alpha+1/1000000)*G+beta*P≤W)
    (hact : W+beta*residual-(AppendixM.alpha-beta)*h0-optLoss ≤ (∑ i∈Finset.range m,wh i*x (order i))+gamma*F)
    (hsmall : beta*chargeLoss+(AppendixM.alpha-beta)*baseLoss+optLoss≤ implementationUnit*opt)
    (hscale : 2000000000≤scale) (hH : 0≤H) (hNscale : (active.card:ℝ)≤scale) (hrscale : (r:ℝ)≤scale)
    (hHscale : H≤scale*opt) (hBscale : B≤scale*opt) (hWscale : ∑ i∈Finset.range m,wh i ≤ scale*opt)
    (hqscale : scale^5≤(Qtime:ℝ)) (hdscale : scale^2≤(D:ℝ))
    (hεscale : ε≤opt/scale^2) (hαscale : α≤1/scale^3) (hηscale : η≤1/scale^2)
    (hEsc₁ : e₁≤1/scale^2) (hEsc₂ : e₂≤1/scale^2) (htsc : ((2:ℝ)^t)⁻¹≤1/scale^2)
    (hρ : ρ = priorityLossBudget active.card r Qtime H ε α)
    (hh : (2*active.card)*(2*Real.exp (-(2*samples*(ε/2)^2)/(H-(-H))^2))*H ≤ implementationUnit*opt) :
    let first := binaryPair one two δ hδ r₁ r₂ a b t ha hb hend
    let out := wordGibbsTrial base active a b lab first ep Finset.univ num k Q D label (fun j => label (order j))
      m samples bits p ⟨hp,hp1⟩ f ε
    (∀ M∈out.outcomes, Capacity.feasible orig cap M) ∧
      (1000/4727+3*implementationUnit)*opt ≤ expected out.outcomes out.mass f := by
  classical
  intro first out
  let hist := fun j => label (order j)
  let h := shiftResidual hist p f m
  have card (e) (he : e∈active) : (base e).card=2 := by rw [one.pairs _ he,Finset.card_pair (one.loopless _ he)]
  have det (estimate : PriorityEstimate C) (acc : ∀ A e, |estimate A e-marginal h (binLabel lab e) (A.image (binLabel lab))|≤ε) :=
    physical_trial_margin base active orig lab copy label hlabel slot ep geom hgeom one two δ hδ r₁ r₂ a b t ha hb hend
      y₁ y₂ hy₁ hy₂ e₁ e₂ h₁ h₂ k Q D hk hQ hD order m cover hi loop simple f hf hn B hB p G F hp hp1 hpc
      wh x hw hlin h estimate num η ρ hc hl hs ha' (hp' estimate acc) (upper estimate)
      opt P residual h0 W chargeLoss optLoss baseLoss scale H α ε Qtime r hopt hG hpU hξU hbase hcharge hlinear hact
      hsmall hscale hH hNscale hrscale hHscale hBscale hWscale hqscale hdscale hεscale hαscale hηscale hEsc₁ hEsc₂ htsc hρ
  have total := wordGibbsTrial_margin base active card a b lab first ep Finset.univ num k Q D label hist m samples bits p
    ⟨hp,hp1⟩ f H ε (fun U => ⟨hn U,upperF U⟩) hε hsamples hbits ((1000/4727+4*implementationUnit)*opt)
    (fun estimate acc => (det estimate acc).2)
  have hload (z) (w : Fin v) : gridLoadNumerator (pairEnds ep) Finset.univ (num z) w ≤ Q :=
    (compact_load slot ep _ (fun _ => rfl) (num z) w).trans_le (hl z (slot w))
  constructor
  · apply wordGibbsTrial_support
    intro est M hM
    let TF := fun z : Marked base active a × Marked base active b =>
      (estimatedOutput base lab h est z.1.val z.2.val).image Prod.fst
    have eqv : priorityLabels base active a b lab h est = fun z => (TF z).image lab := by
      funext z
      simp only [priorityLabels,TF,Finset.image_image]
      rfl
    have valid := trial_feasible cap base active orig lab first ep Finset.univ slot copy label hlabel geom hgeom
      k Q D hk hQ num Finset.univ.toList (Finset.toList_toFinset _) (Finset.nodup_toList _)
      (fun i _ => loop i) hload (fun z => (forgetMark z.1,forgetMark z.2)) TF (fun z i _ => hs z i)
      (fun z => estimated_unmarked_support base lab h est z.1.val z.2.val)
    apply valid M
    rwa [←eqv]
  · change (1000/4727+3*implementationUnit)*opt ≤ expected out.outcomes out.mass f
    change (1000/4727+4*implementationUnit)*opt - _ ≤ expected out.outcomes out.mass f at total
    linarith only [total,hh]

end
end SubmodularMatching.NonmonotoneCandidate
