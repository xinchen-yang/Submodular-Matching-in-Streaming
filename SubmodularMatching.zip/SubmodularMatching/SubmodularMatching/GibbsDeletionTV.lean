import SubmodularMatching.GibbsStability
import SubmodularMatching.GibbsSamplerApproximation

/-!
# The total variation statement of Lemma H.3

The exact projection is a density tilt of the Gibbs distribution on the
remaining edges. Evaluating the expectation-stability theorem at the
maximizing event gives the total variation bound in the paper's form.
-/

open scoped BigOperators

namespace SubmodularMatching.GibbsMatching

open GibbsSampler

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The mass of a particular matching under restriction to the surviving
edges, expressed using the exact density tilt. -/
def vertexProjectionMass (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (v : V) (N : Finset E) : ℝ :=
  let H := deleteVertex ends S v
  let load := extensionLoad ends S activity v
  probability ends H activity N * (1 + load N) / (1 + expectation ends H activity load)

theorem vertexProjectionMass_expectation (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) (F : Finset E → ℝ) :
    expected (matchings ends (deleteVertex ends S v)) (vertexProjectionMass ends S activity v) F =
      expectation ends S activity (fun M => F (M ∩ deleteVertex ends S v)) := by
  rw [expectation_restriction ends S activity ha hends v F, expectation_eq_probability_sum]
  unfold expected vertexProjectionMass
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro N hN
  ring

theorem vertexProjectionMass_probability (ends : E → Finset V) (S : Finset E)
    (activity : E → ℝ) (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2) (v : V) :
    IsProbability (matchings ends (deleteVertex ends S v)) (vertexProjectionMass ends S activity v) := by
  let H := deleteVertex ends S v
  have haH : ∀ e ∈ H, 0 ≤ activity e :=
    fun e he => ha e (deleteVertex_subset ends S v he)
  have hload (N : Finset E) : 0 ≤ extensionLoad ends S activity v N :=
    extensionLoad_nonnegative ends S activity ha v N
  refine ⟨fun N _ => ?_, ?_⟩
  · change 0 ≤ probability ends H activity N * (1 + extensionLoad ends S activity v N) /
      (1 + expectation ends H activity (extensionLoad ends S activity v))
    have hmean := expectation_nonnegative ends H activity haH
      (extensionLoad ends S activity v) (fun N _ => hload N)
    exact div_nonneg (mul_nonneg (probability_nonnegative ends H activity haH N)
      (by linarith [hload N])) (by linarith)
  · simpa [expected, expectation_const ends S activity ha] using
      vertexProjectionMass_expectation ends S activity ha hends v (fun _ => 1)

omit [DecidableEq E] [DecidableEq V] in
/-- For two finite probability laws, the indicator of the positive mass
difference realizes their total variation distance. -/
theorem variation_eq_event_difference {A : Type*} (states : Finset A) (p q : A → ℝ)
    (hp : IsProbability states p) (hq : IsProbability states q) :
    let event := fun a => if q a ≤ p a then (1 : ℝ) else 0
    variation states p q = expected states p event - expected states q event := by
  classical
  dsimp only
  unfold variation expected
  rw [← Finset.sum_sub_distrib, Finset.sum_div]
  have hpoint (a : A) :
      p a * (if q a ≤ p a then (1 : ℝ) else 0) -
          q a * (if q a ≤ p a then (1 : ℝ) else 0) =
        |p a - q a| / 2 + (p a - q a) / 2 := by
    by_cases h : q a ≤ p a
    · simp [h, abs_of_nonneg (sub_nonneg.mpr h)] <;> ring
    · simp [h, abs_of_neg (sub_neg.mpr (lt_of_not_ge h))] <;> ring
  simp_rw [hpoint]
  rw [Finset.sum_add_distrib, ← Finset.sum_div (f := fun a => p a - q a),
    Finset.sum_sub_distrib, hp.total, hq.total]
  simp

/-- Lemma H.3 stated directly as total variation of the projected Gibbs
measure and the Gibbs measure on the vertex-deleted graph. -/
theorem vertex_deletion_total_variation [Finite V]
    (ends : E → Finset V) (S : Finset E) (activity : E → ℝ)
    (ha : ∀ e ∈ S, 0 ≤ activity e)
    (hends : ∀ e ∈ S, (ends e).card = 2)
    (hsimple : Set.InjOn ends (S : Set E)) (h : ℝ) (hh : 0 ≤ h)
    (hcap : ∀ e ∈ S, activity e ≤ h) (v : V) :
    variation (matchings ends (deleteVertex ends S v))
      (vertexProjectionMass ends S activity v)
      (probability ends (deleteVertex ends S v) activity) ≤ Real.sqrt (h / 8) := by
  classical
  let H := deleteVertex ends S v
  let p := vertexProjectionMass ends S activity v
  let q := probability ends H activity
  let F := fun N => if q N ≤ p N then (1 : ℝ) else 0
  have haH : ∀ e ∈ H, 0 ≤ activity e :=
    fun e he => ha e (deleteVertex_subset ends S v he)
  have hp := vertexProjectionMass_probability ends S activity ha hends v
  have hq : IsProbability (matchings ends H) q :=
    ⟨fun N _ => probability_nonnegative ends H activity haH N,
      probability_total ends H activity haH⟩
  have hvar : variation (matchings ends H) p q =
      expected (matchings ends H) p F - expected (matchings ends H) q F :=
    variation_eq_event_difference _ p q hp hq
  rw [vertexProjectionMass_expectation ends S activity ha hends v F] at hvar
  have hqF : expected (matchings ends H) q F = expectation ends H activity F :=
    (expectation_eq_probability_sum ends H activity F).symm
  rw [hqF] at hvar
  have hstab := vertex_deletion_expectation_stability ends S activity ha hends hsimple
    h 1 hh zero_le_one hcap v F (fun N _ => by unfold F; split_ifs <;> norm_num)
  rw [mul_one] at hstab
  exact hvar.le.trans ((le_abs_self _).trans hstab)

end

end SubmodularMatching.GibbsMatching
