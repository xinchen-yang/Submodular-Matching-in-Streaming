import SubmodularMatching.NonmonotoneParameters
import SubmodularMatching.UpperBoundVertexResources

namespace SubmodularMatching.AppendixM
open Streaming UpperBoundAssembly
noncomputable section
attribute [local irreducible] rescaledRateTable

private def referenceGuess : PotentialConfig := signedConfig 2 (by decide) 1 (by norm_num)

private def potentialRatioConstant : ℝ :=
  (1 + (referenceGuess.maxRate + 1) * referenceGuess.p) /
    (referenceGuess.minLow * referenceGuess.p * (streamTolerance:ℝ))

/-- Uniform constant in the per-vertex incidence bound for the fixed
appendix rates. It is independent of input sizes and active guess scales. -/
def incidenceConstant : ℕ :=
  ⌈1 + (2 / (referenceGuess.kappa * referenceGuess.p)) *
    (max 0 (Real.log potentialRatioConstant) + Real.log 2)⌉₊

/-- Bound the cap-to-seed ratio before taking its logarithm. -/
theorem signedConfig_cap_seed (n : ℕ) (hn : 2 ≤ n) (τ : ℝ) (hτ : 0 < τ) :
    let C := signedConfig n hn τ hτ
    C.cap / C.seed = potentialRatioConstant * (n : ℝ) := by
  intro C
  have hp : C.p = referenceGuess.p := rfl
  have hl : C.minLow = referenceGuess.minLow := rfl
  have hr : C.maxRate = referenceGuess.maxRate := rfl
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast (show n ≠ 0 by omega)
  have hτ' : C.tau = τ := rfl
  have hθ' : C.theta = (streamTolerance:ℝ) * τ / (n : ℝ) := rfl
  unfold PotentialConfig.cap PotentialConfig.seed potentialRatioConstant
  rw [hp, hl, hr, hτ', hθ']
  field_simp [hn', hτ.ne', referenceGuess.minLow_pos.ne', referenceGuess.p_pos.ne', (by norm_num [streamTolerance] : (streamTolerance:ℝ) ≠ 0)]

/-- Every positive-scale instance has logarithmically many incidences at
one stored vertex, whether or not its estimates were accurate. -/
theorem signedConfig_incidenceLimit_le (n : ℕ) (hn : 2 ≤ n) (τ : ℝ) (hτ : 0 < τ) :
    (signedConfig n hn τ hτ).incidenceLimit ≤ incidenceConstant * ((n + 1).log2 + 1) := by
  let C := signedConfig n hn τ hτ
  let w := (n + 1).log2 + 1
  let A := 2 / (referenceGuess.kappa * referenceGuess.p)
  let L := max 0 (Real.log potentialRatioConstant)
  have hp : C.p = referenceGuess.p := rfl
  have hk : C.kappa = referenceGuess.kappa := rfl
  have hA : 0 ≤ A := by dsimp [A]; positivity [referenceGuess.kappa_pos, referenceGuess.p_pos]
  have hL : 0 ≤ L := le_max_left _ _
  have hw : (1 : ℝ) ≤ w := by exact_mod_cast (show 1 ≤ w by dsimp [w]; omega)
  have hn' : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
  have hpowN : n ≤ 2 ^ w := (Nat.le_succ n).trans (Nat.lt_log2_self (n := n + 1)).le
  have hpowR : (n : ℝ) ≤ (2 : ℝ) ^ w := by exact_mod_cast hpowN
  have hlog := Real.log_le_log hn' hpowR
  rw [Real.log_pow] at hlog
  have hR : 0 < potentialRatioConstant := by
    unfold potentialRatioConstant
    have hr : 0 ≤ referenceGuess.maxRate := referenceGuess.minLow_pos.le.trans
      (referenceGuess.base_bounds.2.2.1.trans referenceGuess.base_bounds.2.2.2)
    positivity [referenceGuess.minLow_pos, referenceGuess.p_pos, (by norm_num [streamTolerance] : (0:ℝ) < streamTolerance)]
  have hlog' : Real.log (C.cap / C.seed) ≤ (L + Real.log 2) * (w : ℝ) := by
    rw [signedConfig_cap_seed n hn τ hτ]
    rw [Real.log_mul hR.ne' hn'.ne']
    calc
      _ ≤ L + (w : ℝ) * Real.log 2 := add_le_add (le_max_right _ _) hlog
      _ ≤ L * (w : ℝ) + (w : ℝ) * Real.log 2 := by
        exact add_le_add (by simpa only [mul_one] using mul_le_mul_of_nonneg_left hw hL) le_rfl
      _ = _ := by ring
  have hbound : 1 + 2 / (C.kappa * C.p) * Real.log (C.cap / C.seed) ≤
      ((incidenceConstant * w : ℕ) : ℝ) := by
    rw [hp, hk]
    change 1 + A * Real.log (C.cap / C.seed) ≤ _
    calc
      _ ≤ (w : ℝ) + A * ((L + Real.log 2) * (w : ℝ)) :=
        add_le_add hw (mul_le_mul_of_nonneg_left hlog' hA)
      _ = (1 + A * (L + Real.log 2)) * (w : ℝ) := by ring
      _ ≤ _ := by
        push_cast
        exact mul_le_mul_of_nonneg_right (Nat.le_ceil _) (Nat.cast_nonneg w)
  exact (Nat.floor_le_floor hbound).trans_eq (Nat.floor_natCast _)

/-- A fixed logarithmic bound on the number of dyadic guesses. -/
def signedGuessCountConstant : ℕ := 3 + (4398046511104 : ℕ).log2

theorem signedGuessCount_le (n : ℕ) :
    Nat.clog 2 (n * 4398046511104) + 1 ≤ signedGuessCountConstant * ((n + 1).log2 + 1) := by
  let w := (n + 1).log2 + 1
  have h : n * 4398046511104 ≤ 4398046511104 * (n + 1) ^ 1 := by
    rw [pow_one, Nat.mul_comm n]
    exact Nat.mul_le_mul_left _ (Nat.le_succ _)
  have hp := polynomial_index_word_bound h
  have hclog := Nat.clog_le_of_le_pow hp.le
  have hw : 1 ≤ w := by dsimp [w]; omega
  calc
    _ ≤ (1 + (4398046511104 : ℕ).log2 + 1) * w + 1 := Nat.add_le_add_right hclog _
    _ ≤ (1 + (4398046511104 : ℕ).log2 + 1) * w + w := Nat.add_le_add_left hw _
    _ = _ := by unfold signedGuessCountConstant; ring


end
end SubmodularMatching.AppendixM
