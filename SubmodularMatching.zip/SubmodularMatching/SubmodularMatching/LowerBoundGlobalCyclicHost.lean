import SubmodularMatching.LowerBoundGlobalCyclicVectorCount

/-! # The finite ERS host with its numerical parameters -/

namespace SubmodularMatching.LowerBoundGlobal.AJX

open scoped BigOperators

noncomputable section

private def wordLength (L s : ℕ) : ℕ := L * s
private def blockWidth (L s : ℕ) : ℕ := L * wordLength L s
private def gapWidth (C L s : ℕ) : ℕ := 10 * C * wordLength L s

def cyclicModulus (C L s : ℕ) : ℕ :=
  C * (blockWidth L s + gapWidth C L s)

def cyclicDimension (L s : ℕ) : ℕ := wordLength L s * L

def cyclicOrder (C L s : ℕ) : ℕ :=
  cyclicModulus C L s ^ cyclicDimension L s

def cyclicMatchingSize (C L s : ℕ) : ℕ :=
  blockWidth L s * cyclicModulus C L s ^ (cyclicDimension L s - 1)

theorem cyclicMatchingSize_eq (C L s : ℕ) :
    cyclicMatchingSize C L s = L * (L * s) *
      cyclicModulus C L s ^ (cyclicDimension L s - 1) := rfl

theorem cyclicModulus_eq (C L s : ℕ) :
    cyclicModulus C L s = (C * (L + 10 * C) * L) * s := by
  unfold cyclicModulus blockWidth gapWidth wordLength
  ring

theorem cyclicDimension_eq (L s : ℕ) : cyclicDimension L s = L ^ 2 * s := by
  unfold cyclicDimension wordLength
  ring

/-- The regularity of the cyclic buckets gives the ERS block cardinality
exactly, and the low-agreement words provide exponentially many groups. -/
theorem exists_cyclic_host {C L s : ℕ} (hC : 2 ≤ C) (hL : 40 * C < L) (hs : 0 < s) :
    ∃ t : ℕ, 4 ^ s ≤ t ∧ Nonempty (ERS (cyclicOrder C L s) C (cyclicMatchingSize C L s) t) := by
  let m := wordLength L s
  let B := blockWidth L s
  let W := gapWidth C L s
  have hL4 : 4 ≤ L := by omega
  have hm : 2 ≤ m := by
    dsimp [m, wordLength]
    exact le_trans (by omega : 2 ≤ L) (Nat.le_mul_of_pos_right _ hs)
  have hP : B + W = (L + 10 * C) * m := by
    dsimp [B, W, m, blockWidth, gapWidth]
    ring
  have hQ : 0 < C * (B + W) := by rw [hP]; positivity
  letI : NeZero (C * (B + W)) := ⟨hQ.ne'⟩
  obtain ⟨pack, hpack, hgood⟩ := exists_low_agreement_packing hL4 s
  let number : (pack : Type) ≃ Fin pack.card := Fintype.equivFinOfCardEq (Fintype.card_coe _)
  let word : Fin pack.card → Fin m → Fin L := fun i => (number.symm i).val
  have hinj : Function.Injective word := fun _ _ h => number.symm.injective (Subtype.ext h)
  let step := fun a b : Fin C => (C + b.val - a.val) * (L + 10 * C)
  have hstep (a b : Fin C) : 0 < step a b := by
    have ha := a.isLt
    exact Nat.mul_pos (by omega) (by omega)
  let design : CyclicDesign m L C B W pack.card := {
    word := word
    word_injective := hinj
    shift := step
    shift_pos := hstep
    shift_lt := by
      intro a b
      have hb := b.isLt
      have hlt : C + b.val - a.val < 2 * C := by omega
      calc
        _ < 2 * C * (L + 10 * C) := Nat.mul_lt_mul_of_pos_right hlt (by omega)
        _ ≤ C * (B + W) := by
          rw [hP, ← Nat.mul_assoc C]
          calc
            _ = C * (L + 10 * C) * 2 := by ring
            _ ≤ _ := Nat.mul_le_mul_left _ hm
    aligned := by
      intro a b
      have ha := a.isLt
      have hab : a.val + (C + b.val - a.val) = C + b.val := Nat.add_sub_of_le (by omega)
      have heq : a.val * (B + W) + m * step a b = (C + b.val) * (B + W) := calc
        _ = (a.val + (C + b.val - a.val)) * (B + W) := by rw [hP]; dsimp [step]; ring
        _ = _ := congrArg (fun x : ℕ => x * (B + W)) hab
      have hrem : b.val * (B + W) < C * (B + W) :=
        Nat.mul_lt_mul_of_pos_right b.isLt (by rw [hP]; positivity)
      rw [heq, Nat.add_mul, Nat.add_mod, Nat.mod_self, zero_add, Nat.mod_mod,
        Nat.mod_eq_of_lt hrem]
    small_overlap := by
      intro i j hij a b
      have hneq := fun h => hij (hinj h)
      have hag : agreement (word i) (word j) < 4 * s :=
        hgood (number.symm i).property (number.symm j).property hneq
      have hb := b.isLt
      have hstep' : step a b ≤ 2 * C * (L + 10 * C) :=
        Nat.mul_le_mul_right _ (by omega)
      calc
        _ < (4 * s) * step a b := Nat.mul_lt_mul_of_pos_right hag (hstep a b)
        _ ≤ (4 * s) * (2 * C * (L + 10 * C)) := Nat.mul_le_mul_left _ hstep'
        _ = (C * s) * (8 * (L + 10 * C)) := by ring
        _ ≤ (C * s) * (10 * L) := Nat.mul_le_mul_left _ (by omega)
        _ = W := by dsimp [W, gapWidth, wordLength]; ring }
  exact ⟨pack.card, hpack, ⟨design.toERS (cyclicMatchingSize C L s)
    (fun i a => cyclicBucket_card (lt_of_lt_of_le (by decide) hm) (word i) a)⟩⟩

end

end SubmodularMatching.LowerBoundGlobal.AJX
