import SubmodularMatching.FiniteShearerOrder
import SubmodularMatching.GibbsSamplerMixing

/-!
# Law of the complete finite Shearer sampler

The streamed exact kernel sends the old Shearer law to the next restricted
Shearer law. Replacing the exact conditional decisions by their bounded
three-coin implementation gives a normalized law with variation error at
most `2m (4r(1-r))^L`, where `m` is the length of the edge order.
-/

namespace SubmodularMatching.ShearerSampler

open GibbsMatching Shearer GibbsSampler
open scoped BigOperators

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

theorem matchingRow_step_shearer (ends : E → Finset V) (edges P : Finset E)
    (x : E → ℝ) (r : ℝ) (hr0 : 0 < r) (hr1 : r ≤ 1)
    (hx : ∀ e ∈ edges, 0 ≤ x e) (hends : ∀ e ∈ edges, (ends e).card = 2)
    (hdegree : ∀ v, (∑ e ∈ incident ends edges v, x e) ≤ r*(1-r))
    (e : E) (he : e ∉ P) (hP : insert e P ⊆ edges) (N : Finset E)
    (hN : N ∈ matchings ends edges) :
    applyKernel (matchings ends edges)
      (matchingRow ends edges e (fun A => prefixAcceptance ends P A x e))
      (mass ends P x) N = mass ends (insert e P) x N := by
  classical
  let states := matchings ends edges
  let hP' := (Finset.subset_insert e P).trans hP
  let a := fun A => prefixAcceptance ends P A x e
  let next := fun A => if insert e A ∈ states then insert e A else A
  have hpos (A : Finset E) : signedPartition ends (residualEdges ends P A) x ≠ 0 := by
    have hsub := (residualEdges_subset ends P A).trans hP'
    exact (signedPartition_positive_and_ratios ends _ x r hr0 hr1 (fun d hd => hx d (hsub hd))
      (fun d hd => hends d (hsub hd))
      (fun v => (incident_sum_le_of_subset ends _ edges x hx hsub v).trans (hdegree v))).1.ne'
  have hcompat (A : Finset E) :
      A ∈ matchings ends (compatibleEdges ends P e) ↔
        A ∈ matchings ends (compatibleEdges ends (insert e P) e) := by
    have hc : compatibleEdges ends (insert e P) e = compatibleEdges ends P e := by
      ext d
      simp only [mem_compatibleEdges, Finset.mem_insert]
      tauto
    rw [hc]
  have hb (A : Finset E) (hA : A ∈ matchings ends (compatibleEdges ends P e)) :
      next A = insert e A := by
    have hI := insert_mem_matchings ends (insert e P) A e (Finset.mem_insert_self _ _)
      ((hcompat _).mp hA)
    have hMem : insert e A ∈ states := matchings_subset ends _ edges hP hI
    exact if_pos hMem
  have hnone (A : Finset E) (hna : A ∉ matchings ends (compatibleEdges ends P e)) :
      a A = 0 := if_neg hna
  change (∑ A ∈ states, mass ends P x A *
      ((if A = N then 1 - a A else 0) + (if next A = N then a A else 0))) = _
  simp only [mul_add, Finset.sum_add_distrib, mul_ite, mul_zero]
  have hfirst :
      (∑ A ∈ states, (if A = N then mass ends P x A * (1 - a A) else 0)) =
        mass ends P x N * (1-a N) := by simp [states, hN]
  rw [hfirst]
  by_cases heN : e ∈ N
  · have hno : N ∉ matchings ends P := fun h => he ((mem_matchings _ _ _).mp h |>.1 heN)
    rw [mass_of_not_mem ends P x N hno, zero_mul, zero_add]
    let A := N.erase e
    have hA : A ∈ states :=
      matchings_subset ends _ _ (compatibleEdges_subset ends edges e)
        (erase_mem_compatible_matchings ends edges N e hN heN)
    have hterm (B : Finset E) (hne : B ≠ A) :
        (if next B = N then mass ends P x B * a B else 0) = 0 := by
      by_cases hB : B ∈ matchings ends (compatibleEdges ends P e)
      · rw [hb B hB, if_neg]
        intro hEq
        have hneB := not_mem_compatible_matching ends P B e hB
        apply hne
        change B = N.erase e
        rw [← hEq, Finset.erase_insert hneB]
      · simp [hnone B hB]
    rw [Finset.sum_eq_single_of_mem A hA (fun B _ hne => hterm B hne)]
    by_cases hA' : A ∈ matchings ends (compatibleEdges ends P e)
    · rw [hb A hA', if_pos (Finset.insert_erase heN)]
      have h := prefix_accept_mass ends P A x e ((hcompat A).mp hA') (hpos A)
      simpa only [a, A, Finset.insert_erase heN] using h
    · simp only [hnone A hA', mul_zero, ite_self]
      symm
      apply mass_of_not_mem
      intro hNew
      exact hA' ((hcompat A).mpr (erase_mem_compatible_matchings ends (insert e P) N e hNew heN))
  · have hz (B : Finset E) :
        (if next B = N then mass ends P x B * a B else 0) = 0 := by
      by_cases hB : B ∈ matchings ends (compatibleEdges ends P e)
      · rw [hb B hB, if_neg]
        intro hEq
        exact heN (hEq ▸ Finset.mem_insert_self e B)
      · simp [hnone B hB]
    simp only [hz, Finset.sum_const_zero, add_zero]
    by_cases hOld : N ∈ matchings ends P
    · exact prefix_reject_mass ends P N x e he hOld (hpos N)
    · rw [mass_of_not_mem ends P x N hOld, zero_mul]
      symm
      apply mass_of_not_mem
      intro hNew
      obtain ⟨hSub, hdj⟩ := (mem_matchings _ _ _).mp hNew
      apply hOld
      exact (mem_matchings _ _ _).mpr
        ⟨fun d hd => (Finset.mem_insert.mp (hSub hd)).resolve_left (fun heq => heN (heq ▸ hd)), hdj⟩

private theorem tail_subset {edges : Finset E} {e : E} {order : List E}
    (h : (e :: order).toFinset ⊆ edges) : order.toFinset ⊆ edges := by
  rw [List.toFinset_cons] at h
  exact (Finset.subset_insert e order.toFinset).trans h

noncomputable def shearerSchedule (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (fuel : ℕ) :
    (order : List E) → order.toFinset ⊆ edges →
    List ((Finset E → Finset E → ℝ) × (Finset E → Finset E → ℝ))
  | [], _ => []
  | e :: previous, h =>
    let hp := tail_subset h
    (matchingRow ends edges e (fun A => prefixAcceptance ends previous.toFinset A x e),
      matchingRow ends edges e (fun A =>
        boundedAcceptance ends edges previous.toFinset A x r fuel e (vertices e).1 (vertices e).2 hp)) ::
    shearerSchedule ends vertices edges x r fuel previous hp

theorem shearerSchedule_length (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (fuel : ℕ) (order : List E)
    (h : order.toFinset ⊆ edges) :
    (shearerSchedule ends vertices edges x r fuel order h).length = order.length := by
  induction order with
  | nil => rfl
  | cons e prior ih => simp only [shearerSchedule, List.length_cons, ih]

theorem shearerSchedule_kernels (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (hr : 1/2 ≤ r) (hr1 : r < 1)
    (hx : ∀ e ∈ edges, 0 ≤ x e) (hends : ∀ e ∈ edges, (ends e).card = 2)
    (hpairs : ∀ e ∈ edges, ends e = {(vertices e).1, (vertices e).2})
    (hdegree : ∀ v, (∑ e ∈ incident ends edges v, x e) ≤ r*(1-r))
    (L : ℕ) (order : List E) (h : order.toFinset ⊆ edges) :
    ∀ k ∈ shearerSchedule ends vertices edges x r (2*L) order h,
      IsKernel (matchings ends edges) k.1 ∧ IsKernel (matchings ends edges) k.2 ∧
      ∀ s ∈ matchings ends edges, variation (matchings ends edges) (k.1 s) (k.2 s) ≤
        2*(4*r*(1-r))^L := by
  induction order with
  | nil => simp [shearerSchedule]
  | cons e prior ih =>
    intro k hk
    rw [shearerSchedule] at hk
    rcases List.mem_cons.mp hk with hEq | hmem
    · subst k
      have he := h (List.mem_toFinset.mpr (List.mem_cons_self ..))
      exact boundedMatchingRow_refinement ends edges prior.toFinset x r hr hr1 hx hends hdegree L
        e he (vertices e).1 (vertices e).2 (hpairs e he) (tail_subset h)
    · exact ih _ _ hmem

theorem idealSchedule_eq_mass (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (hr0 : 0 < r) (hr1 : r ≤ 1)
    (hx : ∀ e ∈ edges, 0 ≤ x e) (hends : ∀ e ∈ edges, (ends e).card = 2)
    (hdegree : ∀ v, (∑ e ∈ incident ends edges v, x e) ≤ r*(1-r))
    (fuel : ℕ) (order : List E) (hnodup : order.Nodup) (h : order.toFinset ⊆ edges)
    (A : Finset E) (hA : A ∈ matchings ends edges) :
    applySchedule (matchings ends edges) (pointMass ∅)
        ((shearerSchedule ends vertices edges x r fuel order h).map Prod.fst) A =
      mass ends order.toFinset x A := by
  classical
  induction order generalizing A with
  | nil =>
    simp only [shearerSchedule, List.map_nil, applySchedule, List.toFinset_nil]
    by_cases hA : A = ∅
    · subst A
      simp [pointMass, mass, matchings_empty]
    · rw [mass_of_not_mem ends ∅ x A (by simp [matchings_empty, hA])]
      simp [pointMass, Ne.symm hA]
  | cons e prior ih =>
    obtain ⟨hne,hd⟩ := List.nodup_cons.mp hnodup
    rw [shearerSchedule, List.map_cons, applySchedule]
    simp only [List.toFinset_cons]
    trans applyKernel (matchings ends edges)
        (matchingRow ends edges e (fun A => prefixAcceptance ends prior.toFinset A x e))
        (mass ends prior.toFinset x) A
    · unfold applyKernel
      exact Finset.sum_congr rfl fun B hB => by rw [ih hd (tail_subset h) B hB]
    · exact matchingRow_step_shearer ends edges prior.toFinset x r hr0 hr1 hx hends hdegree
        e (fun hm => hne (List.mem_toFinset.mp hm)) (by simpa only [List.toFinset_cons] using h) A hA

/-- Output law of the bounded matching sampler. At most `fuel` top
trials are used for each of its two recursive calls per edge. -/
noncomputable def finiteShearerLaw (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (fuel : ℕ) (order : List E)
    (h : order.toFinset ⊆ edges) : Finset E → ℝ :=
  applySchedule (matchings ends edges) (pointMass ∅)
    ((shearerSchedule ends vertices edges x r fuel order h).map Prod.snd)

/-- The bounded stack procedure yields a feasible matching law with the
global accumulated timeout error. Every timed out call is read as zero,
so its edge is rejected and later edges may still be processed. -/
theorem finiteShearerLaw_variation (ends : E → Finset V) (vertices : E → V × V)
    (edges : Finset E) (x : E → ℝ) (r : ℝ) (hr : 1/2 ≤ r) (hr1 : r < 1)
    (hx : ∀ e ∈ edges, 0 ≤ x e) (hends : ∀ e ∈ edges, (ends e).card = 2)
    (hpairs : ∀ e ∈ edges, ends e = {(vertices e).1, (vertices e).2})
    (hdegree : ∀ v, (∑ e ∈ incident ends edges v, x e) ≤ r*(1-r))
    (L : ℕ) (order : List E) (hnodup : order.Nodup) (h : order.toFinset ⊆ edges) :
    IsProbability (matchings ends edges) (finiteShearerLaw ends vertices edges x r (2*L) order h) ∧
    variation (matchings ends edges) (mass ends order.toFinset x)
      (finiteShearerLaw ends vertices edges x r (2*L) order h) ≤
      2*order.length*(4*r*(1-r))^L := by
  let states := matchings ends edges
  let steps := shearerSchedule ends vertices edges x r (2*L) order h
  let initial := pointMass (∅ : Finset E)
  have hInit : IsProbability states initial :=
    pointMass_probability states ∅ (empty_mem_matchings ends edges)
  have hK := shearerSchedule_kernels ends vertices edges x r hr hr1 hx hends hpairs hdegree L order h
  change IsProbability states (applySchedule states initial (steps.map Prod.snd)) ∧ _
  constructor
  · apply applySchedule_probability states initial hInit (steps.map Prod.snd)
    intro k hk
    obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hk
    exact (hK j hj).2.1
  · have hr0 : 0 < r := by linarith
    have hTV := variation_applySchedule states initial hInit steps (2*(4*r*(1-r))^L) hK
    have hEq (A : Finset E) (hA : A ∈ states) :
        applySchedule states initial (steps.map Prod.fst) A = mass ends order.toFinset x A :=
      idealSchedule_eq_mass ends vertices edges x r hr0 hr1.le hx hends hdegree (2*L) order hnodup h A hA
    unfold variation at hTV ⊢
    have hSum :
        (∑ s ∈ states, |applySchedule states initial (steps.map Prod.fst) s -
            applySchedule states initial (steps.map Prod.snd) s|) =
        ∑ s ∈ states, |mass ends order.toFinset x s - applySchedule states initial (steps.map Prod.snd) s| :=
      Finset.sum_congr rfl (fun s hs => by rw [hEq s hs])
    rw [hSum, show steps.length = order.length from
      shearerSchedule_length ends vertices edges x r (2*L) order h] at hTV
    change (∑ s ∈ states, |mass ends order.toFinset x s -
      applySchedule states initial (steps.map Prod.snd) s|) / 2 ≤ _
    convert hTV using 1
    ring

end SubmodularMatching.ShearerSampler
