import SubmodularMatching.ProjectedShearerRowScores
import SubmodularMatching.NonmonotoneLayersPhysicalPriority

/-! Priority accumulators on every surviving source guess, independent of its accuracy. -/
namespace SubmodularMatching.AppendixM
open Capacity Capacity.RealOracle Streaming Shearer UpperBoundAssembly OracleQuery
noncomputable section
variable {E I C : Type*} [DecidableEq E] [Fintype I] [DecidableEq I] [DecidableEq C]

theorem sampled_label_range (f : Finset E→ℝ) (hf : IsSubmodular f) (hn : ∀ A,0≤f A)
    (keep : I→E) (τ : ℝ) (ht : 0<τ) (base : f ∅ ≤τ) (hs : ∀ i,f {keep i}≤τ) :
    ∀ A : Finset I,0≤f (A.image keep) ∧ f (A.image keep)≤(Fintype.card I+1:ℝ)*τ := by
  intro A
  have each (e) (h : e∈A.image keep) : f {e}≤τ := by
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp h
    exact hs i
  have sub := signed_disjoint_singleton_charge f hf (hn _) ∅ (A.image keep) (by simp)
  rw [Finset.empty_union] at sub
  have sum := Finset.sum_le_sum each
  simp only [Finset.sum_const,nsmul_eq_mul] at sum
  have sz : (A.image keep).card≤Fintype.card I := Finset.card_image_le.trans A.card_le_univ
  have up := mul_le_mul_of_nonneg_right (by exact_mod_cast sz : ((A.image keep).card:ℝ)≤Fintype.card I) ht.le
  exact ⟨hn _,by linarith only [base,sub,sum,up]⟩

set_option maxHeartbeats 1200000 in
/-- Every partial signed accumulator in the sampled priority row fits in
the polynomial register, even when the optimizer returned a bad estimate
or when this surviving guess is far from the optimum. -/
theorem active_score_prefix_registers (f : Finset E→ℝ) (hf : IsSubmodular f) (hn : ∀ A,0≤f A)
    (keep : I→E) (τ : ℝ) (ht : 0<τ) (h0 : f ∅ ≤τ) (hs : ∀ i,f {keep i}≤τ)
    (slots vertices : ℕ) (lab : C→I) (xs : List C) (hist : ℕ→I) (s N : ℕ) (p : ℝ) (hp : 0≤p ∧ p≤1)
    (hN : N≤oracleReads (trialScale slots (Fintype.card I) vertices))
    (tape : WordBatch N s (oracleWidth (trialScale slots (Fintype.card I) vertices))) :
    let K := trialScale slots (Fintype.card I) vertices
    let col := seekScoreColumn lab xs ∅
    let reg := scanScoreWords hist s (oracleWidth K) p (fun U => f (U.image keep))
      (oracleTolerance K τ) col N tape (Vector.replicate xs.length 0)
    ∀ i : Fin xs.length, |(reg[i]:ℝ)| ≤ 8704*(K:ℝ)^12 := by
  intro K col reg i
  have range := sampled_label_range f hf hn keep τ ht h0 hs
  let H := (Fintype.card I+1:ℝ)*τ
  have hk : 0<K := by dsimp [K,trialScale]; positivity
  have hkR : 0<(K:ℝ) := by exact_mod_cast hk
  have he : 0<oracleTolerance K τ := div_pos ht (mul_pos (by norm_num) (pow_pos hkR 2))
  have cap : H ≤ K*τ := by
    apply mul_le_mul_of_nonneg_right _ ht.le
    exact_mod_cast (by have h := (trialScale_bounds slots (Fintype.card I) vertices).2.2.1; omega :
      Fintype.card I+1≤trialScale slots (Fintype.card I) vertices)
  have ok := priority_score_resources lab xs hist s N (oracleWidth K) p hp (fun U => f (U.image keep)) H _
    range he tape
  have up : (N:ℝ)*(4*H/oracleTolerance K τ+1) ≤ (oracleReads K:ℝ)*(4*H/oracleTolerance K τ+1) := by
    have hh : 0≤H := mul_nonneg (add_nonneg (Nat.cast_nonneg _) zero_le_one) ht.le
    exact mul_le_mul_of_nonneg_right (by exact_mod_cast hN) (add_nonneg (div_nonneg (mul_nonneg (by norm_num) hh) he.le) zero_le_one)
  exact ((ok.2.2.2.2.2 i).trans up).trans (physical_score_register K hk τ H ht cap)
end
end SubmodularMatching.AppendixM
