import SubmodularMatching.CapacitySize
import Mathlib.Data.Nat.Log

/-! # Executing the monotone capacity reduction one emitted edge at a time -/

namespace SubmodularMatching.Capacity
open Finset
variable {E V State : Type*} [DecidableEq E] [DecidableEq V]

/-- Run a consumer in increasing index order, with two integer counters. -/
def foldIndices (consume : State → ℕ → State) : ℕ → ℕ → State → State
  | _, 0, st => st
  | i, n + 1, st => foldIndices consume (i+1) n (consume st i)

theorem foldIndices_eq (consume : State → ℕ → State) (i n : ℕ) (st : State) :
    foldIndices consume i n st = (List.range' i n).foldl consume st := by
  induction n generalizing i st with
  | zero => rfl
  | succ n ih => simp [foldIndices, List.range'_succ, ih]

def emitBlock (ends : E → V × V) (cap : V → ℕ) (accept : Bool) (u v : ℕ) (e : E)
    (consume : State → Copy E → State) (st : State) : State :=
  if accept then consume st ⟨e,u,v⟩ else
    foldIndices (fun a i => foldIndices (fun b j => consume b ⟨e,i,j⟩) 0 (cap (ends e).2) a)
      0 (cap (ends e).1) st

/-- Only greedy accepted labels persist between input edges. Their two endpoint degrees
can be read by scanning this set. The stream of copies is fed directly to its consumer. -/
def run (ends : E → V × V) (cap : V → ℕ) (consume : State → Copy E → State)
    (B : Finset E) (st : State) : List E → Finset E × State
  | [] => (B,st)
  | e::xs =>
    let u := (incidences ends B (ends e).1).card
    let v := (incidences ends B (ends e).2).card
    let accept := decide (u < cap (ends e).1 ∧ v < cap (ends e).2)
    let st' := emitBlock ends cap accept u v e consume st
    run ends cap consume (if accept then insert e B else B) st' xs

theorem emitBlock_eq (ends : E → V × V) (cap : V → ℕ) (a : Allocation E V) (e : E)
    (consume : State → Copy E → State) (st : State) :
    emitBlock ends cap (decide (room ends cap a e))
      (incidences ends a.kept (ends e).1).card (incidences ends a.kept (ends e).2).card
      e consume st = (block ends cap a e).foldl consume st := by
  classical
  by_cases h : room ends cap a e
  · simp [emitBlock,block,h,designated, keep]
  · simp only [emitBlock, block, decide_eq_false h, Bool.false_eq_true, if_false, if_neg h]
    simp only [foldIndices_eq, ← List.range_eq_range', List.foldl_map, SProd.sprod,
      List.product, List.foldl_flatMap]

theorem run_eq (ends : E → V × V) (cap : V → ℕ) (a : Allocation E V)
    (consume : State → Copy E → State) (st : State) (s : List E) :
    run ends cap consume a.kept st s =
      ((final ends cap a s).kept, (emitted ends cap a s).foldl consume st) := by
  induction s generalizing a st with
  | nil => rfl
  | cons e s ih =>
    have hb : (step ends cap a e).kept = if room ends cap a e then insert e a.kept else a.kept := by
      by_cases h : room ends cap a e <;> simp [step,keep,h]
    simp only [run, emitted, List.foldl_append]
    change run ends cap consume (if decide (room ends cap a e) then insert e a.kept else a.kept) _ s = _
    simp only [decide_eq_true_eq]
    have hem := emitBlock_eq ends cap a e consume st
    unfold room at hem
    rw [← hb, hem, ih]
    rfl

theorem run_storage (ends : E → V × V) (cap : V → ℕ) (consume : State → Copy E → State)
    (st : State) (input : List E) (hn : input.Nodup) (ν : ℕ)
    (hν : ∀ s, feasible ends cap s → s.card ≤ ν) :
    (run ends cap consume ∅ st input).1.card ≤ ν := by
  have hf : ∀ e ∈ input, e ∉ (emptyAllocation : Allocation E V).kept := by simp [emptyAllocation]
  have ha := final_consistent ends cap emptyAllocation (empty_consistent ends cap) input hn hf
  have h := congrArg Prod.fst (run_eq ends cap (emptyAllocation : Allocation E V) consume st input)
  exact h ▸ hν _ ha.capacity

theorem block_length (ends : E → V × V) (cap : V → ℕ) (a : Allocation E V) (e : E) :
    (block ends cap a e).length ≤ max 1 (cap (ends e).1 * cap (ends e).2) := by
  by_cases h : room ends cap a e <;> simp [block, h, List.length_product]

/-- Projecting a queried set requires at most one label per queried copy. -/
theorem query_storage (q : Finset (Copy E)) : (project q).card ≤ q.card := card_image_le

/-- Replacing the matching number and vertex count in a target space budget
changes only the constant in front of the original bound. -/
theorem space_transfer (ν νb n nv a C : ℕ) (hν : ν ≤ 3 * νb) (hv : nv ≤ n ^ 2) :
    C * (ν + 1) * ((nv + 1).log2 + 1) ^ a ≤
      (C * (3 * 2 ^ a)) * (νb + 1) * ((n + 1).log2 + 1) ^ a := by
  have ha : n + 1 < 2 ^ ((n+1).log2 + 1) := by
    simpa only [Nat.log2_eq_log_two] using Nat.lt_pow_succ_log_self (b:=2) (by decide) (n+1)
  have hp : nv + 1 < 2 ^ (2 * ((n+1).log2 + 1)) := by
    rw [mul_comm 2 _, pow_mul]
    have hsq := Nat.pow_lt_pow_left ha (by decide : 2 ≠ 0)
    nlinarith
  have hlog : (nv + 1).log2 + 1 ≤ 2 * ((n+1).log2 + 1) := by
    rw [Nat.log2_eq_log_two]
    exact Nat.succ_le_of_lt ((Nat.log_lt_of_lt_pow (by omega : nv + 1 ≠ 0) hp))
  calc
    _ ≤ C * (3 * (νb + 1)) * (2 * ((n+1).log2 + 1)) ^ a :=
      Nat.mul_le_mul (Nat.mul_le_mul_left _ (by omega)) (Nat.pow_le_pow_left hlog a)
    _ = _ := by rw [mul_pow]; ring

end SubmodularMatching.Capacity
