import SubmodularMatching.NonmonotoneAdaptiveOptimizer
import SubmodularMatching.NonmonotoneAmplification
import SubmodularMatching.UpperBoundFiniteExecution

/-! Averaging the implemented downstream row over fresh optimizer tapes. -/
namespace SubmodularMatching.AppendixM

open Finset GibbsSampler UpperBoundAssembly NonmonotoneOptimizer
open scoped BigOperators
noncomputable section

theorem good_row_average {A : Type*} (q : CandidateLaw A) (good : A → Bool) (F : A → ℝ) (opt : ℝ)
    (hn : ∀ a∈q.outcomes, 0≤F a) (ho : 0≤opt)
    (hbad : (∑ a∈q.outcomes, if good a then 0 else q.mass a) ≤ outerError)
    (hg : ∀ a∈q.outcomes, good a=true → (1000/4727+3*implementationUnit)*opt ≤ F a) :
    (1000/4727+2*implementationUnit)*opt ≤ expected q.outcomes q.mass F := by
  let β := (1000/4727+3*implementationUnit)
  let ok := ∑ a∈q.outcomes, if good a then q.mass a else 0
  have hb : 0≤β := by norm_num [β,implementationUnit]
  have tot : ok + (∑ a∈q.outcomes, if good a then 0 else q.mass a) = 1 := by
    unfold ok
    rw [←sum_add_distrib,←q.probability.total]
    exact sum_congr rfl (fun a _ => by cases good a <;> simp)
  have mass : 1-outerError ≤ ok := by linarith only [tot,hbad]
  have h : ok*(β*opt) ≤ expected q.outcomes q.mass F := by
    unfold ok
    rw [sum_mul]
    apply sum_le_sum
    intro a ha
    cases hgood : good a with
    | false => simp [hgood,mul_nonneg (q.probability.nonnegative a ha) (hn a ha)]
    | true => exact mul_le_mul_of_nonneg_left (hg a ha hgood) (q.probability.nonnegative a ha)
  have factor : 1000/4727+2*implementationUnit ≤ (1-outerError)*β := by norm_num [β,outerError,implementationUnit]
  exact (mul_le_mul_of_nonneg_right factor ho).trans ((by ring : ((1-outerError)*β)*opt=(1-outerError)*(β*opt)).le.trans
    ((mul_le_mul_of_nonneg_right mass (mul_nonneg hb ho)).trans h))

/-- This program runs roundWords on the real optimizer tape before selecting
the physical row. It never asks whether the answer transcript was accurate. -/
def optimizerTrial {m n l : ℕ} {A : Type*} [DecidableEq A] (J : ℕ)
    (row : OptimizerWords m n l (actionBatch l J) (actionBits l) → CandidateLaw A) : CandidateLaw A :=
  (BlockData.optimizerTapeLaw m n l J).bind (fun tape => row (roundWords tape))

theorem optimizerTrial_support {m n l : ℕ} {A : Type*} [DecidableEq A] (J : ℕ)
    (row : OptimizerWords m n l (actionBatch l J) (actionBits l) → CandidateLaw A)
    (valid : A → Prop) (hs : ∀ w a, a ∈ (row w).outcomes → valid a) :
    ∀ a∈(optimizerTrial J row).outcomes, valid a := by
  intro a ha
  obtain ⟨t,_,h⟩ := (CandidateLaw.mem_bind _ _ _).1 ha
  exact hs (roundWords t) a h

variable {E : Type*} [DecidableEq E] {m n l rows : ℕ} [NeZero n]

theorem optimizerTrial_value (B : BlockData E n l) (G : PackingGrid rows l) (h : ℕ→E) (p : ℕ→ℝ)
    (hp : ∀ i<m, 0≤p i ∧ p i≤1) (f : Finset E→ℝ) (τ opt : ℝ) (J : ℕ)
    {A : Type*} [DecidableEq A] (row : OptimizerWords m n l (actionBatch l J) (actionBits l) → CandidateLaw A)
    (value : A→ℝ) (hn : ∀ a, 0≤value a) (ho : 0≤opt) (hJ : 1/(J:ℝ)≤outerError) :
    let marked := B.markedOptimizerLaw G h p hp f τ J
    (∑ a∈marked.outcomes, if a.2 then 0 else marked.mass a) ≤ 1/(J:ℝ) →
    (∀ a∈marked.outcomes, a.2=true → (1000/4727+3*implementationUnit)*opt ≤
      expected (row a.1).outcomes (row a.1).mass value) →
    (1000/4727+2*implementationUnit)*opt ≤ expected (optimizerTrial J row).outcomes (optimizerTrial J row).mass value := by
  intro marked hbad hgood
  let gain := fun w => expected (row w).outcomes (row w).mass value
  have hnon (w) : 0≤gain w := sum_nonneg (fun a ha => mul_nonneg ((row w).probability.nonnegative _ ha) (hn a))
  have mval := good_row_average marked Prod.snd (fun a => gain a.1) opt (fun a _ => hnon a.1) ho (hbad.trans hJ) hgood
  have unflag := B.markedOptimizer_observable G h p hp f τ J gain
  unfold optimizerTrial
  rw [CandidateLaw.bind_expected]
  exact mval.trans_eq unflag

end
end SubmodularMatching.AppendixM
