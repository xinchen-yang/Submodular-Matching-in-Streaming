import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull019_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 859, 868, 1, 0x1b235b⟩ (by decide +kernel)

private def hull019_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 868, 886, 10, 0xdd9bab716e0dbdb53696ced99b2b64⟩ (by decide +kernel)

private def hull019_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 886, 922, 25, 0x1cd393722e41c7b8e71ae2dc5389710e15c2382702e01bfb7e6fadf1bdb7a6f2de1bbb76⟩ (by decide +kernel)

private def hull019_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 855, 1, 0x1abb53⟩ (by decide +kernel)

private def hull019_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 853, 2, 0xd55aa353⟩ (by decide +kernel)

private def hull019_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 853, 855, 1, 0x1abb55⟩ (by decide +kernel)

private def hull019_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 853, 854, 1, 0x1ab355⟩ (by decide +kernel)

private def hull019_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 854, 855, 1, 0x1abb56⟩ (by decide +kernel)

private def hull019_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 922, 39, 0x734e4dc8b9071ee39c6b8b714e25c4385708e09c0b806fedf9beb7c6f6de9bcb786eedd9bab716e0dbdb53696ced99b2b646b6d69acb53⟩ (by decide +kernel)

private def hull019_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 868, 4, 0x3646b6d69acb53⟩ (by decide +kernel)

private def hull019_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 855, 859, 4, 0x35b6b4d65ac357⟩ (by decide +kernel)

private def hull019_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 859, 3, 0x6b6d69acb53⟩ (by decide +kernel)

private def hull019_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 859, 863, 1, 0x1afb5b⟩ (by decide +kernel)

private def hull019_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 863, 868, 1, 0x1b235f⟩ (by decide +kernel)

private def hull019_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 859, 861, 1, 0x1aeb5b⟩ (by decide +kernel)

private def hull019_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 861, 863, 1, 0x1afb5d⟩ (by decide +kernel)

private def hull019_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 859, 860, 1, 0x1ae35b⟩ (by decide +kernel)

private def hull019_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 860, 861, 1, 0x1aeb5c⟩ (by decide +kernel)

private def hull019_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 861, 862, 1, 0x1af35d⟩ (by decide +kernel)

private def hull019_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 862, 863, 1, 0x1afb5e⟩ (by decide +kernel)

private def hull019_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 70, 61, 0x2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull019_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 863, 865, 1, 0x1b0b5f⟩ (by decide +kernel)

private def hull019_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 865, 868, 1, 0x1b2361⟩ (by decide +kernel)

private def hull019_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 863, 864, 1, 0x1b035f⟩ (by decide +kernel)

private def hull019_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 864, 865, 1, 0x1b0b60⟩ (by decide +kernel)

private def hull019_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 865, 866, 1, 0x1b1361⟩ (by decide +kernel)

private def hull019_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 866, 868, 2, 0xd91b1b62⟩ (by decide +kernel)

private def hull019_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 868, 872, 4, 0x3686ced99b2b64⟩ (by decide +kernel)

private def hull019_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 872, 877, 3, 0x6dada9b4b68⟩ (by decide +kernel)

private def hull019_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 877, 886, 5, 0x1bb3756e2dc1b7b6d⟩ (by decide +kernel)

private def hull019_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 868, 877, 6, 0xdb5b53696ced99b2b64⟩ (by decide +kernel)

private def hull019_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 37, 2, 0x9412023⟩ (by decide +kernel)

private def hull019_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 39, 4, 0x2704c09412023⟩ (by decide +kernel)

private def hull019_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 872, 874, 2, 0xda9b4b68⟩ (by decide +kernel)

private def hull019_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 874, 875, 1, 0x1b5b6a⟩ (by decide +kernel)

private def hull019_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 875, 877, 1, 0x1b6b6b⟩ (by decide +kernel)

private def hull019_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 875, 876, 1, 0x1b636b⟩ (by decide +kernel)

private def hull019_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 876, 877, 1, 0x1b6b6c⟩ (by decide +kernel)

private def hull019_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 35, 43, 8, 0x2b0540a41402704c09412023⟩ (by decide +kernel)

private def hull019_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 877, 878, 1, 0x1b736d⟩ (by decide +kernel)

private def hull019_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 878, 879, 1, 0x1b7b6e⟩ (by decide +kernel)

private def hull019_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 879, 881, 2, 0xdc5b836f⟩ (by decide +kernel)

private def hull019_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 881, 886, 2, 0xdd9bab71⟩ (by decide +kernel)

private def hull019_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 877, 881, 3, 0x6e2dc1b7b6d⟩ (by decide +kernel)

private def hull019_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 881, 883, 1, 0x1b9b71⟩ (by decide +kernel)

private def hull019_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 883, 886, 3, 0x6ecdd5ba373⟩ (by decide +kernel)

private def hull019_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 881, 882, 1, 0x1b9371⟩ (by decide +kernel)

private def hull019_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 882, 883, 1, 0x1b9b72⟩ (by decide +kernel)

private def hull019_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 141, 132, 0x8d11822c4508911021c4308510820c410811001fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull019_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 851, 886, 14, 0xdd9bab716e0dbdb53696ced99b2b646b6d69acb53⟩ (by decide +kernel)

private def hull019_050 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 886, 895, 9, 0x1bfb7e6fadf1bdb7a6f2de1bbb76⟩ (by decide +kernel)

private def hull019_051 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 56, 58, 2, 0xe81c838⟩ (by decide +kernel)

private def hull019_052 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 895, 899, 4, 0x383704e05c037f⟩ (by decide +kernel)

private def hull019_053 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 899, 904, 3, 0x710e15c2383⟩ (by decide +kernel)

private def hull019_054 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 904, 922, 10, 0xe69c9b91720e3dc738d716e29c4b88⟩ (by decide +kernel)

private def hull019_055 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 56, 61, 5, 0x1e83c0760e81c838⟩ (by decide +kernel)

private def hull019_056 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 52, 70, 18, 0x118228440861082084007e0f81e83c0760e81c83806e0d81a834⟩ (by decide +kernel)

private def supportedCone2432 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨859, 868, 859, 859, 868⟩, ⟨0, 0, 45000000000, 835784527, 2875000000000, 680871943283⟩⟩
    hull019_000 0 (by decide +kernel)

private def supportedCone2433 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨868, 886, 868, 868, 869⟩, ⟨0, 0, 5000000000, 93190285, 2920000000000, 681707727810⟩⟩
    hull019_001 0 (by decide +kernel)

private def supportedCone2434 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨886, 922, 886, 886, 887⟩, ⟨0, 0, 68461105815, 1453360163, 3072494535979, 684770783610⟩⟩
    hull019_002 0 (by decide +kernel)

private def supportedCone2435 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 855, 855, 851, 855⟩, ⟨20000000000, 337784524, 0, 0, 2860000000000, 680613399156⟩⟩
    hull019_003 1 (by decide +kernel)

private def supportedCone2436 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 853, 852, 851, 853⟩, ⟨5000000000, 84516364, 5000000000, 84969530, 2845000000000, 680360130996⟩⟩
    hull019_004 1 (by decide +kernel)

private def supportedCone2437 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨853, 855, 853, 853, 855⟩, ⟨0, 0, 10000000000, 168298630, 2850000000000, 680445100526⟩⟩
    hull019_005 0 (by decide +kernel)

private def supportedCone2438 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 853, 853, 852, 853⟩, ⟨5000000000, 84969530, 0, 0, 2850000000000, 680445100526⟩⟩
    hull019_004 2 (by decide +kernel)

private def supportedCone2439 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨853, 854, 853, 853, 854⟩, ⟨0, 0, 5000000000, 84737374, 2850000000000, 680445100526⟩⟩
    hull019_006 0 (by decide +kernel)

private def supportedCone2440 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨854, 855, 854, 854, 855⟩, ⟨0, 0, 5000000000, 83561256, 2855000000000, 680529837900⟩⟩
    hull019_007 0 (by decide +kernel)

private def supportedCone2441 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨853, 854, 854, 853, 854⟩, ⟨5000000000, 84737374, 0, 0, 2855000000000, 680529837900⟩⟩
    hull019_006 1 (by decide +kernel)

private def supportedCone2442 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 858, 857, 859⟩, ⟨5000000000, 85544279, 5000000000, 89256708, 2870000000000, 680782686575⟩⟩
    hull019_008 2 (by decide +kernel)

private def supportedCone2443 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨854, 855, 855, 854, 855⟩, ⟨5000000000, 83561256, 0, 0, 2860000000000, 680613399156⟩⟩
    hull019_007 1 (by decide +kernel)

private def supportedCone2444 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨853, 855, 855, 853, 855⟩, ⟨10000000000, 168298630, 0, 0, 2860000000000, 680613399156⟩⟩
    hull019_005 1 (by decide +kernel)

private def supportedCone2445 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 868, 868, 859, 868⟩, ⟨45000000000, 835784527, 0, 0, 2920000000000, 681707727810⟩⟩
    hull019_009 4 (by decide +kernel)

private def supportedCone2446 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 868, 858, 857, 859⟩, ⟨5000000000, 85544279, 5000000000, 89256708, 2870000000000, 680782686575⟩⟩
    hull019_009 2 (by decide +kernel)

private def supportedCone2447 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨855, 859, 856, 855, 857⟩, ⟨4000000000, 66888548, 1000000000, 16854592, 2864000000000, 680680287704⟩⟩
    hull019_010 1 (by decide +kernel)

private def supportedCone2448 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 859, 858, 868⟩, ⟨5000000000, 89256708, 45000000000, 835784527, 2875000000000, 680871943283⟩⟩
    hull019_008 3 (by decide +kernel)

private def supportedCone2449 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 859, 859, 858, 859⟩, ⟨5000000000, 89256708, 0, 0, 2875000000000, 680871943283⟩⟩
    hull019_011 3 (by decide +kernel)

private def supportedCone2450 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨859, 863, 859, 859, 863⟩, ⟨0, 0, 20000000000, 373745652, 2875000000000, 680871943283⟩⟩
    hull019_012 0 (by decide +kernel)

private def supportedCone2451 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨863, 868, 863, 863, 868⟩, ⟨0, 0, 25000000000, 462038875, 2895000000000, 681245688935⟩⟩
    hull019_013 0 (by decide +kernel)

private def supportedCone2452 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨859, 861, 859, 859, 861⟩, ⟨0, 0, 10000000000, 187262173, 2875000000000, 680871943283⟩⟩
    hull019_014 0 (by decide +kernel)

private def supportedCone2453 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨861, 863, 861, 861, 863⟩, ⟨0, 0, 10000000000, 186483479, 2885000000000, 681059205456⟩⟩
    hull019_015 0 (by decide +kernel)

private def supportedCone2454 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨859, 860, 859, 859, 860⟩, ⟨0, 0, 5000000000, 93676308, 2875000000000, 680871943283⟩⟩
    hull019_016 0 (by decide +kernel)

private def supportedCone2455 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨860, 861, 860, 860, 861⟩, ⟨0, 0, 5000000000, 93585865, 2880000000000, 680965619591⟩⟩
    hull019_017 0 (by decide +kernel)

private def supportedCone2456 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨859, 860, 860, 859, 860⟩, ⟨5000000000, 93676308, 0, 0, 2880000000000, 680965619591⟩⟩
    hull019_016 1 (by decide +kernel)

private def supportedCone2457 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨860, 861, 861, 860, 861⟩, ⟨5000000000, 93585865, 0, 0, 2885000000000, 681059205456⟩⟩
    hull019_017 1 (by decide +kernel)

private def supportedCone2458 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨859, 861, 861, 859, 861⟩, ⟨10000000000, 187262173, 0, 0, 2885000000000, 681059205456⟩⟩
    hull019_014 1 (by decide +kernel)

private def supportedCone2459 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨861, 862, 861, 861, 862⟩, ⟨0, 0, 5000000000, 93401804, 2885000000000, 681059205456⟩⟩
    hull019_018 0 (by decide +kernel)

private def supportedCone2460 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨862, 863, 862, 862, 863⟩, ⟨0, 0, 5000000000, 93081675, 2890000000000, 681152607260⟩⟩
    hull019_019 0 (by decide +kernel)

private def supportedCone2461 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨861, 862, 862, 861, 862⟩, ⟨5000000000, 93401804, 0, 0, 2890000000000, 681152607260⟩⟩
    hull019_018 1 (by decide +kernel)

private def supportedCone2462 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 45, 44, 46⟩, ⟨734647838, 50900754, 412549723, 29103357, 272000000000, 1356018148⟩⟩
    hull019_020 36 (by decide +kernel)

private def supportedCone2463 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 869, 868, 870⟩, ⟨5000000000, 93190285, 5000000000, 94232469, 2925000000000, 681800918095⟩⟩
    hull019_008 5 (by decide +kernel)

def appendixHullConeBlock0076 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2432,
    supportedCone2433,
    supportedCone2434,
    supportedCone2435,
    supportedCone2436,
    supportedCone2437,
    supportedCone2438,
    supportedCone2439,
    supportedCone2440,
    supportedCone2441,
    supportedCone2442,
    supportedCone2443,
    supportedCone2444,
    supportedCone2445,
    supportedCone2446,
    supportedCone2447,
    supportedCone2448,
    supportedCone2449,
    supportedCone2450,
    supportedCone2451,
    supportedCone2452,
    supportedCone2453,
    supportedCone2454,
    supportedCone2455,
    supportedCone2456,
    supportedCone2457,
    supportedCone2458,
    supportedCone2459,
    supportedCone2460,
    supportedCone2461,
    supportedCone2462,
    supportedCone2463,
  ], rfl⟩

private def supportedCone2464 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨862, 863, 863, 862, 863⟩, ⟨5000000000, 93081675, 0, 0, 2895000000000, 681245688935⟩⟩
    hull019_019 1 (by decide +kernel)

private def supportedCone2465 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨861, 863, 863, 861, 863⟩, ⟨10000000000, 186483479, 0, 0, 2895000000000, 681245688935⟩⟩
    hull019_015 1 (by decide +kernel)

private def supportedCone2466 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨859, 863, 863, 859, 863⟩, ⟨20000000000, 373745652, 0, 0, 2895000000000, 681245688935⟩⟩
    hull019_012 1 (by decide +kernel)

private def supportedCone2467 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨863, 865, 863, 863, 865⟩, ⟨0, 0, 10000000000, 185454255, 2895000000000, 681245688935⟩⟩
    hull019_021 0 (by decide +kernel)

private def supportedCone2468 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨865, 868, 865, 865, 868⟩, ⟨0, 0, 15000000000, 276584620, 2905000000000, 681431143190⟩⟩
    hull019_022 0 (by decide +kernel)

private def supportedCone2469 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨863, 864, 863, 863, 864⟩, ⟨0, 0, 5000000000, 92838718, 2895000000000, 681245688935⟩⟩
    hull019_023 0 (by decide +kernel)

private def supportedCone2470 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨864, 865, 864, 864, 865⟩, ⟨0, 0, 5000000000, 92615537, 2900000000000, 681338527653⟩⟩
    hull019_024 0 (by decide +kernel)

private def supportedCone2471 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨863, 864, 864, 863, 864⟩, ⟨5000000000, 92838718, 0, 0, 2900000000000, 681338527653⟩⟩
    hull019_023 1 (by decide +kernel)

private def supportedCone2472 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨864, 865, 865, 864, 865⟩, ⟨5000000000, 92615537, 0, 0, 2905000000000, 681431143190⟩⟩
    hull019_024 1 (by decide +kernel)

private def supportedCone2473 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 868, 859, 869⟩, ⟨45000000000, 835784527, 5000000000, 93190285, 2920000000000, 681707727810⟩⟩
    hull019_008 4 (by decide +kernel)

private def supportedCone2474 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨863, 865, 865, 863, 865⟩, ⟨10000000000, 185454255, 0, 0, 2905000000000, 681431143190⟩⟩
    hull019_021 1 (by decide +kernel)

private def supportedCone2475 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 40, 39, 41⟩, ⟨912885189, 53518492, 1466867611, 87366046, 265912885189, 963567077⟩⟩
    hull019_020 31 (by decide +kernel)

private def supportedCone2476 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨865, 866, 865, 865, 866⟩, ⟨0, 0, 5000000000, 92387388, 2905000000000, 681431143190⟩⟩
    hull019_025 0 (by decide +kernel)

private def supportedCone2477 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨866, 868, 866, 866, 867⟩, ⟨0, 0, 5000000000, 92083575, 2910000000000, 681523530578⟩⟩
    hull019_026 0 (by decide +kernel)

private def supportedCone2478 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨865, 866, 866, 865, 866⟩, ⟨5000000000, 92387388, 0, 0, 2910000000000, 681523530578⟩⟩
    hull019_025 1 (by decide +kernel)

private def supportedCone2479 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨866, 868, 867, 866, 868⟩, ⟨5000000000, 92083575, 5000000000, 92113657, 2915000000000, 681615614153⟩⟩
    hull019_026 1 (by decide +kernel)

private def supportedCone2480 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨866, 868, 868, 867, 868⟩, ⟨5000000000, 92113657, 0, 0, 2920000000000, 681707727810⟩⟩
    hull019_026 2 (by decide +kernel)

private def supportedCone2481 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨865, 868, 868, 865, 868⟩, ⟨15000000000, 276584620, 0, 0, 2920000000000, 681707727810⟩⟩
    hull019_022 1 (by decide +kernel)

private def supportedCone2482 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨863, 868, 868, 863, 868⟩, ⟨25000000000, 462038875, 0, 0, 2920000000000, 681707727810⟩⟩
    hull019_013 1 (by decide +kernel)

private def supportedCone2483 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 871, 870, 873⟩, ⟨5000000000, 95505920, 10000000000, 191554274, 2935000000000, 681990656484⟩⟩
    hull019_008 7 (by decide +kernel)

private def supportedCone2484 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 46, 45, 47⟩, ⟨412549723, 29103357, 1084869137, 78356954, 272412549723, 1385121505⟩⟩
    hull019_020 37 (by decide +kernel)

private def supportedCone2485 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨868, 872, 871, 870, 872⟩, ⟨5000000000, 95505920, 5000000000, 95942771, 2935000000000, 681990656484⟩⟩
    hull019_027 3 (by decide +kernel)

private def supportedCone2486 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨872, 877, 872, 872, 873⟩, ⟨0, 0, 5000000000, 95611503, 2940000000000, 682086599255⟩⟩
    hull019_028 0 (by decide +kernel)

private def supportedCone2487 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨877, 886, 877, 877, 879⟩, ⟨0, 0, 10000000000, 194547295, 2965000000000, 682571043990⟩⟩
    hull019_029 0 (by decide +kernel)

private def supportedCone2488 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 880, 879, 881⟩, ⟨5000000000, 97674803, 5000000000, 98650990, 2980000000000, 682863266088⟩⟩
    hull019_008 11 (by decide +kernel)

private def supportedCone2489 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨868, 872, 872, 871, 872⟩, ⟨5000000000, 95942771, 0, 0, 2940000000000, 682086599255⟩⟩
    hull019_027 4 (by decide +kernel)

private def supportedCone2490 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨868, 877, 871, 870, 873⟩, ⟨5000000000, 95505920, 10000000000, 191554274, 2935000000000, 681990656484⟩⟩
    hull019_030 3 (by decide +kernel)

private def supportedCone2491 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 37, 35, 35, 36⟩, ⟨0, 0, 1256580954, 61153129, 260000000000, 651686301⟩⟩
    hull019_031 0 (by decide +kernel)

private def supportedCone2492 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨868, 877, 870, 869, 871⟩, ⟨5000000000, 94232469, 5000000000, 95505920, 2930000000000, 681895150564⟩⟩
    hull019_030 2 (by decide +kernel)

private def supportedCone2493 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨868, 877, 868, 868, 869⟩, ⟨0, 0, 5000000000, 93190285, 2920000000000, 681707727810⟩⟩
    hull019_030 0 (by decide +kernel)

private def supportedCone2494 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 879, 874, 880⟩, ⟨25000000000, 487482502, 5000000000, 97674803, 2975000000000, 682765591285⟩⟩
    hull019_008 10 (by decide +kernel)

private def supportedCone2495 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨872, 877, 873, 872, 874⟩, ⟨5000000000, 95611503, 5000000000, 95898025, 2945000000000, 682182210758⟩⟩
    hull019_028 1 (by decide +kernel)

def appendixHullConeBlock0077 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2464,
    supportedCone2465,
    supportedCone2466,
    supportedCone2467,
    supportedCone2468,
    supportedCone2469,
    supportedCone2470,
    supportedCone2471,
    supportedCone2472,
    supportedCone2473,
    supportedCone2474,
    supportedCone2475,
    supportedCone2476,
    supportedCone2477,
    supportedCone2478,
    supportedCone2479,
    supportedCone2480,
    supportedCone2481,
    supportedCone2482,
    supportedCone2483,
    supportedCone2484,
    supportedCone2485,
    supportedCone2486,
    supportedCone2487,
    supportedCone2488,
    supportedCone2489,
    supportedCone2490,
    supportedCone2491,
    supportedCone2492,
    supportedCone2493,
    supportedCone2494,
    supportedCone2495,
  ], rfl⟩

private def supportedCone2496 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨868, 877, 874, 873, 877⟩, ⟨5000000000, 95898025, 15000000000, 292935207, 2950000000000, 682278108783⟩⟩
    hull019_030 5 (by decide +kernel)

private def supportedCone2497 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 37, 37, 36, 37⟩, ⟨1418082341, 71124003, 0, 0, 262674663295, 783963433⟩⟩
    hull019_031 2 (by decide +kernel)

private def supportedCone2498 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 873, 871, 874⟩, ⟨10000000000, 191554274, 5000000000, 95898025, 2945000000000, 682182210758⟩⟩
    hull019_008 8 (by decide +kernel)

private def supportedCone2499 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 874, 873, 879⟩, ⟨5000000000, 95898025, 25000000000, 487482502, 2950000000000, 682278108783⟩⟩
    hull019_008 9 (by decide +kernel)

private def supportedCone2500 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨868, 877, 877, 874, 877⟩, ⟨15000000000, 292935207, 0, 0, 2965000000000, 682571043990⟩⟩
    hull019_030 6 (by decide +kernel)

private def supportedCone2501 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 39, 35, 35, 36⟩, ⟨0, 0, 1256580954, 61153129, 260000000000, 651686301⟩⟩
    hull019_032 0 (by decide +kernel)

private def supportedCone2502 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨872, 874, 874, 873, 874⟩, ⟨5000000000, 95898025, 0, 0, 2950000000000, 682278108783⟩⟩
    hull019_033 2 (by decide +kernel)

private def supportedCone2503 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨874, 875, 875, 874, 875⟩, ⟨5000000000, 97730611, 0, 0, 2955000000000, 682375839394⟩⟩
    hull019_034 1 (by decide +kernel)

private def supportedCone2504 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨875, 877, 875, 875, 877⟩, ⟨0, 0, 10000000000, 195204596, 2955000000000, 682375839394⟩⟩
    hull019_035 0 (by decide +kernel)

private def supportedCone2505 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 39, 38, 37, 39⟩, ⟨1099837485, 58486581, 1225499220, 67598571, 263774500780, 842450014⟩⟩
    hull019_032 3 (by decide +kernel)

private def supportedCone2506 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨875, 876, 875, 875, 876⟩, ⟨0, 0, 5000000000, 97806170, 2955000000000, 682375839394⟩⟩
    hull019_036 0 (by decide +kernel)

private def supportedCone2507 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨876, 877, 876, 876, 877⟩, ⟨0, 0, 5000000000, 97398426, 2960000000000, 682473645564⟩⟩
    hull019_037 0 (by decide +kernel)

private def supportedCone2508 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨875, 876, 876, 875, 876⟩, ⟨5000000000, 97806170, 0, 0, 2960000000000, 682473645564⟩⟩
    hull019_036 1 (by decide +kernel)

private def supportedCone2509 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 56, 55, 57⟩, ⟨1000000000, 94363393, 717147340, 69057165, 285000000000, 2437006455⟩⟩
    hull019_020 47 (by decide +kernel)

private def supportedCone2510 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 43, 40, 39, 41⟩, ⟨912885189, 53518492, 1466867611, 87366046, 265912885189, 963567077⟩⟩
    hull019_038 5 (by decide +kernel)

private def supportedCone2511 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 43, 38, 37, 39⟩, ⟨1099837485, 58486581, 1225499220, 67598571, 263774500780, 842450014⟩⟩
    hull019_038 3 (by decide +kernel)

private def supportedCone2512 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 43, 37, 36, 38⟩, ⟨1418082341, 71124003, 1099837485, 58486581, 262674663295, 783963433⟩⟩
    hull019_038 2 (by decide +kernel)

private def supportedCone2513 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨876, 877, 877, 876, 877⟩, ⟨5000000000, 97398426, 0, 0, 2965000000000, 682571043990⟩⟩
    hull019_037 1 (by decide +kernel)

private def supportedCone2514 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨877, 878, 877, 877, 878⟩, ⟨0, 0, 5000000000, 97325643, 2965000000000, 682571043990⟩⟩
    hull019_039 0 (by decide +kernel)

private def supportedCone2515 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨878, 879, 878, 878, 879⟩, ⟨0, 0, 5000000000, 97221652, 2970000000000, 682668369633⟩⟩
    hull019_040 0 (by decide +kernel)

private def supportedCone2516 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨879, 881, 879, 879, 880⟩, ⟨0, 0, 5000000000, 97674803, 2975000000000, 682765591285⟩⟩
    hull019_041 0 (by decide +kernel)

private def supportedCone2517 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨881, 886, 881, 881, 885⟩, ⟨0, 0, 15000000000, 296408850, 2985000000000, 682961917078⟩⟩
    hull019_042 0 (by decide +kernel)

private def supportedCone2518 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨877, 878, 878, 877, 878⟩, ⟨5000000000, 97325643, 0, 0, 2970000000000, 682668369633⟩⟩
    hull019_039 1 (by decide +kernel)

private def supportedCone2519 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 885, 881, 886⟩, ⟨15000000000, 296408850, 72494535979, 1512457682, 3000000000000, 683258325928⟩⟩
    hull019_008 13 (by decide +kernel)

private def supportedCone2520 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨878, 879, 879, 878, 879⟩, ⟨5000000000, 97221652, 0, 0, 2975000000000, 682765591285⟩⟩
    hull019_040 1 (by decide +kernel)

private def supportedCone2521 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨877, 886, 879, 877, 880⟩, ⟨10000000000, 194547295, 5000000000, 97674803, 2975000000000, 682765591285⟩⟩
    hull019_029 1 (by decide +kernel)

private def supportedCone2522 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 881, 880, 885⟩, ⟨5000000000, 98650990, 15000000000, 296408850, 2985000000000, 682961917078⟩⟩
    hull019_008 12 (by decide +kernel)

private def supportedCone2523 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨877, 881, 881, 880, 881⟩, ⟨5000000000, 98650990, 0, 0, 2985000000000, 682961917078⟩⟩
    hull019_043 3 (by decide +kernel)

private def supportedCone2524 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨881, 883, 883, 881, 883⟩, ⟨10000000000, 197892918, 0, 0, 2995000000000, 683159809996⟩⟩
    hull019_044 1 (by decide +kernel)

private def supportedCone2525 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨883, 886, 883, 883, 884⟩, ⟨0, 0, 1000000000, 19662696, 2995000000000, 683159809996⟩⟩
    hull019_045 0 (by decide +kernel)

private def supportedCone2526 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨881, 882, 881, 881, 882⟩, ⟨0, 0, 5000000000, 99192655, 2985000000000, 682961917078⟩⟩
    hull019_046 0 (by decide +kernel)

private def supportedCone2527 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨882, 883, 882, 882, 883⟩, ⟨0, 0, 5000000000, 98700263, 2990000000000, 683061109733⟩⟩
    hull019_047 0 (by decide +kernel)

def appendixHullConeBlock0078 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2496,
    supportedCone2497,
    supportedCone2498,
    supportedCone2499,
    supportedCone2500,
    supportedCone2501,
    supportedCone2502,
    supportedCone2503,
    supportedCone2504,
    supportedCone2505,
    supportedCone2506,
    supportedCone2507,
    supportedCone2508,
    supportedCone2509,
    supportedCone2510,
    supportedCone2511,
    supportedCone2512,
    supportedCone2513,
    supportedCone2514,
    supportedCone2515,
    supportedCone2516,
    supportedCone2517,
    supportedCone2518,
    supportedCone2519,
    supportedCone2520,
    supportedCone2521,
    supportedCone2522,
    supportedCone2523,
    supportedCone2524,
    supportedCone2525,
    supportedCone2526,
    supportedCone2527,
  ], rfl⟩

private def supportedCone2528 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨881, 882, 882, 881, 882⟩, ⟨5000000000, 99192655, 0, 0, 2990000000000, 683061109733⟩⟩
    hull019_046 1 (by decide +kernel)

private def supportedCone2529 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨882, 883, 883, 882, 883⟩, ⟨5000000000, 98700263, 0, 0, 2995000000000, 683159809996⟩⟩
    hull019_047 1 (by decide +kernel)

private def supportedCone2530 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨883, 886, 884, 883, 885⟩, ⟨1000000000, 19662696, 4000000000, 78853236, 2996000000000, 683179472692⟩⟩
    hull019_045 1 (by decide +kernel)

private def supportedCone2531 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨883, 886, 885, 884, 886⟩, ⟨4000000000, 78853236, 72494535979, 1512457682, 3000000000000, 683258325928⟩⟩
    hull019_045 2 (by decide +kernel)

private def supportedCone2532 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨35, 43, 35, 35, 36⟩, ⟨0, 0, 1256580954, 61153129, 260000000000, 651686301⟩⟩
    hull019_038 0 (by decide +kernel)

private def supportedCone2533 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 886, 885, 887⟩, ⟨72494535979, 1512457682, 68461105815, 1453360163, 3072494535979, 684770783610⟩⟩
    hull019_008 14 (by decide +kernel)

private def supportedCone2534 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 121, 120, 122⟩, ⟨5000000000, 1915304082, 2000000000, 812414497, 390000000000, 23533747731⟩⟩
    hull019_048 112 (by decide +kernel)

private def supportedCone2535 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 122, 121, 123⟩, ⟨2000000000, 812414497, 3000000000, 1237421677, 392000000000, 24346162228⟩⟩
    hull019_048 113 (by decide +kernel)

private def supportedCone2536 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 887, 886, 888⟩, ⟨68461105815, 1453360163, 36805533738, 853988727, 3140955641794, 686224143773⟩⟩
    hull019_008 15 (by decide +kernel)

private def supportedCone2537 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 888, 887, 889⟩, ⟨36805533738, 853988727, 36254107532, 854439369, 3177761175532, 687078132500⟩⟩
    hull019_008 16 (by decide +kernel)

private def supportedCone2538 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 889, 888, 890⟩, ⟨36254107532, 854439369, 69902387126, 1648479935, 3214015283064, 687932571869⟩⟩
    hull019_008 17 (by decide +kernel)

private def supportedCone2539 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 890, 889, 891⟩, ⟨69902387126, 1648479935, 16281406043, 392941347, 3283917670190, 689581051804⟩⟩
    hull019_008 18 (by decide +kernel)

private def supportedCone2540 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 891, 890, 892⟩, ⟨16281406043, 392941347, 9518065143, 234958180, 3300199076233, 689973993151⟩⟩
    hull019_008 19 (by decide +kernel)

private def supportedCone2541 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 892, 891, 893⟩, ⟨9518065143, 234958180, 8332060821, 208777523, 3309717141376, 690208951331⟩⟩
    hull019_008 20 (by decide +kernel)

private def supportedCone2542 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 893, 892, 894⟩, ⟨8332060821, 208777523, 12517430593, 323291191, 3318049202197, 690417728854⟩⟩
    hull019_008 21 (by decide +kernel)

private def supportedCone2543 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 894, 893, 895⟩, ⟨12517430593, 323291191, 35488730116, 936693279, 3330566632790, 690741020045⟩⟩
    hull019_008 22 (by decide +kernel)

private def supportedCone2544 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 895, 894, 896⟩, ⟨35488730116, 936693279, 28676703117, 759743449, 3366055362906, 691677713324⟩⟩
    hull019_008 23 (by decide +kernel)

private def supportedCone2545 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 896, 895, 897⟩, ⟨28676703117, 759743449, 70953060128, 1884547540, 3394732066023, 692437456773⟩⟩
    hull019_008 24 (by decide +kernel)

private def supportedCone2546 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 897, 896, 898⟩, ⟨70953060128, 1884547540, 58946236644, 1727350049, 3465685126151, 694322004313⟩⟩
    hull019_008 25 (by decide +kernel)

private def supportedCone2547 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 900, 898, 901⟩, ⟨70073725405, 2055461131, 30104196872, 922253986, 3594705088200, 698104815493⟩⟩
    hull019_008 27 (by decide +kernel)

private def supportedCone2548 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 898, 897, 900⟩, ⟨58946236644, 1727350049, 70073725405, 2055461131, 3524631362795, 696049354362⟩⟩
    hull019_008 26 (by decide +kernel)

private def supportedCone2549 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 886, 886, 885, 886⟩, ⟨72494535979, 1512457682, 0, 0, 3072494535979, 684770783610⟩⟩
    hull019_049 14 (by decide +kernel)

private def supportedCone2550 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨886, 895, 895, 894, 895⟩, ⟨35488730116, 936693279, 0, 0, 3366055362906, 691677713324⟩⟩
    hull019_050 9 (by decide +kernel)

private def supportedCone2551 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨56, 58, 57, 56, 58⟩, ⟨717147340, 69057165, 1502580336, 149488808, 285717147340, 2506063620⟩⟩
    hull019_051 1 (by decide +kernel)

private def supportedCone2552 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨895, 899, 898, 897, 899⟩, ⟨58946236644, 1727350049, 40875319516, 1199857610, 3524631362795, 696049354362⟩⟩
    hull019_052 3 (by decide +kernel)

private def supportedCone2553 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨56, 58, 56, 56, 57⟩, ⟨0, 0, 717147340, 69057165, 285000000000, 2437006455⟩⟩
    hull019_051 0 (by decide +kernel)

private def supportedCone2554 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨899, 904, 899, 899, 900⟩, ⟨0, 0, 29198405889, 855603521, 3565506682311, 697249211972⟩⟩
    hull019_053 0 (by decide +kernel)

private def supportedCone2555 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨904, 922, 904, 904, 905⟩, ⟨0, 0, 52336704843, 1713766016, 3697558031820, 701273218654⟩⟩
    hull019_054 0 (by decide +kernel)

private def supportedCone2556 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨895, 899, 899, 898, 899⟩, ⟨40875319516, 1199857610, 0, 0, 3565506682311, 697249211972⟩⟩
    hull019_052 4 (by decide +kernel)

private def supportedCone2557 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨56, 61, 61, 60, 61⟩, ⟨1317712249, 141660608, 0, 0, 291317712249, 3079499459⟩⟩
    hull019_055 5 (by decide +kernel)

private def supportedCone2558 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨851, 922, 901, 900, 904⟩, ⟨30104196872, 922253986, 72748746748, 2246149175, 3624809285072, 699027069479⟩⟩
    hull019_008 28 (by decide +kernel)

private def supportedCone2559 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨52, 70, 70, 69, 70⟩, ⟨840721629, 103780683, 0, 0, 301402788396, 4247784051⟩⟩
    hull019_056 18 (by decide +kernel)

def appendixHullConeBlock0079 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone2528,
    supportedCone2529,
    supportedCone2530,
    supportedCone2531,
    supportedCone2532,
    supportedCone2533,
    supportedCone2534,
    supportedCone2535,
    supportedCone2536,
    supportedCone2537,
    supportedCone2538,
    supportedCone2539,
    supportedCone2540,
    supportedCone2541,
    supportedCone2542,
    supportedCone2543,
    supportedCone2544,
    supportedCone2545,
    supportedCone2546,
    supportedCone2547,
    supportedCone2548,
    supportedCone2549,
    supportedCone2550,
    supportedCone2551,
    supportedCone2552,
    supportedCone2553,
    supportedCone2554,
    supportedCone2555,
    supportedCone2556,
    supportedCone2557,
    supportedCone2558,
    supportedCone2559,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
