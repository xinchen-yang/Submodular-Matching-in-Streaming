import SubmodularMatching.NonmonotoneRetainedLayout
import SubmodularMatching.NonmonotoneRetainedRuntimeQuality

/-! Quality of the original-label output obtained from the actual nonempty
retained records, for the decisive accurate stream guess. -/
namespace SubmodularMatching.AppendixM
open Capacity UpperBoundAssembly Finset Streaming GibbsSampler
open TwoLayerDiffuse
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

set_option maxRecDepth 6000 in
theorem postprocess_quality (S : SimpleEdgeStream E V) (b : V → ℕ) (hb : ∀ i,0<b i)
    (rank : Slots b ↪ ℕ) (f : Finset E → ℝ) (q J : ℕ) (τ : ℝ) (st : SparseSlots E b)
    (M : Finset E) (ht : 0<τ) (hopt : τ≤2*f M) (hf : IsSubmodular f) (hn : ∀ T,0≤f T)
    (C : PotentialConfig) (hp : (sourceProbability:ℝ) = C.p) (hτ : C.tau = τ)
    (k : ℕ) (edge : ℕ→E) (idx : ℕ→ℕ)
    (l : (e:E) → Fin (b (S.ends e).1)) (r : (e:E) → Fin (b (S.ends e).2))
    (hord : st.assigned.map Prod.fst = st.machine.edges.map Prod.fst)
    (hpair : ∀ a∈st.assigned, a.2=slotPair S.ends b l r a.1)
    (D : RetainedPassData C S.ends b (slotPair S.ends b l r) ((Fintype.card V)^2) k edge idx f M τ st.machine.edges)
    (hs : 0 < (st.machine.edges.map Prod.fst).length)
    (hJ : 0<J) (hfails : 1/(J:ℝ)≤outerError) (hcap : ∀ i,b i ≤ 2^q) :
    let out := postprocess S b hb rank f q J τ st
    (1000/4727+2*implementationUnit)*f M ≤ expected out.outcomes out.mass f := by
  dsimp only
  let v := (Fintype.card V)^2
  let g := layoutGuard_of_witness S b st l r hord hpair D.nodup hs
  let R := retainedLayout S b st g
  have pairEq := retainedLayout_pair S b st g l r hord hpair
  have good := R.indexedRetainedProgram_quality C hp (slotPair S.ends b l r) pairEq v k edge idx f M τ
    ht hopt hτ hf hn D J hJ hfails hb rank q hcap
  rw [postprocess_layout S b hb rank f q J τ st g]
  exact (R.indexedRetainedRegisters_observe v q hb rank f f J τ).ge.trans' good

end
end SubmodularMatching.AppendixM
