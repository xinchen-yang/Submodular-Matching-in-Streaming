import SubmodularMatching.ProjectedShearerNoisy
import Mathlib.Data.Finset.Sort
import Mathlib.Data.Prod.Lex

/-! # Reading the scan's two scores as sums over marked copies -/

namespace SubmodularMatching.Shearer
open scoped BigOperators

variable {E V L : Type*} [DecidableEq E] [DecidableEq V] [DecidableEq L]
variable (ends : E → Finset V) (label : E → L) (h : Finset L → ℝ)

/-- Copies present strictly before the chosen time. -/
def earlierAt (time : E → ℕ) (M : Finset E) (t : ℕ) : Finset E := M.filter (fun e => time e < t)

noncomputable def scoreAt (time : E → ℕ) (M : Finset E) (e : E) :=
  priorityScore ends label h (earlierAt time M (time e)) e

noncomputable def survivingAt (time : E → ℕ) (M : Finset E) (e : E) : ℝ := by
  classical
  exact if ∀ a ∈ earlierAt time M (time e), Disjoint (ends a) (ends e) then
    scoreAt ends label h time M e else 0

/-- Pathwise identities for the scan in strict chronological order. -/
theorem priorityScan_time_scores (time : E → ℕ) (es : List E)
    (hn : es.Pairwise (fun a b => time a < time b)) :
    (priorityScan ends label h es).scores = ∑ e ∈ es.toFinset, scoreAt ends label h time es.toFinset e ∧
    (priorityScan ends label h es).survivingScores = ∑ e ∈ es.toFinset, survivingAt ends label h time es.toFinset e := by
  classical
  let S := es.toFinset
  let f := scoreAt ends label h time S
  let g := survivingAt ends label h time S
  have aux (rest : List E) (st : PriorityScanState E) (ho : rest.Pairwise (fun a b => time a < time b))
      (hc : ∀ e ∈ rest, earlierAt time S (time e) = st.earlier ∪ earlierAt time rest.toFinset (time e)) :
      let out := rest.foldl (priorityStep ends label h) st
      out.scores = st.scores + ∑ e ∈ rest.toFinset, f e ∧
      out.survivingScores = st.survivingScores + ∑ e ∈ rest.toFinset, g e := by
    induction rest generalizing st with
    | nil => simp
    | cons e xs ih =>
      obtain ⟨first,sorted⟩ := List.pairwise_cons.mp ho
      have hnot : e ∉ xs := fun he => (lt_irrefl _ (first e he))
      have hempty : earlierAt time (e::xs).toFinset (time e) = ∅ := by
        apply Finset.eq_empty_iff_forall_notMem.mpr
        intro a ha
        obtain ⟨hl,ht⟩ := Finset.mem_filter.mp ha
        rcases List.mem_cons.mp (List.mem_toFinset.mp hl) with rfl | hx
        · exact lt_irrefl _ ht
        · exact (first _ hx).not_gt ht
      have hpre : earlierAt time S (time e) = st.earlier := by
        simpa only [hempty,Finset.union_empty] using hc e List.mem_cons_self
      have hprefix (b : E) (hb : b ∈ xs) : earlierAt time S (time b) =
          (priorityStep ends label h st e).earlier ∪ earlierAt time xs.toFinset (time b) := by
        rw [hc b (List.mem_cons_of_mem _ hb)]
        simp [earlierAt,Finset.filter_insert,first b hb,priorityStep,Finset.insert_union]
      obtain ⟨h1,h2⟩ := ih (priorityStep ends label h st e) sorted hprefix
      have heq : f e = priorityScore ends label h st.earlier e := by simp [f,scoreAt,hpre]
      have hkeep : (if (∀ a ∈ st.earlier, Disjoint (ends a) (ends e)) ∧ 0 < f e then f e else 0) = g e := by
        have nonneg : 0 ≤ f e := by rw [heq]; exact priorityScore_nonnegative _ _ _ _ _
        dsimp [g,survivingAt]
        rw [hpre,← show f e = scoreAt ends label h time S e from rfl]
        by_cases hc' : ∀ a ∈ st.earlier, Disjoint (ends a) (ends e)
        · by_cases hp : 0 < f e
          · simp [hc',hp]
          · simp [hc',hp,le_antisymm (le_of_not_gt hp) nonneg]
        · simp [hc']
      simp only [List.foldl_cons,List.toFinset_cons,Finset.sum_insert (by simpa using hnot : e ∉ xs.toFinset)]
      simp only [priorityStep,← heq,hkeep] at h1 h2 ⊢
      exact ⟨by linarith only [h1],by linarith only [h2]⟩
  simpa only [priorityScan,zero_add] using aux es ⟨∅,∅,0,0⟩ hn (by simp [S])

private def timeKeyLE [LinearOrder E] (time : E → ℕ) (a b : E) : Prop :=
  toLex (time a,a) ≤ toLex (time b,b)

private instance [LinearOrder E] (time : E → ℕ) : DecidableRel (timeKeyLE time) :=
  fun a b => inferInstanceAs (Decidable (toLex (time a,a) ≤ toLex (time b,b)))
private instance [LinearOrder E] (time : E → ℕ) : IsTrans E (timeKeyLE time) :=
  ⟨fun _ _ _ hab hbc => LE.le.trans hab hbc⟩
private instance [LinearOrder E] (time : E → ℕ) : Std.Antisymm (timeKeyLE time) :=
  ⟨fun _ _ hab hba => congrArg (fun z : Lex (ℕ × E) => (ofLex z).2) (le_antisymm hab hba)⟩
private instance [LinearOrder E] (time : E → ℕ) : Std.Total (timeKeyLE time) :=
  ⟨fun a b => le_total (toLex (time a,a)) (toLex (time b,b))⟩

/-- A sorted list of a finite marked sample, with one copy per marked
coordinate. The ordering within tied bins is resolved by a supplied
linear order. -/
noncomputable def priorityOrder [LinearOrder E] (time : E → ℕ) (S : Finset E) : List E :=
  S.sort (timeKeyLE time)

theorem priorityOrder_ground [LinearOrder E] (time : E → ℕ) (S : Finset E) :
    (priorityOrder time S).toFinset = S := by unfold priorityOrder; exact Finset.sort_toFinset _ _

theorem priorityOrder_strict [LinearOrder E] (time : E → ℕ) (S : Finset E)
    (hi : Set.InjOn time (S : Set E)) : (priorityOrder time S).Pairwise (fun a b => time a < time b) := by
  have hsort : (priorityOrder time S).Pairwise (fun a b => toLex (time a,a) ≤ toLex (time b,b)) := by
    unfold priorityOrder
    exact Finset.pairwise_sort S (timeKeyLE time)
  have hn : (priorityOrder time S).Nodup := by unfold priorityOrder; exact Finset.sort_nodup _ _
  apply (hsort.and hn).imp_of_mem
  intro a b ha hb hh
  rcases Prod.Lex.toLex_le_toLex.mp hh.1 with ht | he
  · exact ht
  · have hmem (z : E) (hz : z ∈ priorityOrder time S) : z ∈ S := by
      rw [← priorityOrder_ground time S]; exact List.mem_toFinset.mpr hz
    exact (hh.2 (hi (hmem a ha) (hmem b hb) he.1)).elim

/-- Dropping an entire tied realization makes the loss explicit. On each
untied order, the two sums are the exact chronological scan quantities. -/
theorem priorityOrder_bounds [LinearOrder E] (time : E → ℕ) (S : Finset E)
    (hf : IsSubmodular h) (hi : Set.InjOn time (S : Set E)) :
    let st := priorityScan ends label h (priorityOrder time S)
    h (S.image label) - h ∅ ≤ ∑ e ∈ S, scoreAt ends label h time S e ∧
    (∑ e ∈ S, survivingAt ends label h time S e) ≤ h (st.kept.image label) - h ∅ := by
  intro st
  have hv := priorityScan_scores ends label h hf (priorityOrder time S)
  have hs := priorityScan_time_scores ends label h time (priorityOrder time S) (priorityOrder_strict time S hi)
  rw [priorityOrder_ground] at hs
  have hs' := hv.2.2
  rw [priorityScan_earlier,priorityOrder_ground,hs.1,hs.2] at hs'
  exact hs'

end SubmodularMatching.Shearer
