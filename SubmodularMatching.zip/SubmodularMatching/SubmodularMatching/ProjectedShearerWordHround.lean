import SubmodularMatching.ProjectedShearerWordTrial
import SubmodularMatching.NonmonotonePhysicalTrialMargin

/-! # Actual finite-word signed-priority and calibrated Gibbs output -/
namespace SubmodularMatching.NonmonotoneCandidate
open MeasureTheory Streaming UpperBoundAssembly GibbsSampler GibbsMatching Shearer AppendixM
open scoped BigOperators
noncomputable section
variable {I E V L : Type*} [LinearOrder I] [LinearOrder E] [DecidableEq V] [DecidableEq L]

private noncomputable instance : LinearOrder (E×ℕ) := LinearOrder.lift' (fun p : E×ℕ => toLex p) toLex.injective

abbrev PriorityEstimate (E : Type*) := Finset (E×ℕ) → E×ℕ → ℝ

def priorityLabels (base : E→Finset V) (S : Finset E) (a b : ℕ) (lab : E→L)
    (h : Finset L→ℝ) (est : PriorityEstimate E) (z : Marked base S a × Marked base S b) :=
  (estimatedOutput base lab h est z.1.val z.2.val).image (binLabel lab)

/-- Outer word batches followed by the actual marked first-stage sampler
and the finite Gibbs sampler. Only paired original-oracle evaluations
determine priority decisions. -/
def wordGibbsTrial (base : E→Finset V) (S : Finset E) (a b : ℕ) (lab : E→L)
    (first : CandidateLaw (Marked base S a × Marked base S b))
    {v : ℕ} (ep : I→Fin v×Fin v) (keep : Finset I) (num : (Marked base S a × Marked base S b)→I→ℕ)
    (k Q D : ℕ) (label : I ↪ L)
    (hist : ℕ→L) (s N bits : ℕ) (p : ℝ) (hp : 0≤p ∧ p≤1) (f : Finset L→ℝ) (ε : ℝ) : CandidateLaw (Finset L) :=
  (CandidateLaw.ofMeasure (wordBatchLaw N s bits)).bind fun ω =>
    trial first ep keep num k Q D (priorityLabels base S a b lab (shiftResidual hist p f s) fun A e =>
      priorityWordEstimate hist s N bits p hp f ε ω (A.image (binLabel lab)) (binLabel lab e)) label

theorem wordGibbsTrial_margin (base : E→Finset V) (S : Finset E) (he : ∀ e∈S,(base e).card=2)
    (a b : ℕ) (lab : E→L) (first : CandidateLaw (Marked base S a × Marked base S b))
    {v : ℕ} (ep : I→Fin v×Fin v) (keep : Finset I) (num : (Marked base S a × Marked base S b)→I→ℕ)
    (k Q D : ℕ) (label : I ↪ L) (hist : ℕ→L) (s N bits : ℕ) (p : ℝ) (hp : 0≤p ∧ p≤1)
    (f : Finset L→ℝ) (H ε : ℝ) (hr : ∀ U, 0≤f U ∧ f U≤H) (hε : 0<ε) (hN : 0<N)
    (hw : s*(1/(2:ℝ)^bits)*(H-(-H)) ≤ ε/64) (value : ℝ) :
    let h := shiftResidual hist p f s
    let test (est : PriorityEstimate E) := trial first ep keep num k Q D (priorityLabels base S a b lab h est) label
    (∀ est : PriorityEstimate E, (∀ A e, |est A e-marginal h (binLabel lab e) (A.image (binLabel lab))| ≤ ε) →
      value ≤ expected (test est).outcomes (test est).mass f) →
    let out := wordGibbsTrial base S a b lab first ep keep num k Q D label hist s N bits p hp f ε
    value-(2*S.card)*(2*Real.exp (-(2*N*(ε/2)^2)/(H-(-H))^2))*H ≤ expected out.outcomes out.mass f := by
  classical
  intro h test certified out
  let els := fun (z : Marked base S a × Marked base S b) => priorityOrder Prod.snd (z.1.val∪z.2.val)
  let g := fun (z : Marked base S a × Marked base S b) (T : Finset (E×ℕ)) =>
    (kernel ep keep (num z) k Q D).map (fun M => T.image (binLabel lab) ∪ M.image label)
  have count (z : Marked base S a × Marked base S b) (_ : z∈first.outcomes) : (els z).length ≤ 2*S.card := by
    have h₁ := markedMatching_card_le base S he a z.1.val z.1.property
    have h₂ := markedMatching_card_le base S he b z.2.val z.2.property
    have card := Finset.card_union_le z.1.val z.2.val
    have eql : (els z).length = (z.1.val∪z.2.val).card := by simp [els,priorityOrder]
    omega
  have rank := priorityWordTrial_transfer first els (2*S.card) count (binEnds base) (binLabel lab) hist s N bits p hp f H ε hr
    hε hN hw g f H value ((hr ∅).1.trans (hr ∅).2)
  have bound (z : Marked base S a × Marked base S b) (A : Finset (E×ℕ)) :
      0 ≤ expected (g z A).outcomes (g z A).mass f ∧ expected (g z A).outcomes (g z A).mass f ≤ H :=
    expectation_range _ _ (g z A).probability f H (fun M _ => hr M)
  have use := rank (fun z _ ω => ⟨(bound z _).1,(bound z _).2⟩) (by
    intro ω
    let target := fun (A : Finset (E×ℕ)) (e : E×ℕ) => marginal h (binLabel lab e) (A.image (binLabel lab))
    let raw := fun (A : Finset (E×ℕ)) (e : E×ℕ) =>
      priorityWordEstimate hist s N bits p hp f ε ω (A.image (binLabel lab)) (binLabel lab e)
    have hs := certified (checkedEstimate target raw ε) (checkedEstimate_error target raw ε hε.le)
    change value ≤ expected (first.bind _).outcomes (first.bind _).mass f at hs
    rw [CandidateLaw.bind_expected] at hs
    exact hs)
  simpa only [Nat.cast_mul,Nat.cast_ofNat] using use

/-- Every outcome of a word mixture is already in the support of a single
deterministic-sign trial on the same first-stage and Gibbs words. -/
theorem wordGibbsTrial_support (base : E→Finset V) (S : Finset E) (a b : ℕ) (lab : E→L)
    (first : CandidateLaw (Marked base S a × Marked base S b))
    {v : ℕ} (ep : I→Fin v×Fin v) (keep : Finset I) (num : (Marked base S a × Marked base S b)→I→ℕ)
    (k Q D : ℕ) (label : I ↪ L) (hist : ℕ→L) (s N bits : ℕ) (p : ℝ) (hp : 0≤p ∧ p≤1)
    (f : Finset L→ℝ) (ε : ℝ) (P : Finset L→Prop)
    (h : ∀ estimate M, M∈(trial first ep keep num k Q D (priorityLabels base S a b lab (shiftResidual hist p f s) estimate) label).outcomes → P M) :
    ∀ M ∈ (wordGibbsTrial base S a b lab first ep keep num k Q D label hist s N bits p hp f ε).outcomes, P M := by
  intro M hm
  obtain ⟨ω,_,hw⟩ := (CandidateLaw.mem_bind _ _ M).mp hm
  exact h _ M hw

end
end SubmodularMatching.NonmonotoneCandidate
