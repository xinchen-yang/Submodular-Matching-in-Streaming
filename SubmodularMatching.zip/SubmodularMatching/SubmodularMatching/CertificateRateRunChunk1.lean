import SubmodularMatching.CertificateRateRunCheck

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 18000
set_option maxHeartbeats 5000000

private abbrev blockEnd := sourceRates18432.headD lastRate

private theorem chunkSize09 : sourceRates09216.length = 1024 := by decide +kernel
private theorem chunkSize10 : sourceRates10240.length = 1024 := by decide +kernel
private theorem chunkSize11 : sourceRates11264.length = 1024 := by decide +kernel
private theorem chunkSize12 : sourceRates12288.length = 1024 := by decide +kernel
private theorem chunkSize13 : sourceRates13312.length = 1024 := by decide +kernel
private theorem chunkSize14 : sourceRates14336.length = 1024 := by decide +kernel
private theorem chunkSize15 : sourceRates15360.length = 1024 := by decide +kernel
private theorem chunkSize16 : sourceRates16384.length = 1024 := by decide +kernel
private theorem chunkSize17 : sourceRates17408.length = 1024 := by decide +kernel

private def chunkSuffix17 : List (List RawSourceMode) := sourceRates17408 :: []
private def chunkSuffix16 : List (List RawSourceMode) := sourceRates16384 :: chunkSuffix17
private def chunkSuffix15 : List (List RawSourceMode) := sourceRates15360 :: chunkSuffix16
private def chunkSuffix14 : List (List RawSourceMode) := sourceRates14336 :: chunkSuffix15
private def chunkSuffix13 : List (List RawSourceMode) := sourceRates13312 :: chunkSuffix14
private def chunkSuffix12 : List (List RawSourceMode) := sourceRates12288 :: chunkSuffix13
private def chunkSuffix11 : List (List RawSourceMode) := sourceRates11264 :: chunkSuffix12
private def chunkSuffix10 : List (List RawSourceMode) := sourceRates10240 :: chunkSuffix11
private def chunkSuffix09 : List (List RawSourceMode) := sourceRates09216 :: chunkSuffix10

private theorem chunkChecked17 :
    checkAdjacentAt checkRateStep (([] : List (List RawSourceMode)).flatten.headD blockEnd) 17408 sourceRates17408 = true := by decide +kernel

private theorem suffixChecked17 :
    checkAdjacentChunks checkRateStep blockEnd 17408 chunkSuffix17 = true := by
  simp only [chunkSuffix17, checkAdjacentChunks, chunkChecked17, Bool.true_and]

private theorem chunkChecked16 :
    checkAdjacentAt checkRateStep (chunkSuffix17.flatten.headD blockEnd) 16384 sourceRates16384 = true := by decide +kernel

private theorem suffixChecked16 :
    checkAdjacentChunks checkRateStep blockEnd 16384 chunkSuffix16 = true := by
  simp only [chunkSuffix16, checkAdjacentChunks, chunkChecked16, chunkSize16, Nat.reduceAdd, suffixChecked17, Bool.true_and]

private theorem chunkChecked15 :
    checkAdjacentAt checkRateStep (chunkSuffix16.flatten.headD blockEnd) 15360 sourceRates15360 = true := by decide +kernel

private theorem suffixChecked15 :
    checkAdjacentChunks checkRateStep blockEnd 15360 chunkSuffix15 = true := by
  simp only [chunkSuffix15, checkAdjacentChunks, chunkChecked15, chunkSize15, Nat.reduceAdd, suffixChecked16, Bool.true_and]

private theorem chunkChecked14 :
    checkAdjacentAt checkRateStep (chunkSuffix15.flatten.headD blockEnd) 14336 sourceRates14336 = true := by decide +kernel

private theorem suffixChecked14 :
    checkAdjacentChunks checkRateStep blockEnd 14336 chunkSuffix14 = true := by
  simp only [chunkSuffix14, checkAdjacentChunks, chunkChecked14, chunkSize14, Nat.reduceAdd, suffixChecked15, Bool.true_and]

private theorem chunkChecked13 :
    checkAdjacentAt checkRateStep (chunkSuffix14.flatten.headD blockEnd) 13312 sourceRates13312 = true := by decide +kernel

private theorem suffixChecked13 :
    checkAdjacentChunks checkRateStep blockEnd 13312 chunkSuffix13 = true := by
  simp only [chunkSuffix13, checkAdjacentChunks, chunkChecked13, chunkSize13, Nat.reduceAdd, suffixChecked14, Bool.true_and]

private theorem chunkChecked12 :
    checkAdjacentAt checkRateStep (chunkSuffix13.flatten.headD blockEnd) 12288 sourceRates12288 = true := by decide +kernel

private theorem suffixChecked12 :
    checkAdjacentChunks checkRateStep blockEnd 12288 chunkSuffix12 = true := by
  simp only [chunkSuffix12, checkAdjacentChunks, chunkChecked12, chunkSize12, Nat.reduceAdd, suffixChecked13, Bool.true_and]

private theorem chunkChecked11 :
    checkAdjacentAt checkRateStep (chunkSuffix12.flatten.headD blockEnd) 11264 sourceRates11264 = true := by decide +kernel

private theorem suffixChecked11 :
    checkAdjacentChunks checkRateStep blockEnd 11264 chunkSuffix11 = true := by
  simp only [chunkSuffix11, checkAdjacentChunks, chunkChecked11, chunkSize11, Nat.reduceAdd, suffixChecked12, Bool.true_and]

private theorem chunkChecked10 :
    checkAdjacentAt checkRateStep (chunkSuffix11.flatten.headD blockEnd) 10240 sourceRates10240 = true := by decide +kernel

private theorem suffixChecked10 :
    checkAdjacentChunks checkRateStep blockEnd 10240 chunkSuffix10 = true := by
  simp only [chunkSuffix10, checkAdjacentChunks, chunkChecked10, chunkSize10, Nat.reduceAdd, suffixChecked11, Bool.true_and]

private theorem chunkChecked09 :
    checkAdjacentAt checkRateStep (chunkSuffix10.flatten.headD blockEnd) 9216 sourceRates09216 = true := by decide +kernel

private theorem suffixChecked09 :
    checkAdjacentChunks checkRateStep blockEnd 9216 chunkSuffix09 = true := by
  simp only [chunkSuffix09, checkAdjacentChunks, chunkChecked09, chunkSize09, Nat.reduceAdd, suffixChecked10, Bool.true_and]

theorem sourceRateBlock1_directions :
    checkAdjacentAt checkRateStep (sourceRates18432.headD lastRate) 9216 sourceRateBlock1 = true := by
  have heq : chunkSuffix09.flatten = sourceRateBlock1 := by
    simp only [chunkSuffix09, chunkSuffix10, chunkSuffix11, chunkSuffix12, chunkSuffix13, chunkSuffix14, chunkSuffix15, chunkSuffix16, chunkSuffix17, sourceRateBlock1, List.flatten_cons, List.flatten_nil, List.append_nil, List.append_assoc]
  rw [← heq, ← checkAdjacentChunks_eq]
  exact suffixChecked09

theorem sourceRateBlock1_direction_size : sourceRateBlock1.length = 9216 := by
  simp only [sourceRateBlock1, List.length_append, chunkSize09, chunkSize10, chunkSize11, chunkSize12, chunkSize13, chunkSize14, chunkSize15, chunkSize16, chunkSize17, Nat.reduceAdd]

end SubmodularMatching.SourceCertificate.Replay
