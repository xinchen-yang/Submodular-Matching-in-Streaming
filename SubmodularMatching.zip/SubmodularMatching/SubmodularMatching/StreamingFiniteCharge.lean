import SubmodularMatching.PotentialRounding

/-!
# Finite-error charging for the actual streaming instance

The acceptance predicate, potential trajectory, frozen weights, random stored
history and ideal increments are all the previously defined computations.
Only the estimator's accuracy event and the ignored-prefix value allowance
remain external to the finite deterministic charging argument.
-/

open scoped BigOperators

namespace SubmodularMatching.Streaming

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

omit [DecidableEq E] [DecidableEq V] [Fintype V] in
/-- Failure of either actual acceptance test bounds the true arriving marginal
by the endpoint potentials and the finite threshold/estimation allowance. -/
theorem rejected_arrival_bound (C : PotentialConfig) (ends : E → V × V)
    (st : PotentialState E V) (e : E) (wh w : ℝ)
    (hphi : ∀ v, 0 ≤ st.potential v) (hno : ¬accepts C ends st e wh)
    (haccurate : w ≤ wh + 3 * C.gap) :
    w ≤ st.potential (ends e).1 + st.potential (ends e).2 + C.theta + 4 * C.gap := by
  unfold accepts at hno
  rcases not_and_or.mp hno with htheta | hsum
  · have ht : wh < C.theta := lt_of_not_ge htheta
    linarith [hphi (ends e).1, hphi (ends e).2, C.gap_nonneg]
  · have ht : wh < st.potential (ends e).1 + st.potential (ends e).2 + C.gap :=
      lt_of_not_ge hsum
    linarith [C.theta_pos]

omit [Fintype V] in
/-- Final residual bound of an actual rejected arrival. -/
theorem rejected_trace_residual_bound (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (f : Finset E → ℝ) (n i : ℕ) (hi : i < n)
    (hp1 : C.p ≤ 1) (hf : IsSubmodular f) (hm : IsMonotone f)
    (hw : ∀ j < n, (input j).2 ≤ C.tau)
    (hno : (input i).1 ∉ (runPotential C ends input n).stored)
    (hloop : (ends (input i).1).1 ≠ (ends (input i).1).2)
    (ha : traceWeight C ends input f i ≤ (input i).2 + 3 * C.gap) :
    traceResidual C ends input f n {(input i).1} ≤
      (∑ v ∈ endpointSet ends (input i).1, (runPotential C ends input n).potential v) +
        C.theta + 4 * C.gap := by
  have hpre : ∀ j < i, (input j).2 ≤ C.tau := fun j hj => hw j (hj.trans hi)
  have hstate := runPotential_invariant_prefix C ends input i hpre
  have hr := rejected_arrival_bound C ends (runPotential C ends input i) (input i).1 (input i).2
    (traceWeight C ends input f i) (fun v => (hstate v).1)
    (not_acceptedAt_of_not_stored C ends input n i hi hno) ha
  have hu := runPotential_potential_mono C ends input n hw i hi.le (ends (input i).1).1
  have hv := runPotential_potential_mono C ends input n hw i hi.le (ends (input i).1).2
  have hg := traceResidual_singleton_le_prefix C ends input f n i (input i).1 hi.le hp1 hf hm
  change traceResidual C ends input f n {(input i).1} ≤ traceWeight C ends input f i at hg
  simp only [endpointSet, Finset.sum_pair hloop]
  linarith

/-- Charging for the actual finite instance, including the exact ideal
potential sum and all deterministic finite error terms. -/
theorem trace_finite_charge (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (f : Finset E → ℝ) (n : ℕ) (M : Finset E)
    (hp1 : C.p ≤ 1) (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0)
    (hM : IsMatchingOn (endpointSet ends) M)
    (hMsub : M ⊆ (Finset.range n).image (fun i => (input i).1))
    (hloop : ∀ i < n, (ends (input i).1).1 ≠ (ends (input i).1).2)
    (hw : ∀ i < n, (input i).2 ≤ C.tau)
    (ha : ∀ i < n, (input i).2 ≤ traceWeight C ends input f i ∧
      traceWeight C ends input f i ≤ (input i).2 + 3 * C.gap) :
    let S := (runPotential C ends input n).stored
    f M ≤ traceRecordedValue C ends input n + traceResidual C ends input f n (M ∩ S) +
      (∑ v ∈ Finset.univ \ (M ∩ S).biUnion (endpointSet ends), idealPotential C ends input n v) +
      3 * C.p * C.gap * n + M.card * (C.theta + 4 * C.gap) + 2 * n * C.grid := by
  let S := (runPotential C ends input n).stored
  let g := traceResidual C ends input f n
  let allowance := C.theta + 4 * C.gap
  have hg := traceResidual_properties C ends input f n hp1 hf hm
  have hstate := runPotential_invariant_prefix C ends input n hw
  have hrejected (e : E) (he : e ∈ M \ S) :
      g {e} - allowance ≤ ∑ v ∈ endpointSet ends e, (runPotential C ends input n).potential v := by
    obtain ⟨i, hi, hie⟩ := Finset.mem_image.mp (hMsub (Finset.mem_sdiff.mp he).1)
    have hin := Finset.mem_range.mp hi
    have hno : (input i).1 ∉ (runPotential C ends input n).stored := by
      rw [hie]
      exact (Finset.mem_sdiff.mp he).2
    have h := rejected_trace_residual_bound C ends input f n i hin hp1 hf hm hw hno
      (hloop i hin) (ha i hin).2
    rw [hie] at h
    dsimp [g, allowance]
    linarith
  have hc := rejected_charge_le_unmatched_potential (endpointSet ends) M S hM
    (fun e => g {e} - allowance) (runPotential C ends input n).potential
    (fun v => (hstate v).1) hrejected
  simp only [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul] at hc
  have hsplit : (M ∩ S) ∪ (M \ S) = M := by
    ext e
    simp only [Finset.mem_union, Finset.mem_inter, Finset.mem_sdiff]
    tauto
  have hs := submodular_union_le_sum_singletons g hg.2.2 hg.2.1 hg.1 (M ∩ S) (M \ S)
  rw [hsplit] at hs
  have hb := value_le_trace_base_add_residual C ends input f n M hp1 hm
  have he := (trace_base_error C ends input f n hp1 hzero ha).2
  have hr := potential_sum_le_ideal_add_rounding C ends input n
    (Finset.univ \ (M ∩ S).biUnion (endpointSet ends))
  have hcard : ((M \ S).card : ℝ) ≤ M.card := by
    exact_mod_cast Finset.card_le_card (Finset.sdiff_subset : M \ S ⊆ M)
  have hallow : 0 ≤ allowance := by dsimp [allowance]; linarith [C.theta_pos, C.gap_nonneg]
  have hcard' := mul_le_mul_of_nonneg_right hcard hallow
  dsimp [S, g, allowance] at hs hc hb hr hcard' ⊢
  linarith

/-- An ignored prefix is charged only by its singleton values, with the loss
made explicit rather than assuming the final charging conclusion. -/
theorem trace_finite_charge_with_prefix (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (f : Finset E → ℝ) (n : ℕ) (M : Finset E) (prefixLoss : ℝ)
    (hp1 : C.p ≤ 1) (hf : IsSubmodular f) (hm : IsMonotone f) (hzero : f ∅ = 0)
    (hM : IsMatchingOn (endpointSet ends) M)
    (hloop : ∀ i < n, (ends (input i).1).1 ≠ (ends (input i).1).2)
    (hw : ∀ i < n, (input i).2 ≤ C.tau)
    (ha : ∀ i < n, (input i).2 ≤ traceWeight C ends input f i ∧
      traceWeight C ends input f i ≤ (input i).2 + 3 * C.gap)
    (hprefix : (∑ e ∈ M \ (Finset.range n).image (fun i => (input i).1), f {e}) ≤ prefixLoss) :
    let S := (runPotential C ends input n).stored
    f M ≤ traceRecordedValue C ends input n + traceResidual C ends input f n (M ∩ S) +
      (∑ v ∈ Finset.univ \ (M ∩ S).biUnion (endpointSet ends), idealPotential C ends input n v) +
      prefixLoss + 3 * C.p * C.gap * n + M.card * (C.theta + 4 * C.gap) + 2 * n * C.grid := by
  let arrived := (Finset.range n).image (fun i => (input i).1)
  let M' := M ∩ arrived
  have hM' : IsMatchingOn (endpointSet ends) M' := by
    intro e he d hd hed
    exact hM (Finset.mem_inter.mp he).1 (Finset.mem_inter.mp hd).1 hed
  have hS : (runPotential C ends input n).stored ⊆ arrived :=
    runPotential_stored_subset C ends input arrived n
      (fun i hi => Finset.mem_image.mpr ⟨i, Finset.mem_range.mpr hi, rfl⟩)
  have heq : M' ∩ (runPotential C ends input n).stored =
      M ∩ (runPotential C ends input n).stored := by
    rw [show M' = M ∩ arrived from rfl, Finset.inter_assoc, Finset.inter_eq_right.mpr hS]
  have hc := trace_finite_charge C ends input f n M' hp1 hf hm hzero hM'
    Finset.inter_subset_right hloop hw ha
  dsimp only at hc ⊢
  rw [heq] at hc
  have hsub := submodular_union_le_sum_singletons f hf hm hzero M' (M \ arrived)
  have hsplit : M' ∪ (M \ arrived) = M := by
    ext e
    simp only [M', Finset.mem_union, Finset.mem_inter, Finset.mem_sdiff]
    tauto
  rw [hsplit] at hsub
  have hcard : (M'.card : ℝ) ≤ M.card := by
    exact_mod_cast Finset.card_le_card (Finset.inter_subset_left : M ∩ arrived ⊆ M)
  have hcost := mul_le_mul_of_nonneg_right hcard
    (by linarith [C.theta_pos, C.gap_nonneg] : 0 ≤ C.theta + 4 * C.gap)
  dsimp [arrived] at hsub
  linarith

end SubmodularMatching.Streaming
