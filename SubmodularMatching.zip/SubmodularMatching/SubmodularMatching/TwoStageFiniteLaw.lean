import SubmodularMatching.GibbsPositiveSupport
import SubmodularMatching.TwoStageRounding

/-!
# Approximate joint rounding law with feasible support

The second-stage kernel may use a different positive-edge graph for each
first outcome. Both distributions live on the same ambient matching space.
The sampler error transfers to the original objective on feasible unions.
-/

open scoped BigOperators

namespace SubmodularMatching.TwoStage

open GibbsSampler

noncomputable section

variable {V : Type*} [DecidableEq V]
variable {m : ℕ}

/-- The actual activity for the second draw conditional on the first matching. -/
def secondActivity (ends : Fin m → V × V) (x y : Fin m → ℝ)
    (εA εG : ℝ) (T : Finset (Fin m)) : Fin m → ℝ :=
  GibbsMatching.calibratedActivity (pairEnds ends) Finset.univ
    (shearerAltered ends x y εA T) (1 - εG / 4)

/-- A bounded observable on the common product space. Infeasible pairs have
zero mass in both samplers, and thus their test value can be set to zero. -/
def feasibleUnionValue (ends : Fin m → V × V) (f : Finset (Fin m) → ℝ)
    (pair : Finset (Fin m) × Finset (Fin m)) : ℝ := by
  classical
  exact if Streaming.IsMatchingOn (pairEnds ends) (pair.1 ∪ pair.2)
    then f (pair.1 ∪ pair.2) else 0

theorem secondActivity_support_matching (ends : Fin m → V × V)
    (x y : Fin m → ℝ) (εA εG : ℝ) (T N : Finset (Fin m))
    (hT : T ∈ GibbsMatching.matchings (pairEnds ends) Finset.univ)
    (hN : 0 < GibbsMatching.probability (pairEnds ends) Finset.univ
      (secondActivity ends x y εA εG T) N) :
    Streaming.IsMatchingOn (pairEnds ends) (T ∪ N) := by
  apply positive_probability_union_matching (pairEnds ends) Finset.univ T N
    (shearerAltered ends x y εA T) (1 - εG / 4)
    ((GibbsMatching.mem_matchings _ _ _).mp hT).2 _ hN
  intro e _ he
  exact altered_avoids_matching ends (fun M : Finset (Fin m) => M)
    (compensatedEdge ends x y) εA T e he

/-- Every positive-mass binary Gibbs output stays compatible with the first
matching, including when that first matching has zero mass in the ideal law. -/
theorem supported_second_union_matching (ends : Fin m → V × V)
    (x y : Fin m → ℝ) (εA εG : ℝ) (T N : Finset (Fin m)) (bits steps : ℕ)
    (hT : T ∈ GibbsMatching.matchings (pairEnds ends) Finset.univ)
    (ha : ∀ e, 0 ≤ secondActivity ends x y εA εG T e)
    (hN : 0 < GibbsMatching.supportedGibbsLaw (pairEnds ends) Finset.univ
      (secondActivity ends x y εA εG T) bits steps N) :
    Streaming.IsMatchingOn (pairEnds ends) (T ∪ N) := by
  classical
  let ep := pairEnds ends
  let activity := secondActivity ends x y εA εG T
  let S := GibbsMatching.positiveEdges Finset.univ activity
  have hN' : N ∈ GibbsMatching.matchings ep S := by
    by_contra h
    simp [GibbsMatching.supportedGibbsLaw, ep, activity, S, h] at hN
  apply secondActivity_support_matching ends x y εA εG T N hT
  change 0 < GibbsMatching.probability ep Finset.univ activity N
  rw [← GibbsMatching.probability_positiveEdges ep Finset.univ activity (fun e _ => ha e)]
  change 0 < GibbsMatching.probability ep S activity N
  simp only [GibbsMatching.probability, hN', ↓reduceIte]
  have hm := (GibbsMatching.mem_matchings ep S N).mp hN'
  exact div_pos (Finset.prod_pos (fun e he => (Finset.mem_filter.mp (hm.1 he)).2))
    (GibbsMatching.partition_positive ep S activity (fun e he => (Finset.mem_filter.mp he).2.le))

theorem ideal_joint_feasibleUnionValue (ends : Fin m → V × V) (x y : Fin m → ℝ)
    (εA εG : ℝ) (f : Finset (Fin m) → ℝ)
    (hactivity : ∀ T ∈ GibbsMatching.matchings (pairEnds ends) Finset.univ,
      ∀ e, 0 ≤ secondActivity ends x y εA εG T e) :
    let ep := pairEnds ends
    let states := GibbsMatching.matchings ep Finset.univ
    expected (states ×ˢ states) (jointLaw (Shearer.mass ep Finset.univ y)
      (fun T => GibbsMatching.probability ep Finset.univ (secondActivity ends x y εA εG T)))
      (feasibleUnionValue ends f) = twoStageValue ends x y εA εG f := by
  classical
  dsimp only
  unfold expected jointLaw twoStageValue Shearer.expectation
  rw [Finset.sum_product]
  apply Finset.sum_congr rfl
  intro T hT
  rw [conditionalValue, GibbsMatching.expectation_eq_probability_sum, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro N _
  let b := GibbsMatching.probability (pairEnds ends) Finset.univ
    (secondActivity ends x y εA εG T) N
  have hb : 0 ≤ b := GibbsMatching.probability_nonnegative _ _ _ (fun e _ => hactivity T hT e) _
  by_cases h : b = 0
  · change _ * b * _ = _ * (b * _)
    rw [h]
    ring
  · have hmatch := secondActivity_support_matching ends x y εA εG T N hT
      (lt_of_le_of_ne hb (Ne.symm h))
    simp only [feasibleUnionValue, hmatch, ↓reduceIte, secondActivity]
    ring

/-- The sampler approximation for the actual two-stage law. The first
error can come from the bounded binary Shearer sampler, and the second
from the rounded Gibbs chain on the positive-activity graph. -/
theorem finite_two_stage_value_error [Fintype V]
    (ends : Fin m → V × V) (x y : Fin m → ℝ) (εA εG r ε₁ ε₂ B : ℝ)
    (hr0 : 0 < r) (hr1 : r ≤ 1)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hy : ∀ e, 0 ≤ y e)
    (hdegree : ∀ v, (∑ e ∈ GibbsMatching.incident (pairEnds ends) Finset.univ v, y e) ≤ r * (1 - r))
    (hactivity : ∀ T ∈ GibbsMatching.matchings (pairEnds ends) Finset.univ,
      ∀ e, 0 ≤ secondActivity ends x y εA εG T e)
    (f : Finset (Fin m) → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (hnorm : f ∅ = 0) (hB : 0 ≤ B) (hsingle : ∀ e, f {e} ≤ B)
    (first : Finset (Fin m) → ℝ) (bits steps : Finset (Fin m) → ℕ)
    (hfirst : IsProbability (GibbsMatching.matchings (pairEnds ends) Finset.univ) first)
    (hε₁ : variation (GibbsMatching.matchings (pairEnds ends) Finset.univ)
      (Shearer.mass (pairEnds ends) Finset.univ y) first ≤ ε₁)
    (hε₂ : ∀ T ∈ GibbsMatching.matchings (pairEnds ends) Finset.univ,
      let ep := pairEnds ends
      let activity := secondActivity ends x y εA εG T
      let edges := GibbsMatching.positiveEdges Finset.univ activity
      let states := GibbsMatching.matchings ep edges
      variation states (iterateKernel states (roundedTransition ep edges activity (bits T))
        (pointMass ∅) (steps T)) (GibbsMatching.probability ep edges activity) ≤ ε₂) :
    let ep := pairEnds ends
    let states := GibbsMatching.matchings ep Finset.univ
    let second := fun T => GibbsMatching.supportedGibbsLaw ep Finset.univ
      (secondActivity ends x y εA εG T) (bits T) (steps T)
    IsProbability (states ×ˢ states) (jointLaw first second) ∧
      (∀ (pair : Finset (Fin m) × Finset (Fin m)), pair ∈ states ×ˢ states →
        0 < jointLaw first second pair → Streaming.IsMatchingOn ep (pair.1 ∪ pair.2)) ∧
      |twoStageValue ends x y εA εG f -
        expected (states ×ˢ states) (jointLaw first second) (feasibleUnionValue ends f)| ≤
          (ε₁ + ε₂) * ((Fintype.card V : ℝ) / 2 * B) := by
  classical
  dsimp only
  let ep := pairEnds ends
  let states := GibbsMatching.matchings ep Finset.univ
  let activity := secondActivity ends x y εA εG
  let second := fun T => GibbsMatching.supportedGibbsLaw ep Finset.univ (activity T) (bits T) (steps T)
  let idealFirst := Shearer.mass ep Finset.univ y
  let idealSecond := fun T => GibbsMatching.probability ep Finset.univ (activity T)
  have hends : ∀ e ∈ (Finset.univ : Finset (Fin m)), (ep e).card = 2 :=
    fun e _ => pairEnds_card_two ends hloop e
  have hsFirst : IsProbability states idealFirst := by
    refine ⟨fun T _ => Shearer.mass_nonnegative ep Finset.univ y r hr0 hr1
      (fun e _ => hy e) hends hdegree T, ?_⟩
    simpa [states, idealFirst, Shearer.expectation] using
      (Shearer.expectation_const ep Finset.univ y (1 : ℝ))
  have hsSecond (T : Finset (Fin m)) (hT : T ∈ states) : IsProbability states (idealSecond T) :=
    ⟨fun N _ => GibbsMatching.probability_nonnegative _ _ _ (fun e _ => hactivity T hT e) N,
      GibbsMatching.probability_total _ _ _ (fun e _ => hactivity T hT e)⟩
  have hsecond (T : Finset (Fin m)) (_ : T ∈ states) : IsProbability states (second T) :=
    GibbsMatching.supportedGibbsLaw_probability ep Finset.univ (activity T) (bits T) (steps T)
  refine ⟨jointLaw_probability states states first second hfirst hsecond, ?_, ?_⟩
  · intro pair hpair hm
    obtain ⟨hT, _⟩ := Finset.mem_product.mp hpair
    have hpos : 0 < second pair.1 pair.2 := by
      by_contra! h
      exact (not_lt_of_ge (mul_nonpos_of_nonneg_of_nonpos
        (hfirst.nonnegative pair.1 hT) h)) hm
    exact supported_second_union_matching ends x y εA εG _ _ _ _
      hT (hactivity pair.1 hT) hpos
  · rw [← ideal_joint_feasibleUnionValue ends x y εA εG f hactivity]
    refine expected_joint_difference_le states states idealFirst first idealSecond second
      hsFirst hfirst hsSecond hsecond (feasibleUnionValue ends f)
      ((Fintype.card V : ℝ) / 2 * B) ε₁ ε₂ (by positivity) ?_ hε₁ ?_
    · intro pair _
      unfold feasibleUnionValue
      split_ifs with hc
      · exact matching_observable_range ep Finset.univ _
          ((GibbsMatching.mem_matchings _ _ _).mpr ⟨Finset.subset_univ _, hc⟩)
          hends f hf hmono hnorm B hB (fun e _ => hsingle e)
      · exact ⟨le_rfl, by positivity⟩
    · intro T hT
      have heq := GibbsMatching.supportedGibbsLaw_variation ep Finset.univ (activity T)
        (fun e _ => hactivity T hT e) (bits T) (steps T)
      change variation states (idealSecond T) (second T) ≤ ε₂
      have hsym : variation states (idealSecond T) (second T) =
          variation states (second T) (idealSecond T) := by
        unfold variation
        simp only [abs_sub_comm (idealSecond T _) (second T _)]
      rw [hsym]
      exact heq.le.trans (hε₂ T hT)

end

end SubmodularMatching.TwoStage
