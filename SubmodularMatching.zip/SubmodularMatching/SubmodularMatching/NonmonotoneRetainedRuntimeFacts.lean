import SubmodularMatching.NonmonotoneRetainedRuntime

/-! The retained frozen register is bounded for a certified stream payload.
All emitted sets are feasible, even for inaccurate optimizer transcripts. -/
namespace SubmodularMatching.AppendixM
open Capacity Finset Streaming NonmonotoneOptimizer NonmonotoneCandidate
open TwoLayerDiffuse Shearer UpperBoundAssembly GibbsSampler
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream E V} {b : V → ℕ} {records : List (E × ℕ)}

theorem feasible_retained_image {keep : Finset E} (ends : E → V×V) (cap : V→ℕ) (U : Finset ↑keep)
    (h : Capacity.feasible (fun e : ↑keep => ends e.val) cap U) :
    Capacity.feasible ends cap (U.image Subtype.val) := by
  intro v
  have he : incidences ends (U.image Subtype.val) v = (incidences (fun e : ↑keep => ends e.val) U v).image Subtype.val := by
    ext e
    constructor
    · intro he
      obtain ⟨hm,ht⟩ := mem_filter.mp he
      obtain ⟨c,hU,eqc⟩ := mem_image.mp hm
      subst e
      exact mem_image.mpr ⟨c,mem_filter.mpr ⟨hU,ht⟩,rfl⟩
    · intro he
      obtain ⟨c,hU,eqc⟩ := mem_image.mp he
      subst e
      exact mem_filter.mpr ⟨mem_image_of_mem _ (mem_filter.mp hU).1,(mem_filter.mp hU).2⟩
  rw [he]
  exact card_image_le.trans (h v)

theorem feasible_retained_law {keep : Finset E} (ends : E → V×V) (cap : V→ℕ)
    (law : CandidateLaw (Finset ↑keep))
    (feas : ∀ U∈law.outcomes, Capacity.feasible (fun e : ↑keep => ends e.val) cap U) :
    ∀ A∈(law.map (fun U => U.image Subtype.val)).outcomes, Capacity.feasible ends cap A := by
  intro A ha
  obtain ⟨U,hU,rfl⟩ := Finset.mem_image.mp ha
  exact feasible_retained_image ends cap U (feas U hU)

namespace RetainedRuntime
variable (R : RetainedRuntime S b records)

theorem bounded_of_source (C : PotentialConfig) (pair : E→BSlot b × BSlot b) (v k : ℕ) (edge : ℕ→E)
    (idx : ℕ→ℕ) (f : Finset E→ℝ) (M : Finset E) (τ : ℝ) (ht : 0<τ)
    (D : RetainedPassData C S.ends b pair v k edge idx f M τ records) : R.Bounded v := by
  let w := frozenInput (fun i => (edge i,(streamTolerance:ℝ)*τ/(v:ℝ)^2*idx i)) k
  have hd : ∀ e∈(records.map Prod.fst).toFinset, w e=(streamTolerance:ℝ)*τ/(v:ℝ)^2*frozenIndex edge idx k e :=
    fun e _ => frozen_index_eq edge idx k _ e
  have hu : ∀ e∈(records.map Prod.fst).toFinset, w e≤τ := fun e _ =>
    (frozenInput_bounds _ k τ ht.le (fun i hi =>
      ⟨by dsimp only; unfold streamTolerance; positivity,D.weights i hi⟩) e).2
  unfold Bounded block
  rw [retainedBlock_stored records _ R.enum R.cols v D.index]
  exact retained_frozen_bound _ R.enum R.cols v _ τ ht w hd hu

set_option maxRecDepth 4096 in
theorem physicalRow_feasible (v q : ℕ) (hb : ∀ i, 0<b i) (rank : Slots b ↪ ℕ) (hw : R.Bounded v)
    (f : Finset E→ℝ) (τ : ℝ) {J : ℕ} (W : R.Words J) :
    ∀ A∈(R.physicalRow v q hb rank hw f τ W).outcomes, Capacity.feasible S.ends b A := by
  letI : NeZero (records.map Prod.fst).length := ⟨R.nonempty.ne'⟩
  letI : LinearOrder ↑(records.map Prod.fst).toFinset := R.tieOrder
  let g := R.retainedWordRow v q hb hw f τ W
  dsimp only [physicalRow]
  apply feasible_retained_law
  exact g.trial_feasible_all hb rank (R.enum 0) (retainedChronological _ R.nodup) (records.map Prod.fst).length τ
    (retainedObjective _ f)

theorem indexedRetainedProgram_feasible (v q : ℕ) (hb : ∀ i,0<b i) (rank : Slots b ↪ ℕ)
    (f : Finset E → ℝ) (J : ℕ) (τ : ℝ) :
    ∀ A∈(R.indexedRetainedProgram v q hb rank f J τ).outcomes, Capacity.feasible S.ends b A := by
  unfold indexedRetainedProgram
  split_ifs with hw
  · exact optimizerTrial_support J _ _ (fun W => R.physicalRow_feasible v q hb rank hw f τ W)
  · intro A hA
    have : A = ∅ := Finset.mem_singleton.mp hA
    subst A
    simp [Capacity.feasible,incidences]

end RetainedRuntime
end
end SubmodularMatching.AppendixM
