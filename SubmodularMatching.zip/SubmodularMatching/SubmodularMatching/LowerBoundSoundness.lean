import SubmodularMatching.CloneLiftSlots
import SubmodularMatching.RecursiveObjectiveCompleteness
import Mathlib.Algebra.BigOperators.Field

/-!
# Quantitative soundness of the lower-bound objective

The selected objects are actual simple clone-graph matchings. The stage budget
is derived by charging nonspecial edges to outside endpoint clones. The
recursive-objective profile then bounds value by the analytic baseline plus
the normalized number of recovered special and distinguished-label edges.
-/

namespace SubmodularMatching.LowerBoundSoundness

open scoped BigOperators
open RecursiveObjective

noncomputable section

variable {L R C : Type*} [Fintype C]

/-- Selected clone edges from one stage. -/
def stageSet (stage : ((L × C) × (R × C)) → ℕ) (i : ℕ)
    (S : Finset ((L × C) × (R × C))) : Finset ((L × C) × (R × C)) :=
  S.filter (fun e => stage e = i)

/-- Normalized number of selected special base-pair copies in one stage. -/
def specialMass (unit : ℝ) (stage : ((L × C) × (R × C)) → ℕ)
    (special : ℕ → L × R → Prop) [∀ i, DecidablePred (special i)]
    (S : Finset ((L × C) × (R × C))) (i : ℕ) : ℝ :=
  (((stageSet stage i S).filter (fun e => special i (CloneLift.basePair e))).card : ℝ) * unit

omit [Fintype C] in
theorem specialMass_nonnegative (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : ((L × C) × (R × C)) → ℕ)
    (special : ℕ → L × R → Prop) [∀ i, DecidablePred (special i)]
    (S : Finset ((L × C) × (R × C))) (i : ℕ) :
    0 ≤ specialMass unit stage special S i :=
  mul_nonneg (Nat.cast_nonneg _) hunit

/-- Derive a stage's normalized budget directly from matching feasibility and
an outside-vertex cover of its nonspecial edges. -/
theorem stage_budget_of_matching (unit c : ℝ) (hunit : 0 ≤ unit)
    (stage : ((L × C) × (R × C)) → ℕ)
    (special : ℕ → L × R → Prop) [∀ i, DecidablePred (special i)]
    (S : Finset ((L × C) × (R × C))) (hS : CloneLift.IsMatching S)
    (i : ℕ) (coverL : Finset L) (coverR : Finset R)
    (hcapacity : (Fintype.card C : ℝ) * (coverL.card + coverR.card) * unit ≤ c)
    (hcover : ∀ e ∈ S, stage e = i → ¬special i (CloneLift.basePair e) →
      e.1.1 ∈ coverL ∨ e.2.1 ∈ coverR) :
    totalStageMass unit stage i S ≤ c + specialMass unit stage special S i := by
  classical
  have hsub : stageSet stage i S ⊆ S := Finset.filter_subset _ _
  have hs := CloneLift.matching_slot_bound (stageSet stage i S)
    (CloneLift.isMatching_subset hS hsub) coverL coverR (special i)
    (fun e he => hcover e (Finset.mem_filter.mp he).1 (Finset.mem_filter.mp he).2)
  have hsR : ((stageSet stage i S).card : ℝ) ≤
      Fintype.card C * (coverL.card + coverR.card) +
        (((stageSet stage i S).filter (fun e => special i (CloneLift.basePair e))).card : ℝ) := by
    exact_mod_cast hs
  have hscale := mul_le_mul_of_nonneg_right hsR hunit
  simpa only [totalStageMass, specialMass, stageSet, Finset.sum_const,
    nsmul_eq_mul] using (show ((stageSet stage i S).card : ℝ) * unit ≤
      c + (((stageSet stage i S).filter (fun e => special i (CloneLift.basePair e))).card : ℝ) *
        unit by nlinarith)

/-- The soundness error is precisely the good-edge and special-edge mass. -/
def recoveryError (unit : ℝ) (stage : ((L × C) × (R × C)) → ℕ)
    (label : ((L × C) × (R × C)) → Bool)
    (special : ℕ → L × R → Prop) [∀ i, DecidablePred (special i)]
    (S : Finset ((L × C) × (R × C))) (start count : ℕ) : ℝ :=
  penalty unit stage label (specialMass unit stage special S) S start count

omit [Fintype C] in
theorem recoveryError_nonnegative (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : ((L × C) × (R × C)) → ℕ)
    (label : ((L × C) × (R × C)) → Bool)
    (special : ℕ → L × R → Prop) [∀ i, DecidablePred (special i)]
    (S : Finset ((L × C) × (R × C))) (start count : ℕ) :
    0 ≤ recoveryError unit stage label special S start count :=
  penalty_nonnegative unit hunit stage label _
    (specialMass_nonnegative unit hunit stage special S) S count start

/-- Pointwise soundness for the actual recursive objective on a clone matching.
The stage-size condition is proved from the outside covers, not assumed. -/
theorem matching_objective_bound (unit c : ℝ) (hunit : 0 ≤ unit)
    (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (stage : ((L × C) × (R × C)) → ℕ)
    (label : ((L × C) × (R × C)) → Bool)
    (special : ℕ → L × R → Prop) [∀ i, DecidablePred (special i)]
    (S : Finset ((L × C) × (R × C))) (hS : CloneLift.IsMatching S)
    (start count : ℕ) (coverL : ℕ → Finset L) (coverR : ℕ → Finset R)
    (hcapacity : ∀ i, start ≤ i → i < start + count →
      (Fintype.card C : ℝ) * ((coverL i).card + (coverR i).card) * unit ≤ c)
    (hcover : ∀ i, start ≤ i → i < start + count → ∀ e ∈ S,
      stage e = i → ¬special i (CloneLift.basePair e) →
        e.1.1 ∈ coverL i ∨ e.2.1 ∈ coverR i) :
    objective unit stage label start count S ≤ c * (count + 1 : ℝ) / (1 + c) +
      recoveryError unit stage label special S start count := by
  have hprof := objective_le_profile_add_penalty unit hunit stage label
    (specialMass unit stage special S) (specialMass_nonnegative unit hunit stage special S)
    c hc0 hc1 count start S (fun i hi hi' =>
      stage_budget_of_matching unit c hunit stage special S hS i (coverL i) (coverR i)
        (hcapacity i hi hi') (hcover i hi hi'))
  exact hprof.trans (add_le_add (LowerBoundProfile.profile_bound hc0 hc1 count) (le_refl _))

omit [Fintype C] in
/-- Exact interchange of the finite expectation and stage-wise recovery sum. -/
theorem expected_recoveryError_eq {Ω : Type*} [Fintype Ω]
    (μ : Ω → ℝ) (unit : ℝ) (stage : ((L × C) × (R × C)) → ℕ)
    (label : Ω → ((L × C) × (R × C)) → Bool)
    (special : Ω → ℕ → L × R → Prop) [∀ ω i, DecidablePred (special ω i)]
    (S : Ω → Finset ((L × C) × (R × C))) (start count : ℕ) :
    (∑ ω, μ ω * recoveryError unit stage (label ω) (special ω) (S ω) start count) =
      (Finset.range count).sum (fun j =>
        (∑ ω, μ ω * stageMass unit stage (label ω) (start + j) true (S ω)) +
        ∑ ω, μ ω * specialMass unit stage (special ω) (S ω) (start + j)) := by
  simp only [recoveryError, penalty_eq_sum, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  simp only [mul_add, Finset.sum_add_distrib]

omit [Fintype C] in
/-- The recovery-error expectation follows from the two information bounds,
without any independence assumption between special and good output counts. -/
theorem expected_recoveryError_le {Ω : Type*} [Fintype Ω]
    (μ : Ω → ℝ) (unit : ℝ) (stage : ((L × C) × (R × C)) → ℕ)
    (label : Ω → ((L × C) × (R × C)) → Bool)
    (special : Ω → ℕ → L × R → Prop) [∀ ω i, DecidablePred (special ω i)]
    (S : Ω → Finset ((L × C) × (R × C))) (start count : ℕ) (G Z : ℝ)
    (hgood : ∀ j < count,
      (∑ ω, μ ω * stageMass unit stage (label ω) (start + j) true (S ω)) ≤ G)
    (hspecial : ∀ j < count,
      (∑ ω, μ ω * specialMass unit stage (special ω) (S ω) (start + j)) ≤ Z) :
    (∑ ω, μ ω * recoveryError unit stage (label ω) (special ω) (S ω) start count) ≤
      (count : ℝ) * (G + Z) := by
  rw [expected_recoveryError_eq]
  calc
    _ ≤ (Finset.range count).sum (fun _ => G + Z) := by
      apply Finset.sum_le_sum
      intro j hj
      exact add_le_add (hgood j (Finset.mem_range.mp hj))
        (hspecial j (Finset.mem_range.mp hj))
    _ = (count : ℝ) * (G + Z) := by simp

/-- Finite-law expected objective bound, with actual matching and oracle data. -/
theorem expected_matching_value_le {Ω : Type*} [Fintype Ω]
    (μ : Ω → ℝ) (hμ : ∀ ω, 0 ≤ μ ω) (hμsum : ∑ ω, μ ω = 1)
    (unit c : ℝ) (hunit : 0 ≤ unit) (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (stage : ((L × C) × (R × C)) → ℕ)
    (label : Ω → ((L × C) × (R × C)) → Bool)
    (special : Ω → ℕ → L × R → Prop) [∀ ω i, DecidablePred (special ω i)]
    (S : Ω → Finset ((L × C) × (R × C))) (hS : ∀ ω, CloneLift.IsMatching (S ω))
    (start count : ℕ) (coverL : Ω → ℕ → Finset L) (coverR : Ω → ℕ → Finset R)
    (hcapacity : ∀ ω i, start ≤ i → i < start + count →
      (Fintype.card C : ℝ) * ((coverL ω i).card + (coverR ω i).card) * unit ≤ c)
    (hcover : ∀ ω i, start ≤ i → i < start + count → ∀ e ∈ S ω,
      stage e = i → ¬special ω i (CloneLift.basePair e) →
        e.1.1 ∈ coverL ω i ∨ e.2.1 ∈ coverR ω i) :
    (∑ ω, μ ω * objective unit stage (label ω) start count (S ω)) ≤
      c * (count + 1 : ℝ) / (1 + c) +
        ∑ ω, μ ω * recoveryError unit stage (label ω) (special ω) (S ω) start count := by
  calc
    _ ≤ ∑ ω, μ ω * (c * (count + 1 : ℝ) / (1 + c) +
      recoveryError unit stage (label ω) (special ω) (S ω) start count) := by
      apply Finset.sum_le_sum
      intro ω _
      exact mul_le_mul_of_nonneg_left (matching_objective_bound unit c hunit hc0 hc1
        stage (label ω) (special ω) (S ω) (hS ω) start count (coverL ω) (coverR ω)
        (hcapacity ω) (hcover ω)) (hμ ω)
    _ = _ := by
      simp only [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul, hμsum, one_mul]

/-- Probability mass of a finite event. -/
def eventMass {Ω : Type*} [Fintype Ω] (μ : Ω → ℝ) (P : Ω → Prop) : ℝ := by
  classical
  exact ∑ ω, if P ω then μ ω else 0

/-- A finite Markov argument with an exceptional completeness event. -/
theorem event_le_exception_add_markov {Ω : Type*} [Fintype Ω]
    (μ X : Ω → ℝ) (complete success : Ω → Prop) (D : ℝ)
    (hμ : ∀ ω, 0 ≤ μ ω) (hX : ∀ ω, 0 ≤ X ω) (hD : 0 < D)
    (himp : ∀ ω, complete ω → success ω → D ≤ X ω) :
    eventMass μ success ≤ eventMass μ (fun ω => ¬complete ω) +
      (∑ ω, μ ω * X ω) / D := by
  classical
  have hpoint (ω : Ω) : (if success ω then μ ω else 0) ≤
      (if ¬complete ω then μ ω else 0) + μ ω * X ω / D := by
    have hx := div_nonneg (mul_nonneg (hμ ω) (hX ω)) hD.le
    by_cases hc : complete ω
    · by_cases hs : success ω
      · have hm := mul_le_mul_of_nonneg_left (himp ω hc hs) (hμ ω)
        have hd := (le_div_iff₀ hD).2 hm
        simpa only [hs, hc, not_true_eq_false, ↓reduceIte, zero_add] using hd
      · simp only [hs, hc, not_true_eq_false, ↓reduceIte, zero_add]
        exact hx
    · by_cases hs : success ω
      · simp only [hs, hc, not_false_eq_true, ↓reduceIte]
        linarith
      · simp only [hs, hc, not_false_eq_true, ↓reduceIte]
        exact add_nonneg (hμ ω) hx
  have hsum := Finset.sum_le_sum (fun ω (_ : ω ∈ Finset.univ) => hpoint ω)
  have hnot : eventMass μ (fun ω => ¬complete ω) =
      ∑ ω, if complete ω then 0 else μ ω := by
    unfold eventMass
    apply Finset.sum_congr rfl
    intro ω _
    by_cases hc : complete ω <;> simp [hc]
  rw [hnot]
  simpa only [eventMass, Finset.sum_add_distrib, Finset.sum_div, ite_not] using hsum

/-- Quantitative failure of approximation against a good-only witness.
The objective's soundness and witness value are derived here from matching
geometry and actual stage masses. Only the probability of constructing a
near-complete witness and the recovery-error expectation remain to be bounded.
An approximation to the optimum in particular approximates every feasible witness. -/
theorem success_against_witness_le {Ω : Type*} [Fintype Ω]
    (μ : Ω → ℝ) (hμ : ∀ ω, 0 ≤ μ ω)
    (unit c Rapprox ξ : ℝ) (hunit : 0 ≤ unit) (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (hR : 0 < Rapprox)
    (stage : ((L × C) × (R × C)) → ℕ)
    (label : Ω → ((L × C) × (R × C)) → Bool)
    (special : Ω → ℕ → L × R → Prop) [∀ ω i, DecidablePred (special ω i)]
    (S W : Ω → Finset ((L × C) × (R × C)))
    (hS : ∀ ω, CloneLift.IsMatching (S ω))
    (start count : ℕ) (coverL : Ω → ℕ → Finset L) (coverR : Ω → ℕ → Finset R)
    (hcapacity : ∀ ω i, start ≤ i → i < start + count →
      (Fintype.card C : ℝ) * ((coverL ω i).card + (coverR ω i).card) * unit ≤ c)
    (hcover : ∀ ω i, start ≤ i → i < start + count → ∀ e ∈ S ω,
      stage e = i → ¬special ω i (CloneLift.basePair e) →
        e.1.1 ∈ coverL ω i ∨ e.2.1 ∈ coverR ω i)
    (complete : Ω → Prop)
    (hwbad : ∀ ω, complete ω → ∀ i, start ≤ i → i < start + count →
      stageMass unit stage (label ω) i false (W ω) = 0)
    (hwgood : ∀ ω, complete ω → ∀ i, start ≤ i → i < start + count →
      1 - ξ ≤ stageMass unit stage (label ω) i true (W ω) ∧
        stageMass unit stage (label ω) i true (W ω) ≤ 1)
    (hgap : 0 < (count : ℝ) * (1 - ξ) / Rapprox - c * (count + 1 : ℝ) / (1 + c)) :
    eventMass μ (fun ω => objective unit stage (label ω) start count (W ω) ≤
        Rapprox * objective unit stage (label ω) start count (S ω)) ≤
      eventMass μ (fun ω => ¬complete ω) +
        (∑ ω, μ ω * recoveryError unit stage (label ω) (special ω) (S ω) start count) /
          ((count : ℝ) * (1 - ξ) / Rapprox - c * (count + 1 : ℝ) / (1 + c)) := by
  apply event_le_exception_add_markov μ _ complete _ _ hμ
    (fun ω => recoveryError_nonnegative unit hunit stage (label ω) (special ω)
      (S ω) start count) hgap
  intro ω hc hs
  have hw := objective_good_only_lower_bound unit hunit stage (label ω) count start
    (W ω) ξ (hwbad ω hc) (hwgood ω hc)
  have hlo : (count : ℝ) * (1 - ξ) / Rapprox ≤
      objective unit stage (label ω) start count (S ω) := by
    apply (div_le_iff₀ hR).2
    simpa only [mul_comm Rapprox] using hw.trans hs
  have hup := matching_objective_bound unit c hunit hc0 hc1 stage (label ω) (special ω)
    (S ω) (hS ω) start count (coverL ω) (coverR ω) (hcapacity ω) (hcover ω)
  linarith

end

end SubmodularMatching.LowerBoundSoundness
