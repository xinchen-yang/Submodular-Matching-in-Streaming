import SubmodularMatching.ProjectedShearerLayerBudget
import SubmodularMatching.NonmonotoneLayersPhysicalDecoder

/-! # Feeding the actual bisection-decoded Y registers to the finite slot sampler -/
namespace SubmodularMatching.AppendixM
open Capacity UpperBoundAssembly NonmonotoneLayers TwoLayerDiffuse Shearer ShearerCappedSampler GibbsSampler
open scoped BigOperators
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

def decodedDen (T k : ℕ) := 40*T*2^decoderSteps k

def decodedNum (S : SimpleEdgeStream E V) (b : V→ℕ) (k q T : ℕ) (u : E→ℕ) (e : E) : ℕ :=
  ⌊decodedCoordinate S b k q (fun i => (u i:ℚ)/T) e * decodedDen T k⌋₊

theorem decoded_number (S : SimpleEdgeStream E V) (b : V→ℕ) (k q T : ℕ) (u : E→ℕ) (hT : 0<T) (e : E) :
    ((decodedNum S b k q T u e:ℝ)/decodedDen T k) =
      (decodedCoordinate S b k q (fun i => (u i:ℚ)/T) e:ℝ) := by
  let y := decodedCoordinate S b k q (fun i => (u i:ℚ)/T) e
  obtain ⟨i,hi,h⟩ := decodedMass_grid (b (S.ends e).1) (b (S.ends e).2) (decoderBits k q) (decoderSteps k)
    firstRateQ secondRateQ layerDegreeQ ((u e:ℚ)/T)
  change y = layerDegreeQ*((u e:ℚ)/T)*i/(2:ℚ)^decoderSteps k at h
  have t : (T:ℚ) ≠ 0 := by exact_mod_cast hT.ne'
  have v : y * (decodedDen T k:ℚ) = ((13*u e*i:ℕ):ℚ) := by
    rw [h]
    simp only [decodedDen,layerDegreeQ,Nat.cast_mul,Nat.cast_ofNat,Nat.cast_pow]
    field_simp
    <;> ring
  have n : decodedNum S b k q T u e = 13*u e*i := by
    unfold decodedNum
    change ⌊y*(decodedDen T k:ℚ)⌋₊ = _
    rw [v,Nat.floor_natCast]
  have d : 0 < decodedDen T k := by unfold decodedDen; positivity
  have eq : ((decodedNum S b k q T u e:ℚ)/decodedDen T k) = y :=
    (div_eq_iff (by exact_mod_cast d.ne' : (decodedDen T k:ℚ)≠0)).mpr (by rw [n,v])
  simpa only [Rat.cast_div,Rat.cast_natCast,y] using congrArg (fun q : ℚ => (q:ℝ)) eq

/-- The two rates are integer quotients with small constant numerators and
denominators, relative to the fixed constants of the paper. -/
theorem physical_rate_integers :
    firstProportion = (firstRateQ.num.toNat:ℝ)/firstRateQ.den ∧
    secondProportion = (secondRateQ.num.toNat:ℝ)/secondRateQ.den := by
  norm_num [firstProportion,secondProportion,firstRateQ,secondRateQ,layerOne,degree,layerDegreeQ,firstDegreeQ]
  norm_num [show Int.toNat 15609923359958673284671 = 15609923359958673284671 from rfl,
    show Int.toNat 4702576640041326715329 = 4702576640041326715329 from rfl]

/-- Sparse tape input and TV bound for the exact output of the label-level
bisection. No slot-expanded decoder or common capacity denominator is used. -/
theorem decoded_sparse_layer (S : SimpleEdgeStream E V) (b : V→ℕ) (hb : ∀ v, 0<b v) (rank : Slots b ↪ ℕ)
    (k q T : ℕ) (u : E→ℕ) (hT : 0<T) (θn θd D : ℕ) (hD : 0<D)
    (δ η : ℝ) (hδ : 0<δ ∧ δ≤1) (hη : 0<η) (K : ℕ) :
    let Y := fun e => (decodedCoordinate S b k q (fun i => (u i:ℚ)/T) e:ℝ)
    (∀ v, ((θn:ℝ)/θd)*Capacity.slotLoad S.ends b Y v ≤ layerOne) →
    ((θn:ℝ)/θd)*(∑ e, Y e)+Real.log (1/η) ≤ K*Real.log 2 →
    ∃ I : Input pairVertices (layerSupport S b rank),
      I.rational = discretize (slotNum S b (decodedNum S b k q T u) θn) (slotDen b (decodedDen T k) θd) D hD ∧
      variation Finset.univ (Shearer.probability pairVertices (layerSupport S b rank)
        (fun p => slotWeight b (labelTable S.ends Y) ((θn:ℝ)/θd) p.1 p.2)) (outcomeLaw I δ hδ K).mass ≤
        (layerSupport S b rank).card/D+δ+η := by
  intro Y hdeg hk
  let a := decodedNum S b k q T u
  let d := decodedDen T k
  have eq : (fun e => (a e:ℝ)/d) = Y := funext (decoded_number S b k q T u hT)
  let deg (v) : ((θn:ℝ)/θd)*Capacity.slotLoad S.ends b (fun e=>(a e:ℝ)/d) v ≤ layerOne := by rw [eq]; exact hdeg v
  refine ⟨physicalLayerInput S b hb rank a d θn θd D hD deg,rfl,?_⟩
  rw [←eq] at hk ⊢
  exact physicalLayer_original_budget S b hb rank a d θn θd D hD deg δ η hδ hη K hk

end SubmodularMatching.AppendixM
