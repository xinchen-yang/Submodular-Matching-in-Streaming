import SubmodularMatching.CapacityClip

/-! When a capacity is announced only on first appearance, restore it from
one clipped integer per previously seen vertex. -/
namespace SubmodularMatching.Capacity
open Finset UpperBoundAssembly

variable {V : Type*} [DecidableEq V] [Fintype V]

abbrev CapacityCache (V : Type*) := List (V × ℕ)

def CacheValid (b : V → ℕ) (cache : CapacityCache V) : Prop :=
  (cache.map Prod.fst).Nodup ∧ ∀ e∈cache, e.2=clipped b e.1

def getCapacity (cache : CapacityCache V) (v : V) (a : Option ℕ) :
    Option (ℕ × CapacityCache V) :=
  match cache.lookup v with
  | some c => some (c,cache)
  | none => a.map fun c =>
    let c' := min c (Fintype.card V-1)
    (c',(v,c')::cache)

theorem capacityCache_lookup_none (v : V) (cache : CapacityCache V) :
    cache.lookup v = none ↔ v ∉ cache.map Prod.fst := by
  induction cache with
  | nil => simp [List.lookup]
  | cons p rows ih =>
    by_cases he : v=p.1
    · simp [he,List.lookup]
    · simpa [List.lookup,beq_eq_false_iff_ne.mpr he,he] using ih

private theorem cache_lookup_sound (cache : CapacityCache V) (b : V → ℕ)
    (h : ∀ e∈cache, e.2=clipped b e.1) (v : V) (c : ℕ)
    (hc : cache.lookup v=some c) : c=clipped b v := by
  induction cache with
  | nil => simp [List.lookup] at hc
  | cons p rows ih =>
    by_cases he : v=p.1
    · subst v
      have eq : p.2=c := by simpa [List.lookup] using hc
      exact eq ▸ h _ List.mem_cons_self
    · have hlook : rows.lookup v=some c := by simpa [List.lookup,beq_eq_false_iff_ne.mpr he] using hc
      exact ih (fun e hh => h e (List.mem_cons_of_mem _ hh)) hlook

theorem getCapacity_correct (b : V → ℕ) (cache : CapacityCache V) (v : V) (a : Option ℕ)
    (hcache : CacheValid b cache)
    (fresh : cache.lookup v=none → a=some (b v)) :
    ∃ next, getCapacity cache v a=some (clipped b v,next) ∧ CacheValid b next := by
  cases h : cache.lookup v with
  | none =>
    have ha := fresh h
    refine ⟨(v,clipped b v)::cache,by simp [getCapacity,h,ha,clipped],?_⟩
    refine ⟨List.nodup_cons.mpr ⟨(capacityCache_lookup_none _ _).mp h,hcache.1⟩,?_⟩
    intro x hx
    rcases List.mem_cons.mp hx with rfl|hx
    · rfl
    · exact hcache.2 _ hx
  | some c =>
    have he := cache_lookup_sound cache b hcache.2 v c h
    exact ⟨cache,by simp [getCapacity,h,he],hcache⟩

def decodeArrival (cache : CapacityCache V) (u v : V) (a b : Option ℕ) :
    Option ((ℕ × ℕ) × CapacityCache V) := do
  let (left,mem) ← getCapacity cache u a
  let (right,mem') ← getCapacity mem v b
  pure ((left,right),mem')

theorem decodeArrival_correct (cap : V → ℕ) (cache : CapacityCache V) (u v : V)
    (left right : Option ℕ) (h : CacheValid cap cache)
    (hl : cache.lookup u=none → left=some (cap u))
    (hr : ∀ state, CacheValid cap state → getCapacity cache u left=some (clipped cap u,state) →
      state.lookup v=none → right=some (cap v)) :
    ∃ state, decodeArrival cache u v left right=some ((clipped cap u,clipped cap v),state) ∧ CacheValid cap state := by
  obtain ⟨mem,hl',hmem⟩ := getCapacity_correct cap cache u left h hl
  obtain ⟨mem',hr',hmem'⟩ := getCapacity_correct cap mem v right hmem (hr mem hmem hl')
  exact ⟨mem',by simp [decodeArrival,hl',hr'],hmem'⟩

theorem capacityCache_words (b : V → ℕ) (cache : CapacityCache V)
    (h : CacheValid b cache) : 2*cache.length ≤ 2*Fintype.card V := by
  apply Nat.mul_le_mul_left
  have hh := card_le_univ ((cache.map Prod.fst).toFinset)
  rw [List.toFinset_card_of_nodup h.1,List.length_map] at hh
  exact hh

end SubmodularMatching.Capacity
