import SubmodularMatching.CapacityPadding
import SubmodularMatching.CapacityInitialOutput
import SubmodularMatching.CapacityRealWordScheduler
import SubmodularMatching.UpperBoundCandidateLaw

/-! Input filtering and the cached incumbent for the signed capacity algorithm. -/
namespace SubmodularMatching.Capacity
open UpperBoundAssembly Streaming Finset GibbsSampler
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]

abbrev Admissible (S : SimpleEdgeStream E V) (cap : V → ℕ) :=
  {e // positiveEnds S.ends (clipped cap) e}

def admissibleStream (S : SimpleEdgeStream E V) (cap : V → ℕ) :=
  positiveStream S (clipped cap)

def effectiveCapacity (cap : V → ℕ) (v : V) := max 1 (clipped cap v)

def originalLabels (S : SimpleEdgeStream E V) (cap : V → ℕ)
    (s : Finset (Admissible S cap)) : Finset E :=
  s.map (Function.Embedding.subtype _)

theorem effective_feasible_iff (S : SimpleEdgeStream E V) (cap : V → ℕ)
    (s : Finset (Admissible S cap)) :
    feasible (admissibleStream S cap).ends (effectiveCapacity cap) s ↔
      feasible S.ends cap (originalLabels S cap s) :=
  (padded_positive_stream S (clipped cap) s).trans
    ((positive_feasible_iff S.ends (clipped cap) s).trans
      (feasible_clipped_iff S cap (originalLabels S cap s)))

theorem original_optimum_lifts (S : SimpleEdgeStream E V) (cap : V → ℕ)
    (f : Finset E → ℝ) (O : Finset E)
    (hO : feasible S.ends cap O) (hopt : ∀ A, feasible S.ends cap A → f A ≤ f O) :
    ∃ T : Finset (Admissible S cap), originalLabels S cap T = O ∧
      feasible (admissibleStream S cap).ends (effectiveCapacity cap) T ∧
      ∀ A, feasible (admissibleStream S cap).ends (effectiveCapacity cap) A →
        f (originalLabels S cap A) ≤ f (originalLabels S cap T) := by
  obtain ⟨T,_,hmap⟩ := positive_lift S cap O hO
  have hlabel : originalLabels S cap T = O := hmap
  refine ⟨T,hlabel,(effective_feasible_iff S cap T).2 (hlabel ▸ hO),?_⟩
  intro A hA
  simpa only [hlabel] using hopt _ ((effective_feasible_iff S cap A).1 hA)

theorem effectiveCapacity_pos (cap : V → ℕ) (v : V) :
    0 < effectiveCapacity cap v := Nat.zero_lt_one.trans_le (le_max_left _ _)

theorem effectiveCapacity_le (cap : V → ℕ) (v : V) :
    effectiveCapacity cap v ≤ Fintype.card V := by
  refine max_le (Fintype.card_pos_iff.mpr ⟨v⟩) ?_
  exact (min_le_right _ _).trans (Nat.sub_le _ _)

/-- At most one label and its exact oracle value accompany the active bank. -/
def realIncumbent (f : Finset E → ℝ) (edges : ℕ → E) : ℕ → Option E × ℝ
  | 0 => (none, f ∅)
  | k+1 =>
    let old := realIncumbent f edges k
    let newValue := f {edges k}
    if old.2 < newValue then (some (edges k), newValue) else old

def incumbentSet : Option E → Finset E
  | none => ∅
  | some e => {e}

theorem realIncumbent_value (f : Finset E → ℝ) (edges : ℕ → E) (hn : 0 ≤ f ∅)
    (k : ℕ) :
    f (incumbentSet (realIncumbent f edges k).1) = (realIncumbent f edges k).2 ∧
    (realIncumbent f edges k).2 = singletonMaximum (RealOracle.edgeClock edges f) (k+1) := by
  induction k with
  | zero =>
    simp [realIncumbent,incumbentSet,RealOracle.edgeClock,singletonMaximum,hn]
  | succ k ih =>
    rw [realIncumbent]
    rw [show singletonMaximum (RealOracle.edgeClock edges f) (k+1+1) =
      max (singletonMaximum (RealOracle.edgeClock edges f) (k+1)) (f {edges k}) from rfl]
    rw [← ih.2]
    split_ifs with h
    · exact ⟨rfl,(max_eq_right h.le).symm⟩
    · exact ⟨ih.1,(max_eq_left (le_of_not_gt h)).symm⟩

theorem realIncumbent_feasible (ends : E → V × V) (cap : V → ℕ)
    (positive : ∀ e, 0<cap (ends e).1 ∧ 0<cap (ends e).2) (f : Finset E → ℝ)
    (edges : ℕ → E) (k : ℕ) :
    feasible ends cap (incumbentSet (realIncumbent f edges k).1) := by
  induction k with
  | zero => intro v; simp [realIncumbent,incumbentSet,incidences]
  | succ k ih =>
    rw [realIncumbent]
    split_ifs
    · exact singleton_feasible ends cap positive _
    · exact ih

theorem realIncumbent_zero_value (f : Finset E → ℝ) (edges : ℕ → E)
    (hf : IsSubmodular f) (hn : ∀ A, 0 ≤ f A) (k : ℕ)
    (hzero : (realIncumbent f edges k).2 = 0) (s : Finset E)
    (hs : s ⊆ (range k).image edges) : f s = 0 := by
  have hz : singletonMaximum (RealOracle.edgeClock edges f) (k+1)=0 :=
    ((realIncumbent_value f edges (hn ∅) k).2).symm.trans hzero
  have hbase : f ∅ = 0 := by
    have le := singleton_le_maximum (RealOracle.edgeClock edges f) (show 0 < k+1 by omega)
    rw [hz] at le
    exact le_antisymm le (hn ∅)
  apply zero_scale_objective f hf hn _ hbase _ s hs
  intro e he
  obtain ⟨i,hi,rfl⟩ := mem_image.mp he
  have le := singleton_le_maximum (RealOracle.edgeClock edges f)
    (show i+1<k+1 by simpa using hi)
  rw [hz] at le
  exact le_antisymm le (hn _)

theorem originalLaw_expected (S : SimpleEdgeStream E V) (cap : V → ℕ)
    (q : CandidateLaw (Finset (Admissible S cap))) (test : Finset E → ℝ) :
    let law := q.map (originalLabels S cap)
    expected law.outcomes law.mass test = expected q.outcomes q.mass (fun a => test (originalLabels S cap a)) :=
  q.map_expected (originalLabels S cap) test

end
end SubmodularMatching.Capacity
