import SubmodularMatching.StreamingK1RealArchives
import SubmodularMatching.StreamingK1RealFreshLaw
import SubmodularMatching.UpperBoundWordSupport
import SubmodularMatching.UpperBoundVertexPeak

/-! # Sparse row bound for every outcome of the fresh real source -/

namespace SubmodularMatching.Streaming.RealSource

open GibbsSampler UpperBoundAssembly

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

omit [DecidableEq V] in
theorem freshGuessIndex_positiveOnSupport (P : ScheduledSource E V) (N : ℕ) (p : ℚ) (edge : E)
    (singleton : ℝ) (old : OnlineStreamState E V) (j : ℕ) :
    (freshGuessIndex P N p edge singleton old j).PositiveOnSupport := by
  classical
  unfold freshGuessIndex
  exact CandidateLaw.map_positiveOnSupport _ _ (CandidateLaw.wordBatchLaw_positiveOnSupport _ _ _)

theorem freshStateStep_positiveOnSupport (P : ScheduledSource E V) (R : GridUpdateParameters)
    (N : ℕ) (p : ℚ) (arrival : ℕ) (old : OnlineStreamState E V) :
    (freshStateStep P R N p arrival old).PositiveOnSupport := by
  classical
  unfold freshStateStep
  apply CandidateLaw.map_positiveOnSupport
  apply CandidateLaw.assign_positiveOnSupport
  intro j
  exact freshGuessIndex_positiveOnSupport P N p _ _ old j

theorem freshPrefixLaw_positiveOnSupport (P : ScheduledSource E V) (R : GridUpdateParameters)
    (N : ℕ) (p : ℚ) (stop : ℕ) : (freshPrefixLaw P R N p stop).PositiveOnSupport := by
  unfold freshPrefixLaw
  exact CandidateLaw.execute_positiveOnSupport _ (freshStateStep_positiveOnSupport P R N p) _ _ _

/-- Every reached sparse state is attained by the reference analysis
transcript. The proof uses the positivity of the actual finite word draws. -/
theorem freshPrefixLaw_attained (P : ScheduledSource E V) (R : GridUpdateParameters)
    (hW : 1 ≤ P.width) (hR : ∀ τ > 0, R.Matches (P.config τ))
    (N : ℕ) (p : ℚ) (stop : ℕ) (hstop : stop ≤ P.arrivals) (st : OnlineStreamState E V)
    (hst : st ∈ (freshPrefixLaw P R N p stop).outcomes) :
    ∃ b ∈ (sourceRealWordTape P N p).outcomes, stateFromBatches P R b stop = st := by
  exact CandidateLaw.mem_image_of_expected_eq (freshPrefixLaw P R N p stop) (sourceRealWordTape P N p)
    (fun b => stateFromBatches P R b stop) (freshPrefixLaw_value P R hW hR N p stop hstop) st hst
    (freshPrefixLaw_positiveOnSupport P R N p stop st hst)

theorem freshPrefix_archiveRows_le (P : ScheduledSource E V) (R : GridUpdateParameters)
    (p : ℚ) (hW : 1 ≤ P.width) (hR : ∀ τ > 0, R.Matches (P.config τ))
    {N : ℕ} (hN : 0 < N) (stop : ℕ) (hstop : stop ≤ P.arrivals)
    (hunique : ∀ i < stop, ∀ j < stop, P.edges i = P.edges j → i = j)
    (bound : ℕ) (allEdges M : Finset E)
    (hin : ∀ i < stop, P.edges i ∈ allEdges)
    (hloop : ∀ e ∈ allEdges, (P.ends e).1 ≠ (P.ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet P.ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet P.ends) A →
      A.card ≤ M.card)
    (hbound : ∀ τ > 0, (P.config τ).incidenceLimit ≤ bound)
    (st : OnlineStreamState E V) (hst : st ∈ (freshPrefixLaw P R N p stop).outcomes) :
    st.archiveRows + st.instances.length ≤ (6 * M.card * bound + 1) * (P.span + 1) := by
  obtain ⟨b, hb, rfl⟩ := freshPrefixLaw_attained P R hW hR N p stop hstop st hst
  have hrows := online_snapshot_archiveRows_bound P R P.width p hW P.width_bound rfl hR
    b stop hstop hN hb hunique bound allEdges M hin hloop hMsub hM hmax hbound
  have hlen : (stateFromBatches P R b stop).instances.length ≤ P.span + 1 := by
    calc
      _ = ((stateFromBatches P R b stop).instances.map Prod.fst).length := by simp
      _ = ((runOnlineEpoch P.width P.span P.value stop).active P.width P.span).length := by
        rw [stateFromBatches, runOnlineIndexed_keys]
      _ ≤ _ := (runOnlineEpoch P.width P.span P.value stop).active_length_le P.width P.span
  calc
    _ ≤ 3 * (2 * M.card * bound * (P.span + 1)) + (P.span + 1) := Nat.add_le_add hrows hlen
    _ = _ := by ring

/-- Reserve cells for the actual sparse archives and their frozen
coordinates, one compact optimizer/rounding scratch region, and the
single incumbent and its comparison index. -/
def OnlineStreamState.postprocessWorkspace (st : OnlineStreamState E V)
    (scratch incumbent : ℕ) : ℕ :=
  16 * st.archiveRows + 8 * st.instances.length + scratch + 2 * incumbent + 16

theorem OnlineStreamState.postprocessWorkspace_le (st : OnlineStreamState E V)
    {ν I L w incumbent m : ℕ} (hw : 1 ≤ w)
    (hrows : st.archiveRows + st.instances.length ≤ (6 * ν * I * w + 1) * (L * w))
    (hincumbent : incumbent ≤ ν) (storedEnds : Fin m → V × V) (j : ℕ)
    (hcurrent : m ≤ (st.initialize false j).edges.length) :
    let scratch := sequentialGuessScratch (Fintype.card (IncidentVertex storedEnds)) m
    st.postprocessWorkspace scratch incumbent ≤ (288 * I * L + 48 * L + 50) * (ν + 1) * w ^ 2 := by
  intro scratch
  have hm : m ≤ st.archiveRows := hcurrent.trans (st.initialize_edge_rows_le false j)
  have hs : scratch ≤ 32 * (st.archiveRows + 1) :=
    (sequentialGuessScratch_le storedEnds).trans (Nat.mul_le_mul_left _ (Nat.add_le_add_right hm 1))
  have hw2 : 1 ≤ w ^ 2 := one_le_pow₀ hw
  have hws : w ≤ w ^ 2 := by
    rw [pow_two]
    exact Nat.le_mul_of_pos_right _ (by omega)
  unfold OnlineStreamState.postprocessWorkspace
  calc
    _ ≤ 48 * (st.archiveRows + st.instances.length) + (2 * ν + 48) := by omega
    _ ≤ 48 * ((6 * ν * I * w + 1) * (L * w)) + (2 * ν + 48) :=
      Nat.add_le_add_right (Nat.mul_le_mul_left _ hrows) _
    _ = (288 * I * L * ν) * w ^ 2 + (48 * L) * w + (2 * ν + 48) := by ring
    _ ≤ (288 * I * L * (ν + 1)) * w ^ 2 + (48 * L * (ν + 1)) * w ^ 2 +
        (50 * (ν + 1)) * w ^ 2 := by
      apply Nat.add_le_add
      · apply Nat.add_le_add
        · exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (Nat.le_succ _))
        · exact (Nat.mul_le_mul_left _ hws).trans
            (Nat.mul_le_mul_right _ (Nat.le_mul_of_pos_right _ (by omega)))
      · exact (show 2 * ν + 48 ≤ 50 * (ν + 1) by omega).trans (Nat.le_mul_of_pos_right _ hw2)
    _ = _ := by ring

/-- Working indices for a sequential optimizer and its retained incumbent,
on every realized state of the fresh source law. -/
theorem freshPrefix_postprocessWorkspace_le (P : ScheduledSource E V) (R : GridUpdateParameters)
    (p : ℚ) (hW : 1 ≤ P.width) (hR : ∀ τ > 0, R.Matches (P.config τ))
    {N : ℕ} (hN : 0 < N) (stop : ℕ) (hstop : stop ≤ P.arrivals)
    (hunique : ∀ i < stop, ∀ j < stop, P.edges i = P.edges j → i = j)
    (I L : ℕ) (allEdges M : Finset E)
    (hin : ∀ i < stop, P.edges i ∈ allEdges)
    (hloop : ∀ e ∈ allEdges, (P.ends e).1 ≠ (P.ends e).2)
    (hMsub : M ⊆ allEdges) (hM : IsMatchingOn (endpointSet P.ends) M)
    (hmax : ∀ A : Finset E, A ⊆ allEdges → IsMatchingOn (endpointSet P.ends) A →
      A.card ≤ M.card)
    (st : OnlineStreamState E V) (hst : st ∈ (freshPrefixLaw P R N p stop).outcomes)
    (incumbent : ℕ) (hincumbent : incumbent ≤ M.card) {m : ℕ} (storedEnds : Fin m → V × V)
    (j : ℕ) (hcurrent : m ≤ (st.initialize false j).edges.length) (wordMultiplier : ℕ) :
    let w := (P.vertices + 1).log2 + 1
    let scratch := sequentialGuessScratch (Fintype.card (IncidentVertex storedEnds)) m
    let cells := st.postprocessWorkspace scratch incumbent
    let C := 288 * I * L + 48 * L + 50
    (∀ τ > 0, (P.config τ).incidenceLimit ≤ I * w) → P.span + 1 ≤ L * w →
      cells ≤ C * (M.card + 1) * w ^ 2 ∧
        cells * wordMultiplier * w ≤ (C * wordMultiplier) * (M.card + 1) * w ^ 3 := by
  intro w scratch cells C hI hL
  have h := freshPrefix_archiveRows_le P R p hW hR hN stop hstop hunique (I * w) allEdges M hin
    hloop hMsub hM hmax hI st hst
  have hrows : st.archiveRows + st.instances.length ≤ (6 * M.card * I * w + 1) * (L * w) := by
    calc
      _ ≤ (6 * M.card * (I * w) + 1) * (P.span + 1) := h
      _ ≤ (6 * M.card * (I * w) + 1) * (L * w) := Nat.mul_le_mul_left _ hL
      _ = _ := by ring
  have hw : 1 ≤ w := by dsimp [w]; omega
  have hcells := st.postprocessWorkspace_le hw hrows hincumbent storedEnds j hcurrent
  exact ⟨hcells, sequentialWorkspace_bitCapacity hcells⟩

end

end SubmodularMatching.Streaming.RealSource
