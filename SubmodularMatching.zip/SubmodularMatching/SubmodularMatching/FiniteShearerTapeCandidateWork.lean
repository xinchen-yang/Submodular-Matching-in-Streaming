import SubmodularMatching.FiniteShearerTapeCandidate
import SubmodularMatching.GibbsSpectralSize
import SubmodularMatching.UpperBoundVertexSamplerBudget

/-!
# Transition visits for the actual compact Gibbs call

The active edge list is exactly the list selected by the integer activity
preprocessor. Prefixes of the supplied tape determine the live mate
table at each transition in the ghost work count.
-/

namespace SubmodularMatching.GibbsSampler

open scoped BigOperators

variable {E : Type*} [DecidableEq E]

/-- One inspected proposal counts once. The implementation makes two
mate reads per inspected proposal. -/
def arrayGibbsScanVisits {n : ℕ} (ep : E → Fin n × Fin n)
    (activity : E → ActivityWords) (active : List E) (m bits : ℕ)
    (state : Array (Option E)) (word : ℕ) : ℕ :=
  (arrayGibbsWork ep activity active m bits state word).1 / 2

theorem arrayGibbsScanVisits_le {n : ℕ} (ep : E → Fin n × Fin n)
    (activity : E → ActivityWords) (active : List E) (m bits : ℕ)
    (state : Array (Option E)) (word : ℕ) :
    arrayGibbsScanVisits ep activity active m bits state word ≤ active.length := by
  unfold arrayGibbsScanVisits
  have h := Nat.div_le_div_right (c := 2) (arrayGibbsWork_bound ep activity active m bits state word).1
  simpa only [Nat.mul_comm 2, Nat.mul_div_cancel _ (by decide : 0 < 2)] using h

/-- Work along the supplied tape. The prefix replay in this definition
is used to refer to the current state and is not part of the execution. -/
def arrayGibbsWalkScanVisits {n : ℕ} (ep : E → Fin n × Fin n)
    (activity : E → ActivityWords) (active : List E) (m bits steps : ℕ)
    (tape : Fin steps → Fin (2^bits)) : ℕ :=
  ∑ i : Fin steps, arrayGibbsScanVisits ep activity active m bits
    (arrayGibbsRun ep activity active m bits i.val
      (fun j => tape ⟨j.val,j.isLt.trans i.isLt⟩)) (tape i).val

theorem arrayGibbsWalkScanVisits_le {n : ℕ} (ep : E → Fin n × Fin n)
    (activity : E → ActivityWords) (active : List E) (m bits steps : ℕ)
    (tape : Fin steps → Fin (2^bits)) :
    arrayGibbsWalkScanVisits ep activity active m bits steps tape ≤ steps*active.length := by
  unfold arrayGibbsWalkScanVisits
  calc
    _ ≤ ∑ _ : Fin steps, active.length := Finset.sum_le_sum fun _ _ => arrayGibbsScanVisits_le _ _ _ _ _ _ _
    _ = _ := by simp

end SubmodularMatching.GibbsSampler

namespace SubmodularMatching.UpperBoundAssembly

open GibbsSampler Joint TwoStage NumericalCertificate

noncomputable section

variable {m N : ℕ} {V : Type*} [DecidableEq V]

/-- Integer activity words used by the compact candidate's second sampler. -/
def compactAppendixGibbsActivityWords (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (first : Finset (Fin m)) : Fin m → ActivityWords :=
  let ep := restrictEnds ends
  let t := appendixRoundedPoint ep tau w f Q draw
  let z := shearerAltered ep t.1 t.2 (roundingError / 4) first
  activityWordsFromStoredGrid (numberedEnds ends) 799999999 800000000 (appendixAlteredDenominator m)
    (fun e => appendixAlteredIndex m (z e)) (List.finRange m)

def compactAppendixGibbsActive (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (first : Finset (Fin m)) : List (Fin m) :=
  positiveActivityList (compactAppendixGibbsActivityWords ends tau w f Q draw first) (List.finRange m)

/-- This supplies the active-edge premise of the compact resource bounds
for each guess, repetition and realized first matching. -/
theorem compactAppendixGibbsActive_le (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (first : Finset (Fin m)) :
    (compactAppendixGibbsActive ends tau w f Q draw first).length ≤ m := by
  unfold compactAppendixGibbsActive positiveActivityList
  exact (List.length_filter_le _ _).trans_eq List.length_finRange

def compactAppendixGibbsWalkScanVisits (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (first : Finset (Fin m)) :
    let active := compactAppendixGibbsActive ends tau w f Q draw first
    let n := (incidentVertexList ends).length
    let D := appendixGibbsDenominator n
    let steps := lowActivitySteps n active.length (lowActivityPrecision D)
    let bits := lowActivityBits steps active.length D
    (Fin steps → Fin (2^bits)) → ℕ :=
  fun tape =>
    arrayGibbsWalkScanVisits (numberedEnds ends)
      (compactAppendixGibbsActivityWords ends tau w f Q draw first)
      (compactAppendixGibbsActive ends tau w f Q draw first)
      (compactAppendixGibbsActive ends tau w f Q draw first).length _ _ tape

theorem compactAppendixGibbsWalkScanVisits_le (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (first : Finset (Fin m)) :
    let active := compactAppendixGibbsActive ends tau w f Q draw first
    let n := (incidentVertexList ends).length
    let D := appendixGibbsDenominator n
    let steps := lowActivitySteps n active.length (lowActivityPrecision D)
    let bits := lowActivityBits steps active.length D
    ∀ tape : Fin steps → Fin (2^bits),
      compactAppendixGibbsWalkScanVisits ends tau w f Q draw first tape ≤ steps*active.length := by
  intro active n D steps bits tape
  exact arrayGibbsWalkScanVisits_le (numberedEnds ends)
    (compactAppendixGibbsActivityWords ends tau w f Q draw first) active active.length bits steps tape


/-- The actual compact Gibbs visit count obeys the polynomial budget
for all first-stage outputs and all supplied second-stage tapes. -/
theorem compactAppendixGibbsWalkScanVisits_polynomial (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q : ℕ) (draw : AppendixDraw m N)
    (first : Finset (Fin m)) :
    let active := compactAppendixGibbsActive ends tau w f Q draw first
    let n := (incidentVertexList ends).length
    let D := appendixGibbsDenominator n
    let steps := lowActivitySteps n active.length (lowActivityPrecision D)
    let bits := lowActivityBits steps active.length D
    ∀ tape : Fin steps → Fin (2^bits),
      compactAppendixGibbsWalkScanVisits ends tau w f Q draw first tape ≤
        (40*(1+2*80000000001))*(m+1)^8 := by
  intro active n D steps bits tape
  have hActive : active.length ≤ m := compactAppendixGibbsActive_le ends tau w f Q draw first
  have hVertices : n ≤ 2*m := incidentVertexList_length_le ends
  have hSteps := (compactGibbs_budget n m active.length hVertices hActive).1
  have hWork := compactAppendixGibbsWalkScanVisits_le ends tau w f Q draw first tape
  calc
    _ ≤ steps*active.length := hWork
    _ ≤ ((40*(1+2*80000000001))*(m+1)^7)*(m+1) :=
      Nat.mul_le_mul hSteps (hActive.trans (Nat.le_succ _))
    _ = _ := by ring

/-- The stored list of a simple graph has at most one edge for each
unordered vertex pair. This supplies the stored-edge size premise. -/
theorem compactAppendixStoredCard_le [Fintype V] (ends : Fin m → V × V)
    (hDistinct : ∀ e, (ends e).1 ≠ (ends e).2)
    (hSimple : Function.Injective (pairEnds ends)) :
    m ≤ (Fintype.card V).choose 2 := by
  simpa using simple_graph_edge_count (pairEnds ends) (Finset.univ : Finset (Fin m))
    (fun e _ => pairEnds_card_two ends hDistinct e) hSimple.injOn

end

end SubmodularMatching.UpperBoundAssembly
