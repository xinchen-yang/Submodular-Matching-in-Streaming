import SubmodularMatching.NonmonotoneJointOutputs
import SubmodularMatching.NonmonotoneSelectorCosts

/-! Exact trial and comparison counts for the final bank selection. -/
namespace SubmodularMatching.AppendixM
open Capacity UpperBoundAssembly GibbsSampler
noncomputable section
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

def countedAfterSignedPass {b : V → ℕ} (f : Finset E→ℝ) (δ : ℝ) (amp : Bool)
    (rounding : ℕ→ℝ→SparseSlots E b→CandidateLaw (Finset E))
    (st : RealOracle.GuessBank (SparseSlots E b) × (Option E × ℝ)) :
    CandidateLaw (Finset E × SelectionWork) :=
  let init := incumbentSet st.2.1
  let B := st.2.2
  if B=0 then CandidateLaw.pure (init,⟨0,0⟩) else
    let qs := bankCandidates (fun _ => rounding (sourceFailureBudget δ)) st.1
    if amp then countedIncumbentRepeat f (outerError*B/2) (selectorUnit*B) qs init (postprocessCount δ) init
    else countedIncumbentScan f (outerError*B/2) qs init

theorem countedAfterSignedPass_observe {b : V→ℕ} (f test : Finset E→ℝ) (δ : ℝ) (amp : Bool)
    (rounding : ℕ→ℝ→SparseSlots E b→CandidateLaw (Finset E))
    (st : RealOracle.GuessBank (SparseSlots E b) × (Option E × ℝ)) :
    let p := countedAfterSignedPass f δ amp rounding st
    let q := afterSignedPass f δ amp rounding st
    expected p.outcomes p.mass (test ∘ Prod.fst) = expected q.outcomes q.mass test := by
  dsimp only
  unfold countedAfterSignedPass afterSignedPass
  dsimp only
  split_ifs
  · simp [CandidateLaw.pure_expected]
  · exact countedRepeat_observe _ _ _ _ _ _ _ _
  · exact countedScan_observe _ _ _ _ _

theorem countedAfterSignedPass_work {b : V→ℕ} (f : Finset E→ℝ) (δ : ℝ) (amp : Bool)
    (rounding : ℕ→ℝ→SparseSlots E b→CandidateLaw (Finset E))
    (st : RealOracle.GuessBank (SparseSlots E b) × (Option E × ℝ)) (z : Finset E × SelectionWork)
    (hz : z∈(countedAfterSignedPass f δ amp rounding st).outcomes) :
    let R := if amp then postprocessCount δ else 1
    z.2.trials ≤ R*st.1.states.length ∧ z.2.comparisons ≤ R*(st.1.states.length+1) := by
  classical
  intro R
  unfold countedAfterSignedPass at hz
  dsimp only at hz
  split at hz
  · have he : z=(incumbentSet st.2.1,⟨0,0⟩) := by simpa [CandidateLaw.pure] using hz
    simp [he]
  · split at hz
    · have e := countedRepeat_cost _ _ _ _ _ _ _ _ hz
      simpa only [R,if_pos (by assumption : amp=true),bankCandidates,List.length_map] using
        And.intro e.1.le e.2.le
    · have e := countedScan_cost _ _ _ _ _ hz
      simp only [R,if_neg (by assumption : ¬amp=true),one_mul]
      simp only [bankCandidates,List.length_map] at e
      omega

end
end SubmodularMatching.AppendixM
