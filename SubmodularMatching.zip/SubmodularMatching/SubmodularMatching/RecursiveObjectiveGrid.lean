import SubmodularMatching.RecursiveObjective

/-! The recursive objective lies on the exact grid with denominator `p! M^p`. -/

namespace SubmodularMatching.RecursiveObjective

noncomputable section

/-- A real value lies on the rational grid with the indicated integer denominator. -/
def OnGrid (denominator : ℕ) (x : ℝ) : Prop :=
  ∃ numerator : ℤ, x * (denominator : ℝ) = (numerator : ℝ)

theorem onGrid_zero (d : ℕ) : OnGrid d 0 := by
  exact ⟨0, by simp⟩

theorem onGrid_nat (d n : ℕ) : OnGrid d (n : ℝ) := by
  refine ⟨(n : ℤ) * d, ?_⟩
  simp

theorem onGrid_min {d : ℕ} {x y : ℝ} (hx : OnGrid d x) (hy : OnGrid d y) :
    OnGrid d (min x y) := by
  rcases le_total x y with h | h
  · simpa [min_eq_left h] using hx
  · simpa [min_eq_right h] using hy

theorem stageMass_onGrid {E : Type*} (M : ℕ) (hM : 0 < M)
    (stage : E → ℕ) (label : E → Bool) (i : ℕ) (tag : Bool) (S : Finset E) :
    OnGrid M (stageMass (1 / (M : ℝ)) stage label i tag S) := by
  refine ⟨((S.filter (fun e => stage e = i ∧ label e = tag)).card : ℤ), ?_⟩
  rw [stageMass_eq_card]
  have hMR : (M : ℝ) ≠ 0 := by exact_mod_cast hM.ne'
  simp [hMR]

theorem raw_onGrid (C M d : ℕ) (hC : 0 < C) (g t z : ℝ)
    (hg : OnGrid M g) (ht : OnGrid M t) (hz : OnGrid d z) :
    OnGrid (C * M * d) (raw C g t z) := by
  rcases hg with ⟨kg, hg⟩
  rcases ht with ⟨kt, ht⟩
  rcases hz with ⟨kz, hz⟩
  refine ⟨kg * (C : ℤ) * d + kt * (C : ℤ) * d + ((C : ℤ) * M - kt) * kz, ?_⟩
  have hCR : (C : ℝ) ≠ 0 := by exact_mod_cast hC.ne'
  have hid : raw (C : ℝ) g t z * ((C : ℝ) * M * d) =
      (g * M) * C * d + (t * M) * C * d + ((C : ℝ) * M - t * M) * (z * d) := by
    unfold raw
    field_simp
  simp only [Nat.cast_mul]
  rw [hid, hg, ht, hz]
  push_cast
  ring

/-- Exact denominator bound from the lower-bound objective lemma, expressed
without introducing a separate rational-valued version of the same function. -/
theorem objective_onGrid {E : Type*} (M : ℕ) (hM : 0 < M)
    (stage : E → ℕ) (label : E → Bool) (count start : ℕ) (S : Finset E) :
    OnGrid (count.factorial * M ^ count)
      (objective (1 / (M : ℝ)) stage label start count S) := by
  induction count generalizing start with
  | zero => exact onGrid_zero _
  | succ n ih =>
    have hd : (n + 1).factorial * M ^ (n + 1) =
        (n + 1) * M * (n.factorial * M ^ n) := by
      rw [Nat.factorial_succ, pow_succ]
      ring
    have hg := stageMass_onGrid M hM stage label start true S
    have hb := stageMass_onGrid M hM stage label start false S
    have ht := onGrid_min hb (onGrid_nat M (n + 1))
    have hz := ih (start + 1)
    have hr := raw_onGrid (n + 1) M (n.factorial * M ^ n) (Nat.succ_pos n) _ _ _ hg ht hz
    rw [hd]
    simpa only [objective, Nat.cast_add, Nat.cast_one] using
      onGrid_min (onGrid_nat ((n + 1) * M * (n.factorial * M ^ n)) (n + 1)) hr

end

end SubmodularMatching.RecursiveObjective
