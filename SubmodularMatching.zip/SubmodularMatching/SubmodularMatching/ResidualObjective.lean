import SubmodularMatching.MarginalComparison
import SubmodularMatching.StreamingCharge
import Mathlib.Order.Monotone.Basic

open scoped BigOperators

namespace SubmodularMatching

variable {E : Type*} [DecidableEq E]

/-- The residual objective is normalized even if the original objective is not. -/
theorem residualValue_empty (edges : ℕ → E) (p : ℝ)
    (f : Finset E → ℝ) (n : ℕ) : residualValue edges p f n ∅ = 0 := by
  simp [residualValue]

/-- Averaging monotone residual objectives preserves monotonicity. -/
theorem residualValue_monotone (edges : ℕ → E) (p : ℝ)
    (f : Finset E → ℝ) (hm : IsMonotone f)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (n : ℕ) :
    IsMonotone (residualValue edges p f n) := by
  intro T U hTU
  apply bernoulliExpectation_mono edges (fun _ => p) _ _ n
    (fun _ _ => ⟨hp, hp1⟩)
  intro A
  exact sub_le_sub_right (hm _ _ (Finset.union_subset_union hTU (Finset.Subset.refl A))) _

/-- Averaging residual objectives preserves submodularity. -/
theorem residualValue_submodular (edges : ℕ → E) (p : ℝ)
    (f : Finset E → ℝ) (hf : IsSubmodular f)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (n : ℕ) :
    IsSubmodular (residualValue edges p f n) := by
  intro T U
  unfold residualValue
  rw [← bernoulliExpectation_add, ← bernoulliExpectation_add]
  apply bernoulliExpectation_mono edges (fun _ => p) _ _ n
    (fun _ _ => ⟨hp, hp1⟩)
  intro A
  have hu : (T ∪ A) ∪ (U ∪ A) = (T ∪ U) ∪ A := by
    ext e
    simp only [Finset.mem_union]
    tauto
  have hi : (T ∪ A) ∩ (U ∪ A) = (T ∩ U) ∪ A := by
    ext e
    simp only [Finset.mem_union, Finset.mem_inter]
    tauto
  have h := hf (T ∪ A) (U ∪ A)
  rw [hu, hi] at h
  linarith

/-- Monotonicity charges any fixed set to the random base and its residual. -/
theorem value_le_base_add_residual (edges : ℕ → E) (p : ℝ)
    (f : Finset E → ℝ) (hm : IsMonotone f)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (n : ℕ) (T : Finset E) :
    f T ≤ bernoulliExpectation edges (fun _ => p) f n +
      residualValue edges p f n T := by
  have h := bernoulliExpectation_mono edges (fun _ => p)
    (fun _ => f T) (fun A => f (T ∪ A)) n (fun _ _ => ⟨hp, hp1⟩)
    (fun A => hm T (T ∪ A) Finset.subset_union_left)
  rw [bernoulliExpectation_const] at h
  unfold residualValue
  rw [bernoulliExpectation_sub]
  linarith

/-- An antitone set function has decreasing expectation as the sampled prefix grows. -/
theorem bernoulliExpectation_antitone_prefix
    (edges : ℕ → E) (p : ℝ) (F : Finset E → ℝ)
    (hp : 0 ≤ p) (hp1 : p ≤ 1)
    (hF : ∀ A B, A ⊆ B → F B ≤ F A) :
    Antitone (bernoulliExpectation edges (fun _ => p) F) := by
  apply antitone_nat_of_succ_le
  intro n
  have h := bernoulliExpectation_mono edges (fun _ => p)
    (fun A => F (A ∪ {edges n})) F n (fun _ _ => ⟨hp, hp1⟩)
    (fun A => hF A (A ∪ {edges n}) Finset.subset_union_left)
  rw [bernoulliExpectation_succ]
  have hmul := mul_le_mul_of_nonneg_left h hp
  nlinarith

/-- A rejected edge's final residual is at most its expected marginal at
arrival, when the stored set was the shorter prefix. -/
theorem residualValue_singleton_le_prefix
    (edges : ℕ → E) (p : ℝ) (f : Finset E → ℝ)
    (hf : IsSubmodular f) (hm : IsMonotone f)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (n : ℕ) (e : E)
    (k : ℕ) (hkn : k ≤ n) :
    residualValue edges p f n {e} ≤
      bernoulliExpectation edges (fun _ => p) (fun A => marginal f e A) k := by
  have h := bernoulliExpectation_antitone_prefix edges p (fun A => marginal f e A)
    hp hp1 (fun A B hAB => marginal_antitone f hf hm A B e hAB) hkn
  simpa only [residualValue, marginal, Finset.union_comm] using h

namespace Streaming

/-- The exact-arithmetic charging core of Lemma 3.1, including the actual
independent-sample residual and its comparison to arrival marginals.
`arrivalIndex e` records the size of the stored prefix when a rejected edge
arrived. The hypotheses expose the rejection threshold; they do not assume
the final charging inequality. Finite-error, guessing and space guarantees
are not part of this theorem. -/
theorem ideal_streaming_charge
    {V : Type*} [DecidableEq V] [Fintype V]
    (ends : E → Finset V) (edges : ℕ → E) (n : ℕ) (M : Finset E)
    (hM : IsMatchingOn ends M) (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1)
    (f : Finset E → ℝ) (hf : IsSubmodular f) (hm : IsMonotone f)
    (potential : V → ℝ) (hpv : ∀ v, 0 ≤ potential v)
    (arrivalIndex : E → ℕ)
    (hindex : ∀ e ∈ M \ (Finset.range n).image edges, arrivalIndex e ≤ n)
    (hreject : ∀ e ∈ M \ (Finset.range n).image edges,
      bernoulliExpectation edges (fun _ => p) (fun A => marginal f e A) (arrivalIndex e) ≤
        ∑ v ∈ ends e, potential v) :
    f M ≤ bernoulliExpectation edges (fun _ => p) f n +
      residualValue edges p f n (M ∩ (Finset.range n).image edges) +
      ∑ v ∈ Finset.univ \ (M ∩ (Finset.range n).image edges).biUnion ends, potential v := by
  apply ideal_optimum_charge ends M ((Finset.range n).image edges) hM f
    (residualValue edges p f n) (bernoulliExpectation edges (fun _ => p) f n)
    (value_le_base_add_residual edges p f hm hp hp1 n M)
    (residualValue_submodular edges p f hf hp hp1 n)
    (residualValue_monotone edges p f hm hp hp1 n)
    (residualValue_empty edges p f n) potential hpv
  intro e he
  exact (residualValue_singleton_le_prefix edges p f hf hm hp hp1 n e
    (arrivalIndex e) (hindex e he)).trans (hreject e he)

end Streaming
end SubmodularMatching
