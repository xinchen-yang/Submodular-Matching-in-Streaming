import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull008_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 408, 409, 1, 0xcc998⟩ (by decide +kernel)

private def hull008_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 407, 409, 1, 0xcc997⟩ (by decide +kernel)

private def hull008_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 141, 132, 0x8d11822c4508911021c4308510820c410811001fc3f07d0f81ec3d0790f01dc3b0750e81cc390710e01bc3706d0d81ac350690d019c330650c818c310610c017c2f05d0b816c2d0590b015c2b0550a814c290510a013c2704d09812c2504909011c2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull008_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 354, 371, 1, 0xb9962⟩ (by decide +kernel)

private def hull008_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 371, 389, 1, 0xc2973⟩ (by decide +kernel)

private def hull008_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 371, 380, 1, 0xbe173⟩ (by decide +kernel)

private def hull008_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 380, 389, 1, 0xc297c⟩ (by decide +kernel)

private def hull008_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 380, 384, 1, 0xc017c⟩ (by decide +kernel)

private def hull008_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 384, 389, 1, 0xc2980⟩ (by decide +kernel)

private def hull008_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 384, 386, 2, 0x608c0980⟩ (by decide +kernel)

private def hull008_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 386, 389, 1, 0xc2982⟩ (by decide +kernel)

private def hull008_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 386, 387, 1, 0xc1982⟩ (by decide +kernel)

private def hull008_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 387, 389, 1, 0xc2983⟩ (by decide +kernel)

private def hull008_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 387, 388, 1, 0xc2183⟩ (by decide +kernel)

private def hull008_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 388, 389, 1, 0xc2984⟩ (by decide +kernel)

private def hull008_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 26, 35, 9, 0x118220420800f81e03a0700d81a⟩ (by decide +kernel)

private def hull008_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 380, 382, 1, 0xbf17c⟩ (by decide +kernel)

private def hull008_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 382, 384, 1, 0xc017e⟩ (by decide +kernel)

private def hull008_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 382, 383, 1, 0xbf97e⟩ (by decide +kernel)

private def hull008_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 383, 384, 1, 0xc017f⟩ (by decide +kernel)

private def hull008_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 389, 398, 1, 0xc7185⟩ (by decide +kernel)

private def hull008_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 398, 407, 1, 0xcb98e⟩ (by decide +kernel)

private def hull008_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 398, 402, 1, 0xc918e⟩ (by decide +kernel)

private def hull008_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 402, 407, 2, 0x65cca992⟩ (by decide +kernel)

private def hull008_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 402, 404, 1, 0xca192⟩ (by decide +kernel)

private def hull008_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 404, 405, 1, 0xca994⟩ (by decide +kernel)

private def hull008_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 405, 406, 1, 0xcb195⟩ (by decide +kernel)

private def hull008_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 406, 407, 1, 0xcb996⟩ (by decide +kernel)

private def hull008_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 21, 26, 5, 0xd01903005c0b015⟩ (by decide +kernel)

private def hull008_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 405, 407, 1, 0xcb995⟩ (by decide +kernel)

private def hull008_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 407, 408, 1, 0xcc197⟩ (by decide +kernel)

private def hull008_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 407, 416, 1, 0xd0197⟩ (by decide +kernel)

private def hull008_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 407, 425, 1, 0xd4997⟩ (by decide +kernel)

private def hull008_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 404, 407, 2, 0x65cca994⟩ (by decide +kernel)

private def hull008_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 402, 403, 1, 0xc9992⟩ (by decide +kernel)

private def hull008_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 403, 404, 1, 0xca193⟩ (by decide +kernel)

private def hull008_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 398, 400, 1, 0xc818e⟩ (by decide +kernel)

private def hull008_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 400, 402, 1, 0xc9190⟩ (by decide +kernel)

private def hull008_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 400, 401, 1, 0xc8990⟩ (by decide +kernel)

private def hull008_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 401, 402, 1, 0xc9191⟩ (by decide +kernel)

private def hull008_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 398, 399, 1, 0xc798e⟩ (by decide +kernel)

private def hull008_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 399, 400, 1, 0xc818f⟩ (by decide +kernel)

private def hull008_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 17, 26, 9, 0xd01903005c0b01502804c09011⟩ (by decide +kernel)

private def hull008_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 389, 393, 1, 0xc4985⟩ (by decide +kernel)

private def hull008_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 393, 398, 1, 0xc7189⟩ (by decide +kernel)

private def hull008_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 393, 395, 2, 0x62cc5189⟩ (by decide +kernel)

private def hull008_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 395, 398, 1, 0xc718b⟩ (by decide +kernel)

private def hull008_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 395, 396, 1, 0xc618b⟩ (by decide +kernel)

private def hull008_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 396, 398, 2, 0x638c698c⟩ (by decide +kernel)

private def hull008_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 389, 391, 1, 0xc3985⟩ (by decide +kernel)

private def hull008_050 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 391, 393, 1, 0xc4987⟩ (by decide +kernel)

private def hull008_051 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 393, 394, 1, 0xc5189⟩ (by decide +kernel)

private def hull008_052 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 394, 395, 1, 0xc598a⟩ (by decide +kernel)

private def hull008_053 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 391, 392, 1, 0xc4187⟩ (by decide +kernel)

private def hull008_054 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 392, 393, 1, 0xc4988⟩ (by decide +kernel)

private def hull008_055 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 389, 390, 1, 0xc3185⟩ (by decide +kernel)

private def hull008_056 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 390, 391, 1, 0xc3986⟩ (by decide +kernel)

private def hull008_057 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 389, 407, 1, 0xcb985⟩ (by decide +kernel)

private def hull008_058 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 389, 425, 1, 0xd4985⟩ (by decide +kernel)

private def hull008_059 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 380, 381, 1, 0xbe97c⟩ (by decide +kernel)

private def hull008_060 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 381, 382, 1, 0xbf17d⟩ (by decide +kernel)

private def hull008_061 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 30, 32, 2, 0x800f81e⟩ (by decide +kernel)

private def hull008_062 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 32, 35, 3, 0x4608810820⟩ (by decide +kernel)

private def hull008_063 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 371, 375, 1, 0xbb973⟩ (by decide +kernel)

private def hull008_064 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 375, 380, 3, 0x2f85e4bc177⟩ (by decide +kernel)

private def supportedCone1024 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨408, 409, 409, 408, 409⟩, ⟨2583614140, 130962241, 0, 0, 1275000000000, 666864814950⟩⟩
    hull008_000 1 (by decide +kernel)

private def supportedCone1025 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨407, 409, 407, 407, 409⟩, ⟨0, 0, 5000000000, 255407105, 1270000000000, 666609407845⟩⟩
    hull008_001 0 (by decide +kernel)

private def supportedCone1026 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨408, 409, 408, 408, 409⟩, ⟨0, 0, 2583614140, 130962241, 1272416385860, 666733852709⟩⟩
    hull008_000 0 (by decide +kernel)

private def supportedCone1027 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 43, 42, 44⟩, ⟨1798390801, 116302336, 1265352162, 86554930, 270000000000, 1218562464⟩⟩
    hull008_002 34 (by decide +kernel)

private def supportedCone1028 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨354, 371, 371, 354, 371⟩, ⟨23306969688, 5251936331, 0, 0, 1212372585047, 660668502430⟩⟩
    hull008_003 1 (by decide +kernel)

private def supportedCone1029 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 115, 114, 116⟩, ⟨5000000000, 1247777599, 3000000000, 816594518, 365000000000, 15345005998⟩⟩
    hull008_002 106 (by decide +kernel)

private def supportedCone1030 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨371, 389, 389, 371, 389⟩, ⟨29102761583, 3870546972, 0, 0, 1241475346630, 664539049402⟩⟩
    hull008_004 1 (by decide +kernel)

private def supportedCone1031 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 36, 35, 37⟩, ⟨1256580954, 61153129, 1418082341, 71124003, 261256580954, 712839430⟩⟩
    hull008_002 27 (by decide +kernel)

private def supportedCone1032 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 35, 34, 36⟩, ⟨1503327172, 68709630, 1256580954, 61153129, 260000000000, 651686301⟩⟩
    hull008_002 26 (by decide +kernel)

private def supportedCone1033 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 34, 33, 35⟩, ⟨827221629, 34669607, 1503327172, 68709630, 258496672828, 582976671⟩⟩
    hull008_002 25 (by decide +kernel)

private def supportedCone1034 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨371, 380, 380, 371, 380⟩, ⟨12627414953, 1940399032, 0, 0, 1225000000000, 662608901462⟩⟩
    hull008_005 1 (by decide +kernel)

private def supportedCone1035 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨380, 389, 389, 380, 389⟩, ⟨16475346630, 1930147940, 0, 0, 1241475346630, 664539049402⟩⟩
    hull008_006 1 (by decide +kernel)

private def supportedCone1036 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 33, 32, 34⟩, ⟨1263823080, 49116029, 827221629, 34669607, 257669451199, 548307064⟩⟩
    hull008_002 24 (by decide +kernel)

private def supportedCone1037 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨380, 389, 380, 380, 389⟩, ⟨0, 0, 16475346630, 1930147940, 1225000000000, 662608901462⟩⟩
    hull008_006 0 (by decide +kernel)

private def supportedCone1038 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨380, 384, 384, 380, 384⟩, ⟨7311555047, 990513007, 0, 0, 1232311555047, 663599414469⟩⟩
    hull008_007 1 (by decide +kernel)

private def supportedCone1039 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨384, 389, 389, 384, 389⟩, ⟨9163791583, 939634933, 0, 0, 1241475346630, 664539049402⟩⟩
    hull008_008 1 (by decide +kernel)

private def supportedCone1040 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨384, 386, 386, 385, 386⟩, ⟨1437509698, 169061924, 0, 0, 1235000000000, 663909294348⟩⟩
    hull008_009 2 (by decide +kernel)

private def supportedCone1041 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨386, 389, 389, 386, 389⟩, ⟨6475346630, 629755054, 0, 0, 1241475346630, 664539049402⟩⟩
    hull008_010 1 (by decide +kernel)

private def supportedCone1042 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 30, 29, 31⟩, ⟨890944115, 29450357, 1605927162, 55162689, 253394072838, 391140221⟩⟩
    hull008_002 21 (by decide +kernel)

private def supportedCone1043 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 29, 28, 30⟩, ⟨1119836040, 35468747, 890944115, 29450357, 252503128723, 361689864⟩⟩
    hull008_002 20 (by decide +kernel)

private def supportedCone1044 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨386, 387, 387, 386, 387⟩, ⟨2658381682, 266874179, 0, 0, 1237658381682, 664176168527⟩⟩
    hull008_011 1 (by decide +kernel)

private def supportedCone1045 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨387, 389, 389, 387, 389⟩, ⟨3816964948, 362880875, 0, 0, 1241475346630, 664539049402⟩⟩
    hull008_012 1 (by decide +kernel)

private def supportedCone1046 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨387, 388, 388, 387, 388⟩, ⟨2341618318, 224019698, 0, 0, 1240000000000, 664400188225⟩⟩
    hull008_013 1 (by decide +kernel)

private def supportedCone1047 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨388, 389, 389, 388, 389⟩, ⟨1475346630, 138861177, 0, 0, 1241475346630, 664539049402⟩⟩
    hull008_014 1 (by decide +kernel)

private def supportedCone1048 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 28, 27, 29⟩, ⟨1383292683, 42240405, 1119836040, 35468747, 251383292683, 326221117⟩⟩
    hull008_002 19 (by decide +kernel)

private def supportedCone1049 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨388, 389, 388, 388, 389⟩, ⟨0, 0, 1475346630, 138861177, 1240000000000, 664400188225⟩⟩
    hull008_014 0 (by decide +kernel)

private def supportedCone1050 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨386, 387, 386, 386, 387⟩, ⟨0, 0, 2658381682, 266874179, 1235000000000, 663909294348⟩⟩
    hull008_011 0 (by decide +kernel)

private def supportedCone1051 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨387, 388, 387, 387, 388⟩, ⟨0, 0, 2341618318, 224019698, 1237658381682, 664176168527⟩⟩
    hull008_013 0 (by decide +kernel)

private def supportedCone1052 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨26, 35, 29, 28, 30⟩, ⟨1119836040, 35468747, 890944115, 29450357, 252503128723, 361689864⟩⟩
    hull008_015 3 (by decide +kernel)

private def supportedCone1053 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 24, 23, 25⟩, ⟨1407888149, 33953019, 1142765542, 29098135, 246407888149, 187176200⟩⟩
    hull008_002 15 (by decide +kernel)

private def supportedCone1054 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨387, 389, 387, 387, 389⟩, ⟨0, 0, 3816964948, 362880875, 1237658381682, 664176168527⟩⟩
    hull008_012 0 (by decide +kernel)

private def supportedCone1055 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨386, 389, 386, 386, 389⟩, ⟨0, 0, 6475346630, 629755054, 1235000000000, 663909294348⟩⟩
    hull008_010 0 (by decide +kernel)

def appendixHullConeBlock0032 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1024,
    supportedCone1025,
    supportedCone1026,
    supportedCone1027,
    supportedCone1028,
    supportedCone1029,
    supportedCone1030,
    supportedCone1031,
    supportedCone1032,
    supportedCone1033,
    supportedCone1034,
    supportedCone1035,
    supportedCone1036,
    supportedCone1037,
    supportedCone1038,
    supportedCone1039,
    supportedCone1040,
    supportedCone1041,
    supportedCone1042,
    supportedCone1043,
    supportedCone1044,
    supportedCone1045,
    supportedCone1046,
    supportedCone1047,
    supportedCone1048,
    supportedCone1049,
    supportedCone1050,
    supportedCone1051,
    supportedCone1052,
    supportedCone1053,
    supportedCone1054,
    supportedCone1055,
  ], rfl⟩

private def supportedCone1056 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 27, 26, 28⟩, ⟨845463440, 24459535, 1383292683, 42240405, 250000000000, 283980712⟩⟩
    hull008_002 18 (by decide +kernel)

private def supportedCone1057 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨384, 386, 384, 384, 385⟩, ⟨0, 0, 1250935255, 140817955, 1232311555047, 663599414469⟩⟩
    hull008_009 0 (by decide +kernel)

private def supportedCone1058 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨384, 386, 385, 384, 386⟩, ⟨1250935255, 140817955, 1437509698, 169061924, 1233562490302, 663740232424⟩⟩
    hull008_009 1 (by decide +kernel)

private def supportedCone1059 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨380, 382, 382, 380, 382⟩, ⟨3995776555, 561542537, 0, 0, 1228995776555, 663170443999⟩⟩
    hull008_016 1 (by decide +kernel)

private def supportedCone1060 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨382, 384, 384, 382, 384⟩, ⟨3315778492, 428970470, 0, 0, 1232311555047, 663599414469⟩⟩
    hull008_017 1 (by decide +kernel)

private def supportedCone1061 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨382, 383, 383, 382, 383⟩, ⟨1004223445, 141783700, 0, 0, 1230000000000, 663312227699⟩⟩
    hull008_018 1 (by decide +kernel)

private def supportedCone1062 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨383, 384, 384, 383, 384⟩, ⟨2311555047, 287186770, 0, 0, 1232311555047, 663599414469⟩⟩
    hull008_019 1 (by decide +kernel)

private def supportedCone1063 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨384, 389, 384, 384, 389⟩, ⟨0, 0, 9163791583, 939634933, 1232311555047, 663599414469⟩⟩
    hull008_008 0 (by decide +kernel)

private def supportedCone1064 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 398, 398, 389, 398⟩, ⟨13524653370, 1170898938, 0, 0, 1255000000000, 665709948340⟩⟩
    hull008_020 1 (by decide +kernel)

private def supportedCone1065 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨398, 407, 407, 398, 407⟩, ⟨15000000000, 899459505, 0, 0, 1270000000000, 666609407845⟩⟩
    hull008_021 1 (by decide +kernel)

private def supportedCone1066 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨398, 402, 402, 398, 402⟩, ⟨6609919477, 451964563, 0, 0, 1261609919477, 666161912903⟩⟩
    hull008_022 1 (by decide +kernel)

private def supportedCone1067 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 46, 45, 47⟩, ⟨412549723, 29103357, 1084869137, 78356954, 272412549723, 1385121505⟩⟩
    hull008_002 37 (by decide +kernel)

private def supportedCone1068 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨402, 407, 407, 405, 407⟩, ⟨3786699786, 204590026, 0, 0, 1270000000000, 666609407845⟩⟩
    hull008_023 2 (by decide +kernel)

private def supportedCone1069 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨402, 404, 404, 402, 404⟩, ⟨3390080523, 179536513, 0, 0, 1265000000000, 666341449416⟩⟩
    hull008_024 1 (by decide +kernel)

private def supportedCone1070 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨404, 405, 405, 404, 405⟩, ⟨1213300214, 63368403, 0, 0, 1266213300214, 666404817819⟩⟩
    hull008_025 1 (by decide +kernel)

private def supportedCone1071 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨405, 406, 406, 405, 406⟩, ⟨1543738642, 84082970, 0, 0, 1267757038856, 666488900789⟩⟩
    hull008_026 1 (by decide +kernel)

private def supportedCone1072 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨406, 407, 407, 406, 407⟩, ⟨2242961144, 120507056, 0, 0, 1270000000000, 666609407845⟩⟩
    hull008_027 1 (by decide +kernel)

private def supportedCone1073 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨21, 26, 22, 21, 23⟩, ⟨1444783328, 26634160, 929323095, 19209070, 244070676905, 134014111⟩⟩
    hull008_028 1 (by decide +kernel)

private def supportedCone1074 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨406, 407, 406, 406, 407⟩, ⟨0, 0, 2242961144, 120507056, 1267757038856, 666488900789⟩⟩
    hull008_027 0 (by decide +kernel)

private def supportedCone1075 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨402, 407, 405, 402, 407⟩, ⟨4603380737, 242904916, 3786699786, 204590026, 1266213300214, 666404817819⟩⟩
    hull008_023 1 (by decide +kernel)

private def supportedCone1076 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨405, 407, 407, 405, 407⟩, ⟨3786699786, 204590026, 0, 0, 1270000000000, 666609407845⟩⟩
    hull008_029 1 (by decide +kernel)

private def supportedCone1077 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨405, 407, 405, 405, 407⟩, ⟨0, 0, 3786699786, 204590026, 1266213300214, 666404817819⟩⟩
    hull008_029 0 (by decide +kernel)

private def supportedCone1078 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨405, 406, 405, 405, 406⟩, ⟨0, 0, 1543738642, 84082970, 1266213300214, 666404817819⟩⟩
    hull008_026 0 (by decide +kernel)

private def supportedCone1079 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨407, 408, 407, 407, 408⟩, ⟨0, 0, 2416385860, 124444864, 1270000000000, 666609407845⟩⟩
    hull008_030 0 (by decide +kernel)

private def supportedCone1080 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨407, 416, 407, 407, 416⟩, ⟨0, 0, 15000000000, 651459756, 1270000000000, 666609407845⟩⟩
    hull008_031 0 (by decide +kernel)

private def supportedCone1081 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨407, 425, 407, 407, 425⟩, ⟨0, 0, 30000000000, 1063187629, 1270000000000, 666609407845⟩⟩
    hull008_032 0 (by decide +kernel)

private def supportedCone1082 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨404, 405, 404, 404, 405⟩, ⟨0, 0, 1213300214, 63368403, 1265000000000, 666341449416⟩⟩
    hull008_025 0 (by decide +kernel)

private def supportedCone1083 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨404, 407, 404, 404, 405⟩, ⟨0, 0, 1213300214, 63368403, 1265000000000, 666341449416⟩⟩
    hull008_033 0 (by decide +kernel)

private def supportedCone1084 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨402, 407, 402, 402, 405⟩, ⟨0, 0, 4603380737, 242904916, 1261609919477, 666161912903⟩⟩
    hull008_023 0 (by decide +kernel)

private def supportedCone1085 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨402, 403, 403, 402, 403⟩, ⟨1529841991, 81839261, 0, 0, 1263139761468, 666243752164⟩⟩
    hull008_034 1 (by decide +kernel)

private def supportedCone1086 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨403, 404, 404, 403, 404⟩, ⟨1860238532, 97697252, 0, 0, 1265000000000, 666341449416⟩⟩
    hull008_035 1 (by decide +kernel)

private def supportedCone1087 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨403, 404, 403, 403, 404⟩, ⟨0, 0, 1860238532, 97697252, 1263139761468, 666243752164⟩⟩
    hull008_035 0 (by decide +kernel)

def appendixHullConeBlock0033 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1056,
    supportedCone1057,
    supportedCone1058,
    supportedCone1059,
    supportedCone1060,
    supportedCone1061,
    supportedCone1062,
    supportedCone1063,
    supportedCone1064,
    supportedCone1065,
    supportedCone1066,
    supportedCone1067,
    supportedCone1068,
    supportedCone1069,
    supportedCone1070,
    supportedCone1071,
    supportedCone1072,
    supportedCone1073,
    supportedCone1074,
    supportedCone1075,
    supportedCone1076,
    supportedCone1077,
    supportedCone1078,
    supportedCone1079,
    supportedCone1080,
    supportedCone1081,
    supportedCone1082,
    supportedCone1083,
    supportedCone1084,
    supportedCone1085,
    supportedCone1086,
    supportedCone1087,
  ], rfl⟩

private def supportedCone1088 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨402, 404, 402, 402, 404⟩, ⟨0, 0, 3390080523, 179536513, 1261609919477, 666161912903⟩⟩
    hull008_024 0 (by decide +kernel)

private def supportedCone1089 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨402, 403, 402, 402, 403⟩, ⟨0, 0, 1529841991, 81839261, 1261609919477, 666161912903⟩⟩
    hull008_034 0 (by decide +kernel)

private def supportedCone1090 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨398, 400, 400, 398, 400⟩, ⟨2431769833, 178013578, 0, 0, 1257431769833, 665887961918⟩⟩
    hull008_036 1 (by decide +kernel)

private def supportedCone1091 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨400, 402, 402, 400, 402⟩, ⟨4178149644, 273950985, 0, 0, 1261609919477, 666161912903⟩⟩
    hull008_037 1 (by decide +kernel)

private def supportedCone1092 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨400, 401, 401, 400, 401⟩, ⟨2568230167, 177059074, 0, 0, 1260000000000, 666065020992⟩⟩
    hull008_038 1 (by decide +kernel)

private def supportedCone1093 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨401, 402, 402, 401, 402⟩, ⟨1609919477, 96891911, 0, 0, 1261609919477, 666161912903⟩⟩
    hull008_039 1 (by decide +kernel)

private def supportedCone1094 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨401, 402, 401, 401, 402⟩, ⟨0, 0, 1609919477, 96891911, 1260000000000, 666065020992⟩⟩
    hull008_039 0 (by decide +kernel)

private def supportedCone1095 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨400, 401, 400, 400, 401⟩, ⟨0, 0, 2568230167, 177059074, 1257431769833, 665887961918⟩⟩
    hull008_038 0 (by decide +kernel)

private def supportedCone1096 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨398, 400, 398, 398, 400⟩, ⟨0, 0, 2431769833, 178013578, 1255000000000, 665709948340⟩⟩
    hull008_036 0 (by decide +kernel)

private def supportedCone1097 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨398, 399, 399, 398, 399⟩, ⟨1110513912, 85681813, 0, 0, 1256110513912, 665795630153⟩⟩
    hull008_040 1 (by decide +kernel)

private def supportedCone1098 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨399, 400, 400, 399, 400⟩, ⟨1321255921, 92331765, 0, 0, 1257431769833, 665887961918⟩⟩
    hull008_041 1 (by decide +kernel)

private def supportedCone1099 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨17, 26, 25, 24, 26⟩, ⟨1142765542, 29098135, 1603882869, 43246842, 247550653691, 216274335⟩⟩
    hull008_042 8 (by decide +kernel)

private def supportedCone1100 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨400, 402, 400, 400, 402⟩, ⟨0, 0, 4178149644, 273950985, 1257431769833, 665887961918⟩⟩
    hull008_037 0 (by decide +kernel)

private def supportedCone1101 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨399, 400, 399, 399, 400⟩, ⟨0, 0, 1321255921, 92331765, 1256110513912, 665795630153⟩⟩
    hull008_041 0 (by decide +kernel)

private def supportedCone1102 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 393, 393, 389, 393⟩, ⟨5135417160, 460538317, 0, 0, 1246610763790, 664999587719⟩⟩
    hull008_043 1 (by decide +kernel)

private def supportedCone1103 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨393, 398, 398, 393, 398⟩, ⟨8389236210, 710360621, 0, 0, 1255000000000, 665709948340⟩⟩
    hull008_044 1 (by decide +kernel)

private def supportedCone1104 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨393, 395, 395, 394, 395⟩, ⟨2097058873, 181290061, 0, 0, 1250000000000, 665291180454⟩⟩
    hull008_045 2 (by decide +kernel)

private def supportedCone1105 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨395, 398, 398, 395, 398⟩, ⟨5000000000, 418767886, 0, 0, 1255000000000, 665709948340⟩⟩
    hull008_046 1 (by decide +kernel)

private def supportedCone1106 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨395, 396, 396, 395, 396⟩, ⟨2167356834, 183041719, 0, 0, 1252167356834, 665474222173⟩⟩
    hull008_047 1 (by decide +kernel)

private def supportedCone1107 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨396, 398, 398, 397, 398⟩, ⟨1894666829, 157889411, 0, 0, 1255000000000, 665709948340⟩⟩
    hull008_048 2 (by decide +kernel)

private def supportedCone1108 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨396, 398, 397, 396, 398⟩, ⟨937976337, 77836756, 1894666829, 157889411, 1253105333171, 665552058929⟩⟩
    hull008_048 1 (by decide +kernel)

private def supportedCone1109 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨398, 399, 398, 398, 399⟩, ⟨0, 0, 1110513912, 85681813, 1255000000000, 665709948340⟩⟩
    hull008_040 0 (by decide +kernel)

private def supportedCone1110 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨398, 402, 398, 398, 402⟩, ⟨0, 0, 6609919477, 451964563, 1255000000000, 665709948340⟩⟩
    hull008_022 0 (by decide +kernel)

private def supportedCone1111 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨398, 407, 398, 398, 407⟩, ⟨0, 0, 15000000000, 899459505, 1255000000000, 665709948340⟩⟩
    hull008_021 0 (by decide +kernel)

private def supportedCone1112 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨396, 398, 396, 396, 397⟩, ⟨0, 0, 937976337, 77836756, 1252167356834, 665474222173⟩⟩
    hull008_048 0 (by decide +kernel)

private def supportedCone1113 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨395, 396, 395, 395, 396⟩, ⟨0, 0, 2167356834, 183041719, 1250000000000, 665291180454⟩⟩
    hull008_047 0 (by decide +kernel)

private def supportedCone1114 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨395, 398, 395, 395, 398⟩, ⟨0, 0, 5000000000, 418767886, 1250000000000, 665291180454⟩⟩
    hull008_046 0 (by decide +kernel)

private def supportedCone1115 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨393, 395, 394, 393, 395⟩, ⟨1292177337, 110302674, 2097058873, 181290061, 1247902941127, 665109890393⟩⟩
    hull008_045 1 (by decide +kernel)

private def supportedCone1116 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨393, 398, 393, 393, 398⟩, ⟨0, 0, 8389236210, 710360621, 1246610763790, 664999587719⟩⟩
    hull008_044 0 (by decide +kernel)

private def supportedCone1117 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨393, 395, 393, 393, 394⟩, ⟨0, 0, 1292177337, 110302674, 1246610763790, 664999587719⟩⟩
    hull008_045 0 (by decide +kernel)

private def supportedCone1118 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 391, 391, 389, 391⟩, ⟨2561075943, 233531766, 0, 0, 1244036422573, 664772581168⟩⟩
    hull008_049 1 (by decide +kernel)

private def supportedCone1119 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨391, 393, 393, 391, 393⟩, ⟨2574341217, 227006551, 0, 0, 1246610763790, 664999587719⟩⟩
    hull008_050 1 (by decide +kernel)

def appendixHullConeBlock0034 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1088,
    supportedCone1089,
    supportedCone1090,
    supportedCone1091,
    supportedCone1092,
    supportedCone1093,
    supportedCone1094,
    supportedCone1095,
    supportedCone1096,
    supportedCone1097,
    supportedCone1098,
    supportedCone1099,
    supportedCone1100,
    supportedCone1101,
    supportedCone1102,
    supportedCone1103,
    supportedCone1104,
    supportedCone1105,
    supportedCone1106,
    supportedCone1107,
    supportedCone1108,
    supportedCone1109,
    supportedCone1110,
    supportedCone1111,
    supportedCone1112,
    supportedCone1113,
    supportedCone1114,
    supportedCone1115,
    supportedCone1116,
    supportedCone1117,
    supportedCone1118,
    supportedCone1119,
  ], rfl⟩

private def supportedCone1120 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨393, 394, 394, 393, 394⟩, ⟨1292177337, 110302674, 0, 0, 1247902941127, 665109890393⟩⟩
    hull008_051 1 (by decide +kernel)

private def supportedCone1121 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨393, 394, 393, 393, 394⟩, ⟨0, 0, 1292177337, 110302674, 1246610763790, 664999587719⟩⟩
    hull008_051 0 (by decide +kernel)

private def supportedCone1122 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨394, 395, 394, 394, 395⟩, ⟨0, 0, 2097058873, 181290061, 1247902941127, 665109890393⟩⟩
    hull008_052 0 (by decide +kernel)

private def supportedCone1123 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨391, 392, 392, 391, 392⟩, ⟨963577427, 86381763, 0, 0, 1245000000000, 664858962931⟩⟩
    hull008_053 1 (by decide +kernel)

private def supportedCone1124 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨392, 393, 393, 392, 393⟩, ⟨1610763790, 140624788, 0, 0, 1246610763790, 664999587719⟩⟩
    hull008_054 1 (by decide +kernel)

private def supportedCone1125 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨392, 393, 392, 392, 393⟩, ⟨0, 0, 1610763790, 140624788, 1245000000000, 664858962931⟩⟩
    hull008_054 0 (by decide +kernel)

private def supportedCone1126 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨391, 393, 391, 391, 393⟩, ⟨0, 0, 2574341217, 227006551, 1244036422573, 664772581168⟩⟩
    hull008_050 0 (by decide +kernel)

private def supportedCone1127 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨391, 392, 391, 391, 392⟩, ⟨0, 0, 963577427, 86381763, 1244036422573, 664772581168⟩⟩
    hull008_053 0 (by decide +kernel)

private def supportedCone1128 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 390, 390, 389, 390⟩, ⟨1278886228, 117434758, 0, 0, 1242754232858, 664656484160⟩⟩
    hull008_055 1 (by decide +kernel)

private def supportedCone1129 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨390, 391, 391, 390, 391⟩, ⟨1282189715, 116097008, 0, 0, 1244036422573, 664772581168⟩⟩
    hull008_056 1 (by decide +kernel)

private def supportedCone1130 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨390, 391, 390, 390, 391⟩, ⟨0, 0, 1282189715, 116097008, 1242754232858, 664656484160⟩⟩
    hull008_056 0 (by decide +kernel)

private def supportedCone1131 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 390, 389, 389, 390⟩, ⟨0, 0, 1278886228, 117434758, 1241475346630, 664539049402⟩⟩
    hull008_055 0 (by decide +kernel)

private def supportedCone1132 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 391, 389, 389, 391⟩, ⟨0, 0, 2561075943, 233531766, 1241475346630, 664539049402⟩⟩
    hull008_049 0 (by decide +kernel)

private def supportedCone1133 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨26, 35, 28, 27, 29⟩, ⟨1383292683, 42240405, 1119836040, 35468747, 251383292683, 326221117⟩⟩
    hull008_015 2 (by decide +kernel)

private def supportedCone1134 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 393, 389, 389, 393⟩, ⟨0, 0, 5135417160, 460538317, 1241475346630, 664539049402⟩⟩
    hull008_043 0 (by decide +kernel)

private def supportedCone1135 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 398, 389, 389, 398⟩, ⟨0, 0, 13524653370, 1170898938, 1241475346630, 664539049402⟩⟩
    hull008_020 0 (by decide +kernel)

private def supportedCone1136 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 407, 389, 389, 407⟩, ⟨0, 0, 28524653370, 2070358443, 1241475346630, 664539049402⟩⟩
    hull008_057 0 (by decide +kernel)

private def supportedCone1137 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨389, 425, 389, 389, 425⟩, ⟨0, 0, 58524653370, 3133546072, 1241475346630, 664539049402⟩⟩
    hull008_058 0 (by decide +kernel)

private def supportedCone1138 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 141, 42, 41, 43⟩, ⟨821856399, 51327005, 1798390801, 116302336, 268201609199, 1102260128⟩⟩
    hull008_002 33 (by decide +kernel)

private def supportedCone1139 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨383, 384, 383, 383, 384⟩, ⟨0, 0, 2311555047, 287186770, 1230000000000, 663312227699⟩⟩
    hull008_019 0 (by decide +kernel)

private def supportedCone1140 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨382, 383, 382, 382, 383⟩, ⟨0, 0, 1004223445, 141783700, 1228995776555, 663170443999⟩⟩
    hull008_018 0 (by decide +kernel)

private def supportedCone1141 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨382, 384, 382, 382, 384⟩, ⟨0, 0, 3315778492, 428970470, 1228995776555, 663170443999⟩⟩
    hull008_017 0 (by decide +kernel)

private def supportedCone1142 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨380, 381, 381, 380, 381⟩, ⟨2339633725, 333126428, 0, 0, 1227339633725, 662942027890⟩⟩
    hull008_059 1 (by decide +kernel)

private def supportedCone1143 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨381, 382, 382, 381, 382⟩, ⟨1656142830, 228416109, 0, 0, 1228995776555, 663170443999⟩⟩
    hull008_060 1 (by decide +kernel)

private def supportedCone1144 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨381, 382, 381, 381, 382⟩, ⟨0, 0, 1656142830, 228416109, 1227339633725, 662942027890⟩⟩
    hull008_060 0 (by decide +kernel)

private def supportedCone1145 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨30, 32, 32, 31, 32⟩, ⟨1405628119, 52888125, 0, 0, 256405628119, 499191035⟩⟩
    hull008_061 2 (by decide +kernel)

private def supportedCone1146 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨32, 35, 34, 33, 35⟩, ⟨827221629, 34669607, 1503327172, 68709630, 258496672828, 582976671⟩⟩
    hull008_062 2 (by decide +kernel)

private def supportedCone1147 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨32, 35, 33, 32, 34⟩, ⟨1263823080, 49116029, 827221629, 34669607, 257669451199, 548307064⟩⟩
    hull008_062 1 (by decide +kernel)

private def supportedCone1148 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨380, 381, 380, 380, 381⟩, ⟨0, 0, 2339633725, 333126428, 1225000000000, 662608901462⟩⟩
    hull008_059 0 (by decide +kernel)

private def supportedCone1149 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨371, 375, 375, 371, 375⟩, ⟨6126952185, 991424615, 0, 0, 1218499537232, 661659927045⟩⟩
    hull008_063 1 (by decide +kernel)

private def supportedCone1150 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨375, 380, 380, 377, 380⟩, ⟨4074694442, 596463386, 0, 0, 1225000000000, 662608901462⟩⟩
    hull008_064 3 (by decide +kernel)

private def supportedCone1151 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨375, 380, 377, 376, 380⟩, ⟨925305558, 134769031, 4074694442, 596463386, 1220925305558, 662012438076⟩⟩
    hull008_064 2 (by decide +kernel)

def appendixHullConeBlock0035 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1120,
    supportedCone1121,
    supportedCone1122,
    supportedCone1123,
    supportedCone1124,
    supportedCone1125,
    supportedCone1126,
    supportedCone1127,
    supportedCone1128,
    supportedCone1129,
    supportedCone1130,
    supportedCone1131,
    supportedCone1132,
    supportedCone1133,
    supportedCone1134,
    supportedCone1135,
    supportedCone1136,
    supportedCone1137,
    supportedCone1138,
    supportedCone1139,
    supportedCone1140,
    supportedCone1141,
    supportedCone1142,
    supportedCone1143,
    supportedCone1144,
    supportedCone1145,
    supportedCone1146,
    supportedCone1147,
    supportedCone1148,
    supportedCone1149,
    supportedCone1150,
    supportedCone1151,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
