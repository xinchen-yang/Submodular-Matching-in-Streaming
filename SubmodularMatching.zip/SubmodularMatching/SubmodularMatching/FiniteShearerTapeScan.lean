import SubmodularMatching.FiniteShearerTape
import SubmodularMatching.FiniteShearerResources
import SubmodularMatching.GibbsSpectralScan

/-!
# Integer neighbor selection by scanning stored edges

The compact coin stores only its vertex stack. The original residual
graph and ancestor checks determine which incident edge blocks contribute.
-/

namespace SubmodularMatching.ShearerSampler

open GibbsMatching GibbsSampler
open scoped BigOperators

variable {E V : Type*}

theorem scanTicket_weighted (cells : E → ℕ) (items : List E)
    (pay : Option E → ℝ) (q : ℕ) (hq : (items.map cells).sum ≤ q) :
    (∑ w ∈ Finset.range q, pay (scanTicket cells items w)) =
      (items.map (fun e => (cells e:ℝ)*pay (some e))).sum +
        ((q - (items.map cells).sum:ℕ):ℝ)*pay none := by
  induction items generalizing q with
  | nil => simp [scanTicket,nsmul_eq_mul]
  | cons e rest ih =>
    let a := cells e
    let r := q-a
    have hBound : a+(rest.map cells).sum ≤ q := hq
    have ha : a ≤ q := by omega
    have hr : (rest.map cells).sum ≤ r := by omega
    have hSplit : q = a+r := (Nat.add_sub_of_le ha).symm
    rw [hSplit,Finset.sum_range_add]
    have hHead :
        (∑ w ∈ Finset.range a, pay (scanTicket cells (e::rest) w)) = (a:ℝ)*pay (some e) := by
      trans ∑ _ ∈ Finset.range a, pay (some e)
      · exact Finset.sum_congr rfl (fun w hw => congrArg pay (if_pos (Finset.mem_range.mp hw)))
      · simp [nsmul_eq_mul]
    have hRest :
        (∑ w ∈ Finset.range r, pay (scanTicket cells (e::rest) (a+w))) =
          ∑ w ∈ Finset.range r, pay (scanTicket cells rest w) := by
      apply Finset.sum_congr rfl
      intro w _
      simp [scanTicket,show cells e = a from rfl]
    rw [hHead,hRest,ih r hr]
    simp only [List.map_cons,List.sum_cons,show cells e = a from rfl,Nat.add_sub_add_left]
    ring

theorem scanTicket_some_cells (cells : E → ℕ) (items : List E) (w : ℕ) (e : E)
    (h : scanTicket cells items w = some e) : e ∈ items ∧ 0 < cells e := by
  induction items generalizing w with
  | nil => simp [scanTicket] at h
  | cons d rest ih =>
    by_cases hh : w < cells d
    · simp [scanTicket,hh] at h
      subst e
      exact ⟨by simp,(Nat.zero_le _).trans_lt hh⟩
    · simp only [scanTicket,if_neg hh] at h
      exact ⟨List.mem_cons_of_mem _ (ih _ h).1,(ih _ h).2⟩

variable [DecidableEq E] [DecidableEq V]

/-- Count an eligible edge's block using the base graph,
the current vertex, and the waiting stack. -/
def compactNeighborCells (c : RationalShearerInput E) (ends : E → Finset V)
    (base : Finset E) (v : V) (ancestors : List V) (e : E) : ℕ :=
  if e ∈ base ∧ v ∈ ends e ∧ ancestors.all (fun w => w ∉ ends e) then c.edgeCells e else 0

theorem compactNeighborCells_eq (c : RationalShearerInput E) (ends : E → Finset V)
    (base : Finset E) (v : V) (ancestors : List V) (e : E) :
    compactNeighborCells c ends base v ancestors e =
      if e ∈ incident ends (removeAncestors ends base ancestors) v then c.edgeCells e else 0 := by
  have h : (e ∈ base ∧ v ∈ ends e ∧ ancestors.all (fun w => w ∉ ends e)) ↔
      e ∈ incident ends (removeAncestors ends base ancestors) v := by
    simp only [incident,Finset.mem_filter,mem_removeAncestors,List.all_eq_true,decide_eq_true_eq]
    tauto
  simp only [compactNeighborCells,h]

private theorem list_scan_sum {R : Type*} [AddCommMonoid R] (stored : List E) (hd : stored.Nodup)
    (f : E → R) : (stored.map f).sum = ∑ e ∈ stored.toFinset, f e := by
  induction stored with
  | nil => simp
  | cons e rest ih =>
    have he : e ∉ rest.toFinset := by simpa using (List.nodup_cons.mp hd).1
    simp only [List.map_cons,List.sum_cons,List.toFinset_cons,Finset.sum_insert he]
    rw [ih (List.nodup_cons.mp hd).2]

theorem compactNeighborCells_fit (c : RationalShearerInput E) (ends : E → Finset V)
    (edges base : Finset E) (hbase : base ⊆ edges) (stored : List E)
    (hs : stored.toFinset = edges) (hd : stored.Nodup) (v : V) (ancestors : List V)
    (hDegree : ∑ e ∈ incident ends edges v, c.x e ≤ c.stop*(1-c.stop)) :
    (stored.map (compactNeighborCells c ends base v ancestors)).sum ≤ c.neighborGrid.denominator := by
  let H := removeAncestors ends base ancestors
  have hH : H ⊆ edges := fun _ he => hbase ((mem_removeAncestors ..).mp he).1
  have hChoices : incident ends H v ⊆ edges := fun _ he => hH (Finset.mem_filter.mp he).1
  have hSum : (stored.map (compactNeighborCells c ends base v ancestors)).sum =
      ∑ e ∈ incident ends H v, c.edgeCells e := by
    rw [list_scan_sum stored hd,hs]
    simp_rw [compactNeighborCells_eq]
    rw [← Finset.sum_filter]
    have hFilter : edges.filter (fun e => e ∈ incident ends H v) = incident ends H v := by
      ext e
      exact Finset.mem_filter.trans ⟨And.right,fun he => ⟨hChoices he,he⟩⟩
    rw [hFilter]
  rw [hSum]
  exact c.neighbor_cells_fit ends H v
    ((Shearer.incident_sum_le_of_subset ends H edges c.x (fun e _ => c.x_nonneg e) hH v).trans hDegree)

/-- A compact neighbor draw accepts a word and scans the current
eligible edge blocks. Unassigned cells and aborts return `none`. -/
def compactNeighborDraw (c : RationalShearerInput E) (ends : E → Finset V)
    (base : Finset E) (stored : List E) (v : V) (ancestors : List V) (B : ℕ)
    (tape : Fin B → Fin (2^c.neighborGrid.bits)) : Option E :=
  (c.neighborGrid.wordDraw B tape).bind (fun w =>
    scanTicket (compactNeighborCells c ends base v ancestors) stored w.val)

theorem compactNeighborDraw_available (c : RationalShearerInput E) (ends : E → Finset V)
    (base : Finset E) (stored : List E) (v : V) (ancestors : List V) (B : ℕ)
    (tape : Fin B → Fin (2^c.neighborGrid.bits)) (e : E)
    (h : compactNeighborDraw c ends base stored v ancestors B tape = some e) :
    e ∈ incident ends (removeAncestors ends base ancestors) v := by
  unfold compactNeighborDraw at h
  cases hWord : c.neighborGrid.wordDraw B tape with
  | none => simp [hWord] at h
  | some w =>
    simp [hWord] at h
    have hp := (scanTicket_some_cells _ _ _ _ h).2
    rw [compactNeighborCells_eq] at hp
    by_contra hn
    simp [hn] at hp

theorem compactNeighborDraw_payoff (c : RationalShearerInput E) (ends : E → Finset V)
    (edges base : Finset E) (hbase : base ⊆ edges) (stored : List E)
    (hs : stored.toFinset = edges) (hd : stored.Nodup) (v : V) (ancestors : List V)
    (hDegree : ∑ e ∈ incident ends edges v, c.x e ≤ c.stop*(1-c.stop))
    (B : ℕ) (pay : E → ℝ) :
    wordAverage (fun tape : Fin B → Fin (2^c.neighborGrid.bits) =>
      (compactNeighborDraw c ends base stored v ancestors B tape).elim 0 pay) =
      c.neighborGrid.alive B * ∑ e ∈ incident ends (removeAncestors ends base ancestors) v,
        (c.x e/(c.stop*(1-c.stop)))*pay e := by
  let cells := compactNeighborCells c ends base v ancestors
  let H := removeAncestors ends base ancestors
  let g := c.neighborGrid
  let φ : Option E → ℝ := fun choice => choice.elim 0 pay
  have hH : H ⊆ edges := fun _ he => hbase ((mem_removeAncestors ..).mp he).1
  have hChoices : incident ends H v ⊆ edges := fun _ he => hH (Finset.mem_filter.mp he).1
  have hPay :
      (fun tape : Fin B → Fin (2^g.bits) =>
        (compactNeighborDraw c ends base stored v ancestors B tape).elim 0 pay) =
      fun tape : Fin B → Fin (2^g.bits) =>
        (g.wordDraw B tape).elim 0 (fun w => φ (scanTicket cells stored w.val)) := by
    funext tape
    unfold compactNeighborDraw
    change ((g.wordDraw B tape).bind (fun w => scanTicket cells stored w.val)).elim (0:ℝ) pay = _
    cases g.wordDraw B tape <;> rfl
  rw [hPay,g.wordDraw_payoff]
  rw [Fin.sum_univ_eq_sum_range (fun w : ℕ => φ (scanTicket cells stored w)) g.denominator]
  rw [scanTicket_weighted cells stored φ g.denominator
    (compactNeighborCells_fit c ends edges base hbase stored hs hd v ancestors hDegree)]
  simp only [show φ none = 0 from rfl,mul_zero,add_zero,list_scan_sum stored hd,hs]
  simp_rw [show ∀ e, φ (some e) = pay e from fun _ => rfl,
    show ∀ e, cells e = if e ∈ incident ends H v then c.edgeCells e else 0 from
      compactNeighborCells_eq c ends base v ancestors,Nat.cast_ite,Nat.cast_zero,ite_mul,zero_mul]
  rw [← Finset.sum_filter]
  have hFilter : edges.filter (fun e => e ∈ incident ends H v) = incident ends H v := by
    ext e
    exact Finset.mem_filter.trans ⟨And.right,fun he => ⟨hChoices he,he⟩⟩
  rw [hFilter,Finset.sum_div]
  congr 1
  apply Finset.sum_congr rfl
  intro e _
  rw [c.neighbor_grid_value]
  ring

end SubmodularMatching.ShearerSampler
