import SubmodularMatching.ProjectedShearerPhysicalLayer

/-! # The size cutoff depends only on activity on retained original labels -/

namespace SubmodularMatching.Capacity
open Finset UpperBoundAssembly ShearerCappedSampler GibbsMatching GibbsSampler Shearer TwoLayerDiffuse
open scoped BigOperators
variable {E V : Type*} [Fintype E] [Fintype V] [DecidableEq E] [DecidableEq V]

theorem stored_activity_budget (S : SimpleEdgeStream E V) (b : V → ℕ) (rank : Slots b ↪ ℕ)
    (Y : E → ℝ) (hY : ∀ e, 0 ≤ Y e) (θ : ℝ) (hθ : 0 ≤ θ) :
    (layerSupport S b rank).sum (fun p => slotWeight b (labelTable S.ends Y) θ p.1 p.2) ≤ θ * ∑ e, Y e := by
  classical
  let T := layerSupport S b rank
  let w := fun p : Slots b × Slots b => slotWeight b (labelTable S.ends Y) θ p.1 p.2
  let f := fun e p => if p ∈ slotFiber b rank (S.ends e) then w p else 0
  have hn (p) : 0 ≤ w p := by
    dsimp [w,slotWeight]
    exact div_nonneg (mul_nonneg hθ (labelTable_nonneg _ _ hY _ _)) (by positivity)
  have covered (p) (hp : p ∈ T) : w p ≤ ∑ e, f e p := by
    obtain ⟨z,hz,hp'⟩ := mem_biUnion.mp (mem_filter.mp hp).1
    obtain ⟨e,_,rfl⟩ := mem_image.mp hz
    have he (j : E) (_ : j ∈ (univ : Finset E)) : 0 ≤ f j p := by dsimp [f]; split_ifs <;> simp [hn]
    exact (show f e p = w p by simp [f,hp']).symm.le.trans (single_le_sum he (mem_univ e))
  have inner (e : E) : ∑ p ∈ T, f e p ≤ θ*Y e := by
    let z := S.ends e
    let val := θ*Y e/((b z.1:ℝ)*b z.2)
    have hv : 0 ≤ val := div_nonneg (mul_nonneg hθ (hY e)) (by positivity)
    have cst (p) (hp : p ∈ slotFiber b rank z) : w p = val := by
      obtain ⟨q,_,rfl⟩ := mem_image.mp hp
      dsimp only [w,orderSlots,slotWeight,val]
      split_ifs <;> simp only [z]
      · rw [labelTable_at S.ends S.simple]
      · rw [labelTable_symm S.ends Y,labelTable_at S.ends S.simple,mul_comm (b (S.ends e).2:ℝ)]
    have hc : (T.filter (fun p => p∈slotFiber b rank z)).card ≤ b z.1*b z.2 :=
      (card_le_card (fun p hp => (mem_filter.mp hp).2)).trans (card_image_le.trans (by simp))
    calc
      ∑ p ∈ T, f e p = ∑ p ∈ T.filter (fun p => p ∈ slotFiber b rank z), w p := by
        simp only [f,z,sum_filter]
      _ = ∑ _p ∈ T.filter (fun p => p ∈ slotFiber b rank z), val :=
        sum_congr rfl (fun p hp => cst p (mem_filter.mp hp).2)
      _ ≤ ((b z.1:ℝ)*b z.2)*val := by
        simp only [sum_const,nsmul_eq_mul]
        apply mul_le_mul_of_nonneg_right _ hv
        exact_mod_cast hc
      _ ≤ θ*Y e := by
        by_cases h : (b z.1:ℝ)*b z.2 = 0
        · simpa only [h,zero_mul] using mul_nonneg hθ (hY e)
        · dsimp only [val]; rw [mul_comm ((b z.1:ℝ)*b z.2), div_mul_cancel₀ _ h]
  calc
    _ ≤ ∑ p ∈ T, ∑ e, f e p := sum_le_sum covered
    _ = ∑ e, ∑ p ∈ T, f e p := sum_comm
    _ ≤ ∑ e, θ*Y e := sum_le_sum (fun e _ => inner e)
    _ = _ := (mul_sum ..).symm

/-- Cap the sparse layer using an original-label budget, independently of
the number or capacities of virtual slot vertices. -/
theorem physicalLayer_original_budget (S : SimpleEdgeStream E V) (b : V → ℕ) (hb : ∀ v, 0 < b v)
    (rank : Slots b ↪ ℕ) (a : E → ℕ) (d θn θd D : ℕ) (hD : 0 < D)
    (hdeg : ∀ u, ((θn:ℝ)/θd)*Capacity.slotLoad S.ends b (fun e=>(a e:ℝ)/d) u ≤ AppendixM.layerOne)
    (δ η : ℝ) (hδ : 0<δ ∧ δ≤1) (hη : 0<η) (K : ℕ)
    (hk : ((θn:ℝ)/θd)*(∑ e, (a e:ℝ)/d) + Real.log (1/η) ≤ K*Real.log 2) :
    let I := physicalLayerInput S b hb rank a d θn θd D hD hdeg
    variation univ (Shearer.probability pairVertices (layerSupport S b rank)
      (fun p => slotWeight b (labelTable S.ends (fun e => (a e:ℝ)/d)) ((θn:ℝ)/θd) p.1 p.2)) (outcomeLaw I δ hδ K).mass
      ≤ (layerSupport S b rank).card/D + δ + η :=
  physicalLayer_variation S b hb rank a d θn θd D hD hdeg δ η hδ hη K
    ((add_le_add (stored_activity_budget S b rank (fun e=>(a e:ℝ)/d) (fun _ => by positivity) ((θn:ℝ)/θd) (by positivity)) (le_rfl : Real.log (1/η) ≤ Real.log (1/η))).trans hk)

end SubmodularMatching.Capacity
