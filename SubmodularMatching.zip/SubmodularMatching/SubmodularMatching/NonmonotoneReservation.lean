import SubmodularMatching.NonmonotoneDiffuseAlteration
import SubmodularMatching.TwoStageSupport
import SubmodularMatching.GibbsPositiveSupport

namespace SubmodularMatching.TwoLayerDiffuse

open GibbsMatching TwoStage
noncomputable section

variable {E V : Type*} [Fintype E] [Fintype V] [DecidableEq E] [DecidableEq V]

omit [Fintype V] in
/-- The occupancy test reserves both entire sampled layers, including all
sampled edges removed by the priority rule. -/
theorem reserved_disjoint (ends : E → V × V) (A B : Layer (pairEnds ends) Finset.univ)
    (x : E → ℝ) (ξ : ℝ) (ω : DualOutcome (pairEnds ends) Finset.univ)
    (T : Finset E) (hT : T ⊆ ω.1.val ∪ ω.2.val)
    (e : E) (he : alteredDiffuse ends A B x ξ ω e ≠ 0) :
    Disjoint (pairEnds ends e) (T.biUnion (pairEnds ends)) := by
  have hv := altered_support ends _ (vacant (pairEnds ends) Finset.univ) (tolerance ξ) ω e he
  apply Finset.disjoint_left.mpr
  intro v hve hvT
  obtain ⟨d,hd,hvd⟩ := Finset.mem_biUnion.mp hvT
  have hfree : vacant (pairEnds ends) Finset.univ v ω = 1 := by
    rcases Finset.mem_insert.mp hve with h|h
    · exact h ▸ hv.1
    · exact (Finset.mem_singleton.mp h) ▸ hv.2
  rcases Finset.mem_union.mp (hT hd) with h|h
  · have hm := Finset.mem_biUnion.mpr ⟨d,h,hvd⟩
    simp [vacant,unmatched,hm] at hfree
  · have hm := Finset.mem_biUnion.mpr ⟨d,h,hvd⟩
    simp [vacant,unmatched,hm] at hfree

omit [Fintype V] in
/-- Every possible positive-support Gibbs output extends the retained
first-stage matching, on ordinary vertices or on capacitated slots. -/
theorem reserved_positive_union (ends : E → V × V) (A B : Layer (pairEnds ends) Finset.univ)
    (x : E → ℝ) (ξ γ : ℝ) (ω : DualOutcome (pairEnds ends) Finset.univ)
    (T : Finset E) (hT : T ⊆ ω.1.val ∪ ω.2.val) (hm : Streaming.IsMatchingOn (pairEnds ends) T)
    (N : Finset E) (hN : N ∈ matchings (pairEnds ends) (positiveEdges Finset.univ
      (calibratedActivity (pairEnds ends) Finset.univ (alteredDiffuse ends A B x ξ ω) γ))) :
    Streaming.IsMatchingOn (pairEnds ends) (T ∪ N) := by
  have hs := (mem_matchings _ _ _).mp hN
  have cross (e d : E) (he : e ∈ T) (hd : d ∈ N) :
      Disjoint (pairEnds ends e) (pairEnds ends d) := by
    have hp := (Finset.mem_filter.mp (hs.1 hd)).2
    have hpos : alteredDiffuse ends A B x ξ ω d ≠ 0 := by
      intro hz
      simp [calibratedActivity,hz] at hp
    have hdj := reserved_disjoint ends A B x ξ ω T hT d hpos
    apply Finset.disjoint_left.mpr
    intro v hve hvd
    exact Finset.disjoint_left.mp hdj hvd (Finset.mem_biUnion.mpr ⟨e,he,hve⟩)
  intro e he d hd hne
  rcases Finset.mem_union.mp he with he|he <;> rcases Finset.mem_union.mp hd with hd|hd
  · exact hm he hd hne
  · exact cross e d he hd
  · exact (cross d e hd he).symm
  · exact hs.2 he hd hne

end
end SubmodularMatching.TwoLayerDiffuse
