import SubmodularMatching.UpperBoundExact
import SubmodularMatching.RoundingGrid
import SubmodularMatching.SampledGreedyOracle

/-!
# Sampled optimizer followed by grid rounding

At a fixed transcript with accurate derivative estimates, the actual
sampled packing iterates and the two exact rounding laws deliver the bound
used before sampler approximation in Appendix K.
-/

open scoped BigOperators

namespace SubmodularMatching.UpperBoundAssembly

open Joint TwoStage

noncomputable section

variable {m N : ℕ} {V : Type*} [Fintype V] [DecidableEq V]

/-- The rounding loss includes the finite packing allowance and the loss
from flooring the compensated coordinates. The sampler laws here are exact. -/
theorem sampled_greedy_and_grid_rounding
    (hm : 0 < m) (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2)
    (hsimple : Function.Injective (pairEnds ends))
    (p D r tau epsOpt epsRound beta lower : ℝ) (Q : ℕ)
    (hp : 0 < p) (hp1 : p ≤ 1) (hD : 0 < D) (hD2 : 2 * D < 1)
    (hr0 : 0 < r) (hr1 : r ≤ 1) (hDr : D = r * (1 - r))
    (htau : 0 < tau) (heOpt0 : 0 < epsOpt) (heOpt1 : epsOpt ≤ 1)
    (heRound0 : 0 < epsRound) (heRound1 : epsRound < 1)
    (hcap : p ≤ epsRound ^ 5 / 163840)
    (f : Finset (Fin m) → ℝ) (hf : IsSubmodular f) (hmono : IsMonotone f)
    (hzero : f ∅ = 0) (w : Fin m → ℝ) (hwbox : ∀ e, 0 ≤ w e ∧ w e ≤ tau)
    (hw : ∀ i < m, w (enumerateEdge hm i) ≤ arrivalWeight (enumerateEdge hm) p f i)
    (hsingleton : ∀ e, f {e} ≤ tau)
    (draw : ℕ → (Fin m ⊕ Fin m → ℝ) → Fin m → Fin N →
      Finset (Fin m) × Finset (Fin m))
    (hQ : 0 < Q)
    (hgrid : (FiniteGreedy.stages D m epsOpt : ℝ) / Q ≤ FiniteGreedy.accuracy D m epsOpt / 2)
    (hmean : ∀ j < FiniteGreedy.stages D m epsOpt, ∀ e,
      let t := sampledPoint p D tau epsOpt ends w (oracleCoefficient D tau epsOpt Q f draw) j
      let g := residualValue (enumerateEdge hm) p f m
      |Streaming.sourceAverage (FiniteGreedy.accuracy D m epsOpt * tau / 2)
        (fun sample => Multilinear.derivativeSample f e (draw j t e sample).1
          (draw j t e sample).2) - exactGradient hm D g t e| ≤
        FiniteGreedy.accuracy D m epsOpt * tau / 2)
    (O : Finset (Fin m))
    (hz0 : Feasible p D ends ends 0 (fun e => D * edgeIndicator O e))
    (hbeta : beta ≤ 1 - Real.exp (-D))
    (hsource : lower ≤ sSup (comparisonValues p D ends w O)) :
    let t := sampledPoint p D tau epsOpt ends w (oracleCoefficient D tau epsOpt Q f draw)
      (FiniteGreedy.stages D m epsOpt)
    let y : Fin m → ℝ := fun e => D * t (.inr e)
    let x' : Fin m → ℝ := fun e => gridCoordinate (p * t (.inl e))
      (pairProbability ends y (ends e).1 (ends e).2) (epsOpt / (8 * m))
    (1 - epsRound) * (lower + beta * residualValue (enumerateEdge hm) p f m O -
      (5 / 8) * epsOpt * tau) ≤
      twoStageValue ends x' y (epsRound / 4) (epsRound / 2) f := by
  dsimp only
  let t := sampledPoint p D tau epsOpt ends w (oracleCoefficient D tau epsOpt Q f draw)
    (FiniteGreedy.stages D m epsOpt)
  let x : Fin m → ℝ := fun e => p * t (.inl e)
  let y : Fin m → ℝ := fun e => D * t (.inr e)
  let mesh := epsOpt / (8 * m)
  let x' : Fin m → ℝ := fun e =>
    gridCoordinate (x e) (pairProbability ends y (ends e).1 (ends e).2) mesh
  have h := oracle_greedy_solution hm p D tau epsOpt Q ends f w draw
    hf hmono hzero hp hp1 hD hD2.le htau heOpt0 heOpt1
    hQ hwbox hsingleton hgrid hmean
  have hmesh : 0 < (m : ℝ) := by exact_mod_cast hm
  have hround := shearer_grid_feasible_and_loss ends hloop p D r mesh tau hD2 hDr
    hr0 hr1 (by dsimp [mesh]; positivity) x y w h.1 hwbox
  change Feasible p D ends ends x' y ∧
    (∑ e, w e * x e) - (Fintype.card (Fin m) : ℝ) * mesh * tau ≤ ∑ e, w e * x' e
    at hround
  have hmeshLoss : (Fintype.card (Fin m) : ℝ) * mesh * tau = epsOpt * tau / 8 := by
    simp only [Fintype.card_fin, mesh]
    field_simp
  rw [hmeshLoss] at hround
  apply rounding_of_comparator_bound hm ends hloop hsimple p D r epsRound beta lower
    ((5 / 8) * epsOpt * tau) hp.le hp1 hr0 hr1 hDr heRound0 heRound1 hcap x' y w hround.1
    f hf hmono hzero (fun e => (hwbox e).1) hw O hz0 hbeta hsource
  intro z hz
  have hscore := h.2 z O hz
  change _ ≤ (∑ e, w e * x e) + residualExtension hm p f y at hscore
  linarith only [hscore, hround.2]

end

end SubmodularMatching.UpperBoundAssembly
