import SubmodularMatching.TwoStageAlteration

/-! Conservative pair denominators for diffuse alteration. -/

namespace SubmodularMatching.TwoLayerDiffuse

open TwoStage VarianceBound
noncomputable section

/-- Upward error in the vacancy denominator and downward rounding of the
quotient incur only additive error, uniformly at the paper's degree bound. -/
theorem conservative_pair_error (x q Q p η z τ : ℝ)
    (hq : (1:ℝ)/3 ≤ q) (hx : 0 ≤ x) (hcap : x / q ≤ p)
    (hQ : q ≤ Q) (hη : Q ≤ q+η)
    (hz₁ : z ≤ x/Q) (hz₂ : x/Q - τ ≤ z) :
    z ≤ x/q ∧ x/q - (3*p*η + τ) ≤ z := by
  have hqp : 0 < q := by linarith
  have hQp : 0 < Q := by linarith
  have hp : 0 ≤ p := (div_nonneg hx hqp.le).trans hcap
  have he : 0 ≤ η := by linarith
  have ha : 0 ≤ x/q := div_nonneg hx hqp.le
  have hc : (x/q)*(Q-q) ≤ p*η :=
    mul_le_mul hcap (by linarith) (by linarith) hp
  have hi : (x/q)*q = x := div_mul_cancel₀ _ hqp.ne'
  have hxQ : x/Q ≤ x/q := div_le_div_of_nonneg_left hx hqp hQ
  have hd : x/q - 3*p*η ≤ x/Q := by
    apply (le_div_iff₀ hQp).2
    nlinarith only [hc,hi,mul_le_mul_of_nonneg_right (show 1/3 ≤ Q by linarith) (mul_nonneg hp he)]
  exact ⟨hz₁.trans hxQ,by linarith⟩

variable {E V Ω : Type*} [Fintype E] [DecidableEq V]

/-- Reducing compensated coordinates reduces every overload test, on every
outcome, including outcomes that have positive reservation correlations. -/
theorem load_mono_coordinates (ends : E → V × V) (U : V → Ω → ℝ) (hU : ∀ v ω, 0 ≤ U v ω)
    (a b : E → ℝ) (h : ∀ e, a e ≤ b e) (v : V) (ω : Ω) :
    load ends a U v ω ≤ load ends b U v ω := by
  unfold load
  apply Finset.sum_le_sum
  intro e _
  apply mul_le_mul_of_nonneg_right (h e)
  unfold opposite
  split_ifs <;> first | exact hU _ _ | exact le_rfl

/-- Conservative coordinate approximation changes the value retained on
each coordinate by at most its own input error. -/
theorem altered_coordinate_loss (ends : E → V × V) (U : V → Ω → ℝ)
    (hU : ∀ v ω, 0 ≤ U v ω) (a b : E → ℝ) (ha : ∀ e, 0 ≤ a e)
    (h : ∀ e, a e ≤ b e) (ε : ℝ) (hε : 0 ≤ ε) (τ : ℝ) (hτ : 0 ≤ τ)
    (ω : Ω) (e : E) (hloss : b e - τ ≤ a e) :
    altered ends b U ε ω e - τ ≤ altered ends a U ε ω e := by
  have hden : 0 < 1+ε := by linarith
  have hload := load_mono_coordinates ends U hU a b h
  by_cases hb : U (ends e).1 ω = 1 ∧ U (ends e).2 ω = 1 ∧
      load ends b U (ends e).1 ω ≤ 1+ε ∧ load ends b U (ends e).2 ω ≤ 1+ε
  · have ha' := And.intro hb.1 (And.intro hb.2.1 (And.intro
        ((hload _ ω).trans hb.2.2.1) ((hload _ ω).trans hb.2.2.2)))
    rw [altered,if_pos hb,altered,if_pos ha']
    have h₁ := (div_le_div_iff_of_pos_right hden).2 hloss
    rw [sub_div] at h₁
    have h₂ : τ/(1+ε) ≤ τ := (div_le_iff₀ hden).2 (by nlinarith only [mul_nonneg hτ hε])
    linarith
  · rw [altered,if_neg hb]
    unfold altered
    split_ifs <;> linarith only [hτ,div_nonneg (ha e) hden.le]

end
end SubmodularMatching.TwoLayerDiffuse
