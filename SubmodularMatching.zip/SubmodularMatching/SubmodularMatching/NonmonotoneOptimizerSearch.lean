import SubmodularMatching.NonmonotoneOptimizerGrid
import Mathlib.Data.Rat.BigOperators

/-! A finite, tail-recursive variational projection search with an actual
call to the executable integer-array packing oracle on every iteration. -/

namespace SubmodularMatching.NonmonotoneOptimizer

variable {M N : ℕ}

def diff (y r : Vec N) (i : Fin N) : ℚ := atRat y i-atRat r i

def oracleGain (y r v : Vec N) : ℚ := ∑ i, diff y r i * diff v r i

def projectLoop (K : PackingGrid M N) (p : ProjectParams) (y : Vec N) : ℕ → Vec N → Vec N
  | 0, r => r
  | k+1, r =>
    let v := signedDir K.entry K.den p.bound p.oracleTol (diff y r)
    if oracleGain y r v ≤ p.threshold then r
    else projectLoop K p y k (mixGrid r v p)

noncomputable def ProjectParams.decrease (p : ProjectParams) (N : ℕ) : ℝ :=
  2*(p.step:ℝ)*p.threshold - (p.step:ℝ)^2*N - N*(2*(p.bound:ℝ)*p.mesh)

noncomputable def ProjectParams.residual (p : ProjectParams) : ℝ := (p.threshold:ℝ)+(p.bound:ℝ)*p.oracleTol

theorem oracleGain_real (y r v : Vec N) : (oracleGain y r v : ℝ) =
    dot (fun i => coordinates y i - coordinates r i) (fun i => coordinates v i-coordinates r i) := by
  simp only [oracleGain,diff,dot,coordinates,Rat.cast_sum,Rat.cast_mul,Rat.cast_sub]

private theorem dot_sub_right (g x y : Fin N → ℝ) :
    dot g (fun i => x i-y i) = dot g x-dot g y := by simp [dot,mul_sub,Finset.sum_sub_distrib]

/-- The concrete search returns a feasible vector and certifies the variational
condition simultaneously against every real comparator. Its explicit fuel
uses a lower bound on objective decrease until termination. -/
theorem projectLoop_correct (K : PackingGrid M N) (p : ProjectParams) (hp : p.Valid)
    (y : Vec N) (hy : ∀ i, atRat y i ≤ p.bound) (fuel : ℕ) (r : Vec N)
    (hr : feasible K.entry K.den (coordinates r))
    (hbudget : distSq (coordinates r) (coordinates y) < fuel*p.decrease N) :
    let z := coordinates (projectLoop K p y fuel r)
    feasible K.entry K.den z ∧ ∀ o, feasible K.entry K.den o →
      dot (fun i => coordinates y i-z i) (fun i => o i-z i) ≤ p.residual := by
  induction fuel generalizing r with
  | zero =>
    simp only [Nat.cast_zero,zero_mul] at hbudget
    exact (not_lt_of_ge (distSq_nonneg _ _) hbudget).elim
  | succ k ih =>
    let v := signedDir K.entry K.den p.bound p.oracleTol (diff y r)
    let g := fun i => coordinates y i-coordinates r i
    have hc (i : Fin N) : diff y r i ≤ p.bound := by
      have h0r : (0:ℝ) ≤ (atRat r i:ℝ) := (hr.1 i).1
      have h0 : 0 ≤ atRat r i := by exact_mod_cast h0r
      dsimp [diff]; linarith only [hy i,h0]
    have H := signedDir_correct K.entry K.den p.bound p.oracleTol (diff y r) K.rows_pos K.cols_pos
      K.den_pos K.valid hp.2.2.2.2 hc hp.2.2.1 hp.2.2.2.1
    have hv : feasible K.entry K.den (coordinates v) := H.1
    have hgain : (oracleGain y r v:ℝ) = dot g (fun i => coordinates v i-coordinates r i) := oracleGain_real _ _ _
    change let z := coordinates (if oracleGain y r v ≤ p.threshold then r else projectLoop K p y k (mixGrid r v p));
      feasible K.entry K.den z ∧ ∀ o, feasible K.entry K.den o →
        dot (fun i => coordinates y i-z i) (fun i => o i-z i) ≤ p.residual
    by_cases hstop : oracleGain y r v ≤ p.threshold
    · rw [if_pos hstop]
      refine ⟨hr, fun o ho => ?_⟩
      have hs : (oracleGain y r v:ℝ) ≤ p.threshold := by exact_mod_cast hstop
      rw [hgain, dot_sub_right] at hs
      have hc' : (fun i => (diff y r i:ℝ)) = g := by funext i; simp [diff,g,coordinates]
      have hobj := H.2 o ho
      rw [hc'] at hobj
      change dot g o ≤ dot g (coordinates v) + (p.bound:ℝ)*p.oracleTol at hobj
      change dot g (fun i => o i-coordinates r i) ≤ p.residual
      rw [dot_sub_right]
      unfold ProjectParams.residual
      linarith only [hs,hobj]
    · rw [if_neg hstop]
      obtain ⟨hnext,hrnd⟩ := mixGrid_correct K p hp r v y hr hv hy
      apply ih (mixGrid r v p) hnext
      have hdec := projection_descent (coordinates r) (coordinates v) (coordinates y) p.step
      rw [hdec] at hrnd
      have hs : (p.threshold:ℝ) < oracleGain y r v := by exact_mod_cast not_le.mp hstop
      rw [hgain] at hs
      change _ ≤ distSq (coordinates r) (coordinates y) -
        2*(p.step:ℝ)*dot g (fun i => coordinates v i-coordinates r i) + _ + _ at hrnd
      have hstep : 0 < (p.step:ℝ) := by exact_mod_cast hp.1
      have hadv := mul_le_mul_of_nonneg_left hs.le (show 0 ≤ 2*(p.step:ℝ) by linarith)
      have hdiam := mul_le_mul_of_nonneg_left (feasible_diam K _ _ hv hr) (sq_nonneg (p.step:ℝ))
      have hdelta : distSq (coordinates (mixGrid r v p)) (coordinates y) ≤
          distSq (coordinates r) (coordinates y)-p.decrease N := by
        unfold ProjectParams.decrease
        linarith only [hrnd,hadv,hdiam]
      push_cast at hbudget
      linarith only [hdelta,hbudget]

/-- A sufficient initial budget independent of the starting packing vector. -/
theorem target_distance_bound (K : PackingGrid M N) (r y : Vec N) (B : ℝ)
    (hr : feasible K.entry K.den (coordinates r))
    (hy : ∀ i, -B ≤ coordinates y i ∧ coordinates y i ≤ B) :
    distSq (coordinates r) (coordinates y) ≤ N*(1+B)^2 := by
  have hh (i : Fin N) : (coordinates r i-coordinates y i)^2 ≤ (1+B)^2 := by
    have h1 : 0 ≤ (1+B)-(coordinates r i-coordinates y i) := by linarith [(hr.1 i).2,(hy i).1]
    have h2 : 0 ≤ (1+B)+(coordinates r i-coordinates y i) := by linarith [(hr.1 i).1,(hy i).2]
    nlinarith only [mul_nonneg h1 h2]
  have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hh i)
  simpa only [distSq,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] using h

end SubmodularMatching.NonmonotoneOptimizer
