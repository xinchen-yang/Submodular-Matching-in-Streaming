import SubmodularMatching.FiniteSubmodularClosure
import SubmodularMatching.LowerBoundProfile
import Mathlib.Tactic.FieldSimp

/-!
# The actual recursive lower-bound objective

Elements have a stage number and a Boolean indicating whether their public
label is the distinguished label of that stage. Setting `unit = 1/M` gives
the paper's normalized good/bad edge counts. The definition applies to every
finite subset, including infeasible subsets and elements outside the active
stage range (which do not affect its value).
-/

namespace SubmodularMatching.RecursiveObjective

noncomputable section

variable {E : Type*} [DecidableEq E]

/-- Normalized count of elements of a selected stage and label class. -/
def stageMass (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (i : ℕ) (tag : Bool) (S : Finset E) : ℝ :=
  (S.filter (fun e => stage e = i ∧ label e = tag)).sum (fun _ => unit)

omit [DecidableEq E] in
theorem stageMass_nonnegative (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (i : ℕ) (tag : Bool) (S : Finset E) :
    0 ≤ stageMass unit stage label i tag S :=
  Finset.sum_nonneg (fun _ _ => hunit)

theorem stageMass_monotone (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (i : ℕ) (tag : Bool) :
    IsMonotone (stageMass unit stage label i tag) := by
  intro A B hAB
  apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset_filter _ hAB)
  intro e he heA
  exact hunit

theorem stageMass_insert (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (i : ℕ) (tag : Bool) (S : Finset E) (e : E) (he : e ∉ S) :
    stageMass unit stage label i tag (insert e S) =
      stageMass unit stage label i tag S +
        if stage e = i ∧ label e = tag then unit else 0 := by
  by_cases hm : stage e = i ∧ label e = tag
  · simp [stageMass, Finset.filter_insert, hm, he, add_comm]
    ring
  · simp [stageMass, Finset.filter_insert, hm]

theorem stageMass_insert_other (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (i : ℕ) (tag : Bool) (S : Finset E) (e : E) (he : stage e ≠ i) :
    stageMass unit stage label i tag (insert e S) = stageMass unit stage label i tag S := by
  simp [stageMass, Finset.filter_insert, he]

omit [DecidableEq E] in
theorem stageMass_eq_card (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (i : ℕ) (tag : Bool) (S : Finset E) :
    stageMass unit stage label i tag S =
      ((S.filter (fun e => stage e = i ∧ label e = tag)).card : ℝ) * unit := by
  simp [stageMass]

/-- Unclipped one-stage expression with the bad count already capped. -/
def raw (capacity good bad suffix : ℝ) : ℝ :=
  good + bad + (1 - bad / capacity) * suffix

/-- The paper's recursion, with `start` the current stage and `count` the
number of remaining stages. -/
def objective (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (start : ℕ) : ℕ → Finset E → ℝ
  | 0, _ => 0
  | n + 1, S => min (n + 1 : ℝ)
      (raw (n + 1) (stageMass unit stage label start true S)
        (min (stageMass unit stage label start false S) (n + 1))
        (objective unit stage label (start + 1) n S))

theorem objective_insert_before (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (count start : ℕ) (S : Finset E) (e : E) (he : stage e < start) :
    objective unit stage label start count (insert e S) =
      objective unit stage label start count S := by
  induction count generalizing start with
  | zero => rfl
  | succ n ih =>
    simp only [objective]
    rw [stageMass_insert_other unit stage label start true S e (by omega),
      stageMass_insert_other unit stage label start false S e (by omega),
      ih (start + 1) (by omega)]

theorem coefficient_bounds (C t : ℝ) (hC : 0 < C) (ht0 : 0 ≤ t) (htC : t ≤ C) :
    0 ≤ 1 - t / C ∧ 1 - t / C ≤ 1 := by
  have hdiv : 0 ≤ t / C := div_nonneg ht0 hC.le
  have hdiv' : t / C ≤ 1 := (div_le_one hC).mpr htC
  constructor <;> linarith

theorem raw_nonnegative (C g t z : ℝ) (hC : 0 < C)
    (hg : 0 ≤ g) (ht0 : 0 ≤ t) (htC : t ≤ C) (hz : 0 ≤ z) :
    0 ≤ raw C g t z := by
  exact add_nonneg (add_nonneg hg ht0)
    (mul_nonneg (coefficient_bounds C t hC ht0 htC).1 hz)

theorem raw_monotone (C g₁ g₂ t₁ t₂ z₁ z₂ : ℝ) (hC : 0 < C)
    (hg : g₁ ≤ g₂) (ht : t₁ ≤ t₂) (hz : z₁ ≤ z₂)
    (ht₂0 : 0 ≤ t₂) (ht₂C : t₂ ≤ C) (hz₁0 : 0 ≤ z₁) (hz₁C : z₁ ≤ C) :
    raw C g₁ t₁ z₁ ≤ raw C g₂ t₂ z₂ := by
  have hm₁ := mul_nonneg (sub_nonneg.mpr ht) (coefficient_bounds C z₁ hC hz₁0 hz₁C).1
  have hm₂ := mul_nonneg (coefficient_bounds C t₂ hC ht₂0 ht₂C).1 (sub_nonneg.mpr hz)
  have hid : raw C g₂ t₂ z₂ - raw C g₁ t₁ z₁ =
      (g₂ - g₁) + (t₂ - t₁) * (1 - z₁ / C) + (1 - t₂ / C) * (z₂ - z₁) := by
    dsimp [raw]
    ring
  apply sub_nonneg.mp
  rw [hid]
  exact add_nonneg (add_nonneg (sub_nonneg.mpr hg) hm₁) hm₂

omit [DecidableEq E] in
theorem objective_empty (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (count start : ℕ) : objective unit stage label start count ∅ = 0 := by
  induction count generalizing start with
  | zero => rfl
  | succ n ih =>
    have hn : (0 : ℝ) ≤ n + 1 := by positivity
    simpa [objective, stageMass, raw, ih] using hn

omit [DecidableEq E] in
theorem objective_bounds (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (count start : ℕ) (S : Finset E) :
    0 ≤ objective unit stage label start count S ∧
      objective unit stage label start count S ≤ (count : ℝ) := by
  induction count generalizing start with
  | zero => simp [objective]
  | succ n ih =>
    have hC : (0 : ℝ) < n + 1 := by positivity
    have hg := stageMass_nonnegative unit hunit stage label start true S
    have hb := stageMass_nonnegative unit hunit stage label start false S
    have ht : 0 ≤ min (stageMass unit stage label start false S) (n + 1 : ℝ) :=
      le_min hb hC.le
    have hraw := raw_nonnegative (n + 1) _ _ _ hC hg ht (min_le_right _ _) (ih (start + 1)).1
    constructor
    · exact le_min hC.le hraw
    · simpa only [Nat.cast_add, Nat.cast_one] using
        (min_le_left (n + 1 : ℝ) (raw (n + 1) (stageMass unit stage label start true S)
          (min (stageMass unit stage label start false S) (n + 1))
          (objective unit stage label (start + 1) n S)))

theorem objective_monotone (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (count start : ℕ) :
    IsMonotone (objective unit stage label start count) := by
  induction count generalizing start with
  | zero => intro A B hAB; exact le_rfl
  | succ n ih =>
    intro A B hAB
    apply min_le_min_left
    have hC : (0 : ℝ) < n + 1 := by positivity
    have hb := stageMass_nonnegative unit hunit stage label start false B
    have hbound := objective_bounds unit hunit stage label n (start + 1) A
    apply raw_monotone (n + 1) _ _ _ _ _ _ hC
      (stageMass_monotone unit hunit stage label start true A B hAB)
      (min_le_min_right _ (stageMass_monotone unit hunit stage label start false A B hAB))
      (ih (start + 1) A B hAB) (le_min hb hC.le) (min_le_right _ _) hbound.1
    linarith [hbound.2]

/-- One step of the objective before its outer truncation. -/
def unclipped (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (start n : ℕ) (S : Finset E) : ℝ :=
  raw (n + 1) (stageMass unit stage label start true S)
    (min (stageMass unit stage label start false S) (n + 1))
    (objective unit stage label (start + 1) n S)

theorem unclipped_monotone (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (start n : ℕ) :
    IsMonotone (unclipped unit stage label start n) := by
  intro A B hAB
  have hC : (0 : ℝ) < n + 1 := by positivity
  have hb := stageMass_nonnegative unit hunit stage label start false B
  have hbound := objective_bounds unit hunit stage label n (start + 1) A
  apply raw_monotone (n + 1) _ _ _ _ _ _ hC
    (stageMass_monotone unit hunit stage label start true A B hAB)
    (min_le_min_right _ (stageMass_monotone unit hunit stage label start false A B hAB))
    (objective_monotone unit hunit stage label n (start + 1) A B hAB)
    (le_min hb hC.le) (min_le_right _ _) hbound.1
  linarith [hbound.2]

theorem unclipped_increment_good (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (start n : ℕ) (S : Finset E) (e : E) (he : e ∉ S)
    (hs : stage e = start) (hl : label e = true) :
    unclipped unit stage label start n (insert e S) -
      unclipped unit stage label start n S = unit := by
  unfold unclipped
  rw [stageMass_insert unit stage label start true S e he,
    stageMass_insert unit stage label start false S e he,
    objective_insert_before unit stage label n (start + 1) S e (by omega)]
  simp only [hs, hl, and_self, if_true, Bool.true_eq_false, and_false, if_false, add_zero]
  unfold raw
  ring

theorem unclipped_increment_bad (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (start n : ℕ) (S : Finset E) (e : E) (he : e ∉ S)
    (hs : stage e = start) (hl : label e = false) :
    unclipped unit stage label start n (insert e S) -
      unclipped unit stage label start n S =
      (min (stageMass unit stage label start false S + unit) (n + 1) -
        min (stageMass unit stage label start false S) (n + 1)) *
      (1 - objective unit stage label (start + 1) n S / (n + 1)) := by
  unfold unclipped
  rw [stageMass_insert unit stage label start true S e he,
    stageMass_insert unit stage label start false S e he,
    objective_insert_before unit stage label n (start + 1) S e (by omega)]
  simp only [hs, hl, and_self, if_true, Bool.false_eq_true, and_false, if_false, add_zero]
  unfold raw
  ring

theorem unclipped_increment_other (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (start n : ℕ) (S : Finset E) (e : E) (hs : stage e ≠ start) :
    unclipped unit stage label start n (insert e S) -
      unclipped unit stage label start n S =
      (1 - min (stageMass unit stage label start false S) (n + 1) / (n + 1)) *
      (objective unit stage label (start + 1) n (insert e S) -
        objective unit stage label (start + 1) n S) := by
  unfold unclipped
  rw [stageMass_insert_other unit stage label start true S e hs,
    stageMass_insert_other unit stage label start false S e hs]
  unfold raw
  ring

theorem capped_increment_nonnegative (C x d : ℝ) (hd : 0 ≤ d) :
    0 ≤ min (x + d) C - min x C := by
  apply sub_nonneg.mpr
  apply min_le_min_right
  linarith

theorem capped_increment_le (C x d : ℝ) (hd : 0 ≤ d) :
    min (x + d) C - min x C ≤ d := by
  rw [min_comm (x + d) C, min_comm x C, min_increment C x d hd]
  exact min_le_left _ _

theorem capped_increment_antitone (C x y d : ℝ) (hxy : x ≤ y) (hd : 0 ≤ d) :
    min (y + d) C - min y C ≤ min (x + d) C - min x C := by
  rw [min_comm (y + d) C, min_comm y C, min_comm (x + d) C, min_comm x C,
    min_increment C y d hd, min_increment C x d hd]
  apply min_le_min_left
  apply max_le_max_right
  linarith

theorem unclipped_diminishing_returns (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (start n : ℕ)
    (htail : HasDiminishingReturns (objective unit stage label (start + 1) n)) :
    HasDiminishingReturns (unclipped unit stage label start n) := by
  intro A B e hAB
  have hC : (0 : ℝ) < n + 1 := by positivity
  by_cases heB : e ∈ B
  · rw [Finset.insert_eq_of_mem heB, sub_self]
    exact sub_nonneg.mpr (unclipped_monotone unit hunit stage label start n
      A (insert e A) (Finset.subset_insert e A))
  · have heA : e ∉ A := fun h => heB (hAB h)
    by_cases hs : stage e = start
    · cases hl : label e with
      | true =>
        rw [unclipped_increment_good unit stage label start n B e heB hs hl,
          unclipped_increment_good unit stage label start n A e heA hs hl]
      | false =>
        rw [unclipped_increment_bad unit stage label start n B e heB hs hl,
          unclipped_increment_bad unit stage label start n A e heA hs hl]
        apply mul_le_mul
        · exact capped_increment_antitone _ _ _ unit
            (stageMass_monotone unit hunit stage label start false A B hAB) hunit
        · apply sub_le_sub_left
          exact div_le_div_of_nonneg_right
            (objective_monotone unit hunit stage label n (start + 1) A B hAB) hC.le
        · have hb := objective_bounds unit hunit stage label n (start + 1) B
          exact (coefficient_bounds _ _ hC hb.1 (by linarith [hb.2])).1
        · exact capped_increment_nonnegative _ _ _ hunit
    · rw [unclipped_increment_other unit stage label start n B e hs,
        unclipped_increment_other unit stage label start n A e hs]
      apply mul_le_mul
      · apply sub_le_sub_left
        apply div_le_div_of_nonneg_right _ hC.le
        exact min_le_min_right _
          (stageMass_monotone unit hunit stage label start false A B hAB)
      · exact htail A B e hAB
      · exact sub_nonneg.mpr (objective_monotone unit hunit stage label n (start + 1)
          B (insert e B) (Finset.subset_insert e B))
      · exact (coefficient_bounds _ _ hC
          (le_min (stageMass_nonnegative unit hunit stage label start false A) hC.le)
          (min_le_right _ _)).1

/-- Diminishing returns of the actual recursive objective on all finite sets. -/
theorem objective_diminishing_returns (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (count start : ℕ) :
    HasDiminishingReturns (objective unit stage label start count) := by
  induction count generalizing start with
  | zero => intro A B e hAB; simp [objective]
  | succ n ih =>
    exact truncate_diminishing_returns _
      (unclipped_monotone unit hunit stage label start n)
      (unclipped_diminishing_returns unit hunit stage label start n (ih (start + 1)))
      (n + 1)

/-- Submodularity on arbitrary, possibly infeasible, sets of potential edges. -/
theorem objective_submodular (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (count start : ℕ) :
    IsSubmodular (objective unit stage label start count) :=
  submodular_of_diminishing_returns _
    (objective_diminishing_returns unit hunit stage label count start)

theorem truncation_increment_le (C x y : ℝ) (hxy : x ≤ y) :
    min C y - min C x ≤ y - x := by
  have h := min_increment C x (y - x) (sub_nonneg.mpr hxy)
  have heq : x + (y - x) = y := by ring
  rw [heq] at h
  rw [h]
  exact min_le_left _ _

/-- Every element has marginal contribution at most its normalization unit. -/
theorem objective_increment_le (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (count start : ℕ) (S : Finset E) (e : E) :
    objective unit stage label start count (insert e S) -
      objective unit stage label start count S ≤ unit := by
  induction count generalizing start with
  | zero => simpa [objective] using hunit
  | succ n ih =>
    have hC : (0 : ℝ) < n + 1 := by positivity
    by_cases he : e ∈ S
    · simpa [Finset.insert_eq_of_mem he] using hunit
    · have hraw : unclipped unit stage label start n (insert e S) -
          unclipped unit stage label start n S ≤ unit := by
        by_cases hs : stage e = start
        · cases hl : label e with
          | true => rw [unclipped_increment_good unit stage label start n S e he hs hl]
          | false =>
            rw [unclipped_increment_bad unit stage label start n S e he hs hl]
            have hb := objective_bounds unit hunit stage label n (start + 1) S
            have hc := (coefficient_bounds _ _ hC hb.1 (by linarith [hb.2])).2
            calc
              _ ≤ (min (stageMass unit stage label start false S + unit) (n + 1) -
                    min (stageMass unit stage label start false S) (n + 1)) * 1 :=
                mul_le_mul_of_nonneg_left hc (capped_increment_nonnegative _ _ _ hunit)
              _ ≤ unit := by
                rw [mul_one]
                exact capped_increment_le _ _ _ hunit
        · rw [unclipped_increment_other unit stage label start n S e hs]
          have hb := stageMass_nonnegative unit hunit stage label start false S
          have hc := (coefficient_bounds _ _ hC (le_min hb hC.le) (min_le_right _ _)).2
          have hz := sub_nonneg.mpr (objective_monotone unit hunit stage label n (start + 1)
            S (insert e S) (Finset.subset_insert e S))
          calc
            _ ≤ 1 * (objective unit stage label (start + 1) n (insert e S) -
                objective unit stage label (start + 1) n S) := mul_le_mul_of_nonneg_right hc hz
            _ ≤ unit := by simpa only [one_mul] using ih (start + 1)
      exact (truncation_increment_le (n + 1) _ _
        (unclipped_monotone unit hunit stage label start n S (insert e S)
          (Finset.subset_insert e S))).trans hraw

/-- The normalized number of all elements of a stage, without looking at labels. -/
def totalStageMass (unit : ℝ) (stage : E → ℕ) (i : ℕ) (S : Finset E) : ℝ :=
  (S.filter (fun e => stage e = i)).sum (fun _ => unit)

omit [DecidableEq E] in
theorem stageMass_partition (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (i : ℕ) (S : Finset E) :
    stageMass unit stage label i true S + stageMass unit stage label i false S =
      totalStageMass unit stage i S := by
  simp only [stageMass, totalStageMass, Finset.sum_filter]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro e he
  cases hl : label e <;> by_cases hs : stage e = i <;> simp [hs]

omit [DecidableEq E] in
theorem stageMass_eq_zero_of_no_stage (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (i : ℕ) (tag : Bool) (S : Finset E) (hS : ∀ e ∈ S, stage e ≠ i) :
    stageMass unit stage label i tag S = 0 := by
  apply Finset.sum_eq_zero
  intro e he
  exact False.elim (hS e (Finset.mem_filter.mp he).1 (Finset.mem_filter.mp he).2.1)

omit [DecidableEq E] in
theorem objective_eq_zero_of_before (unit : ℝ) (stage : E → ℕ) (label : E → Bool)
    (count start : ℕ) (S : Finset E) (hS : ∀ e ∈ S, stage e < start) :
    objective unit stage label start count S = 0 := by
  induction count generalizing start with
  | zero => rfl
  | succ n ih =>
    have hne : ∀ e ∈ S, stage e ≠ start := fun e he => (hS e he).ne
    have hnext : ∀ e ∈ S, stage e < start + 1 := fun e he => by have := hS e he; omega
    simp only [objective]
    rw [stageMass_eq_zero_of_no_stage unit stage label start true S hne,
      stageMass_eq_zero_of_no_stage unit stage label start false S hne, ih (start + 1) hnext]
    have hC : (0 : ℝ) ≤ n + 1 := by positivity
    simp [raw, min_eq_left hC, min_eq_right hC]

theorem min_add_capped (C g b : ℝ) (hg : 0 ≤ g) :
    min C (g + min b C) = min C (g + b) := by
  by_cases hb : b ≤ C
  · rw [min_eq_left hb]
  · rw [min_eq_right (le_of_not_ge hb), min_eq_left (by linarith),
      min_eq_left (by linarith)]

omit [DecidableEq E] in
/-- A query ending in the current stage has value independent of that stage's
distinguished label, even if the query is infeasible or arbitrarily large. -/
theorem terminal_stage_value (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label : E → Bool) (start n : ℕ) (S : Finset E)
    (hS : ∀ e ∈ S, stage e ≤ start) :
    objective unit stage label start (n + 1) S =
      min (n + 1 : ℝ) (totalStageMass unit stage start S) := by
  have hnext : ∀ e ∈ S, stage e < start + 1 := fun e he => by have := hS e he; omega
  simp only [objective]
  rw [objective_eq_zero_of_before unit stage label n (start + 1) S hnext]
  simp only [raw, mul_zero, add_zero]
  rw [min_add_capped _ _ _ (stageMass_nonnegative unit hunit stage label start true S),
    stageMass_partition]

omit [DecidableEq E] in
theorem stageMass_label_congr (unit : ℝ) (stage : E → ℕ) (label₁ label₂ : E → Bool)
    (i : ℕ) (tag : Bool) (S : Finset E)
    (hlabel : ∀ e ∈ S, stage e = i → label₁ e = label₂ e) :
    stageMass unit stage label₁ i tag S = stageMass unit stage label₂ i tag S := by
  unfold stageMass
  congr 1
  apply Finset.filter_congr
  intro e he
  by_cases hs : stage e = i
  · simp [hs, hlabel e he hs]
  · simp [hs]

omit [DecidableEq E] in
/-- Prefix oracle values cannot reveal the distinguished label of the most
recent stage or any later label. Only labels of earlier stages are fixed. -/
theorem prefix_label_invariance (unit : ℝ) (hunit : 0 ≤ unit)
    (stage : E → ℕ) (label₁ label₂ : E → Bool) (count start cutoff : ℕ) (S : Finset E)
    (hS : ∀ e ∈ S, stage e ≤ cutoff)
    (hlabel : ∀ e ∈ S, stage e < cutoff → label₁ e = label₂ e) :
    objective unit stage label₁ start count S = objective unit stage label₂ start count S := by
  induction count generalizing start with
  | zero => rfl
  | succ n ih =>
    by_cases hs : start < cutoff
    · have heq : ∀ e ∈ S, stage e = start → label₁ e = label₂ e := by
        intro e he hi
        apply hlabel e he
        omega
      simp only [objective]
      rw [stageMass_label_congr unit stage label₁ label₂ start true S heq,
        stageMass_label_congr unit stage label₁ label₂ start false S heq, ih (start + 1)]
    · by_cases heq : start = cutoff
      · subst start
        rw [terminal_stage_value unit hunit stage label₁ cutoff n S hS,
          terminal_stage_value unit hunit stage label₂ cutoff n S hS]
      · have hbefore : ∀ e ∈ S, stage e < start := by
          intro e he
          have := hS e he
          omega
        rw [objective_eq_zero_of_before unit stage label₁ (n + 1) start S hbefore,
          objective_eq_zero_of_before unit stage label₂ (n + 1) start S hbefore]

end

end SubmodularMatching.RecursiveObjective
