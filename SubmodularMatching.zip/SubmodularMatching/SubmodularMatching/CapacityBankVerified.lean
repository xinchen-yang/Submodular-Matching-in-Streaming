import SubmodularMatching.CapacityBankTranscript
import SubmodularMatching.CapacityPhysicalVerified

/-! A selected payload of the executed scheduler carries both signed pass certificates. -/

namespace SubmodularMatching.AppendixM
open Capacity SourceCertificate Streaming UpperBoundAssembly Finset
open scoped BigOperators
attribute [local irreducible] rescaledRateTable
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Nonempty E] [Fintype V] [DecidableEq V]

/-- Accuracy is tested against the query on the actual stored edge array at
the instant the word batch is consumed. All estimator and history identities
are obtained from the executable forward bank. -/
theorem capacity_forward_bank_verified (S : SimpleEdgeStream E V) (cap : V → ℕ)
    (hpos : ∀ e, 0 < cap (S.ends e).1 ∧ 0 < cap (S.ends e).2)
    (N bits : ℕ) (hN : 0 < N) (oracle : Finset E → ℚ) (edges : ℕ → E)
    (draw : ℕ → ℕ → ℕ → ℕ → ℕ) (k j : ℕ) (M : Finset E)
    (hk : k ≤ (Fintype.card V)^2) (hf : IsSubmodular (fun A => (oracle A:ℝ)))
    (hn : ∀ A, 0 ≤ (oracle A:ℝ))
    (hinj : ∀ i < k, ∀ l < k, edges i = edges l → i=l)
    (hM : Capacity.feasible S.ends cap M) (hMsub : M ⊆ (range k).image edges) :
    let v := (Fintype.card V)^2
    let W := guessWidth v
    let ep := runOnlineEpoch W (guessSpan v) (edgeClock edges oracle)
    let τ := (ep (k+1)).scale j
    let f := fun A : Finset E => (oracle A:ℝ)
    let b := signedBirth W (f ∅) (fun i => f {edges i}) j k
    let run := bankPrefix S.ends cap hpos v N bits oracle edges draw b j
    let st := run (k-b)
    let suffix := fun i => edges (b+i)
    let samples := fun i (r : Fin N) => (bankRaw (run i) oracle (suffix i) bits (draw (b+i) j) r:ℝ)
    let gap := ((streamTolerance*τ/(v:ℚ)^2:ℚ):ℝ)
    let Q := fun i => storedMarginalQuery ((run i).machine.edges.map Prod.fst) (suffix i) f
      sourceProbability (by norm_num [sourceProbability])
    j ∈ (ep (k+1)).active W (guessSpan v) →
    (∀ i < k-b, (Q i).target-gap ≤ sourceAverage gap (samples i) ∧
      sourceAverage gap (samples i) ≤ (Q i).target+gap) →
    (forwardBank S.ends cap hpos v N bits oracle edges draw k).lookup j = some st ∧
      ∃ ht : 0 < (τ:ℝ), ∃ (left : (e : E) → Fin (cap (S.ends e).1))
          (right : (e : E) → Fin (cap (S.ends e).2)),
        let C := signedConfig v (capacityScheduleVertices S) τ ht
        let pair := slotPair S.ends cap left right
        let input := sampledInput gap suffix samples
        (∀ entry ∈ st.assigned, entry.2 = pair entry.1) ∧
        CapacityPassWitness C S.ends cap pair input (k-b) (st.machine.edges.map Prod.fst).toFinset
          M f streamTolerance := by
  intro v W ep τ f b run st suffix samples gap Q hj herr
  let value := edgeClock edges oracle
  let q := seededScale (f ∅) (fun i => f {edges i})
  have hq : (fun i => (value i:ℝ)) = q := by funext i; cases i <;> rfl
  have hv : 2 ≤ v := capacityScheduleVertices S
  obtain ⟨hw,hw'⟩ := guessWidth_bounds v hv
  have ha := (runOnlineEpoch_active_iff W (guessSpan v) value (le_trans (by norm_num) hw)
    hw' (k+1) j).mp hj
  change guessActive W (guessAnchor W (fun i => (value i:ℝ)) (k+1))
    (singletonMaximum (fun i => (value i:ℝ)) (k+1)) j at ha
  rw [hq] at ha
  have he : (τ:ℝ) = guessAnchor W q (k+1)*2^j := by
    dsimp only [τ,OnlineEpoch.scale,ep]; push_cast
    rw [(runOnlineEpoch_real _ _ _ _).2,←hq]
  have ht := (ha.1.trans_le ha.2.1).trans_eq he.symm
  let C := signedConfig v hv τ ht
  let idx := fun i => (suffix i,sourceWeightIndex N (sourceIndex gap (samples i)))
  let input := sampledInput gap suffix samples
  have hgap : C.gap = gap := by
    change (streamTolerance:ℝ)*(τ:ℝ)/(v:ℝ)^2 = ((streamTolerance*τ/(v:ℚ)^2:ℚ):ℝ)
    push_cast
    rfl
  have hW : (v:ℝ)/(streamTolerance:ℝ) = (W:ℝ) := by simp [W,guessWidth]
  obtain ⟨hlook,hreplay⟩ := active_bank_replay S.ends cap hpos v N bits hv oracle edges draw k j ha
  change ∀ i ≤ k-b, run i = sparseRun S.ends cap hpos (wordGrid v) idx i at hreplay
  refine ⟨hlook,ht,?_⟩
  have hp := capacity_physical_pass_verified_ordered S cap hpos τ ht hN edges samples f k j M
    hk hf hn hinj hM hMsub
  dsimp only at hp
  rw [hW] at hp
  rw [hgap] at hp
  obtain ⟨left,right,hord,hassign,hwitness⟩ := hp
  let pair := slotPair S.ends cap left right
  have hor (i : ℕ) (hi : i≤k-b) : (run i).machine.edges.map Prod.fst = acceptedOrder C pair input i := by
    rw [hreplay i hi]; exact hord i hi
  have hlast : st = sparseRun S.ends cap hpos (wordGrid v) idx (k-b) := hreplay _ le_rfl
  refine ⟨left,right,?_,?_⟩
  · rw [hlast]; exact hassign
  · rw [hlast]
    apply hwitness ha he (fun i _ r => bankRaw_marginal (run i) oracle (suffix i) bits (draw (b+i) j) r)
    intro i hi
    have htarg : (Q i).target = traceWeight C pair input f i := by
      dsimp only [Q]; rw [hor i hi.le]
      exact storedMarginalQuery_target C pair input f sourceProbability _ rfl i
    rw [← htarg]
    exact herr i hi

end
end SubmodularMatching.AppendixM
