import SubmodularMatching.ShearerSampler

/-!
# A Bernoulli-tape bound for Shearer recursion truncation

A successful top coin finishes one pending attempt. A failed top coin
generates one child request and at most two further attempts, consisting of
the child and the parent's retry. Exploring both gives a dominating binary
tree. To reach a request cap of `L` on any continuing tape, at least `L`
of the first `2L` coins must fail. The exact Bernoulli moment then gives
the tail bound `(4r(1-r))^L`.
-/

namespace SubmodularMatching.ShearerSampler

/-- Number of unprocessed slots after a prefix of depth-first exploration
with both children retained at each failed top coin. Here `true` is failure. -/
def pending : ℕ → List Bool → ℕ
  | slots, [] => slots
  | 0, _ :: _ => 0
  | slots+1, b :: tail => pending (slots + if b then 2 else 0) tail

/-- Child requests in that same exploration. Each expanded internal node
is one request, and exploration stops as soon as the slots are exhausted. -/
def requests : ℕ → List Bool → ℕ
  | _, [] => 0
  | 0, _ :: _ => 0
  | slots+1, b :: tail => (if b then 1 else 0) +
      requests (slots + if b then 2 else 0) tail

@[simp] theorem pending_zero (bits : List Bool) : pending 0 bits = 0 := by
  cases bits <;> rfl

theorem pending_accounting (bits : List Bool) (slots : ℕ)
    (hp : 0 < pending slots bits) :
    pending slots bits + bits.length = slots + 2 * bits.count true := by
  induction bits generalizing slots with
  | nil => simp [pending]
  | cons b tail ih =>
    cases slots with
    | zero => simp at hp
    | succ slots =>
      cases b <;> simp [pending] at hp ⊢
      · have h := ih slots hp
        omega
      · have h := ih (slots+2) hp
        omega

theorem requests_le_count (bits : List Bool) (slots : ℕ) :
    requests slots bits ≤ bits.count true := by
  induction bits generalizing slots with
  | nil => simp [requests]
  | cons b tail ih =>
    cases slots with
    | zero => simp [requests]
    | succ slots =>
      cases b <;> simp [requests]
      · exact ih _
      · have h := ih (slots+2)
        omega

theorem requests_append (left right : List Bool) (slots : ℕ) :
    requests slots (left ++ right) = requests slots left + requests (pending slots left) right := by
  induction left generalizing slots with
  | nil => simp [requests, pending]
  | cons b tail ih =>
    cases slots with
    | zero => cases right <;> simp [requests, pending]
    | succ slots => simp [requests, pending, ih, Nat.add_assoc]

/-- The capped exploration event depends only on the first `2L` flips,
in the sense of this pathwise domination for any continuation of the tape. -/
theorem request_cap_implies_many_failures (firstTape suffix : List Bool) (L : ℕ)
    (hlen : firstTape.length = 2 * L) (hcap : L ≤ requests 1 (firstTape ++ suffix)) :
    L ≤ firstTape.count true := by
  by_cases h : L ≤ firstTape.count true
  · exact h
  · have hz : pending 1 firstTape = 0 := by
      by_contra hne
      have hacc := pending_accounting firstTape 1 (Nat.pos_of_ne_zero hne)
      omega
    rw [requests_append, hz] at hcap
    have hz' : requests 0 suffix = 0 := by cases suffix <;> rfl
    rw [hz', Nat.add_zero] at hcap
    exact hcap.trans (requests_le_count firstTape 1)

theorem requests_mono_slots (bits : List Bool) {a b : ℕ} (h : a ≤ b) :
    requests a bits ≤ requests b bits := by
  induction bits generalizing a b with
  | nil => simp [requests]
  | cons bit tail ih =>
    cases a with
    | zero => simp [requests]
    | succ a =>
      cases b with
      | zero => omega
      | succ b =>
        simp only [requests]
        exact Nat.add_le_add_left
          (ih (Nat.add_le_add_right (Nat.le_of_succ_le_succ h) _)) _

/-- The abstract exploration after pruning. Each step may discard any number
of pending attempts, including its own child or retry and calls still
queued from earlier steps. Each trial still follows its top-coin outcome. -/
def requestsPruned : ℕ → List (Bool × ℕ) → ℕ
  | _, [] => 0
  | 0, _ :: _ => 0
  | slots+1, (bit, pruned) :: tail => (if bit then 1 else 0) +
      requestsPruned ((slots + if bit then 2 else 0) - pruned) tail

theorem pruned_requests_le (tape : List (Bool × ℕ)) (slots : ℕ) :
    requestsPruned slots tape ≤ requests slots (tape.map Prod.fst) := by
  induction tape generalizing slots with
  | nil => simp [requestsPruned, requests]
  | cons next tail ih =>
    cases slots with
    | zero => simp [requestsPruned, requests]
    | succ slots =>
      obtain ⟨bit, pruned⟩ := next
      simp only [requestsPruned, List.map_cons, requests]
      exact Nat.add_le_add_left
        ((ih _).trans (requests_mono_slots _ (Nat.sub_le _ _))) _

noncomputable def tapeExpectation (r : ℝ) : ℕ → (List Bool → ℝ) → ℝ
  | 0, f => f []
  | n+1, f => r * tapeExpectation r n (fun tail => f (false :: tail)) +
      (1-r) * tapeExpectation r n (fun tail => f (true :: tail))

theorem tapeExpectation_mono (r : ℝ) (hr : 0 ≤ r) (hr₁ : r ≤ 1)
    (n : ℕ) (f g : List Bool → ℝ)
    (h : ∀ bits : List Bool, bits.length = n → f bits ≤ g bits) :
    tapeExpectation r n f ≤ tapeExpectation r n g := by
  induction n generalizing f g with
  | zero => exact h [] rfl
  | succ n ih =>
    rw [tapeExpectation, tapeExpectation]
    exact add_le_add (mul_le_mul_of_nonneg_left
      (ih _ _ fun bits hn => h (false :: bits) (by simp [hn])) hr)
      (mul_le_mul_of_nonneg_left
        (ih _ _ fun bits hn => h (true :: bits) (by simp [hn])) (sub_nonneg.mpr hr₁))

theorem tapeExpectation_mul (r : ℝ) (n : ℕ) (a : ℝ) (f : List Bool → ℝ) :
    tapeExpectation r n (fun bits => a * f bits) = a * tapeExpectation r n f := by
  induction n generalizing f with
  | zero => rfl
  | succ n ih =>
    rw [tapeExpectation, tapeExpectation, ih (fun bits => f (false :: bits)),
      ih (fun bits => f (true :: bits))]
    ring

theorem tapeExpectation_moment (r z : ℝ) (n : ℕ) :
    tapeExpectation r n (fun bits => z ^ bits.count true) = (r + (1-r)*z)^n := by
  induction n with
  | zero => simp [tapeExpectation]
  | succ n ih =>
    have hf : (fun bits : List Bool => z ^ (false :: bits).count true) =
        (fun bits : List Bool => z ^ bits.count true) := by
      funext bits
      simp
    have ht : (fun bits : List Bool => z ^ (true :: bits).count true) =
        (fun bits : List Bool => z * z ^ bits.count true) := by
      funext bits
      simp [pow_succ']
    rw [tapeExpectation, hf, ht, tapeExpectation_mul, ih, pow_succ]
    ring

/-- A finite Bernoulli tape gives a sharper tail bound for the request cap
than the full-progeny estimate needed by the implementation. -/
theorem request_cap_mass_le (r : ℝ) (hr : 1 / 2 ≤ r) (hr₁ : r < 1)
    (L : ℕ) (trigger : List Bool → Prop) [DecidablePred trigger]
    (htrigger : ∀ bits : List Bool, bits.length = 2 * L →
      trigger bits → L ≤ bits.count true) :
    tapeExpectation r (2 * L) (fun bits => if trigger bits then 1 else 0) ≤
      (4*r*(1-r))^L := by
  let z := r / (1-r)
  have hden : 0 < 1 - r := sub_pos.mpr hr₁
  have hz : 1 ≤ z := (le_div_iff₀ hden).mpr (by linarith)
  have hzpos : 0 < z := zero_lt_one.trans_le hz
  have hmono := tapeExpectation_mono r (by linarith : 0 ≤ r) hr₁.le (2*L)
    (fun bits => if trigger bits then 1 else 0) (fun bits => (z^L)⁻¹ * z^bits.count true)
    (by
      intro bits hlen
      dsimp only
      split_ifs with h
      · rw [← div_eq_inv_mul]
        exact (le_div_iff₀ (pow_pos hzpos _)).mpr
          (by rw [one_mul]; exact pow_le_pow_right₀ hz (htrigger bits hlen h))
      · exact mul_nonneg (inv_nonneg.mpr (pow_nonneg hzpos.le _)) (pow_nonneg hzpos.le _))
  refine hmono.trans_eq ?_
  rw [tapeExpectation_mul, tapeExpectation_moment, pow_mul, ← inv_pow, ← mul_pow]
  congr 1
  dsimp only [z]
  have hrpos : 0 < r := by linarith
  field_simp [hden.ne', hrpos.ne']; ring

/-- For any fixed suffix, the probability of a request count reaching `L`
is controlled by the first `2L` top-coin flips alone. -/
theorem request_scan_truncation (r : ℝ) (hr : 1 / 2 ≤ r) (hr₁ : r < 1)
    (L : ℕ) (suffix : List Bool) :
    tapeExpectation r (2 * L) (fun bits => if L ≤ requests 1 (bits ++ suffix) then 1 else 0) ≤
      (4*r*(1-r))^L := by
  exact request_cap_mass_le r hr hr₁ L _ fun bits hlen hcap =>
    request_cap_implies_many_failures bits suffix L hlen hcap

/-- The finite tail bound survives arbitrary pruning choices and arbitrary
continuations, even when both are functions of the observed top coins. -/
theorem pruned_scan_truncation (r : ℝ) (hr : 1 / 2 ≤ r) (hr₁ : r < 1)
    (L : ℕ) (firstTape suffix : List Bool → List (Bool × ℕ))
    (hp : ∀ bits, (firstTape bits).map Prod.fst = bits) :
    tapeExpectation r (2*L)
      (fun bits => if L ≤ requestsPruned 1 (firstTape bits ++ suffix bits) then 1 else 0) ≤
      (4*r*(1-r))^L := by
  apply request_cap_mass_le r hr hr₁
  intro bits hlen hcap
  apply request_cap_implies_many_failures bits ((suffix bits).map Prod.fst) L hlen
  have hprune := pruned_requests_le (firstTape bits ++ suffix bits) 1
  rw [List.map_append, hp] at hprune
  exact hcap.trans hprune

end SubmodularMatching.ShearerSampler
