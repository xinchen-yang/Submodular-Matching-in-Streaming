import SubmodularMatching.UpperBoundK1IntegerIncidence
import SubmodularMatching.UpperBoundK1OptimizerOnline
import SubmodularMatching.UpperBoundVertexCoefficients

/-! # Sparse projected updates in the integer packing solver -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint LinearPacking
open scoped BigOperators

noncomputable section

variable {m : ℕ} {V : Type*} [Fintype V] [DecidableEq V]

private theorem gridIndex_cast (Q : ℕ) (x : ℝ) (hg : OnGrid Q x) :
    (appendixGridIndex Q x : ℝ) = (Q : ℝ) * x := by
  obtain ⟨k, hk⟩ := hg
  rw [appendixGridIndex, hk, Int.floor_intCast]

private theorem gridProduct_cast {I : Type*} [Fintype I]
    (Q : ℕ) (a : I → ℝ) (b : I → ℤ) (hg : ∀ i, OnGrid Q (a i)) :
    ((∑ i, appendixGridIndex Q (a i) * b i : ℤ) : ℝ) = (Q : ℝ) * ∑ i, a i * (b i : ℝ) := by
  rw [Int.cast_sum, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  rw [Int.cast_mul, gridIndex_cast Q (a i) (hg i), mul_assoc]

private def sparseIntegerColumn (ends : Fin m → V × V) (Q : ℕ) (p D : ℝ)
    (u : V ⊕ V ⊕ Fin m → ℤ) : Fin m ⊕ Fin m → ℤ :=
  let pI := appendixGridIndex Q p
  let dI := appendixGridIndex Q D
  let atVertex := scanIntegerIncidences ends (fun e => u (.inr (.inr e)))
  fun column => match column with
  | .inl e => pI * (u (.inr (.inl (ends e).1)) + u (.inr (.inl (ends e).2))) +
      (Q : ℤ) * u (.inr (.inr e))
  | .inr e => (Q : ℤ) * (u (.inl (ends e).1) + u (.inl (ends e).2)) +
      dI * (u (.inr (.inl (ends e).1)) + u (.inr (.inl (ends e).2)) +
        atVertex (ends e).1 + atVertex (ends e).2)

private theorem sparseIntegerColumn_eq (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (Q : ℕ) (p D : ℝ)
    (hp : OnGrid Q p) (hD : OnGrid Q D) (u : V ⊕ V ⊕ Fin m → ℤ) (i : Fin m ⊕ Fin m) :
    sparseIntegerColumn ends Q p D u i = ∑ h, appendixGridIndex Q (matrix p D ends ends h i) * u h := by
  apply (Int.cast_injective (α := ℝ))
  rw [gridProduct_cast Q _ u (fun h => matrix_grid p D ends ends Q hp hD h i)]
  change _ = (Q : ℝ) * column (matrix p D ends ends) (fun h => (u h : ℝ)) i
  rcases i with e | e
  · rw [sparse_column_x p D ends ends _ e (hloop e)]
    simp only [sparseIntegerColumn, Int.cast_add, Int.cast_mul, Int.cast_natCast, gridIndex_cast Q p hp]
    ring
  · rw [sparse_column_y p D ends ends _ e hloop (hloop e)]
    simp only [sparseIntegerColumn, Int.cast_add, Int.cast_mul, Int.cast_natCast, gridIndex_cast Q D hD,
      scanIntegerIncidences_cast ends _ hloop]
    ring

private def sparseIntegerLoad (ends : Fin m → V × V) (Q : ℕ) (p D : ℝ)
    (take : Fin m ⊕ Fin m → ℕ) : V ⊕ V ⊕ Fin m → ℤ :=
  let pI := appendixGridIndex Q p
  let dI := appendixGridIndex Q D
  let x := scanIntegerIncidences ends (fun e => (take (.inl e) : ℤ))
  let y := scanIntegerIncidences ends (fun e => (take (.inr e) : ℤ))
  fun row => match row with
  | .inl v => (Q : ℤ) * y v
  | .inr (.inl v) => pI * x v + dI * y v
  | .inr (.inr e) => (Q : ℤ) * (take (.inl e) : ℤ) + dI * (y (ends e).1 + y (ends e).2)

private theorem sparseIntegerLoad_eq (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (Q : ℕ) (p D : ℝ)
    (hp : OnGrid Q p) (hD : OnGrid Q D) (take : Fin m ⊕ Fin m → ℕ) (h : V ⊕ V ⊕ Fin m) :
    sparseIntegerLoad ends Q p D take h =
      ∑ i, appendixGridIndex Q (matrix p D ends ends h i) * (take i : ℤ) := by
  apply (Int.cast_injective (α := ℝ))
  rw [gridProduct_cast Q _ (fun i => (take i : ℤ)) (fun i => matrix_grid p D ends ends Q hp hD h i)]
  change _ = (Q : ℝ) * load (matrix p D ends ends) (fun i => ((take i : ℤ) : ℝ)) h
  rcases h with v | v | e
  · rw [load_y]
    simp only [sparseIntegerLoad, Int.cast_mul, Int.cast_natCast, scanIntegerIncidences_cast ends _ hloop]
  · rw [load_shared]
    simp only [sparseIntegerLoad, Int.cast_add, Int.cast_mul, Int.cast_natCast,
      scanIntegerIncidences_cast ends _ hloop, gridIndex_cast Q p hp, gridIndex_cast Q D hD]
    ring
  · rw [load_edge]
    simp only [sparseIntegerLoad, Int.cast_add, Int.cast_mul, Int.cast_natCast,
      scanIntegerIncidences_cast ends _ hloop, gridIndex_cast Q D hD]
    ring

private def retainDualArray (u : V ⊕ V ⊕ Fin m → ℤ) : V ⊕ V ⊕ Fin m → ℤ :=
  let index := Fintype.equivFin (V ⊕ V ⊕ Fin m)
  let array := Vector.ofFn (fun i => u (index.symm i))
  fun h => array[(index h).val]

omit [DecidableEq V] in
private theorem retainDualArray_eq (u : V ⊕ V ⊕ Fin m → ℤ) : retainDualArray u = u := by
  funext h
  simp [retainDualArray]

private abbrev CompactPackingState (m : ℕ) (V : Type*) :=
  PackingArrays (V ⊕ V ⊕ Fin m) (Fin m ⊕ Fin m)

/-- One iteration computes the transpose by an endpoint scan, then the
forward product by two scans. All numerators use the original scales. -/
def sparseIntegerPackingStep (ends : Fin m → V × V) (p D : ℝ) (c : Fin m ⊕ Fin m → ℤ)
    (Q P C R a : ℕ) (state : CompactPackingState m V) : CompactPackingState m V :=
  let column := sparseIntegerColumn ends Q p D state.dual
  let actions := retainK1OptimizerCoordinates (fun i =>
    let take := if (C : ℤ) * column i < c i * (P : ℤ) * (Q : ℤ) then (1 : ℕ) else 0
    (take, state.accumulator i + take))
  let load := sparseIntegerLoad ends Q p D (fun i => (actions i).1)
  ⟨retainDualArray (fun h => min ((P : ℤ) * R) (max 0 (state.dual h + (a : ℤ) * (load h - Q)))),
    fun i => (actions i).2⟩

theorem sparseIntegerPackingStep_eq (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (p D : ℝ) (c : Fin m ⊕ Fin m → ℤ)
    (Q P C R a : ℕ) (hp : OnGrid Q p) (hD : OnGrid Q D) (state : CompactPackingState m V) :
    sparseIntegerPackingStep ends p D c Q P C R a state =
      integerStep (fun h i => appendixGridIndex Q (matrix p D ends ends h i)) c Q P C R a state := by
  unfold sparseIntegerPackingStep integerStep
  have htake : (fun i => if (C : ℤ) * sparseIntegerColumn ends Q p D state.dual i <
      c i * (P : ℤ) * (Q : ℤ) then (1 : ℕ) else 0) =
      integerAction (fun h i => appendixGridIndex Q (matrix p D ends ends h i)) c state.dual P Q C := by
    funext i
    rw [integerAction, sparseIntegerColumn_eq ends hloop Q p D hp hD]
  have hchoice (i : Fin m ⊕ Fin m) :
      (if (C : ℤ) * sparseIntegerColumn ends Q p D state.dual i <
        c i * (P : ℤ) * (Q : ℤ) then (1 : ℕ) else 0) =
        integerAction (fun h i => appendixGridIndex Q (matrix p D ends ends h i)) c state.dual P Q C i :=
    congrFun htake i
  simp only [retainK1OptimizerCoordinates_eq, retainDualArray_eq, htake, hchoice,
    sparseIntegerLoad_eq ends hloop Q p D hp hD]

private def sparsePackingLoop (tick : CompactPackingState m V → CompactPackingState m V) :
    ℕ → CompactPackingState m V → CompactPackingState m V
  | 0, state => state
  | k + 1, state => sparsePackingLoop tick k (tick state)

omit [Fintype V] [DecidableEq V] in
private theorem sparsePackingLoop_succ (tick : CompactPackingState m V → CompactPackingState m V)
    (k : ℕ) (state : CompactPackingState m V) :
    sparsePackingLoop tick (k + 1) state = tick (sparsePackingLoop tick k state) := by
  induction k generalizing state with
  | zero => rfl
  | succ k ih =>
    rw [sparsePackingLoop, ih, ← sparsePackingLoop]

def sparseIntegerPackingRun (ends : Fin m → V × V) (p D : ℝ) (c : Fin m ⊕ Fin m → ℤ)
    (Q P C R a k : ℕ) : CompactPackingState m V :=
  sparsePackingLoop (sparseIntegerPackingStep ends p D c Q P C R a) k ⟨fun _ => 0, fun _ => 0⟩

theorem sparseIntegerPackingRun_eq (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (p D : ℝ) (c : Fin m ⊕ Fin m → ℤ)
    (Q P C R a : ℕ) (hp : OnGrid Q p) (hD : OnGrid Q D) (k : ℕ) :
    sparseIntegerPackingRun ends p D c Q P C R a k =
      integerRun (fun h i => appendixGridIndex Q (matrix p D ends ends h i)) c Q P C R a k := by
  induction k with
  | zero => rfl
  | succ k ih =>
    unfold sparseIntegerPackingRun
    rw [sparsePackingLoop_succ]
    change sparseIntegerPackingStep ends p D c Q P C R a (sparseIntegerPackingRun ends p D c Q P C R a k) = _
    rw [ih, sparseIntegerPackingStep_eq ends hloop p D c Q P C R a hp hD, integerRun]

/-- The graph optimizer uses three sparse incidence scans per packing
iteration. The total definition also permits input matrices with loops. -/
def integerPackingRunOnGraph (ends : Fin m → V × V) (p D : ℝ) (c : Fin m ⊕ Fin m → ℤ)
    (Q P C R a k : ℕ) : CompactPackingState m V :=
  if ∀ e, (ends e).1 ≠ (ends e).2 then sparseIntegerPackingRun ends p D c Q P C R a k
    else integerRun (fun h i => appendixGridIndex Q (matrix p D ends ends h i)) c Q P C R a k

theorem integerPackingRunOnGraph_eq (ends : Fin m → V × V) (p D : ℝ) (c : Fin m ⊕ Fin m → ℤ)
    (Q P C R a : ℕ) (hp : OnGrid Q p) (hD : OnGrid Q D) (k : ℕ) :
    integerPackingRunOnGraph ends p D c Q P C R a k =
      integerRun (fun h i => appendixGridIndex Q (matrix p D ends ends h i)) c Q P C R a k := by
  classical
  unfold integerPackingRunOnGraph
  split
  · rename_i hloop
    exact sparseIntegerPackingRun_eq ends hloop p D c Q P C R a hp hD k
  · rfl

end

end SubmodularMatching.UpperBoundAssembly
