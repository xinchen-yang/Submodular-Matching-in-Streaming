import SubmodularMatching.CapacityPaperResources
import SubmodularMatching.CapacityPackingReads
import SubmodularMatching.NonmonotoneLayersDecoderWork
import SubmodularMatching.ProjectedShearerTimeProgram
import SubmodularMatching.ProjectedShearerOrderCost
import SubmodularMatching.ProjectedShearerRowScores

/-! Substitute the actual retained graph, integer projection dimensions,
compact Gibbs vertices, finite time grid, and the two capped virtual layers
into the traversal counts. Repetitions and guesses are counted by the
physical outer selector. -/
namespace SubmodularMatching.Capacity
open AppendixM UpperBoundAssembly Streaming Streaming.OracleQuery LinearPacking NonmonotoneOptimizer
  NonmonotoneCandidate NonmonotoneLayers GibbsSampler Finset
noncomputable section
variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V] [DecidableEq V]

def paperTraversalWork (n : ℕ) :=
  let v := n^2
  let H := 2^37*(2*v+1)
  let K := 2^35*(n+1)^4
  let m := n^4
  let w := n+2
  let r := 2*(2*v+160*w+1)
  let pack := 1024*(5*v)^2*(2*v)^6*H^43
  pack*(2*(5*v)*(2*v)+4*(5*v+2*v+1)^2)*(v+1)^2 + v*((3*(36+(2*v+1))+1)*(2*n)) +
    2*(m*(1+2*((2*(420000*w))*m))+m*((1+4*(2*(420000*w)))*(3400000*w)))*(v+1) +
    (2*(K^2)*((r+1)*r) + 2*r*(76+5*K)*((r+2)*(r+1))) + 2*r^2+4*(r+v+1)^2 + 8*oracleReads K*(r+v+1)^3 +
    160*(v+K^2+1)^7*v

set_option maxRecDepth 5000 in
theorem paper_retained_traversals (S : SimpleEdgeStream E V) (b : V→ℕ)
    (st : SparseSlots (Admissible S b) (effectiveCapacity b))
    (hg : LayoutGuard (admissibleStream S b) (effectiveCapacity b) st)
    (r active : ℕ) :
    let n := Fintype.card V
    let R := retainedLayout (admissibleStream S b) (effectiveCapacity b) st hg
    let s := (st.machine.edges.map Prod.fst).length
    let k := paperExponent R.l
    let m := (layerSupport R.graph (effectiveCapacity b) (paperSlotRank b)).card
    let K := GridRow.scaleFor (S:=R.graph) (paperSlotRank b)
    let pack := ascentFuel k*projectionFuel k*packingIterationsNat R.m R.l ((scale k)^5)
    let vertices := (assignedSlots R.graph.arrivals (slotPair R.graph.ends _ R.left R.right)).length
    r≤2*layerSampleCap s K → active≤s →
    pack*(2*R.m*R.l+4*(R.m+R.l+1)^2)*(s+1)^2 + s*(decoderSteps k*(2*n)) +
      2*(m*(1+2*((2*rowFuelLimit m K)*m))+m*((1+4*(2*rowFuelLimit m K))*rowAttemptsLimit m K))*(s+1) +
      (2*layerTapeLength K*((r+1)*r) + 2*r*(76+5*Nat.clog 2 K)*((r+2)*(r+1))) + 2*r^2+4*(r+s+1)^2 + 8*oracleReads K*(r+s+1)^3 +
      lowActivitySteps vertices active (lowActivityPrecision (trialGibbsDivisor K))*active ≤ paperTraversalWork n := by
  intro n R s k m K pack vertices hr ha
  let v := n^2
  let H := 2^37*(2*v+1)
  let D := 2^35*(n+1)^4
  let w := n+2
  have hclog (x : ℕ) : Nat.clog 2 x≤x := Nat.clog_le_of_le_pow (Nat.lt_two_pow_self (n:=x)).le
  have hww : Nat.clog 2 (n+1)+1≤w := Nat.succ_le_succ (hclog _)
  have sz := retainedLayout_dimensions (admissibleStream S b) _ st hg
  have hl : R.l=2*s := sz.1
  have hmR : R.m≤5*s := sz.2
  have hsEq : Fintype.card (↑(st.machine.edges.map Prod.fst).toFinset)=s := by
    simp only [Fintype.card_coe,List.toFinset_card_of_nodup R.nodup,s]
  have hs : s≤v := hsEq ▸ physical_ground_size R.graph
  have geo := GridRow.physical_graph_precision R.graph (effectiveCapacity b) (paperSlotRank b) n le_rfl (effectiveCapacity_le b)
  have hm : m≤n^4 := geo.1
  have hK : K≤D := geo.2.1
  have he : physicalLayerExponent K≤160*w := geo.2.2.2.1.trans (Nat.mul_le_mul_left _ hww)
  have hF : rowFuelLimit m K ≤ 420000*w := geo.2.2.2.2.1.trans (Nat.mul_le_mul_left _ hww)
  have hA : rowAttemptsLimit m K ≤ 3400000*w := geo.2.2.2.2.2.trans (Nat.mul_le_mul_left _ hww)
  have hcap := physicalLayerExponent_cap s K
  let rmax := 2*(2*v+160*w+1)
  have hR : r≤rmax := by dsimp only [rmax]; omega
  have hpack : pack≤1024*(5*v)^2*(2*v)^6*H^43 := (paper_retained_work S b st hg 1).2.2.1
  have hlen : R.graph.arrivals.length=s := by
    simpa only [s,R,RetainedRuntime.graph,List.length_map] using congrArg List.length (retainedGraph_labels (admissibleStream S b)
      (st.machine.edges.map Prod.fst) hg.nodup)
  have hvtx : vertices ≤ 2*s := (assignedSlots_size _ _).trans_eq (congrArg (2*·) hlen)
  have hG := (signed_walk_budget vertices s active (trialGibbsDivisor K) hvtx ha).1
  have hk : k ≤ 36+(2*v+1) := by
    have := hclog (R.l+1)
    dsimp only [k,paperExponent]
    omega
  have ht : layerTapeLength K≤D^2 := (hclog (K^2)).trans (Nat.pow_le_pow_left hK _)
  have htime := Nat.mul_le_mul (Nat.mul_le_mul_left 2 ht) (Nat.mul_le_mul (Nat.succ_le_succ hR) hR)
  have hmark : 2*r*(76+5*Nat.clog 2 K)*((r+2)*(r+1)) ≤ 2*rmax*(76+5*D)*((rmax+2)*(rmax+1)) :=
    Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul_left 2 hR) (Nat.add_le_add_left
      (Nat.mul_le_mul_left 5 ((hclog K).trans hK)) 76)) (Nat.mul_le_mul (Nat.add_le_add_right hR 2) (Nat.succ_le_succ hR))
  have hbuf : r+s+1 ≤ rmax+v+1 := Nat.succ_le_succ (Nat.add_le_add hR hs)
  have hscore := Nat.mul_le_mul (Nat.mul_le_mul_left 8 (Nat.mul_le_mul_left 512 (Nat.pow_le_pow_left hK 9)))
    (Nat.pow_le_pow_left hbuf 3)
  have hrows := hmR.trans (Nat.mul_le_mul_left _ hs)
  have hcols := hl.le.trans (Nat.mul_le_mul_left _ hs)
  have htable := Nat.add_le_add (Nat.mul_le_mul (Nat.mul_le_mul_left 2 hrows) hcols)
    (Nat.mul_le_mul_left 4 (Nat.pow_le_pow_left (Nat.succ_le_succ (Nat.add_le_add hrows hcols)) 2))
  have hpacking := Nat.mul_le_mul (Nat.mul_le_mul hpack htable) (Nat.pow_le_pow_left (Nat.succ_le_succ hs) 2)
  have hquery := Nat.mul_le_mul_left 4 (Nat.pow_le_pow_left hbuf 2)
  change _ ≤ _+_+_+_+_+_+_+_
  apply Nat.add_le_add
  · apply Nat.add_le_add
    · apply Nat.add_le_add
      · apply Nat.add_le_add
        · apply Nat.add_le_add
          · apply Nat.add_le_add
            · apply Nat.add_le_add
              · exact hpacking
              · exact Nat.mul_le_mul hs (Nat.mul_le_mul_right _ (Nat.succ_le_succ (Nat.mul_le_mul_left 3 hk)))
            · apply Nat.mul_le_mul _ (Nat.succ_le_succ hs)
              apply Nat.mul_le_mul_left 2
              apply Nat.add_le_add
              · gcongr
              · gcongr
          · exact Nat.add_le_add htime hmark
        · exact Nat.mul_le_mul_left 2 (Nat.pow_le_pow_left hR 2)
      · exact hquery
    · exact hscore
  · apply Nat.mul_le_mul _ (ha.trans hs)
    apply hG.trans
    change 160*(s+K^2+1)^7 ≤ 160*(v+D^2+1)^7
    exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (Nat.succ_le_succ (Nat.add_le_add hs (Nat.pow_le_pow_left hK 2))) 7)

theorem paper_bank_traversal_work (S : SimpleEdgeStream E V) (b : V→ℕ) (f : Finset E→ℝ)
    (c : ℝ) (amp : Bool) (edges : ℕ→Admissible S b)
    (draw : ℕ→ℕ→ℕ→ℕ→ℕ) (k : ℕ) (hk : k≤(Fintype.card V)^2)
    (inc : Option (Admissible S b)×ℝ) (sourceVisits : ℕ) :
    let n := Fintype.card V
    let v := n^2
    let δ := confidenceTarget n c
    let J := sourceFailureBudget δ
    let K := sourceWordScale v (v^2)
    let g := fun x => f (originalLabels S b x)
    let hpos := fun e : Admissible S b => And.intro
      (effectiveCapacity_pos b ((admissibleStream S b).ends e).1)
      (effectiveCapacity_pos b ((admissibleStream S b).ends e).2)
    let bank := RealOracle.countedBank (admissibleStream S b).ends (effectiveCapacity b) hpos v
      (batchCount K J) (batchBits K) g edges draw k
    let outer := countedAfterSignedPass g δ amp (paperRounding S b f) (bank.1,inc)
    let R := max 1 (⌈1/trialSuccess⌉₊*(Nat.clog 2 (max 1 n)*⌈c⌉₊+1))
    let G := signedGuessCountConstant*(v+2)
    ∀ z∈outer.outcomes, sourceVisits + z.2.trials*paperTraversalWork n + 2*z.2.comparisons ≤
      sourceVisits+(R*G)*paperTraversalWork n+2*(R*(G+1)) := by
  intro n v δ J K g hpos bank outer R G z hz
  have exactCost := countedAfterSignedPass_work g δ amp (paperRounding S b f) (bank.1,inc) z hz
  have P := RealOracle.forward_queries_polynomial (admissibleStream S b).ends _ hpos n J k hk g edges draw
  have hg : bank.1.states.length ≤ G := by
    change (RealOracle.countedBank _ _ _ _ _ _ _ _ _ _).1.states.length ≤ _
    rw [P.1]
    exact (RealOracle.GuessBank.state_count _ _ _ _ _ _).trans ((signedGuessCount_le v).trans
      (Nat.mul_le_mul_left _ (Nat.succ_le_succ (Nat.log2_le_self _))))
  have hR : (if amp then postprocessCount δ else 1)≤R := by
    split <;> first | exact (postprocessCount_logarithmic n c).trans (le_max_right ..) | exact le_max_left .. 
  have hT := exactCost.1.trans (Nat.mul_le_mul hR hg)
  have hC := exactCost.2.trans (Nat.mul_le_mul hR (Nat.succ_le_succ hg))
  exact Nat.add_le_add (Nat.add_le_add_left (Nat.mul_le_mul_right _ hT) sourceVisits) (Nat.mul_le_mul_left _ hC)

end
end SubmodularMatching.Capacity
