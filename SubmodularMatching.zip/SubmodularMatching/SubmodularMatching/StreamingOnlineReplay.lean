import SubmodularMatching.StreamingOnlineProgramView
import SubmodularMatching.StreamingSchedulerCharge
import SubmodularMatching.StreamingOnlineLawBridge

/-!
# Reading the source tape through the online state

The raw transcript need not be stored to generate the next samples.
Its previously recorded weights determine precisely the current online
instance. The next oracle samples therefore use that instance's edge list.
-/

namespace SubmodularMatching.Streaming

noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- The index mentioned by a call in the full reference tape. Its scale
and place in the stream are independent of later calls. -/
def ScheduledSource.tapeIndex (P : ScheduledSource E V) {N : ℕ}
    (batches : ℕ → Fin N → ℝ) (arrival guess : ℕ) : ℕ :=
  sourceWeightIndex N (sourceIndex (P.config (P.tau (arrival, guess))).gap
    (P.history batches P.calls.length (arrival, guess)))

omit [DecidableEq E] in
/-- Replacing an index tape outside the prefix cannot affect the online
sparse state. -/
theorem runOnlineInstance_prefix_congr (R : GridUpdateParameters) (ends : E → V × V)
    (input other : ℕ → E × ℕ) (n : ℕ) (h : ∀ i < n, input i = other i) :
    runOnlineInstance R ends input n = runOnlineInstance R ends other n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [runOnlineInstance, runOnlineInstance, ih (fun i hi => h i (Nat.lt_succ_of_lt hi)),
      h n (Nat.lt_succ_self n)]

/-- The executable archive before sample generation agrees with the
reference prefix's frozen edge order and integer potential representation. -/
theorem ScheduledSource.online_prefix_represents
    (P : ScheduledSource E V) (R : GridUpdateParameters) (W : ℚ)
    (oracle : Finset E → ℚ) (hobj : P.objective = fun A => (oracle A : ℝ))
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ P.span) (hwidth : (W : ℝ) = P.width)
    (hR : ∀ tau > 0, R.Matches (P.config tau))
    {N : ℕ} (batches : ℕ → Fin N → ℝ) {t : ℕ} (ht : t < P.calls.length) :
    let call := P.call t
    let ctx := P.context t (P.history batches t)
    let prior := runOnlineIndexed R P.ends W P.span (fun i => oracle {P.edges i}) P.edges
      (P.tapeIndex batches) call.1
    let st := prior.initialize (prior.epoch.resets W (oracle {P.edges call.1})) call.2
    st.Represents ctx.config (runPotential ctx.config ctx.ends ctx.input ctx.index) ∧
      st.edges.map Prod.fst = ctx.ordered := by
  dsimp only
  let call := P.call t
  let birth := P.birth call
  let tau := P.tau call
  let ctx := P.context t (P.history batches t)
  let C := P.config tau
  let value := fun i => oracle {P.edges i}
  let prior := runOnlineIndexed R P.ends W P.span value P.edges (P.tapeIndex batches) call.1
  have hv : (fun i => (value i : ℝ)) = P.value := by
    funext i
    change (oracle {P.edges i} : ℝ) = P.objective {P.edges i}
    rw [hobj]
  have hprepared := runOnlineIndexed_next_input R P.ends W P.span value P.edges
    (P.tapeIndex batches) hW hspan call.1 call.2
  dsimp only at hprepared
  rw [hwidth, hv] at hprepared
  change prior.initialize (prior.epoch.resets W (value call.1)) call.2 =
    replayGuess R P.ends P.edges (P.tapeIndex batches) call.2 birth call.1 at hprepared
  change (prior.initialize (prior.epoch.resets W (value call.1)) call.2).Represents C
      (runPotential C P.ends ctx.input ctx.index) ∧
    (prior.initialize (prior.epoch.resets W (value call.1)) call.2).edges.map Prod.fst = ctx.ordered
  rw [hprepared]
  let realIndex := fun i => (P.edges (birth + i), sourceWeightIndex N
    (sourceIndex C.gap (P.history batches t (birth + i, call.2))))
  have hprefix : replayGuess R P.ends P.edges (P.tapeIndex batches) call.2 birth call.1 =
      runOnlineInstance R P.ends realIndex (call.1 - birth) := by
    unfold replayGuess
    apply runOnlineInstance_prefix_congr
    intro i hi
    obtain ⟨u, hu, hcall, -, hscale⟩ := P.prefix_has_prior_call ht hi
    unfold ScheduledSource.tapeIndex
    dsimp only [realIndex]
    rw [← hcall, hscale, P.history_at_completed batches (hu.trans ht) le_rfl,
      P.history_at_completed batches hu ht.le]
  rw [hprefix]
  have ha := P.call_active ht
  have htau : 0 < tau := ha.2.1.trans_le ha.2.2.1
  have hd : 0 < C.gap := by
    change 0 < (P.config tau).gap
    rw [P.config_gap tau htau, P.config_tau tau htau]
    have hn : (0 : ℝ) < P.vertices := by exact_mod_cast P.vertices_pos
    exact div_pos (mul_pos P.epsilon_pos htau) (pow_pos hn 2)
  have hh := runOnlineInstance_represents R C (hR tau htau) hd P.ends realIndex (call.1 - birth)
  dsimp only at hh
  have heq : (fun i => ((realIndex i).1, C.gap * (realIndex i).2)) = ctx.input := by
    funext i
    change (P.edges (birth + i), C.gap * (sourceWeightIndex N
      (sourceIndex C.gap (P.history batches t (birth + i, call.2))) : ℝ)) =
      (P.edges (birth + i), sourceWeight C.gap (P.history batches t (birth + i, call.2)))
    rw [sourceWeight_eq_index]
  rw [heq] at hh
  exact hh


/-- Every surviving executable guess has exactly the final reference
trace and archive when replaying the reference tape's sample indices. -/
theorem ScheduledSource.online_final_represents
    (P : ScheduledSource E V) (R : GridUpdateParameters) (W : ℚ)
    (oracle : Finset E → ℚ) (hobj : P.objective = fun A => (oracle A : ℝ))
    (hW : 1 ≤ W) (hspan : W ≤ 2 ^ P.span) (hwidth : (W : ℝ) = P.width)
    (hR : ∀ tau > 0, R.Matches (P.config tau))
    {N : ℕ} (batches : ℕ → Fin N → ℝ) (j : ℕ)
    (ha : guessActive P.width (guessAnchor P.width P.value P.arrivals)
      (singletonMaximum P.value P.arrivals) j) :
    let birth := guessBirth P.width P.value j P.arrivals
    let tau := guessAnchor P.width P.value P.arrivals * 2 ^ j
    let C := P.config tau
    let input := sampledInput C.gap (fun r => P.edges (birth + r))
      (fun r => P.history batches P.calls.length (birth + r, j))
    let old := runOnlineIndexed R P.ends W P.span (fun i => oracle {P.edges i}) P.edges
      (P.tapeIndex batches) P.arrivals
    ∃ st, old.instanceAt j = some st ∧
      st.Represents C (runPotential C P.ends input (P.arrivals - birth)) ∧
      st.edges.map Prod.fst = acceptedOrder C P.ends input (P.arrivals - birth) := by
  dsimp only
  let birth := guessBirth P.width P.value j P.arrivals
  let tau := guessAnchor P.width P.value P.arrivals * 2 ^ j
  let C := P.config tau
  let value := fun i => oracle {P.edges i}
  have hv : (fun i => (value i : ℝ)) = P.value := by
    funext i
    change (oracle {P.edges i} : ℝ) = P.objective {P.edges i}
    rw [hobj]
  let st := replayGuess R P.ends P.edges (P.tapeIndex batches) j birth P.arrivals
  refine ⟨st, ?_, ?_⟩
  · have hh := runOnlineIndexed_instanceAt R P.ends W P.span value P.edges
      (P.tapeIndex batches) hW hspan P.arrivals j
    rw [hwidth, hv, expectedIndexView, if_pos ha] at hh
    exact hh
  let indexed := fun i => (P.edges (birth + i), sourceWeightIndex N
    (sourceIndex C.gap (P.history batches P.calls.length (birth + i, j))))
  have hprefix : st = runOnlineInstance R P.ends indexed (P.arrivals - birth) := by
    unfold st replayGuess
    apply runOnlineInstance_prefix_congr
    intro i hi
    obtain ⟨t, -, hc, -, hs⟩ := P.final_suffix_call j i ha hi
    unfold ScheduledSource.tapeIndex
    dsimp only [indexed]
    rw [← hc, hs]
  rw [hprefix]
  have htau : 0 < tau := ha.1.trans_le ha.2.1
  have hd : 0 < C.gap := by
    change 0 < (P.config tau).gap
    rw [P.config_gap tau htau, P.config_tau tau htau]
    exact div_pos (mul_pos P.epsilon_pos htau) (pow_pos (by exact_mod_cast P.vertices_pos) 2)
  have hh := runOnlineInstance_represents R C (hR tau htau) hd P.ends indexed (P.arrivals - birth)
  dsimp only at hh
  let input := sampledInput C.gap (fun r => P.edges (birth + r))
    (fun r => P.history batches P.calls.length (birth + r, j))
  have hinput : (fun i => ((indexed i).1, C.gap * (indexed i).2)) = input := by
    funext i
    change (P.edges (birth + i), C.gap * (sourceWeightIndex N
      (sourceIndex C.gap (P.history batches P.calls.length (birth + i, j))) : ℝ)) =
      (P.edges (birth + i), sourceWeight C.gap (P.history batches P.calls.length (birth + i, j)))
    rw [sourceWeight_eq_index]
  rw [hinput] at hh
  exact hh

end

end SubmodularMatching.Streaming
