import SubmodularMatching.ProjectedShearerTimeLimbs

/-! Bounded time-word rejection and fallback using one sequence of small limbs. -/
namespace SubmodularMatching.Shearer
open ShearerSampler
variable {E : Type*} [LinearOrder E]

private theorem value_zero {B : ℕ} (hb : 0<B) (ds : List ℕ) :
    limbValue B ds = 0 ↔ ∀ x∈ds,x=0 := by
  induction ds with
  | nil => simp [limbValue]
  | cons x xs ih => simp [limbValue,Nat.add_eq_zero,Nat.mul_eq_zero,hb.ne',ih]

/-- A padded word is below k^r exactly when its quotient vanishes after r
small divisions. A rejected block releases its digits before the next one. -/
def limbAttempt (B k : ℕ) : ℕ → List ℕ → List ℕ → Option (List ℕ)
  | 0,ds,rev => if ds.all (·==0) then some rev.reverse else none
  | n+1,ds,rev =>
    let z := divideLimbs B k ds
    limbAttempt B k n z.1 (z.2::rev)

theorem limbAttempt_spec {B k : ℕ} (hb : 0<B) (hk : 0<k) (n : ℕ) (ds rev : List ℕ) (hd : ∀ x∈ds,x<B) :
    limbAttempt B k n ds rev = if limbValue B ds < k^n then
      some (rev.reverse ++ List.ofFn (fun i : Fin n => limbValue B ds/k^(i:ℕ)%k)) else none := by
  induction n generalizing ds rev with
  | zero => simp [limbAttempt,Nat.lt_one_iff,value_zero hb]
  | succ n ih =>
    let z := divideLimbs B k ds
    have ok := divideLimbs_spec B k hk ds hd
    have dc : limbValue B z.1=limbValue B ds/k ∧ z.2=limbValue B ds%k := by
      obtain ⟨_,_,hr,he⟩ := ok
      change z.2<k at hr
      change limbValue B z.1*k+z.2=limbValue B ds at he
      rw [←he,Nat.mul_comm (limbValue B z.1) k]
      simp [Nat.mul_add_div hk,Nat.mul_add_mod,Nat.mod_eq_of_lt hr,Nat.div_eq_of_lt hr]
    change limbAttempt B k n z.1 (z.2::rev) = _
    rw [ih z.1 _ ok.2.1]
    change limbValue B z.1=limbValue B ds/k ∧ z.2=limbValue B ds%k at dc
    simp only [dc.1,dc.2,Nat.div_lt_iff_lt_mul hk,pow_succ]
    split_ifs
    · simp only [Option.some.injEq,List.reverse_cons,List.append_assoc,List.singleton_append,List.ofFn_succ,
        Fin.val_zero,pow_zero,Nat.div_one]
      congr 2
      apply congrArg List.ofFn
      funext i
      rw [Fin.val_succ,pow_succ',Nat.div_div_eq_div_mul]
    · rfl

/-- An accepted block yields its digit vector; exhaustion uses the all-zero
vector just as the finite uniform rejection primitive does. -/
def limbRejections {B k : ℕ} (n : ℕ) : (t : ℕ) → (Fin t → List ℕ) → List ℕ
  | 0,_ => List.replicate n 0
  | t+1,blocks =>
    match limbAttempt B k n (blocks 0) [] with
    | some out => out
    | none => @limbRejections B k n t (Fin.tail blocks)

theorem limbRejections_matches (M : Finset E) (k : ℕ) (hk : 0<k) (t : ℕ)
    (words : Fin t → Fin (2^(timeGrid M k hk).bits)) (B : ℕ) (hb : 0<B)
    (blocks : Fin t → List ℕ) (hblock : ∀ j,limbValue B (blocks j) = (words j).val)
    (hbound : ∀ j x, x∈blocks j → x<B) :
    let pick := ((timeGrid M k hk).wordDraw t words).getD ⟨0,pow_pos hk _⟩
    @limbRejections B k M.card t blocks =
      List.ofFn (fun i : Fin M.card => (timeCodec M k pick ((M.orderIsoOfFin rfl) i)).val) := by
  induction t with
  | zero => simp [limbRejections,timeCodec,ChoiceGrid.wordDraw]
  | succ t ih =>
    rw [limbRejections,limbAttempt_spec hb hk _ _ _ (hbound 0),hblock]
    simp only [List.reverse_nil,List.nil_append]
    change _ = List.ofFn (fun i : Fin M.card => (timeCodec M k
      ((boundedWordDraw (k^M.card) (2^(timeGrid M k hk).bits) (t+1) words).getD _) ((M.orderIsoOfFin rfl) i)).val)
    rw [boundedWordDraw_succ]
    split_ifs with ha
    · simp [timeCodec]
    · exact ih (Fin.tail words) (Fin.tail blocks) (fun j => hblock j.succ) (fun j => hbound j.succ)

end SubmodularMatching.Shearer
