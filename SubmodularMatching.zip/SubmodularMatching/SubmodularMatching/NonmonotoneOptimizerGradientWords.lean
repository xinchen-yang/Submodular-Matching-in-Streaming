import SubmodularMatching.NonmonotoneActionScoreOutput
import Mathlib.Data.Rat.Lemmas

/-! Canonical rational denominator bounds for every physical stochastic gradient,
including transcripts on which one or more sampled estimates are inaccurate. -/

namespace SubmodularMatching.NonmonotoneOptimizer
open Streaming

theorem fraction_den_bound (a : ℤ) (b : ℕ) (hb : 0 < b) :
    ((a:ℚ)/(b:ℚ)).den ≤ b := by
  have hh := Rat.den_dvd a (b:ℤ)
  rw [Rat.divInt_eq_div,Int.cast_natCast] at hh
  exact Nat.le_of_dvd hb (Int.natCast_dvd_natCast.mp hh)

theorem rat_mul_den (a b : ℚ) : (a*b).den ≤ a.den*b.den :=
  Nat.le_of_dvd (Nat.mul_pos a.den_pos b.den_pos) (Rat.mul_den_dvd a b)

theorem rat_add_den (a b : ℚ) : (a+b).den ≤ a.den*b.den :=
  Nat.le_of_dvd (Nat.mul_pos a.den_pos b.den_pos) (Rat.add_den_dvd a b)

theorem clip_den (P : ℕ) (v : ℚ) : (clipAnswer P v).den ≤ v.den := by
  unfold clipAnswer
  rcases max_choice (-(P:ℚ)) (min P v) with e|e
  · rw [e]; simpa using v.den_pos
  · rw [e]; rcases min_choice (P:ℚ) v with e|e
    · rw [e]; simpa using v.den_pos
    · rw [e]

theorem snapped_den_bound (N s : ℕ) (hs : 0 < s) (samples : Fin s → ℝ) :
    (snappedRat (queryTolerance N) samples).den ≤ (paperScale N)^2*(4*s) := by
  let P := paperScale N
  have hp : 0 < P := (by decide : 0 < 2^36).trans_le (paperScale_bounds N).1
  have hh : snappedRat (queryTolerance N) samples =
      ((sourceIndex (queryTolerance N) samples:ℤ):ℚ)/((P^2*(4*s):ℕ):ℚ) := by
    simp only [snappedRat,queryTolerance, Nat.cast_mul,Nat.cast_pow,Nat.cast_ofNat,P]
    ring
  rw [hh]
  exact fraction_den_bound _ _ (by positivity)

variable {E : Type*} [DecidableEq E] {m n N s bits : ℕ}
namespace BlockData
variable (B : BlockData E n N)

theorem paper_answer_den [NeZero n] (h : ℕ → E) (p : ℕ → ℝ) (F : Finset E → ℝ) (τ : ℝ)
    (hp : ∀ j < m, 0 ≤ p j ∧ p j ≤ 1) (W : OptimizerWords m n N s bits)
    (hs : 0 < s) (t : ℕ) (r : Vec N) (i : Fin n) :
    let A := B.paperAnswers h p m F τ hp W
    (A.lower t r i).den ≤ (paperScale N)^2*(4*s) ∧
      (A.upper t r i).den ≤ (paperScale N)^2*(4*s) :=
  ⟨(clip_den _ _).trans (snapped_den_bound N s hs _),
   (clip_den _ _).trans (snapped_den_bound N s hs _)⟩

theorem actRat_den (r : Vec N) (T : ℕ) (hT : 0<T)
    (hr : ∀ j, ∃ z : ℕ, z ≤ T ∧ atRat r j = (z:ℚ)/T)
    (hc : B.c = 40/13) (i : Fin n) :
    (B.actRat r i).den ≤ 53*T := by
  obtain ⟨z,hz,eq⟩ := hr (B.columns (.inr (B.order r i)))
  have hv : B.orderedCoord r i = (z:ℚ)/T := eq
  have hq : (T:ℚ) ≠ 0 := by positivity
  have hs : (40*(T:ℚ)+13*z) ≠ 0 := by positivity
  have hrep : B.actRat r i = (((13*z:ℕ):ℤ):ℚ)/((40*T+13*z:ℕ):ℚ) := by
    unfold actRat; rw [hc,hv]
    push_cast
    field_simp
  rw [hrep]
  exact (fraction_den_bound _ _ (by positivity)).trans (by omega)

theorem observed_den (A : ChainEstimates n N) (t : ℕ) (r : Vec N) (T D : ℕ)
    (hT : 0<T) (hr : ∀ j, ∃ z : ℕ, z ≤ T ∧ atRat r j = (z:ℚ)/T)
    (hc : B.c = 40/13) (i : Fin n)
    (ha : (A.lower t r i).den ≤ D ∧ (A.upper t r i).den ≤ D) :
    (B.observed A t r i).den ≤ (53*T*D)^2 := by
  have hact := B.actRat_den r T hT hr hc i
  have hleft : (1-B.actRat r i).den ≤ 53*T := by
    have dd := Rat.sub_den_dvd (1:ℚ) (B.actRat r i)
    simpa using (Nat.le_of_dvd (by simp [(B.actRat r i).den_pos]) dd).trans (by simpa using hact)
  exact (rat_add_den _ _).trans ((Nat.mul_le_mul
    ((rat_mul_den _ _).trans (Nat.mul_le_mul hleft ha.1))
    ((rat_mul_den _ _).trans (Nat.mul_le_mul hact ha.2))).trans_eq (sq _).symm)

theorem gradient_den [NeZero n] (h : ℕ → E) (p : ℕ → ℝ) (F : Finset E → ℝ) (τ : ℝ)
    (hp : ∀ j < m, 0 ≤ p j ∧ p j ≤ 1) (W : OptimizerWords m n N s bits)
    (hs : 0 < s) (t : ℕ) (r : Vec N) (T H : ℕ) (hT : 0<T)
    (hr : ∀ j, ∃ z : ℕ, z ≤ T ∧ atRat r j = (z:ℚ)/T)
    (hc : B.c = 40/13) (hw : ∀ i, (B.frozen i).den ≤ H) (j : Fin N) :
    (atRat (B.gradient (B.paperAnswers h p m F τ hp W) t r) j).den ≤
      max H (B.β.den*(53*T*((paperScale N)^2*(4*s)))^2) := by
  simp only [gradient,atRat,Vector.getElem_ofFn]
  cases eq : (B.layout r).symm j with
  | inl i => exact (hw i).trans (le_max_left ..)
  | inr i => exact ((rat_mul_den _ _).trans (Nat.mul_le_mul_left _ <|
      B.observed_den _ t r T _ hT hr hc i (B.paper_answer_den h p F τ hp W hs t r i))).trans (le_max_right ..)

end BlockData
end SubmodularMatching.NonmonotoneOptimizer
