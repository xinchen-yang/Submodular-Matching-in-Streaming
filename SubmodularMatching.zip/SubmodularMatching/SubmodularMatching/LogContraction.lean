import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

/-!
# Logarithmic contraction of the Gibbs calibration map

This proves the finite-row analytic contraction used in (GM9). Geometric
interpolation stays in `(0,1]`, so the logarithmic derivative has row norm
at most `R/(1+R)` throughout the path. No contraction premise is assumed.
-/

open scoped BigOperators

namespace SubmodularMatching.LogContraction

noncomputable section

def geometric (a b t : ℝ) : ℝ := Real.exp ((1 - t) * Real.log a + t * Real.log b)

theorem geometric_zero (a b : ℝ) (ha : 0 < a) : geometric a b 0 = a := by
  simp [geometric, Real.exp_log ha]

theorem geometric_one (a b : ℝ) (hb : 0 < b) : geometric a b 1 = b := by
  simp [geometric, Real.exp_log hb]

theorem geometric_bounds (a b t : ℝ) (ha : 0 < a ∧ a ≤ 1) (hb : 0 < b ∧ b ≤ 1)
    (ht : t ∈ Set.Icc 0 1) : 0 < geometric a b t ∧ geometric a b t ≤ 1 := by
  refine ⟨Real.exp_pos _, ?_⟩
  apply Real.exp_le_one_iff.mpr
  have hla := Real.log_nonpos ha.1.le ha.2
  have hlb := Real.log_nonpos hb.1.le hb.2
  exact add_nonpos (mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr ht.2) hla)
    (mul_nonpos_of_nonneg_of_nonpos ht.1 hlb)

theorem geometric_hasDerivAt (a b t : ℝ) :
    HasDerivAt (geometric a b) (geometric a b t * (Real.log b - Real.log a)) t := by
  have hlin := (((hasDerivAt_const t 1).sub (hasDerivAt_id t)).mul_const (Real.log a)).add
    ((hasDerivAt_id t).mul_const (Real.log b))
  have h := hlin.exp
  convert h using 1
  simp only [geometric, Pi.add_apply, Pi.sub_apply, id_eq]
  ring

variable {V : Type*} [Fintype V]

def weighted (w a b : V → ℝ) (t : ℝ) : ℝ := ∑ i, w i * geometric (a i) (b i) t

def weightedDerivative (w a b : V → ℝ) (t : ℝ) : ℝ :=
  ∑ i, w i * (geometric (a i) (b i) t * (Real.log (b i) - Real.log (a i)))

theorem weighted_bounds (w a b : V → ℝ) (R t : ℝ) (hw : ∀ i, 0 ≤ w i)
    (hrow : ∑ i, w i ≤ R) (ha : ∀ i, 0 < a i ∧ a i ≤ 1)
    (hb : ∀ i, 0 < b i ∧ b i ≤ 1) (ht : t ∈ Set.Icc 0 1) :
    0 ≤ weighted w a b t ∧ weighted w a b t ≤ R := by
  constructor
  · exact Finset.sum_nonneg fun i _ =>
      mul_nonneg (hw i) (geometric_bounds _ _ _ (ha i) (hb i) ht).1.le
  · apply le_trans _ hrow
    apply Finset.sum_le_sum
    intro i _
    exact mul_le_of_le_one_right (hw i) (geometric_bounds _ _ _ (ha i) (hb i) ht).2

theorem weighted_hasDerivAt (w a b : V → ℝ) (t : ℝ) :
    HasDerivAt (weighted w a b) (weightedDerivative w a b t) t := by
  exact HasDerivAt.fun_sum fun i _ => (geometric_hasDerivAt (a i) (b i) t).const_mul (w i)

theorem weighted_derivative_bound (w a b : V → ℝ) (d t : ℝ)
    (hw : ∀ i, 0 ≤ w i) (hd : ∀ i, |Real.log (a i) - Real.log (b i)| ≤ d) :
    |weightedDerivative w a b t| ≤ weighted w a b t * d := by
  calc
    _ ≤ ∑ i, |w i * (geometric (a i) (b i) t * (Real.log (b i) - Real.log (a i)))| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i, w i * geometric (a i) (b i) t * d := by
      apply Finset.sum_le_sum
      intro i _
      have hgeom : 0 < geometric (a i) (b i) t := Real.exp_pos _
      rw [abs_mul, abs_mul, abs_of_nonneg (hw i),
        abs_of_pos hgeom, abs_sub_comm]
      have hm := mul_le_mul_of_nonneg_left (hd i)
        (mul_nonneg (hw i) hgeom.le)
      simpa only [mul_assoc] using hm
    _ = _ := by rw [weighted, Finset.sum_mul]

/-- A row of the Gibbs fixed-point map contracts logarithmic distance by
`R/(1+R)` on positive vectors bounded by one. -/
theorem log_sum_contraction (w a b : V → ℝ) (R d : ℝ)
    (hw : ∀ i, 0 ≤ w i) (hrow : ∑ i, w i ≤ R)
    (ha : ∀ i, 0 < a i ∧ a i ≤ 1) (hb : ∀ i, 0 < b i ∧ b i ≤ 1)
    (hd0 : 0 ≤ d) (hd : ∀ i, |Real.log (a i) - Real.log (b i)| ≤ d) :
    |Real.log (1 + ∑ i, w i * a i) - Real.log (1 + ∑ i, w i * b i)| ≤
      R / (1 + R) * d := by
  have hR : 0 ≤ R := (Finset.sum_nonneg fun i _ => hw i).trans hrow
  have hR1 : 0 < 1 + R := by linarith
  have hder : ∀ t ∈ Set.Icc (0 : ℝ) 1,
      HasDerivWithinAt (fun s => Real.log (1 + weighted w a b s))
        (weightedDerivative w a b t / (1 + weighted w a b t)) (Set.Icc 0 1) t := by
    intro t ht
    have hs := (weighted_bounds w a b R t hw hrow ha hb ht).1
    have hp : 0 < 1 + weighted w a b t := by linarith
    have hd' := ((hasDerivAt_const t 1).add (weighted_hasDerivAt w a b t)).log hp.ne'
    simpa only [Pi.add_apply, zero_add] using hd'.hasDerivWithinAt
  have hbound : ∀ t ∈ Set.Ico (0 : ℝ) 1,
      ‖weightedDerivative w a b t / (1 + weighted w a b t)‖ ≤ R / (1 + R) * d := by
    intro t ht
    have hs := weighted_bounds w a b R t hw hrow ha hb ⟨ht.1, ht.2.le⟩
    have hp : 0 < 1 + weighted w a b t := by linarith
    have hratio : weighted w a b t / (1 + weighted w a b t) ≤ R / (1 + R) := by
      apply (div_le_div_iff₀ hp hR1).mpr
      nlinarith [hs.2]
    calc
      _ = |weightedDerivative w a b t| / (1 + weighted w a b t) := by
        rw [Real.norm_eq_abs, abs_div, abs_of_pos hp]
      _ ≤ (weighted w a b t * d) / (1 + weighted w a b t) :=
        div_le_div_of_nonneg_right (weighted_derivative_bound w a b d t hw hd) hp.le
      _ = weighted w a b t / (1 + weighted w a b t) * d := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hratio hd0
  have hm := norm_image_sub_le_of_norm_deriv_le_segment_01' hder hbound
  have hzero : weighted w a b 0 = ∑ i, w i * a i := by
    unfold weighted
    apply Finset.sum_congr rfl
    intro i _
    rw [geometric_zero _ _ (ha i).1]
  have hone : weighted w a b 1 = ∑ i, w i * b i := by
    unfold weighted
    apply Finset.sum_congr rfl
    intro i _
    rw [geometric_one _ _ (hb i).1]
  rw [Real.norm_eq_abs, hzero, hone, abs_sub_comm] at hm
  exact hm

end

end SubmodularMatching.LogContraction
