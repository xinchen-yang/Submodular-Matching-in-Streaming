import SubmodularMatching.NonmonotoneMaskedRegisters
import SubmodularMatching.NonmonotoneSparsePairRead
import SubmodularMatching.NonmonotoneGibbsRegisterSize

/-! Construct first the compensated array and then the Gibbs activity
numerators, using one integer entry per original retained label in both. -/
namespace SubmodularMatching.NonmonotoneCandidate.GridRow
open Capacity Finset TwoLayerDiffuse Shearer GibbsMatching AppendixM NonmonotoneLayers UpperBoundAssembly
open scoped BigOperators
variable {I V : Type*} [Fintype I] [DecidableEq I] [Fintype V] [DecidableEq V]
variable {S : SimpleEdgeStream I V} {b : V→ℕ} (g : GridRow S b) {n : ℕ}

def storedAvailability (rank : Slots b ↪ ℕ) (i : I) :=
  let H := activeEndpoints S.ends
  let T := rationalTable S.ends (decodedCoordinate S b g.k g.q g.w)
  let m := pairScanGrid (scaleFor (S:=S) rank)
  sparsePairUpper H b T firstRateQ m (g.pair i).1 (g.pair i).2 *
    sparsePairUpper H b T secondRateQ m (g.pair i).1 (g.pair i).2

theorem storedAvailability_eq (rank : Slots b ↪ ℕ) (i : I) : g.storedAvailability rank i = g.rationalUpper rank i := by
  simp only [storedAvailability,sparsePairUpper_eq,rationalUpper,firstRateQ,secondRateQ]

def compensatedArray (rank : Slots b ↪ ℕ) (order : Fin n ≃ I) (x : I→ℚ) :=
  let Q := assignedGrid (scaleFor (S:=S) rank)
  Array.ofFn (fun j => floorRegister Q (x (order j)/g.storedAvailability rank (order j)))

def loadEntry (rank : Slots b ↪ ℕ) (order : Fin n ≃ I) (x : I→ℚ) (i : I) : ℕ :=
  (g.compensatedArray rank order x)[(order.symm i).val]'(by simp [compensatedArray])

theorem loadEntry_eq (rank : Slots b ↪ ℕ) (order : Fin n ≃ I) (x : I→ℚ) (i : I) :
    g.loadEntry rank order x i = floorRegister (assignedGrid (scaleFor (S:=S) rank)) (x i/g.rationalUpper rank i) := by
  simp [loadEntry,compensatedArray,storedAvailability_eq]

def markFree {C W : Type*} [DecidableEq C] [DecidableEq W] (base : C→Finset W) (A B : Finset C) (v : W) :=
  decide (v∉A.biUnion base ∧ v∉B.biUnion base)

theorem markFree_eq {C W : Type*} [DecidableEq C] [DecidableEq W] (base : C→Finset W) (A B : Finset C) (v : W) :
    (if markFree base A B v then (1:ℚ) else 0)=freeRegister base A B v := by
  unfold markFree freeRegister
  by_cases hA : v∈A.biUnion base <;> by_cases hB : v∈B.biUnion base <;> simp [hA,hB]

def alterationTable (rank : Slots b ↪ ℕ) (order : Fin n ≃ I) (x : I→ℚ) :=
  let K := scaleFor (S:=S) rank
  let active := layerSupport S b rank
  let a := g.loadEntry rank order x
  fun (z : Marked pairVertices active (firstBins K) × Marked pairVertices active (secondBins K)) =>
    Array.ofFn (fun j => alteredInteger g.pair a (assignedGrid K) (2^31)
      (markFree pairVertices (forgetMark z.1).val (forgetMark z.2).val) (order j))

theorem alterationTable_eq (rank : Slots b ↪ ℕ) (order : Fin n ≃ I) (x : I→ℚ) (hx : ∀i,(x i:ℝ)=g.x i)
    (z) (i : Fin n) :
    (g.alterationTable rank order x z)[i.val]'(by simp [alterationTable]) = g.numerator rank z (order i) := by
  let K := scaleFor (S:=S) rank
  let Q := assignedGrid K
  have hQ : 0<Q := by have hK := g.scale_pos rank; dsimp [Q,K,assignedGrid]; positivity
  have eqn := alteredInteger_correct g.pair x (g.rationalUpper rank) Q (2^31) hQ (by decide)
    (markFree pairVertices (forgetMark z.1).val (forgetMark z.2).val) (order i)
  rw [←g.rationalNumerator_eq rank x hx]
  simp only [alterationTable,Array.getElem_ofFn,Fin.eta,rationalNumerator]
  have he : (min (1 / (2:ℚ)^30) 1)/2 = (1:ℚ)/((2^31:ℕ):ℚ) := by norm_num
  rw [he,show g.loadEntry rank order x = fun j => floorRegister Q (x j/g.rationalUpper rank j) from funext (g.loadEntry_eq rank order x)]
  simpa only [K,Q,markFree_eq] using eqn

end SubmodularMatching.NonmonotoneCandidate.GridRow
