import SubmodularMatching.NonmonotoneRetainedLinearBudget
import SubmodularMatching.NonmonotoneMarkedPriority

/-! The signed objective and all residual oracle values on the retained subtype. -/
namespace SubmodularMatching.AppendixM
open Capacity Streaming NonmonotoneOptimizer Finset Shearer
noncomputable section
variable {E A : Type*} [DecidableEq E] [DecidableEq A]

def embeddedObjective (emb : A ↪ E) (f : Finset E → ℝ) (T : Finset A) := f (T.map emb)
def retainedObjective (keep : Finset E) (f : Finset E → ℝ) (T : Finset ↑keep) := f (T.image Subtype.val)

theorem retainedObjective_map (keep : Finset E) (f : Finset E → ℝ) :
    retainedObjective keep f = embeddedObjective (Function.Embedding.subtype (· ∈ keep)) f := by
  funext T
  simp [retainedObjective,embeddedObjective,Finset.map_eq_image]

theorem retainedObjective_submodular (keep : Finset E) (f : Finset E → ℝ) (hf : IsSubmodular f) :
    IsSubmodular (retainedObjective keep f) := by
  rw [retainedObjective_map]
  intro T U
  simpa [embeddedObjective,map_union,map_inter] using hf
    (T.map (Function.Embedding.subtype _)) (U.map (Function.Embedding.subtype _))

theorem embedded_expectation (emb : A ↪ E) (idx : ℕ → A) (q : ℕ → ℝ) (f : Finset E → ℝ) (n : ℕ) :
    bernoulliExpectation idx q (embeddedObjective emb f) n = bernoulliExpectation (fun i => emb (idx i)) q f n := by
  induction n generalizing f with
  | zero => simp [embeddedObjective]
  | succ n ih =>
    rw [bernoulliExpectation_succ,bernoulliExpectation_succ,ih]
    have he : (fun T => embeddedObjective emb f (T∪{idx n})) =
        embeddedObjective emb (fun T => f (T∪{emb (idx n)})) := by
      funext T; simp [embeddedObjective]
    rw [he,ih]

theorem retained_expectation (keep : Finset E) (idx : ℕ → ↑keep) (original : ℕ → E) (q : ℕ → ℝ)
    (f : Finset E → ℝ) (n : ℕ) (hidx : ∀ i<n, (idx i).val=original i) :
    bernoulliExpectation idx q (retainedObjective keep f) n = bernoulliExpectation original q f n := by
  rw [retainedObjective_map,embedded_expectation]
  exact bernoulliExpectation_edge_prefix _ _ _ _ _ hidx

theorem retained_arrival (keep : Finset E) (idx : ℕ → ↑keep) (original : ℕ → E) (f : Finset E → ℝ)
    (p : ℝ) (i : ℕ) (hh : ∀ j ≤ i, (idx j).val=original j) :
    arrivalWeight idx p (retainedObjective keep f) i = arrivalWeight original p f i := by
  have he : (fun T => marginal (retainedObjective keep f) (idx i) T) =
      retainedObjective keep (marginal f (original i)) := by
    funext T; simp [marginal,retainedObjective,hh i le_rfl]
  rw [arrivalWeight,arrivalWeight,he]
  exact retained_expectation _ _ _ _ _ _ (fun j hj => hh j hj.le)

theorem retained_shift (keep : Finset E) (hist : ℕ → ↑keep) (original : ℕ → E)
    (p : ℝ) (s : ℕ) (f : Finset E → ℝ) (hh : ∀ j<s, (hist j).val=original j)
    (T : Finset ↑keep) :
    shiftResidual hist p (retainedObjective keep f) s T =
      retainedObjective keep (historyMean original (fun _ => p) s f) T := by
  rw [shiftResidual_eq]
  let U := T.image Subtype.val
  have he : (fun X => retainedObjective keep f (T∪X)) = retainedObjective keep (fun X => f (U∪X)) := by
    funext X; simp [U,retainedObjective,Finset.image_union]
  rw [he,retained_expectation _ _ original _ _ s hh]
  rfl

theorem retained_residual (keep : Finset E) (hist : ℕ → ↑keep) (original : ℕ → E)
    (p : ℝ) (s : ℕ) (f : Finset E → ℝ) (hh : ∀ j<s, (hist j).val=original j) (T : Finset ↑keep) :
    residualValue hist p (retainedObjective keep f) s T =
      historyMean original (fun _ => p) s f (T.image Subtype.val) - historyMean original (fun _ => p) s f ∅ := by
  have h₁ := retained_shift keep hist original p s f hh T
  have h₂ := retained_shift keep hist original p s f hh ∅
  simp only [shiftResidual,retainedObjective,image_empty,residualValue_empty,zero_add] at h₁ h₂
  linarith only [h₁,h₂]

/-- The physical marked-label product is the very same signed number on both label spaces. -/
theorem retained_decoded_value (keep : Finset E) (hist sorted : ℕ → ↑keep) (original ordered : ℕ → E)
    (p : ℝ) (s n : ℕ) (q : ℕ → ℝ) (f : Finset E → ℝ)
    (hh : ∀ j<s, (hist j).val=original j) (he : ∀ j<n, (sorted j).val=ordered j) :
    let H := historyMean original (fun _ => p) s f
    bernoulliExpectation sorted q (residualValue hist p (retainedObjective keep f) s) n =
      bernoulliExpectation ordered q H n - H ∅ := by
  intro H
  have eqn : residualValue hist p (retainedObjective keep f) s =
      fun T => retainedObjective keep H T - H ∅ := by funext T; exact retained_residual _ _ _ _ _ _ hh T
  rw [eqn,bernoulliExpectation_sub,bernoulliExpectation_const,retained_expectation _ _ ordered _ H _ he]

variable {V : Type*} [Fintype E] [Nonempty E] [Fintype V] [DecidableEq V]

theorem RetainedPassData.subtype_conservative (C : PotentialConfig) (ends : E → V × V) (b : V → ℕ)
    (pair : E → BSlot b × BSlot b) (v k : ℕ) (edge : ℕ → E) (idx : ℕ → ℕ)
    (f : Finset E → ℝ) (M : Finset E) (τ : ℝ) (records : List (E×ℕ))
    (D : RetainedPassData C ends b pair v k edge idx f M τ records) (fallback : E) :
    let L := records.map Prod.fst
    let input := fun i => (edge i,(streamTolerance:ℝ)*τ/(v:ℝ)^2*idx i)
    ∀ hist : ℕ → ↑L.toFinset, (∀ i<L.length, (hist i).val=L.getD i fallback) →
    ∀ i<L.length, 0 ≤ frozenInput input k (hist i).val ∧
      frozenInput input k (hist i).val ≤ arrivalWeight hist C.p (retainedObjective L.toFinset f) i := by
  intro L input hist ho i hi
  rw [retained_arrival _ _ _ _ _ i (fun j hj => ho j (hj.trans_lt hi)),ho i hi]
  exact D.conservative fallback i (by simpa [L] using hi)

end
end SubmodularMatching.AppendixM
