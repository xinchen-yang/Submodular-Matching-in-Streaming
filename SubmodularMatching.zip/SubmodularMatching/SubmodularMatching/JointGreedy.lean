import SubmodularMatching.JointDirection
import SubmodularMatching.PackingIteration
import SubmodularMatching.SubmodularGreedy

/-!
# The actual finite joint optimizer with exact multilinear gradients

All directions are produced by the explicit clipped-dual packing solver.
The iterates, gradient queries, and Euler updates are defined here. This
version evaluates the finite multilinear polynomial exactly; it establishes
the mathematical finite optimizer, without a polynomial oracle-call bound
for this exact evaluation. The sampled-gradient implementation is separate.
-/

open scoped BigOperators

namespace SubmodularMatching.Joint

noncomputable section

/-- A total enumeration whose first `m` positions enumerate `Fin m` exactly. -/
def enumerateEdge {m : ℕ} (hm : 0 < m) (i : ℕ) : Fin m := ⟨i % m, Nat.mod_lt _ hm⟩

@[simp] theorem enumerateEdge_val {m : ℕ} (hm : 0 < m) (e : Fin m) :
    enumerateEdge hm e.val = e := by
  apply Fin.ext
  exact Nat.mod_eq_of_lt e.isLt

/-- Convert sums over edge coordinates to the ordered prefix used for the
actual multilinear extension. -/
theorem sum_fin_as_range {m : ℕ} (hm : 0 < m) (f : Fin m → ℝ) :
    (∑ e, f e) = ∑ i ∈ Finset.range m, f (enumerateEdge hm i) := by
  simpa only [enumerateEdge_val] using
    Fin.sum_univ_eq_sum_range (fun i => f (enumerateEdge hm i)) m

/-- Physical `y` coordinates of a normalized packing point, on a total prefix. -/
def physicalY {m : ℕ} (hm : 0 < m) (D : ℝ) (t : Fin m ⊕ Fin m → ℝ) : ℕ → ℝ :=
  fun i => D * t (.inr (enumerateEdge hm i))

/-- The actual exact coordinate gradient at the current physical point. -/
def exactGradient {m : ℕ} (hm : 0 < m) (D : ℝ) (F : Finset (Fin m) → ℝ)
    (t : Fin m ⊕ Fin m → ℝ) (e : Fin m) : ℝ :=
  Multilinear.coordinateDerivative (enumerateEdge hm) (physicalY hm D t) F m e.val

/-- Time-dependent coefficients computed from the current actual iterate. -/
def greedyCoefficient {m : ℕ} (hm : 0 < m) (p D tau epsilon : ℝ)
    (F : Finset (Fin m) → ℝ) (w : Fin m → ℝ) (j : ℕ)
    (t : Fin m ⊕ Fin m → ℝ) : Fin m ⊕ Fin m → ℝ :=
  directionCoefficient p D tau 1
    (FiniteGreedy.weight D (FiniteGreedy.stages D m epsilon) (j + 1))
    w (exactGradient hm D F t)

variable {m : ℕ} {V : Type*} [Fintype V] [DecidableEq V]

/-- The defined sequence of normalized finite optimizer iterates. -/
def greedyPoint (hm : 0 < m) (p D tau epsilon : ℝ)
    (ends : Fin m → V × V) (F : Finset (Fin m) → ℝ) (w : Fin m → ℝ) :
    ℕ → Fin m ⊕ Fin m → ℝ :=
  LinearPacking.iterate (matrix p D ends ends) (greedyCoefficient hm p D tau epsilon F w)
    (epsilon / 8) (FiniteGreedy.stages D m epsilon)

/-- The direction actually computed at a given iterate. -/
def greedyDirection (hm : 0 < m) (p D tau epsilon : ℝ)
    (ends : Fin m → V × V) (F : Finset (Fin m) → ℝ) (w : Fin m → ℝ) (j : ℕ) :
    Fin m ⊕ Fin m → ℝ :=
  LinearPacking.iterateDirection (matrix p D ends ends) (greedyCoefficient hm p D tau epsilon F w)
    (epsilon / 8) (FiniteGreedy.stages D m epsilon) j

/-- The actual normalized update equation. -/
theorem greedyPoint_succ (hm : 0 < m) (p D tau epsilon : ℝ)
    (ends : Fin m → V × V) (F : Finset (Fin m) → ℝ) (w : Fin m → ℝ) (j : ℕ)
    (e : Fin m ⊕ Fin m) :
    greedyPoint hm p D tau epsilon ends F w (j + 1) e =
      greedyPoint hm p D tau epsilon ends F w j e +
      (1 / FiniteGreedy.stages D m epsilon) * greedyDirection hm p D tau epsilon ends F w j e := rfl

/-- Fully instantiated finite fractional optimizer. The conclusion holds
simultaneously for every feasible matching-shaped comparator. -/
theorem greedy_solution (hm : 0 < m) (p D tau epsilon : ℝ)
    (ends : Fin m → V × V) (F : Finset (Fin m) → ℝ) (w : Fin m → ℝ)
    (hf : IsSubmodular F) (hmono : IsMonotone F) (hzero : F ∅ = 0)
    (hp : 0 < p) (hp1 : p ≤ 1) (hD : 0 < D) (hD2 : 2 * D ≤ 1)
    (htau : 0 < tau) (heps : 0 < epsilon) (heps1 : epsilon ≤ 1)
    (hw : ∀ e, 0 ≤ w e ∧ w e ≤ tau) (hF : ∀ e, F {e} ≤ tau) :
    let K := FiniteGreedy.stages D m epsilon
    let t := greedyPoint hm p D tau epsilon ends F w K
    Feasible p D ends ends (fun e => p * t (.inl e)) (fun e => D * t (.inr e)) ∧
      ∀ (z : Fin m → ℝ) (O : Finset (Fin m)),
        Feasible p D ends ends z (fun e => D * edgeIndicator O e) →
        (∑ e, w e * z e) + (1 - Real.exp (-D)) * F O - epsilon * tau / 2 ≤
          (∑ e, w e * (p * t (.inl e))) +
            bernoulliExpectation (enumerateEdge hm) (physicalY hm D t) F m := by
  let K := FiniteGreedy.stages D m epsilon
  let A := matrix p D ends ends
  let coeff := greedyCoefficient hm p D tau epsilon F w
  let pt := greedyPoint hm p D tau epsilon ends F w
  let dir := greedyDirection hm p D tau epsilon ends F w
  have hK : 0 < K := FiniteGreedy.stages_positive D m epsilon
  have hD1 : D ≤ 1 := by linarith
  have hDK : D ≤ (K : ℝ) := hD1.trans (by exact_mod_cast hK)
  have hA := matrix_bounds p D ends ends hp.le hp1 hD.le hD2
  have hM : 1 ≤ Fintype.card (V ⊕ V ⊕ Fin m) := by
    simp only [Fintype.card_sum, Fintype.card_fin]
    omega
  have hN : 1 ≤ Fintype.card (Fin m ⊕ Fin m) := by
    simp only [Fintype.card_sum, Fintype.card_fin]
    omega
  have heo : 0 < epsilon / 8 := by positivity
  have heo1 : epsilon / 8 ≤ 1 := by linarith
  have hpoint (j : ℕ) (hj : j ≤ K) :
      (∀ c, 0 ≤ pt j c ∧ pt j c ≤ 1) ∧ (∀ r, LinearPacking.load A (pt j) r ≤ 1) :=
    LinearPacking.iterate_feasible A coeff (epsilon / 8) K hA hM hN heo heo1 hK j hj
  have hdir (j : ℕ) :
      (∀ c, 0 ≤ dir j c ∧ dir j c ≤ 1) ∧ (∀ r, LinearPacking.load A (dir j) r ≤ 1) := by
    have h := LinearPacking.solve_correct A
      (LinearPacking.clipCoefficients (coeff j (pt j))) (epsilon / 8)
      hA (LinearPacking.clipCoefficients_bounds _) hM hN heo heo1
    exact ⟨h.1, h.2.1⟩
  have hybox (j : ℕ) (hj : j ≤ K) (i : ℕ) (_hi : i < m) :
      0 ≤ physicalY hm D (pt j) i ∧ physicalY hm D (pt j) i ≤ 1 := by
    have hc := (hpoint j hj).1 (.inr (enumerateEdge hm i))
    exact ⟨mul_nonneg hD.le hc.1, mul_le_one₀ hD1 hc.1 hc.2⟩
  have hgrad (j : ℕ) (hj : j ≤ K) (e : Fin m) :
      0 ≤ exactGradient hm D F (pt j) e ∧ exactGradient hm D F (pt j) e ≤ tau :=
    Multilinear.partial_bounds (enumerateEdge hm) (physicalY hm D (pt j)) F m e.val e.isLt
      (hybox j hj) (Multilinear.submodular_marginal_bound F hf hmono hzero hF)
  have hcoeff (j : ℕ) (hj : j ≤ K) : ∀ c, 0 ≤ coeff j (pt j) c ∧ coeff j (pt j) c ≤ 1 := by
    have ha := FiniteGreedy.weight_bounds (j := j + 1) hD.le hDK
    exact directionCoefficient_bounds p D tau 1 _ w _ hp.le hp1 hD.le hD1 htau
      (by norm_num) (by norm_num) ha.1 ha.2 hw (hgrad j hj)
  dsimp only
  constructor
  · exact feasible_of_packing p D ends ends hp.le hD.le _
      (fun c => ((hpoint K le_rfl).1 c).1) (hpoint K le_rfl).2
  · intro z O hcomp
    let L : ℕ → ℝ := fun j => ∑ e, w e * (p * pt j (.inl e))
    let linear : ℕ → ℝ := fun j => ∑ e, w e * (p * dir j (.inl e))
    let y : ℕ → ℕ → ℝ := fun j => physicalY hm D (pt j)
    let direction : ℕ → ℕ → ℝ := fun j => physicalY hm D (dir j)
    apply submodular_finite_greedy (enumerateEdge hm) m F hf hmono hzero
      D (∑ e, w e * z e) epsilon tau hD hD1 hm heps htau.le hF
      L linear y direction
    · simp [L, pt, greedyPoint, LinearPacking.iterate]
    · funext i
      simp [y, physicalY, pt, greedyPoint, LinearPacking.iterate]
    · intro j _
      dsimp [L, linear, pt, dir]
      simp_rw [greedyPoint_succ]
      simp only [mul_add, Finset.sum_add_distrib, Finset.mul_sum]
      congr 1
      apply Finset.sum_congr rfl
      intro e _
      ring
    · intro j _
      funext i
      dsimp [y, direction, physicalY, pt, dir, Multilinear.along]
      rw [greedyPoint_succ]
      ring
    · exact hybox
    · intro j _ i _
      have h := (hdir j).1 (.inr (enumerateEdge hm i))
      refine ⟨mul_nonneg hD.le h.1, ?_⟩
      exact (mul_le_mul_of_nonneg_left h.2 hD.le).trans_eq (mul_one D)
    · intro e _
      exact Finset.mem_image.mpr ⟨e.val, Finset.mem_range.mpr e.isLt, enumerateEdge_val hm e⟩
    · intro j hj
      let a := FiniteGreedy.weight D K (j + 1)
      let gradient := exactGradient hm D F (pt j)
      let tn := normalize p D z (fun e => D * edgeIndicator O e)
      have hx : (fun e => p * tn (.inl e)) = z := by
        funext e
        dsimp [tn, normalize]
        field_simp
      have hy : (fun e => D * tn (.inr e)) = (fun e => D * edgeIndicator O e) := by
        funext e
        dsimp [tn, normalize]
        field_simp
      have htn : Feasible p D ends ends (fun e => p * tn (.inl e))
          (fun e => D * tn (.inr e)) := by
        rw [hx, hy]
        exact hcomp
      have hpack := packing_of_feasible p D ends ends hp hD tn htn
      have ho := LinearPacking.iterate_direction_optimal A coeff (epsilon / 8) K j
        hA hM hN heo heo1 (hcoeff j hj.le) tn hpack.1 hpack.2
      change LinearPacking.objective
        (directionCoefficient p D tau 1 a w gradient) tn -
        epsilon / 8 ≤ LinearPacking.objective
          (directionCoefficient p D tau 1 a w gradient) (dir j) at ho
      have hs := mul_le_mul_of_nonneg_left ho htau.le
      rw [mul_sub, directionObjective_scaled p D tau 1 a w gradient htau.ne',
        directionObjective_scaled p D tau 1 a w gradient htau.ne', hx, hy] at hs
      have hsumComp : (∑ e, gradient e * (D * edgeIndicator O e)) =
          D * (∑ i ∈ Finset.range m,
            Multilinear.indicator (fun k => decide (enumerateEdge hm k ∈ O)) i *
              Multilinear.coordinateDerivative (enumerateEdge hm) (y j) F m i) := by
        rw [sum_fin_as_range hm, Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i hi
        have him := Finset.mem_range.mp hi
        dsimp [gradient, exactGradient, enumerateEdge, Multilinear.indicator, edgeIndicator, y]
        simp only [Nat.mod_eq_of_lt him, decide_eq_true_eq]
        split_ifs <;> ring
      have hsumDir : (∑ e, gradient e * (D * dir j (.inr e))) =
          ∑ i ∈ Finset.range m, direction j i *
            Multilinear.coordinateDerivative (enumerateEdge hm) (y j) F m i := by
        rw [sum_fin_as_range hm]
        apply Finset.sum_congr rfl
        intro i hi
        have him := Finset.mem_range.mp hi
        dsimp [gradient, exactGradient, direction, physicalY, enumerateEdge, y]
        simp only [Nat.mod_eq_of_lt him]
        ring
      simp only [directionObjective, one_mul, hsumComp, hsumDir] at hs
      have herr : 0 ≤ 2 * D * FiniteGreedy.accuracy D m epsilon * m * tau := by
        dsimp [FiniteGreedy.accuracy]
        positivity
      change _ ≤ linear j + a * _
      dsimp [linear]
      dsimp [a] at hs
      dsimp [K] at hs
      nlinarith


/-- The finite optimizer's guarantee for every actual matching and every
nonnegative vector satisfying its residual vertex and edge capacities. -/
theorem greedy_matching_guarantee (hm : 0 < m) (p D tau epsilon : ℝ)
    (ends : Fin m → V × V) (F : Finset (Fin m) → ℝ) (w : Fin m → ℝ)
    (hf : IsSubmodular F) (hmono : IsMonotone F) (hzero : F ∅ = 0)
    (hp : 0 < p) (hp1 : p ≤ 1) (hD : 0 < D) (hD2 : 2 * D ≤ 1)
    (htau : 0 < tau) (heps : 0 < epsilon) (heps1 : epsilon ≤ 1)
    (hw : ∀ e, 0 ≤ w e ∧ w e ≤ tau) (hF : ∀ e, F {e} ≤ tau)
    (O : Finset (Fin m)) (z : Fin m → ℝ)
    (hO : Streaming.IsMatchingOn (fun e => {(ends e).1, (ends e).2}) O)
    (hz : ∀ e, 0 ≤ z e)
    (hv : ∀ v, degree ends z v ≤ 1 - D * coveredIndicator ends O v)
    (he : ∀ e, z e ≤ p * (1 - D * (coveredIndicator ends O (ends e).1 +
      coveredIndicator ends O (ends e).2))) :
    let t := greedyPoint hm p D tau epsilon ends F w (FiniteGreedy.stages D m epsilon)
    (∑ e, w e * z e) + (1 - Real.exp (-D)) * F O - epsilon * tau / 2 ≤
      (∑ e, w e * (p * t (.inl e))) +
        bernoulliExpectation (enumerateEdge hm) (physicalY hm D t) F m := by
  exact (greedy_solution hm p D tau epsilon ends F w hf hmono hzero hp hp1 hD hD2
    htau heps heps1 hw hF).2 z O
    (matching_comparator_feasible p D ends ends O z hD.le hO hz hv he)

end

end SubmodularMatching.Joint
