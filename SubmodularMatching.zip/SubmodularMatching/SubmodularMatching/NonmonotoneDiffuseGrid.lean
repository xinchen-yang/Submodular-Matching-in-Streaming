import SubmodularMatching.NonmonotoneDiffusePrecision
import SubmodularMatching.NonmonotoneDiffuseAlteration

/-! # Conservative finite precision for both compensated and altered coordinates -/

namespace SubmodularMatching.TwoLayerDiffuse

open TwoStage GibbsMatching VarianceBound
noncomputable section

def gridNumerator (m : ℕ) (a : ℝ) := ⌊a*m⌋₊

def gridValue (m : ℕ) (a : ℝ) : ℝ := (gridNumerator m a : ℝ) / m

theorem gridValue_bounds (m : ℕ) (hm : 0 < m) (a : ℝ) (ha : 0 ≤ a) :
    0 ≤ gridValue m a ∧ gridValue m a ≤ a ∧ a - 1/m ≤ gridValue m a := by
  have hmp : (0:ℝ) < m := by exact_mod_cast hm
  dsimp [gridValue,gridNumerator]
  refine ⟨by positivity, (div_le_iff₀ hmp).2 (Nat.floor_le (mul_nonneg ha hmp.le)), ?_⟩
  apply (le_div_iff₀ hmp).2
  have h := Nat.lt_floor_add_one (a*(m:ℝ))
  field_simp at *
  linarith only [h]

variable {E V Ω : Type*} [Fintype E] [DecidableEq V]

/-- The finite routine divides by an upper approximation to the pair probability,
floors before alteration, and floors the altered coordinate for the Gibbs walk.
All output coordinates use a single denominator. -/
def gridAltered (ends : E → V × V) (U : V → Ω → ℝ) (x upper : E → ℝ)
    (m : ℕ) (ε : ℝ) (ω : Ω) (e : E) : ℝ :=
  gridValue m (altered ends (fun j => gridValue m (x j / upper j)) U ε ω e)

theorem gridAltered_bounds (ends : E → V × V) (U : V → Ω → ℝ)
    (hU : ∀ v ω, U v ω = 0 ∨ U v ω = 1) (x q upper : E → ℝ) (p η ε : ℝ)
    (m : ℕ) (hm : 0 < m) (hε : 0 ≤ ε) (hx : ∀ e, 0 ≤ x e)
    (hp : 0 ≤ p) (hη : 0 ≤ η) (hq : ∀ e, 1/3 ≤ q e)
    (hupper : ∀ e, q e ≤ upper e ∧ upper e ≤ q e + η)
    (hcap : ∀ e, x e / q e ≤ p) :
    (∀ ω e, 0 ≤ gridAltered ends U x upper m ε ω e ∧ gridAltered ends U x upper m ε ω e ≤ p) ∧
    (∀ ω v, Joint.degree ends (gridAltered ends U x upper m ε ω) v ≤ 1) ∧
    (∀ ω e, gridAltered ends U x upper m ε ω e ≠ 0 → U (ends e).1 ω = 1 ∧ U (ends e).2 ω = 1) ∧
    ∀ ω e, altered ends (fun i => x i / q i) U ε ω e - (3*p*η+2/m) ≤
      gridAltered ends U x upper m ε ω e := by
  let b := fun e => x e / q e
  let a := fun e => gridValue m (x e/upper e)
  have hmp : (0:ℝ) < m := by exact_mod_cast hm
  have hg (e : E) : 0 ≤ a e ∧ a e ≤ x e/upper e ∧ x e/upper e - 1/m ≤ a e :=
    gridValue_bounds m hm _ (div_nonneg (hx e) (by linarith [(hq e),(hupper e).1]))
  have he (e : E) : a e ≤ b e ∧ b e - (3*p*η+1/m) ≤ a e :=
    conservative_pair_error _ _ _ _ _ _ _ (hq e) (hx e) (hcap e)
      (hupper e).1 (hupper e).2 (hg e).2.1 (hg e).2.2
  have ha (e : E) : 0 ≤ a e ∧ a e ≤ p := ⟨(hg e).1,(he e).1.trans (hcap e)⟩
  have hraw (ω : Ω) (e : E) := altered_bounds ends a U ε p hε ha ω e
  have hz (ω : Ω) (e : E) := gridValue_bounds m hm _ (hraw ω e).1
  refine ⟨fun ω e => ⟨(hz ω e).1,(hz ω e).2.1.trans (hraw ω e).2⟩,?_,?_,?_⟩
  · intro ω v
    apply le_trans _ (altered_degree ends a U ε hε (fun e => (ha e).1) hU ω v)
    apply Finset.sum_le_sum
    intro e _
    exact mul_le_mul_of_nonneg_left (hz ω e).2.1 (by unfold Joint.incidence; split_ifs <;> norm_num)
  · intro ω e hne
    apply altered_support ends a U ε ω e
    intro hzero
    exact hne (le_antisymm ((hz ω e).2.1.trans_eq hzero) (hz ω e).1)
  · intro ω e
    have h₁ := altered_coordinate_loss ends U (fun v w => by rcases hU v w with h|h <;> simp [h])
      a b (fun i => (ha i).1) (fun i => (he i).1) ε hε _ (by positivity) ω e (he e).2
    change altered ends b U ε ω e - _ ≤ gridValue m (altered ends a U ε ω e)
    have h₂ := (hz ω e).2.2
    rw [show (2:ℝ)/m = 1/m+1/m by ring]
    linarith only [h₁,h₂]

end
end SubmodularMatching.TwoLayerDiffuse
