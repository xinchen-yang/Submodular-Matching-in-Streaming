import SubmodularMatching.LowerBoundGlobalAverage

/-! # An actual phase experiment using the cited blueprint data -/

namespace SubmodularMatching.LowerBoundGlobal

open Information LowerBoundAssembly
open scoped BigOperators

noncomputable section

/-- The clone edges between a set of sampled base pairs. Different ambient
clone samples can be fixed as side information before a base phase. -/
def survivingClones {L R C : Type*} [DecidableEq L] [DecidableEq R] [DecidableEq C]
    (cloneEdges : Finset (LiftEdge L R C)) (baseSample : Finset (L × R)) :
    Finset (LiftEdge L R C) :=
  cloneEdges.filter (fun e => CloneLift.basePair e ∈ baseSample)

theorem survivingClones_image_subset {L R C : Type*}
    [DecidableEq L] [DecidableEq R] [DecidableEq C]
    (cloneEdges : Finset (LiftEdge L R C)) (baseSample : Finset (L × R)) :
    (survivingClones cloneEdges baseSample).image CloneLift.basePair ⊆ baseSample := by
  intro edge he
  obtain ⟨e, hmem, rfl⟩ := Finset.mem_image.mp he
  exact (Finset.mem_filter.mp hmem).2

theorem prefix_rarity_with_future {N P t H : ℕ} (blueprint : BlueprintExpansion N P t H)
    (phase : Fin P) (J : Fin P → Fin t) (e : Fin N × Fin N)
    {Future : Type*} [Fintype Future]
    (futureLaw : (prefixTuples phase J) → Future → ℝ)
    (hfuture : ∀ J', ∑ f, futureLaw J' f = 1) :
    (∑ side : (prefixTuples phase J) × Future,
      if e ∈ blueprint.phases J phase ∧ specialBase (blueprint.canonical side.1) e then
        (1 / ((prefixTuples phase J).card : ℝ)) * futureLaw side.1 side.2 else 0) ≤ (P : ℝ) / t := by
  classical
  let w := 1 / ((prefixTuples phase J).card : ℝ)
  let relevant := fun J' : (prefixTuples phase J) =>
    e ∈ blueprint.phases J phase ∧ specialBase (blueprint.canonical J') e
  have heq : (∑ side : (prefixTuples phase J) × Future,
      if relevant side.1 then w * futureLaw side.1 side.2 else 0) =
      ∑ side : (prefixTuples phase J) × Future,
        (w * futureLaw side.1 side.2) * (if relevant side.1 then 1 else 0) := by
    apply Finset.sum_congr rfl
    intro side _
    split_ifs <;> simp
  change (∑ side : (prefixTuples phase J) × Future,
    if relevant side.1 then w * futureLaw side.1 side.2 else 0) ≤ _
  rw [heq, sum_future_kernel (fun _ => w) futureLaw hfuture (fun J' => if relevant J' then 1 else 0)]
  simp only [mul_ite, mul_one, mul_zero]
  exact prefix_rarity_sum blueprint phase J e

/-- Legal continuations and the actual conditional phase sample give the
per-phase rare-output bound. The tuple and the remaining future samples
are integrated together. The future samples can depend on the tuple.
The algorithm's tape and all labels have already been fixed. -/
theorem blueprint_phase_output_bound {N P t H : ℕ} (blueprint : BlueprintExpansion N P t H)
    (phase : Fin P) (J : Fin P → Fin t)
    {C State Future : Type*} [Fintype C] [DecidableEq C] [Fintype State] [Nonempty State]
    [Fintype Future]
    (m : Machine (LiftEdge (Fin N) (Fin N) C) State)
    (cloneEdges : Finset (LiftEdge (Fin N) (Fin N) C))
    (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (past : List (LiftEdge (Fin N) (Fin N) C))
    (arrivals : Finset (Fin N × Fin N) → List (LiftEdge (Fin N) (Fin N) C))
    (after : (prefixTuples phase J) × Future → List (LiftEdge (Fin N) (Fin N) C))
    (oracle : Finset (LiftEdge (Fin N) (Fin N) C) → ℝ)
    (futureLaw : (prefixTuples phase J) → Future → ℝ)
    (hfuture0 : ∀ J' f, 0 ≤ futureLaw J' f)
    (hfuture : ∀ J', ∑ f, futureLaw J' f = 1)
    (hphase : 0 < (blueprint.phases J phase).card)
    (hpast : ∀ e ∈ past, CloneLift.basePair e ∉ blueprint.phases J phase)
    (harrivals : ∀ S e, e ∈ arrivals S → e ∈ survivingClones cloneEdges S)
    (hafter : ∀ x e, e ∈ after x → CloneLift.basePair e ∉ blueprint.phases J phase)
    (hlegal : ∀ S, 0 < uniformSubsetMass (blueprint.phases J phase)
        (retainedSize q (blueprint.phases J phase).card) S → ∀ x,
      m.legal oracle (past ++ arrivals S ++ after x))
    (hmatching : ∀ S, 0 < uniformSubsetMass (blueprint.phases J phase)
        (retainedSize q (blueprint.phases J phase).card) S → ∀ x,
      CloneLift.IsMatching (m.output oracle (past ++ arrivals S ++ after x)))
    (s : ℕ) (hstates : Fintype.card State ≤ 2 ^ s) :
    (∑ S, uniformSubsetMass (blueprint.phases J phase)
        (retainedSize q (blueprint.phases J phase).card) S *
      (∑ x : (prefixTuples phase J) × Future,
        ((1 / ((prefixTuples phase J).card : ℝ)) * futureLaw x.1 x.2) *
        (((m.output oracle (past ++ arrivals S ++ after x)).filter (fun e =>
          e ∈ survivingClones cloneEdges (blueprint.phases J phase) ∧
          specialBase (blueprint.canonical x.1) (CloneLift.basePair e))).card : ℝ))) ≤
      (Fintype.card C : ℝ) * ((P : ℝ) / t * (s / Real.logb 2 (1 / q))) := by
  classical
  let U := blueprint.phases J phase
  let μ := uniformSubsetMass U (retainedSize q U.card)
  let old := survivingClones cloneEdges U
  let w := 1 / ((prefixTuples phase J).card : ℝ)
  have hbefore : ∀ S e, 0 < μ S → e ∈ past ++ arrivals S →
      e ∈ old → e ∈ survivingClones cloneEdges S := by
    intro S e _ he hold
    rcases List.mem_append.mp he with hp | ha
    · exact (hpast e hp (Finset.mem_filter.mp hold).2).elim
    · exact harrivals S e ha
  have hnew : ∀ x e, e ∈ after x → e ∉ old :=
    fun x e ha hold => hafter x e ha (Finset.mem_filter.mp hold).2
  let cut := Cut.fixedOracleCut m μ old (survivingClones cloneEdges)
    (fun S => past ++ arrivals S) after oracle hbefore hnew
    (fun S x hs => by simpa only [List.append_assoc] using hlegal S hs x)
  let special := fun x : (prefixTuples phase J) × Future => fun e =>
    e ∈ U ∧ specialBase (blueprint.canonical x.1) e
  have hresult := phase_output_bound m U q hq0 hq1 hphase cut (fun x => w * futureLaw x.1 x.2)
    (fun x => mul_nonneg (by positivity) (hfuture0 x.1 x.2)) special ((P : ℝ) / t)
    (by positivity) (fun e => prefix_rarity_with_future blueprint phase J e futureLaw hfuture)
    s hstates (survivingClones_image_subset cloneEdges)
    (fun S hs x => by simpa only [cut, Cut.fixedOracleCut, List.append_assoc] using hmatching S hs x)
  convert hresult using 1
  apply Finset.sum_congr rfl
  intro S _
  congr 1
  apply Finset.sum_congr rfl
  intro x _
  congr 3
  ext e
  simp only [cut, Cut.fixedOracleCut, old, U, special, List.append_assoc, Finset.mem_filter,
    Finset.mem_inter]
  constructor
  · intro hs
    exact ⟨⟨hs.1, hs.2.1⟩, (Finset.mem_filter.mp hs.2.1).2, hs.2.2⟩
  · intro hs
    exact ⟨hs.1.1, hs.1.2, hs.2.2⟩

end

end SubmodularMatching.LowerBoundGlobal
