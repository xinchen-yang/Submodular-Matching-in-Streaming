import SubmodularMatching.CertificateEndpointTarget
import SubmodularMatching.CertificateMidpointPartition

/-!
# Applying a checked partition to every appendix source mode

The partition covers prices from zero through the last actual knot.
Outside that range one of the source functions has already reached its
large constant tail.
-/

namespace SubmodularMatching.SourceCertificate

open Streaming

/-- Separate the lower and upper endpoint of each interval. -/
def endpointNumber (mode : ℕ) (upper : Bool) : ℕ := 2 * mode + if upper then 1 else 0

def endpointMode (e : ℕ) : ℕ := e / 2

def endpointSide (e : ℕ) : Bool := e % 2 == 1

theorem endpointMode_number (mode : ℕ) (upper : Bool) :
    endpointMode (endpointNumber mode upper) = mode := by
  cases upper <;> simp [endpointMode, endpointNumber] <;> omega

theorem endpointSide_number (mode : ℕ) (upper : Bool) :
    endpointSide (endpointNumber mode upper) = upper := by
  cases upper
  · suffices (2 * mode + 0) % 2 = 0 by simpa [endpointSide, endpointNumber, this]
    omega
  · suffices (2 * mode + 1) % 2 = 1 by simpa [endpointSide, endpointNumber, this]
    omega

theorem endpointNumber_bound (mode : ℕ) (upper : Bool) (hm : mode < 27648) :
    endpointNumber mode upper < 55296 := by
  cases upper <;> simp [endpointNumber] <;> omega

noncomputable section

/-- Endpoint goal indexed by the mode coordinate of a partition. -/
def AppendixIndexedGoal (i j : Bool) (e : ℕ) (a d : ℝ) : Prop :=
  AppendixEndpointGoal (endpointMode e) (endpointSide e) i j a d

/-- The two tail checks and coverage of the root box suffice for the
complete endpoint inequality at arbitrary nonnegative prices. -/
theorem appendixEndpoints_of_root
    (rootSound : ∀ i j e a d, appendixPriceRoot.Contains appendixPotentialTable.realKnot e a d →
      AppendixIndexedGoal i j e a d)
    (tailA : ∀ mode < 27648, ∀ i j, appendixTarget mode i j ≤
      appendixWeightA mode i * appendixPotentialTable.value i (appendixPotentialTable.realKnot 1135))
    (tailB : ∀ mode < 27648, ∀ i j, appendixTarget mode i j ≤
      appendixWeightB mode j * appendixPotentialTable.value j (appendixPotentialTable.realKnot 1135))
    (mode : ℕ) (hm : mode < 27648) (upper i j : Bool) (a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d) :
    AppendixEndpointGoal mode upper i j a d := by
  let last := appendixPotentialTable.realKnot 1135
  by_cases hout : last ≤ a ∨ last ≤ d
  · exact appendixEndpointGoal_of_tail mode hm upper i j last last a d ha hd
      (tailA mode hm i j) (tailB mode hm i j) hout
  · have hA : a ≤ last := (lt_of_not_ge (not_or.mp hout).1).le
    have hD : d ≤ last := (lt_of_not_ge (not_or.mp hout).2).le
    have ha₀ : appendixPotentialTable.realKnot 0 ≤ a := by rw [appendixPotentialTable.knot_zero]; exact ha
    have hd₀ : appendixPotentialTable.realKnot 0 ≤ d := by rw [appendixPotentialTable.knot_zero]; exact hd
    have validPoint : appendixPriceRoot.Contains appendixPotentialTable.realKnot
        (endpointNumber mode upper) a d := by
      refine ⟨Nat.zero_le _, ?_, ha₀, hA, hd₀, hD⟩
      exact Nat.le_of_lt_succ (endpointNumber_bound mode upper hm)
    have h := rootSound i j (endpointNumber mode upper) a d validPoint
    simpa only [AppendixIndexedGoal, endpointMode_number, endpointSide_number] using h

theorem appendixEndpoints_of_partition {W : Type}
    (leafCheck : Bool → Bool → PriceBox → W → Bool)
    (tree : Bool → Bool → MidpointPartition W)
    (checked : ∀ i j, (tree i j).check (leafCheck i j) appendixPriceRoot = true)
    (leafSound : ∀ i j box w, box.IsValid 55296 1135 → leafCheck i j box w = true →
      ∀ e a d, box.Contains appendixPotentialTable.realKnot e a d → AppendixIndexedGoal i j e a d)
    (tailA : ∀ mode < 27648, ∀ i j, appendixTarget mode i j ≤
      appendixWeightA mode i * appendixPotentialTable.value i (appendixPotentialTable.realKnot 1135))
    (tailB : ∀ mode < 27648, ∀ i j, appendixTarget mode i j ≤
      appendixWeightB mode j * appendixPotentialTable.value j (appendixPotentialTable.realKnot 1135))
    (mode : ℕ) (hm : mode < 27648) (upper i j : Bool) (a d : ℝ) (ha : 0 ≤ a) (hd : 0 ≤ d) :
    AppendixEndpointGoal mode upper i j a d :=
  appendixEndpoints_of_root
    (fun i j => MidpointPartition.sound (leafCheck i j) 55296 1135 appendixPotentialTable.realKnot
      (AppendixIndexedGoal i j) (leafSound i j) (tree i j) appendixPriceRoot
      appendixPriceRoot_valid (checked i j))
    tailA tailB mode hm upper i j a d ha hd

theorem actualSourceConditions_of_partition {W : Type}
    (tau theta gap grid : ℝ) (hθ : 0 < theta) (hθτ : theta ≤ tau) (hd : 0 ≤ gap) (hg : 0 < grid)
    (hgτ : grid ≤ NumericalCertificate.coordinateCap * tau)
    (leafCheck : Bool → Bool → PriceBox → W → Bool)
    (tree : Bool → Bool → MidpointPartition W)
    (checked : ∀ i j, (tree i j).check (leafCheck i j) appendixPriceRoot = true)
    (leafSound : ∀ i j box w, box.IsValid 55296 1135 → leafCheck i j box w = true →
      ∀ e a d, box.Contains appendixPotentialTable.realKnot e a d → AppendixIndexedGoal i j e a d)
    (tailA : ∀ mode < 27648, ∀ i j, appendixTarget mode i j ≤
      appendixWeightA mode i * appendixPotentialTable.value i (appendixPotentialTable.realKnot 1135))
    (tailB : ∀ mode < 27648, ∀ i j, appendixTarget mode i j ≤
      appendixWeightB mode j * appendixPotentialTable.value j (appendixPotentialTable.realKnot 1135)) :
    RunSourceConditions appendixPotentialTable.sourceFunction
      (appendixPotentialConfig tau theta gap grid hθ hθτ hd hg hgτ)
      NumericalCertificate.degree NumericalCertificate.sigma (SourceRateTable.appendixCmax : ℝ) :=
  actualSourceConditions_of_endpoints tau theta gap grid hθ hθτ hd hg hgτ
    (appendixEndpoints_of_partition leafCheck tree checked leafSound tailA tailB)

end

end SubmodularMatching.SourceCertificate
