import SubmodularMatching.ProjectedShearerRationalSampler
import SubmodularMatching.CapacityIndexCursor
import SubmodularMatching.CapacityLabelTable
import SubmodularMatching.NonmonotoneStoredSlotAlteration

/-! # A sparse finite-word Shearer layer on the actual retained slot graph -/

set_option maxHeartbeats 1000000

namespace SubmodularMatching.Capacity
open Finset UpperBoundAssembly ShearerCappedSampler GibbsMatching GibbsSampler Shearer TwoLayerDiffuse
open scoped BigOperators
variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- A single tail-recursive scan accumulates the numerator on the requested
unordered vertex pair. Its input is the retained list of original labels. -/
def scanLabelNumerator (ends : E → V×V) (a : E → ℕ) (u v : V) : List E → ℕ → ℕ
  | [], acc => acc
  | e::es, acc => scanLabelNumerator ends a u v es (acc + if hasEndpoints ends e u v then a e else 0)

private theorem scanLabelNumerator_spec (ends : E → V×V) (a : E → ℕ) (u v : V) (es : List E)
    (hs : es.Nodup) (acc : ℕ) : scanLabelNumerator ends a u v es acc =
      acc + ∑ e ∈ es.toFinset, if hasEndpoints ends e u v then a e else 0 := by
  induction es generalizing acc with
  | nil => simp [scanLabelNumerator]
  | cons e es ih =>
    rw [List.nodup_cons] at hs
    simp [scanLabelNumerator,ih hs.2,List.mem_toFinset, hs.1,Nat.add_assoc]

variable [Fintype E] [Fintype V]

theorem scanLabelNumerator_div (S : SimpleEdgeStream E V) (a : E → ℕ) (d : ℕ) (u v : V) :
    (scanLabelNumerator S.ends a u v S.arrivals 0 : ℝ)/d =
      labelTable S.ends (fun e => (a e:ℝ)/d) u v := by
  have hall : S.arrivals.toFinset = univ := eq_univ_of_forall (fun e => List.mem_toFinset.mpr (S.complete e))
  rw [scanLabelNumerator_spec _ _ _ _ _ S.distinct, hall,zero_add,Nat.cast_sum,Finset.sum_div]
  unfold labelTable
  apply sum_congr rfl
  intro e _
  split_ifs <;> simp

def slotNum (S : SimpleEdgeStream E V) (b : V → ℕ) (a : E → ℕ) (θn : ℕ) (p : Slots b × Slots b) :=
  θn * scanLabelNumerator S.ends a p.1.1 p.2.1 S.arrivals 0

def slotDen (b : V → ℕ) (d θd : ℕ) (p : Slots b × Slots b) :=
  θd * d * b p.1.1 * b p.2.1

theorem slot_quotient (S : SimpleEdgeStream E V) (b : V → ℕ) (a : E → ℕ) (d θn θd : ℕ) :
    exactRate (slotNum S b a θn) (slotDen b d θd) =
      fun p => slotWeight b (labelTable S.ends (fun e => (a e:ℝ)/d)) ((θn:ℝ)/θd) p.1 p.2 := by
  funext p
  rw [slotWeight,←scanLabelNumerator_div]
  simp [exactRate,slotNum,slotDen,div_eq_mul_inv,mul_assoc,mul_comm,mul_left_comm]

variable (S : SimpleEdgeStream E V) (b : V → ℕ) (hb : ∀ v, 0 < b v) (rank : Slots b ↪ ℕ)
variable (a : E → ℕ) (d θn θd D : ℕ) (hD : 0 < D)

abbrev layerSupport := storedSlotPairs b rank (univ.image S.ends)

private theorem layerIndex_cover : univ.image (layerAt S.ends b rank S.arrivals) = layerSupport S b rank := by
  have hall : S.arrivals.toFinset = univ := eq_univ_of_forall (fun e => List.mem_toFinset.mpr (S.complete e))
  simpa only [hall] using layerAt_image S b rank S.arrivals

private theorem pair_ne (p : Slots b × Slots b) (hp : p∈layerSupport S b rank) : p.1 ≠ p.2 := by
  have h := (mem_filter.mp hp).2
  exact fun eq => (lt_irrefl _ (show rank p.1 < rank p.1 by simpa only [eq] using h))

include hb in
private theorem layer_degree (hdeg : ∀ u, ((θn:ℝ)/θd)*Capacity.slotLoad S.ends b (fun e=>(a e:ℝ)/d) u ≤ AppendixM.layerOne)
    (i : Slots b) :
    ∑ e ∈ incident pairVertices (layerSupport S b rank) i, exactRate (slotNum S b a θn) (slotDen b d θd) e ≤ AppendixM.layerOne := by
  rw [slot_quotient]
  let Y := fun e => (a e:ℝ)/d
  have h := retained_slot_degree b hb rank (univ.image S.ends) (labelTable S.ends Y) (labelTable_symm S.ends Y) (labelTable_diag S.ends S.loopless Y)
    (labelTable_support S.ends Y) ((θn:ℝ)/θd) i
  rw [labelTable_load S.ends S.loopless] at h
  exact h.le.trans (hdeg i.1)

include hb hD

/-- The input to the native capped tape on the actual retained slots.
Every indexed lookup is implemented by the sparse label-block cursor. -/
noncomputable def physicalLayerInput
    (hdeg : ∀ u, ((θn:ℝ)/θd)*Capacity.slotLoad S.ends b (fun e=>(a e:ℝ)/d) u ≤ AppendixM.layerOne) :
    Input pairVertices (layerSupport S b rank) :=
  layerInput (layerAt S.ends b rank S.arrivals) (layerAt_injective S b rank _ S.distinct) _ _
    (layerIndex_cover S b rank) id (fun _ _ => rfl) (pair_ne S b rank) _ _ D hD (layer_degree S b hb rank a d θn θd hdeg)

/-- The left-hand law uses the unrounded slot weight matrix. The right-hand law
is sampled on a finite word tape with bounded stack and matching size. -/
theorem physicalLayer_variation
    (hdeg : ∀ u, ((θn:ℝ)/θd)*Capacity.slotLoad S.ends b (fun e=>(a e:ℝ)/d) u ≤ AppendixM.layerOne)
    (δ η : ℝ) (hδ : 0<δ ∧ δ≤1) (hη : 0<η) (K : ℕ)
    (hk : (layerSupport S b rank).sum (fun p => slotWeight b (labelTable S.ends (fun e => (a e:ℝ)/d)) ((θn:ℝ)/θd) p.1 p.2)
      + Real.log (1/η) ≤ K*Real.log 2) :
    let I := physicalLayerInput S b hb rank a d θn θd D hD hdeg
    variation univ (Shearer.probability pairVertices (layerSupport S b rank)
      (fun p => slotWeight b (labelTable S.ends (fun e => (a e:ℝ)/d)) ((θn:ℝ)/θd) p.1 p.2)) (outcomeLaw I δ hδ K).mass
      ≤ (layerSupport S b rank).card/D + δ + η := by
  intro I
  rw [←slot_quotient] at hk ⊢
  exact finite_layer_total_variation _ (layerAt_injective S b rank _ S.distinct) _ _ (layerIndex_cover S b rank)
    id (fun _ _ => rfl) (pair_ne S b rank) _ _ D hD (layer_degree S b hb rank a d θn θd hdeg) δ η hδ hη K hk

end SubmodularMatching.Capacity
