import SubmodularMatching.NonmonotoneDiffuseMoments

open scoped BigOperators

namespace SubmodularMatching.TwoLayerDiffuse

open GibbsMatching VarianceBound
noncomputable section

variable {E V : Type*} [DecidableEq E] [DecidableEq V] [Fintype V]
variable {ends : E → Finset V} {S : Finset E}

omit [Fintype V] [DecidableEq E] in
theorem free_product_lower (A B : Layer ends S) (d : ℝ)
    (hdegree : ∀ v, A.deg v + B.deg v ≤ d) (u : V) :
    1 - d ≤ A.free u * B.free u := by
  have h := mul_nonneg (Shearer.vertexDegree_nonnegative ends S A.y A.nonneg u)
    (Shearer.vertexDegree_nonnegative ends S B.y B.nonneg u)
  change 0 ≤ A.deg u * B.deg u at h
  dsimp only [Layer.free]
  nlinarith only [h, hdegree u]

/-- The covariance bound gives the exact load variance coefficient in Appendix M.3. -/
theorem load_variance (A B : Layer ends S) (he : ∀ e ∈ S, (ends e).card = 2)
    (d p : ℝ) (hd : 0 ≤ d) (hp : 0 ≤ p) (hdegree : ∀ v, A.deg v + B.deg v ≤ d)
    (c : V → ℝ) (hc : ∀ v, 0 ≤ c v ∧ c v ≤ p) :
    finiteVariance (joint A B) (fun ω => ∑ v, c v * vacant ends S v ω) ≤
      (2*p*d)*finiteMean (joint A B) (fun ω => ∑ v, c v * vacant ends S v ω) := by
  classical
  let C := finiteCovariance (joint A B) (vacant ends S)
  let a := fun v => A.free v * B.free v
  let W := fun u v => A.weight u v + B.weight u v
  have ha (v : V) : 0 ≤ a v := mul_nonneg (A.free_bounds v).1 (B.free_bounds v).1
  have hw (u v : V) : 0 ≤ W u v := add_nonneg
    (neighborActivity_nonnegative ends S A.y A.nonneg u v) (neighborActivity_nonnegative ends S B.y B.nonneg u v)
  have hwrow (u : V) : ∑ v, W u v ≤ d := by
    dsimp only [W, Layer.weight]
    rw [Finset.sum_add_distrib, neighborActivity_row_sum ends S A.y he, neighborActivity_row_sum ends S B.y he]
    exact hdegree u
  have hdiag (u : V) : C u u ≤ d * a u := by
    dsimp only [C]
    rw [Information.finiteCovariance_eq_product_sub _ (joint_total A B)]
    have hs : (fun ω => vacant ends S u ω * vacant ends S u ω) = vacant ends S u := by
      funext ω; rcases vacant_zero_one u ω with h|h <;> simp [h]
    rw [hs, vacant_mean]
    have hl : 1 - d ≤ a u := free_product_lower A B d hdegree u
    change a u - a u*a u ≤ d*a u
    nlinarith only [mul_le_mul_of_nonneg_right hl (ha u)]
  have hpoint (u v : V) : c u*c v*C u v ≤
      (if v = u then c u*a u*p*d else 0) + (c u*a u*p)*W u v := by
    by_cases huv : v = u
    · subst v
      simp only [ite_true, eq_self]
      have h1 := mul_le_mul_of_nonneg_left (hdiag u) (mul_nonneg (hc u).1 (hc u).1)
      have h2 := mul_le_mul_of_nonneg_right (hc u).2 (mul_nonneg (mul_nonneg (hc u).1 (ha u)) hd)
      have h3 := mul_nonneg (mul_nonneg (mul_nonneg (hc u).1 (ha u)) hp) (hw u u)
      nlinarith only [h1,h2,h3]
    · rw [if_neg huv,zero_add]
      have hb : C u v ≤ W u v * a u := vacant_covariance_upper A B he u v (Ne.symm huv)
      have h1 := mul_le_mul_of_nonneg_left hb (mul_nonneg (hc u).1 (hc v).1)
      have h2 := mul_le_mul_of_nonneg_right (hc v).2
        (mul_nonneg (mul_nonneg (hc u).1 (ha u)) (hw u v))
      nlinarith only [h1,h2]
  rw [finiteVariance_eq_quadraticForm,finiteMean_weighted_sum]
  simp only [vacant_mean]
  change (∑ u, ∑ v, c u*c v*C u v) ≤ (2*p*d)*∑ u, c u*a u
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro u _
  calc
    _ ≤ ∑ v, ((if v = u then c u*a u*p*d else 0) + (c u*a u*p)*W u v) :=
      Finset.sum_le_sum (fun v _ => hpoint u v)
    _ = c u*a u*p*d + (c u*a u*p)*∑ v, W u v := by
      rw [Finset.sum_add_distrib, ← Finset.mul_sum]; simp
    _ ≤ _ := by
      have h := mul_le_mul_of_nonneg_left (hwrow u) (mul_nonneg (mul_nonneg (hc u).1 (ha u)) hp)
      nlinarith only [h]

/-- The exact triangle correction gives a linear-in-cap mean envelope
for the product of the two vacancy indicators. -/
theorem load_mean (A B : Layer ends S) (he : ∀ e ∈ S, (ends e).card = 2)
    (d p : ℝ) (hd : 0 ≤ d) (hd' : 2*d < 1) (hp : 0 ≤ p)
    (hdegree : ∀ v, A.deg v + B.deg v ≤ d)
    (u : V) (c : V → ℝ) (hc : ∀ v, 0 ≤ c v ∧ c v ≤ p) (hself : c u = 0)
    (hbudget : (∑ v, c v * (A.pair u v * B.pair u v)) ≤ A.free u * B.free u) :
    finiteMean (joint A B) (fun ω => ∑ v, c v * vacant ends S v ω) ≤
      1 + TwoStage.meanAllowance p d := by
  let a := fun v => A.free v * B.free v
  let T := fun v => A.triangle u v + B.triangle u v
  have had (v : V) : A.deg v ≤ d := by
    have h : 0 ≤ B.deg v := Shearer.vertexDegree_nonnegative ends S B.y B.nonneg v
    linarith [hdegree v]
  have hbd (v : V) : B.deg v ≤ d := by
    have h : 0 ≤ A.deg v := Shearer.vertexDegree_nonnegative ends S A.y A.nonneg v
    linarith [hdegree v]
  have hT (v : V) : 0 ≤ T v := add_nonneg
    (Shearer.triangleCorrection_nonnegative ends S A.y A.nonneg u v)
    (Shearer.triangleCorrection_nonnegative ends S B.y B.nonneg u v)
  have hTrow : (∑ v, T v) ≤ d^2 := by
    dsimp only [T]
    rw [Finset.sum_add_distrib]
    have hA : (∑ v, A.triangle u v) ≤ d*A.deg u := Shearer.triangleCorrection_row_bound ends S A.y A.nonneg he d had u
    have hB : (∑ v, B.triangle u v) ≤ d*B.deg u := Shearer.triangleCorrection_row_bound ends S B.y B.nonneg he d hbd u
    nlinarith only [hA,hB,mul_le_mul_of_nonneg_left (hdegree u) hd]
  have hpoint (v : V) : a u * (c v * a v) ≤ c v * (A.pair u v * B.pair u v) + p*T v := by
    by_cases huv : u = v
    · subst v; rw [hself]; simpa using mul_nonneg hp (hT u)
    have hA : A.free u * A.free v ≤ A.pair u v + A.triangle u v :=
      Shearer.unmatched_pair_product_bound ends S A.y A.nonneg he d hd'.le had u v huv
    have hB : B.free u * B.free v ≤ B.pair u v + B.triangle u v :=
      Shearer.unmatched_pair_product_bound ends S B.y B.nonneg he d hd'.le hbd u v huv
    have hAb : A.pair u v ≤ 1 := (A.pair_bounds he u v).2.trans (A.free_bounds u).2
    have hBb : B.free u * B.free v ≤ 1 := mul_le_one₀ (B.free_bounds u).2 (B.free_bounds v).1 (B.free_bounds v).2
    have htA : 0 ≤ A.triangle u v := Shearer.triangleCorrection_nonnegative ends S A.y A.nonneg u v
    have htB : 0 ≤ B.triangle u v := Shearer.triangleCorrection_nonnegative ends S B.y B.nonneg u v
    have hprod : a u * a v ≤ A.pair u v * B.pair u v + T v := by
      dsimp only [a,T]
      nlinarith only [mul_le_mul_of_nonneg_right hA (mul_nonneg (B.free_bounds u).1 (B.free_bounds v).1),
        mul_le_mul_of_nonneg_left hB (A.pair_nonneg he u v),
        mul_le_mul_of_nonneg_left hBb htA, mul_le_mul_of_nonneg_left hAb htB]
    nlinarith only [mul_le_mul_of_nonneg_left hprod (hc v).1, mul_le_mul_of_nonneg_right (hc v).2 (hT v)]
  rw [finiteMean_weighted_sum]
  simp only [vacant_mean]
  change (∑ v, c v * a v) ≤ 1 + TwoStage.meanAllowance p d
  have hsum := Finset.sum_le_sum (s := Finset.univ) (fun v _ => hpoint v)
  rw [← Finset.mul_sum, Finset.sum_add_distrib, ← Finset.mul_sum] at hsum
  have hden : 0 < 1-d := by linarith
  have hlo : 1-d ≤ a u := free_product_lower A B d hdegree u
  have hA : 0 ≤ TwoStage.meanAllowance p d := div_nonneg (mul_nonneg hp (sq_nonneg _)) hden.le
  have hid : (1-d)*TwoStage.meanAllowance p d = p*d^2 := by
    dsimp [TwoStage.meanAllowance]; field_simp
  have h₁ := mul_le_mul_of_nonneg_right hlo hA
  change _ ≤ a u at hbudget
  apply le_of_mul_le_mul_left (a := a u)
  · nlinarith only [hsum,hbudget,mul_le_mul_of_nonneg_left hTrow hp,h₁,hid]
  · linarith

end
end SubmodularMatching.TwoLayerDiffuse
