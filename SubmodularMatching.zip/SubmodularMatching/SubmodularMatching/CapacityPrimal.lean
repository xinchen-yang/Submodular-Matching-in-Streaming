import SubmodularMatching.NonmonotoneSourceComparator
import Mathlib.Topology.Order.Compact

/-! # Attainment of the finite source LP used in capacity averaging -/

namespace SubmodularMatching.SourceCertificate.Asymmetric
open Set
open scoped BigOperators
noncomputable section

variable {E V : Type*} [Fintype E] [Fintype V] [DecidableEq E] [DecidableEq V]

theorem objectiveValues_sSup_mem (D : Shape) (I : V → Bool) (ends : E → V × V)
    (p : ℝ) (hp : 0 ≤ p) (S : Finset E) (w : E → ℝ) :
    sSup (objectiveValues D I ends p S w) ∈ objectiveValues D I ends p S w := by
  classical
  let cap := fun e => p * D.edge (I (ends e).1) (I (ends e).2)
  let loads : Set (E → ℝ) := ⋂ v, {z | Joint.degree ends z v ≤ D.vertex (I v)}
  let support : Set (E → ℝ) := ⋂ e : {e // e ∉ S}, {z | z e = 0}
  let box : Set (E → ℝ) := Icc (fun _ => 0) cap
  let A := (box ∩ loads) ∩ support
  let L := fun z : E → ℝ => ∑ e, w e * z e
  have hL : Continuous L := by unfold L; fun_prop
  have hl : IsClosed loads := by
    refine isClosed_iInter fun v => isClosed_le ?_ continuous_const
    unfold Joint.degree
    fun_prop
  have hs : IsClosed support := isClosed_iInter fun e => isClosed_eq (continuous_apply e.val) continuous_const
  have hcompact : IsCompact A := (isCompact_Icc.inter_right hl).inter_right hs
  have he : objectiveValues D I ends p S w = L '' A := by
    ext r
    constructor
    · rintro ⟨z,hz,hv,hn,rfl⟩
      exact ⟨z,⟨⟨⟨fun e => (hz e).1, fun e => (hz e).2⟩,
        mem_iInter.mpr hv⟩,mem_iInter.mpr (fun e => hn e.val e.property)⟩,rfl⟩
    · rintro ⟨z,⟨⟨⟨hzlo,hzhi⟩,hv⟩,hn⟩,rfl⟩
      exact ⟨z,fun e => ⟨hzlo e,hzhi e⟩,mem_iInter.mp hv,
        fun e he => mem_iInter.mp hn ⟨e,he⟩,rfl⟩
  have hnonempty : (objectiveValues D I ends p S w).Nonempty := by
    refine ⟨0, (fun _ => 0),fun e => ⟨le_rfl,mul_nonneg hp (D.edge_nonneg _ _)⟩,?_,fun _ _ => rfl,?_⟩
    · intro v
      simpa [Joint.degree] using D.vertex_nonneg (I v)
    · simp
  rw [he] at hnonempty ⊢
  exact (hcompact.image hL).sSup_mem hnonempty

end
end SubmodularMatching.SourceCertificate.Asymmetric
