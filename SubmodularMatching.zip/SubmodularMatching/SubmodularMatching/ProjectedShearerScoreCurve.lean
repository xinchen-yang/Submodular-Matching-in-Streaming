import SubmodularMatching.ProjectedShearerThinning

/-! # The expected score decreases with the priority threshold -/

namespace SubmodularMatching.Shearer

open GibbsMatching

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

private theorem thinList_mono_test (p : E → ℝ) (hp : ∀ a, p a ∈ Set.Icc 0 1)
    (es : List E) {f g : Finset E → ℝ} (hfg : ∀ A, f A ≤ g A) :
    ∀ A, thinList p es f A ≤ thinList p es g A := by
  induction es with
  | nil => exact hfg
  | cons e es ih =>
    intro A
    exact add_le_add (mul_le_mul_of_nonneg_left (ih _) (sub_nonneg.mpr (hp e).2))
      (mul_le_mul_of_nonneg_left (ih _) (hp e).1)

private theorem thinList_antitone_test (p : E → ℝ) (hp : ∀ a, p a ∈ Set.Icc 0 1)
    (es : List E) (f : Finset E → ℝ) (hf : Antitone f) :
    Antitone (thinList p es f) := by
  induction es with
  | nil => exact hf
  | cons e es ih =>
    intro A B hAB
    exact add_le_add (mul_le_mul_of_nonneg_left (ih (Finset.erase_subset_erase _ hAB)) (sub_nonneg.mpr (hp e).2))
      (mul_le_mul_of_nonneg_left (ih hAB) (hp e).1)

/-- Increasing all retention probabilities can only decrease the mean
of a decreasing observable, for each fixed original matching. -/
theorem thinList_antitone_prob (p q : E → ℝ) (hp : ∀ a, p a ∈ Set.Icc 0 1)
    (hq : ∀ a, q a ∈ Set.Icc 0 1) (hpq : ∀ a, p a ≤ q a)
    (es : List E) (f : Finset E → ℝ) (hf : Antitone f) (A : Finset E) :
    thinList q es f A ≤ thinList p es f A := by
  induction es generalizing A with
  | nil => rfl
  | cons e es ih =>
    have hdec := thinList_antitone_test p hp es f hf (Finset.erase_subset e A)
    have hmul := mul_nonneg (sub_nonneg.mpr (hpq e)) (sub_nonneg.mpr hdec)
    calc
      thinList q (e::es) f A ≤ (1-q e)*thinList p es f (A.erase e) + q e*thinList p es f A :=
        add_le_add (mul_le_mul_of_nonneg_left (ih _) (sub_nonneg.mpr (hq e).2))
          (mul_le_mul_of_nonneg_left (ih _) (hq e).1)
      _ ≤ thinList p (e::es) f A := by
        change _ ≤ (1-p e)*thinList p es f (A.erase e) + p e*thinList p es f A
        linarith only [hmul]

private theorem interior_mono {ends : E → Finset V} {S : Finset E} {x : E → ℝ}
    (hx : InteriorLaw ends S x) {f g : Finset E → ℝ} (hfg : ∀ A, f A ≤ g A) :
    expectation ends S x f ≤ expectation ends S x g := by
  unfold expectation
  exact Finset.sum_le_sum (fun M hM => mul_le_mul_of_nonneg_left (hfg M) (hx.nonneg M hM))

/-- Common mean score of a copy, expressed under the two independent
outside Shearer laws. If both priority thresholds increase, its mean
can only decrease. `f` may be the positive marginal of a repeated label. -/
theorem mean_score_antitone (ends : E → Finset V) (C : Finset E) (x y : E → ℝ)
    (hx : InteriorLaw ends C x) (hy : InteriorLaw ends C y)
    (p q p' q' : E → ℝ) (hp : ∀ a, p a ∈ Set.Icc 0 1) (hq : ∀ a, q a ∈ Set.Icc 0 1)
    (hp' : ∀ a, p' a ∈ Set.Icc 0 1) (hq' : ∀ a, q' a ∈ Set.Icc 0 1)
    (hpq : ∀ a, p a ≤ p' a) (hqq : ∀ a, q a ≤ q' a)
    (f : Finset E → ℝ) (hf : Antitone f) :
    expectation ends C (fun a => p' a*x a) (fun A =>
      expectation ends C (fun b => q' b*y b) (fun B => f (A ∪ B))) ≤
    expectation ends C (fun a => p a*x a) (fun A =>
      expectation ends C (fun b => q b*y b) (fun B => f (A ∪ B))) := by
  let g (rate : E → ℝ) (A : Finset E) := expectation ends C y
    (thinList rate C.toList (fun B => f (A ∪ B)))
  have ganti : Antitone (g q) := by
    intro A B hAB
    exact interior_mono hy (thinList_mono_test q hq C.toList (fun T => hf (Finset.union_subset_union_left hAB)))
  have gle (A : Finset E) : g q' A ≤ g q A := by
    apply interior_mono hy
    apply thinList_antitone_prob q q' hq hq' hqq _ _
    exact fun U T hUT => hf (Finset.union_subset_union_right hUT)
  simp_rw [← thinSupport_law ends C y]
  change expectation ends C (fun a => p' a*x a) (g q') ≤ expectation ends C (fun a => p a*x a) (g q)
  rw [← thinSupport_law ends C x, ← thinSupport_law ends C x]
  apply interior_mono hx
  intro A
  exact (thinList_mono_test p' hp' C.toList gle A).trans
    (thinList_antitone_prob p p' hp hp' hpq C.toList (g q) ganti A)

end SubmodularMatching.Shearer
