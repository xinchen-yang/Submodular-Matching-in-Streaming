import SubmodularMatching.UpperBoundVertexCandidate

/-! # Exact rational arithmetic in compact two-stage rounding -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint TwoStage NumericalCertificate
open GibbsMatching (calibratedActivity referenceMonomer vertexLoad neighborActivity unmatched)
open LinearPacking (OnGrid)
open scoped BigOperators

noncomputable section

variable {m : ℕ} {V : Type*} [Fintype V] [DecidableEq V]

/-- The exact pair formula is quadratic in the common grid numerators.
The triangle term is a sum of products on that same squared grid. -/
theorem pairProbability_onGrid (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (Q : ℕ) (y : Fin m → ℝ)
    (hy : ∀ e, OnGrid Q (y e)) (u v : V) (huv : u ≠ v) :
    OnGrid (Q ^ 2) (pairProbability ends y u v) := by
  let S : Finset (Fin m) := Finset.univ
  let A := pairEnds ends
  have hdegree (v : V) : OnGrid Q (Shearer.vertexDegree A S y v) := by
    unfold Shearer.vertexDegree
    exact OnGrid.sum _ _ fun e _ => hy e
  have hneighbor (v w : V) : OnGrid Q (neighborActivity A S y v w) := by
    unfold neighborActivity
    apply OnGrid.sum
    intro e _
    split_ifs
    · exact hy e
    · exact OnGrid.zero _
  have htriangle : OnGrid (Q * Q) (Shearer.triangleCorrection A S y u v) := by
    unfold Shearer.triangleCorrection
    exact OnGrid.sum _ _ fun w _ => (hneighbor u w).mul (hneighbor v w)
  unfold pairProbability Shearer.unmatchedPair
  rw [Shearer.unmatched_pair_triangle _ _ y (fun e _ => pairEnds_card_two ends hloop e) u v huv, pow_two]
  let one : OnGrid Q (1 : ℝ) := by exact ⟨Q, by simp⟩
  exact (((one.sub (hdegree u)).mul (one.sub (hdegree v))).add
    ((hneighbor u v).mul (((one.sub (hdegree u)).sub (hdegree v)).add (hneighbor u v)))).sub htriangle

omit [Fintype V] in
/-- A feasible point at the fixed rounding degree gives genuine nonzero
pair probabilities bounded by one. -/
theorem appendixPairProbability_bounds (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (x y : Fin m → ℝ)
    (hxy : Feasible coordinateCap NumericalCertificate.degree ends ends x y) (u v : V) :
    0 < pairProbability ends y u v ∧ pairProbability ends y u v ≤ 1 := by
  let A := pairEnds ends
  let S : Finset (Fin m) := Finset.univ
  have hr0 : 0 < sampler := (by norm_num : (0 : ℝ) < 1 / 2).trans sampler_bounds.1
  have hy : ∀ e ∈ S, 0 ≤ y e := fun e _ => hxy.y_nonneg e
  have he : ∀ e ∈ S, (A e).card = 2 := fun e _ => pairEnds_card_two ends hloop e
  have hdegree (v : V) : Shearer.vertexDegree A S y v ≤ sampler * (1 - sampler) := by
    rw [← show NumericalCertificate.degree = sampler * (1 - sampler) from rfl]
    exact (vertexDegree_pairEnds ends y v).le.trans (hxy.y_degree v)
  constructor
  · have hl := Shearer.unmatchedPair_union_bound A S y sampler hr0 sampler_bounds.2.le
      hy he hdegree u v
    change _ ≤ pairProbability ends y u v at hl
    have hu := hdegree u
    have hv := hdegree v
    change Shearer.vertexDegree A S y u ≤ NumericalCertificate.degree at hu
    change Shearer.vertexDegree A S y v ≤ NumericalCertificate.degree at hv
    linarith only [hl, hu, hv, degree_bounds.2]
  · change Shearer.expectation A S y (fun M => unmatched A u M * unmatched A v M) ≤ 1
    rw [← Shearer.expectation_const A S y 1]
    apply Shearer.expectation_mono A S y sampler hr0 sampler_bounds.2.le hy he hdegree
    intro M _
    exact mul_le_one₀ (GibbsMatching.unmatched_bounds A u M).2
      (GibbsMatching.unmatched_bounds A v M).1 (GibbsMatching.unmatched_bounds A v M).2

/-- Denominator of the common mesh for compensated edge weights. -/
def appendixCompensatedDenominator (m : ℕ) : ℕ := 80000000000 * m

theorem appendixCompensatedMesh_eq (hm : 0 < m) :
    finiteError / (8 * (m : ℝ)) = 1 / (appendixCompensatedDenominator m : ℝ) := by
  have hm' : (m : ℝ) ≠ 0 := by exact_mod_cast hm.ne'
  unfold appendixCompensatedDenominator
  norm_num [finiteError, Nat.cast_mul]
  field_simp; norm_num

private theorem floorOnGrid_recip_onGrid (d : ℕ) (hd : 0 < d) (x : ℝ) :
    OnGrid d (floorOnGrid (1 / (d : ℝ)) x) := by
  have hd' : (d : ℝ) ≠ 0 := by exact_mod_cast hd.ne'
  exact ⟨_, by rw [floorOnGrid, ← mul_assoc, mul_one_div_cancel hd', one_mul]⟩

/-- The actual rounded vectors use a common polynomial grid. The
compensated coordinates are stored on the smaller mesh, independently
of the pair probabilities. -/
theorem appendixRoundedPoint_xy_grids (hm : 0 < m) (ends : Fin m → V × V)
    (hloop : ∀ e, (ends e).1 ≠ (ends e).2) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) {N : ℕ} (Q : ℕ) (draw : AppendixDraw m N) (e : Fin m) :
    let t := appendixRoundedPoint ends tau w f Q draw
    let d := appendixShearerDenominator (Fintype.card V) m
    let mesh := appendixCompensatedDenominator m
    OnGrid d (t.2 e) ∧ OnGrid (d ^ 2 * mesh) (t.1 e) ∧
      OnGrid mesh (compensatedEdge ends t.1 t.2 e) := by
  intro t d mesh
  have hy (e : Fin m) : OnGrid d (t.2 e) := appendixRoundedPoint_y_grid hm ends tau w f Q draw e
  have hxy : Feasible coordinateCap NumericalCertificate.degree ends ends t.1 t.2 :=
    appendixRoundedPoint_feasible hm ends hloop tau w f Q draw
  let q := pairProbability ends t.2 (ends e).1 (ends e).2
  have hq : OnGrid (d ^ 2) q := pairProbability_onGrid ends hloop d t.2 hy _ _ (hloop e)
  have hq0 : 0 < q := (appendixPairProbability_bounds ends hloop t.1 t.2 hxy _ _).1
  have hm0 : 0 < mesh := Nat.mul_pos (by decide) hm
  let c := oracleCoefficient NumericalCertificate.degree tau finiteError Q f draw
  let z := sampledPoint coordinateCap NumericalCertificate.degree tau finiteError ends w c
    (FiniteGreedy.stages NumericalCertificate.degree m finiteError)
  let a := floorOnGrid (1 / (mesh : ℝ)) ((coordinateCap * z (.inl e)) / q)
  have ha : OnGrid mesh a := floorOnGrid_recip_onGrid mesh hm0 _
  have hx : t.1 e = q * a := by
    simp only [t, appendixRoundedPoint, roundedSampledPoint, gridCoordinate, appendixCompensatedMesh_eq hm]
    rfl
  have hc : compensatedEdge ends t.1 t.2 e = a := by
    change t.1 e / q = a
    rw [hx, mul_div_cancel_left₀ _ hq0.ne']
  rw [hx, hc]
  exact ⟨hy e, hq.mul ha, ha⟩

/-- Division by the fixed alteration scale retains a common grid. -/
def appendixAlteredDenominator (m : ℕ) : ℕ := appendixCompensatedDenominator m * 400000001

omit [Fintype V] in
theorem appendixShearerAltered_onGrid (ends : Fin m → V × V) (x y : Fin m → ℝ)
    (ha : ∀ e, OnGrid (appendixCompensatedDenominator m) (compensatedEdge ends x y e))
    (T : Finset (Fin m)) (e : Fin m) :
    OnGrid (appendixAlteredDenominator m)
      (shearerAltered ends x y (NumericalCertificate.roundingError / 4) T e) := by
  have hscale : OnGrid 400000001 (1 / (1 + NumericalCertificate.roundingError / 4)) := by
    exact ⟨400000000, by norm_num [NumericalCertificate.roundingError]⟩
  unfold shearerAltered altered
  split_ifs
  · simpa only [appendixAlteredDenominator, mul_one_div] using (ha e).mul hscale
  · exact OnGrid.zero _

end

end SubmodularMatching.UpperBoundAssembly
