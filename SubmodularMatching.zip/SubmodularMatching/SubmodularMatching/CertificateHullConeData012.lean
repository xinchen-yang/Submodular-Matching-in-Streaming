import SubmodularMatching.CertificateHullConeTable
import SubmodularMatching.CertificateConeTable

namespace SubmodularMatching.SourceCertificate.Replay

set_option maxRecDepth 20000
set_option maxHeartbeats 0

private def hull012_000 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 620, 638, 5, 0x13f27b4f49cd3926c⟩ (by decide +kernel)

private def hull012_001 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 620, 629, 3, 0x4ea9cd3926c⟩ (by decide +kernel)

private def hull012_002 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 629, 630, 1, 0x13b275⟩ (by decide +kernel)

private def hull012_003 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 630, 631, 1, 0x13ba76⟩ (by decide +kernel)

private def hull012_004 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 631, 633, 1, 0x13ca77⟩ (by decide +kernel)

private def hull012_005 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 633, 638, 3, 0x4fc9ed3d279⟩ (by decide +kernel)

private def hull012_006 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 629, 631, 1, 0x13ba75⟩ (by decide +kernel)

private def hull012_007 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 567, 851, 49, 0x1a9b4d698d2195b2a61ec3185af95f0b9d72ae45c6b716dada5b2b5d6b2d55a8b4d622c2582afd5f2ab554a9d53295528a4948a895109fd3f27b4f49cd392624c29812fa37⟩ (by decide +kernel)

private def hull012_008 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 629, 633, 1, 0x13ca75⟩ (by decide +kernel)

private def hull012_009 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 631, 632, 1, 0x13c277⟩ (by decide +kernel)

private def hull012_010 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 632, 633, 1, 0x13ca78⟩ (by decide +kernel)

private def hull012_011 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 629, 638, 3, 0x4fc9ed3d275⟩ (by decide +kernel)

private def hull012_012 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 633, 634, 1, 0x13d279⟩ (by decide +kernel)

private def hull012_013 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 634, 635, 1, 0x13da7a⟩ (by decide +kernel)

private def hull012_014 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 635, 638, 1, 0x13f27b⟩ (by decide +kernel)

private def hull012_015 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 633, 635, 2, 0x9ed3d279⟩ (by decide +kernel)

private def hull012_016 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 12, 17, 5, 0x881001e0380680c⟩ (by decide +kernel)

private def hull012_017 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 635, 636, 1, 0x13e27b⟩ (by decide +kernel)

private def hull012_018 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 636, 638, 1, 0x13f27c⟩ (by decide +kernel)

private def hull012_019 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 636, 637, 1, 0x13ea7c⟩ (by decide +kernel)

private def hull012_020 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 637, 638, 1, 0x13f27d⟩ (by decide +kernel)

private def hull012_021 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 567, 709, 26, 0xb15622c2582afd5f2ab554a9d53295528a4948a895109fd3f27b4f49cd392624c29812fa37⟩ (by decide +kernel)

private def hull012_022 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 70, 61, 0x2304508810c210410800fc1f03d0780ec1d0390700dc1b0350680cc190310600bc1702d0580ac1502905009c1302504808c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull012_023 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 567, 638, 9, 0x13f27b4f49cd392624c29812fa37⟩ (by decide +kernel)

private def hull012_024 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 638, 640, 2, 0xa013fa7e⟩ (by decide +kernel)

private def hull012_025 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 640, 642, 1, 0x141280⟩ (by decide +kernel)

private def hull012_026 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 642, 646, 1, 0x143282⟩ (by decide +kernel)

private def hull012_027 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 646, 655, 3, 0x51ea2544286⟩ (by decide +kernel)

private def hull012_028 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 655, 673, 6, 0xa854aa94524a454828f⟩ (by decide +kernel)

private def hull012_029 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 673, 709, 10, 0xb15622c2582afd5f2ab554a9d532a1⟩ (by decide +kernel)

private def hull012_030 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 638, 642, 3, 0x504a013fa7e⟩ (by decide +kernel)

private def hull012_031 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 638, 646, 2, 0xa193fa7e⟩ (by decide +kernel)

private def hull012_032 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 640, 641, 1, 0x140a80⟩ (by decide +kernel)

private def hull012_033 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 641, 642, 1, 0x141281⟩ (by decide +kernel)

private def hull012_034 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 638, 709, 17, 0x162ac4584b055fabe556aa953aa652aa5149291512a213fa7e⟩ (by decide +kernel)

private def hull012_035 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 642, 643, 1, 0x141a82⟩ (by decide +kernel)

private def hull012_036 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 643, 644, 1, 0x142283⟩ (by decide +kernel)

private def hull012_037 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 644, 646, 1, 0x143284⟩ (by decide +kernel)

private def hull012_038 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 14, 17, 3, 0x220400780e⟩ (by decide +kernel)

private def hull012_039 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 0, 35, 26, 0x8c1102104007c0f01d03806c0d01903005c0b01502804c0901102003c0700d01802001800⟩ (by decide +kernel)

private def hull012_040 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 642, 644, 2, 0xa1141a82⟩ (by decide +kernel)

private def hull012_041 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 644, 645, 1, 0x142a84⟩ (by decide +kernel)

private def hull012_042 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 645, 646, 1, 0x143285⟩ (by decide +kernel)

private def hull012_043 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 646, 647, 1, 0x143a86⟩ (by decide +kernel)

private def hull012_044 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 647, 648, 1, 0x144287⟩ (by decide +kernel)

private def hull012_045 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 648, 650, 2, 0xa2944a88⟩ (by decide +kernel)

private def hull012_046 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 650, 655, 1, 0x147a8a⟩ (by decide +kernel)

private def hull012_047 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 646, 648, 1, 0x144286⟩ (by decide +kernel)

private def hull012_048 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 646, 650, 3, 0x514a2544286⟩ (by decide +kernel)

private def hull012_049 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 638, 655, 4, 0x28f512a213fa7e⟩ (by decide +kernel)

private def hull012_050 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 648, 649, 1, 0x144a88⟩ (by decide +kernel)

private def hull012_051 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 649, 650, 1, 0x145289⟩ (by decide +kernel)

private def hull012_052 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 650, 651, 1, 0x145a8a⟩ (by decide +kernel)

private def hull012_053 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 651, 652, 1, 0x14628b⟩ (by decide +kernel)

private def hull012_054 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 652, 655, 1, 0x147a8c⟩ (by decide +kernel)

private def hull012_055 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 650, 652, 1, 0x14628a⟩ (by decide +kernel)

private def hull012_056 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 13, 14, 1, 0x700d⟩ (by decide +kernel)

private def hull012_057 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 652, 653, 1, 0x146a8c⟩ (by decide +kernel)

private def hull012_058 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 653, 655, 1, 0x147a8d⟩ (by decide +kernel)

private def hull012_059 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 653, 654, 1, 0x14728d⟩ (by decide +kernel)

private def hull012_060 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 654, 655, 1, 0x147a8e⟩ (by decide +kernel)

private def hull012_061 : CheckedAppendixHull :=
  checkedAppendixHull ⟨false, 638, 673, 8, 0x2a152aa5149291512a213fa7e⟩ (by decide +kernel)

private def supportedCone1536 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨620, 638, 627, 626, 634⟩, ⟨2429177183, 5054005, 22570822817, 49326381, 1832429177183, 668015138775⟩⟩
    hull012_000 2 (by decide +kernel)

private def supportedCone1537 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨620, 629, 627, 626, 629⟩, ⟨2429177183, 5054005, 5651997101, 12481586, 1832429177183, 668015138775⟩⟩
    hull012_001 2 (by decide +kernel)

private def supportedCone1538 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨620, 638, 626, 620, 627⟩, ⟨20000000000, 37492545, 2429177183, 5054005, 1830000000000, 668010084770⟩⟩
    hull012_000 1 (by decide +kernel)

private def supportedCone1539 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨629, 630, 629, 629, 630⟩, ⟨0, 0, 1918825716, 4225327, 1838081174284, 668027620361⟩⟩
    hull012_002 0 (by decide +kernel)

private def supportedCone1540 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨630, 631, 630, 630, 631⟩, ⟨0, 0, 5000000000, 10942439, 1840000000000, 668031845688⟩⟩
    hull012_003 0 (by decide +kernel)

private def supportedCone1541 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨631, 633, 631, 631, 633⟩, ⟨0, 0, 7387709390, 16041402, 1845000000000, 668042788127⟩⟩
    hull012_004 0 (by decide +kernel)

private def supportedCone1542 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨633, 638, 633, 633, 634⟩, ⟨0, 0, 2612290610, 5635627, 1852387709390, 668058829529⟩⟩
    hull012_005 0 (by decide +kernel)

private def supportedCone1543 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨629, 630, 630, 629, 630⟩, ⟨1918825716, 4225327, 0, 0, 1840000000000, 668031845688⟩⟩
    hull012_002 1 (by decide +kernel)

private def supportedCone1544 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨629, 631, 629, 629, 631⟩, ⟨0, 0, 6918825716, 15167766, 1838081174284, 668027620361⟩⟩
    hull012_006 0 (by decide +kernel)

private def supportedCone1545 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨629, 631, 631, 629, 631⟩, ⟨6918825716, 15167766, 0, 0, 1845000000000, 668042788127⟩⟩
    hull012_006 1 (by decide +kernel)

private def supportedCone1546 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨630, 631, 631, 630, 631⟩, ⟨5000000000, 10942439, 0, 0, 1845000000000, 668042788127⟩⟩
    hull012_003 1 (by decide +kernel)

private def supportedCone1547 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 610, 609, 626⟩, ⟨2361575092, 3680252, 45000000000, 85680828, 1785000000000, 667924403942⟩⟩
    hull012_007 4 (by decide +kernel)

private def supportedCone1548 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨629, 633, 629, 629, 633⟩, ⟨0, 0, 14306535106, 31209168, 1838081174284, 668027620361⟩⟩
    hull012_008 0 (by decide +kernel)

private def supportedCone1549 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨629, 633, 633, 629, 633⟩, ⟨14306535106, 31209168, 0, 0, 1852387709390, 668058829529⟩⟩
    hull012_008 1 (by decide +kernel)

private def supportedCone1550 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨631, 632, 631, 631, 632⟩, ⟨0, 0, 5000000000, 10874012, 1845000000000, 668042788127⟩⟩
    hull012_009 0 (by decide +kernel)

private def supportedCone1551 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨632, 633, 632, 632, 633⟩, ⟨0, 0, 2387709390, 5167390, 1850000000000, 668053662139⟩⟩
    hull012_010 0 (by decide +kernel)

private def supportedCone1552 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨631, 632, 632, 631, 632⟩, ⟨5000000000, 10874012, 0, 0, 1850000000000, 668053662139⟩⟩
    hull012_009 1 (by decide +kernel)

private def supportedCone1553 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨631, 633, 633, 631, 633⟩, ⟨7387709390, 16041402, 0, 0, 1852387709390, 668058829529⟩⟩
    hull012_004 1 (by decide +kernel)

private def supportedCone1554 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨632, 633, 633, 632, 633⟩, ⟨2387709390, 5167390, 0, 0, 1852387709390, 668058829529⟩⟩
    hull012_010 1 (by decide +kernel)

private def supportedCone1555 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨629, 638, 634, 629, 635⟩, ⟨16918825716, 36844795, 5000000000, 16753570, 1855000000000, 668064465156⟩⟩
    hull012_011 1 (by decide +kernel)

private def supportedCone1556 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨633, 634, 633, 633, 634⟩, ⟨0, 0, 2612290610, 5635627, 1852387709390, 668058829529⟩⟩
    hull012_012 0 (by decide +kernel)

private def supportedCone1557 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨634, 635, 634, 634, 635⟩, ⟨0, 0, 5000000000, 16753570, 1855000000000, 668064465156⟩⟩
    hull012_013 0 (by decide +kernel)

private def supportedCone1558 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨635, 638, 635, 635, 638⟩, ⟨0, 0, 10000000000, 38701957, 1860000000000, 668081218726⟩⟩
    hull012_014 0 (by decide +kernel)

private def supportedCone1559 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨633, 634, 634, 633, 634⟩, ⟨2612290610, 5635627, 0, 0, 1855000000000, 668064465156⟩⟩
    hull012_012 1 (by decide +kernel)

private def supportedCone1560 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨633, 635, 634, 633, 635⟩, ⟨2612290610, 5635627, 5000000000, 16753570, 1855000000000, 668064465156⟩⟩
    hull012_015 1 (by decide +kernel)

private def supportedCone1561 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨633, 635, 633, 633, 634⟩, ⟨0, 0, 2612290610, 5635627, 1852387709390, 668058829529⟩⟩
    hull012_015 0 (by decide +kernel)

private def supportedCone1562 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨633, 635, 635, 634, 635⟩, ⟨5000000000, 16753570, 0, 0, 1860000000000, 668081218726⟩⟩
    hull012_015 2 (by decide +kernel)

private def supportedCone1563 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 634, 627, 635⟩, ⟨22570822817, 49326381, 5000000000, 16753570, 1855000000000, 668064465156⟩⟩
    hull012_007 7 (by decide +kernel)

private def supportedCone1564 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨12, 17, 16, 15, 17⟩, ⟨898601210, 7551393, 1516608462, 14915504, 235898601210, 23049927⟩⟩
    hull012_016 4 (by decide +kernel)

private def supportedCone1565 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨634, 635, 635, 634, 635⟩, ⟨5000000000, 16753570, 0, 0, 1860000000000, 668081218726⟩⟩
    hull012_013 1 (by decide +kernel)

private def supportedCone1566 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨633, 638, 635, 634, 638⟩, ⟨5000000000, 16753570, 10000000000, 38701957, 1860000000000, 668081218726⟩⟩
    hull012_005 2 (by decide +kernel)

private def supportedCone1567 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨635, 636, 635, 635, 636⟩, ⟨0, 0, 5000000000, 19425890, 1860000000000, 668081218726⟩⟩
    hull012_017 0 (by decide +kernel)

def appendixHullConeBlock0048 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1536,
    supportedCone1537,
    supportedCone1538,
    supportedCone1539,
    supportedCone1540,
    supportedCone1541,
    supportedCone1542,
    supportedCone1543,
    supportedCone1544,
    supportedCone1545,
    supportedCone1546,
    supportedCone1547,
    supportedCone1548,
    supportedCone1549,
    supportedCone1550,
    supportedCone1551,
    supportedCone1552,
    supportedCone1553,
    supportedCone1554,
    supportedCone1555,
    supportedCone1556,
    supportedCone1557,
    supportedCone1558,
    supportedCone1559,
    supportedCone1560,
    supportedCone1561,
    supportedCone1562,
    supportedCone1563,
    supportedCone1564,
    supportedCone1565,
    supportedCone1566,
    supportedCone1567,
  ], rfl⟩

private def supportedCone1568 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨636, 638, 636, 636, 638⟩, ⟨0, 0, 5000000000, 19276067, 1865000000000, 668100644616⟩⟩
    hull012_018 0 (by decide +kernel)

private def supportedCone1569 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨635, 636, 636, 635, 636⟩, ⟨5000000000, 19425890, 0, 0, 1865000000000, 668100644616⟩⟩
    hull012_017 1 (by decide +kernel)

private def supportedCone1570 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨635, 638, 638, 635, 638⟩, ⟨10000000000, 38701957, 0, 0, 1870000000000, 668119920683⟩⟩
    hull012_014 1 (by decide +kernel)

private def supportedCone1571 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨636, 638, 638, 636, 638⟩, ⟨5000000000, 19276067, 0, 0, 1870000000000, 668119920683⟩⟩
    hull012_018 1 (by decide +kernel)

private def supportedCone1572 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨636, 637, 637, 636, 637⟩, ⟨1951898345, 7532708, 0, 0, 1866951898345, 668108177324⟩⟩
    hull012_019 1 (by decide +kernel)

private def supportedCone1573 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨637, 638, 637, 637, 638⟩, ⟨0, 0, 3048101655, 11743359, 1866951898345, 668108177324⟩⟩
    hull012_020 0 (by decide +kernel)

private def supportedCone1574 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 709, 638, 635, 639⟩, ⟨10000000000, 38701957, 2851281754, 12222461, 1870000000000, 668119920683⟩⟩
    hull012_021 9 (by decide +kernel)

private def supportedCone1575 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨637, 638, 638, 637, 638⟩, ⟨3048101655, 11743359, 0, 0, 1870000000000, 668119920683⟩⟩
    hull012_020 1 (by decide +kernel)

private def supportedCone1576 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 638, 635, 639⟩, ⟨10000000000, 38701957, 2851281754, 12222461, 1870000000000, 668119920683⟩⟩
    hull012_007 9 (by decide +kernel)

private def supportedCone1577 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 14, 13, 15⟩, ⟨1662166960, 7812264, 830797927, 5172745, 234169202073, 10325789⟩⟩
    hull012_022 5 (by decide +kernel)

private def supportedCone1578 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 709, 635, 634, 638⟩, ⟨5000000000, 16753570, 10000000000, 38701957, 1860000000000, 668081218726⟩⟩
    hull012_021 8 (by decide +kernel)

private def supportedCone1579 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 639, 638, 648⟩, ⟨2851281754, 12222461, 37148718246, 190604191, 1872851281754, 668132143144⟩⟩
    hull012_007 10 (by decide +kernel)

private def supportedCone1580 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 638, 638, 635, 638⟩, ⟨10000000000, 38701957, 0, 0, 1870000000000, 668119920683⟩⟩
    hull012_023 9 (by decide +kernel)

private def supportedCone1581 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 640, 639, 638, 640⟩, ⟨2851281754, 12222461, 2148718246, 11126753, 1872851281754, 668132143144⟩⟩
    hull012_024 1 (by decide +kernel)

private def supportedCone1582 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨640, 642, 640, 640, 642⟩, ⟨0, 0, 10000000000, 52044924, 1875000000000, 668143269897⟩⟩
    hull012_025 0 (by decide +kernel)

private def supportedCone1583 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨642, 646, 642, 642, 646⟩, ⟨0, 0, 15000000000, 76922502, 1885000000000, 668195314821⟩⟩
    hull012_026 0 (by decide +kernel)

private def supportedCone1584 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 655, 646, 646, 648⟩, ⟨0, 0, 10000000000, 50510012, 1900000000000, 668272237323⟩⟩
    hull012_027 0 (by decide +kernel)

private def supportedCone1585 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨655, 673, 655, 655, 656⟩, ⟨0, 0, 2528500363, 13077399, 1937471499637, 668466970362⟩⟩
    hull012_028 0 (by decide +kernel)

private def supportedCone1586 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨673, 709, 673, 673, 678⟩, ⟨0, 0, 20000000000, 146772953, 2015000000000, 669022360413⟩⟩
    hull012_029 0 (by decide +kernel)

private def supportedCone1587 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 642, 639, 638, 640⟩, ⟨2851281754, 12222461, 2148718246, 11126753, 1872851281754, 668132143144⟩⟩
    hull012_030 1 (by decide +kernel)

private def supportedCone1588 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 648, 639, 649⟩, ⟨37148718246, 190604191, 2261924095, 11651883, 1910000000000, 668322747335⟩⟩
    hull012_007 11 (by decide +kernel)

private def supportedCone1589 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 646, 639, 638, 646⟩, ⟨2851281754, 12222461, 27148718246, 140094179, 1872851281754, 668132143144⟩⟩
    hull012_031 1 (by decide +kernel)

private def supportedCone1590 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 642, 640, 639, 642⟩, ⟨2148718246, 11126753, 10000000000, 52044924, 1875000000000, 668143269897⟩⟩
    hull012_030 2 (by decide +kernel)

private def supportedCone1591 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 640, 640, 639, 640⟩, ⟨2148718246, 11126753, 0, 0, 1875000000000, 668143269897⟩⟩
    hull012_024 2 (by decide +kernel)

private def supportedCone1592 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨640, 641, 640, 640, 641⟩, ⟨0, 0, 5000000000, 26113004, 1875000000000, 668143269897⟩⟩
    hull012_032 0 (by decide +kernel)

private def supportedCone1593 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨641, 642, 641, 641, 642⟩, ⟨0, 0, 5000000000, 25931920, 1880000000000, 668169382901⟩⟩
    hull012_033 0 (by decide +kernel)

private def supportedCone1594 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨640, 641, 641, 640, 641⟩, ⟨5000000000, 26113004, 0, 0, 1880000000000, 668169382901⟩⟩
    hull012_032 1 (by decide +kernel)

private def supportedCone1595 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 642, 642, 640, 642⟩, ⟨10000000000, 52044924, 0, 0, 1885000000000, 668195314821⟩⟩
    hull012_030 3 (by decide +kernel)

private def supportedCone1596 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 709, 639, 638, 648⟩, ⟨2851281754, 12222461, 37148718246, 190604191, 1872851281754, 668132143144⟩⟩
    hull012_034 1 (by decide +kernel)

private def supportedCone1597 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨640, 642, 642, 640, 642⟩, ⟨10000000000, 52044924, 0, 0, 1885000000000, 668195314821⟩⟩
    hull012_025 1 (by decide +kernel)

private def supportedCone1598 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨641, 642, 642, 641, 642⟩, ⟨5000000000, 25931920, 0, 0, 1885000000000, 668195314821⟩⟩
    hull012_033 1 (by decide +kernel)

private def supportedCone1599 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨642, 643, 642, 642, 643⟩, ⟨0, 0, 2788043017, 14380915, 1885000000000, 668195314821⟩⟩
    hull012_035 0 (by decide +kernel)

def appendixHullConeBlock0049 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1568,
    supportedCone1569,
    supportedCone1570,
    supportedCone1571,
    supportedCone1572,
    supportedCone1573,
    supportedCone1574,
    supportedCone1575,
    supportedCone1576,
    supportedCone1577,
    supportedCone1578,
    supportedCone1579,
    supportedCone1580,
    supportedCone1581,
    supportedCone1582,
    supportedCone1583,
    supportedCone1584,
    supportedCone1585,
    supportedCone1586,
    supportedCone1587,
    supportedCone1588,
    supportedCone1589,
    supportedCone1590,
    supportedCone1591,
    supportedCone1592,
    supportedCone1593,
    supportedCone1594,
    supportedCone1595,
    supportedCone1596,
    supportedCone1597,
    supportedCone1598,
    supportedCone1599,
  ], rfl⟩

private def supportedCone1600 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨643, 644, 643, 643, 644⟩, ⟨0, 0, 2211956983, 11415605, 1887788043017, 668209695736⟩⟩
    hull012_036 0 (by decide +kernel)

private def supportedCone1601 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨644, 646, 644, 644, 646⟩, ⟨0, 0, 10000000000, 51125982, 1890000000000, 668221111341⟩⟩
    hull012_037 0 (by decide +kernel)

private def supportedCone1602 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨14, 17, 17, 16, 17⟩, ⟨1516608462, 14915504, 0, 0, 237415209672, 37965431⟩⟩
    hull012_038 3 (by decide +kernel)

private def supportedCone1603 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨14, 17, 15, 14, 16⟩, ⟨830797927, 5172745, 898601210, 7551393, 235000000000, 15498534⟩⟩
    hull012_038 1 (by decide +kernel)

private def supportedCone1604 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 30, 29, 31⟩, ⟨890944115, 29450357, 1605927162, 55162689, 253394072838, 391140221⟩⟩
    hull012_039 21 (by decide +kernel)

private def supportedCone1605 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 646, 646, 639, 646⟩, ⟨27148718246, 140094179, 0, 0, 1900000000000, 668272237323⟩⟩
    hull012_031 2 (by decide +kernel)

private def supportedCone1606 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨642, 644, 644, 643, 644⟩, ⟨2211956983, 11415605, 0, 0, 1890000000000, 668221111341⟩⟩
    hull012_040 2 (by decide +kernel)

private def supportedCone1607 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨642, 644, 642, 642, 643⟩, ⟨0, 0, 2788043017, 14380915, 1885000000000, 668195314821⟩⟩
    hull012_040 0 (by decide +kernel)

private def supportedCone1608 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨642, 643, 643, 642, 643⟩, ⟨2788043017, 14380915, 0, 0, 1887788043017, 668209695736⟩⟩
    hull012_035 1 (by decide +kernel)

private def supportedCone1609 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨642, 644, 643, 642, 644⟩, ⟨2788043017, 14380915, 2211956983, 11415605, 1887788043017, 668209695736⟩⟩
    hull012_040 1 (by decide +kernel)

private def supportedCone1610 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨643, 644, 644, 643, 644⟩, ⟨2211956983, 11415605, 0, 0, 1890000000000, 668221111341⟩⟩
    hull012_036 1 (by decide +kernel)

private def supportedCone1611 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨642, 646, 646, 642, 646⟩, ⟨15000000000, 76922502, 0, 0, 1900000000000, 668272237323⟩⟩
    hull012_026 1 (by decide +kernel)

private def supportedCone1612 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 35, 31, 30, 32⟩, ⟨1605927162, 55162689, 1405628119, 52888125, 255000000000, 446302910⟩⟩
    hull012_039 22 (by decide +kernel)

private def supportedCone1613 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨644, 645, 644, 644, 645⟩, ⟨0, 0, 5000000000, 25627120, 1890000000000, 668221111341⟩⟩
    hull012_041 0 (by decide +kernel)

private def supportedCone1614 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨645, 646, 645, 645, 646⟩, ⟨0, 0, 5000000000, 25498862, 1895000000000, 668246738461⟩⟩
    hull012_042 0 (by decide +kernel)

private def supportedCone1615 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨644, 645, 645, 644, 645⟩, ⟨5000000000, 25627120, 0, 0, 1895000000000, 668246738461⟩⟩
    hull012_041 1 (by decide +kernel)

private def supportedCone1616 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨645, 646, 646, 645, 646⟩, ⟨5000000000, 25498862, 0, 0, 1900000000000, 668272237323⟩⟩
    hull012_042 1 (by decide +kernel)

private def supportedCone1617 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨644, 646, 646, 644, 646⟩, ⟨10000000000, 51125982, 0, 0, 1900000000000, 668272237323⟩⟩
    hull012_037 1 (by decide +kernel)

private def supportedCone1618 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 647, 646, 646, 647⟩, ⟨0, 0, 5000000000, 25362535, 1900000000000, 668272237323⟩⟩
    hull012_043 0 (by decide +kernel)

private def supportedCone1619 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨647, 648, 647, 647, 648⟩, ⟨0, 0, 5000000000, 25147477, 1905000000000, 668297599858⟩⟩
    hull012_044 0 (by decide +kernel)

private def supportedCone1620 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨648, 650, 648, 648, 649⟩, ⟨0, 0, 2261924095, 11651883, 1910000000000, 668322747335⟩⟩
    hull012_045 0 (by decide +kernel)

private def supportedCone1621 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨650, 655, 650, 650, 655⟩, ⟨0, 0, 22471499637, 117969949, 1915000000000, 668349000413⟩⟩
    hull012_046 0 (by decide +kernel)

private def supportedCone1622 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 657, 649, 658⟩, ⟨32738075905, 171633512, 5000000000, 31009380, 1945000000000, 668506032730⟩⟩
    hull012_007 13 (by decide +kernel)

private def supportedCone1623 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 655, 648, 646, 649⟩, ⟨10000000000, 50510012, 2261924095, 11651883, 1910000000000, 668322747335⟩⟩
    hull012_027 1 (by decide +kernel)

private def supportedCone1624 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 647, 647, 646, 647⟩, ⟨5000000000, 25362535, 0, 0, 1905000000000, 668297599858⟩⟩
    hull012_043 1 (by decide +kernel)

private def supportedCone1625 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 648, 646, 646, 648⟩, ⟨0, 0, 10000000000, 50510012, 1900000000000, 668272237323⟩⟩
    hull012_047 0 (by decide +kernel)

private def supportedCone1626 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 655, 655, 649, 655⟩, ⟨25209575542, 132571144, 0, 0, 1937471499637, 668466970362⟩⟩
    hull012_027 3 (by decide +kernel)

private def supportedCone1627 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 660, 658, 661⟩, ⟨10000000000, 67149584, 5000000000, 36936303, 1960000000000, 668604191694⟩⟩
    hull012_007 15 (by decide +kernel)

private def supportedCone1628 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨647, 648, 648, 647, 648⟩, ⟨5000000000, 25147477, 0, 0, 1910000000000, 668322747335⟩⟩
    hull012_044 1 (by decide +kernel)

private def supportedCone1629 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 650, 646, 646, 648⟩, ⟨0, 0, 10000000000, 50510012, 1900000000000, 668272237323⟩⟩
    hull012_048 0 (by decide +kernel)

private def supportedCone1630 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 650, 648, 646, 649⟩, ⟨10000000000, 50510012, 2261924095, 11651883, 1910000000000, 668322747335⟩⟩
    hull012_048 1 (by decide +kernel)

private def supportedCone1631 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 655, 655, 649, 655⟩, ⟨25209575542, 132571144, 0, 0, 1937471499637, 668466970362⟩⟩
    hull012_049 4 (by decide +kernel)

def appendixHullConeBlock0050 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1600,
    supportedCone1601,
    supportedCone1602,
    supportedCone1603,
    supportedCone1604,
    supportedCone1605,
    supportedCone1606,
    supportedCone1607,
    supportedCone1608,
    supportedCone1609,
    supportedCone1610,
    supportedCone1611,
    supportedCone1612,
    supportedCone1613,
    supportedCone1614,
    supportedCone1615,
    supportedCone1616,
    supportedCone1617,
    supportedCone1618,
    supportedCone1619,
    supportedCone1620,
    supportedCone1621,
    supportedCone1622,
    supportedCone1623,
    supportedCone1624,
    supportedCone1625,
    supportedCone1626,
    supportedCone1627,
    supportedCone1628,
    supportedCone1629,
    supportedCone1630,
    supportedCone1631,
  ], rfl⟩

private def supportedCone1632 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 655, 649, 648, 655⟩, ⟨2261924095, 11651883, 25209575542, 132571144, 1912261924095, 668334399218⟩⟩
    hull012_049 3 (by decide +kernel)

private def supportedCone1633 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 655, 648, 639, 649⟩, ⟨37148718246, 190604191, 2261924095, 11651883, 1910000000000, 668322747335⟩⟩
    hull012_049 2 (by decide +kernel)

private def supportedCone1634 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨0, 70, 15, 14, 16⟩, ⟨830797927, 5172745, 898601210, 7551393, 235000000000, 15498534⟩⟩
    hull012_022 6 (by decide +kernel)

private def supportedCone1635 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 650, 649, 648, 650⟩, ⟨2261924095, 11651883, 2738075905, 14601195, 1912261924095, 668334399218⟩⟩
    hull012_048 2 (by decide +kernel)

private def supportedCone1636 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 648, 648, 646, 648⟩, ⟨10000000000, 50510012, 0, 0, 1910000000000, 668322747335⟩⟩
    hull012_047 1 (by decide +kernel)

private def supportedCone1637 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨648, 650, 649, 648, 650⟩, ⟨2261924095, 11651883, 2738075905, 14601195, 1912261924095, 668334399218⟩⟩
    hull012_045 1 (by decide +kernel)

private def supportedCone1638 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨567, 851, 649, 648, 657⟩, ⟨2261924095, 11651883, 32738075905, 171633512, 1912261924095, 668334399218⟩⟩
    hull012_007 12 (by decide +kernel)

private def supportedCone1639 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨648, 650, 650, 649, 650⟩, ⟨2738075905, 14601195, 0, 0, 1915000000000, 668349000413⟩⟩
    hull012_045 2 (by decide +kernel)

private def supportedCone1640 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 650, 650, 649, 650⟩, ⟨2738075905, 14601195, 0, 0, 1915000000000, 668349000413⟩⟩
    hull012_048 3 (by decide +kernel)

private def supportedCone1641 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨648, 649, 649, 648, 649⟩, ⟨2261924095, 11651883, 0, 0, 1912261924095, 668334399218⟩⟩
    hull012_050 1 (by decide +kernel)

private def supportedCone1642 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨649, 650, 649, 649, 650⟩, ⟨0, 0, 2738075905, 14601195, 1912261924095, 668334399218⟩⟩
    hull012_051 0 (by decide +kernel)

private def supportedCone1643 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨649, 650, 650, 649, 650⟩, ⟨2738075905, 14601195, 0, 0, 1915000000000, 668349000413⟩⟩
    hull012_051 1 (by decide +kernel)

private def supportedCone1644 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨646, 655, 649, 648, 655⟩, ⟨2261924095, 11651883, 25209575542, 132571144, 1912261924095, 668334399218⟩⟩
    hull012_027 2 (by decide +kernel)

private def supportedCone1645 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨650, 651, 650, 650, 651⟩, ⟨0, 0, 5000000000, 26520643, 1915000000000, 668349000413⟩⟩
    hull012_052 0 (by decide +kernel)

private def supportedCone1646 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨651, 652, 651, 651, 652⟩, ⟨0, 0, 5000000000, 26357684, 1920000000000, 668375521056⟩⟩
    hull012_053 0 (by decide +kernel)

private def supportedCone1647 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨652, 655, 652, 652, 655⟩, ⟨0, 0, 12471499637, 65091622, 1925000000000, 668401878740⟩⟩
    hull012_054 0 (by decide +kernel)

private def supportedCone1648 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨650, 652, 652, 650, 652⟩, ⟨10000000000, 52878327, 0, 0, 1925000000000, 668401878740⟩⟩
    hull012_055 1 (by decide +kernel)

private def supportedCone1649 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨650, 652, 650, 650, 652⟩, ⟨0, 0, 10000000000, 52878327, 1915000000000, 668349000413⟩⟩
    hull012_055 0 (by decide +kernel)

private def supportedCone1650 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨650, 651, 651, 650, 651⟩, ⟨5000000000, 26520643, 0, 0, 1920000000000, 668375521056⟩⟩
    hull012_052 1 (by decide +kernel)

private def supportedCone1651 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨651, 652, 652, 651, 652⟩, ⟨5000000000, 26357684, 0, 0, 1925000000000, 668401878740⟩⟩
    hull012_053 1 (by decide +kernel)

private def supportedCone1652 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨13, 14, 14, 13, 14⟩, ⟨1662166960, 7812264, 0, 0, 234169202073, 10325789⟩⟩
    hull012_056 1 (by decide +kernel)

private def supportedCone1653 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨652, 653, 652, 652, 653⟩, ⟨0, 0, 5000000000, 26220994, 1925000000000, 668401878740⟩⟩
    hull012_057 0 (by decide +kernel)

private def supportedCone1654 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨653, 655, 653, 653, 655⟩, ⟨0, 0, 7471499637, 38870628, 1930000000000, 668428099734⟩⟩
    hull012_058 0 (by decide +kernel)

private def supportedCone1655 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨650, 655, 655, 650, 655⟩, ⟨22471499637, 117969949, 0, 0, 1937471499637, 668466970362⟩⟩
    hull012_046 1 (by decide +kernel)

private def supportedCone1656 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨652, 653, 653, 652, 653⟩, ⟨5000000000, 26220994, 0, 0, 1930000000000, 668428099734⟩⟩
    hull012_057 1 (by decide +kernel)

private def supportedCone1657 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨653, 654, 653, 653, 654⟩, ⟨0, 0, 5000000000, 26061123, 1930000000000, 668428099734⟩⟩
    hull012_059 0 (by decide +kernel)

private def supportedCone1658 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨654, 655, 654, 654, 655⟩, ⟨0, 0, 2471499637, 12809505, 1935000000000, 668454160857⟩⟩
    hull012_060 0 (by decide +kernel)

private def supportedCone1659 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨653, 654, 654, 653, 654⟩, ⟨5000000000, 26061123, 0, 0, 1935000000000, 668454160857⟩⟩
    hull012_059 1 (by decide +kernel)

private def supportedCone1660 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨653, 655, 655, 653, 655⟩, ⟨7471499637, 38870628, 0, 0, 1937471499637, 668466970362⟩⟩
    hull012_058 1 (by decide +kernel)

private def supportedCone1661 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨654, 655, 655, 654, 655⟩, ⟨2471499637, 12809505, 0, 0, 1937471499637, 668466970362⟩⟩
    hull012_060 1 (by decide +kernel)

private def supportedCone1662 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 673, 649, 648, 657⟩, ⟨2261924095, 11651883, 32738075905, 171633512, 1912261924095, 668334399218⟩⟩
    hull012_061 3 (by decide +kernel)

private def supportedCone1663 : SupportedAppendixCone :=
  supportedAppendixCone ⟨false, ⟨638, 673, 657, 649, 658⟩, ⟨32738075905, 171633512, 5000000000, 31009380, 1945000000000, 668506032730⟩⟩
    hull012_061 4 (by decide +kernel)

def appendixHullConeBlock0051 : AppendixConeBlock AppendixFastCone.Sufficient := 
  ⟨#[
    supportedCone1632,
    supportedCone1633,
    supportedCone1634,
    supportedCone1635,
    supportedCone1636,
    supportedCone1637,
    supportedCone1638,
    supportedCone1639,
    supportedCone1640,
    supportedCone1641,
    supportedCone1642,
    supportedCone1643,
    supportedCone1644,
    supportedCone1645,
    supportedCone1646,
    supportedCone1647,
    supportedCone1648,
    supportedCone1649,
    supportedCone1650,
    supportedCone1651,
    supportedCone1652,
    supportedCone1653,
    supportedCone1654,
    supportedCone1655,
    supportedCone1656,
    supportedCone1657,
    supportedCone1658,
    supportedCone1659,
    supportedCone1660,
    supportedCone1661,
    supportedCone1662,
    supportedCone1663,
  ], rfl⟩

end SubmodularMatching.SourceCertificate.Replay
