import SubmodularMatching.GibbsSpectralLocalAction

/-!
# Natural-number calculation of dyadic transition cells

Each moving rate uses at most two local activity fractions. Multiply
its numerator by the word size and divide using natural arithmetic.
-/

namespace SubmodularMatching.GibbsSampler

open GibbsMatching

/-- An exact unreduced nonnegative activity fraction. -/
structure ActivityWords where
  numerator : ℕ
  denominator : ℕ

noncomputable def ActivityWords.real (a : ActivityWords) : ℝ := (a.numerator:ℝ)/a.denominator

variable {E V : Type*}

/-- Exact lazified rate numerator and denominator for one local action. -/
def LocalAction.rateWords (m : ℕ) (a : E → ActivityWords) : LocalAction E → ActivityWords
  | .hold => ⟨0,1⟩
  | .erase e =>
      let x := a e
      ⟨x.denominator,2*m*(x.numerator+x.denominator)⟩
  | .insert e =>
      let x := a e
      ⟨x.numerator,2*m*(x.numerator+x.denominator)⟩
  | .swap d e =>
      let x := a e
      let y := a d
      let entering := x.numerator*y.denominator
      let leaving := y.numerator*x.denominator
      ⟨entering,2*m*(entering+leaving)⟩

def LocalAction.cellsFromWordSize (m wordSize : ℕ) (a : E → ActivityWords)
    (action : LocalAction E) : ℕ :=
  let r := action.rateWords m a
  wordSize*r.numerator/r.denominator

/-- One natural-number division suffices to evaluate the block size. -/
def LocalAction.cells (m b : ℕ) (a : E → ActivityWords) (action : LocalAction E) : ℕ :=
  action.cellsFromWordSize m (2^b) a

private theorem floor_pow_mul_fraction (b : ℕ) (r : ActivityWords) :
    ⌊r.real*(2:ℝ)^b⌋₊ = 2^b*r.numerator/r.denominator := by
  have h : r.real*(2:ℝ)^b = ((2^b*r.numerator : ℕ):ℝ)/r.denominator := by
    simp only [ActivityWords.real,Nat.cast_mul,Nat.cast_pow,Nat.cast_ofNat]
    rw [div_mul_eq_mul_div,mul_comm (r.numerator:ℝ)]
  rw [h]
  let top := 2^b*r.numerator
  let bottom := r.denominator
  change ⌊(top:ℝ)/(bottom:ℝ)⌋₊ = top/bottom
  by_cases hZero : bottom = 0
  · simp [hZero]
  · have hPos : 0 < bottom := Nat.pos_of_ne_zero hZero
    have hR : 0 < (bottom:ℝ) := by exact_mod_cast hPos
    apply (Nat.floor_eq_iff (div_nonneg (by positivity) hR.le)).mpr
    constructor
    · exact (le_div_iff₀ hR).mpr (by exact_mod_cast Nat.div_mul_le_self top bottom)
    · apply (div_lt_iff₀ hR).mpr
      have hlt := Nat.lt_mul_div_succ top hPos
      rw [Nat.mul_comm bottom] at hlt
      exact_mod_cast hlt

variable [DecidableEq E] [DecidableEq V]

private theorem offDiagonal_eq_transition_of_ne (ends : E → Finset V) (edges : Finset E)
    (a : E → ℝ) {M N : Finset E} (h : M ≠ N) :
    offDiagonal ends edges a M N = transition ends edges a M N := by
  classical
  rw [transition,if_neg h]

/-- Natural cell arithmetic implements the quantized kernel for every
legal action, including the zero cell count of an inadmissible proposal. -/
theorem legalLocalAction_cells_eq (ends : E → Finset V) (edges : Finset E)
    (a : E → ActivityWords) (ha : ∀ e ∈ edges, 0 < (a e).numerator ∧ 0 < (a e).denominator)
    (b : ℕ) (M : Finset E) (hM : M ∈ matchings ends edges)
    (e : E) (he : e ∈ edges) (action : LocalAction E)
    (hAction : LegalLocalAction ends M e action) :
    action.cells edges.card b a =
      moveCells ends edges (fun d => (a d).real) b M (proposal ends M e) := by
  let activity := fun d => (a d).real
  have hm : 0 < (edges.card:ℝ) := by exact_mod_cast Finset.card_pos.mpr ⟨e,he⟩
  have hNum : 0 < ((a e).numerator:ℝ) := by exact_mod_cast (ha e he).1
  have hDen : 0 < ((a e).denominator:ℝ) := by exact_mod_cast (ha e he).2
  have hActionEq := hAction.apply_eq_proposal ends M e action
  rw [← hActionEq]
  unfold moveCells LocalAction.cells LocalAction.cellsFromWordSize
  rw [← floor_pow_mul_fraction]
  congr 1
  congr 1
  cases hAction with
  | hold hne hBlock =>
    simp [LocalAction.rateWords,ActivityWords.real,LocalAction.apply,offDiagonal_self]
  | erase heM =>
    have hne : M ≠ M.erase e := fun h => (Finset.notMem_erase e M) (h ▸ heM)
    change (LocalAction.rateWords edges.card a (.erase e)).real =
      offDiagonal ends edges activity M (M.erase e)
    rw [offDiagonal_eq_transition_of_ne _ _ _ hne,deletion_transition _ _ _ _ _ heM]
    simp only [LocalAction.rateWords,ActivityWords.real,Nat.cast_mul,Nat.cast_add,Nat.cast_ofNat,activity]
    have hsum : 0 < ((a e).numerator:ℝ)+((a e).denominator:ℝ) := by positivity
    field_simp; ring
  | insert hneM hBlock =>
    have hne : M ≠ insert e M := fun h => hneM (h.symm ▸ Finset.mem_insert_self e M)
    change (LocalAction.rateWords edges.card a (.insert e)).real =
      offDiagonal ends edges activity M (insert e M)
    rw [offDiagonal_eq_transition_of_ne _ _ _ hne,insertion_transition _ _ _ _ _ hneM hBlock]
    simp only [LocalAction.rateWords,ActivityWords.real,Nat.cast_mul,Nat.cast_add,Nat.cast_ofNat,activity]
    have hsum : 0 < ((a e).numerator:ℝ)+((a e).denominator:ℝ) := by positivity
    field_simp; ring
  | swap d hneM hBlock =>
    have hdBlock : d ∈ M.filter (fun j => ¬ Disjoint (ends j) (ends e)) := by
      rw [hBlock,Finset.mem_singleton]
    have hdM : d ∈ M := (Finset.mem_filter.mp hdBlock).1
    have hd := ha d (((mem_matchings ..).mp hM).1 hdM)
    have hdNum : 0 < ((a d).numerator:ℝ) := by exact_mod_cast hd.1
    have hdDen : 0 < ((a d).denominator:ℝ) := by exact_mod_cast hd.2
    have hne : M ≠ insert e (M.erase d) := fun h => hneM (h.symm ▸ Finset.mem_insert_self e _)
    change (LocalAction.rateWords edges.card a (.swap d e)).real =
      offDiagonal ends edges activity M (insert e (M.erase d))
    rw [offDiagonal_eq_transition_of_ne _ _ _ hne,swap_transition _ _ _ _ _ _ hneM hBlock]
    simp only [LocalAction.rateWords,ActivityWords.real,Nat.cast_mul,Nat.cast_add,Nat.cast_ofNat,activity]
    have hsum : 0 < ((a e).numerator:ℝ)*((a d).denominator:ℝ) +
        ((a d).numerator:ℝ)*((a e).denominator:ℝ) := by positivity
    field_simp

omit [DecidableEq E] in
/-- With activity numerators and denominators bounded by `B`, the
only numerator multiplication involving the random word stays within
`2^b B^2`, and the divisor is at most `4m B^2` if the graph is nonempty. -/
theorem localAction_word_bounds (m b B : ℕ) (hm : 0 < m) (hB : 0 < B)
    (a : E → ActivityWords) (ha : ∀ e, (a e).numerator ≤ B ∧ (a e).denominator ≤ B)
    (action : LocalAction E) :
    2^b*(action.rateWords m a).numerator ≤ 2^b*B^2 ∧
      (action.rateWords m a).denominator ≤ 4*m*B^2 := by
  have hBSq : B ≤ B^2 := by
    rw [pow_two]
    exact Nat.le_mul_of_pos_right _ hB
  have hmB : 1 ≤ 4*m*B^2 := Nat.succ_le_of_lt (by positivity)
  have hSmall (e : E) : (a e).numerator+(a e).denominator ≤ 2*B^2 := by
    have h := ha e
    omega
  have hLarge (e d : E) : (a e).numerator*(a d).denominator ≤ B^2 := by
    rw [pow_two]
    exact Nat.mul_le_mul (ha e).1 (ha d).2
  constructor
  · apply Nat.mul_le_mul_left
    cases action with
    | hold => simp [LocalAction.rateWords]
    | erase e => exact (ha e).2.trans hBSq
    | insert e => exact (ha e).1.trans hBSq
    | swap d e => exact hLarge e d
  · cases action with
    | hold => exact hmB
    | erase e =>
      change 2*m*((a e).numerator+(a e).denominator) ≤ _
      calc
        _ ≤ 2*m*(2*B^2) := Nat.mul_le_mul_left _ (hSmall e)
        _ = _ := by ring
    | insert e =>
      change 2*m*((a e).numerator+(a e).denominator) ≤ _
      calc
        _ ≤ 2*m*(2*B^2) := Nat.mul_le_mul_left _ (hSmall e)
        _ = _ := by ring
    | swap d e =>
      change 2*m*((a e).numerator*(a d).denominator+(a d).numerator*(a e).denominator) ≤ _
      calc
        _ ≤ 2*m*(2*B^2) := Nat.mul_le_mul_left _ (by have h := hLarge e d; have h' := hLarge d e; omega)
        _ = _ := by ring

end SubmodularMatching.GibbsSampler
