import SubmodularMatching.UpperBoundK1WordStage
import SubmodularMatching.UpperBoundOptimizerOnline

/-! # Discarding completed optimizer stages -/

namespace SubmodularMatching.UpperBoundAssembly

open Joint GibbsSampler Streaming
open scoped BigOperators

noncomputable section

variable {m N : ℕ} {V : Type*} [Fintype V] [DecidableEq V]

variable (cfg : K1OptimizerSettings)

private def derivativeIndexLoop (observe : ℕ → ℤ) (j : ℕ) : ℕ → ℤ → ℤ
  | 0, total => total
  | fuel + 1, total => derivativeIndexLoop observe (j + 1) fuel (total + observe j)

private theorem derivativeIndexLoop_eq (observe : ℕ → ℤ) (j fuel : ℕ) (total : ℤ) :
    derivativeIndexLoop observe j fuel total = total + ∑ i ∈ Finset.range fuel, observe (j + i) := by
  induction fuel generalizing j total with
  | zero => simp [derivativeIndexLoop]
  | succ fuel ih =>
    rw [derivativeIndexLoop, ih, Finset.sum_range_succ']
    simp only [Nat.add_zero]
    have hj (i : ℕ) : j + 1 + i = j + (i + 1) := by omega
    simp_rw [hj]
    abel

/-- Read one pair of sampled sets and add its snapped marginal to the
running sum. The recursion carries an index and the sum. -/
def k1DerivativeIndex (d : ℝ) (draw : Fin N → Finset (Fin m) × Finset (Fin m))
    (f : Finset (Fin m) → ℝ) (e : Fin m) : ℤ :=
  derivativeIndexLoop (fun i => if hi : i < N then
    let s := draw ⟨i, hi⟩
    ⌊4 * Multilinear.derivativeSample f e s.1 s.2 / d⌋
    else 0) 0 N 0

theorem k1DerivativeIndex_eq (d : ℝ) (draw : Fin N → Finset (Fin m) × Finset (Fin m))
    (f : Finset (Fin m) → ℝ) (e : Fin m) :
    k1DerivativeIndex d draw f e = Streaming.sourceIndex d
      (fun i => Multilinear.derivativeSample f e (draw i).1 (draw i).2) := by
  unfold k1DerivativeIndex Streaming.sourceIndex
  rw [derivativeIndexLoop_eq]
  simp only [zero_add]
  rw [← Fin.sum_univ_eq_sum_range]
  apply Finset.sum_congr rfl
  intro i _
  rw [dif_pos i.isLt]

/-- Compute a discounted derivative with a running integer sum. Each pair
of sample sets is read on demand and can be discarded after its value calls. -/
def k1FoldedGradient (tau : ℝ) (Q j : ℕ) (f : Finset (Fin m) → ℝ)
    (samples : DerivativeSamples m N) (i : Fin m) : ℝ :=
  let d := FiniteGreedy.accuracy cfg.degree m cfg.error * tau / 2
  let discount := roundedWeight cfg.degree (FiniteGreedy.stages cfg.degree m cfg.error) (j + 1) Q
  discount * (d * (k1DerivativeIndex d (samples i) f i : ℝ) / (4 * N))

theorem k1FoldedGradient_eq (tau : ℝ) (Q j : ℕ) (f : Finset (Fin m) → ℝ)
    (samples : DerivativeSamples m N) (point : CurrentOptimizerPoint m) :
    k1FoldedGradient cfg tau Q j f samples =
      oracleCoefficient cfg.degree tau cfg.error Q f (fun _ _ => samples) j point := by
  funext i
  simp only [k1FoldedGradient, oracleCoefficient, sourceAverage, k1DerivativeIndex_eq]

/-- Materialize the two coordinate arrays of an optimizer iterate. -/
def retainK1OptimizerCoordinates {α : Type*} (c : Fin m ⊕ Fin m → α) : Fin m ⊕ Fin m → α :=
  let xs : Vector α m := Vector.ofFn (fun i => c (.inl i))
  let ys : Vector α m := Vector.ofFn (fun i => c (.inr i))
  Sum.elim (fun i => xs[i.val]'i.isLt) (fun i => ys[i.val]'i.isLt)

@[simp] theorem retainK1OptimizerCoordinates_eq {α : Type*} (c : Fin m ⊕ Fin m → α) :
    retainK1OptimizerCoordinates c = c := by
  funext i
  cases i <;> simp [retainK1OptimizerCoordinates]

/-- The current point and the completed coefficient array suffice for the
packing update. No derivative sample batch is retained across updates. -/
def k1AdvanceFoldedPoint (ends : Fin m → V × V) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) (Q j : ℕ) (point : CurrentOptimizerPoint m)
    (samples : DerivativeSamples m N) : CurrentOptimizerPoint m :=
  let coeff := sampledCoefficient cfg.p cfg.degree tau w
    (fun _ _ => k1FoldedGradient cfg tau Q j f samples) j point
  let retained := retainK1OptimizerCoordinates (LinearPacking.clipCoefficients coeff)
  let dir := LinearPacking.solve (matrix cfg.p cfg.degree ends ends)
    retained (cfg.error / 8)
  retainK1OptimizerCoordinates (fun i => point i + (1 / FiniteGreedy.stages cfg.degree m cfg.error) * dir i)

theorem k1AdvanceFoldedPoint_eq (ends : Fin m → V × V) (tau : ℝ) (w : Fin m → ℝ)
    (f : Finset (Fin m) → ℝ) (Q j : ℕ) (point : CurrentOptimizerPoint m)
    (samples : DerivativeSamples m N) :
    k1AdvanceFoldedPoint cfg ends tau w f Q j point samples =
      advanceSampledPoint cfg.p cfg.degree tau cfg.error Q ends f w j point samples := by
  unfold k1AdvanceFoldedPoint advanceSampledPoint sampledCoefficient
  simp only [retainK1OptimizerCoordinates_eq, k1FoldedGradient_eq cfg tau Q j f samples point]

/-- The implementation retains the current point, uses the next fresh
word stage, and discards that stage after its averages update the point. -/
def k1LiveOptimizerStep (N : ℕ) (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q bits j : ℕ)
    (point : CurrentOptimizerPoint m) : CandidateLaw (CurrentOptimizerPoint m) := by
  classical
  exact (CandidateLaw.ofMeasure (optimizerWordStageLaw m N bits)).map fun ω =>
    k1AdvanceFoldedPoint cfg ends tau w f Q j
      point (k1OptimizerWordStageDecode cfg hm bits point ω)

def k1LiveOptimizerLaw (N : ℕ) (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q bits : ℕ) :
    CandidateLaw (CurrentOptimizerPoint m) :=
  CandidateLaw.execute (k1LiveOptimizerStep cfg N hm ends tau w f Q bits)
    (FiniteGreedy.stages cfg.degree m cfg.error) 0 (fun _ => 0)

/-- On every supported word sequence the next point is identical to the
transcript proof's point. The good flag is only an event in the proof. -/
theorem k1LiveOptimizerStep_value (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q bits j : ℕ)
    (t : OptimizerTape m N) (test : CurrentOptimizerPoint m → ℝ) :
    let p := k1LiveOptimizerStep cfg N hm ends tau w f Q bits j (k1OptimizerPoint cfg ends tau w f Q t j)
    let q := k1OptimizerWordTapeStep cfg hm ends tau w f Q bits j t
    expected p.outcomes p.mass test =
      expected q.outcomes q.mass (fun u => test (k1OptimizerPoint cfg ends tau w f Q u (j + 1))) := by
  classical
  dsimp only
  unfold k1LiveOptimizerStep k1OptimizerWordTapeStep
  rw [CandidateLaw.map_expected, CandidateLaw.map_expected]
  apply congrArg (expected _ _)
  funext ω
  simp only [Function.comp_apply, k1OptimizerTapeNext_point, k1AdvanceFoldedPoint_eq]

/-- All observables of the final Euler point agree with the tape proof,
even when the observables induce later adaptive sampler calls. -/
theorem k1LiveOptimizerLaw_value (hm : 0 < m) (ends : Fin m → V × V)
    (tau : ℝ) (w : Fin m → ℝ) (f : Finset (Fin m) → ℝ) (Q bits : ℕ)
    (test : CurrentOptimizerPoint m → ℝ) :
    let p := k1LiveOptimizerLaw cfg N hm ends tau w f Q bits
    let q := k1OptimizerWordTapeLaw (N := N) cfg hm ends tau w f Q bits
    let K := FiniteGreedy.stages cfg.degree m cfg.error
    expected p.outcomes p.mass test =
      expected q.outcomes q.mass (fun t => test (k1OptimizerPoint cfg ends tau w f Q t K)) := by
  let s := k1LiveOptimizerStep cfg N hm ends tau w f Q bits
  let r : ℕ → OptimizerTape m N → CandidateLaw (OptimizerTape m N) :=
    k1OptimizerWordTapeStep cfg hm ends tau w f Q bits
  let pt := k1OptimizerPoint (N := N) cfg ends tau w f Q
  have h (fuel j : ℕ) (t : OptimizerTape m N) :
      let p := CandidateLaw.execute s fuel j (pt t j)
      let q := CandidateLaw.execute r fuel j t
      expected p.outcomes p.mass test = expected q.outcomes q.mass (fun u => test (pt u (j + fuel))) := by
    induction fuel generalizing j t with
    | zero =>
      change expected (CandidateLaw.pure (pt t j)).outcomes (CandidateLaw.pure (pt t j)).mass test =
        expected (CandidateLaw.pure t).outcomes (CandidateLaw.pure t).mass
          (fun u => test (pt u (j + 0)))
      simp only [CandidateLaw.pure_expected, Nat.add_zero]
    | succ fuel ih =>
      dsimp only
      rw [CandidateLaw.execute_expected, CandidateLaw.execute_expected]
      rw [k1LiveOptimizerStep_value cfg hm ends tau w f Q bits j t]
      apply congrArg (expected (r j t).outcomes (r j t).mass)
      funext u
      simpa only [show j + 1 + fuel = j + (fuel + 1) by omega] using ih (j + 1) u
  have h0 : pt (OptimizerTape.empty m N) 0 = fun _ => 0 := rfl
  have he := h (FiniteGreedy.stages cfg.degree m cfg.error) 0 (OptimizerTape.empty m N)
  dsimp only at he
  rw [h0, Nat.zero_add] at he
  exact he

end

end SubmodularMatching.UpperBoundAssembly
