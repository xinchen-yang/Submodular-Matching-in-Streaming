import SubmodularMatching.PotentialUpdate

/-!
# A complete single-instance streaming recursion and its incidence invariant

The input contains edges and their recorded weight estimates. The estimates
may be inaccurate; only their deterministic upper bound by the instance's
scale is used for the space analysis. The routine implements the two acceptance
tests and the actual finite endpoint-potential update from `PotentialUpdate`.
-/

namespace SubmodularMatching.Streaming

variable {E V : Type*} [DecidableEq E] [DecidableEq V]

/-- Sparse state of one fixed-guess instance. The counters are proof-side
instrumentation and are not required by the algorithm. -/
structure PotentialState (E V : Type*) where
  stored : Finset E
  potential : V → ℝ
  count : V → ℕ

/-- The empty initial instance. -/
def emptyPotentialState : PotentialState E V := ⟨∅, fun _ => 0, fun _ => 0⟩

/-- Incidence of a vertex with an endpoint pair. -/
def IsIncident (ends : E → V × V) (v : V) (e : E) : Prop :=
  v = (ends e).1 ∨ v = (ends e).2

instance (ends : E → V × V) (v : V) (e : E) : Decidable (IsIncident ends v e) :=
  inferInstanceAs (Decidable (v = (ends e).1 ∨ v = (ends e).2))

/-- Stored edges incident to a given vertex. -/
def storedIncidences (ends : E → V × V) (S : Finset E) (v : V) : Finset E :=
  S.filter (IsIncident ends v)

/-- The accepted-edge operation, including sorting and the one-time grid rounding. -/
noncomputable def acceptPotential (C : PotentialConfig) (ends : E → V × V)
    (st : PotentialState E V) (e : E) (w : ℝ) : PotentialState E V :=
  let u := (ends e).1
  let v := (ends e).2
  let Q := updateUnordered C ⟨st.potential u, st.potential v⟩ w
  { stored := insert e st.stored
    potential := fun x => if x = u then Q.high else if x = v then Q.low else st.potential x
    count := fun x => if IsIncident ends x e then st.count x + 1 else st.count x }

/-- Both acceptance tests from `ProcessEdge`. -/
def accepts (C : PotentialConfig) (ends : E → V × V)
    (st : PotentialState E V) (e : E) (w : ℝ) : Prop :=
  C.theta ≤ w ∧ st.potential (ends e).1 + st.potential (ends e).2 + C.gap ≤ w

/-- The actual single-edge state transition. -/
noncomputable def processPotential (C : PotentialConfig) (ends : E → V × V)
    (st : PotentialState E V) (e : E) (w : ℝ) : PotentialState E V := by
  classical
  exact if accepts C ends st e w then acceptPotential C ends st e w else st

/-- Prefix recursion preserving the arrival order. -/
noncomputable def runPotential (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) : ℕ → PotentialState E V
  | 0 => emptyPotentialState
  | n + 1 => processPotential C ends (runPotential C ends input n) (input n).1 (input n).2

/-- Growth, bounded potentials, and incidence counting at every vertex. -/
def PotentialInvariant (C : PotentialConfig) (ends : E → V × V)
    (st : PotentialState E V) : Prop :=
  ∀ v, 0 ≤ st.potential v ∧ st.potential v ≤ C.cap ∧
    (0 < st.count v → C.seed * C.factor ^ (st.count v - 1) ≤ st.potential v) ∧
    (storedIncidences ends st.stored v).card ≤ st.count v

theorem PotentialConfig.cap_pos (C : PotentialConfig) : 0 < C.cap := by
  have hm : 0 < C.maxRate := C.minLow_pos.trans_le
    (C.base_bounds.2.2.1.trans C.base_bounds.2.2.2)
  have ht : 0 < C.tau := C.theta_pos.trans_le C.theta_le_tau
  apply mul_pos _ ht
  have h := mul_pos (show 0 < C.maxRate + 1 by linarith) C.p_pos
  linarith

/-- The seed and multiplicative update imply the next exponential lower bound. -/
theorem growth_lower_next (C : PotentialConfig) (k : ℕ) (old new : ℝ)
    (hprev : 0 < k → C.seed * C.factor ^ (k - 1) ≤ old)
    (hseed : C.seed ≤ new) (hgrow : C.factor * old ≤ new) :
    C.seed * C.factor ^ ((k + 1) - 1) ≤ new := by
  by_cases hk : k = 0
  · simpa [hk] using hseed
  · have hk1 : 1 ≤ k := Nat.one_le_iff_ne_zero.mpr hk
    have hp := hprev (Nat.pos_of_ne_zero hk)
    have hm := mul_le_mul_of_nonneg_left hp (le_trans zero_le_one C.factor_gt_one.le)
    calc
      C.seed * C.factor ^ ((k + 1) - 1) =
          C.factor * (C.seed * C.factor ^ (k - 1)) := by
        simp only [Nat.add_sub_cancel]
        conv_lhs => rw [← Nat.sub_add_cancel hk1]
        rw [pow_succ]
        ring
      _ ≤ C.factor * old := hm
      _ ≤ new := hgrow

omit [DecidableEq E] in
/-- The initial empty state satisfies the complete invariant. -/
theorem emptyPotentialState_invariant (C : PotentialConfig) (ends : E → V × V) :
    PotentialInvariant C ends emptyPotentialState := by
  intro v
  simp only [emptyPotentialState, storedIncidences, Finset.filter_empty, Finset.card_empty,
    le_refl, Nat.lt_irrefl, false_implies, and_true, true_and]
  exact C.cap_pos.le

/-- One accepted edge preserves the full per-vertex invariant. -/
theorem acceptPotential_invariant (C : PotentialConfig) (ends : E → V × V)
    (st : PotentialState E V) (e : E) (w : ℝ)
    (hst : PotentialInvariant C ends st)
    (ha : accepts C ends st e w) (hw : w ≤ C.tau) :
    PotentialInvariant C ends (acceptPotential C ends st e w) := by
  have hQ := updateUnordered_accepted_bounds C
    ⟨st.potential (ends e).1, st.potential (ends e).2⟩ w
    (hst (ends e).1).1 (hst (ends e).2).1 ha.1 ha.2 hw
  intro v
  have hv := hst v
  by_cases h1 : v = (ends e).1
  · subst v
    have hseed := hQ.2.2.1
    have hgrow := hQ.1
    have hcap := hQ.2.2.2.2.1
    simp only [acceptPotential, IsIncident, ↓reduceIte, true_or]
    refine ⟨C.seed_pos.le.trans hseed, hcap, ?_, ?_⟩
    · intro _
      exact growth_lower_next C (st.count (ends e).1) _ _ hv.2.2.1 hseed hgrow
    · dsimp [storedIncidences]
      rw [Finset.filter_insert]
      simp only [IsIncident, true_or, ↓reduceIte]
      exact (Finset.card_insert_le _ _).trans (Nat.add_le_add_right hv.2.2.2 1)
  · by_cases h2 : v = (ends e).2
    · subst v
      have hseed := hQ.2.2.2.1
      have hgrow := hQ.2.1
      have hcap := hQ.2.2.2.2.2
      simp only [acceptPotential, IsIncident, h1, ↓reduceIte, or_true]
      refine ⟨C.seed_pos.le.trans hseed, hcap, ?_, ?_⟩
      · intro _
        exact growth_lower_next C (st.count (ends e).2) _ _ hv.2.2.1 hseed hgrow
      · dsimp [storedIncidences]
        rw [Finset.filter_insert]
        simp only [IsIncident, or_true, ↓reduceIte]
        exact (Finset.card_insert_le _ _).trans (Nat.add_le_add_right hv.2.2.2 1)
    · have hi : ¬ IsIncident ends v e := not_or_intro h1 h2
      simp only [acceptPotential, h1, h2, hi, ↓reduceIte, storedIncidences,
        Finset.filter_insert]
      exact hv

/-- Every edge transition preserves the invariant, whether accepted or rejected. -/
theorem processPotential_invariant (C : PotentialConfig) (ends : E → V × V)
    (st : PotentialState E V) (e : E) (w : ℝ)
    (hst : PotentialInvariant C ends st) (hw : w ≤ C.tau) :
    PotentialInvariant C ends (processPotential C ends st e w) := by
  classical
  unfold processPotential
  split_ifs with ha
  · exact acceptPotential_invariant C ends st e w hst ha hw
  · exact hst

/-- The defined streaming algorithm has bounded, geometrically growing
potentials on every transcript whose recorded weights are at most `tau`. -/
theorem runPotential_invariant (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (hw : ∀ i, (input i).2 ≤ C.tau) (n : ℕ) :
    PotentialInvariant C ends (runPotential C ends input n) := by
  induction n with
  | zero => exact emptyPotentialState_invariant C ends
  | succ n ih => exact processPotential_invariant C ends _ _ _ ih (hw n)

/-- Finite-prefix version: no hypothesis is made about nonexistent later arrivals. -/
theorem runPotential_invariant_prefix (C : PotentialConfig) (ends : E → V × V)
    (input : ℕ → E × ℝ) (n : ℕ)
    (hw : ∀ i < n, (input i).2 ≤ C.tau) :
    PotentialInvariant C ends (runPotential C ends input n) := by
  induction n with
  | zero => exact emptyPotentialState_invariant C ends
  | succ n ih =>
      exact processPotential_invariant C ends _ _ _
        (ih (fun i hi => hw i (Nat.lt_trans hi (Nat.lt_succ_self n))))
        (hw n (Nat.lt_succ_self n))

end SubmodularMatching.Streaming
