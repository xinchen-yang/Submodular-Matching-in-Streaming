# Formalizing submodular matching in one-pass streams

Lean 4 and Mathlib formalization of *The Complexity of Submodular Matching in
One-Pass Streams* by Mohammad Hajiaghayi, Morteza Monemizadeh, and Xinchen Yang.
The project covers all 30 numbered results in the revised arXiv manuscript dated
November 24, 2026. The manuscript PDF has SHA-256
`1d18a5bade8049a028f9f9518a44332b1039fa0cc142eba8730ec2f67d3c1e68`.

The final audit checked 8,179 theorem and lemma declarations using only Lean’s
standard axioms `propext`, `Classical.choice`, and `Quot.sound`. The declaration
count includes supporting lemmas. The proof map follows the manuscript numbering.

## Open and check the project

Open the directory containing `lakefile.toml` in VS Code. The project pins
Lean `leanprover/lean4:v4.27.0` and Mathlib `v4.27.0` at commit
`a3a10db0e9d66acbebf76c5e6a135066525ac900`. All dependency revisions are listed
in `lake-manifest.json`.

With Elan, Git, and Python 3 available, run these commands from the project root.

```sh
python3 fetch_cache.py
LEAN_NUM_THREADS=2 python3 verify.py --batch-axioms
```

`fetch_cache.py` fetches the cached dependencies used by the project.
`verify.py` scans the local sources for proof placeholders and extra trust
extensions, runs `lake build`, checks the compiler and pinned dependency
revisions, and verifies that the project root imports every local module. It
generates `Audit.lean` and checks the transitive axiom dependencies of each local
theorem and lemma. The `--batch-axioms` option records their combined
dependencies. Use `python3 verify.py --audit-jobs 3` to record individual
dependencies with three Lean processes.

After the build, these checks display the main statements, the capacity
reduction, the resource bounds, and the Appendix M.5 certificate.

```sh
lake env lean verification/MainStatements.lean
lake env lean verification/Theorem5_1.lean
lake env lean verification/ExtensionStatements.lean
lake env lean verification/ExtensionResources.lean
lake env lean verification/AppendixMDiagnostics.lean
```

The `verification/` directory also contains focused checks for algorithms,
endpoints, and signed execution in `ExtendedAlgorithmChecks.lean`,
`ExtensionEndPoints.lean`, `SignedExecutionChecks.lean`, and
`SignedTheorem5_1.lean`.

## Manuscript proof map

| Manuscript statement | Lean proof and scope |
| --- | --- |
| 1.1, streaming upper bound, factor 4.524656 | `SimpleEdgeStream.theorem1_1_real_verified` and `theorem1_1_real_confidence_verified` specialize the real implementation in K.1 to Appendix L’s kernel-checked constants. They give expected-value and failure-probability guarantees. The K.1 storage and runtime bounds apply to the same program. |
| 1.2 and 4.1, lower bounds below three | `LowerBoundGlobal.theorem1_2_verified` and `theorem1_2_clocked_verified` apply to the same actual hard streams. Both fixed success probability and expectation fail against the true optimum. The proof includes the AJX blueprint construction. The vendored source and its MIT license are in `SubmodularMatching/AJXUpstream/`. |
| 3.1, charging the optimum | `Streaming.sampled_charge_six_epsilon` gives the finite charge. `Streaming.surviving_guess_sampled_charge` and `UpperBoundAssembly.final_trial_quality` instantiate the ignored-prefix and accuracy conditions on the scheduled trace. |
| 3.2, comparison of marginal values | `lemma_3_2` proves the comparison for general first matchings and ordered stored edges. |
| 3.3, continuous greedy | `Joint.greedy_solution` proves the finite Euler guarantee. `Joint.sampled_greedy_solution` and `UpperBoundAssembly.optimizerTape_accurate` handle sampled directional objectives and the accuracy event. |
| 3.4 and D.1, source linear objective | `SourceCertificate.main_run_bound_ideal` derives the checked bound from local source conditions. `CertificateCheckedCover` transfers the exact Appendix L tables and endpoint inequalities to those conditions. |
| 3.5 and H.7, small-coordinate Gibbs rounding | `GibbsMatching.gibbs_epsilon_rounding` proves the explicit $\epsilon^5/5120$ threshold. |
| 3.6, ideal and finite two-stage rounding | `TwoStage.explicit_two_stage_rounding` proves the ideal bound. `compactAppendixTapeOutcomeMass_eq` connects the exact finite word samplers and `appendixRoundingCandidate_error` bounds their value loss. |
| 4.2, certainty entropy bound | `Information.certainty_entropy_bound_on_samples` derives the inclusion-based information bound in bits. |
| 4.3, recursive objective | `RecursiveObjective`, `RecursiveObjectiveGrid`, and `LowerBoundGlobalInstanceFacts` verify monotonicity, submodularity, visibility, marginal limits, and representation by exact words. |
| 4.4, recursive objective profile | `RecursiveObjective.objective_profile_bound` and `RecursiveObjective.objective_good_only_lower_bound` prove the upper profile and the good-only witness. |
| 4.5, two recovery estimates | `LowerBoundGlobal.global_hard_recovery_mean_le` proves both estimates on the actual joint law using adaptive legal oracle queries. |
| Theorem 5.1, monotone 4.525 guarantee | `Capacity.theorem5_1_monotone` and `Capacity.theorem5_1_monotone_confidence` transfer the expectation and confidence guarantees of Theorem 1.1 to the actual one-pass reduced program. The proof imports the checked Appendix L certificate. |
| Theorem 5.1, nonmonotone 4.727 guarantee | `Capacity.theorem5_1_nonmonotone` proves feasibility, expected value, and the $1-n^{-c}$ confidence guarantee for the concrete one-pass algorithm on a simple graph with arbitrary capacities and a nonnegative submodular oracle. `Capacity.theorem5_1_nonmonotone_matching` specializes the same program to unit capacities. The forward pass retains the signed records that the sequential optimizer and rounding consume. The public program has checked workspace, query and traversal bounds. |
| Theorem 5.1, resources | `Capacity.nonmonotone_prefix_workspace`, `Capacity.nonmonotone_empty_prefix_workspace`, `Capacity.nonmonotone_query_budget`, and `Capacity.nonmonotone_stream_traversal_budget` apply to the original arrivals. `CapacityPaperPolynomial.lean` proves the query and traversal budgets are polynomial for fixed confidence exponent. `Capacity.reduced_physical_workspace` and `Capacity.reduced_physical_runtime` cover the monotone reduction. `Capacity.firstAnnouncement_decode` and `Capacity.capacityCache_words` cover first-arrival capacities. |
| Proposition 5.2, exact monotone capacity reduction | `Capacity.proposition5_2_verified`, `Capacity.reduced_stream_execution`, and the bounds in `CapacityStream.lean` |
| E.1, linear packing in linear workspace | `LinearPacking.packingE1_entry` selects a dyadic accuracy for the requested tolerance and proves the additive guarantee, grid and iteration bounds. The executable vector solver uses each objective coefficient’s own denominator. |
| F.1, finite multilinear optimizer | `UpperBoundAssembly.f1Optimizer_verified` selects a precision for any positive requested error, and checks the exact finite integer optimizer against all matching comparators at once. `f1Output_grid` gives a common rational output grid. |
| H.1, deletion coupling | `GibbsMatching.exists_vertex_deletion_coupling`. |
| H.2, variance bound | `GibbsMatching.variance_weighted_unmatched_le`. |
| H.3, vertex deletion stability | `GibbsMatching.vertex_deletion_expectation_stability`. |
| H.4, conditional expectations | `GibbsMatching.gibbs_unconditional_regression` and the conditional regression lemmas in that module. |
| H.5, independent rounding comparison | `GibbsMatching.gibbs_submodular_comparison`. |
| H.6, edge marginal calibration | `GibbsMatching.edge_marginal_calibration`. |
| J.1, two-stage rounding for arbitrary simple graphs | `TwoStage.separate_alteration_correct` derives retention and feasibility on separate, possibly overlapping supports. `TwoStage.separateWordCandidateMass_lower_bound` connects the actual finite word samplers to that value bound with explicit finite losses. |
| K.1, finite implementation | `SimpleEdgeStream.theoremK1_verified` proves (FJ2) and amplification for arbitrary admissible parameters. `StreamingK1RealSamplewise` checks the one-pass sparse source and `UpperBoundK1IntegerArchive` connects the finite optimizer to the actual retained records. `UpperBoundK1Rounding` verifies the two finite word samplers. `archivedWorkspace_le` bounds the working storage, and `archivedRuntime_polynomial` gives the query and arithmetic budgets on the same archive. |
| L.1, approximation family | `approximationFamily_real_corollary_verified` uses the same kernel-checked certificate and sparse implementation as 1.1 and proves the $4.5246551+\epsilon$ guarantee. |
| Lemma M.1, Gibbs rounding for an unnormalized nonnegative submodular function | `GibbsMatching.lemmaM1_verified` |
| Lemma M.2, projection onto edge labels and the union of independent layers | `Shearer.lemmaM2_projected` and `Shearer.LabelLayer.lemmaM2_independent_layers` |
| Appendix M.5, directed square-root endpoints | `AppendixM.arxiv_priority_certificate` proves the directed root enclosure, `gamma_le_priority`, and the exact printed bound `1 / beta < 4.726494 < 4.727`. Lean checks inequality (26) over all 27,648 rate intervals. `AppendixMDiagnosticCertificate.lean` checks all four printed slack bounds over the full rate table. |

## Implementation and probability

The mathematical proofs use the manuscript’s value-oracle arithmetic
model. The generic source keeps the current real scale and rounds each current
oracle difference onto a bounded integer grid using exact comparisons. The
index bounds count the stored grid indices and charge any representation of
the original scale and oracle replies separately, as in Appendix K.5.

- `StreamingSourceTape` and `UpperBoundOptimizerTapeFailure` prove the
  preparation failure budget for the actual adaptive schedule.
  `UpperBoundPreparedProgram` connects the successful preparation to the
  selected stored guesses, the compact sampled optimizer and rounding.
- `StreamingOnlineAppendixRun` and `StreamingOnlineExecutionLaw` identify the
  sparse forward source run and preserve the exact source-word distribution.
  `UpperBoundWordProgram` passes the distribution through the optimizer and
  final output. `UpperBoundOptimizerOnline` transfers all final-point
  observables to a stage process that retains the current Euler point.
- `GibbsSpectralIntegerBudget` proves a polynomial mixing bound from weighted
  canonical paths. Its weaker explicit gap replaces the use of the sharper
  cited Sinclair bound. `FiniteShearerTapeCandidate` identifies the two
  executable word-based rounding stages with the actual compact candidate
  law, including the embedding into original edge identifiers.
- `UpperBoundProgramResources` bounds the query and arithmetic visit counts
  for the concrete schedule by $O_c(n^{10}\log^2 n)$ and
  $O_c(n^{22}\log n)$, respectively. `StreamingSourceTapeWorkspace` and
  `StreamingOnlineAppendixWorkspace` give the simultaneous record and
  scratch bounds even on inaccurate estimation histories. The sequential
  workspace bound has $O((\nu+1)\log^2 n)$ words. The finite bit budget
  uses $O_c(\log n)$-bit words.

The arbitrary-parameter Appendix K proof uses one source sample at a time
and one derivative sample pair at a time. Its analysis couples the sparse
execution to a transcript. The actual output law passes only the current
source state, retained optimizer points, and matching registers between
phases. The resource results bound the physical archive, shared scratch,
integer comparison operands, and actual sampler schedules. Confidence
amplification uses a finer rational comparison grid when the target factor
is close to the conditional bound.

## Numerical certificate verification

The default proof of Theorem 1.1 assembles `Replay.UncoveredMiddle.checked`
from 1,734 standard-kernel proof fragments in
`SubmodularMatching/ReplayUncoveredMiddle/`. They cover 348,985 certificate
rectangles in the middle rate range. The proof combines them with the certified
endpoint margins and the other coverage classes. `UpperBoundFixedK1Program`
uses this certificate for Theorem 1.1 and the approximation family in
Corollary L.1.

The grouped Appendix L check verifies those proof fragments in resumable
batches. The command also checks Theorem 1.1 and the monotone guarantee
in Theorem 5.1.

```sh
lake env python3 verification/aggregate_replay.py ../checked-appendix-l --prepare --jobs 3 --check-monotone
```

The Appendix M.5 certificate supplies the constants for the nonmonotone
guarantee in Theorem 5.1. It proves `gamma_le_priority` using the two-sided
square-root enclosure. The full Appendix M.5 check above covers the four slack
bounds. To check the square-root enclosure and approximation factor on their
own, run these commands.

```sh
lake build SubmodularMatching.AppendixMArxivConstants
lake env lean verification/ArxivConstants.lean
```

For the original Appendix L tables, exact arithmetic, and regeneration
instructions, see [certificate/README.md](certificate/README.md).
`python3 certificate/check_price_partition.py` and
`lake env lean --run certificate/CheckPricePartition.lean` run the compressed
arithmetic check. The optional compiler-trusted entry point
`lake env lean certificate/NativePricePartition.lean` reports its two additional
axiom dependencies.

## Verification reports

The bundled [revised verification receipt](verification/revised-receipt.json)
records the full project’s source-tree digest, compiler, declaration count, and
combined axioms. The [axiom audit](verification/revised-union.log) and
[dependency check](verification/extension-dependency-refresh.json) accompany it.

The bundled `verification/summary.json`, `verification/build.log`,
`verification/axioms.log`, and `Audit.lean` record the original manuscript
run. A local `verify.py` run regenerates them for the revised project.
The archive contains the project sources. The dependency setup and build above
supply the compiled dependencies and local build artifacts.